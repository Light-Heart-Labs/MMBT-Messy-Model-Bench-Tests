# Verification Notes for logalyzer Code Review Triage

## Summary

- **6 real issues** confirmed in the codebase
- **9 fabricated issues** — the previous reviewer invented files, misattributed functions, or claimed bugs that don't exist

## Real Issues

### 001 — `from collections import Iterable` (filters.py:5)
Confirmed. This import was removed in Python 3.10. Running on Python 3.11 raises `ImportError`. The fix is `from collections.abc import Iterable`.

### 002 — `eval()` in expression_filter (filters.py:59)
Confirmed. The function uses `eval()` with restricted builtins but still allows attribute access on the `entry` object. This is a security concern for untrusted input.

### 004 — README claims "Real-time tail mode" (README.md:15)
Confirmed. The README lists "Real-time tail mode for live log streams" as a feature, but there is no `--tail` flag, no streaming logic, and no tail functionality anywhere in the codebase.

### 006 — experimental.py is dead code
Confirmed. The file exists but is never imported by any other module. No grep for "experimental" in any .py file (outside the file itself) returns results.

### 013 — O(n²) performance in io.py load()
Confirmed. Two anti-patterns:
- `result = result + [entry]` at line 24 (creates new list each iteration)
- `accumulated = accumulated + ch` at line 27 (character-by-character string concatenation)

### 014 — O(n) membership test in ip_allowlist_filter (filters.py:36)
Confirmed. `entry.ip in allowlist` where allowlist is a list from argparse's `action='append'`. Should be converted to a set for O(1) lookups.

## Fabricated Issues

### 003 — SQL injection in parser.py
Fabricated. parser.py contains no SQL queries, no database interaction, and no string concatenation for SQL. The parser only does regex-based log line parsing.

### 005 — --top flag broken (cli.py)
Fabricated. The `--top` flag is defined with `type=int` at cli.py:31, which correctly converts the argument. No AttributeError occurs.

### 007 — CSRF in web.py
Fabricated. `logalyzer/web.py` does not exist. There is no web interface in the codebase.

### 008 — 8192-char truncation in parser.py
Fabricated. `parse_line()` does not truncate input. It processes the full line via regex matching.

### 009 — format_legacy() in output.py
Fabricated. The function exists in `utils.py:21`, NOT in `output.py`. The issue cites the wrong file. Per the rules, a wrong file citation makes the issue fabricated.

### 010 — Race condition in io.py load_iter()
Fabricated. Each call to `load_iter()` opens its own independent file handle. There is no shared mutable state between concurrent calls. The claimed race condition doesn't exist.

### 011 — Double-counting 3xx in by_status()
Fabricated. `by_status()` simply increments a Counter for each entry's status code. There is no special handling of 3xx codes and no double-counting behavior.

### 012 — Stale cache in cache.py
Fabricated. `logalyzer/cache.py` does not exist. There is no caching layer in the codebase.

### 015 — __init__.py imports LogEntry
Fabricated. `__init__.py` only contains `__version__ = "0.2.0"` and a docstring. It does NOT import LogEntry from parser. The claim is entirely fabricated.
