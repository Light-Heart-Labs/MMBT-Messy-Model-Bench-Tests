# ADR-001: Issue 009 — format_legacy() file attribution

## Context
Issue 009 claims `format_legacy()` is in `logalyzer/output.py` and is unused.

## Investigation
- `format_legacy()` does exist, but in `logalyzer/utils.py:21`, not `output.py`
- The function is indeed unused (no other module imports it)
- `output.py` contains: `to_json`, `to_csv`, `to_text`, `render_aggregate` — no `format_legacy`

## Decision
**Verdict: fabricated**

Per the rules: "A wrong file citation makes the issue fabricated." The issue explicitly claims the function is in `output.py`, which is incorrect. While the function does exist elsewhere and is indeed unused, the original claim as written (citing `output.py`) is not verifiable against the actual codebase.

## Rationale
The task instructions are explicit: "If issue 009 claims a function is in `output.py` but the function actually lives in `utils.py`, the issue as written is fabricated." This is a direct match to that scenario.

---

# ADR-002: Issue 010 — Race condition in load_iter()

## Context
Issue 010 claims a race condition when `load_iter()` is called concurrently by multiple threads.

## Investigation
- `load_iter()` opens its own file handle per call: `with open(path, "r") as f:`
- Each call gets an independent file descriptor
- There is no shared mutable state between calls
- The only shared resource is the file on disk, which is read-only

## Decision
**Verdict: fabricated**

## Rationale
The claim describes a race condition that doesn't exist. Each invocation of `load_iter()` is fully self-contained with its own file handle. There is no lock needed because there is no shared state. The reviewer appears to have assumed a shared file handle pattern that isn't present in the code.

---

# ADR-003: Issue 015 — __init__.py imports LogEntry

## Context
Issue 015 claims `__init__.py` imports `LogEntry` from `parser` but `parser.py` doesn't export it.

## Investigation
- `__init__.py` contains only `__version__ = "0.2.0"` and a docstring
- It does NOT import `LogEntry` from anywhere
- `parser.py` does define `LogEntry` as a dataclass at line 28

## Decision
**Verdict: fabricated**

## Rationale
The claim is doubly wrong: (1) `__init__.py` doesn't import `LogEntry` at all, and (2) `parser.py` does define and export `LogEntry`. The entire premise of the issue is fabricated.
