# CHANGELOG

## v0.3.2 — Test Coverage Addition

### Coverage Delta

| Metric | Before | After |
|--------|--------|-------|
| Total coverage | 34% (190/287 missed) | 97% (8/287 missed) |
| Tests passing | 14 | 167 |
| Tests failing (pre-existing) | 3 | 3 |

### Per-Module Coverage

| Module | Before | After |
|--------|--------|-------|
| `__init__.py` | 100% | 100% |
| `aggregate.py` | 100% | 100% |
| `cli.py` | 0% | 90% |
| `experimental.py` | 0% | 100% |
| `filters.py` | 74% | 100% |
| `io.py` | 0% | 100% |
| `output.py` | 0% | 100% |
| `parser.py` | 86% | 96% |
| `utils.py` | 0% | 100% |

### New Test Files

1. **`tests/test_experimental.py`** (16 tests)
   - `detect_anomalies`: empty list, single entry, uniform distribution, spike detection, same-minute entries, second truncation, bucket datetime format
   - `session_window`: empty list, single entry, same-IP grouping, gap splitting, custom window, multiple IPs, time sorting, boundary conditions

2. **`tests/test_io.py`** (15 tests)
   - `load()`: empty file, single line with/without newline, mixed valid/invalid, only invalid, blank lines, whitespace lines, multiple lines, return type
   - `load_iter()`: empty file, yielding entries, skipping invalid, generator type, no trailing newline, equivalence with `load()`

3. **`tests/test_output.py`** (26 tests)
   - `to_json()`: empty list, single/multiple entries, timestamp format, special chars, zero/large bytes
   - `to_csv()`: empty list, single/multiple entries, comma in URL, timestamp format
   - `to_text()`: empty list, single/multiple entries, IP alignment, method alignment
   - `render_aggregate()`: text/json with Counter/dict/list, unknown format error, defaults, empty inputs

4. **`tests/test_utils.py`** (29 tests)
   - `parse_iso_date()`: valid dates, leap year, year boundaries, invalid format, nonexistent dates, empty string, partial dates
   - `format_bytes()`: zero, below KB, exact KB/MB/GB/TB, above TB, fractional, negative
   - `format_legacy()`: basic format, structure, timestamp inclusion
   - `chunked()`: empty sequence, size 1, exact division, remainder, strings, generator type, single element

5. **`tests/test_filters_extended.py`** (20 tests)
   - `expression_filter`: status comparison, complex expressions, IP check, URL contains, always true/false, bool return
   - `combine_and`: no predicates, single predicate, all match, short-circuit (first/second fail), three predicates
   - Edge cases: zero/999 status, empty regex pattern, special regex chars, date_range with None bounds

6. **`tests/test_parser_extended.py`** (23 tests)
   - `parse_lines`: empty iterable, single line, skip invalid, generator type
   - `parse_line`: whitespace, leading/trailing whitespace, various status codes/methods/protocols, unicode URL, query strings, IPv6, large bytes, special user chars
   - `parse_timestamp`: positive/negative timezone, UTC, midnight/end-of-day, invalid format, missing timezone, malformed date, all months

7. **`tests/test_cli.py`** (24 tests)
   - `build_parser`: return type, version action, required paths, single/multiple paths, all flags (--status, --url, --ip, --since, --until, --aggregate, --format, --top, --expr), defaults
   - `main()`: text/json/csv output, aggregate status/url/hour, return code, empty file, missing file

### Pre-existing Test Failures (Not Fixed)

Three starter tests fail due to bugs in the source code:
1. `test_status_filter_works_with_cli_string_input` — `status_filter` doesn't convert string to int
2. `test_url_regex_finds_substring_match` — `url_regex_filter` uses `re.match()` instead of `re.search()`
3. `test_timestamp_july_parses_correctly` — `MONTH_NAMES` list is missing "Jul"

See `research/dead-ends.md` for details.

### Infrastructure

- Added `conftest.py` monkey-patch for `collections.Iterable` compatibility (Python 3.11)
- No production code changes — all `/logalyzer/` files are byte-identical to input
