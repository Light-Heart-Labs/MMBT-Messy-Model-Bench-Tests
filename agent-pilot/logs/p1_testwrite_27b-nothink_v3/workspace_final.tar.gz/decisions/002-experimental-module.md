# ADR-002: Testing experimental.py — Keep or Remove?

## Context

`experimental.py` contains two functions: `detect_anomalies` (z-score-based anomaly detection) and `session_window` (session grouping by IP with time-based windowing). The module is marked "experimental" and "not yet wired into the CLI."

## Decision

**Test it.** Despite being marked experimental, the code is real, non-trivial logic that:
1. Has 0% test coverage
2. Contains mathematical logic (z-score calculation) that benefits from edge-case testing
3. Has clear, testable behavior (returns lists of datetimes/tuples)

## Rationale

- The goal of this exercise is increasing coverage and exercising code paths
- Testing experimental code doesn't commit to keeping it — it just ensures the code works as written
- If the code is later removed, the tests will be removed too (that's refactoring, out of scope)

## Recommendation (for future work)

The `experimental.py` module should either be:
1. **Integrated** into the CLI with proper argument flags, or
2. **Removed** if the feature is abandoned

The current state (code exists but is unused and untested) is the worst of both worlds.
