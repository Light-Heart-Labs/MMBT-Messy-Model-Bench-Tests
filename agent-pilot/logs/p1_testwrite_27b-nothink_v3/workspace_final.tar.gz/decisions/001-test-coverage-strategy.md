# ADR-001: Test Coverage Strategy for Under-Covered Modules

## Context

The logalyzer codebase has 34% test coverage. The following modules have 0% coverage:
- `experimental.py` (32 statements) — anomaly detection and session windowing
- `io.py` (26 statements) — file loading helpers
- `output.py` (35 statements) — JSON/CSV/text output formatters
- `utils.py` (21 statements) — utility functions including `format_legacy()`
- `cli.py` (59 statements) — CLI entry point

Partially covered:
- `filters.py` (74%) — missing tests for `expression_filter`, `combine_and`
- `parser.py` (86%) — missing edge cases for `parse_lines`, malformed timestamps

## Decision

Target modules in order of value:

1. **`experimental.py`** — 0% coverage, has real logic (z-score anomaly detection, session windowing). Test edge cases: empty entries, single entry, entries with same timestamp, large gaps.

2. **`io.py`** — 0% coverage, file I/O. Test with temp files: empty file, file with no trailing newline, file with mixed valid/invalid lines.

3. **`output.py`** — 0% coverage, output formatters. Test `to_json`, `to_csv`, `to_text`, `render_aggregate` with various inputs including empty lists, special characters in URLs, `format_legacy` from utils.

4. **`utils.py`** — 0% coverage. Test `parse_iso_date` with invalid dates, `format_bytes` at boundary values (0, 1023, 1024, etc.), `format_legacy`, `chunked` with edge sizes.

5. **`filters.py`** — 74% coverage. Test `expression_filter` (eval-based), `combine_and` with zero/one/many predicates.

6. **`parser.py`** — 86% coverage. Test `parse_lines` generator, malformed timestamps, unicode URLs, very long lines.

7. **`cli.py`** — 0% coverage. Test `build_parser` with various arg combinations, `main` with temp log files.

## Rationale

- `experimental.py` and `io.py` are the highest value because they have 0% coverage and contain non-trivial logic.
- `output.py` is important because output formatting bugs would be hard to detect without tests.
- `utils.py` has `format_legacy()` which is explicitly called out as uncovered.
- Edge cases (empty inputs, boundary values, malformed data) provide more signal than happy-path tests.

## Not Testing

- I will NOT test the 3 failing starter tests — they document bugs that I'm not fixing.
- I will NOT test `cli.py`'s `main()` function extensively because it requires file I/O and argparse; I'll test `build_parser` and a minimal integration test.
