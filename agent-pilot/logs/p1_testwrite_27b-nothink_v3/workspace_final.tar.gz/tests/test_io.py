"""Tests for io.py — file loading helpers.

This module had 0% coverage. Tests target edge cases:
- Empty files
- Files with no trailing newline
- Files with mixed valid/invalid lines
- Large files (generator behavior)
- Files with only whitespace/blank lines
"""
import os
import tempfile

from logalyzer.io import load, load_iter
from logalyzer.parser import LogEntry


VALID_LINE = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326'
INVALID_LINE = "this is not a valid log line"


def test_load_empty_file():
    """An empty file should return an empty list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("")
        path = f.name
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_single_valid_line_with_newline():
    """A file with one valid line and trailing newline."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
        assert result[0].status == 200
    finally:
        os.unlink(path)


def test_load_single_valid_line_no_trailing_newline():
    """A file with one valid line but no trailing newline — the final line handler must work."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE)  # no \n at end
        path = f.name
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_mixed_valid_and_invalid_lines():
    """Invalid lines should be silently skipped."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(INVALID_LINE + "\n")
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 2
        assert all(e.ip == "127.0.0.1" for e in result)
    finally:
        os.unlink(path)


def test_load_file_with_only_invalid_lines():
    """A file with only invalid lines should return empty list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(INVALID_LINE + "\n")
        f.write("another bad line\n")
        path = f.name
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_file_with_blank_lines():
    """Blank lines should be skipped (parse_line returns None for empty strings)."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("\n")
        f.write(VALID_LINE + "\n")
        f.write("\n")
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_file_with_only_whitespace_lines():
    """Lines with only whitespace should be skipped."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("   \n")
        f.write("\t\n")
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 1
    finally:
        os.unlink(path)


def test_load_multiple_lines():
    """Multiple valid lines should all be parsed."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        for i in range(10):
            f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 10
    finally:
        os.unlink(path)


def test_load_returns_list_of_logentry():
    """load() should return a list of LogEntry objects."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load(path)
        assert isinstance(result, list)
        assert isinstance(result[0], LogEntry)
    finally:
        os.unlink(path)


# ---- load_iter ----


def test_load_iter_empty_file():
    """load_iter on an empty file should yield nothing."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("")
        path = f.name
    try:
        result = list(load_iter(path))
        assert result == []
    finally:
        os.unlink(path)


def test_load_iter_yields_entries():
    """load_iter should yield LogEntry objects for valid lines."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = list(load_iter(path))
        assert len(result) == 2
        assert all(isinstance(e, LogEntry) for e in result)
    finally:
        os.unlink(path)


def test_load_iter_skips_invalid_lines():
    """load_iter should skip invalid lines, just like load()."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(INVALID_LINE + "\n")
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = list(load_iter(path))
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_is_generator():
    """load_iter should return a generator, not a list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load_iter(path)
        # Generators are iterators but not lists
        assert not isinstance(result, list)
        # Consume it
        entries = list(result)
        assert len(entries) == 1
    finally:
        os.unlink(path)


def test_load_iter_no_trailing_newline():
    """load_iter should handle files without trailing newline."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE)  # no \n
        path = f.name
    try:
        result = list(load_iter(path))
        assert len(result) == 1
    finally:
        os.unlink(path)


def test_load_and_load_iter_produce_same_results():
    """load() and load_iter() should produce the same entries for the same file."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(INVALID_LINE + "\n")
        f.write(VALID_LINE + "\n")
        f.write(VALID_LINE)  # no trailing newline
        path = f.name
    try:
        loaded = load(path)
        iterated = list(load_iter(path))
        assert len(loaded) == len(iterated)
        for a, b in zip(loaded, iterated):
            assert a.ip == b.ip
            assert a.status == b.status
            assert a.url == b.url
    finally:
        os.unlink(path)
