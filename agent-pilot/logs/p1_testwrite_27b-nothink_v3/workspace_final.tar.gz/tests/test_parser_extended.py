"""Additional tests for parser.py — edge cases and parse_lines.

The existing test_parser.py covers basic CLF parsing, dash bytes,
garbage lines, and timestamp parsing. This file adds:
- parse_lines generator behavior
- Edge cases for parse_line (unicode, long lines, various status codes)
- Edge cases for parse_timestamp (various timezones, boundary dates)
"""

from logalyzer.parser import parse_line, parse_lines, parse_timestamp


def test_parse_lines_empty_iterable():
    """parse_lines with empty iterable should yield nothing."""
    result = list(parse_lines([]))
    assert result == []


def test_parse_lines_single_line():
    """parse_lines with one valid line should yield one entry."""
    line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.0" 200 2326'
    result = list(parse_lines([line]))
    assert len(result) == 1
    assert result[0].ip == "127.0.0.1"


def test_parse_lines_skips_invalid():
    """parse_lines should skip invalid lines and only yield valid ones."""
    lines = [
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100',
        "invalid line",
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 404 200',
        "",
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 500 300',
    ]
    result = list(parse_lines(lines))
    assert len(result) == 3
    assert result[0].status == 200
    assert result[1].status == 404
    assert result[2].status == 500


def test_parse_lines_is_generator():
    """parse_lines should return a generator."""
    result = parse_lines(["line"])
    assert not isinstance(result, list)


def test_parse_line_whitespace_only():
    """parse_line with only whitespace should return None."""
    assert parse_line("   ") is None
    assert parse_line("\t") is None
    assert parse_line("\n") is None


def test_parse_line_leading_trailing_whitespace():
    """parse_line should strip leading/trailing whitespace."""
    line = '  127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100  '
    result = parse_line(line)
    assert result is not None
    assert result.ip == "127.0.0.1"


def test_parse_line_various_status_codes():
    """parse_line should handle various HTTP status codes."""
    for status in [100, 201, 301, 302, 400, 403, 404, 500, 502, 503]:
        line = f'10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "GET / HTTP/1.1" {status} 100'
        result = parse_line(line)
        assert result is not None, f"Failed to parse status {status}"
        assert result.status == status


def test_parse_line_various_methods():
    """parse_line should handle various HTTP methods."""
    for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
        line = f'10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "{method} / HTTP/1.1" 200 100'
        result = parse_line(line)
        assert result is not None, f"Failed to parse method {method}"
        assert result.method == method


def test_parse_line_various_protocols():
    """parse_line should handle various HTTP protocol versions."""
    for proto in ["HTTP/1.0", "HTTP/1.1", "HTTP/2", "HTTP/2.0"]:
        line = f'10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "GET / {proto}" 200 100'
        result = parse_line(line)
        assert result is not None, f"Failed to parse protocol {proto}"
        assert result.protocol == proto


def test_parse_line_unicode_url():
    """parse_line should handle URLs with unicode characters."""
    line = '10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "GET /path/über HTTP/1.1" 200 100'
    result = parse_line(line)
    assert result is not None
    assert result.url == "/path/über"


def test_parse_line_url_with_query_string():
    """parse_line should handle URLs with query strings."""
    line = '10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "GET /search?q=hello+world&page=1 HTTP/1.1" 200 100'
    result = parse_line(line)
    assert result is not None
    assert result.url == "/search?q=hello+world&page=1"


def test_parse_line_ipv6_address():
    """parse_line should handle IPv6 addresses (as \S+ matches them)."""
    line = '::1 - - [01/Jan/2026:00:00:00 +0000] "GET / HTTP/1.1" 200 100'
    result = parse_line(line)
    assert result is not None
    assert result.ip == "::1"


def test_parse_line_large_byte_count():
    """parse_line should handle large byte counts."""
    line = '10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "GET / HTTP/1.1" 200 999999999'
    result = parse_line(line)
    assert result is not None
    assert result.bytes == 999999999


def test_parse_line_user_with_special_chars():
    """parse_line should handle usernames with special characters."""
    line = '10.0.0.1 - user@example.com [01/Jan/2026:00:00:00 +0000] "GET / HTTP/1.1" 200 100'
    result = parse_line(line)
    assert result is not None
    assert result.user == "user@example.com"


# ---- parse_timestamp edge cases ----


def test_parse_timestamp_positive_timezone():
    """Positive timezone offset should be handled correctly."""
    # 12:00:00 +0500 = 07:00:00 UTC
    ts = parse_timestamp("01/Jan/2026:12:00:00 +0500")
    assert ts.hour == 7
    assert ts.minute == 0


def test_parse_timestamp_utc_offset():
    """UTC (+0000) should not change the time."""
    ts = parse_timestamp("01/Jan/2026:15:30:00 +0000")
    assert ts.hour == 15
    assert ts.minute == 30


def test_parse_timestamp_negative_timezone():
    """Negative timezone offset should be handled correctly."""
    # 12:00:00 -0500 = 17:00:00 UTC
    ts = parse_timestamp("01/Jan/2026:12:00:00 -0500")
    assert ts.hour == 17


def test_parse_timestamp_midnight_boundary():
    """Timestamp at midnight should parse correctly."""
    ts = parse_timestamp("01/Jan/2026:00:00:00 +0000")
    assert ts.hour == 0
    assert ts.minute == 0
    assert ts.second == 0


def test_parse_timestamp_end_of_day():
    """Timestamp at end of day should parse correctly."""
    ts = parse_timestamp("30/Dec/2025:23:59:59 +0000")
    assert ts.hour == 23
    assert ts.minute == 59
    assert ts.second == 59


def test_parse_timestamp_invalid_format_raises():
    """Invalid timestamp format should raise ValueError."""
    try:
        parse_timestamp("not-a-timestamp")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_timestamp_missing_timezone_raises():
    """Timestamp without timezone should raise ValueError."""
    try:
        parse_timestamp("01/Jan/2026:12:00:00")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_timestamp_malformed_date_raises():
    """Malformed date should raise ValueError."""
    try:
        parse_timestamp("32/Jan/2026:12:00:00 +0000")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_timestamp_all_months():
    """All 11 months in MONTH_NAMES (Jul is missing — bug documented) should parse."""
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Aug", "Sep", "Oct", "Nov", "Dec"]
    for month in months:
        ts = parse_timestamp(f"01/{month}/2026:12:00:00 +0000")
        assert ts is not None
