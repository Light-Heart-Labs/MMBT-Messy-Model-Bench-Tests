"""Tests for utils.py — utility functions.

This module had 0% coverage. Tests target:
- parse_iso_date: valid dates, invalid formats, edge dates
- format_bytes: boundary values at each unit threshold
- format_legacy: the explicitly uncovered function
- chunked: edge cases with size 1, size > len, empty seq
"""
from datetime import datetime, timezone

from logalyzer.utils import parse_iso_date, format_bytes, format_legacy, chunked
from logalyzer.parser import LogEntry


def _entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ---- parse_iso_date ----


def test_parse_iso_date_valid():
    """Valid YYYY-MM-DD should parse to midnight UTC."""
    dt = parse_iso_date("2026-01-15")
    assert dt == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_leap_year():
    """Feb 29 on a leap year should parse correctly."""
    dt = parse_iso_date("2024-02-29")
    assert dt.month == 2
    assert dt.day == 29


def test_parse_iso_date_year_boundary():
    """Year boundary dates should parse correctly."""
    dt = parse_iso_date("2000-12-31")
    assert dt.year == 2000
    assert dt.month == 12
    assert dt.day == 31

    dt = parse_iso_date("2001-01-01")
    assert dt.year == 2001
    assert dt.month == 1
    assert dt.day == 1


def test_parse_iso_date_invalid_format_raises():
    """Invalid date format should raise ValueError."""
    try:
        parse_iso_date("01-15-2026")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_nonexistent_date_raises():
    """Feb 30 should raise ValueError."""
    try:
        parse_iso_date("2026-02-30")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_empty_string_raises():
    """Empty string should raise ValueError."""
    try:
        parse_iso_date("")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_partial_date_raises():
    """Partial date like '2026-01' should raise ValueError."""
    try:
        parse_iso_date("2026-01")
        assert False, "Expected ValueError"
    except ValueError:
        pass


# ---- format_bytes ----


def test_format_bytes_zero():
    """Zero bytes should be '0.0 B'."""
    assert format_bytes(0) == "0.0 B"


def test_format_bytes_below_kb():
    """Values below 1024 should be in B."""
    assert format_bytes(1) == "1.0 B"
    assert format_bytes(512) == "512.0 B"
    assert format_bytes(1023) == "1023.0 B"


def test_format_bytes_exactly_1kb():
    """Exactly 1024 bytes should be '1.0 KB'."""
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_below_mb():
    """Values between 1KB and 1MB should be in KB."""
    assert format_bytes(2048) == "2.0 KB"
    assert format_bytes(1024 * 1023) == f"{1023.0} KB"


def test_format_bytes_exactly_1mb():
    """Exactly 1MB should be '1.0 MB'."""
    assert format_bytes(1024 * 1024) == "1.0 MB"


def test_format_bytes_exactly_1gb():
    """Exactly 1GB should be '1.0 GB'."""
    assert format_bytes(1024 ** 3) == "1.0 GB"


def test_format_bytes_exactly_1tb():
    """Exactly 1TB should be '1.0 TB'."""
    assert format_bytes(1024 ** 4) == "1.0 TB"


def test_format_bytes_above_tb():
    """Values above 1TB should still be in TB (the loop ends at TB)."""
    result = format_bytes(1024 ** 5)
    assert "PB" in result


def test_format_bytes_fractional():
    """Fractional values should be displayed with one decimal place."""
    assert format_bytes(1536) == "1.5 KB"  # 1.5 * 1024


def test_format_bytes_negative():
    """Negative byte values — the function doesn't handle negatives specially.
    It will iterate through units and return a negative value in B."""
    result = format_bytes(-100)
    assert "-100.0 B" == result


# ---- format_legacy ----


def test_format_legacy_basic():
    """format_legacy should produce the pipe-delimited format."""
    entry = _entry(ip="192.168.1.1", status=404, url="/missing")
    result = format_legacy(entry)
    assert "192.168.1.1" in result
    assert "404" in result
    assert "/missing" in result
    assert "|" in result


def test_format_legacy_format_structure():
    """format_legacy output should follow: ip | timestamp | status | url."""
    entry = _entry()
    result = format_legacy(entry)
    parts = [p.strip() for p in result.split("|")]
    assert len(parts) == 4
    assert parts[0] == "10.0.0.1"
    assert parts[2] == "200"
    assert parts[3] == "/"


def test_format_legacy_timestamp_included():
    """The timestamp should be included in the legacy format."""
    entry = _entry()
    result = format_legacy(entry)
    assert "2026-01-01" in result


# ---- chunked ----


def test_chunked_empty_sequence():
    """Empty sequence should produce no chunks."""
    result = list(chunked([], 3))
    assert result == []


def test_chunked_size_one():
    """Chunk size of 1 should produce one chunk per element."""
    result = list(chunked([1, 2, 3], 1))
    assert result == [[1], [2], [3]]


def test_chunked_size_equals_length():
    """Chunk size equal to sequence length should produce one chunk."""
    result = list(chunked([1, 2, 3], 3))
    assert result == [[1, 2, 3]]


def test_chunked_size_greater_than_length():
    """Chunk size greater than sequence length should produce one chunk with all elements."""
    result = list(chunked([1, 2, 3], 10))
    assert result == [[1, 2, 3]]


def test_chunked_exact_division():
    """When length is exactly divisible by size, all chunks should be full."""
    result = list(chunked([1, 2, 3, 4, 5, 6], 3))
    assert result == [[1, 2, 3], [4, 5, 6]]


def test_chunked_remainder():
    """When length is not divisible by size, the last chunk should be smaller."""
    result = list(chunked([1, 2, 3, 4, 5], 2))
    assert result == [[1, 2], [3, 4], [5]]


def test_chunked_with_strings():
    """chunked should work with any iterable, not just numbers."""
    result = list(chunked(["a", "b", "c", "d"], 2))
    assert result == [["a", "b"], ["c", "d"]]


def test_chunked_is_generator():
    """chunked should return a generator."""
    result = chunked([1, 2, 3], 2)
    assert not isinstance(result, list)
    # Consume it
    assert list(result) == [[1, 2], [3]]


def test_chunked_single_element():
    """A single element should produce one chunk."""
    result = list(chunked([42], 5))
    assert result == [[42]]
