"""Additional tests for filters.py — expression_filter and combine_and.

The existing test_filters.py covers status_filter, url_regex_filter,
ip_allowlist_filter, and date_range_filter. This file adds coverage for:
- expression_filter (eval-based filtering)
- combine_and (predicate composition)
- Edge cases in existing filters
"""
from datetime import datetime, timezone

from logalyzer.filters import (
    combine_and,
    expression_filter,
    status_filter,
    url_regex_filter,
    date_range_filter,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ---- expression_filter ----


def test_expression_filter_status_comparison():
    """Expression filter should evaluate Python expressions against entry."""
    pred = expression_filter("entry.status >= 400")
    assert pred(_entry(status=404)) is True
    assert pred(_entry(status=200)) is False


def test_expression_filter_complex_expression():
    """Complex expressions with multiple conditions should work."""
    pred = expression_filter("entry.bytes > 1024 and entry.method == 'GET'")
    assert pred(_entry(bytes=2048, method="GET")) is True
    assert pred(_entry(bytes=512, method="GET")) is False
    assert pred(_entry(bytes=2048, method="POST")) is False


def test_expression_filter_ip_check():
    """Expression filter can check IP addresses."""
    pred = expression_filter("entry.ip == '10.0.0.1'")
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="192.168.1.1")) is False


def test_expression_filter_url_contains():
    """Expression filter can check URL content."""
    pred = expression_filter("'admin' in entry.url")
    assert pred(_entry(url="/admin/login")) is True
    assert pred(_entry(url="/index.html")) is False


def test_expression_filter_always_true():
    """An expression that always evaluates to True should match all entries."""
    pred = expression_filter("True")
    assert pred(_entry()) is True
    assert pred(_entry(status=500)) is True


def test_expression_filter_always_false():
    """An expression that always evaluates to False should match no entries."""
    pred = expression_filter("False")
    assert pred(_entry()) is False
    assert pred(_entry(status=500)) is False


def test_expression_filter_returns_bool():
    """expression_filter should always return a bool."""
    pred = expression_filter("entry.status > 0")
    result = pred(_entry())
    assert isinstance(result, bool)


# ---- combine_and ----


def test_combine_and_no_predicates():
    """combine_and with no predicates should return True for all entries."""
    pred = combine_and()
    assert pred(_entry()) is True
    assert pred(_entry(status=500)) is True


def test_combine_and_single_predicate():
    """combine_and with one predicate should behave like that predicate."""
    pred = combine_and(status_filter(200))
    assert pred(_entry(status=200)) is True
    assert pred(_entry(status=404)) is False


def test_combine_and_all_match():
    """combine_and should return True when all predicates match."""
    pred = combine_and(
        status_filter(200),
        expression_filter("entry.method == 'GET'"),
    )
    assert pred(_entry(status=200, method="GET")) is True


def test_combine_and_first_fails():
    """combine_and should short-circuit on first failing predicate."""
    pred = combine_and(
        status_filter(404),  # this fails for status=200
        expression_filter("entry.method == 'GET'"),  # this would pass
    )
    assert pred(_entry(status=200, method="GET")) is False


def test_combine_and_second_fails():
    """combine_and should check second predicate if first passes."""
    pred = combine_and(
        status_filter(200),  # this passes
        expression_filter("entry.method == 'POST'"),  # this fails for GET
    )
    assert pred(_entry(status=200, method="GET")) is False


def test_combine_and_three_predicates():
    """combine_and should work with three or more predicates."""
    pred = combine_and(
        status_filter(200),
        expression_filter("entry.method == 'GET'"),
        expression_filter("entry.bytes > 0"),
    )
    assert pred(_entry(status=200, method="GET", bytes=100)) is True
    assert pred(_entry(status=200, method="GET", bytes=0)) is False


# ---- Additional edge cases for existing filters ----


def test_status_filter_zero_status():
    """Status filter should work with status code 0 (edge case)."""
    pred = status_filter(0)
    assert pred(_entry(status=0)) is True
    assert pred(_entry(status=200)) is False


def test_status_filter_999_status():
    """Status filter should work with high status codes."""
    pred = status_filter(999)
    assert pred(_entry(status=999)) is True


def test_url_regex_empty_pattern():
    """Empty regex pattern should match all URLs (empty regex matches at start)."""
    pred = url_regex_filter("")
    # re.match("", "/anything") returns a match object
    assert pred(_entry(url="/anything")) is True


def test_url_regex_special_chars():
    """Regex with special characters should work."""
    pred = url_regex_filter(r"^/api/\d+")
    assert pred(_entry(url="/api/123")) is True
    assert pred(_entry(url="/api/abc")) is False


def test_date_range_only_since():
    """date_range_filter with only since (no until) should have no upper bound."""
    since = datetime(2026, 1, 1, tzinfo=timezone.utc)
    pred = date_range_filter(since, None)
    assert pred(_entry(timestamp=datetime(2026, 6, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2025, 12, 31, tzinfo=timezone.utc))) is False


def test_date_range_only_until():
    """date_range_filter with only until (no since) should have no lower bound."""
    until = datetime(2026, 1, 1, tzinfo=timezone.utc)
    pred = date_range_filter(None, until)
    assert pred(_entry(timestamp=datetime(2025, 6, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2026, 6, 1, tzinfo=timezone.utc))) is False


def test_date_range_both_none():
    """date_range_filter with both None should match everything."""
    pred = date_range_filter(None, None)
    assert pred(_entry()) is True
    assert pred(_entry(timestamp=datetime(2000, 1, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2100, 12, 31, tzinfo=timezone.utc))) is True
