"""Tests for experimental.py — anomaly detection and session windowing.

This module had 0% coverage. Tests target edge cases:
- Empty entry lists
- Single entries
- Entries with identical timestamps (no variance)
- Entries with large gaps (session boundary)
- Anomaly detection with uniform vs. spike distributions
"""
from datetime import datetime, timedelta, timezone

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1"):
    """Helper to create a LogEntry with a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )


# ---- detect_anomalies ----


def test_detect_anomalies_empty_list():
    """Empty list should return empty list (no anomalies to detect)."""
    assert detect_anomalies([]) == []


def test_detect_anomalies_single_entry():
    """A single entry has zero variance, so threshold equals mean; no anomalies."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts)]
    assert detect_anomalies(entries) == []


def test_detect_anomalies_uniform_distribution():
    """Uniform request counts per minute should produce no anomalies."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    # Each minute has exactly 1 request — perfectly uniform
    assert detect_anomalies(entries) == []


def test_detect_anomalies_spike_detected():
    """A minute with many more requests than others should be flagged.

    With 20 uniform minutes (1 req each) and 1 spike minute (50 reqs),
    the z-score threshold is ~34.6, so 50 > 34.6 is True.
    """
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    # 20 minutes with 1 request each
    entries = [_entry(base + timedelta(minutes=i)) for i in range(20)]
    # Add 50 requests in one minute (minute 10)
    spike_minute = base + timedelta(minutes=10)
    entries += [_entry(spike_minute) for _ in range(50)]
    result = detect_anomalies(entries)
    assert spike_minute in result


def test_detect_anomalies_all_same_minute():
    """All entries in the same minute — one bucket, zero variance, no anomalies."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts) for _ in range(50)]
    assert detect_anomalies(entries) == []


def test_detect_anomalies_seconds_truncated_to_minute():
    """Entries within the same minute but different seconds should be bucketed together."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=30)),
        _entry(base + timedelta(seconds=59)),
    ]
    # All three are in the same minute bucket
    result = detect_anomalies(entries)
    # One bucket with 3 entries, zero variance → no anomalies
    assert result == []


def test_detect_anomalies_returns_bucket_datetimes():
    """Anomaly buckets should be datetime objects with seconds/microseconds zeroed.

    Uses 20 uniform minutes + 1 spike of 50 to ensure the spike exceeds threshold.
    """
    base = datetime(2026, 1, 1, 12, 5, 30, tzinfo=timezone.utc)
    # 20 uniform minutes
    for i in range(20):
        entries_at = base - timedelta(minutes=20 - i)
        entries = [_entry(entries_at)]
    # Spike minute
    spike_minute = base
    entries = [_entry(spike_minute) for _ in range(50)]
    for i in range(1, 21):
        entries.append(_entry(base - timedelta(minutes=i)))
    result = detect_anomalies(entries)
    assert len(result) > 0
    for bucket in result:
        assert bucket.second == 0
        assert bucket.microsecond == 0


# ---- session_window ----


def test_session_window_empty_list():
    """Empty list should return empty sessions."""
    assert session_window([]) == []


def test_session_window_single_entry():
    """A single entry forms one session."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts)]
    sessions = session_window(entries)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    assert ip == "10.0.0.1"
    assert len(session_entries) == 1


def test_session_window_same_ip_grouped():
    """Entries from the same IP within the window should be one session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        _entry(base + timedelta(minutes=20)),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 1
    _, session_entries = sessions[0]
    assert len(session_entries) == 3


def test_session_window_gap_exceeds_window():
    """A gap larger than window_seconds should split into two sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        # 40-minute gap exceeds default 30-minute window
        _entry(base + timedelta(minutes=50)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    _, first = sessions[0]
    _, second = sessions[1]
    assert len(first) == 2
    assert len(second) == 1


def test_session_window_custom_window():
    """Custom window_seconds should be respected."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=5)),
        # 10-minute gap exceeds 5-minute window
        _entry(base + timedelta(minutes=15)),
    ]
    sessions = session_window(entries, window_seconds=300)
    assert len(sessions) == 2


def test_session_window_multiple_ips():
    """Different IPs should produce separate sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base, ip="10.0.0.1"),
        _entry(base + timedelta(minutes=5), ip="10.0.0.2"),
        _entry(base + timedelta(minutes=10), ip="10.0.0.1"),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 2
    ips = {ip for ip, _ in sessions}
    assert ips == {"10.0.0.1", "10.0.0.2"}


def test_session_window_entries_sorted_by_time():
    """Entries within a session should be sorted by timestamp."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base + timedelta(minutes=10)),
        _entry(base),
        _entry(base + timedelta(minutes=5)),
    ]
    sessions = session_window(entries)
    _, session_entries = sessions[0]
    timestamps = [e.timestamp for e in session_entries]
    assert timestamps == sorted(timestamps)


def test_session_window_gap_exactly_at_window_boundary():
    """A gap exactly equal to window_seconds should NOT split (only > splits)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1800)),  # exactly 30 min
    ]
    sessions = session_window(entries, window_seconds=1800)
    # gap == window_seconds, not > window_seconds, so one session
    assert len(sessions) == 1
    _, session_entries = sessions[0]
    assert len(session_entries) == 2


def test_session_window_gap_just_over_window():
    """A gap just over window_seconds should split."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1801)),  # 1 second over
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
