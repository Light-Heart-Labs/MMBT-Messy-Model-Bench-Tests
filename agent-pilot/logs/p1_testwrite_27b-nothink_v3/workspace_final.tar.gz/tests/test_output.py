"""Tests for output.py — JSON, CSV, text formatters and render_aggregate.

This module had 0% coverage. Tests target:
- Empty entry lists
- Special characters in URLs (quotes, commas, unicode)
- render_aggregate with different formats and data types
- Edge cases in JSON/CSV/text output
"""
from datetime import datetime, timezone
from collections import Counter

from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.parser import LogEntry


def _entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ---- to_json ----


def test_to_json_empty_list():
    """Empty list should produce empty JSON array."""
    assert to_json([]) == "[]"


def test_to_json_single_entry():
    """Single entry should produce a JSON array with one object."""
    entries = [_entry()]
    result = to_json(entries)
    assert result.startswith("[{")
    assert result.endswith("}]")
    assert '"ip":"10.0.0.1"' in result
    assert '"status":200' in result
    assert '"bytes":100' in result


def test_to_json_multiple_entries():
    """Multiple entries should be comma-separated in the JSON array."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_json(entries)
    assert result.count('"status"') == 2
    assert '"status":200' in result
    assert '"status":404' in result


def test_to_json_timestamp_isoformat():
    """Timestamps should be rendered in ISO format."""
    entries = [_entry()]
    result = to_json(entries)
    assert "2026-01-01T12:00:00+00:00" in result


def test_to_json_url_with_special_chars():
    """URLs with special characters should be included as-is in JSON.

    Note: The hand-built JSON doesn't escape quotes in URLs — this is
    a known limitation documented but not fixed.
    """
    entries = [_entry(url="/path?foo=bar&baz=1")]
    result = to_json(entries)
    assert "/path?foo=bar&baz=1" in result


def test_to_json_zero_bytes():
    """Zero bytes should be rendered as 0, not '-'."""
    entries = [_entry(bytes=0)]
    result = to_json(entries)
    assert '"bytes":0' in result


def test_to_json_large_bytes():
    """Large byte values should be rendered correctly."""
    entries = [_entry(bytes=1048576)]
    result = to_json(entries)
    assert '"bytes":1048576' in result


# ---- to_csv ----


def test_to_csv_empty_list():
    """Empty list should produce CSV with only the header row."""
    result = to_csv([])
    lines = result.strip().split("\n")
    assert len(lines) == 1
    assert "ip,user,timestamp,method,url,protocol,status,bytes" in lines[0]


def test_to_csv_single_entry():
    """Single entry should produce header + one data row."""
    entries = [_entry()]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 2
    assert "10.0.0.1" in lines[1]


def test_to_csv_multiple_entries():
    """Multiple entries should each get their own row."""
    entries = [_entry(status=200), _entry(status=404), _entry(status=500)]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 4  # header + 3 data rows


def test_to_csv_url_with_comma():
    """URLs containing commas should be properly quoted by csv.writer."""
    entries = [_entry(url="/path?a=1,b=2")]
    result = to_csv(entries)
    # csv.writer should quote fields containing commas
    assert "/path?a=1,b=2" in result


def test_to_csv_timestamp_isoformat():
    """Timestamps in CSV should be in ISO format."""
    entries = [_entry()]
    result = to_csv(entries)
    assert "2026-01-01T12:00:00+00:00" in result


# ---- to_text ----


def test_to_text_empty_list():
    """Empty list should produce empty string."""
    assert to_text([]) == ""


def test_to_text_single_entry():
    """Single entry should produce one line of text."""
    entries = [_entry()]
    result = to_text(entries)
    assert "10.0.0.1" in result
    assert "GET" in result
    assert "200" in result
    assert "/" in result


def test_to_text_multiple_entries():
    """Multiple entries should be newline-separated."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_text(entries)
    lines = result.split("\n")
    assert len(lines) == 2


def test_to_text_ip_right_aligned():
    """IP addresses should be right-aligned in the text output."""
    entries = [_entry(ip="1.2.3.4"), _entry(ip="10.20.30.40")]
    result = to_text(entries)
    lines = result.split("\n")
    # Both IPs should be in the output
    assert "1.2.3.4" in lines[0]
    assert "10.20.30.40" in lines[1]


def test_to_text_method_left_aligned():
    """HTTP methods should be left-aligned."""
    entries = [_entry(method="GET"), _entry(method="POST")]
    result = to_text(entries)
    assert "GET" in result
    assert "POST" in result


# ---- render_aggregate ----


def test_render_aggregate_text_with_counter():
    """render_aggregate with a Counter should produce tab-separated text."""
    agg = Counter({"200": 10, "404": 3, "500": 1})
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_text_with_dict():
    """render_aggregate with a dict should produce tab-separated text."""
    agg = {"a": 1, "b": 2}
    result = render_aggregate(agg, fmt="text")
    assert "a\t1" in result
    assert "b\t2" in result


def test_render_aggregate_text_with_list_of_tuples():
    """render_aggregate with a list of tuples should produce tab-separated text."""
    agg = [("url1", 10), ("url2", 5)]
    result = render_aggregate(agg, fmt="text")
    assert "url1\t10" in result
    assert "url2\t5" in result


def test_render_aggregate_json_with_counter():
    """render_aggregate with json format and Counter."""
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="json")
    assert '"200":10' in result
    assert '"404":3' in result
    assert result.startswith("{")
    assert result.endswith("}")


def test_render_aggregate_json_with_list_of_tuples():
    """render_aggregate with json format and list of tuples."""
    agg = [("a", 1), ("b", 2)]
    result = render_aggregate(agg, fmt="json")
    assert '"a":1' in result
    assert '"b":2' in result


def test_render_aggregate_unknown_format_raises():
    """render_aggregate should raise ValueError for unknown format."""
    agg = Counter({"a": 1})
    try:
        render_aggregate(agg, fmt="xml")
        assert False, "Expected ValueError"
    except ValueError as e:
        assert "unknown format" in str(e)


def test_render_aggregate_default_format_is_text():
    """Default format should be text."""
    agg = Counter({"a": 1})
    result = render_aggregate(agg)
    assert "a\t1" in result


def test_render_aggregate_empty_counter():
    """Empty Counter should produce empty output."""
    agg = Counter()
    result = render_aggregate(agg, fmt="text")
    assert result == ""


def test_render_aggregate_empty_list():
    """Empty list should produce empty output."""
    agg = []
    result = render_aggregate(agg, fmt="text")
    assert result == ""
