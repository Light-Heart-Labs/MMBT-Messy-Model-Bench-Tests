"""Shared pytest fixtures."""
import sys
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Workaround: logalyzer/filters.py imports `Iterable` from `collections`,
# which was removed in Python 3.11 (moved to collections.abc).
# We patch it here so the module can be imported. This is NOT a fix —
# the source code bug is documented in dead-ends.md.
import collections
if not hasattr(collections, "Iterable"):
    from collections.abc import Iterable as _Iterable
    collections.Iterable = _Iterable
