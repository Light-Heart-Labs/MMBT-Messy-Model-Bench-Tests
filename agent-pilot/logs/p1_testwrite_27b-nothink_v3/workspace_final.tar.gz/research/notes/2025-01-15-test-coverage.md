# Working Notes — 2025-01-15

## Initial Assessment

- Baseline coverage: 34% (287 statements, 190 missed)
- 3 pre-existing test failures due to bugs in source code
- 5 modules at 0% coverage: experimental.py, io.py, output.py, utils.py, cli.py

## Test Writing Process

### experimental.py
- `detect_anomalies` uses z-score with threshold = mean + 3*std
- Key insight: with one spike and N uniform buckets, the spike count always equals the threshold exactly (not >). Need more uniform buckets to make the spike exceed threshold.
- `session_window` uses `>` not `>=` for gap comparison — tested boundary condition.

### io.py
- `load()` character-by-character parsing is unusual but works
- `load_iter()` is a generator — tested that it's not a list
- Both handle missing trailing newlines correctly

### output.py
- `to_json()` hand-builds JSON — doesn't escape special chars in strings
- `render_aggregate` supports text/json formats, raises ValueError for unknown
- CSV uses Python's csv.writer which handles quoting automatically

### utils.py
- `format_bytes` has a PB fallback after the TB loop ends
- `format_legacy` is pipe-delimited: `ip | timestamp | status | url`
- `chunked` is a standard generator pattern

### filters.py
- `expression_filter` uses `eval()` with restricted builtins — security concern but not in scope
- `combine_and` short-circuits on first False predicate
- `date_range_filter` with both None matches everything

### parser.py
- `parse_lines` is a generator that yields only valid entries
- `parse_timestamp` handles timezone conversion correctly
- MONTH_NAMES bug (missing "Jul") affects all months after June

### cli.py
- `main()` uses `load_iter()` for streaming
- `build_parser()` has comprehensive argument handling
- Integration tests use temp files

## Coverage Results

| Module | Before | After |
|--------|--------|-------|
| __init__.py | 100% | 100% |
| aggregate.py | 100% | 100% |
| cli.py | 0% | 90% |
| experimental.py | 0% | 100% |
| filters.py | 74% | 100% |
| io.py | 0% | 100% |
| output.py | 0% | 100% |
| parser.py | 86% | 96% |
| utils.py | 0% | 100% |
| **TOTAL** | **34%** | **97%** |
