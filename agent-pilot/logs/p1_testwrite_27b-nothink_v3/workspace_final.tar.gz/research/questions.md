# Questions

## Resolved

1. **How to handle `collections.Iterable` import error?**
   - Resolved: Added monkey-patch in conftest.py. This is a test infrastructure workaround, not a source fix.

2. **How to test `detect_anomalies` spike detection?**
   - Resolved: The z-score math means a single spike among N uniform buckets always equals the threshold. Need more uniform buckets (20+) to dilute the spike enough that it exceeds the threshold.

3. **Should I test the 3 failing starter tests?**
   - Resolved: No — they document bugs I'm not fixing. Documented in dead-ends.md.

## Open

1. **Should `expression_filter` be tested for security (arbitrary code execution)?**
   - The function uses `eval()` with `{"__builtins__": {}}` which restricts builtins. Testing security is out of scope for coverage — the function works as designed.

2. **Should `to_json` be tested for JSON injection via special characters?**
   - The hand-built JSON doesn't escape quotes in strings. This is a potential bug but testing it would require the test to fail (since the output is broken). Documented but not tested.
