# Dead Ends

## Failing Starter Tests (Not Fixed — Per Rules)

Three starter tests fail against the current codebase. These are bugs in the source code that I am NOT fixing per the rules ("you are NOT fixing bugs").

### 1. `test_status_filter_works_with_cli_string_input`

**Bug:** `status_filter` does an `==` comparison between `entry.status` (int) and the provided `status` parameter. When the CLI passes `"404"` (string), `404 == "404"` is `False` in Python. The filter should convert to int.

**Impact:** The `--status` CLI flag is effectively broken for string input.

**Decision:** Documented, not fixed. The test remains as-is in the starter code.

### 2. `test_url_regex_finds_substring_match`

**Bug:** `url_regex_filter` uses `rx.match()` which only matches at the beginning of the string. A pattern like `"admin"` won't match `/admin/login` because the URL starts with `/`. The test expects substring matching but `re.match()` anchors at position 0.

**Impact:** URL regex filtering only works for patterns that match from the start of the URL.

**Decision:** Documented, not fixed. The test remains as-is in the starter code.

### 3. `test_timestamp_july_parses_correctly`

**Bug:** The `MONTH_NAMES` list in `parser.py` is missing "Jul" — it has "Jun" then "Aug" with no "Jul" in between. This causes `ValueError: 'Jul' is not in list` when parsing July timestamps.

**Impact:** Any log entry dated in July will fail to parse.

**Decision:** Documented, not fixed. The test remains as-is in the starter code.

## Conftest Patch for `collections.Iterable`

The source code in `filters.py` imports `from collections import Iterable`, which was removed in Python 3.11 (moved to `collections.abc`). I added a monkey-patch in `conftest.py` to make the module importable. This is NOT a source code fix — it's a test infrastructure workaround.
