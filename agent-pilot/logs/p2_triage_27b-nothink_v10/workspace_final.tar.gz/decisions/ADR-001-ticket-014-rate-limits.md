# ADR-001: Ticket 014 — API Rate Limits Classification

## Context
Ticket 014 from ops@major-customer.com reports hitting API rate limits (600 req/min on Business plan) during nightly data ingestion, resulting in 4 hours of 429 errors. The customer mentions their $48k/yr contract.

## Decision
Classified as **bug-report** with **urgent** urgency.

## Rationale
- The core issue is a technical limitation: the documented rate limit is insufficient for the customer's documented use case (nightly ingestion of trailing-day data).
- While the customer mentions their contract value, they are not disputing charges — they are using it to emphasize business impact and request a higher limit or burst allowance.
- This is not `billing-other` because there is no billing question or dispute.
- This is not `incident-active` because the issue is intermittent (nightly, 2-3am EST) rather than a continuous outage.
- Marked **urgent** because: (a) it's actively blocking data ingestion, (b) the backlog is growing (~200 GB/day per follow-up 023), and (c) there is a quarterly review deadline approaching.

## Alternatives Considered
- `billing-other`: Rejected — no billing question present.
- `incident-active`: Rejected — intermittent, not a continuous outage.
- `feature-request`: Rejected — the customer is reporting a problem with existing functionality, not requesting new features.
