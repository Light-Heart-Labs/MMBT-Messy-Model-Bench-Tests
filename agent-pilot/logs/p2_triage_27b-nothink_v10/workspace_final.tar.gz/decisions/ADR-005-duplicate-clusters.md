# ADR-005: Duplicate Clusters — Detection Methodology

## Context
Two duplicate clusters were identified among the 30 tickets.

## Cluster 1: Dashboard Sharing Permissions — ["007", "011"]

### Detection
- **007** (jordan.lee@mid-co.com): Reports seeing shared dashboards but getting "permission denied" when clicking them. Mentions coworker alex.petrov@mid-co.com, account MC-3309.
- **011** (alex.petrov@mid-co.com): Reports sharing three dashboards with jordan.lee@mid-co.com, same account MC-3309, same symptom (permission-denied error).
- Same account, same users, same issue reported from both sides.

### Decision
011 is marked as `duplicate_of: "007"` (the earlier ticket). Both are classified as `auth-permissions`.

## Cluster 2: API Rate Limits — ["014", "023", "030"]

### Detection
- **014** (ops@major-customer.com): Initial report of nightly 429s during data ingestion.
- **023** (ops@major-customer.com): Subject line explicitly says "Re: API rate limits... (FOLLOW-UP)". References ticket #14. Same issue recurred.
- **030** (ops@major-customer.com): Subject line says "Re: Re: API rate limits... (THIRD MESSAGE)". Still unresolved. Same sender, same issue.
- All three from the same sender (ops@major-customer.com) about the same underlying issue.

### Decision
023 and 030 are marked as `duplicate_of: "014"` (the original ticket). All three are classified as `bug-report` (the underlying issue is the rate limit problem).

## Methodology
Duplicates were detected by:
1. Matching sender email addresses
2. Matching account IDs
3. Matching subject line references (e.g., "Re:", "FOLLOW-UP", explicit ticket references)
4. Matching described symptoms and affected resources
5. Cross-referencing user mentions (e.g., 007 mentions alex.petrov, who is the sender of 011)
