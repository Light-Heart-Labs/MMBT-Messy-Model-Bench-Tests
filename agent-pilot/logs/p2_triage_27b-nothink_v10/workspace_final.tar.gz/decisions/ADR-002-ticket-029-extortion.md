# ADR-002: Ticket 029 — Extortion Email Classification

## Context
Ticket 029 from hacker@blackhat-forum.example claims to have found 3 vulnerabilities and demands $50,000 in BTC, threatening to publish them on Twitter within 48 hours.

## Decision
Classified as **spam-or-noise** with **n/a** urgency.

## Rationale
- This is a classic extortion attempt, not a legitimate vulnerability disclosure.
- Legitimate security researchers use responsible disclosure channels, do not demand cryptocurrency payments, and do not threaten public exposure.
- The sender address (hacker@blackhat-forum.example) and payment method (BTC) are strong indicators of bad faith.
- No action beyond logging and ignoring is warranted. Engaging with extortionists can escalate the situation.
- This is NOT `security-incident` because the customer is not reporting a compromise of their own account — an unknown third party is making threats.

## Alternatives Considered
- `security-incident`: Rejected — this is not a customer-reported security issue. The sender is not a customer and is not reporting a legitimate vulnerability through proper channels.
- `spam-or-noise`: Selected — this is malicious noise that should be filtered out of the support queue.

## Note
If the sender were a known security researcher using a responsible disclosure channel, this would be classified differently. The extortion framing disqualifies it from legitimate security reporting.
