# ADR-003: Ticket 016 — API 500 Errors Classification

## Context
Ticket 016 from dev@platform-engineering.com reports ~30% of POST requests to /api/v2/exports returning 500 since 14:00 UTC today. The status page shows green. They have a SOC1 review tomorrow morning that depends on these exports.

## Decision
Classified as **incident-active** with **urgent** urgency.

## Rationale
- This describes an ongoing outage with a specific start time (14:00 UTC today) and active, measurable impact (30% failure rate).
- The status page showing green while customers experience 500s is itself a concern — the monitoring may not cover this endpoint.
- There is a hard deadline: SOC1 review tomorrow morning.
- This is `incident-active` rather than `bug-report` because: (a) the issue started at a specific time today (suggesting a recent deployment or infrastructure change), (b) it's actively ongoing, and (c) it has immediate business impact.
- A bug-report would be for a reproducible issue that exists in the product design; this appears to be a runtime incident.

## Alternatives Considered
- `bug-report`: Rejected — the temporal nature (started at 14:00 UTC today) and active ongoing impact make this an incident, not a pre-existing bug.
- `incident-active`: Selected — active outage with time-sensitive impact.
