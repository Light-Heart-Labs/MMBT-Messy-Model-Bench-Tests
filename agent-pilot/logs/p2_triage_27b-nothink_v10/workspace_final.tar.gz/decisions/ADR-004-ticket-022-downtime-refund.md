# ADR-004: Ticket 022 — Downtime Refund Classification

## Context
Ticket 022 from brian@retailer.example requests a refund/credit because the platform was down 11 hours over the weekend during their product launch. They reference the status page as confirmation.

## Decision
Classified as **billing-refund** with **normal** urgency.

## Rationale
- The explicit ask is a credit/refund for a period of confirmed downtime.
- The customer references the status page, indicating the downtime was acknowledged by the product team.
- This is a legitimate request — the customer experienced a service disruption during a critical business event.
- Marked **normal** (not urgent) because: (a) the downtime has already occurred and ended, (b) there is no active outage, and (c) this is a post-hoc credit request, not an ongoing issue.
- This is `billing-refund` rather than `billing-other` because the explicit ask is for a credit/refund, not just a billing question.

## Alternatives Considered
- `billing-other`: Rejected — the customer is explicitly asking for a credit, which is a refund-type request.
- `incident-active`: Rejected — the downtime has already ended; this is a post-incident request.
