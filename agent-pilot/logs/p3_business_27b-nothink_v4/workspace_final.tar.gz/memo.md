# Executive Committee Memo — Borealis Analytics Acquisition

**To:** Executive Committee | **From:** Independent Review | **Date:** 2026-04-15
**Re:** Project Lighthouse — Acquisition of Borealis Analytics for $84M

---

## Recommendation: HOLD — Conditional Proceed

I recommend **holding** the LOI decision pending targeted diligence over the next two weeks. The deal has merit, but the pack contains material gaps and internal inconsistencies that must be resolved before committing $84M.

I would move to **proceed** if: (a) the integration plan is reconciled with the strategic rationale, (b) retention conversations expand to include the CTO and key engineers, (c) comparable transactions are fully contextualized with deal structure details, and (d) legal review confirms no material change-of-control risks.

I would move to **pass** if: (a) customer concentration exceeds 40% in the top 5 customers, (b) the CTO or majority of key engineers decline to stay, (c) burn rate acceleration is unexplained or worsening, or (d) legal review uncovers material change-of-control provisions in customer contracts.

---

## Strongest Concerns

### 1. Integration plan contradicts strategic rationale

The pack states Aurora "overlaps minimally" with our offerings (~12% feature overlap) and is "differentiated vs current alternatives." Yet the integration plan calls for **Aurora platform sunset at 12 months post-close** with full customer migration to our platform. If Aurora is truly differentiated, why sunset it? This contradiction suggests either the strategic rationale is overstated or the integration plan is premature.

### 2. Retention estimate rests on a single source

The pack estimates "~85% retention expected based on conversations with their VP Eng." The CTO (Sarah Lin) — described as a "strong technical leader" — is not mentioned. For a tech acquisition, losing the CTO is a deal-breaker risk. An 85% estimate from one person is not diligence; it's a hope.

### 3. Comparable transactions lack critical context

The pack justifies the 7.4x ARR valuation by citing three comps (Hexa Insights at ~9x, Aspen Data at ~12x, Trellis Analytics at ~7x). But no deal structure is disclosed: were these earn-out-heavy? Did buyers pay strategic premiums? What were the targets' growth rates at time of sale? Without this context, the comps are suggestive at best.

### 4. Customer concentration and revenue quality are unaddressed

The pack reports ~280 customers and a $32K median ARR but provides no concentration analysis. What percentage of revenue comes from the top 5 or top 10 customers? Additionally, the $2.2M gap between recognized revenue ($9.2M) and ARR ($11.4M) is unexplained. The contract mix and revenue recognition practices are unknown.

### 5. Burn rate acceleration is unexplained

The pack notes "22 months runway at last cap raise" but only $4.1M cash on hand against a $750K monthly burn (~5.5 months of runway). Burn has accelerated roughly 4x since the last raise. The pack does not explain why.

### 6. No legal or security diligence is reported

The pack is signed off by VP Corp Dev, VP Eng, and CFO. There is no mention of legal review, data privacy assessment, SOC 2 status, or change-of-control provisions in customer contracts. For a customer-data-analytics company, this is a significant omission.

---

## Diligence Asks (Next 2 Weeks)

See [`asks.md`](asks.md) for the full list. Highest-priority items:

1. **Reconcile the integration plan** with the strategic rationale. (Owner: VP Eng + Corp Dev; Deadline: 2026-04-22)
2. **Expand retention conversations** to include the CTO and at least 3 key engineers. (Owner: Corp Dev + VP Eng; Deadline: 2026-04-25)
3. **Obtain full deal structure details** for all three comparable transactions. (Owner: Corp Dev; Deadline: 2026-04-22)
4. **Complete legal review** of material contracts, flagging change-of-control provisions. (Owner: Legal; Deadline: 2026-04-28)
5. **Explain the burn rate acceleration** and obtain the debt schedule. (Owner: Corp Dev + Finance; Deadline: 2026-04-22)
6. **Provide customer concentration analysis** and explain the revenue/ARR gap. (Owner: Corp Dev + Finance; Deadline: 2026-04-22)

---

## Bottom Line

The Borealis deal has genuine strategic merit — complementary product, strong growth, clean codebase. But the pack reads as advocacy, not analysis. The integration plan's internal contradiction, the single-source retention estimate, the uncontextualized comps, and the absence of legal diligence are not minor gaps. They are the kind of gaps that, in hindsight, explain why acquisitions fail.

Hold the LOI. Run the diligence. Then decide.
