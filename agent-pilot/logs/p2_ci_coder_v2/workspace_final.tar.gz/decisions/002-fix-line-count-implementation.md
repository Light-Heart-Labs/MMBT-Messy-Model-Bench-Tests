# Decision 002: Fix line_count() to return total quantity

## Context

The CHANGELOG for v0.3.0 states: "Cart.line_count() now returns the number of lines, not the total quantity across lines."

However, the test `test_line_count_matches_qty_sum` clearly expects the total quantity:
- Adds 2 items + 3 items = 5 total items
- Asserts `line_count() == 5`

## Decision

We will fix `line_count()` to return the sum of quantities:

```python
def line_count(self) -> int:
    return sum(line.qty for line in self.lines)
```

## Rationale

1. **Test expectations should be trusted**: The test name "line_count_matches_qty_sum" explicitly states the expected behavior
2. **CHANGELOG v0.3.0 appears incorrect**: The v0.2.0 CHANGELOG says "Cart.line_count() returns total quantity", which matches the test
3. **Breaking change without justification**: Changing the meaning of `line_count()` from total quantity to number of lines is a significant semantic change that would break existing code
4. **The test was not modified**: The test suite was not changed in v0.3.0, suggesting the implementation change was a mistake

## Status

Implemented and verified.
