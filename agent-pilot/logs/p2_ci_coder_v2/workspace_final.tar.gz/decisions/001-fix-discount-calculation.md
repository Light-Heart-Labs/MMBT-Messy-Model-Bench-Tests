# Decision 001: Fix discount calculation to divide by 100

## Context

The `discount_amount()` function in v0.3.0 was updated to accept percent (0-100) instead of fraction (0.0-1.0) as stated in the CHANGELOG. However, the implementation was not updated to divide by 100.

Example failure:
- `discount_amount(100.0, 20.0)` returned `2000.0` (100 * 20)
- Expected: `20.0` (100 * 20 / 100)

## Decision

We will fix the implementation by dividing by 100 in the calculation:

```python
return round(price * percent_off / 100.0, 2)
```

## Rationale

1. The test expectations are correct: they expect 20% of $100 to be $20
2. The CHANGELOG states the function now takes percent (0-100), which implies division by 100
3. The function documentation examples show `discount_amount(100.0, 20.0) -> 20.0`
4. Fixing the implementation is simpler and safer than changing the tests

## Status

Implemented and verified.
