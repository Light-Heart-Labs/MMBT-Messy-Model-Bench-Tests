# Coverage Targets - April 28, 2024

## Initial Targets

The task requires adding tests for under-covered code. The initial coverage targets were:

1. **experimental.py** - 0% coverage
2. **utils.py** - 0% coverage
3. **io.py** - 0% coverage
4. **output.py** - 0% coverage
5. **filters.py** - 74% coverage (some edge cases)
6. **parser.py** - 86% coverage (some edge cases)

## Results

| Module | Target | Actual | Status |
|--------|--------|--------|--------|
| experimental.py | 100% | 100% | ✓ |
| utils.py | 100% | 100% | ✓ |
| io.py | 100% | 100% | ✓ |
| output.py | 100% | 100% | ✓ |
| filters.py | 97% | 97% | ✓ |
| parser.py | 88% | 88% | ✓ |

## Uncovered Modules

### cli.py (0%)

This module is hard to test without integration tests because it:
1. Uses argparse for command-line parsing
2. Prints to stdout
3. Reads from files

Testing it would require:
1. Mocking sys.argv
2. Capturing stdout with pytest's capfd fixture
3. Creating temporary files for testing

This is beyond the scope of unit tests for individual modules.

## Conclusion

All target modules have been tested. The only uncovered module is cli.py, which would require integration tests.
