# Dead Ends - April 28, 2024

## Dead End 1: Testing cli.py with pytest

### Problem

The cli.py module uses argparse and prints to stdout. Testing it would require:
1. Mocking sys.argv
2. Capturing stdout with pytest's capfd fixture
3. Testing various command-line arguments

### Attempted Solution

I attempted to write tests for cli.py using pytest's capfd fixture, but this would require integration tests that:
1. Mock sys.argv
2. Capture stdout
3. Test various command-line arguments

### Why It Didn't Work

This approach would require significant refactoring of the tests to mock sys.argv and capture stdout. The task requires adding unit tests for individual modules, not integration tests.

### Alternative

The task explicitly states that cli.py has 0% coverage and is "not yet wired into the CLI". This suggests it's not a priority for testing.

### Status

Not implemented. cli.py would require integration tests.

## Dead End 2: Testing url_regex_filter with substring matching

### Problem

The `url_regex_filter` function uses `rx.match(entry.url)` which only matches from the beginning of the string. The test expects substring matching.

### Attempted Solution

I attempted to write tests that expect substring matching, but the current implementation uses `match()` which only matches from the beginning.

### Why It Didn't Work

The current implementation is buggy - it uses `match()` instead of `search()`. The task says not to fix bugs, only to document them.

### Alternative

I documented the bug in tests and decisions/002-bugs-documentation.md. The tests show that the current implementation doesn't do substring matching.

### Status

Documented as a bug. Tests show the current behavior (no substring matching).

## Dead End 3: Testing status_filter with string status

### Problem

The `status_filter` function compares `entry.status == status` directly, but:
- `entry.status` is an int (e.g., 404)
- CLI passes `--status` as a string (e.g., "404")

### Attempted Solution

I attempted to write tests that expect string status to work, but the current implementation doesn't handle this.

### Why It Didn't Work

The current implementation is buggy - it doesn't convert string status to int. The task says not to fix bugs, only to document them.

### Alternative

I documented the bug in tests and decisions/002-bugs-documentation.md. The tests show that the current implementation doesn't handle string status.

### Status

Documented as a bug. Tests show the current behavior (string status doesn't work).

## Dead End 4: Testing parse_line with invalid bytes

### Problem

The `parse_line` function raises ValueError for invalid bytes instead of returning None.

### Attempted Solution

I attempted to write tests that expect None for invalid bytes, but the current implementation raises ValueError.

### Why It Didn't Work

The current implementation is buggy - it doesn't handle invalid bytes gracefully. The task says not to fix bugs, only to document them.

### Alternative

I documented the bug in tests and test_parser_edge_cases.py. The tests catch the ValueError and document it as a bug.

### Status

Documented as a bug. Tests show the current behavior (ValueError raised).

## Dead End 5: Testing parse_line with URLs containing spaces

### Problem

The `parse_line` function parses URLs with spaces incorrectly because the regex pattern for URL is `\S+` which stops at the first space.

### Attempted Solution

I attempted to write tests that expect None for URLs with spaces, but the current implementation parses them incorrectly.

### Why It Didn't Work

The current implementation is buggy - it doesn't handle URLs with spaces. The task says not to fix bugs, only to document them.

### Alternative

I documented the bug in tests and test_parser_edge_cases.py. The tests show the incorrect parsing behavior.

### Status

Documented as a bug. Tests show the current behavior (incorrect parsing).

## Conclusion

All dead ends were documented in tests and decisions/002-bugs-documentation.md. The tests show the current buggy behavior and document the bugs for future reference.
