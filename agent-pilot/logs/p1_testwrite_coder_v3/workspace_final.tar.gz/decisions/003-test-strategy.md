# Decision 003: Test Strategy

**Date:** 2024-04-28

## Context

The task requires adding high-value tests for under-covered code. The tests must:
1. Pass when run against the current codebase
2. Actually exercise the code under test
3. Not change behavior
4. Avoid trivial tests

## Decision

We will add tests that:
1. Test edge cases (empty inputs, boundary conditions, invalid inputs)
2. Test error paths (exceptions, None returns)
3. Test integration between modules
4. Document bugs in the starter code

## Test Files Added

1. **test_experimental.py** - Tests for experimental features (detect_anomalies, session_window)
   - Tests for empty inputs
   - Tests for single entries
   - Tests for multiple anomalies
   - Tests for edge cases (negative window_seconds, zero window_seconds)

2. **test_utils.py** - Tests for utility functions (parse_iso_date, format_bytes, format_legacy, chunked)
   - Tests for date parsing (leap years, various months)
   - Tests for byte formatting (B, KB, MB, GB, TB, PB)
   - Tests for legacy formatting
   - Tests for chunking (empty, single chunk, partial last chunk)

3. **test_output.py** - Tests for output formatters (to_json, to_csv, to_text, render_aggregate)
   - Tests for empty entries
   - Tests for single and multiple entries
   - Tests for special characters and Unicode
   - Tests for aggregate rendering

4. **test_io.py** - Tests for file loading (load, load_iter)
   - Tests for empty files
   - Tests for single and multiple entries
   - Tests for mixed valid/invalid lines
   - Tests for no trailing newline
   - Tests for generator behavior

5. **test_aggregate_edge_cases.py** - Additional edge case tests for aggregations
   - Tests for empty entries
   - Tests for many status codes
   - Tests for URLs with query strings and fragments
   - Tests for all 24 hours
   - Tests for large bytes values

6. **test_filters_edge_cases.py** - Additional edge case tests for filters
   - Tests for string vs int status
   - Tests for regex patterns at start
   - Tests for empty allowlists
   - Tests for date range with since/until/both/none
   - Tests for expression filters
   - Tests for combine_and with short-circuit

7. **test_parser_edge_cases.py** - Additional edge case tests for parsing
   - Tests for empty strings and whitespace
   - Tests for invalid bytes
   - Tests for URLs with spaces
   - Tests for all 12 months
   - Tests for various timezone offsets
   - Tests for leap years

## Rationale

- **Edge cases**: Testing edge cases is more valuable than testing happy paths because edge cases often reveal bugs.
- **Error paths**: Testing error paths ensures the code handles invalid inputs gracefully.
- **Integration**: Testing integration between modules ensures the code works as a whole.
- **Documentation**: Documenting bugs in tests ensures the bugs are known and can be fixed later.

## Alternative Considered

We considered adding fewer, more comprehensive tests, but this would not provide as much coverage of edge cases.

## Status

Implemented.
