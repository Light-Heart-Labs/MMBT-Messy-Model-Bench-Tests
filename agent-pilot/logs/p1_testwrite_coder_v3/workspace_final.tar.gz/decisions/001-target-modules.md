# Decision 001: Target Modules for Testing

**Date:** 2024-04-28

## Context

The starter codebase has several modules with low or zero test coverage:
- `cli.py`: 0% coverage
- `experimental.py`: 0% coverage
- `io.py`: 0% coverage
- `output.py`: 0% coverage
- `utils.py`: 0% coverage
- `filters.py`: 74% coverage (some edge cases uncovered)
- `parser.py`: 86% coverage (some edge cases uncovered)

## Decision

We will add tests for the following modules in order of priority:

1. **experimental.py** - High value, 0% coverage, contains useful anomaly detection and session window functions
2. **utils.py** - High value, 0% coverage, contains utility functions used throughout the codebase
3. **output.py** - High value, 0% coverage, contains output formatters
4. **io.py** - High value, 0% coverage, contains file loading functions
5. **filters.py** - Medium value, 74% coverage, add edge case tests
6. **parser.py** - Medium value, 86% coverage, add edge case tests
7. **aggregate.py** - Already has tests, minimal additions needed

## Rationale

- **experimental.py**: This module contains `detect_anomalies` and `session_window` functions that are not tested at all. Testing them will exercise the code paths and may reveal bugs (which we will document but not fix).
- **utils.py**: Contains utility functions like `parse_iso_date`, `format_bytes`, `format_legacy`, and `chunked` that are used throughout the codebase. Testing them ensures the utilities work correctly.
- **output.py**: Contains output formatters (`to_json`, `to_csv`, `to_text`, `render_aggregate`) that are used to display results. Testing them ensures the output is correct.
- **io.py**: Contains file loading functions (`load`, `load_iter`) that are used to read log files. Testing them ensures the file I/O works correctly.
- **filters.py**: Already has some tests, but edge cases like empty allowlists, empty patterns, and various status codes are not tested.
- **parser.py**: Already has some tests, but edge cases like empty strings, whitespace-only strings, and various timestamp formats are not tested.

## Uncovered Modules

- **cli.py**: This module is hard to test without integration tests because it uses argparse and prints to stdout. We will not add tests for this module as it would require significant refactoring.

## Alternative Considered

We considered testing `cli.py` using pytest's `capfd` fixture to capture stdout, but this would require integration tests that are beyond the scope of unit tests for individual modules.

## Status

Implemented.
