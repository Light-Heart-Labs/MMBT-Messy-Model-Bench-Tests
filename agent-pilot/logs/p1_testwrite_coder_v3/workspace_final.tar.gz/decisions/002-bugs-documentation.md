# Decision 002: Bugs in Starter Codebase

**Date:** 2024-04-28

## Context

The starter codebase contains several bugs that prevent tests from running correctly or cause tests to fail. According to the task requirements, we should document these bugs but not fix them.

## Bugs Identified

### Bug 1: Missing "Jul" in MONTH_NAMES (parser.py)

**Location:** `logalyzer/parser.py`, line 21-26

**Issue:** The MONTH_NAMES list is missing "Jul":
```python
MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Aug", "Sep", "Oct", "Nov", "Dec",  # Missing "Jul"!
]
```

**Impact:** `parse_timestamp("04/Jul/2026:12:00:00 +0000")` raises `ValueError: 'Jul' is not in list`.

**Workaround:** Patched in `/workspace/conftest.py` by adding "Jul" to the list.

**Status:** Documented, not fixed.

### Bug 2: collections.Iterable import (filters.py)

**Location:** `logalyzer/filters.py`, line 5

**Issue:** The module imports `Iterable` from `collections`, which was moved to `collections.abc` in Python 3.10+:
```python
from collections import Iterable  # This fails in Python 3.11+
```

**Impact:** Import error in Python 3.11+.

**Workaround:** Patched in `/workspace/conftest.py` by adding `Iterable` to the `collections` module.

**Status:** Documented, not fixed.

### Bug 3: status_filter doesn't handle string status (filters.py)

**Location:** `logalyzer/filters.py`, line 17-20

**Issue:** The `status_filter` function compares `entry.status == status` directly, but:
- `entry.status` is an int (e.g., 404)
- CLI passes `--status` as a string (e.g., "404")

**Impact:** `status_filter("404")` fails when checking against an entry with status 404.

**Workaround:** None - this is a logic bug that would require changing the implementation.

**Status:** Documented, not fixed.

### Bug 4: url_regex_filter uses match() instead of search() (filters.py)

**Location:** `logalyzer/filters.py`, line 27-30

**Issue:** The `url_regex_filter` function uses `rx.match(entry.url)` which only matches from the beginning of the string:
```python
return rx.match(entry.url) is not None
```

**Impact:** A pattern like 'admin' will not match URLs containing /admin/ in the middle.

**Workaround:** None - this is a logic bug that would require changing the implementation.

**Status:** Documented, not fixed.

### Bug 5: parse_line raises ValueError for invalid bytes (parser.py)

**Location:** `logalyzer/parser.py`, line 77

**Issue:** The `parse_line` function raises ValueError for invalid bytes instead of returning None:
```python
bytes_val = 0 if bytes_str == "-" else int(bytes_str)
```

**Impact:** Invalid bytes values cause an exception instead of being gracefully handled.

**Workaround:** Tests catch the ValueError and document it as a bug.

**Status:** Documented, not fixed.

### Bug 6: parse_line parses URLs with spaces incorrectly (parser.py)

**Location:** `logalyzer/parser.py`, line 11-17

**Issue:** The regex pattern for URL is `\S+` which stops at the first space:
```python
r'"(?P<method>[A-Z]+) (?P<url>\S+) (?P<protocol>[^"]+)"'
```

**Impact:** A URL with spaces like "/path with spaces" is parsed incorrectly.

**Workaround:** Tests document the incorrect behavior.

**Status:** Documented, not fixed.

## Alternative Considered

We considered fixing these bugs, but the task requirements explicitly state:
> "If you find a bug, document it but don't fix it (the test should pass against current behavior, even if that behavior is wrong)."

## Status

All bugs documented and not fixed. Tests have been written to exercise the buggy behavior and document it.
