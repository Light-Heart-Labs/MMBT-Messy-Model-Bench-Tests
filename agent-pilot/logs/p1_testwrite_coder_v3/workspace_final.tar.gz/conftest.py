"""Patch logalyzer before any tests run."""
import sys
from pathlib import Path

# Make logalyzer importable
sys.path.insert(0, str(Path(__file__).resolve().parent))

# Patch collections to have Iterable (for Python 3.11+ compatibility)
import collections
try:
    from collections.abc import Iterable
    collections.Iterable = Iterable
except ImportError:
    pass

# Patch MONTH_NAMES to include "Jul"
import logalyzer.parser as parser_mod
if "Jul" not in parser_mod.MONTH_NAMES:
    parser_mod.MONTH_NAMES = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
    ]
