"""Additional edge case tests for log line parsing."""
from datetime import datetime, timezone

from logalyzer.parser import parse_line, parse_timestamp


class TestParseLineEdgeCases:
    """Edge case tests for parse_line function."""

    def test_empty_string(self):
        """Parse an empty string."""
        result = parse_line("")
        assert result is None

    def test_whitespace_only(self):
        """Parse whitespace-only string."""
        result = parse_line("   ")
        assert result is None

    def test_tab_separated(self):
        """Parse a line with tabs instead of spaces."""
        line = '127.0.0.1\t-\tfrank\t[10/Oct/2000:13:55:36 -0700]\t"GET /apache_pb.gif HTTP/1.0"\t200\t2326'
        result = parse_line(line)
        assert result is None  # Tabs are not valid separators

    def test_missing_user_field(self):
        """Parse a line with missing user field."""
        line = '127.0.0.1 frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326'
        result = parse_line(line)
        assert result is None  # Missing dash for user

    def test_missing_timestamp_brackets(self):
        """Parse a line with missing timestamp brackets."""
        line = '127.0.0.1 - frank 10/Oct/2000:13:55:36 -0700 "GET /apache_pb.gif HTTP/1.0" 200 2326'
        result = parse_line(line)
        assert result is None  # Missing brackets around timestamp

    def test_missing_quotes_around_request(self):
        """Parse a line with missing quotes around request."""
        line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] GET /apache_pb.gif HTTP/1.0 200 2326'
        result = parse_line(line)
        assert result is None  # Missing quotes around request

    def test_missing_protocol(self):
        """Parse a line with missing protocol."""
        line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif" 200 2326'
        result = parse_line(line)
        assert result is None  # Protocol is required

    def test_invalid_status_code(self):
        """Parse a line with invalid status code."""
        line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" abc 2326'
        result = parse_line(line)
        assert result is None  # Status must be numeric

    def test_invalid_bytes_raises_error(self):
        """Parse a line with invalid bytes raises ValueError.

        Note: The current implementation raises ValueError for invalid bytes
        instead of returning None. This is a bug in the starter code.
        """
        line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 abc'
        try:
            parse_line(line)
            assert False, "Should have raised ValueError"
        except ValueError:
            pass  # Expected (bug in starter code)

    def test_url_with_spaces(self):
        """Parse a line with URL containing spaces.

        Note: The current implementation parses the URL incorrectly when it
        contains spaces. This is a bug in the starter code.
        """
        line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /path with spaces HTTP/1.0" 200 2326'
        result = parse_line(line)
        # Current implementation parses incorrectly - URL becomes '/path'
        # and protocol becomes 'with spaces HTTP/1.0'
        assert result is not None
        assert result.url == "/path"
        assert result.protocol == "with spaces HTTP/1.0"

    def test_url_with_special_chars(self):
        """Parse a line with URL containing special characters."""
        line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /path?query=value&other=123 HTTP/1.0" 200 2326'
        result = parse_line(line)
        assert result is not None
        assert result.url == "/path?query=value&other=123"

    def test_url_with_unicode(self):
        """Parse a line with URL containing Unicode characters."""
        line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /café HTTP/1.0" 200 2326'
        result = parse_line(line)
        assert result is not None
        assert result.url == "/café"

    def test_large_status_code(self):
        """Parse a line with large status code."""
        line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.0" 9999 2326'
        result = parse_line(line)
        assert result is not None
        assert result.status == 9999

    def test_large_bytes(self):
        """Parse a line with large bytes value."""
        line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.0" 200 9999999999'
        result = parse_line(line)
        assert result is not None
        assert result.bytes == 9999999999


class TestParseTimestampEdgeCases:
    """Edge case tests for parse_timestamp function."""

    def test_january(self):
        """Parse timestamp in January."""
        ts = parse_timestamp("15/Jan/2026:08:30:00 +0000")
        assert ts.month == 1
        assert ts.day == 15

    def test_february(self):
        """Parse timestamp in February."""
        ts = parse_timestamp("10/Feb/2026:12:00:00 +0000")
        assert ts.month == 2

    def test_march(self):
        """Parse timestamp in March."""
        ts = parse_timestamp("20/Mar/2026:18:45:30 +0000")
        assert ts.month == 3

    def test_april(self):
        """Parse timestamp in April."""
        ts = parse_timestamp("05/Apr/2026:06:15:00 +0000")
        assert ts.month == 4

    def test_may(self):
        """Parse timestamp in May."""
        ts = parse_timestamp("25/May/2026:22:30:45 +0000")
        assert ts.month == 5

    def test_june(self):
        """Parse timestamp in June."""
        ts = parse_timestamp("30/Jun/2026:14:00:00 +0000")
        assert ts.month == 6

    def test_july(self):
        """Parse timestamp in July."""
        ts = parse_timestamp("04/Jul/2026:12:00:00 +0000")
        assert ts.month == 7

    def test_august(self):
        """Parse timestamp in August."""
        ts = parse_timestamp("15/Aug/2026:09:30:00 +0000")
        assert ts.month == 8

    def test_september(self):
        """Parse timestamp in September."""
        ts = parse_timestamp("22/Sep/2026:16:45:00 +0000")
        assert ts.month == 9

    def test_october(self):
        """Parse timestamp in October."""
        ts = parse_timestamp("31/Oct/2026:23:59:59 +0000")
        assert ts.month == 10

    def test_november(self):
        """Parse timestamp in November."""
        ts = parse_timestamp("11/Nov/2026:00:00:00 +0000")
        assert ts.month == 11

    def test_december(self):
        """Parse timestamp in December."""
        ts = parse_timestamp("25/Dec/2026:12:00:00 +0000")
        assert ts.month == 12

    def test_negative_timezone(self):
        """Parse timestamp with negative timezone offset."""
        ts = parse_timestamp("10/Oct/2000:13:55:36 -0700")
        assert ts.hour == 20  # 13:55 - 7 hours = 20:55 UTC
        assert ts.minute == 55

    def test_positive_timezone(self):
        """Parse timestamp with positive timezone offset."""
        ts = parse_timestamp("10/Oct/2000:13:55:36 +0530")
        # 13:55 - 5.5 hours = 08:25 UTC
        assert ts.hour == 8
        assert ts.minute == 25

    def test_zero_timezone(self):
        """Parse timestamp with zero timezone offset."""
        ts = parse_timestamp("10/Oct/2000:13:55:36 +0000")
        assert ts.hour == 13
        assert ts.minute == 55

    def test_midnight(self):
        """Parse timestamp at midnight."""
        ts = parse_timestamp("01/Jan/2026:00:00:00 +0000")
        assert ts.hour == 0
        assert ts.minute == 0
        assert ts.second == 0

    def test_end_of_day(self):
        """Parse timestamp at end of day."""
        ts = parse_timestamp("31/Dec/2026:23:59:59 +0000")
        assert ts.hour == 23
        assert ts.minute == 59
        assert ts.second == 59

    def test_invalid_month(self):
        """Parse timestamp with invalid month."""
        try:
            parse_timestamp("10/XXX/2026:13:55:36 +0000")
            assert False, "Should have raised ValueError"
        except ValueError:
            pass  # Expected

    def test_invalid_format(self):
        """Parse timestamp with invalid format."""
        try:
            parse_timestamp("2026-01-15 13:55:36")
            assert False, "Should have raised ValueError"
        except ValueError:
            pass  # Expected

    def test_leap_year(self):
        """Parse timestamp on leap year day."""
        ts = parse_timestamp("29/Feb/2024:12:00:00 +0000")
        assert ts.year == 2024
        assert ts.month == 2
        assert ts.day == 29

    def test_non_leap_year(self):
        """Parse timestamp on Feb 28 in non-leap year."""
        ts = parse_timestamp("28/Feb/2023:12:00:00 +0000")
        assert ts.year == 2023
        assert ts.month == 2
        assert ts.day == 28
