"""Tests for output formatters."""
from datetime import datetime, timezone

from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.parser import LogEntry


class TestToJson:
    """Tests for to_json function."""

    def test_empty_entries(self):
        """Render empty entries as empty JSON array."""
        result = to_json([])
        assert result == "[]"

    def test_single_entry(self):
        """Render a single entry as JSON."""
        entry = LogEntry(
            ip="127.0.0.1",
            user="frank",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="GET",
            url="/index.html",
            protocol="HTTP/1.1",
            status=200,
            bytes=1024,
        )
        result = to_json([entry])
        assert '"ip":"127.0.0.1"' in result
        assert '"user":"frank"' in result
        assert '"method":"GET"' in result
        assert '"url":"/index.html"' in result
        assert '"status":200' in result
        assert '"bytes":1024' in result

    def test_multiple_entries(self):
        """Render multiple entries as JSON array."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
            LogEntry(
                ip="10.0.0.1",
                user="user",
                timestamp=datetime(2026, 1, 1, 13, 0, 0, tzinfo=timezone.utc),
                method="POST",
                url="/api/data",
                protocol="HTTP/1.1",
                status=201,
                bytes=50,
            ),
        ]
        result = to_json(entries)
        assert result.startswith("[")
        assert result.endswith("]")
        assert '"ip":"127.0.0.1"' in result
        assert '"ip":"10.0.0.1"' in result

    def test_special_chars_in_url(self):
        """Render entry with special characters in URL."""
        entry = LogEntry(
            ip="127.0.0.1",
            user="-",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="GET",
            url="/path?query=value&other=123",
            protocol="HTTP/1.1",
            status=200,
            bytes=100,
        )
        result = to_json([entry])
        assert '"url":"/path?query=value&other=123"' in result

    def test_unicode_in_url(self):
        """Render entry with Unicode characters in URL."""
        entry = LogEntry(
            ip="127.0.0.1",
            user="-",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="GET",
            url="/café",
            protocol="HTTP/1.1",
            status=200,
            bytes=100,
        )
        result = to_json([entry])
        assert '"url":"/café"' in result

    def test_timestamp_format(self):
        """Render timestamp in ISO format."""
        entry = LogEntry(
            ip="127.0.0.1",
            user="-",
            timestamp=datetime(2026, 1, 1, 12, 30, 45, tzinfo=timezone.utc),
            method="GET",
            url="/",
            protocol="HTTP/1.1",
            status=200,
            bytes=100,
        )
        result = to_json([entry])
        assert '"timestamp":"2026-01-01T12:30:45+00:00"' in result


class TestToCsv:
    """Tests for to_csv function."""

    def test_empty_entries(self):
        """Render empty entries as CSV with header only."""
        result = to_csv([])
        lines = result.strip().split("\n")
        assert len(lines) == 1
        assert "ip,user,timestamp,method,url,protocol,status,bytes" in lines[0]

    def test_single_entry(self):
        """Render a single entry as CSV."""
        entry = LogEntry(
            ip="127.0.0.1",
            user="frank",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="GET",
            url="/index.html",
            protocol="HTTP/1.1",
            status=200,
            bytes=1024,
        )
        result = to_csv([entry])
        lines = result.strip().split("\n")
        assert len(lines) == 2
        assert "127.0.0.1" in lines[1]
        assert "frank" in lines[1]
        assert "GET" in lines[1]
        assert "/index.html" in lines[1]
        assert "200" in lines[1]
        assert "1024" in lines[1]

    def test_multiple_entries(self):
        """Render multiple entries as CSV."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
            LogEntry(
                ip="10.0.0.1",
                user="user",
                timestamp=datetime(2026, 1, 1, 13, 0, 0, tzinfo=timezone.utc),
                method="POST",
                url="/api/data",
                protocol="HTTP/1.1",
                status=201,
                bytes=50,
            ),
        ]
        result = to_csv(entries)
        lines = result.strip().split("\n")
        assert len(lines) == 3  # Header + 2 entries
        assert "127.0.0.1" in lines[1]
        assert "10.0.0.1" in lines[2]


class TestToText:
    """Tests for to_text function."""

    def test_empty_entries(self):
        """Render empty entries as empty string."""
        result = to_text([])
        assert result == ""

    def test_single_entry(self):
        """Render a single entry as text."""
        entry = LogEntry(
            ip="127.0.0.1",
            user="frank",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="GET",
            url="/index.html",
            protocol="HTTP/1.1",
            status=200,
            bytes=1024,
        )
        result = to_text([entry])
        assert "2026-01-01T12:00:00+00:00" in result
        assert "127.0.0.1" in result
        assert "GET" in result
        assert "200" in result
        assert "/index.html" in result

    def test_multiple_entries(self):
        """Render multiple entries as text."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
            LogEntry(
                ip="10.0.0.1",
                user="user",
                timestamp=datetime(2026, 1, 1, 13, 0, 0, tzinfo=timezone.utc),
                method="POST",
                url="/api/data",
                protocol="HTTP/1.1",
                status=201,
                bytes=50,
            ),
        ]
        result = to_text(entries)
        lines = result.split("\n")
        assert len(lines) == 2
        assert "127.0.0.1" in lines[0]
        assert "10.0.0.1" in lines[1]


class TestRenderAggregate:
    """Tests for render_aggregate function."""

    def test_counter_text(self):
        """Render a Counter as text."""
        from collections import Counter
        agg = Counter({200: 10, 404: 5, 500: 1})
        result = render_aggregate(agg, fmt="text")
        assert "200" in result
        assert "10" in result
        assert "404" in result
        assert "5" in result

    def test_counter_json(self):
        """Render a Counter as JSON."""
        from collections import Counter
        agg = Counter({200: 10, 404: 5})
        result = render_aggregate(agg, fmt="json")
        assert '"200":10' in result
        assert '"404":5' in result

    def test_dict_text(self):
        """Render a dict as text."""
        agg = {"a": 1, "b": 2}
        result = render_aggregate(agg, fmt="text")
        assert "a" in result
        assert "1" in result
        assert "b" in result
        assert "2" in result

    def test_dict_json(self):
        """Render a dict as JSON."""
        agg = {"a": 1, "b": 2}
        result = render_aggregate(agg, fmt="json")
        assert '"a":1' in result
        assert '"b":2' in result

    def test_list_text(self):
        """Render a list as text."""
        agg = [("a", 1), ("b", 2)]
        result = render_aggregate(agg, fmt="text")
        assert "a" in result
        assert "1" in result
        assert "b" in result
        assert "2" in result

    def test_list_json(self):
        """Render a list as JSON."""
        agg = [("a", 1), ("b", 2)]
        result = render_aggregate(agg, fmt="json")
        assert '"a":1' in result
        assert '"b":2' in result

    def test_unknown_format_raises_error(self):
        """Unknown format raises ValueError."""
        agg = {"a": 1}
        try:
            render_aggregate(agg, fmt="unknown")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "unknown format" in str(e)
