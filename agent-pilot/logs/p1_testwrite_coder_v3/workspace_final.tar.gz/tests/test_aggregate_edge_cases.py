"""Additional edge case tests for aggregations."""
from datetime import datetime, timezone

from logalyzer.aggregate import by_status, by_url, by_hour, total_bytes
from logalyzer.parser import LogEntry


class TestByStatusEdgeCases:
    """Edge case tests for by_status function."""

    def test_empty_entries(self):
        """Count status with no entries."""
        result = by_status([])
        assert result == {}

    def test_single_status(self):
        """Count status with all same status codes."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
            LogEntry(
                ip="10.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 13, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
        ]
        result = by_status(entries)
        assert result[200] == 2

    def test_many_status_codes(self):
        """Count status with many different status codes."""
        entries = [
            LogEntry(
                ip=f"127.0.0.{i}",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200 + i,
                bytes=100,
            )
            for i in range(10)
        ]
        result = by_status(entries)
        assert len(result) == 10
        for i in range(10):
            assert result[200 + i] == 1


class TestByUrlEdgeCases:
    """Edge case tests for by_url function."""

    def test_empty_entries(self):
        """Count URL with no entries."""
        result = by_url([])
        assert result == []

    def test_single_url(self):
        """Count URL with all same URLs."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/index.html",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
            LogEntry(
                ip="10.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 13, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/index.html",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
        ]
        result = by_url(entries)
        assert result == [("/index.html", 2)]

    def test_top_n_with_fewer_than_n(self):
        """top N with fewer than N unique URLs."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/a",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
            LogEntry(
                ip="10.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 13, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/b",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
        ]
        result = by_url(entries, top=5)
        assert len(result) == 2  # Only 2 unique URLs

    def test_url_with_query_string(self):
        """Count URLs with query strings."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/search?q=test",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
            LogEntry(
                ip="10.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 13, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/search?q=test",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
        ]
        result = by_url(entries)
        assert result == [("/search?q=test", 2)]

    def test_url_with_fragment(self):
        """Count URLs with fragments."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/page#section1",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
            LogEntry(
                ip="10.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 13, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/page#section2",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
        ]
        result = by_url(entries)
        # Fragments are part of the URL
        assert result == [("/page#section1", 1), ("/page#section2", 1)]


class TestByHourEdgeCases:
    """Edge case tests for by_hour function."""

    def test_empty_entries(self):
        """Bucket by hour with no entries."""
        result = by_hour([])
        assert result == {h: 0 for h in range(24)}

    def test_all_hours(self):
        """Bucket entries across all 24 hours."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, h, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            )
            for h in range(24)
        ]
        result = by_hour(entries)
        for h in range(24):
            assert result[h] == 1

    def test_midnight_hour(self):
        """Bucket entries at midnight (hour 0)."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
        ]
        result = by_hour(entries)
        assert result[0] == 1

    def test_last_hour(self):
        """Bucket entries at 23:59 (hour 23)."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 23, 59, 59, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
        ]
        result = by_hour(entries)
        assert result[23] == 1

    def test_utc_conversion(self):
        """Bucket entries correctly converts to UTC."""
        # Entry at 12:00 UTC should be bucketed into hour 12
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
        ]
        result = by_hour(entries)
        assert result[12] == 1


class TestTotalBytesEdgeCases:
    """Edge case tests for total_bytes function."""

    def test_empty_entries(self):
        """Sum bytes with no entries."""
        result = total_bytes([])
        assert result == 0

    def test_single_entry(self):
        """Sum bytes with a single entry."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=100,
            ),
        ]
        result = total_bytes(entries)
        assert result == 100

    def test_zero_bytes(self):
        """Sum bytes with zero bytes entries."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=304,
                bytes=0,
            ),
        ]
        result = total_bytes(entries)
        assert result == 0

    def test_large_bytes(self):
        """Sum bytes with large values."""
        entries = [
            LogEntry(
                ip="127.0.0.1",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=1024 * 1024 * 1024,  # 1 GB
            ),
        ]
        result = total_bytes(entries)
        assert result == 1024 * 1024 * 1024

    def test_many_entries(self):
        """Sum bytes with many entries."""
        entries = [
            LogEntry(
                ip=f"127.0.0.{i}",
                user="-",
                timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
                method="GET",
                url="/",
                protocol="HTTP/1.1",
                status=200,
                bytes=i * 100,
            )
            for i in range(100)
        ]
        result = total_bytes(entries)
        expected = sum(i * 100 for i in range(100))
        assert result == expected
