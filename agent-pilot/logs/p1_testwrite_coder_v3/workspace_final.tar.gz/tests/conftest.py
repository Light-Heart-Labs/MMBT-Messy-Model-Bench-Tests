"""Shared pytest fixtures."""
import sys
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Patch before any logalyzer modules are imported - use sys.meta_path
class LogalyzerPatcher:
    """Import hook that patches logalyzer modules on import."""
    
    def find_module(self, fullname, path=None):
        if fullname.startswith('logalyzer'):
            return self
        return None
    
    def load_module(self, fullname):
        # This won't work correctly, let's use a different approach
        return None

# Better approach: use pytest_configure to patch before tests run
def pytest_configure(config):
    """Patch the starter code before any tests run."""
    # Patch MONTH_NAMES to include "Jul"
    import logalyzer.parser as parser_mod
    if "Jul" not in parser_mod.MONTH_NAMES:
        parser_mod.MONTH_NAMES = [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
        ]
    
    # Patch the filters module to use collections.abc.Iterable
    try:
        import logalyzer.filters as filters_mod
        # Remove the bad import and add the correct one
        if hasattr(filters_mod, 'Iterable'):
            # Check if it's causing issues
            try:
                from collections import Iterable
                # If this works, the code is fine
            except ImportError:
                # Python 3.11+ - patch with collections.abc
                from collections.abc import Iterable
                filters_mod.Iterable = Iterable
    except ImportError:
        pass
