"""Tests for file loading helpers."""
import tempfile
import os

from logalyzer.io import load, load_iter
from logalyzer.parser import LogEntry


class TestLoad:
    """Tests for load function."""

    def test_empty_file(self):
        """Load from an empty file returns empty list."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write("")
            temp_path = f.name
        try:
            result = load(temp_path)
            assert result == []
        finally:
            os.unlink(temp_path)

    def test_single_entry(self):
        """Load a single valid log entry."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            temp_path = f.name
        try:
            result = load(temp_path)
            assert len(result) == 1
            entry = result[0]
            assert entry.ip == "127.0.0.1"
            assert entry.user == "frank"
            assert entry.method == "GET"
            assert entry.url == "/apache_pb.gif"
            assert entry.status == 200
            assert entry.bytes == 2326
        finally:
            os.unlink(temp_path)

    def test_multiple_entries(self):
        """Load multiple log entries."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.write('10.0.0.1 - - [11/Oct/2000:14:00:00 +0000] "POST /api/data HTTP/1.1" 201 50\n')
            temp_path = f.name
        try:
            result = load(temp_path)
            assert len(result) == 2
            assert result[0].ip == "127.0.0.1"
            assert result[1].ip == "10.0.0.1"
        finally:
            os.unlink(temp_path)

    def test_mixed_valid_invalid_lines(self):
        """Load handles mixed valid and invalid lines."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.write('this is not a valid log line\n')
            f.write('10.0.0.1 - - [11/Oct/2000:14:00:00 +0000] "POST /api/data HTTP/1.1" 201 50\n')
            temp_path = f.name
        try:
            result = load(temp_path)
            assert len(result) == 2  # Only valid lines
            assert result[0].ip == "127.0.0.1"
            assert result[1].ip == "10.0.0.1"
        finally:
            os.unlink(temp_path)

    def test_no_trailing_newline(self):
        """Load handles file without trailing newline."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326')
            temp_path = f.name
        try:
            result = load(temp_path)
            assert len(result) == 1
            assert result[0].ip == "127.0.0.1"
        finally:
            os.unlink(temp_path)

    def test_dash_for_zero_bytes(self):
        """Load handles dash for zero bytes."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write('127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 304 -\n')
            temp_path = f.name
        try:
            result = load(temp_path)
            assert len(result) == 1
            assert result[0].bytes == 0
        finally:
            os.unlink(temp_path)


class TestLoadIter:
    """Tests for load_iter function."""

    def test_empty_file(self):
        """Load iter from an empty file yields nothing."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write("")
            temp_path = f.name
        try:
            result = list(load_iter(temp_path))
            assert result == []
        finally:
            os.unlink(temp_path)

    def test_single_entry(self):
        """Load iter returns a single valid log entry."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            temp_path = f.name
        try:
            result = list(load_iter(temp_path))
            assert len(result) == 1
            entry = result[0]
            assert entry.ip == "127.0.0.1"
        finally:
            os.unlink(temp_path)

    def test_multiple_entries(self):
        """Load iter returns multiple log entries."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.write('10.0.0.1 - - [11/Oct/2000:14:00:00 +0000] "POST /api/data HTTP/1.1" 201 50\n')
            temp_path = f.name
        try:
            result = list(load_iter(temp_path))
            assert len(result) == 2
            assert result[0].ip == "127.0.0.1"
            assert result[1].ip == "10.0.0.1"
        finally:
            os.unlink(temp_path)

    def test_generator_behavior(self):
        """Load iter returns a generator, not a list."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            temp_path = f.name
        try:
            result = load_iter(temp_path)
            # Should be a generator
            assert hasattr(result, '__iter__')
            assert not isinstance(result, list)
            # Can only iterate once
            list1 = list(result)
            list2 = list(result)
            assert len(list1) == 1
            assert len(list2) == 0  # Generator exhausted
        finally:
            os.unlink(temp_path)
