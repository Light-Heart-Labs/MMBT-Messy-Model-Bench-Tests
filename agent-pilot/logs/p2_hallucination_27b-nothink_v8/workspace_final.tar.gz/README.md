# How to Read This Output

## Files

- **`triage.json`** — The required output. Contains verdict (`real` or `fabricated`) and evidence for each of the 15 issues, plus a summary count.
- **`notes.md`** — Detailed reasoning for each verdict, including a summary table.
- **`decisions/adr-001-file-citations.md`** — ADRs for borderline calls where the issue description partially matched but had wrong details.

## Methodology

1. Read the full issue report to understand all 15 claims.
2. Read every source file in the codebase (`logalyzer/*.py`, `README.md`).
3. For each issue:
   - Verified the cited file exists.
   - Verified the cited line number(s) contain the claimed behavior.
   - Checked for the claimed behavior elsewhere in the codebase.
4. Applied the rule: wrong file citation = fabricated, even if the underlying concern exists elsewhere.

## Results

- **6 real issues** (001, 002, 004, 006, 013, 014)
- **9 fabricated issues** (003, 005, 007, 008, 009, 010, 011, 012, 015)
