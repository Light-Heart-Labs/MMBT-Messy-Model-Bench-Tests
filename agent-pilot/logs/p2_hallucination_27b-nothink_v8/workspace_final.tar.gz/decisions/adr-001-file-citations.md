# ADR-001: Issue 009 — `format_legacy()` file location

## Decision: Fabricated

The issue claims `format_legacy()` is in `logalyzer/output.py`. The function actually exists in `logalyzer/utils.py:21`.

While the underlying observation (that `format_legacy()` is unused) is technically correct — no module imports it — the issue as written cites the wrong file. Per the rules:

> "A wrong file citation makes the issue fabricated. If issue 009 claims a function is in `output.py` but the function actually lives in `utils.py`, the issue as written is fabricated."

The function is indeed unused (only `parse_iso_date` is imported from `utils.py`), but the claim about its location in `output.py` is false.

---

# ADR-002: Issue 014 — `ip_allowlist_filter` performance

## Decision: Real

The issue claims `entry.ip in allowlist` is O(n) when `allowlist` is a list. This is confirmed:

- `filters.py:36`: `return entry.ip in allowlist`
- `cli.py:47`: `preds.append(ip_allowlist_filter(args.ip))` where `args.ip` is a list from `action='append'`

The function does not convert the allowlist to a set, so membership testing is O(n) per entry. This is a legitimate performance concern for large allowlists.

---

# ADR-003: Issue 010 — Race condition in `load_iter()`

## Decision: Fabricated

The `load_iter()` function in `io.py:35-40` opens a file and yields parsed entries. Each call creates its own file handle via `with open(path, "r") as f`. There is no shared mutable state between concurrent invocations. The claim of a "race between file-handle creation and iteration" is unfounded — these are sequential operations within a single thread's context manager.
