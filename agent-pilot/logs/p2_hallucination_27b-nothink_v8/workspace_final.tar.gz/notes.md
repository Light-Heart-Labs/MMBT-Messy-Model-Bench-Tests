# Verification Notes

## Summary

Out of 15 issues in the preliminary review report, **6 are real** and **9 are fabricated**.

## Real Issues (6)

| # | Issue | Evidence |
|---|-------|----------|
| 001 | `from collections import Iterable` | `filters.py:5` — removed in Python 3.10+ |
| 002 | `eval()` on user input | `filters.py:59` — `expression_filter()` uses `eval()` |
| 004 | README claims "Real-time tail mode" | `README.md:13` — no `--tail` flag exists |
| 006 | `experimental.py` is dead code | No imports of `experimental` anywhere |
| 013 | O(n²) list/string building in `load()` | `io.py:24,27` — `result + [entry]` and `accumulated + ch` |
| 014 | O(n) membership test in `ip_allowlist_filter` | `filters.py:36` — `entry.ip in allowlist` where allowlist is a list |

## Fabricated Issues (9)

| # | Issue | Why Fabricated |
|---|-------|----------------|
| 003 | SQL injection in parser | No SQL anywhere in `parser.py` or the codebase |
| 005 | `--top` flag broken | `--top` has `type=int` and works correctly |
| 007 | CSRF in web interface | `web.py` does not exist; no web interface |
| 008 | 8192-char truncation | No truncation in `parse_line()` |
| 009 | `format_legacy()` in `output.py` | Function is in `utils.py`, not `output.py` |
| 010 | Race condition in `load_iter()` | Each call has its own file handle; no shared state |
| 011 | Double-counting 3xx in `by_status()` | Simple Counter increment; no special 3xx handling |
| 012 | Cache invalidation | `cache.py` does not exist |
| 015 | `__init__.py` imports `LogEntry` | `__init__.py` only has `__version__` |

## Key Observations

1. **Non-existent files**: The reviewer invented `web.py` (issue 007) and `cache.py` (issue 012). Neither exists.
2. **Wrong file citations**: Issue 009 claims `format_legacy()` is in `output.py` but it's actually in `utils.py`. Per the rules, this makes the issue fabricated.
3. **False behavioral claims**: Issues 003, 005, 008, 010, 011, and 015 describe behaviors that simply don't exist in the code.
4. **The real issues are all verifiable**: Each real issue has a clear, citable line in the actual code.
