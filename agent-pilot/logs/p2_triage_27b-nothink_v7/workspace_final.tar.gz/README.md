# Triage Results — Support Inbox

## Overview

30 tickets triaged from `/input/repo/tickets.txt`. Results are in [`triage_results.json`](./triage_results.json).

### Quick Stats

| Metric | Count |
|---|---|
| Total tickets | 30 |
| Urgent | 6 |
| Normal | 15 |
| Low | 6 |
| N/A (spam) | 4 |
| Duplicate clusters | 2 |

### Category Breakdown

| Category | Count |
|---|---|
| bug-report | 7 |
| billing-refund | 4 |
| feature-request | 3 |
| incident-active | 2 |
| account-management | 2 |
| auth-permissions | 2 |
| general-question | 2 |
| spam-or-noise | 4 |
| external-business | 2 |
| security-incident | 1 |
| legal-compliance | 1 |

## Recommended Processing Order (Urgent First)

1. **TICKET 028** — Security incident: active account compromise, freeze account immediately
2. **TICKET 003** — Production outage: entire org locked out, board meeting in ~1 hour
3. **TICKET 016** — API 500 errors on `/api/v2/exports`, SOC1 review deadline tomorrow
4. **TICKET 014** (cluster: 014, 023, 030) — API rate limits blocking $48k customer's nightly ingestion; 3 follow-ups, escalating frustration
5. **TICKET 019** — GDPR data export request (30-day statutory deadline)

## Duplicate Clusters

### Cluster 1: Dashboard sharing permissions (007, 011)
- **007**: jordan.lee reports can't see shared dashboards (permission denied)
- **011**: alex.petrov (the sharer) reports the same issue from the other side
- Same account (MC-3309), same team, same symptom. 011 is a duplicate of 007.

### Cluster 2: API rate limits (014, 023, 030)
- **014**: ops@major-customer.com reports nightly 429s during data ingestion
- **023**: Same sender, follow-up — issue recurred, backlog growing
- **030**: Same sender, third message — still no response, threatening escalation
- All from ops@major-customer.com about the same rate-limit issue. 023 and 030 are duplicates of 014.

## Ambiguous Calls & Rationale

See `/workspace/decisions/` for detailed ADRs on non-obvious classifications.

### Notable decisions:
- **TICKET 029** (extortion email): Classified as `spam-or-noise`, not `security-incident`. This is a classic extortion attempt — no legitimate disclosure process, BTC demand. Do not engage.
- **TICKET 014**: Classified as `bug-report` (not `billing-other`) because the core ask is a technical fix (higher rate limits), not a billing dispute.
- **TICKET 004** (Pixar collectables): Obvious spam — no such program exists.
- **TICKET 022** (downtime refund): Classified as `billing-refund` with `normal` urgency — the outage has already passed.
