# Extraction Notes

## Summary
Extracted 20 fields from Veridyne Networks, Inc. Q3 FY2026 earnings press release dated March 18, 2026.

## Field-by-Field Notes

- **company_name**: Used "Veridyne Networks, Inc." as it appears in the header and matches the schema's accepted variants.
- **ticker_symbol**: Extracted "VRDN" from "NASDAQ: VRDN".
- **fiscal_period**: Extracted "Q3 2026" as it matches the accepted variants.
- **fiscal_period_end_date**: Extracted "2026-02-28" from "February 28, 2026".
- **total_revenue_usd_millions**: Extracted `187.4` from "Total revenue of $187.4 million".
- **revenue_yoy_growth_pct**: Extracted `38` from "up 38% year-over-year".
- **subscription_revenue_usd_millions**: Extracted `171.2` from "Subscription revenue of $171.2 million".
- **gaap_gross_margin_pct**: Extracted `76.3` from "GAAP gross margin of 76.3%".
- **non_gaap_operating_income_usd_millions**: Extracted `9.8` from "Non-GAAP operating income of $9.8 million". Note: The press release also mentions "non-GAAP operating loss of $4.1 million in Q3 FY2025", but we extract the current quarter's positive income.
- **total_customers**: Extracted `4117` from "Total customers grew to 4,117".
- **customers_above_100k_arr**: Extracted `1082` from "Customers contributing more than $100,000 in annual recurring revenue (ARR) grew to 1,082".
- **customers_above_1m_arr**: Extracted `71` from "Customers contributing more than $1 million in ARR grew to 71".
- **net_dollar_retention_pct**: Extracted `124` from "Net dollar retention rate of 124%".
- **total_arr_usd_millions**: Extracted `710` per ADR-002; the press release says "exceeded $710 million".
- **fte_count_end_of_q3**: Extracted `1847` per ADR-004.
- **stitchwise_acquisition_total_consideration_usd_millions**: Extracted `115` per ADR-001; the press release says "approximately $115 million".
- **stitchwise_close_date**: Extracted "2026-01-22" from "closed its acquisition of Stitchwise Labs, Inc., on January 22, 2026".
- **fy2026_revenue_guidance_low_usd_millions**: Extracted `722` per ADR-003.
- **fy2026_revenue_guidance_high_usd_millions**: Extracted `726` per ADR-003.
- **share_repurchase_authorization_usd_millions**: Extracted `200` from "authorized a share repurchase program of up to $200 million".

## Uncertainty
No fields were genuinely missing or ambiguous beyond the documented tolerances. All values were explicitly stated or accepted per schema notes.

## ADRs
- ADR-001: Stitchwise acquisition total consideration
- ADR-002: Total ARR extraction
- ADR-003: FY2026 revenue guidance extraction
- ADR-004: FTE count extraction
