# ADR: FTE Count Extraction

## Decision
Extract `fte_count_end_of_q3` as `1847`.

## Rationale
The press release states:
> The Company ended the quarter with 1,847 full-time employees, up from 1,612 as of November 30, 2025, an increase of 14.6% sequentially driven primarily by the Stitchwise acquisition and continued investment in product engineering.

The quarter ended February 28, 2026, which is Q3 FY2026. The FTE count at the end of the quarter is explicitly `1,847`.

## Notes
- The schema asks for `fte_count_end_of_q3`, which matches this figure.
- We do not use the sequential increase percentage to back-calculate; we use the stated figure.
