# ADR: Total ARR Extraction

## Decision
Extract `total_arr_usd_millions` as `710`.

## Rationale
The press release states: "Total ARR exceeded $710 million as of quarter-end."

The schema notes: "Press release says 'exceeded $710 million'; accept 710 or any value labeled 'over 710' / '>$710M'."

Per instructions, we extract the stated figure `710` as the lower bound. Since the schema explicitly accepts this phrasing, we use `710`.

## Notes
- The word "exceeded" implies the actual value is >710, but the instruction says to accept `710` as the value.
- We do not guess a higher number (e.g., 711 or 712) because the press release does not provide an exact figure.
