# ADR: FY2026 Revenue Guidance Extraction

## Decision
Extract `fy2026_revenue_guidance_low_usd_millions` as `722` and `fy2026_revenue_guidance_high_usd_millions` as `726`.

## Rationale
The press release states under "Full-Year FY2026 Guidance":
> Total revenue: $722-$726 million (previously $702-$710 million), representing growth of 35-36% year-over-year.

The range is explicitly given as `$722-$726 million`. We extract the low and high values directly.

## Notes
- This is not a forward-looking statement that we should ignore; the schema explicitly lists these guidance fields as expected.
- The "previously" range is historical context and not the current guidance.
