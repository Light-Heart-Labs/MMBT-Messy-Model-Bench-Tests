# ADR-001: Test Targets and Strategy

## Date
2025-01-XX

## Context
The logalyzer codebase has several modules with 0% or low coverage:
- `experimental.py` — 0% coverage (anomaly detection, session windowing)
- `output.py` — 0% coverage (JSON, CSV, text formatters, `render_aggregate`)
- `utils.py` — 0% coverage (date parsing, byte formatting, legacy formatter, chunking)
- `io.py` — 0% coverage (file loading helpers)
- `cli.py` — 0% coverage (CLI entry point)
- `filters.py` — 74% coverage (missing: `expression_filter`, `combine_and`)
- `parser.py` — 86% coverage (missing: `parse_lines`, edge cases)

## Decision
Target modules in order of highest value:
1. `experimental.py` — complex logic (z-score, session windowing) with 0% coverage
2. `output.py` — formatters with 0% coverage, including `format_legacy`
3. `utils.py` — utility functions with edge cases (empty sequences, large numbers, invalid dates)
4. `io.py` — file I/O with edge cases (empty files, malformed lines, no trailing newline)
5. `cli.py` — integration-level tests for the CLI
6. `filters.py` — missing `expression_filter` and `combine_and` tests
7. `parser.py` — edge cases for `parse_lines` generator

## Pre-existing Test Failures (Documented, Not Fixed)
Three starter tests fail against the current codebase:
1. `test_status_filter_works_with_cli_string_input` — `status_filter` does not convert string to int; `"404" != 404`
2. `test_url_regex_finds_substring_match` — `url_regex_filter` uses `re.match` (anchored at start), so pattern `"admin"` doesn't match `"/admin/login"`
3. `test_timestamp_july_parses_correctly` — `MONTH_NAMES` list is missing `"Jul"` (jumps from `"Jun"` to `"Aug"`)

These are bugs in production code. Per project rules, tests must pass against current behavior. These failing tests are pre-existing and will remain as-is.

## Not Testing
- `benchmarks/bench.py` — performance benchmark, not part of the package
- `__init__.py` — only contains `__version__`, trivial
