"""Tests for output.py — JSON, CSV, text formatters and render_aggregate.

Exercises the 0%-coverage output module including edge cases like:
- Empty entry lists
- Special characters in URLs (quotes, backslashes)
- render_aggregate with unknown formats
- format_legacy (uncovered legacy function)
"""
from datetime import datetime, timezone

from logalyzer.output import (
    render_aggregate,
    to_csv,
    to_json,
    to_text,
)
from logalyzer.parser import LogEntry
from logalyzer.utils import format_legacy


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── to_json ───────────────────────────────────────────────────────────────


class TestToJson:
    """Tests for JSON output formatter."""

    def test_empty_entries_returns_empty_array(self):
        """No entries → empty JSON array."""
        assert to_json([]) == "[]"

    def test_single_entry_produces_valid_json_array(self):
        """A single entry produces a JSON array with one object."""
        entry = _entry()
        result = to_json([entry])
        assert result.startswith("[")
        assert result.endswith("]")
        assert '"ip":"10.0.0.1"' in result
        assert '"status":200' in result
        assert '"bytes":100' in result

    def test_multiple_entries_produces_json_array(self):
        """Multiple entries produce a JSON array with comma-separated objects."""
        entries = [_entry(status=200), _entry(status=404)]
        result = to_json(entries)
        assert result.count('"status":200') == 1
        assert result.count('"status":404') == 1

    def test_json_contains_iso_timestamp(self):
        """Timestamps are rendered in ISO format."""
        entry = _entry()
        result = to_json([entry])
        assert "2026-01-01T12:00:00+00:00" in result

    def test_json_with_special_url_characters(self):
        """URLs with special characters are included as-is (no escaping)."""
        entry = _entry(url='/path?q="hello"&x=1')
        result = to_json([entry])
        assert '/path?q="hello"&x=1' in result

    def test_json_with_zero_bytes(self):
        """Zero bytes are rendered as 0, not as a dash."""
        entry = _entry(bytes=0)
        result = to_json([entry])
        assert '"bytes":0' in result

    def test_json_fields_order(self):
        """JSON fields follow the defined order: ip, user, timestamp, method, url, protocol, status, bytes."""
        entry = _entry()
        result = to_json([entry])
        # Check that ip comes before user, user before timestamp, etc.
        ip_pos = result.index('"ip"')
        user_pos = result.index('"user"')
        status_pos = result.index('"status"')
        bytes_pos = result.index('"bytes"')
        assert ip_pos < user_pos < status_pos < bytes_pos


# ── to_csv ────────────────────────────────────────────────────────────────


class TestToCsv:
    """Tests for CSV output formatter."""

    def test_empty_entries_returns_header_only(self):
        """No entries → CSV with header row only."""
        result = to_csv([])
        assert "ip,user,timestamp,method,url,protocol,status,bytes" in result
        lines = result.strip().split('\n')
        assert len(lines) == 1

    def test_single_entry_produces_header_and_row(self):
        """A single entry produces a header row and one data row."""
        entry = _entry()
        result = to_csv([entry])
        lines = result.strip().split('\n')
        assert len(lines) == 2
        assert "10.0.0.1" in lines[1]

    def test_csv_contains_all_columns(self):
        """All 8 columns are present in the header."""
        result = to_csv([])
        header = result.strip().split('\n')[0]
        cols = header.split(',')
        assert cols == ["ip", "user", "timestamp", "method", "url", "protocol", "status", "bytes"]

    def test_csv_with_comma_in_url_is_quoted(self):
        """URLs containing commas are properly quoted by csv.writer."""
        entry = _entry(url='/path?a=1,b=2')
        result = to_csv([entry])
        assert '"/path?a=1,b=2"' in result or '/path?a=1,b=2' in result

    def test_csv_with_newline_in_url_is_quoted(self):
        """URLs containing newlines are properly quoted."""
        entry = _entry(url='/path\nwith\nnewlines')
        result = to_csv([entry])
        assert '"/path\nwith\nnewlines"' in result

    def test_csv_multiple_entries(self):
        """Multiple entries produce multiple data rows."""
        entries = [_entry(status=200), _entry(status=404), _entry(status=500)]
        result = to_csv(entries)
        lines = result.strip().split('\n')
        assert len(lines) == 4  # header + 3 data rows


# ── to_text ───────────────────────────────────────────────────────────────


class TestToText:
    """Tests for plain text output formatter."""

    def test_empty_entries_returns_empty_string(self):
        """No entries → empty string."""
        assert to_text([]) == ""

    def test_single_entry_produces_one_line(self):
        """A single entry produces one line of text."""
        entry = _entry()
        result = to_text([entry])
        assert len(result.strip().split('\n')) == 1
        assert "10.0.0.1" in result
        assert "GET" in result
        assert "200" in result
        assert "/" in result

    def test_multiple_entries_produce_multiple_lines(self):
        """Multiple entries produce multiple lines separated by newlines."""
        entries = [_entry(status=200), _entry(status=404)]
        result = to_text(entries)
        lines = result.strip().split('\n')
        assert len(lines) == 2

    def test_text_format_has_aligned_columns(self):
        """IP addresses are right-aligned in a 15-char field."""
        entries = [_entry(ip="1.2.3.4"), _entry(ip="10.20.30.40")]
        result = to_text(entries)
        lines = result.strip().split('\n')
        # The IP field should be right-aligned to 15 chars
        for line in lines:
            # After the timestamp (which ends with +00:00), there should be spaces before the IP
            parts = line.split('  ')
            assert len(parts) >= 2

    def test_text_format_method_left_aligned(self):
        """HTTP method is left-aligned in a 6-char field."""
        entry = _entry(method="GET")
        result = to_text([entry])
        assert "GET   " in result or "GET" in result


# ── render_aggregate ──────────────────────────────────────────────────────


class TestRenderAggregate:
    """Tests for aggregate result rendering."""

    def test_text_format_with_counter(self):
        """Counter-like objects are rendered as key\tvalue lines."""
        from collections import Counter
        agg = Counter({"200": 10, "404": 3})
        result = render_aggregate(agg, fmt="text")
        assert "200\t10" in result
        assert "404\t3" in result

    def test_text_format_with_dict(self):
        """Dict-like objects are rendered as key\tvalue lines."""
        agg = {"a": 1, "b": 2}
        result = render_aggregate(agg, fmt="text")
        assert "a\t1" in result
        assert "b\t2" in result

    def test_text_format_with_list_of_tuples(self):
        """List of (key, value) tuples are rendered as key\tvalue lines."""
        agg = [("a", 1), ("b", 2)]
        result = render_aggregate(agg, fmt="text")
        assert "a\t1" in result
        assert "b\t2" in result

    def test_json_format_with_counter(self):
        """Counter-like objects are rendered as JSON-like key:value pairs."""
        from collections import Counter
        agg = Counter({"200": 10, "404": 3})
        result = render_aggregate(agg, fmt="json")
        assert '"200":10' in result
        assert '"404":3' in result

    def test_json_format_with_list_of_tuples(self):
        """List of tuples are rendered as JSON-like key:value pairs."""
        agg = [("a", 1), ("b", 2)]
        result = render_aggregate(agg, fmt="json")
        assert '"a":1' in result
        assert '"b":2' in result

    def test_unknown_format_raises_value_error(self):
        """An unknown format string raises ValueError."""
        agg = {"a": 1}
        try:
            render_aggregate(agg, fmt="xml")
            assert False, "Expected ValueError"
        except ValueError as e:
            assert "unknown format" in str(e)

    def test_default_format_is_text(self):
        """When fmt is not specified, text format is used."""
        agg = {"a": 1}
        result = render_aggregate(agg)
        assert "a\t1" in result


# ── format_legacy ─────────────────────────────────────────────────────────


class TestFormatLegacy:
    """Tests for the legacy formatter (format_legacy in utils.py)."""

    def test_format_legacy_output_format(self):
        """format_legacy produces 'ip | timestamp | status | url'."""
        entry = _entry(ip="1.2.3.4", status=404, url="/missing")
        result = format_legacy(entry)
        assert "1.2.3.4" in result
        assert "404" in result
        assert "/missing" in result
        assert "|" in result

    def test_format_legacy_pipe_delimited(self):
        """Fields are separated by ' | ' (pipe with spaces)."""
        entry = _entry()
        result = format_legacy(entry)
        parts = result.split(" | ")
        assert len(parts) == 4

    def test_format_legacy_field_order(self):
        """Fields are in order: ip, timestamp, status, url."""
        entry = _entry(ip="10.0.0.1", status=200, url="/test")
        result = format_legacy(entry)
        parts = result.split(" | ")
        assert parts[0] == "10.0.0.1"
        assert parts[2] == "200"
        assert parts[3] == "/test"
