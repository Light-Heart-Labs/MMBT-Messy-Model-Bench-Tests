"""Tests for utils.py — date parsing, byte formatting, chunking, and legacy formatter.

Exercises the 0%-coverage utils module including edge cases like:
- Invalid date strings
- Very large byte counts
- Empty sequences in chunked()
- chunked with size=1 and size larger than sequence
"""
from datetime import datetime, timezone

import pytest

from logalyzer.utils import chunked, format_bytes, format_legacy, parse_iso_date


# ── parse_iso_date ────────────────────────────────────────────────────────


class TestParseIsoDate:
    """Tests for ISO date string parsing."""

    def test_valid_date_parsed_correctly(self):
        """A valid YYYY-MM-DD string is parsed to a UTC datetime at midnight."""
        result = parse_iso_date("2026-01-15")
        assert result == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)

    def test_date_is_utc(self):
        """Parsed dates are in UTC timezone."""
        result = parse_iso_date("2026-06-30")
        assert result.tzinfo is timezone.utc

    def test_date_is_at_midnight(self):
        """Parsed dates have hour=0, minute=0, second=0."""
        result = parse_iso_date("2026-12-25")
        assert result.hour == 0
        assert result.minute == 0
        assert result.second == 0

    def test_invalid_date_raises_value_error(self):
        """An invalid date string raises ValueError from strptime."""
        with pytest.raises(ValueError):
            parse_iso_date("not-a-date")

    def test_wrong_format_raises_value_error(self):
        """A date in wrong format (e.g., MM/DD/YYYY) raises ValueError."""
        with pytest.raises(ValueError):
            parse_iso_date("01/15/2026")

    def test_leap_year_date(self):
        """A leap year date (Feb 29) is parsed correctly."""
        result = parse_iso_date("2024-02-29")
        assert result.month == 2
        assert result.day == 29

    def test_end_of_year_date(self):
        """December 31 is parsed correctly."""
        result = parse_iso_date("2025-12-31")
        assert result.month == 12
        assert result.day == 31

    def test_single_digit_month_and_day(self):
        """Single-digit months and days work (e.g., 2026-1-1)."""
        result = parse_iso_date("2026-1-1")
        assert result.month == 1
        assert result.day == 1

    def test_empty_string_raises_value_error(self):
        """An empty string raises ValueError."""
        with pytest.raises(ValueError):
            parse_iso_date("")


# ── format_bytes ──────────────────────────────────────────────────────────


class TestFormatBytes:
    """Tests for human-readable byte formatting."""

    def test_zero_bytes(self):
        """Zero bytes is formatted as '0.0 B'."""
        assert format_bytes(0) == "0.0 B"

    def test_small_bytes_in_bytes(self):
        """Values under 1024 are shown in bytes."""
        assert format_bytes(500) == "500.0 B"

    def test_exactly_1024_is_kb(self):
        """1024 bytes is formatted as '1.0 KB'."""
        assert format_bytes(1024) == "1.0 KB"

    def test_kb_range(self):
        """Values in KB range are formatted correctly."""
        assert format_bytes(2048) == "2.0 KB"

    def test_mb_range(self):
        """Values in MB range are formatted correctly."""
        assert format_bytes(1024 * 1024) == "1.0 MB"

    def test_gb_range(self):
        """Values in GB range are formatted correctly."""
        assert format_bytes(1024 ** 3) == "1.0 GB"

    def test_tb_range(self):
        """Values in TB range are formatted correctly."""
        assert format_bytes(1024 ** 4) == "1.0 TB"

    def test_fractional_kb(self):
        """Fractional KB values are shown with one decimal place."""
        result = format_bytes(1536)  # 1.5 KB
        assert result == "1.5 KB"

    def test_fractional_mb(self):
        """Fractional MB values are shown with one decimal place."""
        result = format_bytes(1024 * 1024 * 1.5)  # 1.5 MB
        assert result == "1.5 MB"

    def test_very_large_value(self):
        """Very large values are formatted in TB (the last unit in the loop)."""
        result = format_bytes(1024 ** 4 * 100)  # 100 TB
        assert "TB" in result

    def test_negative_bytes(self):
        """Negative byte counts are formatted (edge case)."""
        result = format_bytes(-500)
        assert "B" in result

    def test_one_byte(self):
        """A single byte is formatted as '1.0 B'."""
        assert format_bytes(1) == "1.0 B"

    def test_just_under_kb(self):
        """1023 bytes is still in B, not KB."""
        assert format_bytes(1023) == "1023.0 B"


# ── chunked ───────────────────────────────────────────────────────────────


class TestChunked:
    """Tests for the chunked() generator."""

    def test_empty_sequence(self):
        """An empty sequence produces no chunks."""
        result = list(chunked([], 3))
        assert result == []

    def test_chunk_size_larger_than_sequence(self):
        """When chunk size > sequence length, the entire sequence is one chunk."""
        result = list(chunked([1, 2, 3], 10))
        assert result == [[1, 2, 3]]

    def test_chunk_size_one(self):
        """Chunk size of 1 produces one-element chunks."""
        result = list(chunked([1, 2, 3], 1))
        assert result == [[1], [2], [3]]

    def test_exact_multiple(self):
        """When sequence length is an exact multiple of chunk size, no remainder."""
        result = list(chunked([1, 2, 3, 4, 5, 6], 3))
        assert result == [[1, 2, 3], [4, 5, 6]]

    def test_remainder_chunk(self):
        """When sequence length is not a multiple of chunk size, a smaller final chunk."""
        result = list(chunked([1, 2, 3, 4, 5], 2))
        assert result == [[1, 2], [3, 4], [5]]

    def test_single_element(self):
        """A single element produces one chunk."""
        result = list(chunked([42], 5))
        assert result == [[42]]

    def test_chunks_are_lists(self):
        """Each chunk is a list, not a generator or tuple."""
        result = list(chunked([1, 2, 3], 2))
        assert all(isinstance(c, list) for c in result)

    def test_generator_behavior(self):
        """chunked is a generator (lazy evaluation)."""
        gen = chunked([1, 2, 3, 4], 2)
        first = next(gen)
        assert first == [1, 2]
        second = next(gen)
        assert second == [3, 4]

    def test_works_with_strings(self):
        """chunked works with string iterables."""
        result = list(chunked("abcdef", 2))
        assert result == [["a", "b"], ["c", "d"], ["e", "f"]]

    def test_works_with_generator_input(self):
        """chunked works with generator input (not just lists)."""
        def gen():
            yield 1
            yield 2
            yield 3
            yield 4
        result = list(chunked(gen(), 2))
        assert result == [[1, 2], [3, 4]]


# ── format_legacy (also tested in test_output.py, but test here for coverage) ──


class TestFormatLegacyUtils:
    """Tests for format_legacy from utils module."""

    def test_format_legacy_with_various_statuses(self):
        """format_legacy works with different status codes."""
        from logalyzer.parser import LogEntry
        entry = LogEntry(
            ip="192.168.1.1",
            user="admin",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="POST",
            url="/api/data",
            protocol="HTTP/1.1",
            status=500,
            bytes=2048,
        )
        result = format_legacy(entry)
        assert "192.168.1.1" in result
        assert "500" in result
        assert "/api/data" in result
