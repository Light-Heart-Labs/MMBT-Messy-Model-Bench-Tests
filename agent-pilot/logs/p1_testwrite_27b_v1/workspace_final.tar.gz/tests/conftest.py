"""Shared pytest fixtures."""
import sys
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Compatibility shim: collections.Iterable was removed in Python 3.10+
# The production code imports it; we patch it here so tests can run.
import collections
from collections.abc import Iterable as _Iterable
if not hasattr(collections, "Iterable"):
    collections.Iterable = _Iterable
