"""Additional tests for parser.py — edge cases and parse_lines generator.

The starter tests cover basic CLF parsing, dash-for-zero-bytes, garbage lines,
and timestamp parsing. These tests cover:
- parse_lines generator
- Edge cases for parse_line (unicode, long URLs, various methods)
- Timestamp edge cases (positive timezone, boundary dates)
"""
from datetime import datetime, timezone

import pytest

from logalyzer.parser import LogEntry, parse_line, parse_lines, parse_timestamp


# ── parse_lines ───────────────────────────────────────────────────────────


class TestParseLines:
    """Tests for parse_lines — generator over an iterable of lines."""

    def test_empty_iterable(self):
        """parse_lines with empty iterable produces no entries."""
        result = list(parse_lines([]))
        assert result == []

    def test_single_valid_line(self):
        """parse_lines with one valid line yields one entry."""
        lines = ['127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.0" 200 2326']
        result = list(parse_lines(lines))
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"

    def test_mixed_valid_and_invalid_lines(self):
        """parse_lines skips invalid lines and yields valid ones."""
        lines = [
            '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.0" 200 2326',
            "this is garbage",
            "",
            '10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512',
        ]
        result = list(parse_lines(lines))
        assert len(result) == 2
        assert result[0].ip == "127.0.0.1"
        assert result[1].ip == "10.0.0.1"

    def test_all_invalid_lines(self):
        """parse_lines with all invalid lines produces no entries."""
        lines = ["garbage", "more garbage", ""]
        result = list(parse_lines(lines))
        assert result == []

    def test_is_generator(self):
        """parse_lines returns a generator, not a list."""
        result = parse_lines([])
        assert hasattr(result, "__next__")

    def test_lazy_evaluation(self):
        """parse_lines evaluates lazily (doesn't consume all input upfront)."""
        call_count = [0]

        def lazy_lines():
            for line in [
                '127.0.0.1 - - [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.0" 200 2326',
                '10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "GET / HTTP/1.0" 200 100',
            ]:
                call_count[0] += 1
                yield line

        gen = parse_lines(lazy_lines())
        # Consume only the first entry
        first = next(gen)
        assert first.ip == "127.0.0.1"
        # Only one line should have been consumed
        assert call_count[0] == 1


# ── parse_line edge cases ─────────────────────────────────────────────────


class TestParseLineEdgeCases:
    """Edge case tests for parse_line."""

    def test_whitespace_only_line(self):
        """A line with only whitespace returns None."""
        assert parse_line("   ") is None
        assert parse_line("\t") is None

    def test_line_with_leading_trailing_whitespace(self):
        """Lines with leading/trailing whitespace are stripped and parsed."""
        line = '  127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.0" 200 2326  '
        result = parse_line(line)
        assert result is not None
        assert result.ip == "127.0.0.1"

    def test_various_http_methods(self):
        """parse_line handles various HTTP methods."""
        for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
            line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "{method} / HTTP/1.1" 200 100'
            result = parse_line(line)
            assert result is not None, f"Failed to parse {method}"
            assert result.method == method

    def test_various_status_codes(self):
        """parse_line handles various status codes."""
        for status in [200, 201, 301, 302, 304, 400, 401, 403, 404, 500, 502, 503]:
            line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" {status} 100'
            result = parse_line(line)
            assert result is not None
            assert result.status == status

    def test_url_with_query_string(self):
        """URLs with query strings are parsed correctly."""
        line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /search?q=hello&page=1 HTTP/1.1" 200 5000'
        result = parse_line(line)
        assert result is not None
        assert result.url == "/search?q=hello&page=1"

    def test_url_with_encoded_characters(self):
        """URLs with percent-encoded characters are parsed correctly."""
        line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /path%20with%20spaces HTTP/1.1" 200 100'
        result = parse_line(line)
        assert result is not None
        assert result.url == "/path%20with%20spaces"

    def test_ipv6_address(self):
        """IPv6 addresses are parsed correctly."""
        line = '::1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100'
        result = parse_line(line)
        assert result is not None
        assert result.ip == "::1"

    def test_user_field_with_username(self):
        """Non-dash user fields are parsed correctly."""
        line = '127.0.0.1 - admin [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100'
        result = parse_line(line)
        assert result is not None
        assert result.user == "admin"

    def test_large_byte_count(self):
        """Large byte counts are parsed correctly."""
        line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 999999999'
        result = parse_line(line)
        assert result is not None
        assert result.bytes == 999999999

    def test_http_protocol_versions(self):
        """Various HTTP protocol versions are parsed."""
        for proto in ["HTTP/1.0", "HTTP/1.1", "HTTP/2.0"]:
            line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / {proto}" 200 100'
            result = parse_line(line)
            assert result is not None
            assert result.protocol == proto

    def test_malformed_method_returns_none(self):
        """Lines with non-uppercase methods return None (regex requires [A-Z]+)."""
        line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "get / HTTP/1.1" 200 100'
        result = parse_line(line)
        assert result is None

    def test_missing_protocol_returns_none(self):
        """Lines with missing protocol return None."""
        line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /" 200 100'
        result = parse_line(line)
        assert result is None

    def test_log_entry_is_frozen(self):
        """LogEntry dataclass is frozen (immutable)."""
        line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100'
        entry = parse_line(line)
        assert entry is not None
        try:
            entry.ip = "hacker"
            assert False, "Expected FrozenInstanceError"
        except Exception as e:
            assert "frozen" in str(e).lower() or "immutable" in str(e).lower() or "frozen" in type(e).__name__.lower()


# ── parse_timestamp edge cases ────────────────────────────────────────────


class TestParseTimestampEdgeCases:
    """Edge case tests for parse_timestamp."""

    def test_positive_timezone_offset(self):
        """Positive timezone offsets are handled correctly."""
        # +0530 means local time is 5:30 ahead of UTC
        # 12:00 +0530 → 06:30 UTC
        ts = parse_timestamp("15/Mar/2026:12:00:00 +0530")
        assert ts.hour == 6
        assert ts.minute == 30

    def test_utc_timezone(self):
        """+0000 timezone produces the same time in UTC."""
        ts = parse_timestamp("01/Jan/2026:00:00:00 +0000")
        assert ts.hour == 0
        assert ts.minute == 0

    def test_negative_timezone_offset(self):
        """Negative timezone offsets are handled correctly."""
        # -0500 means local time is 5 hours behind UTC
        # 12:00 -0500 → 17:00 UTC
        ts = parse_timestamp("15/Mar/2026:12:00:00 -0500")
        assert ts.hour == 17
        assert ts.minute == 0

    def test_march_date(self):
        """March timestamps parse correctly (month=3)."""
        ts = parse_timestamp("15/Mar/2026:12:00:00 +0000")
        assert ts.month == 3

    def test_december_date(self):
        """December timestamps parse correctly (month=12)."""
        ts = parse_timestamp("31/Dec/2026:23:59:59 +0000")
        assert ts.month == 12
        assert ts.day == 31

    def test_invalid_timestamp_raises_value_error(self):
        """Invalid timestamp format raises ValueError."""
        with pytest.raises(ValueError):
            parse_timestamp("not-a-timestamp")

    def test_empty_timestamp_raises_value_error(self):
        """Empty string raises ValueError."""
        with pytest.raises(ValueError):
            parse_timestamp("")

    def test_missing_timezone_raises_value_error(self):
        """Timestamp without timezone offset raises ValueError."""
        with pytest.raises(ValueError):
            parse_timestamp("15/Mar/2026:12:00:00")

    def test_all_months_parse(self):
        """All 11 months in MONTH_NAMES parse correctly (Jul is missing — known bug)."""
        # NOTE: "Jul" is missing from MONTH_NAMES — this is a known bug
        # We test the months that DO work
        working_months = [
            ("Jan", 1), ("Feb", 2), ("Mar", 3), ("Apr", 4), ("May", 5),
            ("Jun", 6), ("Aug", 8), ("Sep", 9), ("Oct", 10), ("Nov", 11), ("Dec", 12),
        ]
        for month_str, expected_month in working_months:
            ts = parse_timestamp(f"15/{month_str}/2026:12:00:00 +0000")
            assert ts.month == expected_month, f"Failed for {month_str}"

    def test_july_raises_value_error(self):
        """July timestamps raise ValueError because 'Jul' is missing from MONTH_NAMES.

        This is a known bug in the production code. The test documents the behavior.
        """
        with pytest.raises(ValueError):
            parse_timestamp("04/Jul/2026:12:00:00 +0000")
