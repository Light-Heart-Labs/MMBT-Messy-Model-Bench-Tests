"""Tests for cli.py — command-line entry point.

Exercises the 0%-coverage CLI module including:
- Argument parsing
- Integration with filters, aggregators, and output formatters
- Edge cases like missing files, empty results
"""
import os
import tempfile

from logalyzer.cli import build_parser, main
from logalyzer.parser import LogEntry


SAMPLE_LINE = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326'


def _write_temp(content: str) -> str:
    """Write content to a temp file and return the path."""
    fd, path = tempfile.mkstemp(suffix=".log")
    with os.fdopen(fd, "w") as f:
        f.write(content)
    return path


# ── build_parser ──────────────────────────────────────────────────────────


class TestBuildParser:
    """Tests for argument parser construction."""

    def test_parser_has_required_paths_argument(self):
        """The parser requires at least one log file path."""
        parser = build_parser()
        # paths is a positional argument with nargs="+"
        try:
            parser.parse_args([])
            assert False, "Expected error for missing paths"
        except SystemExit:
            pass

    def test_parser_accepts_status_filter(self):
        """--status argument is accepted."""
        parser = build_parser()
        args = parser.parse_args(["/tmp/test.log", "--status", "404"])
        assert args.status == "404"

    def test_parser_accepts_url_filter(self):
        """--url argument is accepted."""
        parser = build_parser()
        args = parser.parse_args(["/tmp/test.log", "--url", r"^/api"])
        assert args.url == r"^/api"

    def test_parser_accepts_multiple_ip_filters(self):
        """--ip can be repeated for multiple IPs."""
        parser = build_parser()
        args = parser.parse_args(["/tmp/test.log", "--ip", "10.0.0.1", "--ip", "10.0.0.2"])
        assert args.ip == ["10.0.0.1", "10.0.0.2"]

    def test_parser_accepts_since_until(self):
        """--since and --until accept ISO date strings."""
        parser = build_parser()
        args = parser.parse_args(["/tmp/test.log", "--since", "2026-01-01", "--until", "2026-12-31"])
        assert args.since is not None
        assert args.until is not None

    def test_parser_accepts_expr(self):
        """--expr argument is accepted."""
        parser = build_parser()
        args = parser.parse_args(["/tmp/test.log", "--expr", "entry.status >= 500"])
        assert args.expr == "entry.status >= 500"

    def test_parser_accepts_aggregate(self):
        """--aggregate accepts status, url, hour."""
        parser = build_parser()
        for agg in ["status", "url", "hour"]:
            args = parser.parse_args(["/tmp/test.log", "--aggregate", agg])
            assert args.aggregate == agg

    def test_parser_rejects_invalid_aggregate(self):
        """--aggregate rejects invalid values."""
        parser = build_parser()
        try:
            parser.parse_args(["/tmp/test.log", "--aggregate", "invalid"])
            assert False, "Expected error for invalid aggregate"
        except SystemExit:
            pass

    def test_parser_accepts_format(self):
        """--format accepts text, json, csv."""
        parser = build_parser()
        for fmt in ["text", "json", "csv"]:
            args = parser.parse_args(["/tmp/test.log", "--format", fmt])
            assert args.format == fmt

    def test_parser_default_format_is_text(self):
        """Default format is text."""
        parser = build_parser()
        args = parser.parse_args(["/tmp/test.log"])
        assert args.format == "text"

    def test_parser_accepts_top(self):
        """--top accepts an integer."""
        parser = build_parser()
        args = parser.parse_args(["/tmp/test.log", "--top", "10"])
        assert args.top == 10

    def test_parser_accepts_version(self):
        """--version prints version and exits."""
        parser = build_parser()
        try:
            parser.parse_args(["--version"])
            assert False, "Expected SystemExit for --version"
        except SystemExit as e:
            assert e.code == 0


# ── main ──────────────────────────────────────────────────────────────────


class TestMain:
    """Integration tests for main()."""

    def test_main_returns_zero_on_success(self):
        """main() returns 0 on successful execution."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = main([path])
            assert result == 0
        finally:
            os.unlink(path)

    def test_main_with_status_filter(self):
        """main() with --status filters entries."""
        path = _write_temp(
            SAMPLE_LINE + "\n"
            + '127.0.0.1 - - [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.0" 404 0\n'
        )
        try:
            result = main([path, "--status", "200", "--format", "json"])
            assert result == 0
        finally:
            os.unlink(path)

    def test_main_with_aggregate_status(self):
        """main() with --aggregate status produces status counts."""
        path = _write_temp(
            SAMPLE_LINE + "\n"
            + '127.0.0.1 - - [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.0" 404 0\n'
        )
        try:
            result = main([path, "--aggregate", "status"])
            assert result == 0
        finally:
            os.unlink(path)

    def test_main_with_aggregate_url(self):
        """main() with --aggregate url produces URL counts."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = main([path, "--aggregate", "url"])
            assert result == 0
        finally:
            os.unlink(path)

    def test_main_with_aggregate_hour(self):
        """main() with --aggregate hour produces hour counts."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = main([path, "--aggregate", "hour"])
            assert result == 0
        finally:
            os.unlink(path)

    def test_main_with_json_format(self):
        """main() with --format json produces JSON output."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = main([path, "--format", "json"])
            assert result == 0
        finally:
            os.unlink(path)

    def test_main_with_csv_format(self):
        """main() with --format csv produces CSV output."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = main([path, "--format", "csv"])
            assert result == 0
        finally:
            os.unlink(path)

    def test_main_with_empty_file(self):
        """main() with an empty file produces no entries."""
        path = _write_temp("")
        try:
            result = main([path])
            assert result == 0
        finally:
            os.unlink(path)

    def test_main_with_nonexistent_file(self):
        """main() with a nonexistent file raises FileNotFoundError."""
        try:
            main(["/nonexistent/file.log"])
            assert False, "Expected FileNotFoundError"
        except FileNotFoundError:
            pass

    def test_main_with_multiple_files(self):
        """main() with multiple file paths processes all of them."""
        path1 = _write_temp(SAMPLE_LINE + "\n")
        path2 = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = main([path1, path2])
            assert result == 0
        finally:
            os.unlink(path1)
            os.unlink(path2)

    def test_main_with_since_filter(self):
        """main() with --since filters by date."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = main([path, "--since", "2000-01-01"])
            assert result == 0
        finally:
            os.unlink(path)

    def test_main_with_ip_filter(self):
        """main() with --ip filters by IP."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = main([path, "--ip", "127.0.0.1"])
            assert result == 0
        finally:
            os.unlink(path)

    def test_main_with_top_parameter(self):
        """main() with --top limits aggregate results."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = main([path, "--aggregate", "url", "--top", "5"])
            assert result == 0
        finally:
            os.unlink(path)
