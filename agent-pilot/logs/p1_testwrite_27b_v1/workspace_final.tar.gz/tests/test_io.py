"""Tests for io.py — file loading helpers.

Exercises the 0%-coverage io module including edge cases like:
- Empty files
- Files with no trailing newline
- Files with malformed lines mixed with valid ones
- load() vs load_iter() consistency
"""
import os
import tempfile

from logalyzer.io import load, load_iter
from logalyzer.parser import LogEntry


SAMPLE_LINE = '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326'


def _write_temp(content: str) -> str:
    """Write content to a temp file and return the path."""
    fd, path = tempfile.mkstemp(suffix=".log")
    with os.fdopen(fd, "w") as f:
        f.write(content)
    return path


# ── load ──────────────────────────────────────────────────────────────────


class TestLoad:
    """Tests for load() — reads entire file at once."""

    def test_empty_file(self):
        """An empty file returns an empty list."""
        path = _write_temp("")
        try:
            result = load(path)
            assert result == []
        finally:
            os.unlink(path)

    def test_single_line_with_trailing_newline(self):
        """A file with one valid line and a trailing newline."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = load(path)
            assert len(result) == 1
            assert isinstance(result[0], LogEntry)
            assert result[0].ip == "127.0.0.1"
        finally:
            os.unlink(path)

    def test_single_line_without_trailing_newline(self):
        """A file with one valid line and NO trailing newline.

        This is a common edge case — the last line of a file often lacks
        a trailing newline. The load() function must handle this.
        """
        path = _write_temp(SAMPLE_LINE)
        try:
            result = load(path)
            assert len(result) == 1
            assert result[0].ip == "127.0.0.1"
        finally:
            os.unlink(path)

    def test_multiple_lines(self):
        """A file with multiple valid lines."""
        path = _write_temp(SAMPLE_LINE + "\n" + SAMPLE_LINE + "\n")
        try:
            result = load(path)
            assert len(result) == 2
        finally:
            os.unlink(path)

    def test_malformed_lines_are_skipped(self):
        """Malformed lines are silently skipped."""
        path = _write_temp(SAMPLE_LINE + "\ngarbage line\n" + SAMPLE_LINE + "\n")
        try:
            result = load(path)
            assert len(result) == 2
        finally:
            os.unlink(path)

    def test_blank_lines_are_skipped(self):
        """Blank lines (empty or whitespace-only) are skipped."""
        path = _write_temp(SAMPLE_LINE + "\n\n  \n" + SAMPLE_LINE + "\n")
        try:
            result = load(path)
            assert len(result) == 2
        finally:
            os.unlink(path)

    def test_only_malformed_lines(self):
        """A file with only malformed lines returns an empty list."""
        path = _write_temp("garbage\nmore garbage\n")
        try:
            result = load(path)
            assert result == []
        finally:
            os.unlink(path)

    def test_returns_list_of_log_entries(self):
        """load() returns a list, not a generator."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = load(path)
            assert isinstance(result, list)
        finally:
            os.unlink(path)

    def test_nonexistent_file_raises_file_not_found(self):
        """Loading a nonexistent file raises FileNotFoundError."""
        try:
            load("/nonexistent/path/to/file.log")
            assert False, "Expected FileNotFoundError"
        except FileNotFoundError:
            pass


# ── load_iter ─────────────────────────────────────────────────────────────


class TestLoadIter:
    """Tests for load_iter() — generator-based file loading."""

    def test_empty_file(self):
        """An empty file produces no entries."""
        path = _write_temp("")
        try:
            result = list(load_iter(path))
            assert result == []
        finally:
            os.unlink(path)

    def test_single_line(self):
        """A file with one valid line produces one entry."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = list(load_iter(path))
            assert len(result) == 1
            assert result[0].ip == "127.0.0.1"
        finally:
            os.unlink(path)

    def test_multiple_lines(self):
        """A file with multiple valid lines produces multiple entries."""
        path = _write_temp(SAMPLE_LINE + "\n" + SAMPLE_LINE + "\n")
        try:
            result = list(load_iter(path))
            assert len(result) == 2
        finally:
            os.unlink(path)

    def test_malformed_lines_are_skipped(self):
        """Malformed lines are silently skipped."""
        path = _write_temp(SAMPLE_LINE + "\ngarbage\n" + SAMPLE_LINE + "\n")
        try:
            result = list(load_iter(path))
            assert len(result) == 2
        finally:
            os.unlink(path)

    def test_returns_generator(self):
        """load_iter() returns a generator, not a list."""
        path = _write_temp(SAMPLE_LINE + "\n")
        try:
            result = load_iter(path)
            # Check it's a generator (has __next__)
            assert hasattr(result, "__next__")
        finally:
            os.unlink(path)

    def test_nonexistent_file_raises_file_not_found(self):
        """Loading a nonexistent file raises FileNotFoundError."""
        try:
            list(load_iter("/nonexistent/path/to/file.log"))
            assert False, "Expected FileNotFoundError"
        except FileNotFoundError:
            pass


# ── load vs load_iter consistency ─────────────────────────────────────────


class TestLoadVsLoadIter:
    """Tests that load() and load_iter() produce consistent results."""

    def test_consistent_results_for_valid_file(self):
        """load() and load_iter() produce the same entries for a valid file."""
        path = _write_temp(SAMPLE_LINE + "\n" + SAMPLE_LINE + "\n")
        try:
            loaded = load(path)
            iterated = list(load_iter(path))
            assert len(loaded) == len(iterated)
            for a, b in zip(loaded, iterated):
                assert a.ip == b.ip
                assert a.status == b.status
                assert a.url == b.url
        finally:
            os.unlink(path)

    def test_consistent_results_for_mixed_file(self):
        """load() and load_iter() skip malformed lines consistently."""
        path = _write_temp(SAMPLE_LINE + "\ngarbage\n" + SAMPLE_LINE + "\n")
        try:
            loaded = load(path)
            iterated = list(load_iter(path))
            assert len(loaded) == len(iterated)
        finally:
            os.unlink(path)

    def test_consistent_results_for_empty_file(self):
        """load() and load_iter() both return empty for an empty file."""
        path = _write_temp("")
        try:
            assert load(path) == []
            assert list(load_iter(path)) == []
        finally:
            os.unlink(path)
