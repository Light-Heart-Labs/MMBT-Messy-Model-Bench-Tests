"""Tests for experimental.py — anomaly detection and session windowing.

These tests exercise the 0%-coverage experimental module to validate:
- z-score anomaly detection with various distributions
- session windowing with gaps, single entries, and edge cases
"""
from datetime import datetime, timedelta, timezone

import pytest

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1", **kw):
    """Helper to create a LogEntry with a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
        **kw,
    )


# ── detect_anomalies ──────────────────────────────────────────────────────


class TestDetectAnomalies:
    """Tests for z-score-based anomaly detection."""

    def test_empty_entries_returns_empty_list(self):
        """No entries → no anomalies."""
        assert detect_anomalies([]) == []

    def test_uniform_distribution_no_anomalies(self):
        """When all minutes have the same count, no anomalies are detected."""
        # 10 entries, each in a different minute → all counts = 1
        entries = [_entry(datetime(2026, 1, 1, 0, i, 0, tzinfo=timezone.utc)) for i in range(10)]
        result = detect_anomalies(entries)
        assert result == []

    def test_single_spike_detected_as_anomaly(self):
        """A minute with many more requests than others should be flagged.

        NOTE: The algorithm uses population std dev and strict > comparison.
        With only 2 buckets, the spike always equals the threshold exactly.
        We use 50 normal minutes to ensure the spike exceeds mean + 3*std.
        """
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        # 50 minutes with 1 request each
        entries = [_entry(base + timedelta(minutes=i)) for i in range(50)]
        # Add 100 requests in minute 60
        for j in range(100):
            entries.append(_entry(base + timedelta(minutes=60, seconds=j % 59)))
        result = detect_anomalies(entries)
        assert len(result) == 1
        assert result[0] == base + timedelta(minutes=60)

    def test_all_entries_same_minute(self):
        """All entries in the same minute → only one bucket, no anomalies."""
        entries = [_entry(datetime(2026, 1, 1, 0, 0, s, tzinfo=timezone.utc)) for s in range(60)]
        result = detect_anomalies(entries)
        # Single bucket → mean = count, std = 0, threshold = mean → no anomalies
        assert result == []

    def test_two_buckets_one_dominant(self):
        """Two minutes, one with far more entries → the dominant one is anomalous.

        With 2 buckets, the std dev is large. We need a very skewed distribution.
        """
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        # Use many normal minutes to reduce the std dev impact
        entries = [_entry(base + timedelta(minutes=i)) for i in range(20)]
        # Add 500 requests in minute 25
        for j in range(500):
            entries.append(_entry(base + timedelta(minutes=25, seconds=j % 59)))
        result = detect_anomalies(entries)
        assert len(result) == 1
        assert result[0] == base + timedelta(minutes=25)

    def test_seconds_and_microseconds_bucketed_to_minute(self):
        """Entries with different seconds/microseconds in the same minute are bucketed together."""
        base = datetime(2026, 1, 1, 12, 30, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(seconds=30)),
            _entry(base + timedelta(seconds=59, microseconds=999999)),
        ]
        result = detect_anomalies(entries)
        # All in same minute bucket → no anomalies
        assert result == []

    def test_multiple_anomalous_minutes(self):
        """Multiple minutes exceeding the threshold are all returned."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = []
        # 20 normal minutes with 1 request each
        for i in range(20):
            entries.append(_entry(base + timedelta(minutes=i)))
        # 2 spike minutes with enough entries to exceed threshold
        for j in range(200):
            entries.append(_entry(base + timedelta(minutes=25, seconds=j % 59)))
            entries.append(_entry(base + timedelta(minutes=30, seconds=j % 59)))
        result = detect_anomalies(entries)
        assert len(result) == 2
        assert base + timedelta(minutes=25) in result
        assert base + timedelta(minutes=30) in result

    def test_returns_datetime_objects_not_strings(self):
        """Anomaly buckets are datetime objects, not strings."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [_entry(base)] * 100
        result = detect_anomalies(entries)
        # Single bucket → no anomalies, but check type if there were any
        assert isinstance(result, list)

    def test_single_entry_no_anomaly(self):
        """A single entry in a single minute cannot be anomalous."""
        entries = [_entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))]
        result = detect_anomalies(entries)
        assert result == []

    def test_anomaly_buckets_have_seconds_zeroed(self):
        """Anomaly bucket datetimes have seconds and microseconds set to 0."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [_entry(base + timedelta(minutes=i)) for i in range(50)]
        for j in range(100):
            entries.append(_entry(base + timedelta(minutes=60, seconds=j % 59)))
        result = detect_anomalies(entries)
        for bucket in result:
            assert bucket.second == 0
            assert bucket.microsecond == 0


# ── session_window ────────────────────────────────────────────────────────


class TestSessionWindow:
    """Tests for session windowing logic."""

    def test_empty_entries_returns_empty_sessions(self):
        """No entries → no sessions."""
        assert session_window([]) == []

    def test_single_entry_one_session(self):
        """A single entry forms one session."""
        entry = _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))
        sessions = session_window([entry])
        assert len(sessions) == 1
        ip, evs = sessions[0]
        assert ip == "10.0.0.1"
        assert len(evs) == 1

    def test_entries_within_window_form_one_session(self):
        """Entries within the default 30-min window form a single session."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(minutes=10)),
            _entry(base + timedelta(minutes=20)),
        ]
        sessions = session_window(entries)
        assert len(sessions) == 1
        assert len(sessions[0][1]) == 3

    def test_gap_exceeding_window_splits_session(self):
        """A gap strictly larger than the window splits into two sessions.

        NOTE: The code uses `>` (strictly greater), so a gap equal to the
        window does NOT split. We use a gap of 31 minutes to ensure split.
        """
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(minutes=10)),
            _entry(base + timedelta(minutes=41)),  # 31-min gap > 30-min window
        ]
        sessions = session_window(entries)
        assert len(sessions) == 2
        assert len(sessions[0][1]) == 2
        assert len(sessions[1][1]) == 1

    def test_exact_window_boundary_does_not_split(self):
        """A gap exactly equal to window_seconds does NOT split (uses > not >=)."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(seconds=1800)),  # exactly 30 min
        ]
        sessions = session_window(entries, window_seconds=1800)
        assert len(sessions) == 1

    def test_custom_window_seconds(self):
        """Custom window_seconds parameter is respected."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(minutes=5)),
            _entry(base + timedelta(minutes=16)),  # 11-min gap > 10-min window
        ]
        # With 600s (10 min) window, the 11-min gap should split
        sessions = session_window(entries, window_seconds=600)
        assert len(sessions) == 2

    def test_multiple_ips_separate_sessions(self):
        """Different IPs are tracked separately."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base, ip="10.0.0.1"),
            _entry(base + timedelta(minutes=5), ip="10.0.0.2"),
            _entry(base + timedelta(minutes=10), ip="10.0.0.1"),
        ]
        sessions = session_window(entries)
        assert len(sessions) == 2
        ips = {s[0] for s in sessions}
        assert ips == {"10.0.0.1", "10.0.0.2"}

    def test_sessions_sorted_by_timestamp(self):
        """Entries within a session are sorted by timestamp."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base + timedelta(minutes=10)),
            _entry(base),
            _entry(base + timedelta(minutes=5)),
        ]
        sessions = session_window(entries)
        assert len(sessions) == 1
        timestamps = [e.timestamp for e in sessions[0][1]]
        assert timestamps == sorted(timestamps)

    def test_many_sessions_from_single_ip(self):
        """A single IP with many gaps produces many sessions."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = []
        for hour in range(10):
            entries.append(_entry(base + timedelta(hours=hour, minutes=5)))
            entries.append(_entry(base + timedelta(hours=hour, minutes=10)))
        # Each pair is 5 min apart (within window), but pairs are 55 min apart
        sessions = session_window(entries, window_seconds=1800)
        assert len(sessions) == 10

    def test_session_returns_tuples_of_ip_and_list(self):
        """Each session is a (ip_str, [LogEntry, ...]) tuple."""
        entry = _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))
        sessions = session_window([entry])
        ip, evs = sessions[0]
        assert isinstance(ip, str)
        assert isinstance(evs, list)
        assert all(isinstance(e, LogEntry) for e in evs)

    def test_gap_of_zero_seconds_does_not_split(self):
        """Two entries at the exact same timestamp form one session."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [_entry(base), _entry(base)]
        sessions = session_window(entries)
        assert len(sessions) == 1
        assert len(sessions[0][1]) == 2
