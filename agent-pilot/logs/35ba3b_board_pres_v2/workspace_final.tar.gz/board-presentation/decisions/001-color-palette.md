# ADR-001: Color Palette — Sequential Blues with Scenario Accents

**Date:** 2025-06-18
**Status:** Accepted

## Context
Need a color palette for the deck that is distinctive but functional. The board is technical and will scrutinize every design choice.

## Decision
**Primary palette:** Deep navy (#0A1628) background, white text, with a sequential blue colormap for data visualization.

**Scenario colors:**
- Bear: #E74C3C (red) — consistent across all scenario visualizations
- Base: #3498DB (blue) — consistent across all scenario visualizations
- Bull: #2ECC71 (green) — consistent across all scenario visualizations

**Accent colors:**
- GitLab brand: #E24329 (orange-red) — used only for GitLab-specific data points
- Peer average: #95A5A6 (gray) — used for reference lines and peer data
- Highlight: #F39C12 (amber) — used for inflection points and catalysts

## Rationale
1. **Dark background** reduces eye strain for a 30-minute presentation and makes charts pop
2. **Sequential blues** for financial data because the data has a natural zero point (current price) and we're showing deviation from it
3. **Scenario colors are consistent** — bear is always red, bull is always green, across every chart that uses them. This is not decorative; it's functional.
4. **GitLab's brand color** is used sparingly — only when we need to distinguish GitLab from peers in a chart
5. **No clip-art colors** — every color serves a data purpose

## Alternatives Considered
- **Light background with dark text:** More traditional, but harder on the eyes for a long presentation
- **Diverging colormap for all data:** Would imply a natural midpoint, but most financial data doesn't have one
- **Rainbow palette:** Too decorative, would distract from the data

## Impact
All charts in /assets/charts/ use this palette. The scenario colors are hardcoded in each chart script for consistency.
