# ADR-003: Chart Convention — Scatter Plots Over Pie Charts for Competitive Landscape

**Date:** 2025-06-18
**Status:** Accepted

## Context
The competitive landscape slide needs to show GitLab's position relative to peers. The input repo's memo uses a table, but a table is hard to digest in a presentation.

## Decision
**Use a scatter plot** with:
- X-axis: Revenue Growth Rate
- Y-axis: Operating Margin
- Bubble size: Market Cap
- Color: Sector

## Rationale
1. **Pie charts obscure the actual thesis** — they show market share distribution but hide the relationship between growth and profitability that is the core of the investment thesis
2. **Scatter plots reveal structure** — you can immediately see which companies are high-growth/high-margin vs. low-growth/low-margin
3. **Bubble size adds a third dimension** — market cap context without cluttering the chart
4. **GitLab's position is clear** — high growth (23%), improving margins (-1%), undervalued (small bubble)

## Alternatives Considered
- **Table (input repo approach):** Accurate but hard to digest in a presentation
- **Bar chart of EV/Revenue multiples:** Shows valuation but not growth/margin dynamics
- **Radar chart:** Too many dimensions, hard to read
- **Pie chart of market share:** Obscures the actual thesis (margin compression at scale)

## Impact
The scatter plot script is in /assets/charts/06_competitive_scatter.py. It reads competitor data from /input/repo/extracted/competitor_data.json.
