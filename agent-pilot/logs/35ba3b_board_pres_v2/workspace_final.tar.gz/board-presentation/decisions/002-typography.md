# ADR-002: Typography — System Fonts for Reproducibility

**Date:** 2025-06-18
**Status:** Accepted

## Context
Need typography that renders consistently across all systems without requiring font installation. The deck must be viewable on any machine.

## Decision
**Headings:** Montserrat (Google Fonts) — bold, geometric, modern
**Body:** Source Sans Pro (Google Fonts) — clean, readable, professional
**Data/Numbers:** Roboto Mono (Google Fonts) — monospaced, precise, technical

## Rationale
1. **Google Fonts are free and widely available** — no licensing issues
2. **System fallbacks:** Helvetica Neue → Arial → sans-serif for headings; Georgia → serif for body; Courier New → monospace for data
3. **Roboto Mono for numbers** ensures alignment in tables and makes financial figures easy to scan
4. **No custom fonts** — avoids rendering issues on different systems

## Alternatives Considered
- **Custom font files embedded in PPTX:** Would increase file size and risk rendering issues
- **System fonts only (Arial, Times):** Too generic, doesn't earn the distinctive design
- **All monospace:** Too technical, hard to read for narrative content

## Impact
Font files are referenced in the PPTX template. Board members viewing the PDF will see the same typography.
