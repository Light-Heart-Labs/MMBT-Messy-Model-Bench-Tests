# ADR-005: Reasoning Trail — Dependency Graph Over Linear Narrative

**Date:** 2025-06-18
**Status:** Accepted

## Context
Need to visualize how the agent moved from filings → analysis → conclusion. A linear narrative (we read this, then that, then concluded) is boring and doesn't show the actual decision process.

## Decision
**Use a dependency graph (node-link diagram)** showing:
- Input nodes: financial data, transcripts, competitor data
- Process nodes: DCF model, peer comparison, scenario analysis
- Decision nodes: company selection, valuation methodology, competitor selection
- Output nodes: recommendation, price target, thesis

Edges show data flow and dependency relationships.

## Rationale
1. **A dependency graph shows the actual structure of the analysis** — not just the sequence, but the relationships between components
2. **It's reproducible** — a board member can trace any conclusion back to its data source
3. **It demonstrates capability** — the graph shows the system's ability to integrate multiple data sources
4. **It's honest about complexity** — the analysis isn't a straight line; it's a network of interdependent decisions

## Alternatives Considered
- **Linear timeline:** Too simple, doesn't show the branching nature of analysis
- **Flowchart:** Too detailed, would be overwhelming
- **Mind map:** Too informal for a technical audience
- **Commit history visualization:** Too low-level, doesn't show the analytical structure

## Impact
The reasoning trail diagram is in /assets/diagrams/01_reasoning_trail.svg. It's generated from the input repo's decisions/, research/notes/, and commit history.
