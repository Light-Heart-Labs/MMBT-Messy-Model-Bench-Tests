# ADR-004: Price Target Visualization — Distribution Over Point Estimate

**Date:** 2025-06-18
**Status:** Accepted

## Context
The memo gives a single price target ($42.00) but also provides bear/base/bull scenarios. Presenting the target as a single number is misleading — it implies more precision than exists.

## Decision
**Show the price target as a probability-weighted distribution** — a histogram or density plot showing the full range of outcomes with their probabilities.

Bear ($18.58, 25%) — Base ($38.52, 50%) — Bull ($88.30, 25%)
Probability-weighted target: $45.98

## Rationale
1. **A single number implies false precision** — the board is technical and will recognize that DCF valuations are sensitive to assumptions
2. **A distribution shows the full range of possibilities** — the board can see the upside ($88.30) and downside ($18.58) at a glance
3. **Probability weighting is the honest approach** — it combines the scenarios into a single expected value while preserving the uncertainty
4. **Consistent with the memo's own analysis** — the memo already provides scenario probabilities

## Alternatives Considered
- **Single number with confidence interval:** Less intuitive than a distribution
- **Three separate bullet points:** Too text-heavy, doesn't visualize the uncertainty
- **Box plot:** Too statistical, less accessible to non-quants
- **Monte Carlo simulation:** Overkill for this analysis; the memo's scenarios are sufficient

## Impact
The distribution chart is in /assets/charts/09_scenario_distribution.py. It uses the scenario data from the memo.
