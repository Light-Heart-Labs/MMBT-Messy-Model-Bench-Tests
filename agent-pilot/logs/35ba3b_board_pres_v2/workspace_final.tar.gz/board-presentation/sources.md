# External Sources

Any external content fetched for the deck (icons, fonts, reference imagery).

## Fonts (Google Fonts)

| Font | URL | License | Usage |
|------|-----|---------|-------|
| Montserrat | https://fonts.google.com/specimen/Montserrat | Open Font License | Headings |
| Source Sans Pro | https://fonts.google.com/specimen/Source+Sans+Pro | Open Font License | Body text |
| Roboto Mono | https://fonts.google.com/specimen/Roboto+Mono | Open Font License | Data/numbers |

## Chart Libraries

| Library | URL | Version | Usage |
|---------|-----|---------|-------|
| matplotlib | https://matplotlib.org/ | 3.9.x | All chart generation |
| pandas | https://pandas.pydata.org/ | 2.2.x | Data manipulation |
| scipy | https://scipy.org/ | 1.14.x | KDE for scenario distribution |
| python-pptx | https://python-pptx.readthedocs.io/ | 1.0.x | PPTX generation |

## No External Imagery

- No clip-art, no stock photography, no AI-generated faces
- All visuals are data-driven (charts, diagrams, tables)
- The GitLab brand color (#E24329) is from GitLab's public branding
