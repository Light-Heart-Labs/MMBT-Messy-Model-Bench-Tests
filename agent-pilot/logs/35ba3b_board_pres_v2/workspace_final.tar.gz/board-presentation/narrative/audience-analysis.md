# Audience Analysis: Board of Advisors

## Who's on the Board

Based on the task description, the board is:
- **Technical** — they understand financial models, valuation methods, and SaaS metrics
- **Skeptical** — they want to evaluate the agent system's reasoning, not rubber-stamp a pick
- **Experienced** — they've read the investment memo; this deck is for discussion, not redelivery

## What Each Board Member Cares About

### The Quantitative Analyst
- **Cares about:** Model assumptions, data provenance, statistical rigor
- **Questions they'll ask:**
  - "What's the beta you used for WACC, and why?"
  - "How sensitive is the DCF to terminal growth rate?"
  - "Are the ARR/NRR figures from management or independently verified?"
- **How the deck addresses them:**
  - Every number traces to a source file in /audit/traces/
  - ADRs document every non-obvious choice
  - Scenario analysis shows sensitivity to key assumptions
  - The "how to audit" slide gives them the tools to verify independently

### The Risk Manager
- **Cares about:** What could go wrong, downside protection, tail risks
- **Questions they'll ask:**
  - "What's the worst-case scenario?"
  - "How concentrated is the risk?"
  - "What would trigger a sell?"
- **How the deck addresses them:**
  - Dedicated risk assessment slide with probability/impact matrix
  - Bear case shows 14% downside (not catastrophic)
  - $1.26B cash provides significant downside protection
  - "What would change the recommendation" slide shows the kill criteria

### The Process Auditor
- **Cares about:** How the analysis was conducted, what was considered, what was rejected
- **Questions they'll ask:**
  - "What alternatives did you consider?"
  - "What data sources did you try and fail to access?"
  - "How do I know you didn't cherry-pick data?"
- **How the deck addresses them:**
  - Dead ends slide shows failed approaches honestly
  - Reasoning trail visualization shows the full decision process
  - Commit history shows the evolution of the analysis
  - /decisions/ contains ADRs for every key choice

### The Investment Committee Chair
- **Cares about:** The recommendation, the thesis, the conviction level
- **Questions they'll ask:**
  - "What's your price target and why?"
  - "How confident are you?"
  - "What's the catalyst?"
- **How the deck addresses them:**
  - Recommendation is Slide 2 — the second slide
  - Confidence visualization shows probability-weighted outcomes
  - Catalysts are called out in the memo and referenced in the deck

## Presentation Strategy

### Tone
- **Confident but not arrogant** — we have a thesis, but we've stress-tested it
- **Transparent about limitations** — we know what we don't know
- **Data-driven** — every claim is backed by a traceable source

### Pacing
- **Slides 1-3 (5 min):** Recommendation and thesis — fast, decisive
- **Slides 4-8 (10 min):** Evidence — data-heavy, let the numbers speak
- **Slides 9-11 (8 min):** Process — show the reasoning trail
- **Slides 12-13 (5 min):** Audit — the meta-layer

### Q&A Preparation
- Anticipate pushback on: NRR decline trend, AI monetization uncertainty, competition from GitHub
- Have the dead ends and limitations ready to discuss
- The "how to audit" slide is the ultimate Q&A tool — invite verification
