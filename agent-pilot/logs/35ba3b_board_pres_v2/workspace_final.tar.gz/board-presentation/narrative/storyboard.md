# Storyboard: GitLab (GTLB) Board Presentation

**Date:** 2025-06-18
**Audience:** Board of Advisors (technical, skeptical)
**Duration:** 30 min presentation + 15 min Q&A
**Goal:** Walk the board through the recommendation AND the reasoning trail

---

## Narrative Arc

### Act I: The Ask (Slides 1-3) — "Here's what we think, and why you should care"

**Slide 1: Title — GitLab (GTLB): A Case for Conviction**
- Set the stage: mid-cap SaaS, DevOps platform, $3.66B market cap
- No fluff — this is a technical audience

**Slide 2: Recommendation & Price Target — BUY, $42.00, 95% upside**
- Lead with the answer. Technical audiences respect decisiveness.
- Show confidence level: probability-weighted target $45.98
- Visual: price target as a distribution, not a point estimate
- This is the single most important slide — everything else supports it

**Slide 3: The Thesis in One Slide**
- 5 bullet points, in the agent's own words (from the memo)
- Each bullet maps to a later slide for deep dive
- This is the "elevator pitch" — if the board remembers nothing else, they remember this

### Act II: The Evidence (Slides 4-8) — "Here's the data that supports it"

**Slide 4: What Would Change the Recommendation**
- 2-3 specific conditions that would flip the thesis
- Shows intellectual honesty — we're not married to the conclusion
- Examples: NRR below 110%, AI monetization failure, GitHub Copilot full DevOps platform

**Slide 5: Financial Trajectory — Historical and Projected**
- Revenue, operating margin, FCF, ARR — all on one chart
- Call out the inflection points: FCF turned positive FY2024, operating margin improving 13pp/year
- Projected to FY2031 with clear assumptions
- This is the data backbone — every number traces to extracted/income_statement_annual.csv

**Slide 6: Competitive Position**
- Scatter plot: growth vs. margin, sized by market cap
- GitLab in the center — high growth, improving margins, undervalued
- Explain WHY these comps were chosen (ADR-002)
- Not a pie chart — pie charts obscure the actual thesis (margin compression at scale)

**Slide 7: The Mispricing Thesis**
- Why is the market wrong? Three reasons:
  1. AI monetization not priced in
  2. Operating leverage trajectory underestimated
  3. Balance sheet strength as optionality
- Compare GitLab's EV/Revenue (2.6x) to peer average (7.0x)
- This is the "alpha" slide — where the edge comes from

### Act III: The Process (Slides 9-11) — "Here's how we got here"

**Slide 8: Risk Assessment — Prioritized**
- Risk matrix: probability vs. impact
- Each risk has a "what would have to be true" condition
- Shows we've thought about what could go wrong

**Slide 9: Bear/Base/Bull Scenarios — Probability-Weighted**
- NOT three bullet points — a real visualization
- Distribution of outcomes with probabilities
- Price target as a range, not a number
- Shows the full spectrum of possibilities

**Slide 10: The Reasoning Trail**
- Visual: dependency graph from filings → analysis → conclusion
- Shows the actual decision process, not just the output
- Source: commit history, decisions/, research/notes/
- This is the capability demonstration — how the agent thinks

**Slide 11: Dead Ends — Hypotheses Investigated and Rejected**
- SEC filings blocked → used yfinance (documented)
- CIK lookup failed initially → found correct one
- GitLab IR site unreachable → used transcripts
- Shows intellectual honesty — we investigated, we failed, we adapted
- Boards trust analysts who show their work

### Act IV: The Audit (Slides 12-13) — "Here's how you can verify everything"

**Slide 12: Confidence & Limitations — Visual**
- What we're confident about (facts, not estimates)
- What we're estimating (forward-looking, uncertain)
- What a human analyst would do differently
- Visual: confidence thermometer or radar chart

**Slide 13: How to Audit This Deck**
- Self-audit slide: the most important slide for a skeptical board
- Step-by-step: clone repo → pick any claim → follow trace → verify
- Show the trace mechanism in action with an example
- This is the capability demonstration's capstone

---

## Design Principles

1. **Lead with the recommendation** — don't bury the lead
2. **Show the reasoning trail** — the process is as important as the conclusion
3. **Surface dead ends** — intellectual honesty builds trust
4. **Visualize, don't bullet** — charts over text, especially for financial data
5. **Every number traces back** — no claim without a source
6. **Color is functional** — sector colors consistent, scenario colors consistent
7. **No clip-art, no stock imagery** — charts are the visual centerpiece

## Slide Order Rationale

We lead with the recommendation because:
- The board has read the memo; this is for discussion, not redelivery
- Technical audiences want the answer first, then the evidence
- It frames the entire presentation — every subsequent slide supports or challenges the recommendation

We end with the audit because:
- It's the meta-layer that validates everything that came before
- It's the "trust but verify" moment
- It demonstrates the system's capability to be transparent

## Rejected Structures

1. **Chronological (data → analysis → conclusion)** — Too academic, buries the lead
2. **Problem → Solution format** — Implies GitLab is the problem, not the investment
3. **Competitive analysis first** — Context matters, but the recommendation is the story

See `/narrative/alternatives.md` for full details.
