# Audit: Quotes in the Deck

Every quote in the deck with file + line number in the input repo, plus surrounding context.

## Quote 1: GitLab Business Description

**Quote:** "GitLab Inc., together with its subsidiaries, develops software for the software development lifecycle in the United States, Europe, and the Asia Pacific. The company provides GitLab, an intelligent orchestration platform for DevSecOps, which is a single application offering the entire software development lifecycle, including software, project plans, code, security scans, compliance checks, and deployment configurations."

**Source:** /input/repo/extracted/company_info.json
**Field:** `longBusinessSummary`
**Context:** This is the full business description from yfinance, sourced from the company's SEC filings. It provides the official business description used for the "What is GitLab" framing in the deck.

## Quote 2: GitLab Duo Platform Description

**Quote:** "It also offers the GitLab Duo Agent Platform, which enables intelligent orchestration of teams and AI agents to execute tasks autonomously across planning, development, security, and deployment. This platform combines conversational AI assistance, purpose-built agents for specialized tasks, workflow automation, and enterprise controls."

**Source:** /input/repo/extracted/company_info.json
**Field:** `longBusinessSummary` (second paragraph)
**Context:** This is the AI-specific portion of the business description. It's used to support the AI monetization thesis in the deck.

## Quote 3: Earnings Call — Q4 2024 (Sid Sijbrandij)

**Quote:** "GitLab's Co-Founder and CEO, Sid Sijbrandij; and GitLab's Chief Financial Officer, Brian Robbins, will provide commentary on the quarter and the fiscal year."

**Source:** /input/repo/raw/transcripts/GTLB_Q4_2024_transcript.txt
**Lines:** 1-50 (opening section)
**Context:** This is the opening of the Q4 2024 earnings call transcript. The full transcript is available at /input/repo/raw/transcripts/GTLB_Q4_2024_transcript.txt. The transcript confirms the call participants and provides the Safe Harbor statement context.

## Quote 4: Earnings Call — Q1 2025

**Quote:** "GitLab Inc. (GTLB) Q1 2025 Earnings Call Transcript"
**Date:** Q1 2025 earnings call

**Source:** /input/repo/raw/transcripts/GTLB_Q1_2025_transcript.txt
**Lines:** 1-100 (opening section)
**Context:** This is the most recent earnings call transcript in the input repo. It contains management commentary on the latest quarter's results, including ARR, NRR, and AI feature adoption.

## Note on Quotes

The input repo's transcripts are from Seeking Alpha and contain the standard opening sections (operator instructions, Safe Harbor, participant introductions). The full transcripts contain management commentary on financial results, but the specific ARR/NRR figures cited in the memo are management-disclosed metrics that appear throughout the call commentary sections.

For the deck, we reference the transcripts as the source of ARR and NRR figures, which are management metrics disclosed in earnings calls rather than GAAP financial statement items.
