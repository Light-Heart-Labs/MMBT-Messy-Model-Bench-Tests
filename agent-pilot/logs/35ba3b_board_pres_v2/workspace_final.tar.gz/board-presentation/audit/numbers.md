# Audit: Numbers in the Deck

Every number in the deck with its source path in the input repo.

## Recommendation Slide (Slide 2)

| Number | Source File | Location | Notes |
|--------|------------|----------|-------|
| $21.51 (Current Price) | /input/repo/extracted/company_info.json | `currentPrice` field | yfinance API |
| $3.66B (Market Cap) | /input/repo/extracted/company_info.json | `marketCap` field | yfinance API |
| $42.00 (Price Target) | /input/repo/memo/gitlab_investment_memo.md | Line ~8 | Stated in memo |
| 95% (Upside) | /input/repo/memo/gitlab_investment_memo.md | Line ~8 | Calculated: ($42-$21.51)/$21.51 |
| $45.98 (Prob-Weighted) | /input/repo/memo/gitlab_investment_memo.md | Line ~9 | Calculated in memo |
| 114% (Prob-Weighted Upside) | /input/repo/memo/gitlab_investment_memo.md | Line ~9 | Calculated: ($45.98-$21.51)/$21.51 |

## Financial Trajectory Slide (Slide 5)

| Number | Source File | Location | Notes |
|--------|------------|----------|-------|
| $424M (FY2023 Revenue) | /input/repo/extracted/income_statement_annual.csv | TotalRevenue, 2023-01-31 column | yfinance |
| $580M (FY2024 Revenue) | /input/repo/extracted/income_statement_annual.csv | TotalRevenue, 2024-01-31 column | yfinance |
| $759M (FY2025 Revenue) | /input/repo/extracted/income_statement_annual.csv | TotalRevenue, 2025-01-31 column | yfinance |
| $955M (FY2026 Revenue) | /input/repo/extracted/income_statement_annual.csv | TotalRevenue, 2026-01-31 column | yfinance |
| +37% (FY2024 Growth) | /input/repo/extracted/financial_summary.json | revenue array | Calculated from CSV |
| +31% (FY2025 Growth) | /input/repo/extracted/financial_summary.json | revenue array | Calculated from CSV |
| +26% (FY2026 Growth) | /input/repo/extracted/financial_summary.json | revenue array | Calculated from CSV |
| -49.8% (FY2023 Op Margin) | /input/repo/extracted/income_statement_annual.csv | Operating Income / Revenue | Calculated |
| -32.3% (FY2024 Op Margin) | /input/repo/extracted/income_statement_annual.csv | Operating Income / Revenue | Calculated |
| -18.8% (FY2025 Op Margin) | /input/repo/extracted/income_statement_annual.csv | Operating Income / Revenue | Calculated |
| -7.4% (FY2026 Op Margin) | /input/repo/extracted/income_statement_annual.csv | Operating Income / Revenue | Calculated |
| $222M (FY2026 FCF) | /input/repo/extracted/cash_flow_annual.csv | Free Cash Flow, 2026-01-31 | yfinance |
| $33M (FY2024 FCF) | /input/repo/extracted/cash_flow_annual.csv | Free Cash Flow, 2024-01-31 | yfinance |
| $860M (FY2026 ARR) | /input/repo/extracted/financial_summary.json | arr array, index 4 | From earnings transcripts |
| 115% (FY2026 NRR) | /input/repo/extracted/financial_summary.json | nrr array, index 4 | From earnings transcripts |

## Competitive Position Slide (Slide 6)

| Number | Source File | Location | Notes |
|--------|------------|----------|-------|
| 2.56x (GitLab EV/Rev) | /input/repo/extracted/competitor_data.json | GTLB.ev_revenue | yfinance |
| 3.22x (Atlassian EV/Rev) | /input/repo/extracted/competitor_data.json | TEAM.ev_revenue | yfinance |
| 12.39x (Datadog EV/Rev) | /input/repo/extracted/competitor_data.json | DDOG.ev_revenue | yfinance |
| 7.33x (MongoDB EV/Rev) | /input/repo/extracted/competitor_data.json | MDB.ev_revenue | yfinance |
| 8.69x (Confluent EV/Rev) | /input/repo/extracted/competitor_data.json | CFLT.ev_revenue | yfinance |
| 10.07x (Snowflake EV/Rev) | /input/repo/extracted/competitor_data.json | SNOW.ev_revenue | yfinance |
| 6.71x (Zscaler EV/Rev) | /input/repo/extracted/competitor_data.json | ZS.ev_revenue | yfinance |
| 3.88x (Okta EV/Rev) | /input/repo/extracted/competitor_data.json | OKTA.ev_revenue | yfinance |
| 2.14x (Bill.com EV/Rev) | /input/repo/extracted/competitor_data.json | BILL.ev_revenue | yfinance |
| 7.03x (Peer Avg EV/Rev) | /input/repo/memo/gitlab_investment_memo.md | Valuation section | Calculated in memo |
| 23.2% (GitLab Growth) | /input/repo/extracted/competitor_data.json | GTLB.revenue_growth | yfinance |
| -1.0% (GitLab Op Margin) | /input/repo/extracted/competitor_data.json | GTLB.operating_margin | yfinance |

## Scenario Analysis Slide (Slide 9)

| Number | Source File | Location | Notes |
|--------|------------|----------|-------|
| $18.58 (Bear Price) | /input/repo/memo/gitlab_investment_memo.md | Scenario table | DCF bear case |
| 25% (Bear Probability) | /input/repo/memo/gitlab_investment_memo.md | Scenario table | Assumed |
| $38.52 (Base Price) | /input/repo/memo/gitlab_investment_memo.md | Scenario table | DCF base case |
| 50% (Base Probability) | /input/repo/memo/gitlab_investment_memo.md | Scenario table | Assumed |
| $88.30 (Bull Price) | /input/repo/memo/gitlab_investment_memo.md | Scenario table | DCF bull case |
| 25% (Bull Probability) | /input/repo/memo/gitlab_investment_memo.md | Scenario table | Assumed |
| $45.98 (Prob-Weighted) | /input/repo/memo/gitlab_investment_memo.md | Scenario table | 0.25×18.58 + 0.50×38.52 + 0.25×88.30 |
| 10.5% (Base WACC) | /input/repo/memo/gitlab_investment_memo.md | DCF section | CAPM: Rf=4.5%, Beta=1.2, ERP=5.5% |
| 3.0% (Terminal Growth) | /input/repo/memo/gitlab_investment_memo.md | DCF section | Assumed |

## Risk Assessment Slide (Slide 8)

| Number | Source File | Location | Notes |
|--------|------------|----------|-------|
| 120% (FY2022 NRR) | /input/repo/extracted/financial_summary.json | nrr array, index 0 | From earnings transcripts |
| 115% (FY2026 NRR) | /input/repo/extracted/financial_summary.json | nrr array, index 4 | From earnings transcripts |
| $1.26B (Cash & Investments) | /input/repo/extracted/company_info.json | totalCash field | yfinance |
| $0.2M (Total Debt) | /input/repo/extracted/balance_sheet_annual.csv | Total Debt, 2026-01-31 | yfinance |
| 170.1M (Shares Outstanding) | /input/repo/extracted/company_info.json | sharesOutstanding field | yfinance |

## Confidence & Limitations Slide (Slide 12)

| Number | Source File | Location | Notes |
|--------|------------|----------|-------|
| 87.4% (FY2026 Gross Margin) | /input/repo/extracted/income_statement_annual.csv | Gross Profit / Revenue | Calculated |
| 87.8% (FY2023 Gross Margin) | /input/repo/extracted/income_statement_annual.csv | Gross Profit / Revenue | Calculated |
| 89.7% (FY2024 Gross Margin) | /input/repo/extracted/income_statement_annual.csv | Gross Profit / Revenue | Calculated |
| 88.8% (FY2025 Gross Margin) | /input/repo/extracted/income_statement_annual.csv | Gross Profit / Revenue | Calculated |
| $572M (FY2026 Deferred Rev) | /input/repo/extracted/balance_sheet_annual.csv | Current Deferred Revenue, 2026-01-31 | yfinance |
| 2,580 (Employees) | /input/repo/extracted/company_info.json | fullTimeEmployees field | yfinance |
