# Trace: Slide 5 — Financial Trajectory

## Claim: Revenue figures (FY2023-FY2026)
- **Deck:** Slide 5, "Revenue & ARR Trajectory" chart
- **Source:** /input/repo/extracted/income_statement_annual.csv
- **Row:** `Total Revenue`
- **FY2023:** 424336000.0 → $424M
- **FY2024:** 579906000.0 → $580M
- **FY2025:** 759249000.0 → $759M
- **FY2026:** 955224000.0 → $955M

## Claim: ARR figures (FY2023-FY2026)
- **Deck:** Slide 5, "Revenue & ARR Trajectory" chart
- **Source:** /input/repo/extracted/financial_summary.json
- **Field:** `arr`
- **FY2023:** 400, FY2024: 530, FY2025: 680, FY2026: 860

## Claim: Operating margin figures (FY2023-FY2026)
- **Deck:** Slide 5, "Operating Margin & Free Cash Flow" chart
- **Source:** /input/repo/extracted/income_statement_annual.csv
- **Row:** `Operating Income` / `Total Revenue`
- **FY2023:** -211411000/424336000 = -49.8%
- **FY2024:** -187440000/579906000 = -32.3%
- **FY2025:** -142715000/759249000 = -18.8%
- **FY2026:** -70481000/955224000 = -7.4%

## Claim: FCF figures (FY2023-FY2026)
- **Deck:** Slide 5, "Operating Margin & Free Cash Flow" chart
- **Source:** /input/repo/extracted/cash_flow_annual.csv
- **Row:** `Free Cash Flow`
- **FY2023:** -83478000.0 → -$83M
- **FY2024:** 33442000.0 → $33M
- **FY2025:** -67736000.0 → -$68M
- **FY2026:** 222029000.0 → $222M

## Claim: NRR = 115% (FY2026)
- **Deck:** Slide 5, "NRR: 115% (FY2026)" annotation
- **Source:** /input/repo/extracted/financial_summary.json
- **Field:** `nrr`
- **FY2026:** 115

## Claim: Projected revenue (FY2027-FY2031)
- **Deck:** Slide 8, "Operating Margin Trajectory" chart
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "FCF Projections" table
- **FY2027E:** $1,146M, FY2028E: $1,352M, FY2029E: $1,555M, FY2030E: $1,742M, FY2031E: $1,916M

## Claim: Projected FCF (FY2027-FY2031)
- **Deck:** Slide 8, "Operating Margin Trajectory" chart
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "FCF Projections" table
- **FY2027E:** $230M, FY2028E: $298M, FY2029E: $373M, FY2030E: $436M, FY2031E: $498M

## Claim: Projected operating margins (FY2027-FY2031)
- **Deck:** Slide 8, "Operating Margin Trajectory" chart
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "FCF Projections" table (FCF Margin column)
- **FY2027E:** 20%, FY2028E: 22%, FY2029E: 24%, FY2030E: 25%, FY2031E: 26%
