# Trace: Slide 12 — Confidence & Limitations

## Claim: Revenue trajectory — high confidence
- **Deck:** Slide 12, "Confidence & Limitations" radar chart
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "Confidence and Limitations → What We're Confident About"
- **Context:** "Revenue trajectory: 5 years of consistent growth data provides strong basis for projections"

## Claim: Gross margins — high confidence
- **Deck:** Slide 12, "Confidence & Limitations" radar chart
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "Confidence and Limitations → What We're Confident About"
- **Context:** "Gross margins: Stable at 87-90%, well-documented across filings"
- **Source data:** /input/repo/extracted/income_statement_annual.csv
- **FY2023:** 87.8%, FY2024: 89.7%, FY2025: 88.8%, FY2026: 87.4%

## Claim: Balance sheet — high confidence
- **Deck:** Slide 12, "Confidence & Limitations" radar chart
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "Confidence and Limitations → What We're Confident About"
- **Context:** "Balance sheet: $1.26B in cash/investments with negligible debt is a fact, not an estimate"
- **Source data:** /input/repo/extracted/company_info.json, `totalCash` = 1259902976

## Claim: ARR/NRR — estimating (lower confidence)
- **Deck:** Slide 12, "Confidence & Limitations" radar chart
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "Confidence and Limitations → What We're Estimating"
- **Context:** "ARR and NRR: These are management metrics, not GAAP figures. Our estimates are derived from earnings call transcripts and may differ from official figures."
- **Source data:** /input/repo/extracted/financial_summary.json, `arr` and `nrr` fields

## Claim: AI monetization — estimating (lowest confidence)
- **Deck:** Slide 12, "Confidence & Limitations" radar chart
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "Confidence and Limitations → What We're Estimating"
- **Context:** "AI monetization: The revenue impact of AI features is uncertain and forward-looking."

## Claim: Competitive dynamics — estimating
- **Deck:** Slide 12, "Confidence & Limitations" radar chart
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "Confidence and Limitations → What We're Estimating"
- **Context:** "Competitive dynamics: The pace of GitHub/Atlassian AI feature development is unpredictable."

## Claim: Human analysts would do more
- **Deck:** Slide 12, "Confidence & Limitations" section
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "Confidence and Limitations → What a Human Analyst Would Do Differently"
- **Context:** Lists 5 items: full 10-K filings, earnings call participation, customer interviews, competitor product evaluation, management meetings
