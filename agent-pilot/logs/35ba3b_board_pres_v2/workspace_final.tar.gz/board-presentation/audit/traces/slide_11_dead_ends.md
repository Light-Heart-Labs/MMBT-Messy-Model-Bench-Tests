# Trace: Slide 11 — Dead Ends

## Claim: SEC filing downloads failed (403 errors)
- **Deck:** Slide 11, "SEC Filing Downloads"
- **Source:** /input/repo/research/dead-ends.md
- **Section:** "1. SEC Filing Downloads"
- **Context:** "Downloaded 10-K and 10-Q filings directly from sec.gov. Why it failed: SEC's website returns 403 (Forbidden) for all automated requests."

## Claim: GitLab IR website unreachable (DNS failure)
- **Deck:** Slide 11, "GitLab Investor Relations"
- **Source:** /input/repo/research/dead-ends.md
- **Section:** "2. GitLab Investor Relations Website"
- **Context:** "Accessed investors.gitlab.com for earnings presentations and transcripts. Why it failed: DNS resolution failed."

## Claim: PRNewswire search failed (404)
- **Deck:** Slide 11, "PRNewswire Press Releases"
- **Source:** /input/repo/research/dead-ends.md
- **Section:** "3. PRNewswire Press Releases"
- **Context:** "Searched PRNewswire for GitLab press releases. Why it failed: Search URL returned 404."

## Claim: Initial CIK lookup was wrong
- **Deck:** Slide 11, "Initial CIK Lookup"
- **Source:** /input/repo/research/dead-ends.md
- **Section:** "4. Initial CIK Lookup"
- **Context:** "Used CIK 0001687226 (found in some online sources) for GitLab. Why it failed: This CIK mapped to 'Harper James P' not GitLab Inc. Resolution: Found correct CIK 0001653482."

## Claim: Earnings call audio unavailable
- **Deck:** Slide 11, "Earnings Call Audio"
- **Source:** /input/repo/research/dead-ends.md
- **Section:** "5. Earnings Call Audio"
- **Context:** "Looked for audio recordings of earnings calls. Why it failed: No accessible audio sources found. Seeking Alpha has 'Play Call' buttons but these require JavaScript execution."
