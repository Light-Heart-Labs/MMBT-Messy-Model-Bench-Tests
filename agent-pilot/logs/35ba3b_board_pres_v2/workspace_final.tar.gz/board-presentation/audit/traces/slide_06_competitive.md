# Trace: Slide 6 — Competitive Position

## Claim: GitLab EV/Revenue = 2.56x
- **Deck:** Slide 6, "Competitive Landscape" scatter plot
- **Source:** /input/repo/extracted/competitor_data.json
- **Field:** `GTLB.ev_revenue`
- **Value:** 2.559

## Claim: Peer EV/Revenue multiples
- **Deck:** Slide 6, "Competitive Landscape" scatter plot
- **Source:** /input/repo/extracted/competitor_data.json
- **Atlassian (TEAM):** 3.215
- **Datadog (DDOG):** 12.388
- **MongoDB (MDB):** 7.329
- **Confluent (CFLT):** 8.686
- **Snowflake (SNOW):** 10.069
- **Zscaler (ZS):** 6.711
- **Okta (OKTA):** 3.884
- **Bill.com (BILL):** 2.143

## Claim: Peer average EV/Revenue = 7.03x
- **Deck:** Slide 6, "Competitive Landscape" annotation
- **Source:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** "Comparable Company Analysis"
- **Context:** "Using peer average EV/Revenue multiple of 7.03x"
- **Note:** The memo uses 8 peers; the extracted data has 10 peers. The deck uses the memo's figure.

## Claim: GitLab revenue growth = 23.2%
- **Deck:** Slide 6, "Competitive Landscape" scatter plot (x-axis)
- **Source:** /input/repo/extracted/competitor_data.json
- **Field:** `GTLB.revenue_growth`
- **Value:** 0.232

## Claim: GitLab operating margin = -1.0%
- **Deck:** Slide 6, "Competitive Landscape" scatter plot (y-axis)
- **Source:** /input/repo/extracted/competitor_data.json
- **Field:** `GTLB.operating_margin`
- **Value:** -0.01005

## Claim: Competitor selection rationale
- **Deck:** Slide 6, "Competitive Landscape"
- **Source:** /input/repo/decisions/002-competitor-selection.md
- **Context:** ADR-002 documents why these 8 competitors were chosen (SaaS business model, similar growth profiles, publicly traded)
