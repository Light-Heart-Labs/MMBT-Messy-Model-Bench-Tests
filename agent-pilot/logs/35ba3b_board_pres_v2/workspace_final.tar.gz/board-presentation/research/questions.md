# Research Questions — Deck Construction

## Q1: How to handle the SEC filing limitation in the audit?
**Issue:** The input repo couldn't download SEC filings (403 errors). All financial data comes from yfinance, which is a secondary source.
**Resolution:** Trace files will point to /input/repo/extracted/*.csv files. The audit/numbers.md will note that these are yfinance-derived. The reconciliation will acknowledge this limitation. This is honest and transparent.

## Q2: Should the deck use the memo's fiscal year labels or calendar years?
**Issue:** The memo uses "FY2023" through "FY2026" but GitLab's fiscal year ends January 31. FY2026 ended Jan 31, 2026.
**Resolution:** Use the memo's fiscal year labels for consistency. The board has read the memo and will recognize the labeling. Add a footnote clarifying that GitLab's fiscal year ends January 31.

## Q3: How to visualize the reasoning trail without overcomplicating?
**Issue:** The dependency graph needs to be clear at presentation size (projected on a screen).
**Resolution:** Use a simplified graph with 3 layers: Inputs → Analysis → Outputs. Use color coding to distinguish GitLab-specific nodes from general process nodes. Keep it to ~15 nodes max.

## Q4: What to do about the price history data gap (no data before Aug 2025)?
**Issue:** Historical prices only go back to Aug 2025, but the 52-week high is $54.08 (from all-time high of $137).
**Resolution:** Use the company_info.json data for the 52-week range ($18.73 - $54.08) and note that detailed daily data starts Aug 2025. The dramatic decline from ~$54 to ~$21 is the key story.

## Q5: How to handle the ARR/NRR figures that are management metrics, not GAAP?
**Issue:** ARR and NRR are disclosed by management in earnings calls, not in GAAP financial statements.
**Resolution:** Label them clearly as "Management Metrics" in all charts and tables. The trace files will point to the earnings call transcripts. The confidence section will note this as an estimation area.

## Q6: Should I include the analyst consensus data?
**Issue:** The input repo has analyst_recommendations.csv showing mean target ~$30.79.
**Resolution:** Yes — it provides a useful benchmark. Our $42.00 target is above consensus, which supports the mispricing thesis. Include on the recommendation slide.

## Q7: How many slides is too many?
**Issue:** The requirement says 15-25 slides. I want to be comprehensive but not overwhelming.
**Resolution:** Target 18 slides. This fits within the 30-minute window (about 1.5 min per slide) with room for Q&A.
