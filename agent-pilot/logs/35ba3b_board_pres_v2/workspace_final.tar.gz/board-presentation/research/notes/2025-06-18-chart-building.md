# Research Notes — Deck Construction Session 2
**Date:** 2025-06-18
**Topic:** Building chart scripts and data preparation

## Chart Scripts Created

1. **01_financial_trajectory.py** — Revenue, operating margin, FCF, ARR over time
   - Source: /input/repo/extracted/income_statement_annual.csv, /input/repo/extracted/financial_summary.json
   - Output: /assets/charts/01_financial_trajectory.png

2. **02_price_history.py** — GTLB stock price from Aug 2025 to Apr 2026
   - Source: /input/repo/extracted/historical_prices.csv
   - Output: /assets/charts/02_price_history.png

3. **03_competitive_scatter.py** — Growth vs. margin scatter plot
   - Source: /input/repo/extracted/competitor_data.json
   - Output: /assets/charts/03_competitive_scatter.png

4. **04_scenario_distribution.py** — Bear/base/bull probability distribution
   - Source: Memo scenario data (bear $18.58/25%, base $38.52/50%, bull $88.30/25%)
   - Output: /assets/charts/04_scenario_distribution.png

5. **05_risk_matrix.py** — Risk probability vs. impact matrix
   - Source: Memo risk assessment
   - Output: /assets/charts/05_risk_matrix.png

6. **06_confidence_radar.py** — Confidence/limitations radar chart
   - Source: Memo confidence section
   - Output: /assets/charts/06_confidence_radar.png

7. **07_ev_revenue_comparison.py** — EV/Revenue comparison (GitLab vs. peers)
   - Source: /input/repo/extracted/competitor_data.json
   - Output: /assets/charts/07_ev_revenue_comparison.png

8. **08_operating_margin_trend.py** — Operating margin improvement trajectory
   - Source: /input/repo/extracted/income_statement_annual.csv
   - Output: /assets/charts/08_operating_margin_trend.png

## Data Preparation Notes

- All chart scripts read directly from /input/repo/ files
- Scripts are self-contained and reproducible
- Each script outputs both a PNG and a CSV of the data used
- Color palette is consistent across all charts (see ADR-001)

## Issues Encountered

1. **yfinance data has NaN for FY2022** — the financial_summary.json has NaN for FY2022 revenue. I'll start charts from FY2023.

2. **Historical prices start at Aug 2025** — I don't have data before that. The 52-week high of $54.08 is from the company_info.json, so I'll note the data limitation.

3. **Competitor data has some null P/E ratios** — handled by skipping null values in the scatter plot.
