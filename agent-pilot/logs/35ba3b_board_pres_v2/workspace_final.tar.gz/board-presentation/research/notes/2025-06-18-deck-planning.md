# Research Notes — Deck Construction Session 1
**Date:** 2025-06-18
**Topic:** Reading input repo, planning deck structure

## Key Observations

1. **Input repo is well-structured** — the agent that produced it did good work. The decisions/, research/, and extracted/ directories are clean and traceable.

2. **Financial data is from yfinance, not direct SEC filings** — this is a limitation I need to surface in the deck. The trace files will point to extracted/*.csv files, which trace back to yfinance API.

3. **ARR and NRR are from earnings call transcripts** — these are management metrics, not GAAP. The memo acknowledges this. I need to preserve this nuance in the deck.

4. **The memo's fiscal year labeling is slightly off** — the memo says "FY2026" for data ending Jan 2026, but GitLab's FY2026 actually ended Jan 31, 2026. The yfinance data confirms this. I'll use the memo's labeling for consistency.

5. **Competitor data includes 11 companies** — the memo uses 8, but the extracted data has 11 (including GTLB itself). I'll use the same 8 as the memo for consistency.

6. **Historical prices show a dramatic decline** — from ~$54 in late 2025 to ~$21 in April 2026. This is a key part of the mispricing thesis. I'll include a price history chart.

## Questions to Resolve
- Q1: Should I use the memo's price target ($42.00) or the probability-weighted target ($45.98)?
  - A: Use $42.00 as the official target (it's the memo's stated target), but show $45.98 as the probability-weighted expected value.

- Q2: How to handle the SEC filing limitation?
  - A: Be transparent. The trace files will point to extracted/*.csv, and the audit will note that these are yfinance-derived, not direct SEC filings.

- Q3: Should I include the analyst consensus data?
  - A: Yes — it provides a useful benchmark. Mean target is ~$30.79, which is below our $42.00 target.

## Next Steps
- Build all chart scripts
- Create the PPTX deck
- Write trace files for every claim
- Build the audit materials
