# Dead Ends — Deck Construction

## 1. Monte Carlo Simulation for Scenario Analysis (Rejected)

**What I tried:** Build a Monte Carlo simulation with 10,000 iterations varying WACC, terminal growth, and revenue growth rates.

**Why it didn't make the cut:**
- The input repo's memo uses discrete scenarios (bear/base/bull), not a continuous distribution
- A Monte Carlo would require assumptions about the joint distribution of inputs that the memo doesn't provide
- The board has read the memo; introducing a new methodology would create confusion
- The discrete scenarios are sufficient for the deck's purpose

**What I used instead:** The memo's bear/base/bull scenarios with probability weighting.

## 2. Interactive HTML Deck (Rejected)

**What I tried:** Build an interactive HTML deck with Plotly charts that board members could explore.

**Why it didn't make the cut:**
- The requirement specifies a PPTX deck
- An HTML deck would be harder to distribute and present
- The PPTX is the deliverable; HTML would be a nice-to-have extra
- The chart scripts in /assets/charts/ serve the same purpose (reproducibility)

**What I used instead:** Static PPTX with PNG chart images, plus reproducible scripts.

## 3. Full SEC Filing Screenshots (Rejected)

**What I tried:** Include screenshots of SEC filing pages to show primary source data.

**Why it didn't make the cut:**
- SEC filings couldn't be downloaded (403 errors, documented in input repo's dead-ends.md)
- The yfinance data is a secondary source; screenshots of yfinance output would be less authoritative
- The trace files point to the extracted CSV files, which is the best available provenance

**What I used instead:** Trace files pointing to extracted CSV files, with clear documentation of the yfinance provenance.

## 4. Animated Slide Transitions (Rejected)

**What I tried:** Add animated transitions to reveal data step-by-step during the presentation.

**Why it didn't make the cut:**
- Animations can be distracting in a technical presentation
- They don't add analytical value
- The board is technical and wants to see the full picture, not a step-by-step reveal
- PPTX animations are fragile and can break across different systems

**What I used instead:** Clean, static slides with clear visual hierarchy.

## 5. Competitor Product Comparison Table (Rejected)

**What I tried:** Build a detailed feature comparison table (GitLab vs. GitHub vs. Atlassian).

**Why it didn't make the cut:**
- This is a product analysis, not an investment analysis
- The board cares about financial metrics and competitive positioning, not feature lists
- The input repo's memo focuses on financial comparables, not product features
- Would have required subjective judgments about feature value

**What I used instead:** Financial scatter plot showing growth vs. margin vs. valuation.

## 6. DCF Sensitivity Tornado Chart (Rejected)

**What I tried:** Build a tornado chart showing DCF sensitivity to each input variable.

**Why it didn't make the cut:**
- The memo already provides scenario analysis, which serves a similar purpose
- A tornado chart would require running the DCF model with each variable varied individually
- The memo's scenarios already capture the key sensitivities (WACC, terminal growth, revenue growth)
- Would have added complexity without adding insight

**What I used instead:** The memo's scenario analysis visualized as a probability distribution.
