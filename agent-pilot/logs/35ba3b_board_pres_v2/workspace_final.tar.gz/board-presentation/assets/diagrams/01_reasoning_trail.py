#!/usr/bin/env python3
"""
Chart 09: Reasoning Trail — Dependency Graph Visualization

Generates a node-link diagram showing how the agent moved from:
  Inputs (data sources) → Analysis (models, comparisons) → Decisions → Conclusion

Uses data from:
  - /input/repo/decisions/ (ADR files)
  - /input/repo/research/notes/ (session notes)
  - /input/repo/extracted/ (data files)
  - /input/repo/raw/transcripts/ (earnings calls)

Outputs:
  - /workspace/board-presentation/assets/diagrams/01_reasoning_trail.png
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import os

# Color palette
NAVY = '#0A1628'
BLUE = '#3498DB'
GREEN = '#2ECC71'
RED = '#E74C3C'
AMBER = '#F39C12'
GRAY = '#95A5A6'
WHITE = '#FFFFFF'
LIGHT_BLUE = '#5DADE2'
PURPLE = '#9B59B6'

# Create figure
fig, ax = plt.subplots(figsize=(16, 12))
fig.patch.set_facecolor(NAVY)

# Node positions (x, y)
nodes = {
    # Input layer (left)
    'income_stmt': (0.05, 0.85),
    'balance_sheet': (0.05, 0.70),
    'cash_flow': (0.05, 0.55),
    'transcripts': (0.05, 0.40),
    'competitors': (0.05, 0.25),
    'prices': (0.05, 0.10),
    
    # Analysis layer (middle)
    'financial_model': (0.25, 0.75),
    'arr_nrr_analysis': (0.25, 0.55),
    'peer_comparison': (0.25, 0.35),
    'price_analysis': (0.25, 0.15),
    
    # Decision layer (center)
    'company_selection': (0.45, 0.85),
    'valuation_method': (0.45, 0.65),
    'competitor_selection': (0.45, 0.45),
    'risk_assessment': (0.45, 0.25),
    
    # Output layer (right)
    'dcf_valuation': (0.65, 0.75),
    'scenario_analysis': (0.65, 0.55),
    'thesis': (0.65, 0.35),
    'recommendation': (0.85, 0.55),
}

# Node colors by layer
node_colors = {
    'income_stmt': BLUE, 'balance_sheet': BLUE, 'cash_flow': BLUE,
    'transcripts': BLUE, 'competitors': BLUE, 'prices': BLUE,
    'financial_model': LIGHT_BLUE, 'arr_nrr_analysis': LIGHT_BLUE,
    'peer_comparison': LIGHT_BLUE, 'price_analysis': LIGHT_BLUE,
    'company_selection': PURPLE, 'valuation_method': PURPLE,
    'competitor_selection': PURPLE, 'risk_assessment': PURPLE,
    'dcf_valuation': GREEN, 'scenario_analysis': GREEN,
    'thesis': AMBER, 'recommendation': RED,
}

# Node labels
node_labels = {
    'income_stmt': 'Income\nStatement',
    'balance_sheet': 'Balance\nSheet',
    'cash_flow': 'Cash Flow',
    'transcripts': 'Earnings\nTranscripts',
    'competitors': 'Competitor\nData',
    'prices': 'Historical\nPrices',
    'financial_model': 'Three-Statement\nModel',
    'arr_nrr_analysis': 'ARR/NRR\nAnalysis',
    'peer_comparison': 'Peer\nMultiples',
    'price_analysis': 'Price\nAction',
    'company_selection': 'Company\nSelection',
    'valuation_method': 'Valuation\nMethodology',
    'competitor_selection': 'Comp Set\nSelection',
    'risk_assessment': 'Risk\nAssessment',
    'dcf_valuation': 'DCF\nValuation',
    'scenario_analysis': 'Scenario\nAnalysis',
    'thesis': 'Investment\nThesis',
    'recommendation': 'BUY\n$42.00',
}

# Edges (from, to)
edges = [
    # Inputs → Analysis
    ('income_stmt', 'financial_model'),
    ('balance_sheet', 'financial_model'),
    ('cash_flow', 'financial_model'),
    ('transcripts', 'arr_nrr_analysis'),
    ('competitors', 'peer_comparison'),
    ('prices', 'price_analysis'),
    
    # Analysis → Decisions
    ('financial_model', 'dcf_valuation'),
    ('arr_nrr_analysis', 'thesis'),
    ('peer_comparison', 'scenario_analysis'),
    ('price_analysis', 'thesis'),
    
    # Decisions → Analysis (feedback)
    ('company_selection', 'financial_model'),
    ('valuation_method', 'dcf_valuation'),
    ('competitor_selection', 'peer_comparison'),
    ('risk_assessment', 'scenario_analysis'),
    
    # Decisions → Output
    ('dcf_valuation', 'recommendation'),
    ('scenario_analysis', 'recommendation'),
    ('thesis', 'recommendation'),
]

# Draw edges
for src, dst in edges:
    x1, y1 = nodes[src]
    x2, y2 = nodes[dst]
    ax.plot([x1, x2], [y1, y2], color=GRAY, linewidth=1.5, alpha=0.4, zorder=1)
    # Arrow
    dx, dy = x2 - x1, y2 - y1
    length = (dx**2 + dy**2)**0.5
    ux, uy = dx/length, dy/length
    ax.annotate('', xy=(x2 - ux*0.02, y2 - uy*0.02), 
                xytext=(x2 - ux*0.04, y2 - uy*0.04),
                arrowprops=dict(arrowstyle='->', color=GRAY, lw=1.5, alpha=0.4))

# Draw nodes
for name, (x, y) in nodes.items():
    color = node_colors[name]
    # Node box
    rect = mpatches.FancyBboxPatch((x - 0.04, y - 0.04), 0.08, 0.08,
                                    boxstyle="round,pad=0.01",
                                    facecolor=color, edgecolor=WHITE, 
                                    linewidth=1.5, alpha=0.8, zorder=2)
    ax.add_patch(rect)
    
    # Label
    ax.text(x, y, node_labels[name], ha='center', va='center',
            fontsize=7, color=WHITE, fontweight='bold', zorder=3,
            multialignment='center')

# Layer labels
ax.text(0.05, 0.97, 'INPUTS', ha='center', fontsize=12, color=BLUE, 
        fontweight='bold', alpha=0.7)
ax.text(0.25, 0.97, 'ANALYSIS', ha='center', fontsize=12, color=LIGHT_BLUE, 
        fontweight='bold', alpha=0.7)
ax.text(0.45, 0.97, 'DECISIONS', ha='center', fontsize=12, color=PURPLE, 
        fontweight='bold', alpha=0.7)
ax.text(0.65, 0.97, 'VALUATION', ha='center', fontsize=12, color=GREEN, 
        fontweight='bold', alpha=0.7)
ax.text(0.85, 0.97, 'OUTPUT', ha='center', fontsize=12, color=RED, 
        fontweight='bold', alpha=0.7)

# Title
ax.set_title('GitLab (GTLB): Agent Reasoning Trail\n'
             'From Data Sources → Analysis → Decisions → Recommendation',
             color=WHITE, fontsize=16, fontweight='bold', pad=20)

ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis('off')

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/diagrams/01_reasoning_trail.png', 
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

print("Diagram 01 generated successfully.")
print(f"Nodes: {len(nodes)}, Edges: {len(edges)}")
print("Layers: Inputs → Analysis → Decisions → Valuation → Output")
