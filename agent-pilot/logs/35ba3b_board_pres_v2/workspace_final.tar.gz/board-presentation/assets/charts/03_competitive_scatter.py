#!/usr/bin/env python3
"""
Chart 03: Competitive Landscape — Growth vs. Margin Scatter Plot

Reads from:
  - /input/repo/extracted/competitor_data.json

Outputs:
  - /workspace/board-presentation/assets/charts/03_competitive_scatter.png
  - /workspace/board-presentation/assets/tables/03_competitive_scatter.csv
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
import os

# Color palette
NAVY = '#0A1628'
BLUE = '#3498DB'
GITLAB_ORANGE = '#E24329'
GRAY = '#95A5A6'
WHITE = '#FFFFFF'
LIGHT_GRAY = '#BDC3C7'

# Read competitor data
with open('/input/repo/extracted/competitor_data.json') as f:
    competitors = json.load(f)

# Build data
data = []
for ticker, info in competitors.items():
    if ticker == 'GTLB':
        continue  # Will add separately
    data.append({
        'ticker': ticker,
        'name': info['name'],
        'revenue_growth': info['revenue_growth'] * 100,
        'operating_margin': info['operating_margin'] * 100,
        'market_cap_b': info['market_cap_b'],
        'ev_revenue': info['ev_revenue'],
        'sector': info['sector']
    })

df = pd.DataFrame(data)

# GitLab data
gtlb = competitors['GTLB']
gtlb_data = {
    'ticker': 'GTLB',
    'name': 'GitLab',
    'revenue_growth': gtlb['revenue_growth'] * 100,
    'operating_margin': gtlb['operating_margin'] * 100,
    'market_cap_b': gtlb['market_cap_b'],
    'ev_revenue': gtlb['ev_revenue'],
    'sector': gtlb['sector']
}

# Create figure
fig, ax = plt.subplots(figsize=(14, 9))
fig.patch.set_facecolor(NAVY)

# Bubble size proportional to market cap (scaled)
sizes = [d['market_cap_b'] * 80 for d in data]

# Plot peers
scatter = ax.scatter(df['revenue_growth'], df['operating_margin'], 
                     s=sizes, c=GRAY, alpha=0.4, edgecolors=LIGHT_GRAY, 
                     linewidth=0.5, zorder=1)

# Label peers
for _, row in df.iterrows():
    ax.annotate(row['ticker'], 
                xy=(row['revenue_growth'], row['operating_margin']),
                xytext=(5, 5), textcoords='offset points',
                fontsize=9, color=LIGHT_GRAY, fontweight='bold',
                zorder=3)

# Plot GitLab prominently
gtlb_size = gtlb_data['market_cap_b'] * 80
ax.scatter([gtlb_data['revenue_growth']], [gtlb_data['operating_margin']], 
           s=gtlb_size, c=GITLAB_ORANGE, alpha=0.9, edgecolors=WHITE, 
           linewidth=2, zorder=4, label='GitLab (GTLB)')

ax.annotate('GitLab', 
            xy=(gtlb_data['revenue_growth'], gtlb_data['operating_margin']),
            xytext=(10, 10), textcoords='offset points',
            fontsize=12, color=GITLAB_ORANGE, fontweight='bold', zorder=5,
            bbox=dict(boxstyle='round,pad=0.3', facecolor=NAVY, edgecolor=GITLAB_ORANGE, alpha=0.9))

# Reference lines
ax.axhline(y=0, color=WHITE, linestyle='-', alpha=0.2, linewidth=0.5)
ax.axvline(x=20, color=WHITE, linestyle='--', alpha=0.3, linewidth=0.8, label='20% Growth')

# Title and labels
ax.set_title('Competitive Landscape: Revenue Growth vs. Operating Margin\n'
             'Bubble Size = Market Cap (B) | GitLab at 2.6x EV/Revenue vs. Peer Avg 7.0x',
             color=WHITE, fontsize=14, fontweight='bold', pad=20)
ax.set_xlabel('Revenue Growth Rate (%)', color=WHITE, fontsize=12)
ax.set_ylabel('Operating Margin (%)', color=WHITE, fontsize=12)
ax.tick_params(axis='x', colors=WHITE)
ax.tick_params(axis='y', colors=WHITE)
ax.set_facecolor(NAVY)
ax.legend(loc='upper right', facecolor=NAVY, edgecolor=GRAY, 
          labelcolor=WHITE, fontsize=10)
ax.grid(alpha=0.15, color=GRAY, linestyle='-')

# Add EV/Revenue annotation for GitLab
ax.text(0.02, 0.02, f'GitLab EV/Revenue: {gtlb_data["ev_revenue"]:.1f}x\n'
                    f'Peer Average EV/Revenue: 7.0x',
        transform=ax.transAxes, fontsize=10, color=WHITE,
        bbox=dict(boxstyle='round,pad=0.4', facecolor=NAVY, edgecolor=GITLAB_ORANGE, alpha=0.9))

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/03_competitive_scatter.png', 
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

# Save CSV
df_out = df.copy()
df_out['market_cap_b'] = df_out['market_cap_b'].round(2)
df_out['ev_revenue'] = df_out['ev_revenue'].round(2)
df_out.to_csv('/workspace/board-presentation/assets/tables/03_competitive_scatter.csv', index=False)

# Add GitLab row
gtlb_df = pd.DataFrame([gtlb_data])
gtlb_df['market_cap_b'] = gtlb_df['market_cap_b'].round(2)
gtlb_df['ev_revenue'] = gtlb_df['ev_revenue'].round(2)
pd.concat([df_out, gtlb_df], ignore_index=True).to_csv(
    '/workspace/board-presentation/assets/tables/03_competitive_scatter.csv', index=False)

print("Chart 03 generated successfully.")
print(f"Peers plotted: {len(df)}, GitLab highlighted")
print(f"GitLab: {gtlb_data['revenue_growth']:.1f}% growth, {gtlb_data['operating_margin']:.1f}% margin")
