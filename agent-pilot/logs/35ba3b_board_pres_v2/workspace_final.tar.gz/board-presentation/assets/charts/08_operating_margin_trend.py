#!/usr/bin/env python3
"""
Chart 08: Operating Margin Improvement Trajectory — Historical and Projected

Reads from:
  - /input/repo/extracted/income_statement_annual.csv

Outputs:
  - /workspace/board-presentation/assets/charts/08_operating_margin_trend.png
  - /workspace/board-presentation/assets/tables/08_operating_margin_trend.csv
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
import os

# Color palette
NAVY = '#0A1628'
RED = '#E74C3C'
GREEN = '#2ECC71'
BLUE = '#3498DB'
GRAY = '#95A5A6'
WHITE = '#FFFFFF'
AMBER = '#F39C12'

# Read income statement
income = pd.read_csv('/input/repo/extracted/income_statement_annual.csv', index_col=0)

# Read financial summary
with open('/input/repo/extracted/financial_summary.json') as f:
    summary = json.load(f)

revenue = summary['revenue']
op_income = summary['op_income']
fy_labels = summary['fy_labels']

# Calculate operating margins
op_margins = [(op / rev * 100) if (op and rev and rev != 0) else None 
              for op, rev in zip(op_income, revenue)]

# Historical data (FY2023-FY2026)
start_idx = 1
years_hist = fy_labels[start_idx:]
margins_hist = [m for m in op_margins[start_idx:] if m is not None]
rev_hist = [r for r in revenue[start_idx:] if r is not None and not pd.isna(r)]

# Projected data (FY2027-FY2031) from memo
years_proj = ['FY2027E', 'FY2028E', 'FY2029E', 'FY2030E', 'FY2031E']
# From memo: margins improve from -7% (FY2026) to +5% (FY2029) to +12% (FY2031)
margins_proj = [-2.0, 2.0, 5.0, 8.0, 12.0]
rev_proj = [1146, 1352, 1555, 1742, 1916]  # From memo

# Create figure
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 10), 
                                gridspec_kw={'height_ratios': [3, 1]})
fig.patch.set_facecolor(NAVY)

# Top: Operating margin trajectory
x_hist = range(len(years_hist))
x_proj = [len(years_hist) + i for i in range(len(years_proj))]

# Historical line
ax1.plot(x_hist, margins_hist, 'o-', color=RED, linewidth=3, markersize=10, 
         label='Historical', zorder=3)
for i, (y, m) in enumerate(zip(years_hist, margins_hist)):
    ax1.annotate(f'{m:.1f}%', xy=(x_hist[i], margins_hist[i]),
                 xytext=(0, 15), textcoords='offset points',
                 ha='center', fontsize=10, color=RED, fontweight='bold')

# Projected line
ax1.plot(x_proj, margins_proj, 's--', color=GREEN, linewidth=2.5, markersize=8, 
         label='Projected', zorder=3, alpha=0.8)
for i, (y, m) in enumerate(zip(years_proj, margins_proj)):
    ax1.annotate(f'{m:+.1f}%', xy=(x_proj[i], margins_proj[i]),
                 xytext=(0, 15), textcoords='offset points',
                 ha='center', fontsize=10, color=GREEN, fontweight='bold')

# 0% reference line
ax1.axhline(y=0, color=WHITE, linestyle='-', alpha=0.3, linewidth=1.5)

# Shaded regions
ax1.axvspan(0, len(years_hist) - 0.5, alpha=0.1, color=GRAY, label='Historical Period')
ax1.axvspan(len(years_hist) - 0.5, len(years_hist) + len(years_proj) - 0.5, 
            alpha=0.05, color=GREEN, label='Projection Period')

# Vertical separator
ax1.axvline(x=len(years_hist) - 0.5, color=WHITE, linestyle=':', alpha=0.5, linewidth=1)

# X-axis labels
all_years = years_hist + years_proj
all_x = list(range(len(all_years)))
ax1.set_xticks(all_x)
ax1.set_xticklabels(all_years, color=WHITE, fontsize=10)

ax1.set_ylabel('Operating Margin (%)', color=WHITE, fontsize=12)
ax1.set_title('GitLab (GTLB): Operating Margin Trajectory\n'
              'Improving ~13pp/year: -50% (FY2023) → -7% (FY2026) → +12% (FY2031E)',
              color=WHITE, fontsize=14, fontweight='bold', pad=20)
ax1.tick_params(axis='y', colors=WHITE)
ax1.set_facecolor(NAVY)
ax1.legend(loc='upper left', facecolor=NAVY, edgecolor=GRAY, 
           labelcolor=WHITE, fontsize=10)
ax1.grid(axis='y', alpha=0.15, color=GRAY)

# Bottom: FCF trajectory
ax2_twin = ax2.twinx()

# FCF historical
fcf_hist = [f for f in summary['fcf'][start_idx:] if f is not None and not pd.isna(f)]
ax2.plot(x_hist, fcf_hist, 'o-', color=BLUE, linewidth=2.5, markersize=8, 
         label='FCF Historical ($M)', zorder=3)

# FCF projected (from memo: $230M, $298M, $373M, $436M, $498M)
fcf_proj = [230, 298, 373, 436, 498]
ax2.plot(x_proj, fcf_proj, 's--', color=GREEN, linewidth=2.5, markersize=8, 
         label='FCF Projected ($M)', zorder=3, alpha=0.8)

# 0% reference
ax2.axhline(y=0, color=WHITE, linestyle='-', alpha=0.3, linewidth=1.5)

# Value labels
for i, f in enumerate(fcf_hist):
    ax2.annotate(f'${f:.0f}M', xy=(x_hist[i], fcf_hist[i]),
                 xytext=(0, 10), textcoords='offset points',
                 ha='center', fontsize=9, color=BLUE, fontweight='bold')
for i, f in enumerate(fcf_proj):
    ax2.annotate(f'${f:.0f}M', xy=(x_proj[i], fcf_proj[i]),
                 xytext=(0, 10), textcoords='offset points',
                 ha='center', fontsize=9, color=GREEN, fontweight='bold')

ax2.set_ylabel('Free Cash Flow ($M)', color=BLUE, fontsize=11)
ax2_twin.set_ylabel('Revenue ($M)', color=AMBER, fontsize=11)
ax2_twin.plot(x_proj, rev_proj, '^-', color=AMBER, linewidth=1.5, markersize=6, 
              alpha=0.6, label='Revenue Projected ($M)')

ax2.set_xticks(all_x)
ax2.set_xticklabels(all_years, color=WHITE, fontsize=10)
ax2.set_title('Free Cash Flow & Revenue Projections', color=WHITE, fontsize=12, pad=10)
ax2.tick_params(axis='y', colors=BLUE)
ax2_twin.tick_params(axis='y', colors=AMBER)
ax2.set_facecolor(NAVY)
ax2_twin.set_facecolor(NAVY)

# Combined legend
lines1, labels1 = ax2.get_legend_handles_labels()
lines2, labels2 = ax2_twin.get_legend_handles_labels()
ax2.legend(lines1 + lines2, labels1 + labels2, loc='lower left', 
           facecolor=NAVY, edgecolor=GRAY, labelcolor=WHITE, fontsize=9)
ax2.grid(axis='y', alpha=0.15, color=GRAY)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/08_operating_margin_trend.png', 
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

# Save CSV
csv_data = pd.DataFrame({
    'Year': all_years,
    'Operating_Margin_Pct': margins_hist + margins_proj,
    'FCF_M': fcf_hist + fcf_proj,
    'Revenue_M': rev_hist + rev_proj
})
csv_data.to_csv('/workspace/board-presentation/assets/tables/08_operating_margin_trend.csv', index=False)

print("Chart 08 generated successfully.")
print(f"Historical margins: {[f'{m:.1f}%' for m in margins_hist]}")
print(f"Projected margins: {[f'{m:+.1f}%' for m in margins_proj]}")
