#!/usr/bin/env python3
"""
Chart 01: Financial Trajectory — Revenue, Operating Margin, FCF, ARR

Reads from:
  - /input/repo/extracted/income_statement_annual.csv (revenue, operating income)
  - /input/repo/extracted/financial_summary.json (ARR, NRR, FCF)

Outputs:
  - /workspace/board-presentation/assets/charts/01_financial_trajectory.png
  - /workspace/board-presentation/assets/tables/01_financial_trajectory.csv
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import json
import os

# Color palette (ADR-001)
NAVY = '#0A1628'
BLUE = '#3498DB'
GREEN = '#2ECC71'
RED = '#E74C3C'
AMBER = '#F39C12'
GRAY = '#95A5A6'
WHITE = '#FFFFFF'
LIGHT_BLUE = '#5DADE2'

# Read income statement
income = pd.read_csv('/input/repo/extracted/income_statement_annual.csv', index_col=0)

# Read financial summary
with open('/input/repo/extracted/financial_summary.json') as f:
    summary = json.load(f)

fy_labels = summary['fy_labels']  # FY2022-FY2026
revenue = summary['revenue']       # in $M
fcf = summary['fcf']               # in $M
arr = summary['arr']               # in $M
nrr = summary['nrr']               # %

# Calculate operating margin
op_income = summary['op_income']  # in $M
op_margins = [(op / rev * 100) if (op and rev and rev != 0) else None 
              for op, rev in zip(op_income, revenue)]

# Filter to FY2023-FY2026 (skip FY2022 which has NaN revenue)
start_idx = 1  # Skip FY2022
years = fy_labels[start_idx:]
rev_data = [r for r in revenue[start_idx:] if r is not None and not pd.isna(r)]
op_margin_data = [m for m in op_margins[start_idx:] if m is not None]
fcf_data = [f for f in fcf[start_idx:] if f is not None and not pd.isna(f)]
arr_data = [a for a in arr[start_idx:] if a is not None]
nrr_data = [n for n in nrr[start_idx:] if n is not None]

# Create figure
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 10), gridspec_kw={'height_ratios': [3, 1]})
fig.patch.set_facecolor(NAVY)

# Top chart: Revenue and ARR
bars1 = ax1.bar([f'FY{y.split("FY")[1]}' for y in years], rev_data, 
                width=0.35, label='Revenue ($M)', color=BLUE, alpha=0.8)
bars2 = ax1.bar([f'FY{y.split("FY")[1]}' for y in years], arr_data, 
                width=0.35, label='ARR ($M)', color=LIGHT_BLUE, alpha=0.6, 
                hatch='///', edgecolor=WHITE, linewidth=0.5)

ax1.set_ylabel('Revenue / ARR ($M)', color=WHITE, fontsize=12)
ax1.set_xlabel('Fiscal Year', color=WHITE, fontsize=12)
ax1.set_title('GitLab (GTLB): Revenue & ARR Trajectory (FY2023–FY2026)', 
              color=WHITE, fontsize=14, fontweight='bold', pad=20)
ax1.tick_params(axis='x', colors=WHITE)
ax1.tick_params(axis='y', colors=WHITE)
ax1.set_facecolor(NAVY)
ax1.legend(loc='upper left', facecolor=NAVY, edgecolor=GRAY, 
           labelcolor=WHITE, fontsize=10)
ax1.grid(axis='y', alpha=0.2, color=GRAY)

# Add value labels on bars
for bar in bars1:
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height + 15,
             f'${height:.0f}M', ha='center', va='bottom', 
             color=WHITE, fontsize=9, fontweight='bold')
for bar in bars2:
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height + 15,
             f'${height:.0f}M', ha='center', va='bottom', 
             color=LIGHT_BLUE, fontsize=9)

# Bottom chart: Operating Margin and FCF
ax2_twin = ax2.twinx()
line1 = ax2.plot([f'FY{y.split("FY")[1]}' for y in years], op_margin_data, 
                 'o-', color=RED, linewidth=2.5, markersize=8, label='Operating Margin (%)')
line2 = ax2_twin.plot([f'FY{y.split("FY")[1]}' for y in years], fcf_data, 
                      's-', color=GREEN, linewidth=2.5, markersize=8, label='Free Cash Flow ($M)')

ax2.set_ylabel('Operating Margin (%)', color=RED, fontsize=12)
ax2_twin.set_ylabel('Free Cash Flow ($M)', color=GREEN, fontsize=12)
ax2.set_xlabel('Fiscal Year', color=WHITE, fontsize=12)
ax2.set_title('Operating Margin & Free Cash Flow (FY2023–FY2026)', 
              color=WHITE, fontsize=12, pad=10)
ax2.tick_params(axis='x', colors=WHITE)
ax2.tick_params(axis='y', colors=RED)
ax2_twin.tick_params(axis='y', colors=GREEN)
ax2.set_facecolor(NAVY)
ax2_twin.set_facecolor(NAVY)

# Add 0% reference line
ax2.axhline(y=0, color=GRAY, linestyle='--', alpha=0.5, linewidth=1)

# Add value labels
for i, (m, f) in enumerate(zip(op_margin_data, fcf_data)):
    ax2.text(i, m + 2, f'{m:.1f}%', ha='center', color=RED, fontsize=9, fontweight='bold')
    ax2_twin.text(i, f + 10, f'${f:.0f}M', ha='center', color=GREEN, fontsize=9, fontweight='bold')

# Legend
lines1, labels1 = ax2.get_legend_handles_labels()
lines2, labels2 = ax2_twin.get_legend_handles_labels()
ax2.legend(lines1 + lines2, labels1 + labels2, loc='lower left', 
           facecolor=NAVY, edgecolor=GRAY, labelcolor=WHITE, fontsize=9)

# Add NRR annotation
ax2.text(0.98, 0.95, f'NRR: {nrr_data[-1]}% (FY2026)', 
         transform=ax2.transAxes, ha='right', va='top',
         color=AMBER, fontsize=10, fontweight='bold',
         bbox=dict(boxstyle='round,pad=0.3', facecolor=NAVY, edgecolor=AMBER, alpha=0.9))

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/01_financial_trajectory.png', 
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

# Save CSV
df = pd.DataFrame({
    'Year': years,
    'Revenue_M': rev_data,
    'ARR_M': arr_data,
    'Operating_Margin_Pct': op_margin_data,
    'FCF_M': fcf_data,
    'NRR_Pct': nrr_data
})
df.to_csv('/workspace/board-presentation/assets/tables/01_financial_trajectory.csv', index=False)

print("Chart 01 generated successfully.")
print(f"Data: {len(years)} years, Revenue range: ${min(rev_data):.0f}M - ${max(rev_data):.0f}M")
