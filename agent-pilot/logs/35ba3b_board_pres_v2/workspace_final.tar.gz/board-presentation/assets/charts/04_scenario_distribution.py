#!/usr/bin/env python3
import pandas as pd
"""
Chart 04: Bear/Base/Bull Scenario Distribution — Probability-Weighted

Uses scenario data from the memo:
  - Bear: $18.58 (25%)
  - Base: $38.52 (50%)
  - Bull: $88.30 (25%)
  - Probability-weighted: $45.98

Outputs:
  - /workspace/board-presentation/assets/charts/04_scenario_distribution.png
  - /workspace/board-presentation/assets/tables/04_scenario_distribution.csv
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os

# Color palette (ADR-001)
NAVY = '#0A1628'
BEAR_RED = '#E74C3C'
BASE_BLUE = '#3498DB'
BULL_GREEN = '#2ECC71'
GRAY = '#95A5A6'
WHITE = '#FFFFFF'
AMBER = '#F39C12'

# Scenario data from memo
scenarios = {
    'Bear': {'price': 18.58, 'probability': 0.25, 'color': BEAR_RED},
    'Base': {'price': 38.52, 'probability': 0.50, 'color': BASE_BLUE},
    'Bull': {'price': 88.30, 'probability': 0.25, 'color': BULL_GREEN},
}
weighted_target = 45.98
current_price = 21.51

# Create figure
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 10), 
                                gridspec_kw={'height_ratios': [3, 1]})
fig.patch.set_facecolor(NAVY)

# Top: Probability distribution (kernel density estimate)
np.random.seed(42)
# Generate samples from a mixture of three normal distributions
bear_samples = np.random.normal(scenarios['Bear']['price'], 5, 2500)
base_samples = np.random.normal(scenarios['Base']['price'], 8, 5000)
bull_samples = np.random.normal(scenarios['Bull']['price'], 15, 2500)

all_samples = np.concatenate([bear_samples, base_samples, bull_samples])

# KDE
from scipy.stats import gaussian_kde
kde = gaussian_kde(all_samples)
x_range = np.linspace(10, 100, 500)
y_density = kde(x_range)

# Normalize to probability
y_density = y_density / y_density.sum() * (x_range[1] - x_range[0])

# Plot
ax1.fill_between(x_range, y_density, alpha=0.3, color=BASE_BLUE)
ax1.plot(x_range, y_density, color=BASE_BLUE, linewidth=2)

# Shade regions
ax1.axvspan(0, 25, alpha=0.15, color=BEAR_RED, label='Bear (25%)')
ax1.axvspan(25, 60, alpha=0.15, color=BASE_BLUE, label='Base (50%)')
ax1.axvspan(60, 100, alpha=0.15, color=BULL_GREEN, label='Bull (25%)')

# Scenario markers
for name, s in scenarios.items():
    ax1.axvline(x=s['price'], color=s['color'], linestyle='--', linewidth=2, alpha=0.8)
    ax1.annotate(f"{name}\n${s['price']:.2f}", 
                 xy=(s['price'], 0),
                 xytext=(s['price'], max(y_density) * 0.8),
                 ha='center', va='bottom',
                 fontsize=11, fontweight='bold', color=s['color'],
                 arrowprops=dict(arrowstyle='->', color=s['color'], lw=1.5),
                 bbox=dict(boxstyle='round,pad=0.3', facecolor=NAVY, edgecolor=s['color'], alpha=0.9))

# Current price line
ax1.axvline(x=current_price, color=WHITE, linestyle='-', linewidth=2, alpha=0.7, 
            label=f'Current Price: ${current_price:.2f}')

# Weighted target
ax1.axvline(x=weighted_target, color=AMBER, linestyle='-.', linewidth=2.5, alpha=0.9,
            label=f'Prob.-Weighted: ${weighted_target:.2f}')

ax1.set_xlabel('Price per Share ($)', color=WHITE, fontsize=12)
ax1.set_ylabel('Probability Density', color=WHITE, fontsize=12)
ax1.set_title('GitLab (GTLB): Probability-Weighted Price Distribution\n'
              'Bear ($18.58, 25%) | Base ($38.52, 50%) | Bull ($88.30, 25%)',
              color=WHITE, fontsize=14, fontweight='bold', pad=20)
ax1.tick_params(axis='x', colors=WHITE)
ax1.tick_params(axis='y', colors=WHITE)
ax1.set_facecolor(NAVY)
ax1.legend(loc='upper right', facecolor=NAVY, edgecolor=GRAY, 
           labelcolor=WHITE, fontsize=9)
ax1.grid(axis='y', alpha=0.15, color=GRAY)

# Bottom: Upside/Downside bar chart
upside_bear = (scenarios['Bear']['price'] - current_price) / current_price * 100
upside_base = (scenarios['Base']['price'] - current_price) / current_price * 100
upside_bull = (scenarios['Bull']['price'] - current_price) / current_price * 100
upside_weighted = (weighted_target - current_price) / current_price * 100

labels = ['Bear\n(25%)', 'Base\n(50%)', 'Bull\n(25%)', 'Prob.-Wtd.\n(100%)']
values = [upside_bear, upside_base, upside_bull, upside_weighted]
colors = [BEAR_RED, BASE_BLUE, BULL_GREEN, AMBER]

bars = ax2.bar(labels, values, color=colors, alpha=0.8, edgecolor=WHITE, linewidth=1)
ax2.axhline(y=0, color=WHITE, linestyle='-', alpha=0.3, linewidth=1)

# Add value labels
for bar, val in zip(bars, values):
    color = 'white' if val > 0 else 'white'
    ax2.text(bar.get_x() + bar.get_width()/2., bar.get_height() + (3 if val > 0 else -5),
             f'{val:+.0f}%', ha='center', va='bottom' if val > 0 else 'top',
             color=color, fontsize=12, fontweight='bold')

ax2.set_ylabel('Upside/Downside from Current ($21.51)', color=WHITE, fontsize=11)
ax2.set_title('Scenario Outcomes vs. Current Price', color=WHITE, fontsize=12, pad=10)
ax2.tick_params(axis='x', colors=WHITE)
ax2.tick_params(axis='y', colors=WHITE)
ax2.set_facecolor(NAVY)
ax2.grid(axis='y', alpha=0.15, color=GRAY)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/04_scenario_distribution.png', 
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

# Save CSV
csv_data = pd.DataFrame({
    'Scenario': ['Bear', 'Base', 'Bull', 'Prob-Weighted'],
    'Price': [18.58, 38.52, 88.30, 45.98],
    'Probability': [0.25, 0.50, 0.25, 1.00],
    'Upside_Downside_Pct': [upside_bear, upside_base, upside_bull, upside_weighted]
})
csv_data.to_csv('/workspace/board-presentation/assets/tables/04_scenario_distribution.csv', index=False)

print("Chart 04 generated successfully.")
print(f"Scenarios: Bear ${scenarios['Bear']['price']:.2f} ({upside_bear:+.0f}%), "
      f"Base ${scenarios['Base']['price']:.2f} ({upside_base:+.0f}%), "
      f"Bull ${scenarios['Bull']['price']:.2f} ({upside_bull:+.0f}%)")
print(f"Probability-weighted: ${weighted_target:.2f} ({upside_weighted:+.0f}%)")
