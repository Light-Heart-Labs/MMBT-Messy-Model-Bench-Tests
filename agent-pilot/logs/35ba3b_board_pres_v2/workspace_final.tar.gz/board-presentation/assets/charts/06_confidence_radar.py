#!/usr/bin/env python3
"""
Chart 06: Confidence & Limitations — Radar Chart

Uses confidence data from the memo:
  - High confidence: Revenue trajectory, Gross margins, Balance sheet, SaaS model quality
  - Estimating: ARR/NRR, AI monetization, Competitive dynamics
  - Human-only: SEC filings, Customer interviews, Management meetings

Outputs:
  - /workspace/board-presentation/assets/charts/06_confidence_radar.png
  - /workspace/board-presentation/assets/tables/06_confidence_radar.csv
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os

# Color palette
NAVY = '#0A1628'
GREEN = '#2ECC71'
AMBER = '#F39C12'
RED = '#E74C3C'
GRAY = '#95A5A6'
WHITE = '#FFFFFF'
BLUE = '#3498DB'

# Confidence categories and scores (0-100)
categories = [
    'Revenue\nTrajectory',
    'Gross\nMargins',
    'Balance\nSheet',
    'SaaS Model\nQuality',
    'ARR/NRR\nFigures',
    'AI\nMonetization',
    'Competitive\nDynamics',
]

# Confidence scores
confidence = [90, 85, 95, 80, 60, 45, 50]
# Limitation scores (inverse of confidence)
limitations = [10, 15, 5, 20, 40, 55, 50]

# Create radar chart
fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(polar=True))
fig.patch.set_facecolor(NAVY)

N = len(categories)
angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
angles += angles[:1]

# Confidence values
conf_values = confidence + [confidence[0]]
lim_values = limitations + [limitations[0]]

# Plot confidence
ax.plot(angles, conf_values, 'o-', color=GREEN, linewidth=2.5, markersize=8, label='Confidence')
ax.fill(angles, conf_values, alpha=0.15, color=GREEN)

# Plot limitations
ax.plot(angles, lim_values, 'o-', color=RED, linewidth=2.5, markersize=8, label='Limitation')
ax.fill(angles, lim_values, alpha=0.15, color=RED)

# Labels
ax.set_xticks(angles[:-1])
ax.set_xticklabels(categories, color=WHITE, fontsize=10, fontweight='bold')
ax.set_ylim(0, 100)
ax.set_yticks([25, 50, 75, 100])
ax.set_yticklabels(['25', '50', '75', '100'], color=GRAY, fontsize=9)
ax.tick_params(axis='y', colors=GRAY)

# Grid
ax.grid(alpha=0.2, color=GRAY)

# Title
ax.set_title('GitLab (GTLB): Confidence vs. Limitation by Category\n'
             'Higher = More Confident (green) / More Limited (red)',
             color=WHITE, fontsize=13, fontweight='bold', pad=20)

# Legend
ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), 
          facecolor=NAVY, edgecolor=GRAY, labelcolor=WHITE, fontsize=10)

# Add score annotations
for i, (c, l) in enumerate(zip(confidence, limitations)):
    angle = angles[i]
    ax.annotate(f'{c}/{l}', 
                xy=(angle, c),
                xytext=(angle, c + 5),
                fontsize=8, color=WHITE, ha='center', fontweight='bold')

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/06_confidence_radar.png', 
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

# Save CSV
import pandas as pd
csv_data = pd.DataFrame({
    'Category': categories,
    'Confidence_Score': confidence,
    'Limitation_Score': limitations
})
csv_data.to_csv('/workspace/board-presentation/assets/tables/06_confidence_radar.csv', index=False)

print("Chart 06 generated successfully.")
for cat, conf, lim in zip(categories, confidence, limitations):
    print(f"  {cat}: Confidence={conf}/100, Limitation={lim}/100")
