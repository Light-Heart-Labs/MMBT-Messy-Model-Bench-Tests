#!/usr/bin/env python3
"""
Chart 02: Stock Price History — GTLB

Reads from:
  - /input/repo/extracted/historical_prices.csv

Outputs:
  - /workspace/board-presentation/assets/charts/02_price_history.png
  - /workspace/board-presentation/assets/tables/02_price_history.csv
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os

# Color palette
NAVY = '#0A1628'
BLUE = '#3498DB'
RED = '#E74C3C'
GREEN = '#2ECC71'
GRAY = '#95A5A6'
WHITE = '#FFFFFF'
AMBER = '#F39C12'

# Read historical prices (has header row)
prices = pd.read_csv('/input/repo/extracted/historical_prices.csv')
prices['date'] = pd.to_datetime(prices['Date'], utc=True)

# Get company info for reference levels
import json
with open('/input/repo/extracted/company_info.json') as f:
    info = json.load(f)

current_price = info['currentPrice']  # $21.51
high_52w = info['fiftyTwoWeekHigh']   # $54.08
low_52w = info['fiftyTwoWeekLow']     # $18.73
all_time_high = info['allTimeHigh']   # $137.00

# Create figure
fig, ax = plt.subplots(figsize=(14, 7))
fig.patch.set_facecolor(NAVY)

# Plot closing price
ax.plot(prices['date'], prices['Close'], color=BLUE, linewidth=1.5, label='Close Price')

# Fill area under the curve
ax.fill_between(prices['date'], prices['Close'], alpha=0.15, color=BLUE)

# Reference lines
ax.axhline(y=current_price, color=GREEN, linestyle='--', alpha=0.7, linewidth=1.5, 
           label=f'Current Price: ${current_price:.2f}')
ax.axhline(y=high_52w, color=RED, linestyle='--', alpha=0.5, linewidth=1, 
           label=f'52W High: ${high_52w:.2f}')
ax.axhline(y=low_52w, color=AMBER, linestyle='--', alpha=0.5, linewidth=1, 
           label=f'52W Low: ${low_52w:.2f}')

# Mark the peak in the data
peak_idx = prices['Close'].idxmax()
peak_date = prices.loc[peak_idx, 'date']
peak_price = prices.loc[peak_idx, 'Close']
ax.annotate(f'Peak: ${peak_price:.2f}\n{peak_date.strftime("%b %Y")}',
            xy=(peak_date, peak_price),
            xytext=(peak_date, peak_price + 3),
            fontsize=9, color=RED, fontweight='bold',
            arrowprops=dict(arrowstyle='->', color=RED, lw=1.5),
            ha='center',
            bbox=dict(boxstyle='round,pad=0.3', facecolor=NAVY, edgecolor=RED, alpha=0.9))

# Mark the current price area
last_date = prices['date'].iloc[-1]
last_price = prices['Close'].iloc[-1]
ax.annotate(f'Latest: ${last_price:.2f}\n{last_date.strftime("%b %Y")}',
            xy=(last_date, last_price),
            xytext=(last_date - pd.Timedelta(days=60), last_price + 3),
            fontsize=9, color=GREEN, fontweight='bold',
            arrowprops=dict(arrowstyle='->', color=GREEN, lw=1.5),
            ha='right',
            bbox=dict(boxstyle='round,pad=0.3', facecolor=NAVY, edgecolor=GREEN, alpha=0.9))

# Calculate decline
decline_pct = ((last_price - peak_price) / peak_price) * 100
ax.text(0.02, 0.95, f'Decline from peak: {decline_pct:.1f}%',
        transform=ax.transAxes, fontsize=11, color=RED, fontweight='bold',
        bbox=dict(boxstyle='round,pad=0.4', facecolor=NAVY, edgecolor=RED, alpha=0.9))

ax.set_title('GitLab (GTLB) Stock Price: Historical\n'
             f'52-Week Range: ${low_52w:.2f} – ${high_52w:.2f} | All-Time High: ${all_time_high:.2f}',
             color=WHITE, fontsize=13, fontweight='bold', pad=15)
ax.set_xlabel('Date', color=WHITE, fontsize=11)
ax.set_ylabel('Price ($)', color=WHITE, fontsize=11)
ax.tick_params(axis='x', colors=WHITE, labelrotation=45)
ax.tick_params(axis='y', colors=WHITE)
ax.set_facecolor(NAVY)
ax.legend(loc='upper left', facecolor=NAVY, edgecolor=GRAY, 
          labelcolor=WHITE, fontsize=9)
ax.grid(axis='y', alpha=0.15, color=GRAY)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/02_price_history.png', 
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

# Save CSV
prices[['date', 'Close', 'Volume']].to_csv('/workspace/board-presentation/assets/tables/02_price_history.csv', 
                                            index=False)

print("Chart 02 generated successfully.")
print(f"Data: {len(prices)} trading days, Peak: ${peak_price:.2f}, Latest: ${last_price:.2f}")
print(f"Decline from peak: {decline_pct:.1f}%")
