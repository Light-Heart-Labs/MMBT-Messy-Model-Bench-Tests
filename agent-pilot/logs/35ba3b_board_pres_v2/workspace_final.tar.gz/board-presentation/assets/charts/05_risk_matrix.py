#!/usr/bin/env python3
"""
Chart 05: Risk Assessment — Probability vs. Impact Matrix

Uses risk data from the memo:
  - High Prob / High Impact: NRR decline, GitHub competition
  - Medium Prob / High Impact: Macro downturn, AI monetization failure
  - Low Prob / High Impact: Open-source cannibalization, Key person risk

Outputs:
  - /workspace/board-presentation/assets/charts/05_risk_matrix.png
  - /workspace/board-presentation/assets/tables/05_risk_matrix.csv
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os

# Color palette
NAVY = '#0A1628'
RED = '#E74C3C'
AMBER = '#F39C12'
BLUE = '#3498DB'
GRAY = '#95A5A6'
WHITE = '#FFFFFF'

# Risk data: (name, probability, impact, description)
risks = [
    ('NRR Decline', 0.7, 0.9, 'NRR falls below 110%'),
    ('GitHub Competition', 0.6, 0.8, 'Copilot expands to full DevOps'),
    ('Macro Downturn', 0.4, 0.8, 'Enterprise software spending cuts'),
    ('AI Monetization Failure', 0.4, 0.7, 'AI features don\'t drive upsells'),
    ('Open-Source Cannibalization', 0.2, 0.6, 'Free version competes with paid'),
    ('Key Person Risk', 0.15, 0.5, 'Loss of Sid Sijbrandij'),
]

# Create figure
fig, ax = plt.subplots(figsize=(12, 8))
fig.patch.set_facecolor(NAVY)

# Define risk zones
ax.axhspan(0.67, 1.0, alpha=0.1, color=RED, label='High Impact')
ax.axhspan(0.33, 0.67, alpha=0.1, color=AMBER, label='Medium Impact')
ax.axhspan(0.0, 0.33, alpha=0.1, color=BLUE, label='Low Impact')

ax.axvspan(0.67, 1.0, alpha=0.05, color=RED)
ax.axvspan(0.33, 0.67, alpha=0.05, color=AMBER)
ax.axvspan(0.0, 0.33, alpha=0.05, color=BLUE)

# Plot risks
for i, (name, prob, impact, desc) in enumerate(risks):
    # Size based on impact
    size = impact * 800 + 200
    # Color based on combined score
    score = prob * impact
    if score > 0.5:
        color = RED
    elif score > 0.25:
        color = AMBER
    else:
        color = BLUE
    
    ax.scatter(prob, impact, s=size, c=color, alpha=0.7, edgecolors=WHITE, 
               linewidth=1.5, zorder=3)
    
    # Label
    ax.annotate(name, 
                xy=(prob, impact),
                xytext=(10, 10), textcoords='offset points',
                fontsize=10, color=WHITE, fontweight='bold', zorder=4)
    
    # Description below
    ax.annotate(desc,
                xy=(prob, impact),
                xytext=(0, -20), textcoords='offset points',
                fontsize=8, color=GRAY, ha='center', zorder=4)

# Axis labels
ax.set_xlabel('Probability of Materialization', color=WHITE, fontsize=12)
ax.set_ylabel('Impact on Valuation', color=WHITE, fontsize=12)
ax.set_title('GitLab (GTLB): Risk Assessment Matrix\n'
             'Bubble Size = Combined Score (Probability × Impact)',
             color=WHITE, fontsize=14, fontweight='bold', pad=20)
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
ax.set_xticklabels(['0%', '25%', '50%', '75%', '100%'], color=WHITE)
ax.set_yticks([0, 0.33, 0.67, 1.0])
ax.set_yticklabels(['Low', 'Medium', 'High', 'Critical'], color=WHITE)
ax.tick_params(axis='x', colors=WHITE)
ax.tick_params(axis='y', colors=WHITE)
ax.set_facecolor(NAVY)
ax.grid(alpha=0.15, color=GRAY, linestyle='-')

# Legend
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor=RED, alpha=0.7, label='High Priority (NRR, GitHub)'),
    Patch(facecolor=AMBER, alpha=0.7, label='Medium Priority (Macro, AI)'),
    Patch(facecolor=BLUE, alpha=0.7, label='Lower Priority (Cannibalization, Key Person)'),
]
ax.legend(handles=legend_elements, loc='upper right', facecolor=NAVY, 
          edgecolor=GRAY, labelcolor=WHITE, fontsize=10)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/05_risk_matrix.png', 
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

# Save CSV
import pandas as pd
csv_data = pd.DataFrame(risks, columns=['Risk', 'Probability', 'Impact', 'Condition'])
csv_data['Combined_Score'] = csv_data['Probability'] * csv_data['Impact']
csv_data.to_csv('/workspace/board-presentation/assets/tables/05_risk_matrix.csv', index=False)

print("Chart 05 generated successfully.")
for name, prob, impact, desc in risks:
    score = prob * impact
    print(f"  {name}: P={prob:.0%}, I={impact:.0%}, Score={score:.2f} — {desc}")
