#!/usr/bin/env python3
"""
Chart 07: EV/Revenue Comparison — GitLab vs. Peers

Reads from:
  - /input/repo/extracted/competitor_data.json

Outputs:
  - /workspace/board-presentation/assets/charts/07_ev_revenue_comparison.png
  - /workspace/board-presentation/assets/tables/07_ev_revenue_comparison.csv
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
import os

# Color palette
NAVY = '#0A1628'
GITLAB_ORANGE = '#E24329'
GRAY = '#95A5A6'
WHITE = '#FFFFFF'
BLUE = '#3498DB'
AMBER = '#F39C12'

# Read competitor data
with open('/input/repo/extracted/competitor_data.json') as f:
    competitors = json.load(f)

# Build data (exclude GTLB, sort by EV/Revenue)
data = []
for ticker, info in competitors.items():
    if ticker == 'GTLB':
        continue
    data.append({
        'ticker': ticker,
        'name': info['name'],
        'ev_revenue': info['ev_revenue'],
        'revenue_growth': info['revenue_growth'] * 100,
        'market_cap_b': info['market_cap_b'],
    })

df = pd.DataFrame(data).sort_values('ev_revenue', ascending=True)

# GitLab data
gtlb = competitors['GTLB']

# Create figure
fig, ax = plt.subplots(figsize=(12, 8))
fig.patch.set_facecolor(NAVY)

# Bar chart
colors = [GITLAB_ORANGE if row['ticker'] == 'GTLB' else GRAY for _, row in df.iterrows()]
bars = ax.barh(df['name'], df['ev_revenue'], color=colors, alpha=0.8, edgecolor=WHITE, linewidth=0.5)

# Add GitLab separately on top
ax.barh(gtlb['name'], gtlb['ev_revenue'], color=GITLAB_ORANGE, alpha=0.9, 
        edgecolor=WHITE, linewidth=2, zorder=3)

# Peer average line
peer_avg = df['ev_revenue'].mean()
ax.axvline(x=peer_avg, color=BLUE, linestyle='--', linewidth=2, alpha=0.8, 
           label=f'Peer Average: {peer_avg:.1f}x')

# GitLab label
ax.annotate(f'GitLab: {gtlb["ev_revenue"]:.1f}x',
            xy=(gtlb['ev_revenue'], gtlb['name']),
            xytext=(gtlb['ev_revenue'] + 0.5, gtlb['name']),
            fontsize=11, color=GITLAB_ORANGE, fontweight='bold',
            va='center')

# Peer average label
ax.annotate(f'Peer Avg: {peer_avg:.1f}x',
            xy=(peer_avg, 0.95),
            xytext=(peer_avg + 0.5, 0.95),
            fontsize=10, color=BLUE, fontweight='bold',
            va='top',
            bbox=dict(boxstyle='round,pad=0.3', facecolor=NAVY, edgecolor=BLUE, alpha=0.9))

# Discount annotation
discount = (1 - gtlb['ev_revenue'] / peer_avg) * 100
ax.text(0.02, 0.02, f'GitLab trades at {discount:.0f}% discount to peer average EV/Revenue',
        transform=ax.transAxes, fontsize=11, color=WHITE, fontweight='bold',
        bbox=dict(boxstyle='round,pad=0.4', facecolor=NAVY, edgecolor=GITLAB_ORANGE, alpha=0.9))

ax.set_xlabel('EV / Revenue (x)', color=WHITE, fontsize=12)
ax.set_title('EV/Revenue Comparison: GitLab vs. SaaS Peers\n'
             f'GitLab at {gtlb["ev_revenue"]:.1f}x vs. Peer Average {peer_avg:.1f}x ({discount:.0f}% discount)',
             color=WHITE, fontsize=14, fontweight='bold', pad=20)
ax.tick_params(axis='x', colors=WHITE)
ax.tick_params(axis='y', colors=WHITE)
ax.set_facecolor(NAVY)
ax.legend(loc='lower right', facecolor=NAVY, edgecolor=GRAY, 
          labelcolor=WHITE, fontsize=10)
ax.grid(axis='x', alpha=0.15, color=GRAY)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/07_ev_revenue_comparison.png', 
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

# Save CSV
df_out = df.copy()
df_out['ev_revenue'] = df_out['ev_revenue'].round(2)
df_out['revenue_growth'] = df_out['revenue_growth'].round(1)
gtlb_row = pd.DataFrame([{
    'ticker': 'GTLB', 'name': 'GitLab',
    'ev_revenue': round(gtlb['ev_revenue'], 2),
    'revenue_growth': round(gtlb['revenue_growth'] * 100, 1),
    'market_cap_b': gtlb['market_cap_b']
}])
pd.concat([df_out, gtlb_row], ignore_index=True).to_csv(
    '/workspace/board-presentation/assets/tables/07_ev_revenue_comparison.csv', index=False)

print("Chart 07 generated successfully.")
print(f"GitLab EV/Revenue: {gtlb['ev_revenue']:.1f}x")
print(f"Peer Average: {peer_avg:.1f}x")
print(f"Discount: {discount:.0f}%")
