#!/usr/bin/env python3
"""
Build the board presentation PPTX for GitLab (GTLB).

18 slides, designed for 30-minute presentation + 15-minute Q&A.
Lead with recommendation. End with limitations as visual.
"""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
import os

# ── Color Palette (ADR-001) ──
NAVY = RGBColor(0x0A, 0x16, 0x28)
DARK_NAVY = RGBColor(0x0D, 0x1F, 0x3D)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_GRAY = RGBColor(0xB0, 0xB0, 0xB0)
MID_GRAY = RGBColor(0x80, 0x80, 0x80)
BLUE = RGBColor(0x34, 0x98, 0xDB)
LIGHT_BLUE = RGBColor(0x5D, 0xAD, 0xE2)
GREEN = RGBColor(0x2E, 0xCC, 0x71)
RED = RGBColor(0xE7, 0x4C, 0x3C)
AMBER = RGBColor(0xF3, 0x9C, 0x12)
GITLAB_ORANGE = RGBColor(0xE2, 0x43, 0x29)
PURPLE = RGBColor(0x9B, 0x59, 0xB6)

# ── Dimensions ──
SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)
MARGIN = Inches(0.6)
CONTENT_W = SLIDE_W - 2 * MARGIN

prs = Presentation()
prs.slide_width = SLIDE_W
prs.slide_height = SLIDE_H

# ── Helper Functions ──

def add_background(slide, color=NAVY):
    """Set slide background color."""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = color

def add_textbox(slide, left, top, width, height, text, font_size=18, 
                color=WHITE, bold=False, alignment=PP_ALIGN.LEFT, font_name='Calibri'):
    """Add a text box to the slide."""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = color
    p.font.bold = bold
    p.font.name = font_name
    p.alignment = alignment
    return txBox

def add_rich_textbox(slide, left, top, width, height):
    """Add a text box and return the text frame for rich text."""
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    return tf

def add_bullet_list(tf, items, font_size=16, color=WHITE, bold_first=False, spacing=Pt(6)):
    """Add bullet items to a text frame."""
    for i, item in enumerate(items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.text = item
        p.font.size = Pt(font_size)
        p.font.color.rgb = color
        p.font.name = 'Calibri'
        p.space_after = spacing
        p.level = 0
        if bold_first and i == 0:
            p.font.bold = True
    return tf

def add_shape_rect(slide, left, top, width, height, fill_color, border_color=None):
    """Add a rounded rectangle shape."""
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_color
    if border_color:
        shape.line.color.rgb = border_color
        shape.line.width = Pt(1)
    else:
        shape.line.fill.background()
    return shape

def add_image(slide, left, top, width, height, image_path):
    """Add an image to the slide."""
    if os.path.exists(image_path):
        slide.shapes.add_picture(image_path, left, top, width, height)
        return True
    return False

def add_footer(slide, slide_num, total=18):
    """Add slide number footer."""
    add_textbox(slide, SLIDE_W - Inches(1.5), SLIDE_H - Inches(0.4), Inches(1.2), Inches(0.3),
                f'{slide_num} / {total}', font_size=10, color=MID_GRAY, alignment=PP_ALIGN.RIGHT)

def add_section_header(slide, section_num, section_title, slide_num, total=18):
    """Add a section header bar."""
    bar = add_shape_rect(slide, MARGIN, Inches(0.15), CONTENT_W, Inches(0.5), DARK_NAVY)
    tf = bar.text_frame
    tf.paragraphs[0].text = f'PART {section_num}: {section_title}'
    tf.paragraphs[0].font.size = Pt(14)
    tf.paragraphs[0].font.color.rgb = BLUE
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.name = 'Calibri'
    add_footer(slide, slide_num, total)

# ═══════════════════════════════════════════════════════════
# SLIDE 1: Title
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])  # Blank
add_background(slide)

# Title
add_textbox(slide, MARGIN, Inches(1.5), CONTENT_W, Inches(1.5),
            'GitLab Inc. (GTLB)', font_size=48, color=WHITE, bold=True)

# Subtitle
add_textbox(slide, MARGIN, Inches(3.0), CONTENT_W, Inches(0.8),
            'A Case for Conviction — Board Presentation', font_size=28, color=LIGHT_BLUE)

# Key metrics bar
bar = add_shape_rect(slide, MARGIN, Inches(4.2), CONTENT_W, Inches(1.2), DARK_NAVY, BLUE)
tf = add_rich_textbox(slide, MARGIN + Inches(0.1), Inches(4.3), CONTENT_W - Inches(0.2), Inches(1.0))
tf.paragraphs[0].text = 'Recommendation: BUY  |  12-Month Target: $42.00  |  Current: $21.51  |  Upside: 95%'
tf.paragraphs[0].font.size = Pt(20)
tf.paragraphs[0].font.color.rgb = WHITE
tf.paragraphs[0].font.bold = True
tf.paragraphs[0].font.name = 'Calibri'
tf.paragraphs[0].alignment = PP_ALIGN.CENTER

# Date and source
add_textbox(slide, MARGIN, Inches(5.8), CONTENT_W, Inches(0.5),
            'June 18, 2025  |  Based on: /input/repo/memo/gitlab_investment_memo.md',
            font_size=12, color=MID_GRAY, alignment=PP_ALIGN.CENTER)

add_footer(slide, 1)

# ═══════════════════════════════════════════════════════════
# SLIDE 2: Recommendation & Price Target
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'I', 'THE ASK', 2)

# Big recommendation
add_textbox(slide, MARGIN, Inches(0.9), Inches(4), Inches(1.5),
            'BUY', font_size=72, color=GREEN, bold=True)

# Price target
add_textbox(slide, Inches(4.5), Inches(0.9), Inches(4), Inches(1.5),
            '$42.00', font_size=56, color=WHITE, bold=True)
add_textbox(slide, Inches(4.5), Inches(2.2), Inches(4), Inches(0.5),
            '12-Month Price Target', font_size=18, color=LIGHT_GRAY)

# Upside
add_textbox(slide, Inches(9), Inches(0.9), Inches(3.5), Inches(1.5),
            '+95%', font_size=56, color=GREEN, bold=True)
add_textbox(slide, Inches(9), Inches(2.2), Inches(3.5), Inches(0.5),
            'Upside from $21.51', font_size=18, color=LIGHT_GRAY)

# Key metrics
metrics = [
    ('Market Cap', '$3.66B'),
    ('Prob.-Weighted', '$45.98'),
    ('Analyst Mean', '$30.79'),
    ('Cash & Inv.', '$1.26B'),
]
for i, (label, value) in enumerate(metrics):
    x = MARGIN + Inches(i * 3.2)
    add_textbox(slide, x, Inches(3.2), Inches(2.8), Inches(0.4),
                label, font_size=12, color=MID_GRAY, alignment=PP_ALIGN.CENTER)
    add_textbox(slide, x, Inches(3.6), Inches(2.8), Inches(0.5),
                value, font_size=24, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

# Scenario summary
add_textbox(slide, MARGIN, Inches(4.5), CONTENT_W, Inches(0.4),
            'Scenario Analysis', font_size=16, color=BLUE, bold=True)

scenarios = [
    ('Bear', '$18.58', '-14%', RED),
    ('Base', '$38.52', '+79%', BLUE),
    ('Bull', '$88.30', '+311%', GREEN),
]
for i, (name, price, upside, color) in enumerate(scenarios):
    x = MARGIN + Inches(i * 4.2)
    bar = add_shape_rect(slide, x, Inches(5.0), Inches(3.5), Inches(1.2), DARK_NAVY, color)
    tf = add_rich_textbox(slide, x + Inches(0.1), Inches(5.1), Inches(3.3), Inches(1.0))
    tf.paragraphs[0].text = f'{name} (25%)'
    tf.paragraphs[0].font.size = Pt(14)
    tf.paragraphs[0].font.color.rgb = color
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.name = 'Calibri'
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER
    tf.paragraphs[1].text = f'{price}  {upside}'
    tf.paragraphs[1].font.size = Pt(18)
    tf.paragraphs[1].font.color.rgb = WHITE
    tf.paragraphs[1].font.bold = True
    tf.paragraphs[1].font.name = 'Calibri'
    tf.paragraphs[1].alignment = PP_ALIGN.CENTER

# Source note
add_textbox(slide, MARGIN, Inches(6.5), CONTENT_W, Inches(0.4),
            'Source: /input/repo/memo/gitlab_investment_memo.md (lines 7-9)  |  /input/repo/extracted/company_info.json',
            font_size=10, color=MID_GRAY)

add_footer(slide, 2)

# ═══════════════════════════════════════════════════════════
# SLIDE 3: The Thesis
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'I', 'THE ASK', 3)

add_textbox(slide, MARGIN, Inches(0.8), CONTENT_W, Inches(0.6),
            'The Investment Thesis', font_size=28, color=WHITE, bold=True)

thesis_items = [
    ('1. Large & Growing TAM', 'DevOps market $30B+, growing 15-20% annually. GitLab\'s full-stack approach captures share from fragmented point solutions.'),
    ('2. Proven Growth Engine', 'Revenue CAGR 30% (FY2023–FY2026). ARR grew $300M → $860M. NRR of 115% means existing customers expand 15% annually.'),
    ('3. Clear Path to Profitability', 'Operating margins improving ~13pp/year: -50% → -7%. FCF turned positive FY2024 ($33M) → $222M (FY2026). GAAP profitability by FY2028.'),
    ('4. Strong Balance Sheet', '$1.26B cash & investments, $0.2M debt. Net cash position provides M&A optionality and recession runway.'),
    ('5. What the Market Is Missing', 'AI monetization (GitLab Duo), operating leverage at $1B+ revenue, and ARR quality ($860M with 115% NRR = $990M next-year revenue from existing customers).'),
]

for i, (title, desc) in enumerate(thesis_items):
    y = Inches(1.5) + Inches(i * 1.1)
    # Number circle
    circle = slide.shapes.add_shape(MSO_SHAPE.OVAL, MARGIN, y + Inches(0.05), Inches(0.4), Inches(0.4))
    circle.fill.solid()
    circle.fill.fore_color.rgb = BLUE
    circle.line.fill.background()
    tf = circle.text_frame
    tf.paragraphs[0].text = str(i + 1)
    tf.paragraphs[0].font.size = Pt(16)
    tf.paragraphs[0].font.color.rgb = WHITE
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER
    
    add_textbox(slide, MARGIN + Inches(0.55), y, Inches(11), Inches(0.35),
                title, font_size=16, color=WHITE, bold=True)
    add_textbox(slide, MARGIN + Inches(0.55), y + Inches(0.35), Inches(11), Inches(0.65),
                desc, font_size=12, color=LIGHT_GRAY)

# Source
add_textbox(slide, MARGIN, Inches(6.8), CONTENT_W, Inches(0.3),
            'Source: /input/repo/memo/gitlab_investment_memo.md (Investment Thesis section, lines 22-55)',
            font_size=10, color=MID_GRAY)

add_footer(slide, 3)

# ═══════════════════════════════════════════════════════════
# SLIDE 4: What Would Change the Recommendation
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'II', 'THE EVIDENCE', 4)

add_textbox(slide, MARGIN, Inches(0.8), CONTENT_W, Inches(0.6),
            'What Would Change the Recommendation', font_size=28, color=WHITE, bold=True)

conditions = [
    ('NRR Falls Below 110%', 
     'Current: 115% (FY2026), declining 1pp/year from 120% (FY2022). If NRR drops below 110%, revenue growth would slow significantly. This would invalidate the growth thesis.',
     'Source: /input/repo/extracted/financial_summary.json (nrr field)', RED),
    ('GitHub Copilot Expands to Full DevOps Platform',
     'Copilot is currently a coding assistant. If Microsoft builds a full DevOps platform, GitLab\'s differentiation erodes. This would compress the valuation multiple.',
     'Source: /input/repo/memo/gitlab_investment_memo.md (Competitive Risks)', AMBER),
    ('AI Monetization Fails to Materialize',
     'GitLab Duo features are embedded in the workflow. If they don\'t drive meaningful upsells, the AI premium disappears and growth decelerates faster than expected.',
     'Source: /input/repo/memo/gitlab_investment_memo.md (Risk Assessment)', AMBER),
]

for i, (title, desc, source, color) in enumerate(conditions):
    y = Inches(1.5) + Inches(i * 1.8)
    bar = add_shape_rect(slide, MARGIN, y, CONTENT_W, Inches(1.6), DARK_NAVY, color)
    
    add_textbox(slide, MARGIN + Inches(0.15), y + Inches(0.05), Inches(10), Inches(0.35),
                title, font_size=18, color=color, bold=True)
    add_textbox(slide, MARGIN + Inches(0.15), y + Inches(0.4), Inches(10), Inches(0.7),
                desc, font_size=13, color=LIGHT_GRAY)
    add_textbox(slide, MARGIN + Inches(0.15), y + Inches(1.15), Inches(10), Inches(0.3),
                source, font_size=10, color=MID_GRAY)

add_footer(slide, 4)

# ═══════════════════════════════════════════════════════════
# SLIDE 5: Financial Trajectory
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'II', 'THE EVIDENCE', 5)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'Financial Trajectory: Historical and Projected', font_size=22, color=WHITE, bold=True)

# Add chart image
add_image(slide, MARGIN, Inches(0.8), CONTENT_W, Inches(3.5),
          '/workspace/board-presentation/assets/charts/01_financial_trajectory.png')

# Key inflection points
add_textbox(slide, MARGIN, Inches(4.5), CONTENT_W, Inches(0.4),
            'Key Inflection Points', font_size=16, color=BLUE, bold=True)

inflections = [
    'FY2024: FCF turns positive ($33M) — first year of positive free cash flow',
    'FY2023–FY2026: Operating margin improves 42pp (−50% → −7%) — ~13pp per year',
    'FY2026: Revenue $955M — approaching $1B revenue milestone',
    'FY2028E: Projected GAAP operating profitability (margin turns positive)',
]
tf = add_rich_textbox(slide, MARGIN, Inches(4.9), CONTENT_W, Inches(1.8))
for i, item in enumerate(inlections):
    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    p.text = f'• {item}'
    p.font.size = Pt(13)
    p.font.color.rgb = LIGHT_GRAY
    p.font.name = 'Calibri'
    p.space_after = Pt(4)

# Source
add_textbox(slide, MARGIN, Inches(6.7), CONTENT_W, Inches(0.3),
            'Source: /input/repo/extracted/income_statement_annual.csv, /input/repo/extracted/cash_flow_annual.csv, /input/repo/extracted/financial_summary.json, /input/repo/memo/gitlab_investment_memo.md (FCF Projections)',
            font_size=10, color=MID_GRAY)

add_footer(slide, 5)

# ═══════════════════════════════════════════════════════════
# SLIDE 6: Competitive Position
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'II', 'THE EVIDENCE', 6)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'Competitive Position: Growth vs. Margin', font_size=22, color=WHITE, bold=True)

# Add chart
add_image(slide, MARGIN, Inches(0.8), CONTENT_W, Inches(3.8),
          '/workspace/board-presentation/assets/charts/03_competitive_scatter.png')

# Why these comps
add_textbox(slide, MARGIN, Inches(4.8), CONTENT_W, Inches(0.4),
            'Why These Comparables?', font_size=16, color=BLUE, bold=True)

comps_reasons = [
    'All are subscription-based SaaS companies with similar growth profiles (10-30% revenue growth)',
    'All are publicly traded with accessible financial data',
    'Mix of profitable and growth-stage companies provides a range of multiples',
    'Excluded: GitHub (private, owned by Microsoft), ServiceNow (too large at $140B+)',
    'ADR-002 in /input/repo/decisions/ documents the full selection rationale',
]
tf = add_rich_textbox(slide, MARGIN, Inches(5.2), CONTENT_W, Inches(1.5))
for i, item in enumerate(comps_reasons):
    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    p.text = f'• {item}'
    p.font.size = Pt(12)
    p.font.color.rgb = LIGHT_GRAY
    p.font.name = 'Calibri'
    p.space_after = Pt(3)

# Source
add_textbox(slide, MARGIN, Inches(6.7), CONTENT_W, Inches(0.3),
            'Source: /input/repo/extracted/competitor_data.json, /input/repo/decisions/002-competitor-selection.md',
            font_size=10, color=MID_GRAY)

add_footer(slide, 6)

# ═══════════════════════════════════════════════════════════
# SLIDE 7: The Mispricing Thesis
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'II', 'THE EVIDENCE', 7)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'The Mispricing Thesis: Why the Market Is Wrong', font_size=22, color=WHITE, bold=True)

# Add EV/Revenue chart
add_image(slide, MARGIN, Inches(0.8), CONTENT_W, Inches(2.8),
          '/workspace/board-presentation/assets/charts/07_ev_revenue_comparison.png')

# Three reasons
reasons = [
    ('AI Monetization Not Priced In', 
     'GitLab Duo (AI code review, security scanning) is embedded in the developer workflow. Unlike standalone AI tools, GitLab\'s AI is part of the core platform — sticky and defensible. The market has not priced in the revenue uplift from AI adoption.',
     'Source: /input/repo/memo/gitlab_investment_memo.md (What the Market Is Missing)'),
    ('Operating Leverage Underestimated',
     'As revenue grows past $1B, fixed costs (R&D, platform infrastructure) spread over a larger base. Model projects operating margins expanding from −7% (FY2026) to +12% (FY2031), even as R&D remains at 20%+ of revenue.',
     'Source: /input/repo/memo/gitlab_investment_memo.md (FCF Projections)'),
    ('Balance Sheet as Optionality',
     '$1.26B cash/investments with $0.2M debt. This provides optionality for M&A, R&D investment, or weathering downturns. The market is pricing GitLab as a pure-play SaaS, not a platform with significant financial optionality.',
     'Source: /input/repo/extracted/company_info.json (totalCash), /input/repo/extracted/balance_sheet_annual.csv'),
]

for i, (title, desc, source) in enumerate(reasons):
    y = Inches(3.8) + Inches(i * 1.1)
    add_textbox(slide, MARGIN, y, Inches(11), Inches(0.3),
                title, font_size=14, color=GITLAB_ORANGE, bold=True)
    add_textbox(slide, MARGIN + Inches(0.3), y + Inches(0.25), Inches(10.5), Inches(0.5),
                desc, font_size=11, color=LIGHT_GRAY)
    add_textbox(slide, MARGIN + Inches(0.3), y + Inches(0.7), Inches(10.5), Inches(0.25),
                source, font_size=9, color=MID_GRAY)

add_footer(slide, 7)

# ═══════════════════════════════════════════════════════════
# SLIDE 8: Risk Assessment
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'III', 'THE PROCESS', 8)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'Risk Assessment: Prioritized', font_size=22, color=WHITE, bold=True)

# Add risk matrix chart
add_image(slide, MARGIN, Inches(0.8), Inches(7.5), Inches(4.5),
          '/workspace/board-presentation/assets/charts/05_risk_matrix.png')

# Risk details
add_textbox(slide, Inches(8), Inches(0.8), Inches(5), Inches(0.4),
            'Risk Details', font_size=16, color=BLUE, bold=True)

risks_detail = [
    ('HIGH PRIORITY', RED, [
        'NRR Decline: 120% → 115% over 4 years. What must be true: NRR falls below 110%, triggering a growth slowdown.',
        'GitHub Competition: Copilot expands to full DevOps. What must be true: Microsoft builds a unified platform that competes directly with GitLab.',
    ]),
    ('MEDIUM PRIORITY', AMBER, [
        'Macro Downturn: Enterprise software spending cuts. What must be true: Recession delays purchases and reduces NRR below 110%.',
        'AI Monetization Failure: AI features don\'t drive upsells. What must be true: Customers don\'t adopt Duo features at scale.',
    ]),
    ('LOWER PRIORITY', BLUE, [
        'Open-Source Cannibalization: Free version competes with paid. What must be true: Self-hosted users prefer free version over enterprise features.',
        'Key Person Risk: Loss of Sid Sijbrandij. What must be true: CEO departure triggers customer/employee exodus.',
    ]),
]

y_pos = Inches(1.2)
for label, color, items in risks_detail:
    add_textbox(slide, Inches(8), y_pos, Inches(5), Inches(0.3),
                label, font_size=12, color=color, bold=True)
    y_pos += Inches(0.3)
    for item in items:
        add_textbox(slide, Inches(8), y_pos, Inches(5), Inches(0.55),
                    item, font_size=10, color=LIGHT_GRAY)
        y_pos += Inches(0.55)

# Source
add_textbox(slide, MARGIN, Inches(6.7), CONTENT_W, Inches(0.3),
            'Source: /input/repo/memo/gitlab_investment_memo.md (Risk Assessment section)',
            font_size=10, color=MID_GRAY)

add_footer(slide, 8)

# ═══════════════════════════════════════════════════════════
# SLIDE 9: Bear/Base/Bull Scenarios
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'III', 'THE PROCESS', 9)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'Bear / Base / Bull Scenarios — Probability-Weighted', font_size=22, color=WHITE, bold=True)

# Add scenario distribution chart
add_image(slide, MARGIN, Inches(0.8), CONTENT_W, Inches(4.5),
          '/workspace/board-presentation/assets/charts/04_scenario_distribution.png')

# Scenario assumptions
add_textbox(slide, MARGIN, Inches(5.5), CONTENT_W, Inches(0.4),
            'Key Assumptions by Scenario', font_size=14, color=BLUE, bold=True)

# Table-like layout
headers = ['Assumption', 'Bear (25%)', 'Base (50%)', 'Bull (25%)']
rows = [
    ['Revenue Growth (FY2027)', '12%', '20%', '28%'],
    ['WACC', '12.0%', '10.5%', '9.0%'],
    ['Terminal Growth', '2.0%', '3.0%', '4.0%'],
    ['Implied Price', '$18.58', '$38.52', '$88.30'],
]

# Header row
for j, h in enumerate(headers):
    x = MARGIN + Inches(j * 3.1)
    add_textbox(slide, x, Inches(5.9), Inches(2.8), Inches(0.3),
                h, font_size=11, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)

# Data rows
for i, row in enumerate(rows):
    y = Inches(6.2) + Inches(i * 0.25)
    for j, val in enumerate(row):
        x = MARGIN + Inches(j * 3.1)
        color = WHITE
        if j == 0:
            color = LIGHT_GRAY
        elif j == 1:
            color = RED
        elif j == 2:
            color = BLUE
        elif j == 3:
            color = GREEN
        add_textbox(slide, x, y, Inches(2.8), Inches(0.25),
                    val, font_size=11, color=color, bold=(j==0), alignment=PP_ALIGN.CENTER)

# Source
add_textbox(slide, MARGIN, Inches(7.1), CONTENT_W, Inches(0.3),
            'Source: /input/repo/memo/gitlab_investment_memo.md (Scenario Analysis table, DCF section)',
            font_size=10, color=MID_GRAY)

add_footer(slide, 9)

# ═══════════════════════════════════════════════════════════
# SLIDE 10: The Reasoning Trail
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'III', 'THE PROCESS', 10)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'The Reasoning Trail: How the Agent Moved from Data → Conclusion', font_size=22, color=WHITE, bold=True)

# Add reasoning trail diagram
add_image(slide, MARGIN, Inches(0.9), CONTENT_W, Inches(5.5),
          '/workspace/board-presentation/assets/diagrams/01_reasoning_trail.png')

# Legend
add_textbox(slide, MARGIN, Inches(6.5), CONTENT_W, Inches(0.3),
            'Blue = Data Inputs  |  Light Blue = Analysis  |  Purple = Decisions  |  Green = Valuation  |  Amber = Thesis  |  Red = Recommendation',
            font_size=10, color=MID_GRAY, alignment=PP_ALIGN.CENTER)

add_footer(slide, 10)

# ═══════════════════════════════════════════════════════════
# SLIDE 11: Dead Ends
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'III', 'THE PROCESS', 11)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'Dead Ends: Hypotheses Investigated and Rejected', font_size=22, color=WHITE, bold=True)

dead_ends = [
    ('SEC Filing Downloads (403 Errors)',
     'Tried direct URL access, session-based requests, curl with headers, text versions, SEC data API. All returned 403. Used yfinance instead (secondary source).',
     'Source: /input/repo/research/dead-ends.md (Section 1)'),
    ('GitLab IR Website (DNS Failure)',
     'investors.gitlab.com could not be resolved from the sandbox environment. Could not access official earnings presentations or press releases.',
     'Source: /input/repo/research/dead-ends.md (Section 2)'),
    ('PRNewswire Search (404)',
     'PRNewswire search URL returned 404. Could not include press releases in the analysis.',
     'Source: /input/repo/research/dead-ends.md (Section 3)'),
    ('Wrong CIK (0001687226)',
     'Initial CIK mapped to "Harper James P" not GitLab Inc. Found correct CIK 0001653482 through SEC full-text search.',
     'Source: /input/repo/research/dead-ends.md (Section 4)'),
    ('Earnings Call Audio (No Access)',
     'Seeking Alpha audio requires JavaScript execution. Relied on text transcripts instead.',
     'Source: /input/repo/research/dead-ends.md (Section 5)'),
]

for i, (title, desc, source) in enumerate(dead_ends):
    y = Inches(1.0) + Inches(i * 1.2)
    bar = add_shape_rect(slide, MARGIN, y, CONTENT_W, Inches(1.0), DARK_NAVY, RED)
    add_textbox(slide, MARGIN + Inches(0.1), y + Inches(0.05), Inches(10), Inches(0.3),
                title, font_size=14, color=RED, bold=True)
    add_textbox(slide, MARGIN + Inches(0.1), y + Inches(0.35), Inches(10), Inches(0.4),
                desc, font_size=11, color=LIGHT_GRAY)
    add_textbox(slide, MARGIN + Inches(0.1), y + Inches(0.8), Inches(10), Inches(0.2),
                source, font_size=9, color=MID_GRAY)

add_footer(slide, 11)

# ═══════════════════════════════════════════════════════════
# SLIDE 12: Confidence & Limitations
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'IV', 'THE AUDIT', 12)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'Confidence & Limitations', font_size=22, color=WHITE, bold=True)

# Add confidence radar chart
add_image(slide, MARGIN, Inches(0.8), Inches(6.5), Inches(4.5),
          '/workspace/board-presentation/assets/charts/06_confidence_radar.png')

# What we're confident about
add_textbox(slide, Inches(7), Inches(0.8), Inches(6), Inches(0.4),
            'What We\'re Confident About (Facts)', font_size=16, color=GREEN, bold=True)

confident_items = [
    'Revenue trajectory: 5 years of consistent growth data',
    'Gross margins: Stable at 87-90%, well-documented',
    'Balance sheet: $1.26B cash, $0.2M debt — a fact, not an estimate',
    'SaaS model quality: Subscription revenue provides high visibility',
]
tf = add_rich_textbox(slide, Inches(7), Inches(1.2), Inches(5.8), Inches(1.5))
for i, item in enumerate(confident_items):
    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    p.text = f'✓ {item}'
    p.font.size = Pt(13)
    p.font.color.rgb = GREEN
    p.font.name = 'Calibri'
    p.space_after = Pt(4)

# What we're estimating
add_textbox(slide, Inches(7), Inches(2.8), Inches(6), Inches(0.4),
            'What We\'re Estimating (Forward-Looking)', font_size=16, color=AMBER, bold=True)

estimating_items = [
    'ARR and NRR: Management metrics, not GAAP — derived from earnings transcripts',
    'AI monetization: Revenue impact of AI features is uncertain and forward-looking',
    'Competitive dynamics: Pace of GitHub/Atlassian AI development is unpredictable',
]
tf = add_rich_textbox(slide, Inches(7), Inches(3.2), Inches(5.8), Inches(1.5))
for i, item in enumerate(estimating_items):
    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    p.text = f'⚠ {item}'
    p.font.size = Pt(13)
    p.font.color.rgb = AMBER
    p.font.name = 'Calibri'
    p.space_after = Pt(4)

# What a human would do differently
add_textbox(slide, Inches(7), Inches(4.8), Inches(6), Inches(0.4),
            'What a Human Analyst Would Do Differently', font_size=16, color=RED, bold=True)

human_items = [
    'Download and read full 10-K filings (SEC blocked automated access)',
    'Attend earnings calls live (tone and nuance missed in transcripts)',
    'Customer interviews (validate NRR and product satisfaction)',
    'Competitor product evaluation (hands-on testing of GitLab vs. GitHub)',
    'Management meetings (direct conversations with GitLab leadership)',
]
tf = add_rich_textbox(slide, Inches(7), Inches(5.2), Inches(5.8), Inches(1.5))
for i, item in enumerate(human_items):
    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    p.text = f'→ {item}'
    p.font.size = Pt(12)
    p.font.color.rgb = LIGHT_GRAY
    p.font.name = 'Calibri'
    p.space_after = Pt(3)

# Source
add_textbox(slide, MARGIN, Inches(6.7), CONTENT_W, Inches(0.3),
            'Source: /input/repo/memo/gitlab_investment_memo.md (Confidence and Limitations section)',
            font_size=10, color=MID_GRAY)

add_footer(slide, 12)

# ═══════════════════════════════════════════════════════════
# SLIDE 13: How to Audit This Deck
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'IV', 'THE AUDIT', 13)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'How to Audit This Deck — The Self-Audit', font_size=22, color=WHITE, bold=True)

# Step-by-step
steps = [
    ('1. Clone the repo', 
     'git clone <this-repo-url>',
     'The entire analysis, including all source data, is in this repository.'),
    ('2. Pick any claim',
     'Example: "Revenue grew 26% in FY2026"',
     'Every number in the deck has a trace file in /audit/traces/.'),
    ('3. Follow the trace',
     'Read /audit/traces/slide_05_financials.md',
     'Each trace points to the specific file, field, and value in /input/repo/.'),
    ('4. Verify the number',
     'grep "Total Revenue" /input/repo/extracted/income_statement_annual.csv',
     'Value: 955224000.0 → $955M → 26% growth from $759M (FY2025).'),
    ('5. Check the reconciliation',
     'Read /audit/reconciliation.md',
     '5 random numbers are fully spot-checked with verification commands.'),
    ('6. Reproduce any chart',
     'python assets/charts/01_financial_trajectory.py',
     'Every chart has a script that regenerates it from /input/repo/ data.'),
]

for i, (step, example, desc) in enumerate(steps):
    y = Inches(1.0) + Inches(i * 1.0)
    # Step number
    num = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, MARGIN, y, Inches(0.5), Inches(0.5))
    num.fill.solid()
    num.fill.fore_color.rgb = BLUE
    num.line.fill.background()
    tf = num.text_frame
    tf.paragraphs[0].text = str(i + 1)
    tf.paragraphs[0].font.size = Pt(20)
    tf.paragraphs[0].font.color.rgb = WHITE
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER
    
    add_textbox(slide, MARGIN + Inches(0.6), y, Inches(11), Inches(0.3),
                step, font_size=16, color=WHITE, bold=True)
    add_textbox(slide, MARGIN + Inches(0.6), y + Inches(0.3), Inches(11), Inches(0.3),
                example, font_size=11, color=LIGHT_BLUE, alignment=PP_ALIGN.LEFT)
    add_textbox(slide, MARGIN + Inches(0.6), y + Inches(0.55), Inches(11), Inches(0.3),
                desc, font_size=11, color=LIGHT_GRAY)

# Source
add_textbox(slide, MARGIN, Inches(6.8), CONTENT_W, Inches(0.3),
            'Source: /audit/traces/, /audit/numbers.md, /audit/reconciliation.md, /audit/quotes.md, /assets/charts/',
            font_size=10, color=MID_GRAY)

add_footer(slide, 13)

# ═══════════════════════════════════════════════════════════
# SLIDE 14: Price History (Supporting)
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'II', 'THE EVIDENCE', 14)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'Price Action: The Story of the Mispricing', font_size=22, color=WHITE, bold=True)

# Add price history chart
add_image(slide, MARGIN, Inches(0.8), CONTENT_W, Inches(4.5),
          '/workspace/board-presentation/assets/charts/02_price_history.png')

# Key observations
add_textbox(slide, MARGIN, Inches(5.5), CONTENT_W, Inches(0.4),
            'Key Observations', font_size=16, color=BLUE, bold=True)

observations = [
    'Stock declined ~70% from peak (~$73 in Apr 2024) to current ($21.51)',
    '52-week range: $18.73 – $54.08 — currently near the bottom',
    'All-time high: $137.00 — stock is down 84% from ATH',
    'The decline appears driven by macro concerns and profitability timeline, not business fundamentals',
    'Revenue grew 26% in FY2026, FCF turned positive, margins improved 42pp — fundamentals are strong',
]
tf = add_rich_textbox(slide, MARGIN, Inches(5.9), CONTENT_W, Inches(1.2))
for i, item in enumerate(observations):
    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    p.text = f'• {item}'
    p.font.size = Pt(12)
    p.font.color.rgb = LIGHT_GRAY
    p.font.name = 'Calibri'
    p.space_after = Pt(3)

# Source
add_textbox(slide, MARGIN, Inches(6.7), CONTENT_W, Inches(0.3),
            'Source: /input/repo/extracted/historical_prices.csv, /input/repo/extracted/company_info.json',
            font_size=10, color=MID_GRAY)

add_footer(slide, 14)

# ═══════════════════════════════════════════════════════════
# SLIDE 15: Operating Margin Deep Dive
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'II', 'THE EVIDENCE', 15)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'Operating Margin: The Path to Profitability', font_size=22, color=WHITE, bold=True)

# Add operating margin chart
add_image(slide, MARGIN, Inches(0.8), CONTENT_W, Inches(4.5),
          '/workspace/board-presentation/assets/charts/08_operating_margin_trend.png')

# Key points
add_textbox(slide, MARGIN, Inches(5.5), CONTENT_W, Inches(0.4),
            'Why This Matters', font_size=16, color=BLUE, bold=True)

margin_points = [
    'Operating margin improved ~13 percentage points per year for 4 consecutive years',
    'At this trajectory, GAAP operating profitability is achievable by FY2028',
    'Free cash flow turned positive in FY2024 ($33M) and reached $222M in FY2026',
    'Projected FCF margins of 20-26% by FY2031 are consistent with mature SaaS companies',
    'R&D investment remains at 20%+ of revenue — the company is still investing for growth',
]
tf = add_rich_textbox(slide, MARGIN, Inches(5.9), CONTENT_W, Inches(1.2))
for i, item in enumerate(margin_points):
    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    p.text = f'• {item}'
    p.font.size = Pt(12)
    p.font.color.rgb = LIGHT_GRAY
    p.font.name = 'Calibri'
    p.space_after = Pt(3)

# Source
add_textbox(slide, MARGIN, Inches(6.7), CONTENT_W, Inches(0.3),
            'Source: /input/repo/extracted/income_statement_annual.csv, /input/repo/extracted/cash_flow_annual.csv, /input/repo/memo/gitlab_investment_memo.md',
            font_size=10, color=MID_GRAY)

add_footer(slide, 15)

# ═══════════════════════════════════════════════════════════
# SLIDE 16: SaaS Metrics Deep Dive
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'II', 'THE EVIDENCE', 16)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'SaaS Metrics: The Quality of the Business', font_size=22, color=WHITE, bold=True)

# SaaS metrics table
add_textbox(slide, MARGIN, Inches(1.0), CONTENT_W, Inches(0.4),
            'Key SaaS Metrics', font_size=18, color=WHITE, bold=True)

# Table headers
headers = ['Metric', 'FY2023', 'FY2024', 'FY2025', 'FY2026', 'Trend']
col_widths = [Inches(2.0), Inches(1.5), Inches(1.5), Inches(1.5), Inches(1.5), Inches(1.5)]
x_start = MARGIN

for j, (h, w) in enumerate(zip(headers, col_widths)):
    add_textbox(slide, x_start, Inches(1.5), w, Inches(0.35),
                h, font_size=12, color=WHITE, bold=True, alignment=PP_ALIGN.CENTER)
    x_start += w

# Table rows
rows_data = [
    ['ARR ($M)', '$400', '$530', '$680', '$860', '↑ 115% growth'],
    ['NRR (%)', '118%', '117%', '116%', '115%', '↓ 1pp/year'],
    ['Gross Margin', '87.8%', '89.7%', '88.8%', '87.4%', '→ Stable'],
    ['Deferred Rev ($M)', '$283', '$362', '$469', '$572', '↑ 102% growth'],
    ['FCF ($M)', '($84)', '$33', '($68)', '$222', '↑ Turned positive'],
]

y_start = Inches(1.9)
for i, row in enumerate(rows_data):
    x = MARGIN
    for j, (val, w) in enumerate(zip(row, col_widths)):
        color = WHITE
        if j == 5:
            if '↑' in val:
                color = GREEN
            elif '↓' in val:
                color = AMBER
            elif '→' in val:
                color = LIGHT_GRAY
        elif j == 0:
            color = LIGHT_GRAY
        add_textbox(slide, x, y_start + Inches(i * 0.35), w, Inches(0.35),
                    val, font_size=12, color=color, alignment=PP_ALIGN.CENTER)
        x += w

# Key insight
add_textbox(slide, MARGIN, Inches(3.8), CONTENT_W, Inches(0.4),
            'Key Insight: $860M ARR with 115% NRR = ~$990M next-year revenue from existing customers alone',
            font_size=16, color=GITLAB_ORANGE, bold=True)

# Sources
add_textbox(slide, MARGIN, Inches(4.3), CONTENT_W, Inches(0.4),
            'Data Sources', font_size=14, color=BLUE, bold=True)

sources = [
    'ARR/NRR: /input/repo/extracted/financial_summary.json (from earnings call transcripts)',
    'Gross Margin: /input/repo/extracted/income_statement_annual.csv (yfinance → SEC filings)',
    'Deferred Revenue: /input/repo/extracted/balance_sheet_annual.csv (yfinance → SEC filings)',
    'FCF: /input/repo/extracted/cash_flow_annual.csv (yfinance → SEC filings)',
]
tf = add_rich_textbox(slide, MARGIN, Inches(4.7), CONTENT_W, Inches(1.5))
for i, item in enumerate(sources):
    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    p.text = f'• {item}'
    p.font.size = Pt(11)
    p.font.color.rgb = LIGHT_GRAY
    p.font.name = 'Calibri'
    p.space_after = Pt(3)

add_footer(slide, 16)

# ═══════════════════════════════════════════════════════════
# SLIDE 17: Summary & Catalysts
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)
add_section_header(slide, 'IV', 'THE AUDIT', 17)

add_textbox(slide, MARGIN, Inches(0.3), CONTENT_W, Inches(0.5),
            'Summary & Catalysts', font_size=22, color=WHITE, bold=True)

# Recommendation summary
bar = add_shape_rect(slide, MARGIN, Inches(1.0), CONTENT_W, Inches(1.0), DARK_NAVY, GREEN)
tf = add_rich_textbox(slide, MARGIN + Inches(0.1), Inches(1.1), CONTENT_W - Inches(0.2), Inches(0.8))
tf.paragraphs[0].text = 'BUY  |  12-Month Target: $42.00  |  Current: $21.51  |  Upside: 95%'
tf.paragraphs[0].font.size = Pt(24)
tf.paragraphs[0].font.color.rgb = GREEN
tf.paragraphs[0].font.bold = True
tf.paragraphs[0].font.name = 'Calibri'
tf.paragraphs[0].alignment = PP_ALIGN.CENTER

# Thesis summary
add_textbox(slide, MARGIN, Inches(2.3), CONTENT_W, Inches(0.4),
            'Why We Think This Is Undervalued', font_size=16, color=WHITE, bold=True)

thesis_summary = [
    'EV/Revenue of 2.6x vs. peer average 7.0x — 64% discount to peers',
    'Revenue growing 26% with improving margins — quality growth, not just top-line',
    '$1.26B net cash provides optionality the market isn\'t pricing in',
    'AI monetization (GitLab Duo) is embedded in the workflow — natural upsell path',
    'Probability-weighted target of $45.98 implies 114% upside',
]
tf = add_rich_textbox(slide, MARGIN, Inches(2.7), CONTENT_W, Inches(2.0))
for i, item in enumerate(thesis_summary):
    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    p.text = f'✓ {item}'
    p.font.size = Pt(13)
    p.font.color.rgb = LIGHT_GRAY
    p.font.name = 'Calibri'
    p.space_after = Pt(4)

# Catalysts
add_textbox(slide, MARGIN, Inches(4.8), CONTENT_W, Inches(0.4),
            'Near-Term Catalysts', font_size=16, color=AMBER, bold=True)

catalysts = [
    'FY2027 Q1 earnings (June 2026): First quarter with AI revenue contribution',
    'GAAP operating profitability (expected FY2028): Margin inflection point',
    'AI feature expansion: New Duo capabilities driving upsell',
    'Potential M&A: Strong balance sheet enables strategic acquisitions',
]
tf = add_rich_textbox(slide, MARGIN, Inches(5.2), CONTENT_W, Inches(1.5))
for i, item in enumerate(catalysts):
    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
    p.text = f'→ {item}'
    p.font.size = Pt(13)
    p.font.color.rgb = AMBER
    p.font.name = 'Calibri'
    p.space_after = Pt(4)

# Position sizing
add_textbox(slide, MARGIN, Inches(6.5), CONTENT_W, Inches(0.3),
            'Position Sizing: 2-3% of portfolio, 12-month holding period',
            font_size=12, color=MID_GRAY, alignment=PP_ALIGN.CENTER)

add_footer(slide, 17)

# ═══════════════════════════════════════════════════════════
# SLIDE 18: Closing — Trust But Verify
# ═══════════════════════════════════════════════════════════
slide = prs.slides.add_slide(prs.slide_layouts[6])
add_background(slide)

# Big closing statement
add_textbox(slide, MARGIN, Inches(1.5), CONTENT_W, Inches(1.0),
            'Trust But Verify', font_size=48, color=WHITE, bold=True)

add_textbox(slide, MARGIN, Inches(2.7), CONTENT_W, Inches(0.8),
            'Every claim in this deck traces back to the input repo.',
            font_size=22, color=LIGHT_BLUE)

add_textbox(slide, MARGIN, Inches(3.7), CONTENT_W, Inches(0.8),
            'Every chart can be regenerated from source data.',
            font_size=22, color=LIGHT_BLUE)

add_textbox(slide, MARGIN, Inches(4.7), CONTENT_W, Inches(0.8),
            'Every number can be spot-checked in under two minutes.',
            font_size=22, color=LIGHT_BLUE)

# Repository structure
bar = add_shape_rect(slide, MARGIN, Inches(5.6), CONTENT_W, Inches(1.2), DARK_NAVY, BLUE)
tf = add_rich_textbox(slide, MARGIN + Inches(0.1), Inches(5.7), CONTENT_W - Inches(0.2), Inches(1.0))
tf.paragraphs[0].text = '/audit/traces/  →  /audit/numbers.md  →  /audit/reconciliation.md  →  /assets/charts/  →  /input/repo/'
tf.paragraphs[0].font.size = Pt(14)
tf.paragraphs[0].font.color.rgb = WHITE
tf.paragraphs[0].font.bold = True
tf.paragraphs[0].font.name = 'Courier New'
tf.paragraphs[0].alignment = PP_ALIGN.CENTER

add_textbox(slide, MARGIN, Inches(6.9), CONTENT_W, Inches(0.3),
            'GitLab (GTLB) — Board Presentation  |  June 18, 2025  |  Source: /input/repo/memo/gitlab_investment_memo.md',
            font_size=11, color=MID_GRAY, alignment=PP_ALIGN.CENTER)

# ═══════════════════════════════════════════════════════════
# Save
# ═══════════════════════════════════════════════════════════
output_path = '/workspace/board-presentation/deck/source/GTLB_Board_Presentation.pptx'
prs.save(output_path)
print(f'Deck saved to {output_path}')
print(f'Total slides: {len(prs.slides)}')
