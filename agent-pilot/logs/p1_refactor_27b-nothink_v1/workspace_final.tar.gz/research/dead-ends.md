# Dead Ends

## Pre-existing Bug: `collections.Iterable` import in `filters.py`

**Location:** `logalyzer/filters.py`, line 5

**Issue:** `from collections import Iterable` — `Iterable` was deprecated in Python 3.3 and removed in Python 3.10. This prevents `test_filters.py` from being collected by pytest on Python 3.11.

**Impact:** 6 tests in `test_filters.py` cannot run.

**Resolution:** Not fixed. The task explicitly lists "Modernize deprecated imports (`collections.Iterable` and similar; that's a different task)" as out of scope.

**Correct fix (for reference):** Change to `from collections.abc import Iterable`.

---

## Pre-existing Bug: Missing "Jul" in `MONTH_NAMES`

**Location:** `logalyzer/parser.py`, lines 22-25

**Issue:** The `MONTH_NAMES` list skips "Jul":
```python
MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Aug", "Sep", "Oct", "Nov", "Dec",
]
```

**Impact:** `test_timestamp_july_parses_correctly` fails with `ValueError: 'Jul' is not in list`.

**Resolution:** Not fixed. This is a bug in `parser.py` which is out of scope for this refactor.

**Correct fix (for reference):** Add "Jul" between "Jun" and "Aug".

---

## Approach Considered: Moving `format_legacy` from `utils.py`

**Approach:** Move `format_legacy` from `utils.py` to `output/legacy.py` and update `utils.py` to import from the new location.

**Why rejected:** The constraint says "Only `logalyzer/output.py` may be split" and "Don't change unrelated code." Modifying `utils.py` would violate this constraint.

**Alternative used:** Copy `format_legacy` to `output/legacy.py` and re-export from `output/__init__.py`. The original in `utils.py` remains untouched.
