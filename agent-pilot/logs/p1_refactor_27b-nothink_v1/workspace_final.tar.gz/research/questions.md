# Questions and Resolutions

## Q1: Where does `format_legacy` live?

**Question:** The task says `output.py` mixes `format_legacy()`, but it's actually defined in `utils.py`. Should I move it from `utils.py`?

**Resolution:** The constraint says "Only `logalyzer/output.py` may be split" and "Don't change unrelated code." I cannot modify `utils.py`. Instead, I placed a copy of `format_legacy` in `output/legacy.py` and re-export it from `output/__init__.py`. This satisfies the verification requirement (`from logalyzer.output import format_legacy` works) without modifying `utils.py`.

## Q2: Where should `render_aggregate` go?

**Question:** `render_aggregate` dispatches to text/json/csv formats. Which module owns it?

**Resolution:** It doesn't belong to any single renderer since it handles multiple formats. Kept it in `output/__init__.py` at the package level.

## Q3: Should I fix the `collections.Iterable` bug?

**Question:** `filters.py` imports `collections.Iterable` which was removed in Python 3.10, preventing test collection.

**Resolution:** No. The task explicitly lists "Modernize deprecated imports (`collections.Iterable` and similar; that's a different task)" as out of scope. Documented in `dead-ends.md`.

## Q4: Should I fix the missing "Jul" in `MONTH_NAMES`?

**Question:** `parser.py` has `MONTH_NAMES` missing "Jul", causing `test_timestamp_july_parses_correctly` to fail.

**Resolution:** No. This is a bug in `parser.py` which I'm not allowed to modify. Documented in `dead-ends.md`.
