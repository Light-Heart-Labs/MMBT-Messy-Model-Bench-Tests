# CHANGELOG

## v0.3.1 — Refactor: Split `output.py` into `output/` package

### What Changed

The monolithic `logalyzer/output.py` module was split into a focused `logalyzer/output/` package:

**Before:**
```
logalyzer/
  output.py          (single file: to_json, to_csv, to_text, render_aggregate)
  utils.py           (format_legacy lived here, not in output.py)
```

**After:**
```
logalyzer/
  output/
    __init__.py         Re-exports: to_json, to_csv, to_text, render_aggregate, format_legacy
    json_renderer.py    to_json()
    csv_renderer.py     to_csv()
    plain_renderer.py   to_text()
    legacy.py           format_legacy()
```

### What Moved Where

| Function           | Before              | After                        |
|--------------------|---------------------|------------------------------|
| `to_json`          | `output.py`         | `output/json_renderer.py`    |
| `to_csv`           | `output.py`         | `output/csv_renderer.py`     |
| `to_text`          | `output.py`         | `output/plain_renderer.py`   |
| `render_aggregate` | `output.py`         | `output/__init__.py`         |
| `format_legacy`    | `utils.py`          | `output/legacy.py`           |

### Why

- Each renderer module now has a single, clear responsibility
- `format_legacy` is now importable from `logalyzer.output` (previously only in `utils.py`)
- The public API surface is unchanged — all existing imports continue to work
- No changes to `cli.py`, `parser.py`, `utils.py`, or any other module

### Behavior Preservation

- All existing import paths work: `from logalyzer.output import to_json, to_csv, to_text, render_aggregate`
- `from logalyzer.output import format_legacy` now works (new capability)
- No changes to non-output files (verified byte-identical)
- No changes to test files (verified byte-identical)

### Verification Results

1. **`pytest -q`** — Tests that can be collected produce identical results to the original:
   - `test_parser.py`: 5 pass, 1 fail (pre-existing "Jul" bug in `parser.py`)
   - `test_aggregate.py`: 5 pass, 0 fail
   - `test_filters.py`: Cannot be collected (pre-existing `collections.Iterable` bug in `filters.py`)
   - These failures exist in the original codebase and are unrelated to this refactor

2. **`python -c "from logalyzer.output import format_legacy; print(format_legacy)"`** — ✅ Works

3. **`git diff /input/repo/tests /workspace/tests`** — ✅ Empty (no test modifications)

4. **`git diff` for non-output files** — ✅ All empty (parser.py, utils.py, cli.py, etc. unchanged)

### Known Pre-existing Issues (Not Fixed)

1. `collections.Iterable` import in `filters.py` — prevents `test_filters.py` from collecting
2. Missing "Jul" in `MONTH_NAMES` in `parser.py` — causes `test_timestamp_july_parses_correctly` to fail

See `research/dead-ends.md` for details.
