"""Plain-text output renderer."""
from __future__ import annotations

from typing import Iterable

from ..parser import LogEntry


def to_text(entries: Iterable[LogEntry]) -> str:
    """Render entries as readable plain text, one entry per line."""
    lines = []
    for e in entries:
        lines.append(
            f'{e.timestamp.isoformat()}  {e.ip:>15}  {e.method:<6} {e.status} {e.url}'
        )
    return '\n'.join(lines)
