"""Output formatters: JSON, CSV, plain text.

This module is a package that re-exports the public API from focused submodules.
All imports that previously worked against logalyzer.output continue to work.
"""
from __future__ import annotations

from .json_renderer import to_json
from .csv_renderer import to_csv
from .plain_renderer import to_text
from .legacy import format_legacy

# render_aggregate is a higher-level function that dispatches to text/json/csv.
# It's kept here in __init__.py since it doesn't fit neatly into one renderer.
from typing import Any, Iterable


def render_aggregate(agg: Any, fmt: str = "text") -> str:
    """Render an aggregate result (Counter, dict, list) as text/json/csv."""
    if fmt == "text":
        if hasattr(agg, "items"):
            return '\n'.join(f"{k}\t{v}" for k, v in agg.items())
        return '\n'.join(f"{k}\t{v}" for k, v in agg)
    elif fmt == "json":
        if hasattr(agg, "items"):
            items = list(agg.items())
        else:
            items = list(agg)
        parts = [f'"{k}":{v}' for k, v in items]
        return '{' + ','.join(parts) + '}'
    else:
        raise ValueError(f"unknown format: {fmt}")
