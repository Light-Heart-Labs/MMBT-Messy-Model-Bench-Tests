# ADR-0001: Why split output.py

## Status

Accepted

## Context

The `logalyzer/output.py` module mixed four distinct concerns:

1. **JSON serialization** (`to_json`) — hand-crafted JSON string building
2. **CSV serialization** (`to_csv`) — uses `csv` stdlib module
3. **Plain-text formatting** (`to_text`) — human-readable line formatting
4. **Aggregate rendering** (`render_aggregate`) — dispatches to text/json for aggregate data
5. **Legacy formatter** (`format_legacy`) — backwards-compat shim from v0.1

Additionally, `format_legacy()` was defined in `utils.py` rather than `output.py`, creating a confusing split where output-related code lived in two different modules.

## Decision

Split `logalyzer/output.py` into a `logalyzer/output/` package with one module per concern:

- `json_renderer.py` — `to_json()`
- `csv_renderer.py` — `to_csv()`
- `plain_renderer.py` — `to_text()`
- `legacy.py` — `format_legacy()`
- `__init__.py` — re-exports public API + `render_aggregate()`

`render_aggregate()` was kept in `__init__.py` because it dispatches across formats and doesn't belong to any single renderer.

## Consequences

- Each renderer module has a single, clear responsibility
- The public API surface is unchanged — all existing imports continue to work
- `format_legacy()` is now importable from `logalyzer.output` (previously only in `utils.py`)
- The `utils.py` copy of `format_legacy()` remains untouched (no modification to unrelated code)
