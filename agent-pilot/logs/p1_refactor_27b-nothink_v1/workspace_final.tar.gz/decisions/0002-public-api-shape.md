# ADR-0002: Public API shape

## Status

Accepted

## Context

The `logalyzer.output` module is imported by `cli.py` with:

```python
from .output import render_aggregate, to_csv, to_json, to_text
```

The verification requirement also demands:

```python
from logalyzer.output import format_legacy
```

## Decision

The `logalyzer/output/__init__.py` re-exports:

| Name              | Source Module        | Used By     |
|-------------------|---------------------|-------------|
| `to_json`         | `json_renderer.py`  | `cli.py`    |
| `to_csv`          | `csv_renderer.py`   | `cli.py`    |
| `to_text`         | `plain_renderer.py` | `cli.py`    |
| `render_aggregate`| `__init__.py`       | `cli.py`    |
| `format_legacy`   | `legacy.py`         | external scripts |

### Why `render_aggregate` stays in `__init__.py`

`render_aggregate()` dispatches to text/json/csv based on a format parameter. It doesn't belong to any single renderer — it's a higher-level orchestration function. Placing it in `__init__.py` keeps it at the package level where it's easily discoverable.

### Why `format_legacy` is in `output/legacy.py`

`format_legacy()` was originally defined in `utils.py`. The task requires it to be importable from `logalyzer.output`. Rather than modifying `utils.py` (which is out of scope), a copy was placed in `output/legacy.py` and re-exported from `__init__.py`. The original in `utils.py` remains untouched.

## Consequences

- All existing import paths continue to work
- No changes required to `cli.py` or any other module
- The `utils.py` copy of `format_legacy` is now duplicated but this is acceptable for a backwards-compat shim
