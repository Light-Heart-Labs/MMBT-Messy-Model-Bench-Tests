# Incident Rewrite Output

This directory contains three audience-tailored rewrites of the Friday service disruption, based on the internal draft memo at `/input/repo/draft_memo.md`. Each rewrite follows the constraints specified in `/input/repo/audience_briefs.json`.

## Files

| File | Audience | Word Count | Limit |
|------|----------|------------|-------|
| `ceo_brief.md` | CEO (board prep) | 241 | ≤250 |
| `customer_email.md` | Affected customers (mass email) | 296 | ≤350 |
| `legal_summary.md` | In-house counsel (SLA review) | 285 | ≤400 |

## How to Read

Each document is a standalone rewrite — not a summary of the others. The same incident is presented three different ways:

- **`ceo_brief.md`** is a concise, executive-level briefing for the CEO's board preparation. It includes the outage summary, impact scope, the "second incident in 90 days" board signal, and key remediations. It avoids engineering jargon and internal names.

- **`customer_email.md`** is a warm, accountable mass email to affected customers. It explains what happened in plain language, outlines commitments for improvement, and explicitly offers SLA credits. It does not name any individuals, does not mention the "second outage in 90 days" framing, and avoids technical terminology.

- **`legal_summary.md`** is a dispassionate, factual summary for in-house counsel reviewing SLA-credit obligations. It uses "incident" rather than "outage," enumerates the exact time window and impact scope, and provides a recommendation on credit-request handling. It contains no marketing language, speculation, or engineering remediation details.

## Supporting Documentation

- `decisions/adr-001-omissions.md` — ADR-style records documenting non-obvious editorial choices (e.g., omission of named individuals, translation of technical root cause, use of "incident" vs "outage").
- `research/notes.md` — Working notes with extracted facts from the source memo and audience-specific decision rationale.
