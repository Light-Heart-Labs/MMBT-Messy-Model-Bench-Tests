# Working Notes — Incident Rewrite Project

## Source Facts Extracted

### Timeline
- **14:09 UTC** — Config change deployed (doubled rate-limit thresholds for internal auth service)
- **14:11 UTC** — Outage begins (primary API returning 502s)
- **~14:50 UTC** — Status page still green (wrong endpoint check)
- **~15:00 UTC** — First hour spent investigating load balancer (symptoms looked like LB issue)
- **Priya** noticed auth service internal metrics showing 100% throttle rate
- **18:18 UTC** — Config change reverted
- **18:24 UTC** — Full traffic recovery
- **Total duration:** ~4 hours 13 minutes (14:11–18:24 UTC)
- **Communication delay:** 47 minutes from "we know it's an outage" to first proactive customer comms

### Impact
- **11,400** customer accounts impacted
- **~28** enterprise accounts (with named CSMs) had real revenue impact during business hours
- **At least 4** cases of downstream automation breakage requiring manual cleanup
- **217** inbound support tickets
- **31** refund requests (mix of SLA-credit-only and full-month-credit requests)

### Root Cause
- Config change doubled rate-limit thresholds for internal auth service
- Auth service has internal limiter using a fraction of global threshold, computed against hard-coded MAX value
- When threshold doubled, internal limiter's fraction stayed pinned to old MAX
- Result: all inbound auth requests throttled → auth fails → API fails → 502s

### SLA
- Contractual SLA: 99.9% monthly uptime with credits for breach
- SLA was nominally violated for affected accounts
- Legal stance: should not contest credit requests where SLA was clearly breached

### Remediations
1. Add canary/staged config rollout (1 sprint, Pri 1)
2. Fix internal limiter to compute fraction against actual global config (2-week project)
3. Status-page check fixed (Friday evening) — was pointing at /healthz on fixed instance
4. 15-minute acknowledgment communication rule for on-call commander
5. Runbook update for "502s widespread but LB green" scenario

### Board Signal
- Second 4+ hour outage in 2026 (first was in February with database storage issue)
- Second data point in 90 days; a third would trigger reliability program overhaul conversation

### People Mentioned
- Marcus (platform team) — deployed the config change
- Priya — noticed the auth service metrics anomaly
- Sarah — had flagged the hard-coded MAX issue in June, left in September

---

## Audience-Specific Decisions

### CEO Brief
- Include: outage summary, 11,400 accounts, 28 enterprise accounts with revenue impact, second outage in 90 days, 4 key remediations
- Exclude: Marcus/Priya/Sarah names, technical details about rate limiters and MAX values
- Tone: Direct, no hedging

### Customer Email
- Include: outage acknowledgement, plain-language root cause, remediation commitments, SLA credit offer, contact path
- Exclude: Marcus name, "second outage in 90 days" framing, technical jargon, internal warnings
- Tone: Warm, accountable, active voice

### Legal Summary
- Include: exact times (14:11–18:24 UTC), 11,400 accounts, 28 enterprise, 4 downstream breakage cases, 99.9% SLA, credit handling recommendation
- Exclude: speculation, named employees, marketing language, engineering remediation details
- Tone: Dispassionate, factual, use "incident" not "outage"
