# Incident Summary — SLA Credit Obligation Review

## 1. Incident Time Window

The incident occurred from 14:11 UTC to 18:24 UTC on Friday, 2026. Total duration: approximately 4 hours 13 minutes. Service was restored at 18:24 UTC following a configuration revert at 18:18 UTC.

## 2. Scope of Impact

- **Total accounts impacted:** Approximately 11,400 customer accounts.
- **Enterprise accounts with revenue impact:** Roughly 28 accounts (those with named Customer Success Managers) experienced impact during business hours.
- **Downstream automation failures:** At least 4 cases identified where customer downstream automation broke, requiring manual data cleanup.
- **Support volume:** 217 inbound support tickets received.
- **Refund/credit requests:** 31 requests received to date. Some request SLA credits only; others request full-month credits.

## 3. SLA Terms and Breach Assessment

The contractual SLA provides for 99.9% monthly uptime with credits for breach. The incident duration (approximately 4 hours 13 minutes) constitutes a nominal breach of the 99.9% monthly uptime threshold for the affected accounts.

## 4. Credit-Request Handling Recommendation

- **SLA-driven requests:** For accounts where the SLA was clearly breached, credit requests should be honored per the Master Service Agreement. The company should not contest these requests.
- **Relationship-driven requests:** For accounts requesting credits on the basis of lost trust or goodwill (where no contractual SLA breach is established), handling should be case-by-case through Finance and Customer Success. These are relationship decisions, not contractual obligations.
- **Downstream automation damage (4 cases):** These accounts are being offered hands-on data-cleanup support engagements in addition to standard SLA credits.

## 5. Processing Timeline

Legal and Finance are working through the 31 refund requests case by case. The SLA-impact analysis is required by end of day Tuesday for the credit-processing batch.
