# Service Disruption — What Happened and What We're Doing About It

Dear Customer,

On Friday, our primary API experienced a service disruption from approximately 14:11 UTC to 18:24 UTC. During this time, between 60% and 100% of requests returned errors. We know this disrupted your operations, and we take full responsibility.

**What happened:** A configuration update to our authentication system was deployed at 14:09 UTC. The change was intended to increase capacity, but it interacted unexpectedly with an internal safeguard, causing all authentication requests to be rejected. Without successful authentication, the API could not process requests, which is why you saw errors. We identified the issue, reverted the change at 18:18 UTC, and full service was restored by 18:24 UTC.

**Who was affected:** Approximately 11,400 customer accounts experienced some impact. We are in direct contact with the roughly 28 enterprise accounts that experienced revenue impact during business hours.

**What we're doing differently:**
- We are adding staged rollouts for configuration changes so updates are tested on a small subset before reaching all customers.
- We are fixing the underlying interaction between our authentication safeguards and configuration settings so this cannot recur.
- Our status monitoring has been corrected to accurately reflect the services you use.
- We are implementing a rule to acknowledge known disruptions within 15 minutes, even before we have a full diagnosis.

**SLA credit:** If your account was affected, you are entitled to an SLA credit per the terms of your agreement. Accounts that explicitly request one will receive it. If you have questions or need to request a credit, please contact your Customer Success Manager or reach out to our support team.

We understand that trust is earned through reliability, and we are committed to doing better.

Sincerely,

The Engineering Team
