# ADR-001: Omission of Named Individuals in Customer Email

**Status:** Accepted
**Date:** 2026-01-XX

**Context:** The source memo names Marcus (platform engineer who deployed the config change), Priya (who noticed the metrics anomaly), and Sarah (who had previously flagged the hard-coded MAX issue). The audience briefs explicitly prohibit naming individuals in the customer email and legal summary.

**Decision:** All named individuals are omitted from the customer email and legal summary. The CEO brief also omits names per the "no internal nicknames" constraint.

**Rationale:** The customer email must not assign blame to a named individual (per must_not_include). The legal summary must not include named-employee blame (per must_not_include). The CEO brief must not include internal nicknames or informal apologies.

---

# ADR-002: Omission of "Second Outage in 90 Days" from Customer Email

**Status:** Accepted
**Date:** 2026-01-XX

**Context:** The source memo frames this as the "second 4+ hour outage in 2026" and "second data point in 90 days." The CEO brief must include this framing (board signal). The customer email must NOT include it.

**Decision:** The "second outage in 90 days" framing is included only in the CEO brief. It is excluded from the customer email and legal summary.

**Rationale:** The audience briefs explicitly state this is "an internal signal, not a customer-facing one" for the customer email. For the legal summary, it is irrelevant to SLA credit determinations and would constitute unnecessary context.

---

# ADR-003: Technical Root Cause Translation for Customer Email

**Status:** Accepted
**Date:** 2026-01-XX

**Context:** The source memo describes the root cause in technical terms: a config change doubled rate-limit thresholds, which interacted with a hard-coded MAX value in an internal limiter, causing all auth requests to be throttled.

**Decision:** The customer email describes the root cause in plain language: "A configuration update to our authentication system was deployed... The change was intended to increase capacity, but it interacted unexpectedly with an internal safeguard, causing all authentication requests to be rejected."

**Rationale:** The customer email must not include engineering jargon (rate limiter, MAX, throttling internals). The plain-language description preserves the essential facts (config change, authentication system, unintended interaction, rejection of requests) without technical terminology.

---

# ADR-004: Use of "Incident" vs "Outage" in Legal Summary

**Status:** Accepted
**Date:** 2026-01-XX

**Context:** The source memo uses "outage" throughout. The legal summary audience brief specifies using "incident" not "outage."

**Decision:** The legal summary uses "incident" exclusively. The CEO brief and customer email use "disruption" and "service disruption" respectively, which are appropriate for their audiences.

**Rationale:** The legal summary tone specification explicitly states "Use 'incident' not 'outage'." The term "incident" is more precise and dispassionate for legal documentation.

---

# ADR-005: SLA Credit Language in Customer Email

**Status:** Accepted
**Date:** 2026-01-XX

**Context:** The source memo describes a tiered approach: SLA credits for enterprise accounts, hands-on support for the 4 downstream-damage cases, and SLA credits for any account that explicitly requests one.

**Decision:** The customer email offers SLA credits broadly ("If your account was affected, you are entitled to an SLA credit per the terms of your agreement") without distinguishing tiers. The specific tiered approach is internal operational detail not appropriate for a mass email.

**Rationale:** The customer email must include "explicit reference to the SLA credit / how to request." A mass email should not differentiate between customer tiers or mention specific case counts. The tiered handling is an internal operational matter.
