# ADR-002: ARR Figure to Use — Adjusted ($36-37M)

**Date:** 2026-03-15
**Status:** Accepted

## Context

The company claims $42M ARR in its press release. TechCrunch reports that adjusted for December churn (Sundry Brands $4.2M + Klatch), the run-rate is closer to $36-37M.

## Decision

**Use the adjusted figure ($36-37M) as the primary ARR metric, with the $42M figure noted as the company's stated number.**

## Rationale

- The $42M figure includes contracts that have already terminated (Sundry in November, Klatch in December). Using it as a current metric is misleading.
- The TechCrunch sourcing is from "two sources familiar with the company's finances," which is credible journalistic sourcing.
- The former employee's blog post independently confirms the Sundry loss was not a surprise internally, lending credibility to the churn narrative.
- The company itself confirmed the Sundry non-renewal to TechCrunch.

## Caveats

- The exact adjusted number ($36-37M) comes from a single source's estimate. We cannot independently verify the Klatch contract size.
- The CEO claims three new $1M+ contracts in Q1, which could partially offset churn. But these are self-reported and unverified.
