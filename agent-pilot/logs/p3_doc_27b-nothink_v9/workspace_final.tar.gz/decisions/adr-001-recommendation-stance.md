# ADR-001: Recommendation Stance — Pass

**Date:** 2026-03-15
**Status:** Accepted

## Context

The brief requires a clear stance: invest, pass, or more diligence needed. The sources present significant tensions between the company's public narrative and internal realities.

## Decision

**Recommendation: PASS on follow-on investment at current valuation.**

## Rationale

1. **Valuation is disconnected from fundamentals**: The $560M post-money valuation implies a ~13x multiple on adjusted ARR ($36-37M). Even the unadjusted $42M ARR doesn't justify this multiple given the churn and concentration risks. The round was already repriced down from $720M, suggesting the market is still working its way down.

2. **Negative unit economics at current scale**: $4M/month burn vs. $3.5M/month revenue means the company is losing ~$500K/month even before restructuring. The restructuring plan (30% international cuts, product tier elimination) is a pivot away from the growth story that justified the Series B.

3. **Customer concentration is a structural risk, not a one-off**: Top 5 customers = 38% of ARR. Losing the #1 customer ($4.2M) is a 10% revenue hit. This isn't a solvable problem with a single follow-on check.

4. **The restructuring signals the growth story is over**: Deferring international expansion, cutting Berlin headcount, and sunsetting the Lite tier all indicate the company is shifting from growth-at-all-costs to survival mode. A follow-on investor would be buying into a turnaround, not a growth story.

5. **The $50M credit facility is a red flag, not a comfort**: While the memo calls it "insurance," securing a credit facility at this stage suggests the company anticipates needing more capital than the Series B provides.

## Counterarguments Considered

- **Strong investor backing**: Sequoia, Accel, Lightning Capital, and FedEx Ventures are credible. But they're also the ones who repriced the round down. Their continued participation doesn't validate the valuation.
- **Good technology and team**: The blog post confirms strong engineering. But technology quality doesn't overcome unit economics.
- **36-month runway with restructuring**: This is true per the memo, but 36 months of runway at a loss is not a path to value creation for a follow-on investor.

## Conditions That Would Change This

- Evidence that the restructuring has been executed and burn is below revenue for two consecutive quarters
- A repriced round at a valuation closer to 8-10x adjusted ARR
- Diversification of the customer base (top 5 < 25% of ARR)
