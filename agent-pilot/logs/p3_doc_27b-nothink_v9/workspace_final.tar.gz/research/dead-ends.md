# Dead Ends — Ideas Considered and Abandoned

## Considered but not included in brief

1. **Deep dive on FedEx Ventures strategic investment**: The PR mentions FedEx as a strategic investor, which could signal distribution partnerships. However, the leaked memo shows international expansion is deferred and Berlin is being downsized — the strategic value of FedEx is unclear and not elaborated in any source. Omitted for lack of substance.

2. **CTO Daniel Wong's technical credibility**: The blog post praises him highly. While relevant for team quality, it doesn't materially change the investment thesis. Mentioned briefly in brief but not a focal point.

3. **The three new $1M+ contracts claimed by CEO**: TechCrunch reports these but provides no independent verification. Noted as a claim but not weighted heavily since they're self-reported and could be small deals aggregated.

4. **Compensation analysis**: The blog post's comp data ($215K base + $50K equity) is interesting for talent market positioning but irrelevant to investment decision. Omitted.

5. **Customer names (Maevia, Truant Coffee, Brick & Cobble)**: Named in PR but no further information available. Not material to analysis.

6. **"AI-driven inventory optimization"**: Mentioned in PR as a use of proceeds but no detail on what this actually is. Could be vaporware or real — no way to tell from sources. Omitted.

7. **The three undisclosed investors in Form D**: Their identities could matter (e.g., if they're known to be distressed buyers), but we have no information. Noted as a gap but not analyzed.

## Framing decisions

- **Recommendation stance**: After weighing all sources, the recommendation is "pass" rather than "more diligence needed." The tensions are material enough that a follow-on at this valuation is unjustified without seeing the restructuring play out. "More diligence" would be appropriate if the issues were fixable with a few answers — but the burn rate, customer concentration, and valuation repricing are structural.

- **Weighting of leaked memo vs. blog post**: The memo is treated as more authoritative because it's an internal CEO document obtained by a reputable outlet (The Information), whereas the blog is one person's perspective. However, the blog's numbers (burn rate, layoff count, concentration %) are consistent with the memo's implications, lending mutual credibility.
