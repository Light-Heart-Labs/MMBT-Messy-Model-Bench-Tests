# Working Notes — Nimbus Logistics Source Analysis

## Source-by-Source Summary

### Source 1 — Press Release (2026-01-14)
- $84M Series B, led by Lightning Capital
- Post-money valuation: $560M (up from $230M Series A in 2023)
- Total funding: $128M across all rounds
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400+ e-commerce brands on platform
- 187 employees across Oakland, Austin, Berlin
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (strategic)
- Use of proceeds: international expansion, AI-driven inventory optimization
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO)

### Source 2 — TechCrunch (2026-01-15)
- Lost two top-five customers in late 2025:
  - Sundry Brands: $4.2M ARR, did not renew in November
  - Klatch: fast-fashion brand, exited in December
- Adjusted ARR after churn: $36-37M (vs. $42M claimed)
- Sundry non-renewal characterized as "strategic mutual decision"
- CEO claims 3 new $1M+ ARR contracts signed in Q1
- Net retention claimed >110%
- Round was meant to close at $720M but repriced down to $560M after Sundry news
- Repricing happened after lead investor learned of Sundry in early December

### Source 3 — Former Employee Blog (2026-02-22)
- Author: "Daniel R", former senior engineer, 14 months tenure
- Positive: good architecture, CTO Daniel Wong is strong, real customer love, competitive comp ($215K base + $50K equity/yr)
- Negative:
  - Burn ~$4M/month vs. ~$3.5M/month revenue (mid-2025)
  - 22 layoffs (~11% of org) in Feb 2025, not publicly announced, mostly customer success and BD
  - Top 5 customers = ~38% of ARR (concentration risk)
  - Sundry loss was not a shock internally
  - Path to profitability requires faster growth or significant cuts
- Recommendation: good for senior engineers, not for those needing job security

### Source 4 — Leaked Internal Memo (2026-03-05)
- Dated Feb 28, 2026, from CEO Mira Patel
- Restructuring plan for cash-flow breakeven by Q4 2026:
  - 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
  - International expansion deferred to 2027
  - Berlin reframed as "support hub" not sales/expansion
  - Nimbus Lite tier sunset (~310 customers, $5K-$20K ARR each)
  - 90-day notice for Lite customers
- New $50M credit facility from Silicon Valley Bridge
- Memo claims 24+ months runway at current burn, extended to 36+ months with cuts
- Breakeven by Q4 2026 is trigger for Series C conversations
- Company declined to confirm specifics

### Source 5 — SEC Form D (filed 2026-01-22)
- Confirms $84M offering, all sold
- 7 investors total (Lightning, Sequoia, Accel, FedEx Ventures + 3 undisclosed)
- Series B Preferred equity
- No officer/director compensation disclosed
- Use of proceeds: "expansion, working capital, general corporate purposes"

## Key Tensions Identified

1. **ARR inflation**: $42M claimed vs. $36-37M adjusted for churn
2. **Valuation repricing**: $720M target → $560M actual (22% haircut)
3. **Customer concentration**: Top 5 = 38% of ARR; lost #1 customer ($4.2M)
4. **Burn rate**: $4M/mo vs. $3.5M/mo revenue = net negative $500K/mo
5. **Hidden layoffs**: 22 people cut in Feb 2025, not publicly disclosed
6. **International pivot**: Berlin expansion now deferred; 30% headcount cut there
7. **Product simplification**: Nimbus Lite being sunset (310 small customers)
8. **Credit facility**: $50M from Silicon Valley Bridge — "insurance, not operating capital"

## Source Quality Assessment

- Source 1 (PR): Company narrative, optimistic framing, selective facts
- Source 2 (TechCrunch): Journalistic, sourced from insiders, corroborates some PR claims
- Source 3 (Blog): Single ex-employee perspective, but specific numbers align with other sources
- Source 4 (Memo): Leaked internal document, likely authentic given specificity and The Information sourcing
- Source 5 (SEC): Regulatory filing, factual but limited scope
