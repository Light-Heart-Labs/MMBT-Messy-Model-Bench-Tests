# Key Facts — Nimbus Logistics, Inc.

Every material fact incorporated into the executive brief, with source attribution.

## Funding & Valuation

| Fact | Source |
|------|--------|
| $84M Series B closed 2026-01-14 | [Source 1], [Source 5] |
| Post-money valuation: $560M | [Source 1] |
| Previous valuation: $230M (Series A, 2023) | [Source 1] |
| Total funding raised: $128M | [Source 1] |
| Lead investor: Lightning Capital | [Source 1], [Source 5] |
| Participants: Sequoia, Accel, FedEx Ventures (strategic), +3 undisclosed | [Source 1], [Source 5] |
| 7 total investors | [Source 5] |
| Round was originally targeted at $720M but repriced down after Sundry non-renewal | [Source 2] |
| $50M credit facility from Silicon Valley Bridge secured | [Source 4] |

## Revenue & Financials

| Fact | Source |
|------|--------|
| Company-reported ARR: $42M as of Q4 2025 | [Source 1] |
| ARR a year prior: $11M | [Source 1] |
| Adjusted ARR after churn: $36-37M | [Source 2] |
| Monthly burn rate: ~$4M (mid-2025) | [Source 3] |
| Monthly revenue: ~$3.5M (mid-2025) | [Source 3] |
| Net monthly loss: ~$500K | [Source 3] (derived) |

## Customers

| Fact | Source |
|------|--------|
| 1,400+ e-commerce brands on platform | [Source 1], [Source 2] |
| Lost Sundry Brands: $4.2M ARR, non-renewal in November 2025 | [Source 2] |
| Lost Klatch: fast-fashion brand, exited December 2025 | [Source 2] |
| Both Sundry and Klatch were top-five customers | [Source 2] |
| Top 5 customers = ~38% of ARR | [Source 3] |
| CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 | [Source 2] |
| CEO claims net retention >110% | [Source 2] |
| Nimbus Lite tier sunset: ~310 customers, $5K-$20K ARR each | [Source 4] |

## Organization & People

| Fact | Source |
|------|--------|
| 187 employees (Oakland, Austin, Berlin) | [Source 1] |
| Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) | [Source 1] |
| 22 layoffs (~11% of org) in February 2025, not publicly announced | [Source 3] |
| Layoffs mostly in customer success and BD | [Source 3] |
| Berlin headcount: 41, planned reduction to 28-30 by end Q2 2026 | [Source 4] |
| 30% reduction in international headcount planned | [Source 4] |

## Strategy & Operations

| Fact | Source |
|------|--------|
| Platform: warehouse management, carrier orchestration, demand forecasting | [Source 1] |
| Stated use of proceeds: international expansion, AI-driven inventory optimization | [Source 1] |
| International expansion deferred to 2027 | [Source 4] |
| Berlin reframed as "support hub" not sales/expansion | [Source 4] |
| Restructuring target: cash-flow breakeven by Q4 2026 | [Source 4] |
| Runway: 24+ months at current burn, 36+ months with restructuring | [Source 4] |
| Series C conversations triggered by operating-cash-flow breakeven | [Source 4] |

## Source Quality Notes

| Source | Assessment |
|--------|------------|
| Source 1 (Press Release) | Company narrative; selective and optimistic |
| Source 2 (TechCrunch) | Journalistic; sourced from insiders; corroborates some PR claims |
| Source 3 (Blog Post) | Single ex-employee; specific numbers align with other sources |
| Source 4 (Leaked Memo) | Internal CEO document; obtained by The Information; high specificity |
| Source 5 (SEC Form D) | Regulatory filing; factual but limited scope |
