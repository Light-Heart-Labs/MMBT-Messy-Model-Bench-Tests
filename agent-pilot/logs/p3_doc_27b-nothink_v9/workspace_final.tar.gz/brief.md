# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Recommendation

**Date:** 2026-03-15
**Recommendation:** **PASS** — Do not make a follow-on investment at current valuation.

---

## The Bottom Line

Nimbus Logistics raised an $84M Series B at a $560M post-money valuation in January 2026 [Source 1]. On the surface, the metrics look strong: $42M ARR, 1,400 customers, and backing from top-tier VCs [Source 1]. But a synthesis of all available sources reveals a company in the early stages of a painful restructuring, with a valuation that still doesn't reflect its underlying economics. **We recommend passing until the company demonstrates at least two consecutive quarters of positive unit economics post-restructuring.**

---

## What the Numbers Actually Say

The company's headline ARR of $42M [Source 1] includes two major contracts that terminated in late 2025: Sundry Brands ($4.2M ARR, non-renewal in November) and Klatch (December exit) [Source 2]. Adjusted for this churn, the current run-rate is closer to $36-37M [Source 2]. The company confirmed the Sundry non-renewal but declined to discuss Klatch [Source 2].

Burn is worse. A former senior engineer reports ~$4M/month burn against ~$3.5M/month revenue as of mid-2025 — a net loss of roughly $500K per month [Source 3]. This aligns with a leaked memo outlining a 30% cut in international headcount, elimination of the lowest-priced product tier (~310 customers affected), and deferral of international expansion to 2027 [Source 4].

The valuation was already discounted from an initial $720M target down to $560M after the Sundry non-renewal became known to the lead investor [Source 2]. At $560M on $36-37M adjusted ARR, Nimbus trades at roughly 15x ARR — a multiple that assumes the growth story is intact. It isn't.

---

## The Restructuring Is a Pivot, Not a Trim

The leaked internal memo from CEO Mira Patel (dated February 28, 2026) is the most revealing document [Source 4]. It describes a fundamental shift in strategy:

- **International expansion is deferred.** Berlin headcount drops from 41 to 28-30, and the office is reframed as a "support hub" [Source 4]. This directly contradicts the press release's stated use of proceeds for "international expansion" [Source 1].
- **The product is being simplified.** The Nimbus Lite tier is being sunset, pushing ~310 small customers ($5K-$20K ARR each) to migrate or leave [Source 4].
- **The goal is survival, not growth.** The memo's stated objective is cash-flow breakeven by Q4 2026, which would "trigger Series C conversations" [Source 4].

A follow-on investor today would be buying into a turnaround, not a growth story. The company also secured a $50M credit facility from Silicon Valley Bridge, which the memo calls "insurance, not operating capital" [Source 4] — suggesting the company anticipates needing more capital than the Series B provides.

---

## Customer Concentration Is a Structural Problem

The top five customers represent approximately 38% of ARR [Source 3]. Losing the largest customer (Sundry, $4.2M) was a 10% revenue hit that the team "was not shocked by" internally [Source 3]. This is a structural vulnerability in a customer base of 1,400 brands where a handful of large accounts dominate revenue.

The CEO claims three new $1M+ contracts in Q1 and net retention above 110% [Source 2]. These are self-reported. Even if true, they don't solve the concentration problem.

---

## Source Quality Notes

The press release is the company's narrative [Source 1]. TechCrunch's reporting is sourced from insiders and reveals the churn [Source 2]. The former-employee blog post is one person's perspective, but its specific numbers (burn rate, layoff count, concentration %) are consistent with the leaked memo's implications [Source 3, Source 4]. The SEC Form D confirms the $84M offering and seven investors but discloses no individual amounts [Source 5]. Three are unnamed.

---

## Conditions That Would Change This Recommendation

We would reconsider if we saw:
1. **Two consecutive quarters of positive unit economics** post-restructuring.
2. **A repriced round** at a valuation closer to 8-10x adjusted ARR.
3. **Customer base diversification** — top five customers below 25% of ARR.

The company has 36+ months of runway per the memo [Source 4], giving time for the restructuring to play out and a better entry point to emerge.
