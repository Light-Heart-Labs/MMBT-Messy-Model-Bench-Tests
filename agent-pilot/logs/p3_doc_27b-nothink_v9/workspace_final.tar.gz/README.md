# Nimbus Logistics — Follow-On Investment Brief

## How to Read This Output

### Primary Deliverable
- **`brief.md`** — The 1-page executive brief (691 words). This is the main output. Read this first.

### Supporting Materials
- **`key-facts.md`** — A comprehensive table of every material fact incorporated into the brief, with source attribution. Use this to verify claims.
- **`research/notes.md`** — Working notes from reading all five source documents. Includes source-by-source summaries, key tensions identified, and source quality assessment.
- **`research/dead-ends.md`** — Ideas considered but abandoned during analysis, with rationale for exclusion.
- **`decisions/adr-001-recommendation-stance.md`** — ADR explaining why the recommendation is "PASS" rather than "more diligence needed."
- **`decisions/adr-002-arr-figure.md`** — ADR explaining the choice to use adjusted ARR ($36-37M) rather than the company's stated $42M.

### Source Documents
The five source documents are in `/input/repo/sources.md`:
1. **Source 1** — Company press release (2026-01-14)
2. **Source 2** — TechCrunch news article (2026-01-15)
3. **Source 3** — Former-employee blog post (2026-02-22)
4. **Source 4** — Leaked internal memo via The Information (2026-03-05)
5. **Source 5** — SEC Form D filing summary (2026-01-22)

### Methodology
All facts in the brief trace to one of the five source documents. No external research was conducted. Source quality is assessed inline in the brief and in `research/notes.md`. The recommendation is calibrated to the evidence: the press release is treated as the company's narrative, the TechCrunch article as journalistic reporting with insider sourcing, the blog post as a single perspective (but one whose numbers are corroborated), the leaked memo as a high-specificity internal document, and the SEC filing as factual but limited in scope.
