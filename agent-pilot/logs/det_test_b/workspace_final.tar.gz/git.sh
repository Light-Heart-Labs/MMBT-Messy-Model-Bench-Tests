#!/bin/bash
cd /workspace && GIT_DIR=/workspace/.git git "$@"
