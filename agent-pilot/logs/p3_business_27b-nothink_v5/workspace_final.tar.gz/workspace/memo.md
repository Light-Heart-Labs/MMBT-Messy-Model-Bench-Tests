# Executive Committee Memo — Borealis Analytics Acquisition Review

**To:** Executive Committee | **From:** [Reviewer] | **Date:** 2026-04-15
**Re:** Independent review of Corp Dev diligence pack — Project Lighthouse
**Recommendation:** **HOLD** — do not proceed to LOI until additional diligence is completed

---

## Recommendation

I recommend **holding** this deal for two more weeks of targeted diligence. The Corp Dev pack presents an attractive target — 80% YoY revenue growth, 118% net retention, and a 7.4x ARR multiple that appears reasonable at face value. However, the pack is an advocacy document with material gaps that prevent me from endorsing the $84M LOI at this time.

**Shift to PROCEED if:** additional diligence confirms customer concentration is manageable, the comp set validates the multiple, and a downside IRR scenario remains acceptable.

**Shift to PASS if:** diligence reveals high customer concentration (>30% of ARR in top 5), a weak competitive moat, or if the downside IRR falls below our hurdle rate.

---

## Strongest Concerns

### 1. Valuation comps are cherry-picked and unnormalized.

The pack cites three comparable transactions — Hexa Insights (~9x ARR), Aspen Data (~12x ARR), and Trellis Analytics (~7x ARR) — to justify Borealis at 7.4x. But no detail is provided on the growth rates, profitability, or deal structures of those targets. A company growing 200% YoY commands a higher multiple than one growing 80%. The pack does not disclose whether those deals included earn-outs or stock components. Three comps is not a dataset — we need at least 8–10 deals, normalized for growth and deal structure, to validate this multiple.

### 2. Customer concentration risk is unquantified.

The pack reports ~280 paid customers with a median ARR of $32K per customer, but does not disclose what share of revenue the top 5 or top 10 customers represent. Reference calls were limited to the top 5, all uniformly positive. We have no churned-customer perspective and no data on whether Borealis's customers overlap with ours (a cannibalization risk the pack ignores).

### 3. The integration plan is aggressive and under-supported.

The pack proposes sunsetting Aurora within 12 months post-close and migrating all customers to our platform. Customers reporting "strong satisfaction" with Aurora may resist. The 4–6 month integration timeline assumes no technical surprises, but the engineering review was high-level ("no concerning patterns"). The pack provides no data migration plan, customer communication strategy, or rollback procedures.

### 4. Key financial details are missing.

The pack provides only one year of financials with no quarterly breakdown, no seasonality analysis, and no cohort-level retention data. The gross margin of 71% is described as "acceptable" without explanation of what drives it or whether it is sustainable at scale. The burn rate of $750K/month against $4.1M in cash yields only ~5.5 months of runway — yet the pack references "22 months runway at last cap raise" without explaining the gap or disclosing the terms of the last raise.

### 5. Synergy and IRR estimates are unsubstantiated.

The $3.2M annual cost savings from "consolidated infra" is stated without a line-item breakdown. The 28–34% risk-adjusted IRR is presented without a model, assumptions, or sensitivity analysis. We need a downside scenario — what happens if retention is 50%, integration takes 18 months, and synergies are not realized?

---

## Diligence Asks for the Next Two Weeks

See `asks.md` for the full list. The highest-priority items:

1. **Customer concentration analysis** — what % of ARR is in the top 5 and top 10 customers? (Corp Dev / Finance, by 4/22)
2. **Broader M&A comp set** — at least 8–10 deals, growth-adjusted and deal-structure-adjusted. (Corp Dev / Finance, by 4/25)
3. **Downside IRR scenario** — model a worst-case integration and retention scenario. (Finance, by 4/28)
4. **Retention conversations** — speak with all 14 engineers and key non-engineering staff, not just the VP Eng. (Corp Dev / HR, by 4/25)
5. **Detailed synergy model** — line-item breakdown of the $3.2M estimate. (Finance / Corp Dev, by 4/25)

---

## Bottom Line

Borealis Analytics appears to be a genuinely interesting target with strong headline metrics and credible leadership. But the diligence pack reads as a sales pitch, not a balanced analysis. At $84M, we owe it to ourselves to close the gaps before committing. Two more weeks of focused diligence will either confirm this is a good deal or reveal reasons to walk away — both are better outcomes than proceeding blind.
