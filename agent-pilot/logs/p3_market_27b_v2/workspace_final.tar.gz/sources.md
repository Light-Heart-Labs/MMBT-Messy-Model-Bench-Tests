# Sources

Every URL fetched during this research, with timestamp and description.

## 1Password

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 1 | https://1password.com/pricing/ | 2025-01-15 | Pricing page. Extracted Business tier: $7.99/user/month (annual), $9.99/user/month (monthly). Teams tier: $19.95/month for up to 10 users. |
| 2 | https://1password.com/business/ | 2025-01-15 | Business features page. Confirms SSO, audit logs, admin console, secret detection. |
| 3 | https://1password.com/features/ | 2025-01-15 | Features page. Confirms CLI, SSH agent, developer tools, platform coverage. |
| 4 | https://1password.com/security/ | 2025-01-15 | Security page. Zero-knowledge architecture, security audit history. |
| 5 | https://trust.1password.io/ | 2025-01-15 | Trust center. SOC 2 Type II compliance confirmed. |
| 6 | https://1password.com/downloads/ | 2025-01-15 | Downloads page. Confirms platform coverage: macOS, Windows, Linux, iOS, Android, browser extensions, CLI. |

## Bitwarden

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 7 | https://bitwarden.com/pricing/ | 2025-01-15 | Pricing page. Extracted: Premium $1.65/user/month, Families $3.99/month, Business Teams $4.00/user/month, Business Enterprise $6.00/user/month (all annual billing). |
| 8 | https://bitwarden.com/product/ | 2025-01-15 | Product page. Confirms open-source, self-hostable, SSO, audit logs. |
| 9 | https://bitwarden.com/help/article/security/ | 2025-01-15 | Security documentation. Zero-knowledge architecture, open-source code. |
| 10 | https://bitwarden.com/ | 2025-01-15 | Homepage. General product information. |
| 11 | https://github.com/bitwarden | 2025-01-15 | GitHub repository. Confirms open-source client and server code. |

## LastPass

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 12 | https://www.lastpass.com/pricing | 2025-01-15 | Pricing page. JS-rendered; pricing extracted from API endpoint. |
| 13 | https://www.lastpass.com/lpapi/purchase/productcatalog | 2025-01-15 | Product catalog API. Extracted: Premium $36/year, Families $48/year, Teams $51/year, Business $84/year, Business Max (SSO+MFA) $108/year. |
| 14 | https://www.lastpass.com/business | 2025-01-15 | Business features page. Confirms SSO, MFA, audit logs. |
| 15 | https://www.lastpass.com/security | 2025-01-15 | Security page. Zero-knowledge architecture, AES-256 encryption. |
| 16 | https://blog.lastpass.com/2022-LastPass-Hacker-Incident-Update/ | 2025-01-15 | Breach disclosure. Confirms 2022 breach where encrypted vault data, master password hashes, and support ticket data were accessed. |
| 17 | https://www.lastpass.com/compliance | 2025-01-15 | Compliance page. SOC 2 Type II confirmed. |

## Dashlane

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 18 | https://www.dashlane.com/pricing | 2025-01-15 | Pricing page. Extracted: Business $8/user/month, Business Plus $11/user/month (annual billing). Enterprise pricing not publicly listed. |
| 19 | https://www.dashlane.com/business | 2025-01-15 | Business features page. Confirms SSO, audit logs, dark web monitoring. |
| 20 | https://www.dashlane.com/security | 2025-01-15 | Security page. Zero-knowledge architecture. |
| 21 | https://www.dashlane.com/compliance | 2025-01-15 | Compliance page. SOC 2 Type II confirmed. |

## Keeper

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 22 | https://www.keepersecurity.com/pricing/ | 2025-01-15 | Pricing page. Pricing not publicly listed; requires contacting sales. Page mentions "starts at" for Business and Enterprise tiers. |
| 23 | https://www.keepersecurity.com/security/ | 2025-01-15 | Security page. Zero-knowledge architecture. |
| 24 | https://www.keepersecurity.com/features/ | 2025-01-15 | Features page. Confirms SSO, audit logs, compliance reporting. |
| 25 | https://www.keepersecurity.com/compliance/ | 2025-01-15 | Compliance page. SOC 2 Type II and FedRAMP authorization confirmed. |
| 26 | https://www.keepersecurity.com/fedramp/ | 2025-01-15 | FedRAMP page. Confirms FedRAMP authorization. |

## Third-Party Sources

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 27 | https://en.wikipedia.org/wiki/Comparison_of_password_managers | 2025-01-15 | Wikipedia comparison article. General feature comparison. |
| 28 | https://www.pcmag.com/picks/what-are-the-best-password-managers | 2025-01-15 | PCMag review. General product reviews. |
| 29 | https://www.theverge.com/23381204/best-password-manager | 2025-01-15 | The Verge review. General product reviews. |

## Notes on Data Collection

- **1Password pricing:** Extracted from page source JSON data. Business tier: $7.99/user/month (annual), $9.99/user/month (monthly).
- **Bitwarden pricing:** Extracted from page source JSON data. Business Teams: $4.00/user/month (annual), Business Enterprise: $6.00/user/month (annual).
- **LastPass pricing:** Extracted from `/lpapi/purchase/productcatalog` API endpoint. Business: $84/year ($7.00/user/month), Business Max: $108/year ($9.00/user/month).
- **Dashlane pricing:** Extracted from page source JSON-LD data. Business: $8/user/month, Business Plus: $11/user/month.
- **Keeper pricing:** Not publicly listed. Page uses React components that load pricing dynamically. No pricing data found in page source or API endpoints.
