# ADR-002: Evaluation Criteria for Password Manager Selection

## Status
Accepted

## Context
We need to evaluate password managers for a 50-person engineering team at a Series-B SaaS company. The team currently uses shadow-IT password storage (browser, sticky notes, Slack DMs). The CTO wants this fixed in 90 days.

## Decision
We will evaluate products against these criteria, weighted for a Series-B SaaS engineering team:

| # | Criterion | Weight | Rationale |
|---|-----------|--------|-----------|
| 1 | Security posture & incident history | High | Zero-knowledge architecture, no major breaches, independent audits |
| 2 | Developer tooling | High | CLI, SSH agent, CI/CD integration, secret detection in Git repos |
| 3 | SSO integration | High | SAML SSO with Google Workspace (our IdP) for single sign-on |
| 4 | Admin console & audit logging | High | SOC 2 compliance requires audit trails; admin UX affects adoption |
| 5 | Platform coverage | Medium | macOS, Windows, Linux, iOS, Android, browser extensions |
| 6 | Pricing transparency | Medium | Per-seat pricing must be clear; no hidden costs |
| 7 | Vendor stability | Medium | Company funding, customer base, product roadmap |

## Rationale
- **Security posture** is weighted High because a password manager breach would be catastrophic for the company.
- **Developer tooling** is weighted High because our team is engineering-focused; poor developer UX will lead to low adoption.
- **SSO integration** is weighted High because we use Google Workspace as our IdP, and SSO reduces friction.
- **Admin console & audit logging** is weighted High because SOC 2 compliance requires audit trails.
- **Platform coverage** is weighted Medium because all major products support the platforms we need.
- **Pricing transparency** is weighted Medium because we need to budget accurately, but pricing can be negotiated.
- **Vendor stability** is weighted Medium because we need a vendor that will be around for the long term.

## Consequences
- Products that fail on High-weight criteria will be eliminated regardless of price.
- Products that fail on Medium-weight criteria may still be considered if they excel on High-weight criteria.
