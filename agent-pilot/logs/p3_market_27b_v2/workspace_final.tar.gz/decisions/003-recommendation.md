# ADR-003: Recommendation — 1Password Business

## Status
Accepted

## Context
After evaluating 5 password managers (1Password, Bitwarden, LastPass, Dashlane, Keeper) against our criteria, we need to select one for the team.

## Decision
We recommend **1Password Business** at $7.99/user/month on annual billing ($4,794/year for 50 seats).

## Rationale
1. **Best developer experience** — CLI, SSH agent, secret detection in Git repos
2. **Clean security track record** — No major breaches (vs. LastPass 2022 breach)
3. **SOC 2-ready** — Audit logs, admin console, SSO with Google Workspace
4. **Full platform coverage** — macOS, Windows, Linux, iOS, Android, browser extensions, CLI
5. **Transparent pricing** — Public pricing page, no need to contact sales

## Runner-Up
Bitwarden Business Teams at $4.00/user/month ($2,400/year for 50 seats). Choose Bitwarden if:
- Budget is the primary constraint (~50% cheaper)
- Self-hosting is required
- Open-source transparency is a priority

## Alternatives Considered
- **LastPass** — Eliminated due to 2022 security breach
- **Dashlane** — Eliminated due to higher price and lack of developer tooling
- **Keeper** — Eliminated due to pricing opacity (no public per-seat pricing)

## Consequences
- **Vendor lock-in** — 1Password supports CSV/JSON export, but migration cost is non-zero
- **No self-hosting** — If data residency requirements emerge, this could be a limitation
- **Annual commitment** — Annual billing locks in the rate for 12 months
