# ADR-001: Selection of 5 Password Managers for Evaluation

## Status
Accepted

## Context
We need to evaluate password managers for a 50-person engineering team at a Series-B SaaS company. The team currently uses shadow-IT password storage (browser, sticky notes, Slack DMs). The CTO wants this fixed in 90 days.

## Decision
We will evaluate the following 5 password managers:

1. **1Password** — Leading enterprise password manager with strong security posture
2. **Bitwarden** — Open-source, self-hostable option with growing enterprise features
3. **LastPass** — Well-known brand, though with recent security incidents
4. **Dashlane** — Consumer-friendly with enterprise features
5. **Keeper** — Long-standing enterprise security company

## Rationale
These 5 represent the major players in the team/enterprise password manager space:
- Mix of open-source (Bitwarden) and proprietary (1Password, LastPass, Dashlane, Keeper)
- Range of pricing models (per-seat, flat-rate, self-hosted)
- Different security philosophies and incident histories
- All support SSO, admin consoles, and audit logging — key requirements for a SaaS company

## Alternatives Considered
- **Keeper** vs **RoboForm**: Keeper has stronger enterprise features and compliance posture
- **NordPass**: Newer entrant, less enterprise track record
- **Enpass**: Offline-first model, less suitable for team management
- **Zoho Vault**: Part of Zoho ecosystem, but less focused on engineering teams
- **Hashicorp Vault / AWS Secrets Manager**: These are secrets management infrastructure, not password managers for human users
