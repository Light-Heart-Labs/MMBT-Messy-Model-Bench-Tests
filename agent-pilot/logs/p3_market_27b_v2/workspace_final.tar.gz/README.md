# Password Manager Recommendation — How to Read This Output

## Overview
This repository contains the research and recommendation for standardizing a password manager for a 50-person engineering team at a Series-B SaaS company.

## Files

| File | Description |
|------|-------------|
| `recommendation.md` | **Primary deliverable.** 1-2 page recommendation memo with decision criteria, product recommendation, runner-up, and concerns. |
| `comparison.md` | Side-by-side feature/pricing/security comparison of the 5 evaluated products. |
| `sources.md` | Every URL fetched during research, with timestamp and description. |
| `research/notes.md` | Working notes from the research process. |
| `decisions/001-select-5-products.md` | ADR: Which 5 products were selected and why. |
| `decisions/002-evaluation-criteria.md` | ADR: What criteria were used to evaluate products. |
| `decisions/003-recommendation.md` | ADR: Final recommendation and rationale. |

## Quick Start
1. Read `recommendation.md` for the executive summary and recommendation.
2. Read `comparison.md` for the detailed feature/pricing comparison.
3. Read `sources.md` for source verification.
4. Read `decisions/` for the decision-making process.

## Products Evaluated
1. **1Password** — Recommended
2. **Bitwarden** — Runner-up
3. **LastPass** — Eliminated (security breach)
4. **Dashlane** — Eliminated (price/features)
5. **Keeper** — Eliminated (pricing opacity)

## Recommendation
**1Password Business** at $7.99/user/month on annual billing ($4,794/year for 50 seats).
