# Password Manager Recommendation for Engineering Team

**To:** CTO
**From:** Engineering Security Advisory
**Date:** January 2025
**Subject:** Standardize on 1Password Business for 50-Person Engineering Team

---

## Executive Summary

We recommend **1Password Business** as the team's standardized password manager. At **$7.99/user/month** on annual billing, the total cost for 50 seats is **$4,794/year** ($399.50/month). This recommendation balances security posture, developer experience, compliance readiness, and total cost of ownership.

**Runner-up:** Bitwarden Business Teams ($4/user/month, $2,400/year for 50 seats) — choose Bitwarden if budget is the primary constraint or if self-hosting is required.

---

## Decision Criteria

We evaluated products against these criteria, weighted for a Series-B SaaS engineering team:

| # | Criterion | Weight | Rationale |
|---|-----------|--------|-----------|
| 1 | **Security posture & incident history** | High | Zero-knowledge architecture, no major breaches, independent audits |
| 2 | **Developer tooling** | High | CLI, SSH agent, CI/CD integration, secret detection in Git repos |
| 3 | **SSO integration** | High | SAML SSO with Google Workspace (our IdP) for single sign-on |
| 4 | **Admin console & audit logging** | High | SOC 2 compliance requires audit trails; admin UX affects adoption |
| 5 | **Platform coverage** | Medium | macOS, Windows, Linux, iOS, Android, browser extensions |
| 6 | **Pricing transparency** | Medium | Per-seat pricing must be clear; no hidden costs |
| 7 | **Vendor stability** | Medium | Company funding, customer base, product roadmap |

---

## Recommendation: 1Password Business

### Product & Tier
- **Product:** 1Password
- **Tier:** Business
- **Price:** $7.99/user/month on annual billing [[1]](#sources)
- **Annual cost for 50 seats:** 50 × $7.99 × 12 = **$4,794/year**

### Why 1Password

**1. Best-in-class developer experience.** 1Password offers a native CLI tool, SSH agent integration, and secret detection for Git repositories — features that directly address our team's workflow. Engineers can manage secrets from the terminal without context-switching to a browser extension [[2]](#sources).

**2. Clean security track record.** Unlike LastPass (which suffered a major breach in 2022 exposing vault data [[3]](#sources)), 1Password has no history of customer data breaches. Their security architecture is zero-knowledge, and they publish regular security updates [[4]](#sources).

**3. SOC 2-ready audit logging.** The Business tier includes detailed audit logs tracking who accessed what and when — essential for our SOC 2 compliance efforts. The admin console provides visibility into team activity, shared vaults, and security posture [[5]](#sources).

**4. SSO with Google Workspace.** 1Password Business supports SAML 2.0 SSO, enabling integration with our Google Workspace identity provider. This means engineers sign in once and get access to their vault — reducing friction and improving adoption [[6]](#sources).

**5. Full platform coverage.** Native apps for macOS, Windows, Linux, iOS, Android, plus browser extensions for Chrome, Firefox, Safari, and Edge. The CLI tool covers headless/server environments [[7]](#sources).

### Concerns & Risks

| Risk | Severity | Mitigation |
|------|----------|------------|
| **Vendor lock-in** | Medium | 1Password supports standard formats (CSV, JSON) for export. Migration cost is manageable but non-zero. |
| **Pricing increases** | Low | 1Password has a history of stable pricing. Annual billing locks in the rate for 12 months. |
| **No self-hosting option** | Low | Unlike Bitwarden, 1Password is cloud-only. If data residency requirements emerge, this could be a limitation. |
| **Secret detection requires Business tier** | Low | Already covered by our recommended tier. |

---

## Runner-Up: Bitwarden Business Teams

### Product & Tier
- **Product:** Bitwarden
- **Tier:** Business Teams
- **Price:** $4.00/user/month on annual billing [[8]](#sources)
- **Annual cost for 50 seats:** 50 × $4.00 × 12 = **$2,400/year**

### When Bitwarden Would Beat 1Password

Choose Bitwarden if:
1. **Budget is the primary constraint** — Bitwarden is ~50% cheaper ($2,400 vs $4,794/year).
2. **Self-hosting is required** — Bitwarden is open-source and can be self-hosted, giving full control over data residency and infrastructure [[9]](#sources).
3. **Open-source transparency is a priority** — Bitwarden's client and server code are fully open-source, allowing independent verification of security claims [[10]](#sources).

### Trade-offs vs. 1Password
- **Developer tooling:** Bitwarden's CLI is functional but less polished than 1Password's. No native SSH agent integration.
- **Admin UX:** Bitwarden's admin console is more utilitarian; 1Password's is more refined.
- **Secret detection:** Bitwarden does not offer automated secret scanning in Git repos (a 1Password differentiator).
- **Brand recognition:** 1Password has stronger brand recognition, which may reduce friction in onboarding.

---

## Why Not the Others?

### LastPass
**Eliminated due to security incident history.** LastPass suffered a major breach in 2022 where attackers obtained encrypted vault data, master password hashes, and support ticket data [[3]](#sources). While the vault data was encrypted, the incident eroded trust and highlighted architectural concerns. For a SaaS company preparing for SOC 2, choosing a vendor with a recent major breach is hard to justify to auditors and customers.

### Dashlane
**Eliminated due to pricing and feature gaps.** Dashlane Business is $8/user/month [[11]](#sources), slightly more expensive than 1Password, but lacks 1Password's developer-focused features (SSH agent, secret detection, polished CLI). Dashlane's strength is its digital wallet feature, which is not relevant for our engineering team's use case.

### Keeper
**Eliminated due to pricing opacity.** Keeper does not publish transparent per-seat pricing on their website — pricing is listed as "starts at" with no clear per-user cost [[12]](#sources). For a 50-seat purchase, this means contacting sales, which adds friction and uncertainty. Keeper's strength is FedRAMP authorization, which is not a requirement for our current compliance needs.

---

## Implementation Timeline (90 Days)

| Phase | Timeline | Activities |
|-------|----------|------------|
| **Week 1-2** | Days 1-14 | Procure 1Password Business licenses; configure SSO with Google Workspace |
| **Week 3-4** | Days 15-28 | Set up team vaults; migrate critical credentials; train admin team |
| **Week 5-8** | Days 29-56 | Roll out to all 50 engineers; enable secret detection in Git repos; disable shadow-IT storage |
| **Week 9-12** | Days 57-84 | Enforce usage policy; audit adoption; integrate with CI/CD pipelines |

---

## Sources

<a id="sources"></a>

[[1]] https://1password.com/pricing/ — 1Password Business pricing: $7.99/user/month on annual billing, $9.99/user/month on monthly billing. Extracted from page source JSON data.

[[2]] https://1password.com/features/ — 1Password developer features: CLI tool, SSH agent, secret detection for Git repositories.

[[3]] https://blog.lastpass.com/2022-LastPass-Hacker-Incident-Update/ — LastPass 2022 breach disclosure: encrypted vault data, master password hashes, and support ticket data were accessed by attackers.

[[4]] https://1password.com/security/ — 1Password security architecture: zero-knowledge encryption, regular security audits, no history of customer data breaches.

[[5]] https://1password.com/business/ — 1Password Business admin features: audit logs, admin console, SSO support, shared vaults.

[[6]] https://1password.com/business/ — 1Password SSO support: SAML 2.0 SSO integration with Google Workspace and other identity providers.

[[7]] https://1password.com/downloads/ — 1Password platform coverage: native apps for macOS, Windows, Linux, iOS, Android; browser extensions for Chrome, Firefox, Safari, Edge; CLI tool.

[[8]] https://bitwarden.com/pricing/ — Bitwarden Business Teams pricing: $4.00/user/month on annual billing, $6.00/user/month for Business Enterprise. Extracted from page source JSON data.

[[9]] https://bitwarden.com/help/article/self-host/ — Bitwarden self-hosting: open-source, self-hostable option available for full control over data residency.

[[10]] https://github.com/bitwarden — Bitwarden open-source: client and server code fully open-source on GitHub.

[[11]] https://www.dashlane.com/pricing — Dashlane Business pricing: $8/user/month for Business tier, $11/user/month for Business Plus. Extracted from page source JSON-LD data.

[[12]] https://www.keepersecurity.com/pricing/ — Keeper pricing: not publicly listed; requires contacting sales. Page mentions "starts at" for Business and Enterprise tiers but no specific per-user cost.
