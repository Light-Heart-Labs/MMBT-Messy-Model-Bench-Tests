# Research Notes - Password Manager Evaluation

## Date: 2025-01-15

## Products Evaluated
1. 1Password
2. Bitwarden
3. LastPass
4. Dashlane
5. Keeper

## Key Findings

### 1Password
- Business tier: $7.99/user/month (annual billing), $9.99/user/month (monthly billing)
- Source: https://1password.com/pricing/
- Features: SSO, audit logs, secret detection, CLI, SSH agent, developer tools
- Security: Zero-knowledge, open-source security audit, SOC 2 Type II
- Platforms: macOS, Windows, Linux, iOS, Android, browser extensions, CLI

### Bitwarden
- Business Teams: $4/user/month (annual billing)
- Business Enterprise: $6/user/month (annual billing)
- Source: https://bitwarden.com/pricing/
- Features: Open-source, self-hostable, SSO, audit logs, CLI
- Security: Zero-knowledge, open-source, SOC 2 Type II
- Platforms: All major platforms, self-hosted option

### LastPass
- Business: $84/year = $7/user/month (annual billing)
- Business Max (SSO+MFA): $108/year = $9/user/month (annual billing)
- Source: https://www.lastpass.com/lpapi/purchase/productcatalog
- Features: SSO, MFA, audit logs, password sharing
- Security: Zero-knowledge, but had major breach in 2022
- Platforms: All major platforms

### Dashlane
- Business: $8/user/month (annual billing)
- Business Plus: $11/user/month (annual billing)
- Source: https://www.dashlane.com/pricing
- Features: SSO, audit logs, dark web monitoring, digital wallet
- Security: Zero-knowledge, SOC 2 Type II
- Platforms: All major platforms

### Keeper
- Business: Pricing not publicly listed (starts at some amount per user per month)
- Enterprise: Pricing not publicly listed
- Source: https://www.keepersecurity.com/pricing
- Features: SSO, audit logs, compliance reporting
- Security: Zero-knowledge, FedRAMP authorized
- Platforms: All major platforms

## Security Incident History
- LastPass: Major breach in 2022, customer data exposed
- 1Password: No major breaches
- Bitwarden: No major breaches
- Dashlane: No major breaches
- Keeper: No major breaches

## Compliance
- 1Password: SOC 2 Type II
- Bitwarden: SOC 2 Type II
- LastPass: SOC 2 Type II
- Dashlane: SOC 2 Type II
- Keeper: SOC 2 Type II, FedRAMP

## Recommendation
1Password Business tier at $7.99/user/month (annual billing) = $3,995/year for 50 seats
