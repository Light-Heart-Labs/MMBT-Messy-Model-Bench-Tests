# Password Manager Recommendation for Engineering Team

**To:** CTO  
**From:** Security Advisory  
**Date:** June 2025  
**Subject:** Standardizing on 1Password Business for 50-Person Engineering Team  

---

## Executive Summary

After evaluating five password managers — 1Password, Bitwarden, Dashlane, Keeper, and LastPass — we recommend **1Password Business** as the standard password manager for our 50-person engineering team.

**Recommended product:** 1Password Business  
**Recommended tier:** Business (annual billing)  
**Per-seat cost:** $7.99/user/month, billed annually  
**Total annual cost:** $4,794/year ($7.99 × 50 users × 12 months)  

**Runner-up:** Bitwarden Teams at $4/user/month ($2,400/year for 50 seats), which would beat 1Password if budget is the primary constraint and open-source transparency is valued over polished admin UX.

---

## Decision Criteria

We established the following criteria, in order of importance:

### Required (Must-Have)
1. **SOC 2 Type 2 compliance** — Required for our own SOC 2 audit; the password manager must provide a SOC 2 report to our auditors [1]
2. **SSO integration with Google Workspace** — Our team uses Google Workspace for identity; SSO is essential for a smooth 90-day rollout [2]
3. **Audit logging** — Must provide admin-visible audit logs of who accessed what and when [3]
4. **Transparent pricing** — Per-seat pricing must be publicly available; "contact sales" is a disqualifier for a Series-B company that needs budget predictability

### Important (Should-Have)
5. **Developer tooling** — CLI, API, and CI/CD integration (GitHub, GitLab, etc.) for engineering team adoption [4]
6. **Mobile + desktop coverage** — Must support macOS, Windows, Linux, iOS, and Android [5]
7. **Admin UX** — Self-service admin console for onboarding, policy management, and user lifecycle [6]
8. **Security track record** — No major public breaches in the last 5 years

### Nice-to-Have
9. **Open source** — Code auditable by our security team
10. **Self-hosting option** — Ability to host on our own infrastructure
11. **FedRAMP / ISO 27001** — Additional compliance certifications

---

## Recommendation: 1Password Business

### Why 1Password?

1Password Business is the strongest overall fit for our team because it:

- **Meets all required criteria:** SOC 2 Type 2 certified [7], SSO with Google Workspace [8], comprehensive audit logging [9], and transparent public pricing [10]
- **Has excellent developer tooling:** Native CLI (`op` command), Secrets Automation for CI/CD, GitHub/GitLab integrations, and a REST API [11]
- **Covers all platforms:** macOS, Windows, Linux, iOS, Android, and browser extensions for Chrome, Firefox, Safari, and Edge [12]
- **Has a clean security track record:** No major public breaches; maintains a bug bounty program on HackerOne [13]
- **Has a polished admin console:** Self-service user provisioning, policy management, and compliance reporting [14]

### Pricing

| Item | Value |
|------|-------|
| Tier | 1Password Business |
| Per-seat price | $7.99/user/month (annual billing) [10] |
| Monthly billing alternative | $9.99/user/month [10] |
| Seats | 50 |
| **Annual total** | **$4,794** ($7.99 × 50 × 12) |
| Monthly total (if monthly billing) | $5,994 ($9.99 × 50 × 12) |

### 90-Day Rollout Plan

1. **Week 1-2:** Set up 1Password Business org, configure SSO with Google Workspace, define sharing policies
2. **Week 3-4:** Onboard engineering leads and admins, migrate critical shared credentials
3. **Week 5-8:** Roll out to full team, provide training, migrate browser-saved passwords
4. **Week 9-12:** Enforce policies, disable shadow-IT storage (Slack DMs, sticky notes), conduct audit

---

## Runner-Up: Bitwarden Teams

**Bitwarden Teams** at $4/user/month ($2,400/year for 50 seats) is the clear runner-up [15].

### When Bitwarden Would Beat 1Password

Choose Bitwarden instead if:
- **Budget is the primary constraint:** Bitwarden is 50% cheaper ($2,400 vs $4,794 annually)
- **Open-source transparency is valued:** Bitwarden's code is fully open source and auditable [16]
- **Self-hosting is desired:** Bitwarden can be self-hosted on your own infrastructure [17]
- **Your team is comfortable with a less polished admin UX:** Bitwarden's admin console is functional but less refined than 1Password's

### Bitwarden's Advantages
- SOC 2 Type II and SOC 3 certified [18]
- ISO 27001 certified [18]
- HIPAA compliant [18]
- Open source (client and server) [16]
- Self-hosting available [17]
- CLI tooling (`bw` command) [19]

### Bitwarden's Disadvantages vs. 1Password
- Less polished admin console and onboarding experience
- Fewer native CI/CD integrations (no equivalent to 1Password Secrets Automation)
- No equivalent to 1Password's "Watchtower" breach monitoring
- Less mature mobile app experience

---

## Concerns and Risks with 1Password

### Vendor Lock-in
1Password is proprietary software. Migrating away would require exporting all vault data and reconfiguring integrations. Mitigation: 1Password supports standard CSV/KeeperXML export formats.

### Pricing Increases
As a private company, 1Password could increase prices with limited notice. Mitigation: Annual billing locks in pricing for 12 months.

### No Self-Hosting Option
1Password is cloud-only. If our compliance requirements evolve to require on-premises hosting, we would need to migrate. Mitigation: Monitor compliance requirements; Bitwarden is the fallback for self-hosting needs.

### No FedRAMP Certification
1Password is SOC 2 Type 2 certified but does not have FedRAMP authorization. This is not a concern for our current use case (private SaaS company) but could be if we pursue government contracts.

### Security Incident History
1Password has not had a major public breach. However, as a cloud-hosted service, any future incident could impact our team. Mitigation: 1Password uses zero-knowledge architecture, meaning they cannot access our encrypted vault data even if compromised.

---

## Why the Other Products Were Not Recommended

### Dashlane
- **Pricing:** $11/user/month is the most expensive option evaluated [20]
- **No transparent public pricing** for all tiers; some pricing requires contact
- **No major security incidents** but less mature developer tooling than 1Password
- **Compliance data** not as prominently documented as 1Password or Bitwarden

### Keeper
- **Pricing not publicly listed:** Keeper's pricing is JS-rendered and requires contact or dynamic rendering to view [21]
- **Strongest compliance certifications:** FedRAMP High, ISO 27001/27017/27018, SOC 2 Type 2 (10+ years) [22]
- **Overkill for our use case:** Keeper is strongest in government and highly regulated sectors
- **Opaque pricing is a risk** for a Series-B company that needs budget predictability

### LastPass
- **Major security breach in January 2022:** Attackers stole encrypted vault data, master password hashes, and other sensitive data [23]
- **Pricing not publicly listed:** LastPass's pricing is JS-rendered and not visible in static HTML [24]
- **Disqualified on security grounds:** A password manager that has been breached is not suitable for storing our team's credentials
- **Even if pricing were transparent,** the security incident history makes LastPass unacceptable for a company preparing for SOC 2 audit

---

## Sources

[1] 1Password Security page: https://1password.com/security/ — "1Password is SOC 2 type 2 certified"  
[2] 1Password SSO documentation: https://1password.com/business/ — SSO with Google Workspace  
[3] 1Password audit logging: https://1password.com/business/ — Admin audit logs  
[4] 1Password developer tools: https://1password.com/downloads/command-line/ — CLI, API, CI/CD  
[5] 1Password platform support: https://1password.com/downloads/ — macOS, Windows, Linux, iOS, Android  
[6] 1Password admin console: https://1password.com/business/ — Self-service admin  
[7] 1Password SOC 2: https://1password.com/security/ — "SOC 2 type 2 certified"  
[8] 1Password SSO: https://1password.com/business/ — SSO integration  
[9] 1Password audit logs: https://1password.com/business/ — Audit logging  
[10] 1Password pricing: https://1password.com/business-pricing/ — $7.99/user/month (annual)  
[11] 1Password Secrets Automation: https://1password.com/products/secrets-automation/ — CI/CD integration  
[12] 1Password downloads: https://1password.com/downloads/ — All platforms  
[13] 1Password bug bounty: https://hackerone.com/1password — Bug bounty program  
[14] 1Password admin: https://1password.com/business/ — Admin console  
[15] Bitwarden pricing: https://bitwarden.com/pricing/business/ — $4/user/month (Teams), $6/user/month (Enterprise)  
[16] Bitwarden open source: https://github.com/bitwarden — Open source codebase  
[17] Bitwarden self-hosting: https://bitwarden.com/help/article/self-hosted-vault-server/ — Self-hosting  
[18] Bitwarden compliance: https://bitwarden.com/compliance/ — SOC 2, ISO 27001, HIPAA  
[19] Bitwarden CLI: https://bitwarden.com/help/article/cli/ — CLI tooling  
[20] Dashlane pricing: https://www.dashlane.com/pricing — $11/user/month (from page source)  
[21] Keeper pricing: https://www.keepersecurity.com/pricing/business-and-enterprise.html — JS-rendered, not publicly listed  
[22] Keeper compliance: https://www.keepersecurity.com/security.html — FedRAMP High, ISO 27001, SOC 2  
[23] LastPass breach: https://blog.lastpass.com/2022-01-security-breach-update/ — January 2022 breach  
[24] LastPass pricing: https://www.lastpass.com/features/business — JS-rendered, not publicly listed  
