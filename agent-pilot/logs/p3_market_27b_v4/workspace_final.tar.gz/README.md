# Password Manager Recommendation — How to Read This Output

## Overview

This repository contains the research and recommendation for standardizing a password manager for a 50-person engineering team at a Series-B SaaS company.

## Files

| File | Description |
|------|-------------|
| `recommendation.md` | **Primary deliverable.** 1-2 page recommendation memo with decision criteria, product recommendation, pricing, runner-up, and concerns. |
| `comparison.md` | Side-by-side feature/pricing/security comparison of the 5 products evaluated. |
| `sources.md` | Every URL fetched during research, with timestamp and description of what was obtained. |
| `research/notes.md` | Working notes from the research process. |
| `decisions/adr-001-products-selected.md` | ADR explaining which 5 products were selected and why. |
| `decisions/adr-002-decision-criteria.md` | ADR explaining the decision criteria used for evaluation. |

## Quick Start

1. Read `recommendation.md` for the executive summary and final recommendation.
2. Read `comparison.md` for the detailed side-by-side comparison.
3. Read `sources.md` to verify any factual claim.
4. Read the ADRs in `decisions/` for context on methodology.

## Products Evaluated

1. **1Password** (Business tier) — Recommended
2. **Bitwarden** (Teams and Enterprise tiers) — Runner-up
3. **Dashlane** (Business tier)
4. **Keeper** (Business and Enterprise tiers)
5. **LastPass** (Business tier)

## Key Findings

- **Recommended:** 1Password Business at $7.99/user/month ($4,794/year for 50 seats)
- **Runner-up:** Bitwarden Teams at $4.00/user/month ($2,400/year for 50 seats)
- **Disqualified:** LastPass due to January 2022 security breach
- **Concerns:** Keeper and LastPass have opaque pricing (JS-rendered, not publicly listed)

## Data Quality Notes

- Pricing for 1Password and Bitwarden was directly extracted from page source. High confidence.
- Pricing for Dashlane was extracted from a `customPrice` field. Medium confidence.
- Pricing for Keeper and LastPass is not publicly available in static HTML. These are flagged as concerns.
- Compliance data was cross-checked on company trust/security pages, not marketing pages.
