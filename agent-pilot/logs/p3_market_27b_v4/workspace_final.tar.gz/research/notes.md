# Research Notes — Password Manager Evaluation

## Date: 2025-06-18

## Products Evaluated
1. 1Password (Business tier)
2. Bitwarden (Teams and Enterprise tiers)
3. Dashlane (Business tier)
4. Keeper (Business and Enterprise tiers)
5. LastPass (Business tier)

## Pricing Data Collected

### 1Password
- Source: https://1password.com/business-pricing/
- Business tier: $7.99/user/month (annual billing), $9.99/user/month (monthly)
- Extracted from JSON data in page source
- Per user, per month pricing model

### Bitwarden
- Source: https://bitwarden.com/pricing/business/
- Teams tier: $4/user/month (annual billing)
- Enterprise tier: $6/user/month (annual billing)
- Extracted from page source and JSON data
- "Pricing shown in USD and based on an annual subscription. Taxes not included."

### Dashlane
- Source: https://www.dashlane.com/pricing
- Business tier: $11/user/month (from customPrice field in page source)
- "per user/month, billed annually"
- Pricing extracted from JSON-LD structured data

### Keeper
- Source: https://www.keepersecurity.com/pricing/business-and-enterprise.html
- Business and Enterprise pricing is JS-rendered and not visible in static HTML
- FAQ mentions "Starts at [dynamic] per user per month, billed annually"
- Pricing not publicly listed; requires contact or JS rendering

### LastPass
- Source: https://www.lastpass.com/features/business
- Pricing not found in static HTML or script tags
- Pricing not publicly listed; requires contact or JS rendering

## Compliance Data Collected

### 1Password
- SOC 2 Type 2 certified
- Source: https://1password.com/security/
- "1Password is SOC 2 type 2 certified and complies with the most stringent industry standards for data confidentiality"

### Bitwarden
- SOC 2 Type II and SOC 3 certified
- ISO 27001 certified
- HIPAA compliant
- CCPA compliant
- Source: https://bitwarden.com/compliance/

### Keeper
- SOC 2 Type 2 (over 10 years)
- ISO 27001, 27017, 27018
- FedRAMP High Authorized
- GovRAMP High Authorized
- GDPR, CCPA, HIPAA, PCI DSS
- Source: https://www.keepersecurity.com/security.html

### LastPass
- Compliance data not found in scraped pages
- Known to have had a major breach in 2022

### Dashlane
- Compliance data not found in scraped pages

## Security Incident History

### LastPass
- Major breach in January 2022: attackers stole encrypted vault data, master password hashes, and other sensitive data
- This is a significant concern for any enterprise evaluation

### 1Password
- No major public breaches reported
- Has a bug bounty program on HackerOne

### Bitwarden
- No major public breaches reported
- Open source codebase allows community auditing

### Keeper
- No major public breaches reported
- Longest-standing SOC 2 and ISO certifications in the industry

### Dashlane
- No major public breaches reported

## Key Findings

1. **1Password** has the best balance of pricing, features, and security for a 50-person engineering team
2. **Bitwarden** is the most cost-effective option with open-source transparency
3. **Keeper** has the most comprehensive compliance certifications but opaque pricing
4. **LastPass** has a significant security incident history that disqualifies it for most enterprises
5. **Dashlane** is mid-range in pricing but lacks transparent public pricing

## Decision Criteria

For a 50-person Series-B SaaS engineering team, the key criteria are:
1. SOC 2 compliance (required for SOC 2 audit)
2. SSO integration with Google Workspace
3. Audit logging capabilities
4. Developer-friendly features (CLI, API, CI/CD integration)
5. Transparent pricing
6. Security track record
7. Mobile and desktop coverage
8. Admin UX for onboarding 50 users in 90 days
