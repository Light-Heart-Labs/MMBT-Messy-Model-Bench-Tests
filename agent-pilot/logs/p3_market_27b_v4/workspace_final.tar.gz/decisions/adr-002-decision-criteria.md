# ADR-002: Decision Criteria

## Status
Accepted

## Context
We need to define objective criteria for evaluating password managers for a 50-person engineering team at a Series-B SaaS company.

## Decision
The following criteria were established, in order of importance:

### Required (Must-Have)
1. **SOC 2 Type 2 compliance** — Required for our own SOC 2 audit; the password manager must be able to provide a SOC 2 report to our auditors
2. **SSO integration with Google Workspace** — Our team uses Google Workspace for identity; SSO is essential for a smooth 90-day rollout
3. **Audit logging** — Must provide admin-visible audit logs of who accessed what and when
4. **Transparent pricing** — Per-seat pricing must be publicly available; "contact sales" is a disqualifier for a Series-B company that needs budget predictability

### Important (Should-Have)
5. **Developer tooling** — CLI, API, and CI/CD integration (GitHub, GitLab, etc.) for engineering team adoption
6. **Mobile + desktop coverage** — Must support macOS, Windows, Linux, iOS, and Android
7. **Admin UX** — Self-service admin console for onboarding, policy management, and user lifecycle
8. **Security track record** — No major public breaches in the last 5 years

### Nice-to-Have
9. **Open source** — Code auditable by our security team
10. **Self-hosting option** — Ability to host on our own infrastructure
11. **FedRAMP / ISO 27001** — Additional compliance certifications

## Rationale
- SOC 2 is non-negotiable for a Series-B SaaS company preparing for enterprise sales
- SSO with Google Workspace is critical because we don't want to manage a separate identity system
- Transparent pricing is essential because we need to budget for 50 seats and can't afford surprise costs
- Developer tooling is important because our team uses CLI tools, CI/CD pipelines, and needs to integrate password management into their workflow

## Consequences
- Products without transparent pricing (Keeper, LastPass) are at a significant disadvantage
- Products without SOC 2 compliance would be disqualified
- Products with major security breaches (LastPass) are at a significant disadvantage
