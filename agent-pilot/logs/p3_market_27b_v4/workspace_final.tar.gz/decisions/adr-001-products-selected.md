# ADR-001: Products Selected for Evaluation

## Status
Accepted

## Context
We need to evaluate password managers for a 50-person engineering team at a Series-B SaaS company. The team currently has shadow-IT password storage (browser, sticky notes, Slack DMs) and the new CTO wants this fixed in the next 90 days.

## Decision
We selected the following 5 password managers for evaluation:

1. **1Password** — Market leader in enterprise password management, strong developer tooling
2. **Bitwarden** — Open-source, most cost-effective, growing enterprise adoption
3. **Dashlane** — Well-known consumer brand with business offerings
4. **Keeper** — Longest-standing compliance certifications, strong government sector presence
5. **LastPass** — Historically popular, but included due to market presence (despite security concerns)

## Rationale
- These 5 represent the most commonly recommended password managers for teams of this size
- They span the pricing spectrum (from $4/user/month to $11+/user/month)
- They include both open-source (Bitwarden) and proprietary options
- They cover different compliance postures (from SOC 2 only to FedRAMP High)

## Consequences
- LastPass is included despite its 2022 breach because it remains a market player and its exclusion is itself a finding
- Keeper and LastPass have opaque pricing, which is itself a risk factor
- We did not evaluate CyberArk, Delinea, or BeyondTrust as those are PAM (Privileged Access Management) products, not password managers for general engineering use
