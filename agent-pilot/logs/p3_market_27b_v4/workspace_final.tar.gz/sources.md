# Sources

Every URL fetched during this research, with timestamp and description.

## 1Password

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 1 | https://1password.com/pricing/ | 2025-06-18 | 1Password pricing page; extracted pricing data from JSON in page source |
| 2 | https://1password.com/business-pricing/ | 2025-06-18 | 1Password Business pricing; confirmed $7.99/user/month (annual), $9.99/user/month (monthly) |
| 3 | https://1password.com/security/ | 2025-06-18 | 1Password security page; confirmed SOC 2 Type 2 certification, bug bounty on HackerOne |
| 4 | https://1password.com/trust/ | 2025-06-18 | 1Password trust center; compliance information |
| 5 | https://1password.com/business/ | 2025-06-18 | 1Password Business product page; SSO, audit logging, admin features |
| 6 | https://1password.com/downloads/ | 2025-06-18 | 1Password downloads; platform support (macOS, Windows, Linux, iOS, Android, browser extensions) |
| 7 | https://1password.com/downloads/command-line/ | 2025-06-18 | 1Password CLI tool; developer tooling |
| 8 | https://1password.com/products/secrets-automation/ | 2025-06-18 | 1Password Secrets Automation; CI/CD integration |
| 9 | https://hackerone.com/1password | 2025-06-18 | 1Password bug bounty program on HackerOne |

## Bitwarden

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 10 | https://bitwarden.com/pricing/business/ | 2025-06-18 | Bitwarden business pricing; confirmed $4/user/month (Teams), $6/user/month (Enterprise) |
| 11 | https://bitwarden.com/compliance/ | 2025-06-18 | Bitwarden compliance page; confirmed SOC 2 Type II, SOC 3, ISO 27001, HIPAA, CCPA |
| 12 | https://bitwarden.com/security/ | 2025-06-18 | Bitwarden security page; zero-knowledge architecture, bug bounty |
| 13 | https://bitwarden.com/help/article/cli/ | 2025-06-18 | Bitwarden CLI documentation; developer tooling |
| 14 | https://github.com/bitwarden | 2025-06-18 | Bitwarden GitHub repository; open source codebase |
| 15 | https://bitwarden.com/help/article/self-hosted-vault-server/ | 2025-06-18 | Bitwarden self-hosting documentation |
| 16 | https://bitwarden.com/download/ | 2025-06-18 | Bitwarden downloads; platform support |

## Dashlane

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 17 | https://www.dashlane.com/pricing | 2025-06-18 | Dashlane pricing page; extracted $11/user/month from customPrice field in page source |
| 18 | https://www.dashlane.com/business-password-manager | 2025-06-18 | Dashlane Business product page; features overview |
| 19 | https://www.dashlane.com/security | 2025-06-18 | Dashlane security page; zero-knowledge architecture |
| 20 | https://www.dashlane.com/download | 2025-06-18 | Dashlane downloads; platform support |
| 21 | https://www.dashlane.com/developers | 2025-06-18 | Dashlane developer tools; API documentation |

## Keeper

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 22 | https://www.keepersecurity.com/pricing/business-and-enterprise.html | 2025-06-18 | Keeper business pricing; pricing is JS-rendered and not visible in static HTML |
| 23 | https://www.keepersecurity.com/business.html | 2025-06-18 | Keeper Business product page; features overview |
| 24 | https://www.keepersecurity.com/security.html | 2025-06-18 | Keeper security page; confirmed SOC 2 Type 2 (10+ years), ISO 27001/27017/27018, FedRAMP High, HIPAA, GDPR, CCPA, PCI DSS |
| 25 | https://www.keepersecurity.com/developer/ | 2025-06-18 | Keeper developer tools; API, CLI |
| 26 | https://www.keepersecurity.com/download.html | 2025-06-18 | Keeper downloads; platform support |
| 27 | https://www.keepersecurity.com/pricing/business-add-ons/ | 2025-06-18 | Keeper business add-ons pricing; no pricing data found |

## LastPass

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 28 | https://www.lastpass.com/features/business | 2025-06-18 | LastPass Business features page; pricing is JS-rendered and not visible in static HTML |
| 29 | https://blog.lastpass.com/2022-01-security-breach-update/ | 2025-06-18 | LastPass January 2022 security breach; attackers stole encrypted vault data, master password hashes |

## Comparison / Third-Party

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 30 | https://www.capterra.com/password-management-software/ | 2025-06-18 | Capterra password management comparison; limited pricing data |
| 31 | https://www.g2.com/products/keeper/reviews | 2025-06-18 | G2 Keeper reviews; no pricing data found |

## Notes on Data Quality

- **1Password and Bitwarden:** Pricing data was successfully extracted from page source JSON. High confidence.
- **Dashlane:** Pricing ($11/user/month) was extracted from a `customPrice` field in the page source. Medium confidence; may not reflect all tier options.
- **Keeper:** Pricing is dynamically rendered via JavaScript and not available in static HTML. The FAQ mentions "Starts at [dynamic] per user per month, billed annually" but the actual numbers are not in the static page. Low confidence; requires contact or JS rendering.
- **LastPass:** Pricing is dynamically rendered via JavaScript and not available in static HTML. Low confidence; requires contact or JS rendering.
- **Compliance data:** Cross-checked on company trust/security pages rather than blog posts or marketing pages.
