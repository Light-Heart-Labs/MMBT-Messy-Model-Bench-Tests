# Nimbus Logistics, Inc. — Investment Brief Package

## Files

- `brief.md` — The 1-page executive brief (598 words). This is the primary deliverable.
- `key-facts.md` — A list of every material fact incorporated into the brief, with source attribution.
- `research/notes.md` — Working notes from reading the five sources, including tensions and contradictions.
- `decisions/adr.md` — ADR-style records for framing choices (recommendation stance, narrative flow, omissions).
- `README.md` — This file.

## How to Read This Package

1. **Start with `brief.md`** — This is the deliverable for the investor. It leads with a clear recommendation (PASS), cites sources inline, and synthesizes the five documents.

2. **Check `key-facts.md`** — This verifies that every metric in the brief traces to one of the five sources. No invented numbers.

3. **Review `research/notes.md`** — This shows the reasoning process: how the sources were read, what tensions were identified, and how source quality was assessed.

4. **Read `decisions/adr.md`** — This documents the non-obvious framing choices (e.g., why PASS instead of "more diligence needed").

## Source Key

- **Source 1**: Press release (company-issued)
- **Source 2**: TechCrunch news article
- **Source 3**: Former-employee blog post
- **Source 4**: Leaked internal memo
- **Source 5**: SEC Form D filing summary

## Key Takeaway

The press release tells a story of growth. The other four sources tell a story of repricing, churn, and strategic retreat. The brief synthesizes these to recommend passing on the follow-on investment.
