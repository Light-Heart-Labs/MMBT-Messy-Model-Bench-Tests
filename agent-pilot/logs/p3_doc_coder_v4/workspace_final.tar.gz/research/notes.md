# Working Notes — Nimbus Logistics, Inc. Source Review

## Key Facts Extracted

### Valuation & Funding
- Series B closed $84M at $560M post-money (Source 1)
- Total funding to date: $128M (Source 1)
- SEC Form D filed 2026-01-22, 7 investors (Source 5)
- TechCrunch reports Series B was initially meant to close at $720M in late 2025 but repriced down after Sundry non-renewal (Source 2)
- Internal memo mentions $50M credit facility from Silicon Valley Bridge (Source 4)

### Financial Metrics
- ARR reported as $42M as of Q4 2025 (Source 1)
- ARR was $11M a year prior (Source 1)
- TechCrunch: adjusted for December churn, run-rate is $36-37M (Source 2)
- Former employee: company spending ~$4M/month all-in vs ~$3.5M/month revenue (Source 3)
- Internal memo: burn rate context confirms negative cash flow (Source 4)

### Customer Base & Churn
- 1,400 customers (Source 1)
- Top 5 customers = ~38% of ARR (Source 3)
- Lost Sundry Brands ($4.2M ARR) in November 2025 (Source 2, 3)
- Lost Klatch (fast-fashion) in December 2025 (Source 2)
- CEO claims 3 new $1M+ ARR contracts signed in Q1 (Source 2)
- CEO claims net retention >110% (Source 2)
- Internal memo: ~310 customers on "Nimbus Lite" ($5K-$20K ARR each) to be migrated out (Source 4)

### Operations & Strategy
- 187 employees across Oakland, Austin, Berlin (Source 1)
- Layoffs in February 2025: 22 people (~11% of org), mostly customer success & BD (Source 3)
- Internal memo: 30% reduction in international headcount, Berlin from 41 to ~28-30 by end of Q2 (Source 4)
- Berlin office to become "support hub" instead of sales/expansion (Source 4)
- "Nimbus Lite" tier to be sunset (Source 4)
- International expansion deferred to 2027 (Source 4)
- Path to cash-flow breakeven by Q4 2026 (Source 4)

### Founders & Leadership
- CEO: Mira Patel (Source 1)
- CTO: Daniel Wong (Source 1, 3)
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (Source 1)

## Tensions & Contradictions

1. **Valuation**: Press release says $560M post-money; TechCrunch says Series B was meant to close at $720M but repriced down (Source 1 vs Source 2)

2. **ARR**: Press release says $42M; TechCrunch says adjusted for churn it's $36-37M; former employee says revenue ~$3.5M/month ($42M annualized) but burn ~$4M/month (Source 1 vs Source 2 vs Source 3)

3. **Growth Narrative**: Press release says "doubled valuation", "accelerate expansion"; TechCrunch says lost top customer, repriced round; internal memo says international expansion deferred, layoffs planned (Source 1 vs Source 2 vs Source 4)

4. **Customer Concentration**: Press release doesn't mention; former employee says top 5 = 38% of ARR; internal memo shows plan to shed low-tier customers (Source 1 vs Source 3 vs Source 4)

5. **Runway**: Press release says "new capital brings total to $128M"; internal memo says Series B gives 24+ months runway, credit facility extends to 36+ months (Source 1 vs Source 4)

## Source Quality Assessment

- **Source 1 (Press Release)**: Company narrative, optimistic, omits negatives
- **Source 2 (TechCrunch)**: Journalistic, cites anonymous sources, contradicts press release on key points
- **Source 3 (Blog Post)**: First-hand employee perspective, balanced (good and bad), but subjective
- **Source 4 (Leaked Memo)**: Internal strategy, reveals painful decisions, likely most accurate on operational reality
- **Source 5 (SEC Form D)**: Factual filing, confirms funding but no narrative

## Key Questions for Investor

1. Is $36-37M ARR (adjusted) the right baseline, not $42M?
2. Is the company burning cash ($4M/month burn vs ~$3.5M revenue) and if so, is the path to breakeven credible?
3. Is customer concentration risk (top 5 = 38% ARR) manageable or a red flag?
4. Are the planned cuts (30% international, sunsetting Lite tier) sufficient to reach cash-flow breakeven?
5. Is the $50M credit facility a sign of strength (runway extension) or weakness (needing insurance)?
