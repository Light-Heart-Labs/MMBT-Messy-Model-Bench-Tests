# ADR: Executive Brief Framing for Nimbus Logistics

## Decision: Recommendation Stance

**Recommendation: PASS on follow-on investment, with clear conditions for reconsideration.**

### Rationale

The company presents a compelling growth story in its press release, but the other four sources reveal significant tensions:

- **Valuation appears inflated**: Series B repriced from $720M to $560M post-money (Source 2), suggesting investor skepticism emerged during the round.
- **ARR is overstated**: $42M reported ARR includes customers that churned in December; adjusted run-rate is $36-37M (Source 2).
- **Negative cash flow**: Company burning ~$500K/month ($4M burn vs ~$3.5M revenue) (Source 3).
- **Customer concentration risk**: Top 5 customers = 38% of ARR (Source 3), and losing one of them (Sundry, $4.2M ARR) was significant.
- **Strategic retreat**: International expansion deferred, Lite tier sunset, layoffs planned (Source 4) — all signs of a company in damage-control mode, not aggressive growth.

The internal memo (Source 4) is the most revealing: it confirms the company is not on its original growth path and is now focused on survival ("insurance, not operating capital" for $50M credit facility). The path to cash-flow breakeven by Q4 2026 is ambitious and depends on successful execution of painful cuts.

### Why Not "More Diligence Needed"?

The brief format requires a clear stance. The evidence is sufficient to form a judgment: the company is in a weaker position than its press release suggests. "More diligence" would be needed for a lead investment, but for a follow-on, the investor should either commit (if they believe the turnaround plan) or pass. Given the contradictions across sources, passing is the prudent stance.

### Conditions for Reconsideration

The investor should reconsider if:
1. Verified ARR (audited, excluding churned customers) is $38M+ by Q2 2026
2. Net retention drops below 100% (current claim is >110%, but includes churned customers in baseline)
3. The $50M credit facility proves insufficient and the company seeks another round at a lower valuation

## Decision: Structure of the Brief

### Headline Stance
Lead with "PASS" — clear, actionable, and calibrated to the investor's 5-minute window.

### Narrative Flow
1. **Stance first**: "Pass on follow-on investment"
2. **Key facts**: Valuation, ARR, cash flow, customer concentration
3. **Tensions**: Press release vs. TechCrunch vs. leaked memo
4. **Recommendation conditions**: What would change the stance

### Tone
- Calibrated: "according to sources" for contested facts
- Direct: "the company is burning cash" not "cash flow is negative"
- Evidence-based: every claim tied to a source

## Decision: Omissions

- Did not include founder biographies (not material to investment decision)
- Did not include customer names beyond Sundry (Klatch mentioned in TechCrunch, but not necessary for summary)
- Did not include exact layoff numbers beyond context (22 people in Feb 2025, 30% international cut) — included only where material to cash flow or growth narrative

## Decision: Citation Style

- Inline citations: [Source 1], [Source 2], etc.
- No fabricated citations: every claim traces to one of the five sources
- For contested facts (e.g., ARR), present both the company claim and the contradictory evidence
