# Key Facts — Nimbus Logistics, Inc.

## Valuation & Funding

- Series B closed $84M at $560M post-money valuation (Source 1)
- Total funding to date: $128M (Source 1)
- SEC Form D filed 2026-01-22, 7 investors (Source 5)
- Series B was initially meant to close at $720M in late 2025 but repriced down after Sundry non-renewal (Source 2)
- $50M credit facility from Silicon Valley Bridge secured (Source 4)

## Financial Metrics

- ARR reported as $42M as of Q4 2025 (Source 1)
- ARR was $11M a year prior (Source 1)
- Adjusted for December churn, run-rate ARR is $36-37M (Source 2)
- Company spending ~$4M/month all-in vs ~$3.5M/month in revenue (Source 3)
- Path to cash-flow breakeven by Q4 2026 (Source 4)

## Customer Base & Churn

- 1,400 customers (Source 1)
- Top 5 customers = ~38% of ARR (Source 3)
- Lost Sundry Brands ($4.2M ARR) in November 2025 (Source 2, 3)
- Lost Klatch (fast-fashion) in December 2025 (Source 2)
- 3 new $1M+ ARR contracts signed in Q1 (Source 2)
- Net retention claimed >110% (Source 2)
- ~310 customers on "Nimbus Lite" ($5K-$20K ARR each) to be migrated out (Source 4)

## Operations & Strategy

- 187 employees across Oakland, Austin, Berlin (Source 1)
- Layoffs in February 2025: 22 people (~11% of org), mostly customer success & BD (Source 3)
- 30% reduction in international headcount, Berlin from 41 to ~28-30 by end of Q2 (Source 4)
- Berlin office to become "support hub" instead of sales/expansion office (Source 4)
- "Nimbus Lite" tier to be sunset (Source 4)
- International expansion deferred to 2027 (Source 4)

## Founders & Leadership

- CEO: Mira Patel (Source 1)
- CTO: Daniel Wong (Source 1, 3)
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (Source 1)
