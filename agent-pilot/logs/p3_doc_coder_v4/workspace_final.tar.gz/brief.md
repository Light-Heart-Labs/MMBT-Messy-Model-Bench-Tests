# Executive Brief: Nimbus Logistics, Inc. — Follow-on Investment Recommendation

**Recommendation: PASS on follow-on investment.** The company’s press release tells a story of explosive growth, but the full picture—drawn from five independent sources—reveals a business in strategic retreat, burning cash, and re-pricing its future. The $84M Series B at $560M post-money is not a validation of momentum; it’s a repricing after key customers churned and the original $720M valuation proved unsustainable [Source 2]. For an existing investor, this is a red flag, not a green light.

## The Press Release vs. Reality

Nimbus’s own announcement touts $42M ARR (up from $11M a year prior), 1,400 customers, and expansion into international markets [Source 1]. But TechCrunch reports that the $42M figure includes customers that churned in December 2025—Sundry Brands ($4.2M ARR) and fast-fashion brand Klatch—adjusting the run-rate to $36-37M [Source 2]. CEO Mira Patel claims net retention above 110% and three new $1M+ contracts in Q1, but these are forward-looking claims, not verified facts [Source 2].

The internal memo, leaked to *The Information*, tells a different story: the company is not on its growth path. International expansion is deferred to 2027, the Berlin office will shrink by 30% (from 41 to ~28-30), and the lowest-tier “Nimbus Lite” plan (310 customers, $5K-$20K ARR each) will be sunset [Source 4]. This is not the behavior of a company confident in its trajectory; it’s the behavior of a company in damage-control mode.

## Cash Flow Is the Critical Risk

The most alarming fact is the company’s negative cash flow. A former senior engineer reports that Nimbus was spending ~$4M/month all-in in mid-2025, against ~$3.5M/month in revenue—a $500K monthly burn [Source 3]. The company’s path to cash-flow breakeven by Q4 2026, outlined in the internal memo, depends on successful execution of painful cuts: layoffs, international retrenchment, and customer base pruning [Source 4]. This is a high-risk plan: if growth stalls or churn accelerates, the runway could shrink faster than projected.

The $50M credit facility mentioned in the memo is described as “insurance, not operating capital” [Source 4]. This is not a sign of strength; it’s a recognition that the Series B’s $84M may not be enough to fund the original growth plan.

## Customer Concentration and Churn Risk

The top 5 customers represent ~38% of ARR [Source 3]. Losing one of them (Sundry, $4.2M ARR) was a material event that forced a $160M valuation repricing (from $720M to $560M) [Source 2]. This concentration risk is not mitigated by the company’s claim of 1,400 customers; if the next largest customers follow Sundry’s lead, ARR could decline faster than growth can offset it.

## Why Not Invest?

The case for investing would require believing that:
1. The company can achieve cash-flow breakeven by Q4 2026 despite negative current run-rate;
2. The new $1M+ contracts will offset churn and drive net retention above 110% sustainably;
3. The international retrenchment and Lite-tier sunsetting won’t damage brand perception or customer trust.

None of these are impossible, but they are high-risk, especially given the contradictory signals across sources. The internal memo is the most revealing: it confirms the company is not on its original path and is now focused on survival, not growth.

## Conditions for Reconsideration

This recommendation would change if:
- Verified ARR (audited, excluding churned customers) is $38M+ by Q2 2026;
- Net retention drops below 100% (current claim is >110%, but includes churned customers in baseline);
- The $50M credit facility proves insufficient and the company seeks another round at a lower valuation.

## Bottom Line

The press release is a marketing document. The TechCrunch article, the leaked memo, and the former-employee blog post tell a more complete story: a company that raised $84M at a $560M valuation after repricing a $720M round, burning cash, and retreating from its international ambitions. For an investor evaluating a follow-on, this is not a compelling opportunity. The prudent stance is to pass.

---

**Word count: 598**
