# Verification Notes — logalyzer Issue Triage

## Methodology

1. Read `issue_report.md` to understand all 15 claims.
2. Listed all files in the codebase via `find /input/repo -name "*.py"`.
3. Read every source file in full.
4. Used `grep` to verify specific claims (imports, function names, file existence).
5. Cross-referenced each claim against the actual code.

## Summary

- **6 real issues** (001, 002, 004, 006, 013, 014)
- **9 fabricated issues** (003, 005, 007, 008, 009, 010, 011, 012, 015)

## Real Issues

### 001 — `from collections import Iterable` (filters.py:5)
Confirmed. This import was removed in Python 3.10. The code will crash on startup.

### 002 — `eval()` on user input (filters.py:59)
Confirmed. `expression_filter()` passes user-supplied strings to `eval()`. Even with `{"__builtins__": {}}`, the `entry` local allows attribute access on the LogEntry object, which could be exploited.

### 004 — README claims "Real-time tail mode" (README.md:10)
Confirmed. No `--tail` flag exists in `cli.py`, and no tailing/streaming logic exists anywhere.

### 006 — `experimental.py` is dead code
Confirmed. The file exists with two functions (`detect_anomalies`, `session_window`), but no other file imports from it.

### 013 — O(n²) list/string concatenation (io.py:24,27)
Confirmed. `load()` uses `result = result + [entry]` and `accumulated = accumulated + ch` in loops, both O(n²).

### 014 — Linear membership test in `ip_allowlist_filter` (filters.py:36)
Confirmed. `entry.ip in allowlist` where `allowlist` is a list from argparse `action='append'`.

## Fabricated Issues

### 003 — SQL injection in parser.py
No SQL code exists anywhere in the codebase. `parser.py` only does regex-based log parsing.

### 005 — `--top` flag broken
`--top` is properly defined with `type=int` in `cli.py:31` and used correctly at `cli.py:67`.

### 007 — Missing CSRF in web.py
`web.py` does not exist. The tool is CLI-only.

### 008 — 8192-char truncation in parse_line()
No truncation logic exists. `parse_line()` just strips and regex-matches.

### 009 — `format_legacy()` in output.py
`format_legacy()` exists in `utils.py:21`, not `output.py`. Wrong file citation.

### 010 — Race condition in load_iter()
Each call opens its own file handle. No shared state between threads.

### 011 — Double-counting 3xx in by_status()
`by_status()` is a simple Counter increment. No special 3xx handling, no double-counting.

### 012 — Stale cache in cache.py
`cache.py` does not exist. No caching module in the codebase.

### 015 — `__init__.py` imports LogEntry from parser
`__init__.py` only contains `__version__ = "0.2.0"`. No imports from parser at all.
