# Verification Notes

## Summary

Out of 15 issues in the preliminary review report, **6 are real** and **9 are fabricated**.

## Real Issues (6)

| # | Issue | Evidence |
|---|-------|----------|
| 001 | `from collections import Iterable` | `logalyzer/filters.py:5` — confirmed ImportError on Python 3.11 |
| 002 | `eval()` usage | `logalyzer/filters.py:59` — `eval(expr, {"__builtins__": {}}, {"entry": entry})` |
| 004 | README false feature claim | `README.md:12` — "Real-time tail mode" not implemented |
| 006 | Dead code: experimental.py | `logalyzer/experimental.py` — never imported by any module |
| 013 | O(n²) performance in io.py | `logalyzer/io.py:24,27` — `result = result + [entry]` and `accumulated = accumulated + ch` |
| 014 | O(n) IP allowlist lookup | `logalyzer/filters.py:35` — `entry.ip in allowlist` where allowlist is a list |

## Fabricated Issues (9)

| # | Issue | Why Fabricated |
|---|-------|----------------|
| 003 | SQL injection in parser.py | No SQL anywhere in parser.py or the codebase |
| 005 | `--top` flag broken | `--top` is properly defined with `type=int` and used correctly |
| 007 | CSRF in web.py | `logalyzer/web.py` does not exist; no web interface |
| 008 | 8192-char truncation | `parse_line()` has no length limit |
| 009 | `format_legacy()` in output.py | Function exists in `utils.py`, not `output.py` (wrong file citation) |
| 010 | Race condition in io.py | Each call opens its own file handle; no shared state |
| 011 | Double-counting 3xx | `by_status()` treats all codes identically; no special 3xx logic |
| 012 | Stale cache entries | `logalyzer/cache.py` does not exist |
| 015 | `__init__.py` imports LogEntry | `__init__.py` only has `__version__`; no LogEntry import |

## Key Observations

- The previous reviewer invented files that don't exist (`web.py`, `cache.py`).
- The reviewer misattributed `format_legacy()` to `output.py` when it's in `utils.py`.
- The reviewer claimed `__init__.py` imports `LogEntry` when it doesn't.
- The reviewer claimed SQL injection where there is no SQL at all.
- The reviewer claimed a truncation bug where no truncation exists.
