# Triage Output

## Files

- **`triage.json`** — Required output. Contains verdict (`real` or `fabricated`) and evidence for each of the 15 issues, plus a summary count.
- **`notes.md`** — Detailed reasoning table with explanations for each verdict, including borderline cases.

## How to Read

Each issue in `triage.json` has:
- **`verdict`**: `"real"` if the issue exists in the code as described, `"fabricated"` if it doesn't.
- **`evidence`**: For real issues, a file:line citation. For fabricated issues, an explanation of why the claim is wrong.

## Summary

| Verdict | Count |
|---------|-------|
| Real    | 6     |
| Fabricated | 9 |

The previous reviewer was confidently wrong on 9 of 15 issues — inventing files that don't exist (`web.py`, `cache.py`), claiming bugs where the code is fine (SQL injection, race conditions, double-counting), and citing wrong file locations (`format_legacy` in `output.py` instead of `utils.py`).
