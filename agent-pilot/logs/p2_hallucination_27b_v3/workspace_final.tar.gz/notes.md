# Verification Notes

## Summary

Of 15 issues in the preliminary report, **6 are real** and **9 are fabricated**.

## Real Issues (6)

| # | Issue | Evidence |
|---|-------|----------|
| 001 | `from collections import Iterable` | `filters.py:5` — raises `ImportError` on Python 3.10+ |
| 002 | `eval()` on user input | `filters.py:59` — `eval(expr, {"__builtins__": {}}, {"entry": entry})` |
| 004 | README claims "Real-time tail mode" | `README.md:10` — no `--tail` flag or streaming logic exists |
| 006 | `experimental.py` is dead code | No other module imports from it (grep confirmed) |
| 013 | O(n²) list/string concatenation in `load()` | `io.py:24` (`result = result + [entry]`) and `io.py:27` (`accumulated = accumulated + ch`) |
| 014 | O(n) IP allowlist membership | `filters.py:36` — `entry.ip in allowlist` where allowlist is a list from argparse |

## Fabricated Issues (9)

| # | Issue | Why Fabricated |
|---|-------|----------------|
| 003 | SQL injection in parser.py | No SQL code exists anywhere in the codebase |
| 005 | `--top` flag broken | `--top` is correctly defined with `type=int` in `cli.py:33` |
| 007 | CSRF in web.py | No `web.py` file exists in the codebase |
| 008 | 8192-char truncation in parse_line() | No length limit exists; `parse_line()` just strips and regex-matches |
| 009 | `format_legacy()` in output.py | Function exists in `utils.py:21`, NOT in `output.py` |
| 010 | Race condition in load_iter() | File is opened and iterated in the same function; no race window |
| 011 | Double-counting 3xx in by_status() | `by_status()` is a simple Counter increment; no special 3xx logic |
| 012 | Stale cache in cache.py | No `cache.py` file exists in the codebase |
| 015 | `__init__.py` imports LogEntry | `__init__.py` only contains `__version__`; no imports at all |

## Borderline Cases

### Issue 009 — Wrong File Citation
The function `format_legacy()` does exist, but in `logalyzer/utils.py:21`, not in `logalyzer/output.py` as claimed. Per the rules ("A wrong file citation makes the issue fabricated"), this is labeled fabricated. The dead-code concern about `format_legacy()` is valid, but the original claim about its location is wrong.

### Issue 010 — Race Condition Claim
The claim describes a race between "file-handle creation" and "iteration" in `load_iter()`. The actual code opens the file with a `with` statement and immediately iterates within the same function body. There is no separate file-handle creation step that could race. The claim is fabricated because the described mechanism doesn't exist.
