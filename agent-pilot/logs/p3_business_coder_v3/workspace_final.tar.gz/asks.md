# Diligence Asks for the Next 2 Weeks

**Owner**: Executive Committee / External Advisor (to be engaged)
**Deadline**: 2026-04-30 (to inform final decision)

---

## 1. Financial Deep Dive

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| **A1**: Provide ARR reconciliation: Break down ARR by contract type (annual vs multi-year), show how $11.4M ARR maps to $9.2M recognized revenue. | Corp Dev + Finance | 2026-04-22 | Clarify the 22% ARR premium over revenue. |
| **A2**: Provide burn-rate trend: Monthly burn for the last 12 months, and projection for next 6 months. | Corp Dev + Finance | 2026-04-22 | Verify runway is not deteriorating. |
| **A3**: Provide gross margin trend: Quarterly gross margins for the last 4 quarters. | Corp Dev + Finance | 2026-04-22 | Assess if 71% is stable or improving. |
| **A4**: Provide customer concentration: Top 5, top 10, and top 20 customers by ARR and revenue. | Corp Dev + Finance | 2026-04-22 | Identify if >30% ARR is concentrated. |

---

## 2. Customer & Market Validation

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| **A5**: Provide full reference list: All 280 customers, with contact info, contract end date, and ARR. | Corp Dev | 2026-04-22 | Enable independent reference calls beyond top 5. |
| **A6**: Conduct 10+ reference calls: 5 mid-tier customers (not top 5), 3 churned customers, 2 prospects that said no. | Executive Committee / Advisor | 2026-04-25 | Validate NPS claim and satisfaction distribution. |
| **A7**: Provide churn breakdown: Churn by customer size (small vs large mid-market), by industry, and by product usage. | Corp Dev | 2026-04-22 | Understand if churn is concentrated or random. |
| **A8**: Provide competitive win/loss rates: Last 12 months, by competitor. | Corp Dev | 2026-04-22 | Assess competitive positioning. |

---

## 3. Team & Integration Risk

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| **A9**: Provide engineering team tenure: Role, title, and start date for all 14 engineers. | Corp Dev | 2026-04-22 | Assess team stability beyond CTO. |
| **A10**: Provide retention plan: Equity rollover terms, retention bonuses, and post-close reporting structure for engineering and product. | Corp Dev + HR | 2026-04-22 | Validate 85% retention assumption. |
| **A11**: Provide integration work-breakdown: Milestones, dependencies, and key risks for 4-6 month integration. | Corp Dev + Integration Lead | 2026-04-23 | Validate timeline feasibility. |
| **A12**: Provide synergy validation: Detailed cost model for $3.2M savings (cloud, headcount, real estate). | Corp Dev + Finance | 2026-04-23 | Ensure synergy assumptions are grounded. |

---

## 4. Product & Tech

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| **A13**: Provide tech debt assessment: Independent third-party code review (not just engineering internal). | External Tech Advisor | 2026-04-24 | Confirm "clean, well-tested" claim. |
| **A14**: Provide product roadmap: Next 12 months, with feature priorities and resource allocation. | Corp Dev + Product | 2026-04-22 | Assess if roadmap aligns with our strategy. |
| **A15**: Provide CAC and LTV: By customer segment, with cohort analysis. | Corp Dev + Finance | 2026-04-22 | Validate growth efficiency. |

---

## 5. Valuation & Deal Structuring

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| **A16**: Provide IRR sensitivity analysis: IRR at 50% ARR growth, 65% gross margin, 9-month integration, 0 synergies. | Corp Dev + Finance | 2026-04-22 | Test deal resilience. |
| **A17**: Provide deal structure options: All-cash, all-stock, mixed, earnout scenarios. | Corp Dev + Finance | 2026-04-22 | Align with treasury and tax strategy. |
| **A18**: Provide post-close capital needs: Capex and Opex for integration and product development. | Corp Dev + Finance | 2026-04-22 | Assess impact on cash flow. |

---

## 6. Legal & Compliance

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| **A19**: Provide key customer contract terms: Auto-renewal clauses, termination rights, change-of-control triggers. | Legal | 2026-04-22 | Identify contract-level risks. |
| **A20**: Provide IP assignment: Confirm all employees have assigned IP to the company. | Legal | 2026-04-22 | Critical for tech acquisition. |

---

## Summary

- **Critical asks** (must be completed before LOI): A1, A3, A5, A9, A16
- **High-priority asks** (should be completed before board sign-off): A6, A10, A11, A13, A19
- **Follow-up asks**: All others, to be completed post-LOI if deal proceeds.
