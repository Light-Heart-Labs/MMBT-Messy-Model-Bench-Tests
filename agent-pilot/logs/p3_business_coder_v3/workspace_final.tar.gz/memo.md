# Executive Committee Review: Borealis Analytics Acquisition

**Date**: 2026-04-16  
**Prepared by**: Executive Committee Member  
**Recommendation**: **HOLD** — Do not issue LOI at $84M until core concerns are addressed.

---

## Recommendation

I recommend **HOLD** on the Corp Dev team’s PROCEED recommendation. The deal has strategic merit (mid-market e-commerce gap, minimal feature overlap), but the diligence pack overstates financial stability, customer satisfaction, and integration feasibility. I would change my stance to **PROCEED** if the following conditions are met within the next 2 weeks:

1. **Financial clarity**: ARR reconciliation confirms runway ≥18 months and ARR is not inflated relative to recognized revenue.
2. **Customer validation**: At least 5 mid-tier (non-top-5) customer references confirm satisfaction and expansion potential.
3. **Integration realism**: Work-breakdown validates a 6-month timeline with clear milestones and risk mitigation.
4. **Team retention**: Retention plan includes equity rollover and bonuses for top 5 engineers, not just CTO.

---

## Strongest Concerns

### 1. Financial Metrics Are Ambiguous and Potentially Overstated

Per the financials table, ARR ($11.4M) exceeds recognized revenue ($9.2M) by 22%. For a company with 12-month contracts, this is unusual and suggests either aggressive ARR calculation (e.g., including expected upsell or not adjusting for churn) or multi-year contracts with upfront recognition. The pack does not explain this discrepancy, leaving valuation at 7.4x ARR potentially inflated. Similarly, the “22 months runway” claim is based on the last cap raise without specifying when that occurred or showing burn-rate trends. If burn is accelerating, runway could be significantly shorter.

### 2. Customer Satisfaction Is Overclaimed and Cherry-Picked

The pack states customers have “NPS in the high 40s” but does not define NPS or benchmark “high 40s” as strong (it’s typically “good”). More critically, the five testimonials are all from the top 5 customers, and one declined to be quoted. This cherry-picking obscures the distribution of satisfaction across the 280-customer base. Without data on churn by segment or negative references, we cannot assess whether Borealis has a defensible product or just a few happy anchor accounts.

### 3. Integration Plan Is Overly Optimistic

The pack claims a “4-6 month full integration timeline” and “85% retention expected,” but provides no work-breakdown or retention plan beyond the CTO. Integration timelines are notoriously optimistic, and the pack offers no mitigation for customer resistance to Aurora’s sunset or migration delays. The $3.2M synergy estimate is also unvalidated — no breakdown of cloud, headcount, or real estate savings is provided.

---

## Next Steps: 2-Week Diligence Sprint

If the committee wants to keep the deal alive, I propose the following 2-week sprint to address the core concerns:

1. **Financial deep dive** (Corp Dev + Finance, by 2026-04-22): ARR reconciliation, burn trend, gross margin trend, customer concentration.
2. **Customer validation** (Executive Committee/Advisor, by 2026-04-25): 10+ reference calls (5 mid-tier, 3 churned, 2 prospects).
3. **Integration realism** (Corp Dev + Integration Lead, by 2026-04-23): Work-breakdown for 4-6 month timeline, synergy validation, retention plan for top 5 engineers.

Full asks are in `asks.md`.

---

## Conclusion

The Borealis deal is not a “no-brainer” tuck-in. The pack’s advocacy framing masks material risks in financials, customer satisfaction, and integration. A HOLD stance protects the committee from signing a term sheet based on incomplete data. With the 2-week diligence sprint, we can either de-risk the deal and proceed, or walk away with confidence that $84M is not justified.
