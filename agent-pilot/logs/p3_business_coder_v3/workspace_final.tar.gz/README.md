# Borealis Analytics Acquisition Review

This repository contains the executive committee review of the Borealis Analytics acquisition diligence pack.

## Files

| File | Purpose |
|------|---------|
| `memo.md` | **Primary deliverable**: 1-page memo with recommendation, concerns, and next steps. |
| `concerns.md` | Extended enumeration of all concerns with the deal pack (10+ categories). |
| `asks.md` | 20+ specific diligence asks for the next 2 weeks, with owners and deadlines. |
| `decisions/adr001.md` | ADR on memo scope (prioritized 3 core concerns over comprehensive list). |
| `decisions/adr002.md` | ADR on recommendation stance (HOLD vs. PROCEED, with conditions). |

## How to Read This Output

1. **Start with `memo.md`** — This is the executive summary. It contains the recommendation, the strongest concerns, and the path forward.

2. **Review `concerns.md`** — This expands on the memo's concerns and adds additional issues not elevated to the memo (e.g., competitive landscape, IP assignment).

3. **Review `asks.md`** — This is the action plan for the next 2 weeks. It translates the concerns into specific, time-bound diligence tasks.

4. **Review `decisions/adr*.md`** — These are the judgment calls that shaped the memo. They explain why certain concerns were prioritized and why the recommendation is HOLD.

## Key Takeaways

- **Recommendation**: HOLD (not PROCEED, not PASS).
- **Core concerns**: Financial metric ambiguity, customer validation overclaim, integration optimism.
- **Conditions to move to PROCEED**: Financial clarity, customer validation, integration realism, team retention plan.
- **Next steps**: 2-week diligence sprint (20+ asks) to address core concerns.

## Timeline

- **Pack date**: 2026-04-15
- **Decision deadline**: 2026-04-30
- **Memo date**: 2026-04-16
- **Diligence sprint**: 2026-04-16 to 2026-04-30
