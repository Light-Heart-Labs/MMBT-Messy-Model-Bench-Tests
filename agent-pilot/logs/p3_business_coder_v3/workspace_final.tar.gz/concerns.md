# Concerns with the Borealis Acquisition Deal Pack

## 1. Overstated Strategic Rationale

- **Claim**: "Borealis would extend our analytics surface area into mid-market e-commerce, a segment we currently service only via partner integrations."
- **Concern**: This frames Borealis as filling a critical gap, but doesn't quantify the *value* of that extension. How much incremental revenue or market share is expected? What is the current revenue contribution from partner-served e-commerce customers? Without this, the strategic rationale is advocacy, not analysis.

## 2. Customer NPS and Testimonials

- **Claim**: "Pre-LOI conversations with their five largest customers indicate strong satisfaction (NPS in the high 40s)."
- **Concern**: NPS is not defined in the pack. High 40s is presented as strong, but NPS >0 is generally considered positive; 40-50 is typically "good" not "strong". The pack conflates satisfaction with loyalty or defensibility. Also, only 4 of 5 customers were willing to be quoted — why did one decline? What was the sample bias?

- **Claim**: Testimonials are all from top 5 customers. This is cherry-picking. Where are the negative or neutral references? What is the distribution of satisfaction across the full 280-customer base?

## 3. Financial Metrics — Ambiguities and Omissions

- **Claim**: "Revenue (recognized GAAP) | $9.2M" and "ARR (end of period) | $11.4M"
- **Concern**: ARR ($11.4M) > Revenue ($9.2M) is unusual for a company with 12-month contracts. If contracts are annual, ARR should be close to or slightly above the annualized portion of recognized revenue. A 22% ARR premium suggests either:
  - Long-term contracts (multi-year) with upfront recognition, or
  - Aggressive ARR calculation (e.g., including expected upsell or not adjusting for churn).
  The pack does not explain this discrepancy.

- **Claim**: "Gross margin | 71%" — "Acceptable for early-growth stage"
- **Concern**: Acceptable is not a benchmark. How does 71% compare to peers? Is it improving or declining? A static "acceptable" label hides trend analysis.

- **Claim**: "Net retention | 118%" and "Logo retention | 91%"
- **Concern**: Net retention >100% with logo retention <100% implies expansion is driving growth, which is positive. But the pack does not break down expansion revenue. Is expansion coming from a few large accounts or broadly? If it's concentrated, it's riskier.

- **Burn rate & runway**: "Burn rate (avg monthly) | $750K" and "22 months runway at last cap raise"
- **Concern**: Burn rate is presented as a historical average, but runway is based on "last cap raise". When was that? If the cap raise was 6+ months ago, and burn is accelerating, runway could be significantly shorter. The pack does not specify the date of the last cap raise.

## 4. Comparable Transactions — Flawed Benchmarking

- **Claim**: Borealis at ~7.4x ARR is "in line with the lower comps".
- **Concerns**:
  - The comps are all *acquisitions*, but Borealis is being priced as if it were a strategic acquisition. Are these also strategic (vs financial) acquirers? Salesforce, Snowflake, and HubSpot are strategic; the pack doesn't clarify.
  - No details on deal terms (e.g., earnouts, contingent payments) or timing of the deals. Market multiples may have shifted since Q4 2024.
  - No adjustment for Borealis's stage (Series-A) vs. the comps (unknown stage). Earlier-stage companies typically trade at lower multiples.

## 5. Integration Plan — Over-Optimistic Assumptions

- **Claim**: "4-6 month full integration timeline" and "85% retention expected"
- **Concern**: No detail on *how* these estimates were derived. Integration timelines are notoriously optimistic. The pack provides no work-breakdown or dependency mapping.

- **Claim**: "Aurora platform sunset planned for 12 months post-close"
- **Concern**: What happens if customers resist migration? What is the fallback? No risk mitigation is described.

- **Claim**: "Synergy estimate: $3.2M annual cost savings"
- **Concern**: How was this calculated? What infrastructure is being consolidated? The pack does not break down the cost components (e.g., cloud, headcount, real estate).

## 6. Team Retention — Critical Risk

- **Claim**: "No critical attrition in last 12 months" and "CTO Sarah Lin is a strong technical leader"
- **Concern**: While CTO is strong, the pack does not address what happens if she departs post-close (e.g., via rollover equity cliff). What is the retention plan for the engineering team beyond the CTO? What is the tenure distribution of the 14 engineers?

## 7. Product Roadmap — Lack of Validation

- **Claim**: "Borealis has shipped 3 major features in the last 9 months... validated as differentiated"
- **Concern**: "Validated" by whom? The Corp Dev team or an independent PM? There's no evidence of product-market fit beyond current customers (who are already paying). What is the pipeline of new logos? What is the CAC/LTV?

## 8. Valuation — No Sensitivity Analysis

- **Claim**: IRR estimate is "28-34% over the 4-year hold"
- **Concern**: No sensitivity analysis is provided. What happens to IRR if:
  - ARR growth slows to 50% YoY?
  - Integration takes 9+ months?
  - Gross margin declines to 65%?
  - Synergies fail to materialize?
  A single-point IRR estimate is misleading without context.

## 9. Missing: Customer Concentration

- **Omission**: The pack mentions the five largest customers but does not state their contribution to ARR or revenue. If the top 5 customers represent >30% of ARR, that is a material concentration risk.

## 10. Missing: Competitive Landscape

- **Omission**: No discussion of competitors (e.g., Segment, mParticle, RudderStack) or how Borealis differentiates beyond the three features listed. What is their defensible moat?
