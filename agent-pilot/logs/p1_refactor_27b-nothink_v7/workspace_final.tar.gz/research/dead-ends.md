# Dead Ends

## Pre-existing Bug: `collections.Iterable` Import (filters.py)

**File**: `logalyzer/filters.py`, line 5
**Issue**: `from collections import Iterable` fails on Python 3.10+ because `Iterable` was moved to `collections.abc`.
**Impact**: `test_filters.py` cannot be collected by pytest.
**Resolution**: Documented but not fixed. This is a pre-existing bug in the original codebase. The task explicitly prohibits bug fixes.

## Pre-existing Bug: Missing "Jul" in MONTH_NAMES (parser.py)

**File**: `logalyzer/parser.py`, line 22-25
**Issue**: The `MONTH_NAMES` list is:
```python
MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Aug", "Sep", "Oct", "Nov", "Dec",
]
```
"Jul" is missing between "Jun" and "Aug".
**Impact**: `test_timestamp_july_parses_correctly` fails with `ValueError: 'Jul' is not in list`.
**Resolution**: Documented but not fixed. This is a pre-existing bug in the original codebase.

## Approach Considered: Moving format_legacy from utils.py

**Approach**: Move the `format_legacy` function from `utils.py` to `output/legacy.py`.
**Why rejected**: The constraint says "Only `logalyzer/output.py` may be split" and "Don't change unrelated code." Moving `format_legacy` would require modifying `utils.py`, which is out of scope.
**Alternative used**: `output/legacy.py` re-exports `format_legacy` from `utils.py` via `from ..utils import format_legacy`.

## Approach Considered: Adding format_legacy to output.py before splitting

**Approach**: Add `format_legacy` to the original `output.py` before splitting, so it's part of the module being split.
**Why rejected**: This would require modifying `output.py` in a way that adds new content (not just splitting). The task says to split the existing content, not add to it. Also, `format_legacy` is not actually in `output.py` — the task description was slightly inaccurate about this.
