# Questions and Resolutions

## Q1: Where does `format_legacy` live?

**Question**: The task says `output.py` contains `format_legacy`, but it's actually in `utils.py`. Should I move it?

**Resolution**: No. The constraint says "Only `logalyzer/output.py` may be split" and "Don't change unrelated code." Moving `format_legacy` from `utils.py` would change `utils.py`. Instead, `output/legacy.py` re-exports it from `utils.py`, and `output/__init__.py` re-exports it from `legacy.py`. This satisfies the requirement that `from logalyzer.output import format_legacy` works.

## Q2: Where should `render_aggregate` go?

**Question**: `render_aggregate` supports text, json, and csv formats. Which module does it belong in?

**Resolution**: Placed in `plain_renderer.py` because:
- Its default format is "text"
- It's a general-purpose rendering function
- It doesn't fit neatly into a single format-specific module
- The task spec lists only 4 modules, and this is the best fit

## Q3: Should I fix the pre-existing bugs?

**Question**: `collections.Iterable` import fails and `MONTH_NAMES` is missing "Jul".

**Resolution**: No. The task explicitly says "No bug fixes. If you encounter a bug, document it in `dead-ends.md` but don't fix it." Both bugs are documented in `dead-ends.md`.

## Q4: What about the `__pycache__` directories?

**Question**: Should I include `__pycache__` in the repo?

**Resolution**: No. Added `.gitignore` to exclude `__pycache__/`, `*.pyc`, and `.pytest_cache/`.
