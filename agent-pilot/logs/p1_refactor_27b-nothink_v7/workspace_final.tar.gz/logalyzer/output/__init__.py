"""Output formatters: JSON, CSV, plain text.

This module is a package that re-exports the public API from its submodules.
All imports that previously worked against logalyzer.output continue to work.
"""
from __future__ import annotations

from .json_renderer import to_json
from .csv_renderer import to_csv
from .plain_renderer import render_aggregate, to_text
from .legacy import format_legacy

__all__ = [
    "to_json",
    "to_csv",
    "to_text",
    "render_aggregate",
    "format_legacy",
]
