"""Legacy output formatters for backwards compatibility."""
from __future__ import annotations

# Re-export format_legacy from utils for backwards compatibility.
# This function was originally in utils.py but is exposed through the
# output module's public API for external scripts that depend on it.
from ..utils import format_legacy  # noqa: F401

__all__ = ["format_legacy"]
