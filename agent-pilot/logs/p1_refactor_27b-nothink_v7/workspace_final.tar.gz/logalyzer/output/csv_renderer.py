"""CSV output rendering."""
from __future__ import annotations

import csv
import io
from typing import Iterable

from ..parser import LogEntry


def to_csv(entries: Iterable[LogEntry]) -> str:
    """Render entries as CSV (with header row)."""
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["ip", "user", "timestamp", "method", "url", "protocol", "status", "bytes"])
    for e in entries:
        w.writerow([e.ip, e.user, e.timestamp.isoformat(), e.method, e.url, e.protocol, e.status, e.bytes])
    return buf.getvalue()
