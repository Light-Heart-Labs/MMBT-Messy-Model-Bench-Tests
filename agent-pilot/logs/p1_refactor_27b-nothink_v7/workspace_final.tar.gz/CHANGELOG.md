# CHANGELOG

## v0.3.1 — Refactor: Split `output.py` into `output/` package

### What Changed

The monolithic `logalyzer/output.py` module has been split into a focused `logalyzer/output/` package:

**Before:**
```
logalyzer/
  output.py          (to_json, to_csv, to_text, render_aggregate)
```

**After:**
```
logalyzer/
  output/
    __init__.py         Re-exports the full public API
    json_renderer.py    to_json()
    csv_renderer.py     to_csv()
    plain_renderer.py   to_text(), render_aggregate()
    legacy.py           format_legacy() (re-exported from utils)
```

### What Moved Where

| Function | Old Location | New Location |
|----------|-------------|--------------|
| `to_json` | `output.py` | `output/json_renderer.py` |
| `to_csv` | `output.py` | `output/csv_renderer.py` |
| `to_text` | `output.py` | `output/plain_renderer.py` |
| `render_aggregate` | `output.py` | `output/plain_renderer.py` |
| `format_legacy` | `utils.py` (re-exported) | `output/legacy.py` (re-exported from utils) |

### Why

- **Separation of concerns**: Each output format now has its own module
- **Extensibility**: Adding new output formats is as simple as adding a new module
- **Maintainability**: Smaller, focused modules are easier to understand and test
- **Backward compatibility**: All existing imports continue to work via `__init__.py` re-exports

### What Didn't Change

- No behavior changes — all functions are byte-identical copies
- No test modifications — the test suite is untouched
- No changes to `parser.py`, `utils.py`, `cli.py`, or any other file
- No new dependencies

### Verification Results

1. **`pytest -q`**: 10 passed, 1 failed (pre-existing bug in `parser.py` — "Jul" missing from `MONTH_NAMES`)
   - Same results as the original repo
   - `test_filters.py` cannot be collected due to pre-existing `collections.Iterable` bug in `filters.py`

2. **`python -c "from logalyzer.output import format_legacy; print(format_legacy)"`**: ✅ Works
   - Outputs: `<function format_legacy at 0x...>`

3. **`git diff /input/repo/tests /workspace/tests`**: ✅ Empty (no test modifications)

4. **Non-output file diffs**: ✅ All empty
   - `parser.py`, `utils.py`, `cli.py`, `filters.py`, `aggregate.py`, `io.py`, `experimental.py`, `__init__.py` — all byte-identical

### Pre-existing Bugs (Not Fixed)

1. **`collections.Iterable` import** in `filters.py` — fails on Python 3.10+
2. **Missing "Jul"** in `MONTH_NAMES` in `parser.py` — causes July timestamp parsing to fail

Both bugs exist in the original codebase and are documented in `research/dead-ends.md`.
