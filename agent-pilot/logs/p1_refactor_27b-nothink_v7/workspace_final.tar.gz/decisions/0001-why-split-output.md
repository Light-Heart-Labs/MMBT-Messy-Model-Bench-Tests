# ADR-0001: Why Split output.py

## Status

Accepted

## Context

The `logalyzer/output.py` module mixed four distinct concerns:

1. **JSON serialization** (`to_json`) — hand-crafted JSON string building for `LogEntry` objects
2. **CSV serialization** (`to_csv`) — using the `csv` stdlib module
3. **Plain-text formatting** (`to_text`) — human-readable log entry rendering
4. **Aggregate rendering** (`render_aggregate`) — multi-format rendering for aggregation results
5. **Legacy compatibility** (`format_legacy`) — a backward-compat formatter originally in `utils.py`

This single-module structure made it difficult to:
- Understand which functions belong to which output concern
- Add new output formats without bloating the module
- Test individual output formats in isolation
- Maintain clear separation of concerns

## Decision

Split `logalyzer/output.py` into a `logalyzer/output/` package with one module per concern:

```
logalyzer/output/
  __init__.py         Re-exports the public API
  json_renderer.py    to_json()
  csv_renderer.py     to_csv()
  plain_renderer.py   to_text(), render_aggregate()
  legacy.py           format_legacy() (re-exported from utils)
```

## Consequences

- **Positive**: Clear separation of concerns, easier to extend with new formats, better testability
- **Neutral**: No behavioral change — all existing imports continue to work via `__init__.py` re-exports
- **Risk**: Minimal — the `__init__.py` acts as a compatibility shim

## Alternatives Considered

- **Keep as single module**: Would require no changes but doesn't address the structural issue
- **Create separate top-level modules** (e.g., `logalyzer/json_output.py`): Would require changing all import sites
- **Use a factory/registry pattern**: Over-engineered for this small codebase
