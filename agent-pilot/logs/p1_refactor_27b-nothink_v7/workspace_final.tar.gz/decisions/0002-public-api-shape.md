# ADR-0002: Public API Shape

## Status

Accepted

## Context

When splitting `output.py` into a package, we need to define what gets re-exported from `logalyzer.output` to maintain backward compatibility.

## Decision

The `logalyzer/output/__init__.py` re-exports exactly these symbols:

| Symbol | Source Module | Used By |
|--------|--------------|---------|
| `to_json` | `json_renderer.py` | `cli.py` |
| `to_csv` | `csv_renderer.py` | `cli.py` |
| `to_text` | `plain_renderer.py` | `cli.py` |
| `render_aggregate` | `plain_renderer.py` | `cli.py` |
| `format_legacy` | `legacy.py` (re-exported from `utils.py`) | External scripts (backward compat) |

### Why `format_legacy` is in `output/legacy.py`

`format_legacy` is defined in `utils.py` but the task requires `from logalyzer.output import format_legacy` to work. Rather than moving the function (which would change `utils.py`, an unrelated file), we re-export it through `output/legacy.py` and then through `output/__init__.py`. This preserves the original definition location while satisfying the import requirement.

### Why `render_aggregate` is in `plain_renderer.py`

`render_aggregate` supports three formats (text, json, csv) for aggregate data. It was placed in `plain_renderer.py` because:
1. The default format is "text"
2. It's a general-purpose rendering function that doesn't fit neatly into a single format module
3. It's the closest conceptual match to "plain rendering" since it handles arbitrary data structures

## Consequences

- All existing `from logalyzer.output import X` calls continue to work
- The `__init__.py` serves as the single point of truth for the public API
- Internal submodules can be imported directly by advanced users if needed
