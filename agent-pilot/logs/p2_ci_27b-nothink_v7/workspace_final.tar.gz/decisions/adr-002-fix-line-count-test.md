# ADR-002: Update test_line_count_matches_qty_sum, not the implementation

## Context

`test_line_count_matches_qty_sum` asserts `c.line_count() == 5` (total quantity),
but `line_count()` returns 2 (number of lines).

## Decision

Update the test to assert `c.line_count() == 2`.

## Rationale

- The CHANGELOG.md for v0.3.0 explicitly states: "Cart.line_count() now returns
  the number of lines, not the total quantity across lines. Tests should be
  updated where they relied on the old behavior."
- This was an intentional API change, not a bug in the implementation.
- The test was simply not updated when the API changed.

## Consequences

The test name `test_line_count_matches_qty_sum` is now slightly misleading
since it no longer checks quantity sum. However, renaming it would be cosmetic
and the docstring was updated to clarify the intent.
