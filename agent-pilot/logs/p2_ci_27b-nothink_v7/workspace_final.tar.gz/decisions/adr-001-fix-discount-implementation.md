# ADR-001: Fix discount_amount implementation, not the tests

## Context

`discount_amount(100.0, 20.0)` returned 2000.0 instead of 20.0. The function
takes `percent_off` in the range [0, 100] per the v0.3.0 breaking change, but
the implementation multiplied directly without dividing by 100.

## Decision

Fix the implementation: `price * percent_off / 100` instead of `price * percent_off`.

## Rationale

- The docstring examples clearly show `discount_amount(100.0, 20.0) -> 20.0`
- The changelog documents the v0.3.0 API change to percent-based input
- The tests were written correctly for the documented API
- The implementation was simply never updated to match the API change

## Consequences

`apply_discount()` also benefits since it calls `discount_amount()` internally.
Both `test_discount_amount` and `test_apply_discount` now pass.
