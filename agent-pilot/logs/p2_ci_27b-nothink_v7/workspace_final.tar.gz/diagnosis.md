# Diagnosis of CI Failures

## Issue 1: Ruff F401 — Unused `json` import in `cart.py`

**What was wrong:** `import json` was present in `src/discountkit/cart.py` but never used.
**Fix:** Removed the unused import line.
**Why:** This is a straightforward lint fix — the import served no purpose.

## Issue 2: `discount_amount()` returns wrong value (2000 instead of 20)

**What was wrong:** The function multiplies `price * percent_off` directly, but since v0.3.0 the parameter is a percentage (0-100), not a fraction (0-1). So `100 * 20 = 2000` instead of `100 * 20 / 100 = 20`.
**Fix:** Changed `return round(price * percent_off, 2)` to `return round(price * percent_off / 100, 2)`.
**Why:** The code was wrong. The docstring examples (`discount_amount(100.0, 20.0) -> 20.0`) and the changelog (v0.3.0 BREAKING change to percent-based API) both confirm the intended behavior. The implementation was never updated to match the API change.

## Issue 3: `test_line_count_matches_qty_sum` fails (asserts 5, gets 2)

**What was wrong:** The test expects `line_count()` to return the total quantity across lines (5), but v0.3.0 changed `line_count()` to return the number of lines (2).
**Fix:** Updated the test to assert `c.line_count() == 2` (number of lines) instead of `c.line_count() == 5` (total qty).
**Why:** The changelog explicitly states: "Tests should be updated where they relied on the old behavior." The code change was intentional; the test was not updated to match.

## Issue 4: Ruff I001/UP006/UP035/UP045 — Import sorting and typing modernization

**What was wrong:** Import blocks were unsorted, and deprecated `typing.List`/`typing.Optional` were used instead of modern `list`/`X | None`.
**Fix:** Applied `ruff --fix` to auto-correct all of these.
**Why:** The pyproject.toml configures ruff to select rules I, E, F, B, UP. These must all pass.
