# Decision Record: Customer Email

## Choice 1: Omit all engineer names (including Marcus)
- **Rationale**: Customer email must NOT mention named individuals per brief spec. Memo identifies Marcus as the engineer but this is internal detail.
- **Source alignment**: Source says "it was Marcus" but brief explicitly forbids naming individuals.

## Choice 2: Simplify root cause to "authentication service throttled all incoming requests"
- **Rationale**: Must avoid engineering jargon (rate limiter, MAX, fraction) per brief spec. "Throttled all incoming requests" captures effect without technical detail.
- **Source alignment**: Source says "internal limiter's fraction stayed pinned to the old MAX, and ALL inbound auth requests started getting throttled" — accurate simplification.

## Choice 3: Omit "second outage in 90 days" framing
- **Rationale**: Brief explicitly forbids this as "internal signal, not customer-facing." Board-level concern is irrelevant to customers.
- **Source alignment**: Source mentions this twice but brief forbids inclusion.

## Choice 4: Include contact paths (CSM, support, named executive)
- **Rationale**: Brief requires "a contact path (CSM, support, named exec)" — included placeholders for customization.
- **Source alignment**: Memo mentions CSMs for enterprise accounts; support@company.com is reasonable placeholder.

## Choice 5: Mention 4 downstream automation cases without technical details
- **Rationale**: Brief requires acknowledging impact; "downstream systems were affected" captures this without jargon.
- **Source alignment**: Source says "4 cases where a customer's downstream automation broke and they had to manually clean up" — accurately summarized.

## Choice 6: Use "sincerely apologize" instead of "apologize"
- **Rationale**: Tone must be "warm, direct, accountable" — "sincerely apologize" adds appropriate weight.
- **Source alignment**: Source memo says "I want to write up... honest about what we got wrong because I think that matters more than the spin" — supports empathetic tone.

## Choice 7: Omit "4-hour" duration in customer email
- **Rationale**: Brief doesn't require exact times; "Friday" suffices for customer comms. Avoids overwhelming customers with technical timing.
- **Source alignment**: Source provides exact times but brief doesn't require them for customer audience.
