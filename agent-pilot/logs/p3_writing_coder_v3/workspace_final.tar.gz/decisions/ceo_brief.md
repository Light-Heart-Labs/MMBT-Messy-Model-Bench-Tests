# Decision Record: CEO Brief

## Choice 1: Omit exact times in favor of "4-hour outage"
- **Rationale**: CEO brief max is 250 words; exact times consume valuable space. "4-hour outage" conveys severity without cluttering.
- **Source alignment**: Memo states "from approximately 14:11 UTC to 18:24 UTC" — duration is ~4 hours. Acceptable.

## Choice 2: Group remediations into 4 high-level items
- **Rationale**: Memo lists 5 remediations; CEO needs concise takeaways. Combined status-page fix and communication protocol into two items, grouped config-system fixes.
- **Source alignment**: All four items map to specific items in memo (canary config deploys, internal limiter fix, status-page fix, communication protocol).

## Choice 3: Phrase board signal as "second 4+ hour outage this year"
- **Rationale**: Memo mentions "second 4+ hour outage in 2026 (the other was in February)" — accurate and board-appropriate framing.
- **Avoided**: "second outage in 90 days" phrasing (too informal for CEO brief per brief spec).

## Choice 4: Omit specific dollar impact for enterprise accounts
- **Rationale**: Memo says "real revenue impact" but doesn't quantify dollars. Specifying amounts would be fabrication.
- **Source alignment**: "Roughly 28 enterprise accounts (the ones with named CSMs) had real revenue impact during their business hours" — captured accurately.

## Choice 5: Use "SLA credits" without specifying credit amount
- **Rationale**: Memo says "standard SLA credit per our MSA is appropriate" but doesn't specify percentage/duration. Stating specifics would be fabrication.
- **Source alignment**: Accurate per "we owe the 4 known-broken-downstream customers something more than SLA credits" — implies standard SLA credits apply elsewhere.
