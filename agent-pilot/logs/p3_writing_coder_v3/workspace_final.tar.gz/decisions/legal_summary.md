# Decision Record: Legal Summary

## Choice 1: Use exact incident time window (14:11 UTC to 18:24 UTC)
- **Rationale**: Legal brief explicitly requires "exact incident time window with timezone."
- **Source alignment**: Source memo states "from approximately 14:11 UTC to 18:24 UTC on Friday" — precise.

## Choice 2: Specify "nominal breach" of SLA
- **Rationale**: Legal brief requires "the contractual SLA threshold (99.9% monthly) and whether it was nominally breached."
- **Source alignment**: Source memo states "the SLA we sell ('99.9% monthly uptime, with credits for breach') was nominally violated for the affected accounts."

## Choice 3: Omit remediation details
- **Rationale**: Legal brief explicitly forbids "engineering remediation details (irrelevant to counsel)."
- **Source alignment**: Source memo details 5 remediations but brief specifies they must be omitted.

## Choice 4: Frame credit recommendation as "contractual vs. relationship-driven"
- **Rationale**: Legal brief requires "recommendation on credit-request handling."
- **Source alignment**: Source memo states "For the 4 known-broken-downstream customers... hands-on data-cleanup... plus the SLA credit. For the other ~24 enterprise accounts... standard SLA credit... For the remaining ~11,400 accounts... SLA credit for any account that explicitly requests one."

## Choice 5: Use "incident" not "outage"
- **Rationale**: Legal brief requires "dispassionate" tone; "incident" is more formal/legal term.
- **Source alignment**: Source uses both terms but "incident" is preferred for legal context.

## Choice 6: Omit all informal language
- **Rationale**: Legal brief forbids "informal candor" and requires "precise, factual, dispassionate" tone.
- **Source alignment**: Source memo contains informal phrases ("so, ok," "sorry Sarah," "we should probably loop") — all omitted.

## Choice 7: Specify "approximately 28 enterprise accounts"
- **Rationale**: Legal brief requires "scope (account count, customer-tier breakdown)."
- **Source alignment**: Source memo states "Roughly 28 enterprise accounts (the ones with named CSMs) had real revenue impact" — accurately captured.

## Choice 8: Omit refund request count (31)
- **Rationale**: Legal brief doesn't require this metric; focus is on SLA breach and downstream harm. 31 is internal finance data.
- **Source alignment**: Source mentions 31 requests but brief doesn't mandate inclusion.
