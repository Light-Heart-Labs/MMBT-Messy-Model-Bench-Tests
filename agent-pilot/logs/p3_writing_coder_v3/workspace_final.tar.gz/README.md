# Incident Rewrite Package

This directory contains three audience-specific rewrites of the internal outage memo (`/input/repo/draft_memo.md`), each tailored to its target audience per the specifications in `/input/repo/audience_briefs.json`.

## Output Files

- `ceo_brief.md` — Executive summary for CEO (≤250 words)
- `customer_email.md` — Mass email to affected customers (≤350 words)
- `legal_summary.md` — SLA-credit analysis for in-house counsel (≤400 words)

## Supporting Materials

- `decisions/` — ADR-style records explaining non-obvious choices per rewrite
- `research/notes.md` — Working notes documenting source facts and audience constraints

## Key Facts Preserved

- **Incident time**: 14:11 UTC to 18:24 UTC on Friday
- **Accounts impacted**: 11,400
- **Enterprise accounts with revenue impact**: ~28
- **Known downstream automation harm**: 4 cases
- **Support tickets**: 217
- **Credit/refund requests**: 31
- **SLA**: 99.9% monthly uptime, credits for breach

## Compliance Notes

- No facts were invented; all numbers and details derive from the source memo.
- Each rewrite adheres to its audience's must_include and must_not_include constraints.
- Word counts are within specified limits.
