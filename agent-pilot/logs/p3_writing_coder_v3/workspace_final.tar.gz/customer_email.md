Subject: Update on Friday’s Service Disruption and What We’re Doing Differently

Hi [Customer Name],

On Friday, between 14:11 and 18:24 UTC, our API experienced an outage that caused 502 errors for many of our customers. We know this disrupted your workflows, and we sincerely apologize.

A configuration change we made inadvertently caused our authentication service to throttle all incoming requests, which in turn made our API unavailable. Our team identified the issue and restored service by 18:24 UTC.

We understand this was especially disruptive for customers with automated systems, and we’re working directly with those teams to help recover any lost data or processing.

As part of our commitment to you, we’re implementing several changes:
- Adding staged rollouts for all configuration changes to catch issues before they affect everyone.
- Fixing the internal logic that caused this outage.
- Updating our monitoring to reflect the same endpoints our customers use.
- Improving our incident response communications so you’re informed sooner.

Per our Service Level Agreement, we’re offering SLA credits to affected accounts. You can request your credit by contacting your CSM or support@company.com. For enterprise customers, your CSM is available for a personalized review.

If you have questions or need assistance, please reach out to your CSM, our support team at support@company.com, or me directly at [Executive Name] at exec@company.com.

We’re grateful for your partnership and are committed to earning your trust every day.

Best regards,  
[Executive Name]  
[Title]
