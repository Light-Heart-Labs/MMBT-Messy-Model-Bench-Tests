# CEO Brief: Friday Outage Summary

**What happened**: A configuration change caused our primary API to return 502 errors for approximately 4 hours (14:11–18:24 UTC), impacting all customer accounts.

**Scope of impact**: 11,400 accounts affected; ~28 enterprise accounts (with named CSMs) experienced revenue-impacting downtime during their business hours. 217 support tickets filed; 31 credit/refund requests received.

**Board-level signal**: This is the second 4+ hour outage this year (the first was in February). A third such event would trigger a full reliability program overhaul.

**Key remediations**:
1. Add staged config deploys (canary rollout for configuration changes) — ~1 sprint.
2. Fix authentication service to use dynamic thresholds instead of hard-coded values — ~2 weeks.
3. Correct status-page monitoring to use customer-facing endpoints — completed.
4. Implement 15-minute incident acknowledgment protocol — in progress.

We will provide SLA credits to affected enterprise accounts and handle other credit requests case-by-case. The engineering team owns all remediations with clear timelines.
