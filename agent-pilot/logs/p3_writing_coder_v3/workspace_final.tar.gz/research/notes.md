# Working Notes

## Source Memo Summary

- **Incident time**: 14:11 UTC to 18:24 UTC on Friday
- **Root cause**: A config change doubled rate-limit thresholds for the internal authentication service. An internal limiter used a fraction of a hard-coded MAX value instead of the new configured value, causing all auth requests to be throttled.
- **Impact**:
  - 11,400 customer accounts impacted
  - ~28 enterprise accounts (with named CSMs) had real revenue impact during business hours
  - 4 downstream automation cases broke and required manual cleanup
  - 217 support tickets; 31 refund requests (some SLA credits, some full month credits)
- **Remediations**:
  1. Add canary deploys for config changes (1 sprint)
  2. Fix internal limiter to use actual global config instead of hard-coded MAX (2 weeks)
  3. Fix status-page check to use correct endpoints (already done)
  4. Improve incident communication (issue "we see it, we're working it" within 15 minutes)
  5. Update runbooks to include this failure mode
- **SLA**: 99.9% monthly uptime; credits for breach
- **Board signal**: Second 4+ hour outage in 2026 (first in February); third would trigger reliability program overhaul

## Key Facts to Preserve

- Exact time window: 14:11 UTC to 18:24 UTC
- Account count: 11,400
- Enterprise accounts: ~28 (with named CSMs)
- Known downstream automation harm: 4 cases
- Support tickets: 217
- Refund/credit requests: 31
- SLA: 99.9% monthly uptime

## Audience-Specific Constraints

### CEO Brief
- Must include: one-line summary, scope (accounts, money framing), second-occurrence-in-90-days framing, top 3-4 remediations
- Must NOT include: internal nicknames/apologies, engineering jargon, detailed technical explanations
- Tone: concise, executive, direct

### Customer Email
- Must include: outage acknowledgment, root cause in plain language, commitments, explicit SLA credit offer, contact path
- Must NOT include: named individual blame, engineering jargon, internal board signals, "second outage in 90 days"
- Tone: warm, direct, accountable

### Legal Summary
- Must include: exact time window, scope (account count, tier breakdown), SLA threshold and breach status, 4 downstream automation cases, credit handling recommendation
- Must NOT include: speculation, named blame, informal candor, marketing language, engineering remediation details
- Tone: precise, factual, dispassionate

## Decisions Log

### CEO Brief
- Will use "4-hour outage" instead of exact times for brevity
- Will group remediations into 4 high-level items (canary config deploys, config-system fix, status-page fix, communication protocol)
- Will phrase board signal as "second 4+ hour outage this year" without mentioning February specifically
- Will avoid mentioning specific customer impact dollar amounts since memo says "roughly 28 enterprise accounts had real revenue impact" without specifics

### Customer Email
- Will explain root cause as "a configuration change that inadvertently caused our authentication service to throttle all incoming requests" without technical details
- Will NOT mention Marcus or any engineer by name
- Will NOT mention "second outage in 90 days" or board signals
- Will offer SLA credits explicitly and provide contact paths (CSM, support, named executive)
- Will mention the 4 downstream automation cases as "some customers' downstream systems were affected" without technical details

### Legal Summary
- Will use exact times (14:11 UTC to 18:24 UTC)
- Will specify 11,400 accounts impacted, ~28 enterprise accounts
- Will explicitly state SLA was "nominally breached" for affected accounts
- Will specify 4 cases of known downstream automation harm
- Will recommend contractual credits for SLA-breach cases, case-by-case for relationship-driven requests
- Will avoid all remediation details (engineering work items)
