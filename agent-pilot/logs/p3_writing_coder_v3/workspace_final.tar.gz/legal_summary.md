# Legal Summary: SLA Credit Obligations — Friday Incident

## Incident Overview

- **Time window**: 14:11 UTC to 18:24 UTC on Friday.
- **Scope**: 11,400 customer accounts impacted; approximately 28 enterprise accounts (those with named CSMs) experienced revenue-impacting downtime during their business hours.
- **Known downstream harm**: 4 cases where customer downstream automation broke and required manual cleanup.

## SLA Terms and Breach Status

- **Contractual SLA**: 99.9% monthly uptime, with credits for breach.
- **Breach determination**: The incident duration and scope constitute a nominal breach of the 99.9% monthly uptime SLA for the affected accounts.

## Credit-Request Handling Recommendation

- **Contractual obligations**: SLA credits are due for all accounts where the SLA was breached (i.e., enterprise accounts and other impacted accounts that experienced service degradation during the incident window).
- **Relationship-driven requests**: For accounts requesting credits beyond contractual SLA breaches (e.g., no-impact accounts citing trust concerns), handle requests case-by-case per standard finance/CS protocol.

## Notes for Counsel

- This summary is limited to facts relevant to SLA-credit determinations.
- No speculation about future outages or systemic reliability concerns is included.
- Engineering remediation details (e.g., config-system fixes) are irrelevant to contractual obligations and omitted.
