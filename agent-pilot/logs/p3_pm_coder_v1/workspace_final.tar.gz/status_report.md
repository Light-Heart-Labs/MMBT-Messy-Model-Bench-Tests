# Project Aurora — Status Report (as of 2026-04-08)

## Headline

V1 is locked in for **mid-July GA**, with the embedded SDK in **private-beta only** (3–5 customers with extra contracts) due to an unresolved access-control security gap. Custom branding and native mobile are deferred to V2.

---

## Workstreams

| Workstream | Owner | Status | Blocking V1? |
|------------|-------|--------|--------------|
| Dashboard refresh (core) | Marcus (TL) | On track; query-layer 60% done, mid-May completion | No |
| Embedded SDK (query layer) | Marcus (TL) | 60% done, mid-May completion | Yes (for SDK) |
| Mobile (responsive) | Jen (UX) | On track, mid-May completion | No (V1 can ship without it) |
| Custom branding | Jen (UX) | Deferred to V2 | No |
| Panel-density fix (V1.1) | Roman (data) | 30% done, on track for August | No (known limitation in V1) |
| SDK access-control (IAM) | Roman + Priya (security) | IAM design started; IAM API discussion next week | Yes (for SDK GA) |

---

## Risks

| Severity | Risk | Notes |
|----------|------|-------|
| High | SDK access-control gap | No access-control layer for embedded dashboards (customer X → customer Y). Security team estimates 4 weeks minimum. Mitigation: V1 SDK is private-beta only with 3–5 customers who sign extra contracts (week 6) |
| Medium | Maevia expectation mismatch | Maevia was promised GA SDK at conference; they will push back when told it’s private-beta. Sara has call with their CSM (week 6) |
| Low | Panel-density limit (~40 panels/page) | Known limitation; documented in V1; architectural fix planned for V1.1 (August) (week 3) |

---

## Decisions Made

| Date | Decision | Decider |
|------|----------|---------|
| 2026-03-18 | Cut custom-branding from V1; defer to V2 | Brendan (CEO) |
| 2026-03-18 | Accept 40-panel-per-page limit as known limitation in V1 | Brendan (CEO) |
| 2026-03-18 | Mobile = web-responsive in V1; native in V2 | Team (Jen proposed, Sara agreed, Brendan approved) |
| 2026-04-08 | Ship V1 with embedded SDK in **private-beta only** (3–5 customers with extra contracts) | Brendan (CEO) |

---

## Milestones

| Target | Milestone | Owner |
|--------|-----------|-------|
| Mid-May | Query-layer completion | Marcus (TL) |
| Mid-May | Mobile-responsive completion | Jen (UX) |
| August | V1.1 (architectural fix + IAM API) | Roman (data) + Priya (security) |
| TBC (post-V1) | Custom-branding V2 | Jen (UX) |
| TBC (post-V1) | Native mobile V2 | Jen (UX) |

---

## Open Questions / Asks

1. **Legal involvement**: Who owns legal review of private-beta access-control contracts? (Sara needs this to proceed.)
2. **Maevia handling**: Should Brendan be involved in the Maevia conversation, or is Sara empowered to manage it?
3. **V1.1 scope**: Any changes to the V1.1 roadmap (architectural fix + IAM API + custom-branding start)?
