# Project Aurora — Working Notes

## Timeline Summary

- **Week 1 (2026-03-04)**: Kickoff. Brendan wants end-of-June GA. Scope = dashboard refresh + embedded SDK. Backend query layer needs 4-6 weeks. Custom branding and mobile are open questions. Panel-density limit (~40) is a concern.
- **Week 2 (2026-03-11)**: Revised estimate = 8 weeks for query layer. Custom branding adds ~3 weeks. Panel-density issue confirmed. End-of-June no longer realistic.
- **Week 3 (2026-03-18)**: Brendan negotiates timeline. Decision: cut custom-branding from V1, accept 40-panel limit as known limitation. Mobile = web-responsive in V1, native in V2. Query-layer still 8 weeks, blocked on code review.
- **Week 4 (2026-03-25)**: Query-layer moving (sub-reviewer found). Mobile scope: responsive = 4 weeks, native = 12+ weeks → responsive in V1. **Critical new risk**: SDK access-control gap (security model not built). Roman flags as blocker.
- **Week 5 (2026-04-01)**: Security team (Priya) says access-control = 4 weeks minimum. Options: (a) ship dashboard-only V1, SDK later; (b) private-beta SDK with 3-5 customers; (c) push V1 to August. Brendan absent; escalation needed.
- **Week 6 (2026-04-08)**: Brendan chooses **Option B** (private-beta SDK with 3-5 customers). Legal involvement needed for contracts. One customer (Maevia) was promised GA SDK at conference → needs handling.

## Workstream Status (most recent)

| Workstream | Owner | Status | Blocking V1? |
|------------|-------|--------|--------------|
| Dashboard refresh | Marcus (TL) | On track, mid-May query-layer completion | No (core) |
| Embedded SDK (query layer) | Marcus (TL) | 60% done, mid-May completion | Yes (for SDK) |
| Mobile (responsive) | Jen (UX) | On track, mid-May completion | No (V1 can ship without it) |
| Custom branding | Jen (UX) | Deferred to V2 | No |
| Panel-density architectural fix | Roman (data) | 30% done, on track for V1.1 (August) | No (known limitation in V1) |
| SDK access-control (IAM) | Roman + Priya (security) | IAM design started; IAM API discussion next week | Yes (for SDK GA) |

## Risks

1. **SDK access-control gap** (week 4, 5) — Severity: **High**. No access-control layer built for embedded dashboards (customer X embedding for customer Y). Security team says 4 weeks minimum. Decision: ship V1 with SDK in private-beta only with 3-5 customers who sign extra contracts.
2. **Maevia customer expectation** (week 6) — Severity: **Medium**. One customer (Maevia) was promised GA SDK at conference; they will push back when told it's private-beta. Sara has call with their CSM.
3. **Panel-density limit (~40 panels/page)** (week 1, 2, 3) — Severity: **Low**. Known limitation documented; architectural fix planned for V1.1.

## Decisions Made

| Date | Decision | Decider |
|------|----------|---------|
| 2026-03-18 | Cut custom-branding from V1; defer to V2 | Brendan (CEO) |
| 2026-03-18 | Accept 40-panel-per-page limit as known limitation in V1 | Brendan (CEO) |
| 2026-03-18 | Mobile = web-responsive in V1; native in V2 | Team (Jen proposed, Sara agreed, Brendan approved via timeline negotiation) |
| 2026-04-08 | Ship V1 with embedded SDK in **private-beta only** with 3-5 customers who sign extra access-control contracts | Brendan (CEO) |

## Milestones (targets & owners)

| Target | Milestone | Owner |
|--------|-----------|-------|
| Mid-May | Query-layer completion | Marcus (TL) |
| Mid-May | Mobile-responsive completion | Jen (UX) |
| August | V1.1 (architectural fix + IAM API) | Roman (data) + Priya (security) |
| TBC (post-V1) | Custom-branding V2 | Jen (UX) |
| TBC (post-V1) | Native mobile V2 | Jen (UX) |

## Open Questions / Asks for CEO

1. **Legal involvement**: Who owns legal review of private-beta access-control contracts? (Sara needs this to proceed.)
2. **Maevia handling**: Should Brendan be involved in the Maevia conversation, or is Sara empowered to manage it?
3. **V1.1 scope**: Any changes to the V1.1 roadmap (architectural fix + IAM API + custom-branding start)?
