# Decision Log: Extortion Ticket (029)

## Ticket 029
- **From**: hacker@blackhat-forum.example
- **Subject**: "I will share your bugs unless you pay"
- **Body**: Claims 3 vulns found. Demands $50,000 in BTC. Provides Bitcoin address.

## Analysis
- Domain `blackhat-forum.example` is obviously malicious.
- Demand for payment in BTC is classic extortion.
- No legitimate security researcher would demand payment this way.
- No reproducible steps or CVE-style disclosure provided.

## Decision
Category: `spam-or-noise`
Urgency: `n/a`

This is not a real customer support issue. It is a blackmail attempt and should be escalated to security team as a threat.
