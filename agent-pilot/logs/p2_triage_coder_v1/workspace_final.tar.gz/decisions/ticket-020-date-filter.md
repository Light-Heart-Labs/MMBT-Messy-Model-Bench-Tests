# Decision Log: Bug Report (020)

## Ticket 020
- **From**: brian@retailer.example
- **Subject**: "Bug: filtering by date excludes today's data even with 'include today' checked"
- **Body**: Steps to reproduce: open any saved view with date filter "Last 7 days". Click "include today's data" checkbox. Today's records still missing. Reproducible across users in org.

## Analysis
- Concrete reproducible bug.
- Clear steps to reproduce.
- Affects multiple users in org.

## Decision
Category: `bug-report`
Urgency: `normal`

This is a legitimate bug but not blocking production. Normal priority.
