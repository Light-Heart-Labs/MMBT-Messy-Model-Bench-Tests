# Decision Log: Bug Report (005)

## Ticket 005
- **From**: ben@ben-and-co.dev
- **Subject**: "Bug: CSV export drops the last row when filename has spaces"
- **Body**: Reproducer: any saved view, click Export → CSV, filename with space ("my report.csv"). Downloaded file missing last row. If no spaces, all rows present. Reliable. Browser: Firefox 134 on macOS.

## Analysis
- Concrete reproducible bug with clear steps.
- Specific to filenames with spaces.
- Reliable reproducibility.

## Decision
Category: `bug-report`
Urgency: `normal`

This is a legitimate bug but not blocking production. Normal priority.
