# Decision Log: Urgent Incidents

## Ticket 003 vs Ticket 016

Both are marked `urgent`, but for different reasons:

- **003**: Login page 503s affecting entire org (BC-44218). Board meeting at 11 EST → time-sensitive.
- **016**: API endpoint `/api/v2/exports` returning 500s since 14:00 UTC. SOC1 review tomorrow morning → production-down for a critical process.

These are **not duplicates** — different endpoints, different orgs (BC vs PE), different impact.

## Decision: Keep both as separate `incident-active` entries.

Both are `urgent` because:
- 003: Time-sensitive deadline (board meeting)
- 016: Critical dependency for SOC1 audit

No further action needed.
