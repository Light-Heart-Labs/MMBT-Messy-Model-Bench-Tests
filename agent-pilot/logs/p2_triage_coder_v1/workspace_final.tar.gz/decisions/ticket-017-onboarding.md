# Decision Log: General Question (017)

## Ticket 017
- **From**: hi@new-user.example
- **Subject**: "Tutorial / onboarding question — how do I import data?"
- **Body**: Just signed up. Trying to import CSV with customer data. Import wizard says "no valid columns found" but CSV definitely has headers. What format expected?

## Analysis
- Onboarding question about data import.
- User is new and trying to get started.

## Decision
Category: `general-question`
Urgency: `normal`

Standard onboarding question. Normal priority.
