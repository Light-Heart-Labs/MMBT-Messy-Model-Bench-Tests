# Decision Log: Duplicate Cluster — Dashboard Sharing Permission Issue

## Tickets
- **007**: From jordan.lee@mid-co.com — can't open dashboards shared by alex.petrov@mid-co.com. Gets "permission denied".
- **011**: From alex.petrov@mid-co.com — same user pair, same account (MC-3309), same issue: dashboards visible in sidebar but permission-denied when opened.

## Analysis
- Same org (`mid-co.com`)
- Same account ID (MC-3309)
- Same two users involved (jordan.lee and alex.petrov)
- Same symptom: dashboards visible but not accessible
- Ticket 011 explicitly references same scenario as 007

## Decision
- **007** is the original (earlier timestamp implied by content: "last week")
- **011** → `duplicate_of: "007"`

Both are `normal` — not production-down, but blocking collaboration.

Cluster: `["007", "011"]`
