# Decision Log: Bug Report (027)

## Ticket 027
- **From**: jamie.k@enterprise-dev.example
- **Subject**: "BUG: Report PDFs render charts at low resolution (looks pixelated)"
- **Body**: When exporting dashboard with charts to PDF, charts come out at ~72 DPI, visibly pixelated when printed. Web view looks fine. Tested on three dashboards.

## Analysis
- Concrete bug report with reproducible steps.
- Affects PDF export quality.
- Browser: Chrome 130 on Windows.

## Decision
Category: `bug-report`
Urgency: `normal`

This is a quality issue but not blocking functionality. Normal priority.
