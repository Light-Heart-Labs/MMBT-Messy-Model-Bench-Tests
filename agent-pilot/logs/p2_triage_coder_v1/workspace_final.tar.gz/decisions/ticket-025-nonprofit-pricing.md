# Decision Log: General Question (025)

## Ticket 025
- **From**: maya@curious-user.example
- **Subject**: "How does your pricing work for non-profits?"
- **Body**: Runs small environmental non-profit (501c3). Do you offer non-profit discounts? Looked on website but couldn't find anything specific.

## Analysis
- Pricing inquiry for non-profit organization.
- User is trying to determine if product is a fit.

## Decision
Category: `general-question`
Urgency: `normal`

Pricing inquiry for non-profit. Normal priority.
