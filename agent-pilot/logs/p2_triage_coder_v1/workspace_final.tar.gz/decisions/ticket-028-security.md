# Decision Log: Security Incident (028)

## Ticket 028
- **From**: critical-incident@major-bank.example
- **Subject**: "SECURITY — possible account compromise, freeze account immediately"
- **Body**: Unauthorized API key usage from foreign IPs in last 90 minutes. Requests immediate account freeze and API key revocation. Compliance team will need full access logs.

## Analysis
- Sent from `critical-incident@` domain — indicates serious security team.
- Account MB-8821 (major bank) — high-value target.
- Explicit request to freeze account and revoke API keys.
- Mentions compliance team and audit logs.

## Decision
Category: `security-incident`
Urgency: `urgent`

This is a confirmed security incident requiring immediate action. Account freeze and API key revocation are time-sensitive.
