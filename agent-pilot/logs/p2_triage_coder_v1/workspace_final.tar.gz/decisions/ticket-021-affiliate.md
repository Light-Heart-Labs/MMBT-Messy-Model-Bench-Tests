# Decision Log: Affiliate Spam (021)

## Ticket 021
- **From**: random@blog-hosting.example
- **Subject**: "Did you know you can save 80% on web hosting?"
- **Body**: 8 paragraphs of affiliate links to a hosting platform.

## Analysis
- No support request — pure marketing pitch.
- Affiliate link spam.
- No product-related inquiry.

## Decision
Category: `spam-or-noise`
Urgency: `n/a`

This is not a real customer support issue. It is unsolicited marketing and should be ignored.
