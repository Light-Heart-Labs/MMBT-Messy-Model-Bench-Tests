# Decision Log: Billing Refund (022)

## Ticket 022
- **From**: pat@small-business.example
- **Subject**: "Refund — service was down all weekend during our launch"
- **Body**: Platform was down 11 hours over weekend (per status page). Small business; this hurt them materially. Looking for at minimum a credit for the affected period. Account: SB-2204.

## Analysis
- Explicit refund/credit request for service downtime.
- References status page for downtime duration.
- Small business impact.

## Decision
Category: `billing-refund`
Urgency: `normal`

Service downtime refund requests should be addressed, but this is not an emergency. Normal priority.
