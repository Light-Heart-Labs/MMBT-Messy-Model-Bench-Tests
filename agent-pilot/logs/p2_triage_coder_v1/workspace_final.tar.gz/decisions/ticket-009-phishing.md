# Decision Log: Phishing Ticket (009)

## Ticket 009
- **From**: noreply@phishing-site.example
- **Subject**: "VERIFY YOUR ACCOUNT NOW or LOSE ACCESS"
- **Body**: Link to `http://totally-real-verify.example.com/login`. "Account Security Team"

## Analysis
- Domain `phishing-site.example` is obviously malicious.
- URL `totally-real-verify.example.com` is obviously fake.
- Impersonates "Account Security Team" — classic phishing vector.
- No legitimate support ticket would come from a domain named `phishing-site.example`.

## Decision
Category: `spam-or-noise`
Urgency: `n/a`

This is not a real customer support issue. It should be reported to security team as a potential phishing campaign.
