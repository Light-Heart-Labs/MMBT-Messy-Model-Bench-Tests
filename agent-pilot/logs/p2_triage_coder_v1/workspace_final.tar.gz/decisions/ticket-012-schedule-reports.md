# Decision Log: Feature Request (012)

## Ticket 012
- **From**: priya.k@datatools.example
- **Subject**: "Feature request: schedule reports to be emailed weekly"
- **Body**: Currently manually pull reports. Would love to schedule weekly email of top 5 dashboards as PDFs. Externally using cron + headless browser today. Account: DT-1198.

## Analysis
- Explicit feature request for scheduled report emails.
- Clear use case: automate manual reporting.

## Decision
Category: `feature-request`
Urgency: `normal`

Feature request for automation. Normal priority.
