# Decision Log: Account Management (026)

## Ticket 026
- **From**: hr@new-customer-org.example
- **Subject**: "Need to add 12 new seats and remove 3 old ones"
- **Body**: Account admin here. Onboarded 12 new analysts, 3 people left. Requests bulk seat update. Names attached in CSV.

## Analysis
- Seat add/remove request.
- Sent from HR (typical admin for seat management).
- Account NCO-3389.

## Decision
Category: `account-management`
Urgency: `normal`

Standard seat management request. Not urgent but needs to be processed in a business day.
