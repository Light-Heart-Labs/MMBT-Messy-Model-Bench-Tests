# How to Read This Output

## Files

- **`triage.json`** — The main output. Contains verdicts (`real` or `fabricated`) for all 15 issues, with evidence citations.
- **`notes.md`** — Summary table and key observations about the review process.
- **`decisions/`** — ADRs for borderline calls where the reasoning needed more space than the JSON evidence field allowed.

## Methodology

1. Read every source file in the codebase.
2. For each issue, verified:
   - Does the cited file exist?
   - Does the cited code/behavior actually exist at the claimed location?
   - If the file exists but the behavior doesn't, is the behavior present elsewhere?
3. Applied the rule: wrong file citation = fabricated, even if a similar issue exists elsewhere.

## Results

- **6 real issues** — confirmed in the code with specific line citations
- **9 fabricated issues** — either non-existent files, wrong file citations, or behaviors not present in the code
