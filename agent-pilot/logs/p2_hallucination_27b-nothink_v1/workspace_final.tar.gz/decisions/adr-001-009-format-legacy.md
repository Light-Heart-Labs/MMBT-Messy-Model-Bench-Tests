# ADR-001: Issue 009 — `format_legacy()` location

## Context

Issue 009 claims that `format_legacy()` is in `logalyzer/output.py` and is unused dead code.

## Investigation

- `format_legacy()` does exist, but in `logalyzer/utils.py:21`, not `output.py`.
- It is indeed unused — no other module imports it.
- `output.py` does not contain `format_legacy()`.

## Decision

**Verdict: fabricated**

Per the rules: "A wrong file citation makes the issue fabricated." The claim specifically states the function is in `output.py`, which is incorrect. While the function does exist elsewhere and is indeed unused, the original claim as written is not verifiable because it points to the wrong file.

## Rationale

The reviewer may have misremembered the file location, but the claim as stated ("The `format_legacy()` function in `output.py` is unused") is false because `format_legacy()` is not in `output.py`. A diligent reviewer would need to check the actual file to verify the claim, and the actual file does not contain the function.

---

# ADR-002: Issue 010 — Race condition in `load_iter()`

## Context

Issue 010 claims a race condition between file-handle creation and iteration in `load_iter()`.

## Investigation

The code in `logalyzer/io.py:36-41`:
```python
def load_iter(path: str) -> Iterable[LogEntry]:
    with open(path, "r") as f:
        for line in f:
            entry = parse_line(line)
            if entry is not None:
                yield entry
```

## Decision

**Verdict: fabricated**

The `with open()` and `for line in f` are in the same scope. There is no gap between file-handle creation and iteration where another thread could interfere. The file handle is created and immediately used within the same `with` block. Even if two threads called `load_iter()` on the same path, each would get its own file handle — there's no shared mutable state.

## Rationale

The claim describes a race condition that doesn't exist in the code structure. The reviewer may have been thinking of a different pattern (e.g., opening a file in one thread and reading in another), but that's not what the code does.
