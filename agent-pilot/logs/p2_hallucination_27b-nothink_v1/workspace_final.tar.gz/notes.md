# Verification Notes for logalyzer Code Review

## Summary

Out of 15 issues in the preliminary report, **6 are real** and **9 are fabricated**.

## Real Issues (6)

| # | Issue | Evidence |
|---|-------|----------|
| 001 | `from collections import Iterable` | `logalyzer/filters.py:5` — removed in Python 3.10+ |
| 002 | `eval()` on user input | `logalyzer/filters.py:59` — `expression_filter()` uses `eval()` |
| 004 | README claims tail mode | `README.md:14` — no `--tail` flag exists |
| 006 | `experimental.py` is dead code | No imports of `experimental` anywhere in codebase |
| 013 | O(n²) list/string concat in `load()` | `logalyzer/io.py:24,27` — `result = result + [entry]` and `accumulated = accumulated + ch` |
| 014 | O(n) IP allowlist lookup | `logalyzer/filters.py:36` — `entry.ip in allowlist` where allowlist is a list |

## Fabricated Issues (9)

| # | Issue | Why Fabricated |
|---|-------|----------------|
| 003 | SQL injection in parser | No SQL anywhere in `parser.py` or codebase |
| 005 | `--top` flag broken | `--top` is correctly defined with `type=int` and works fine |
| 007 | CSRF in web interface | `logalyzer/web.py` does not exist |
| 008 | 8192-char truncation | No truncation logic in `parse_line()` |
| 009 | `format_legacy()` in `output.py` | Function is in `utils.py`, not `output.py` |
| 010 | Race condition in `load_iter()` | No race condition — file handle and iteration are in same scope |
| 011 | Double-counting 3xx in `by_status()` | Simple Counter increment — no special 3xx handling |
| 012 | Stale cache in `cache.py` | `logalyzer/cache.py` does not exist |
| 015 | `__init__.py` imports `LogEntry` | `__init__.py` only has `__version__` — no imports at all |

## Key Observations

1. **Non-existent files**: The reviewer invented `web.py` (issue 007) and `cache.py` (issue 012). These files do not exist in the codebase.

2. **Wrong file citations**: Issue 009 claims `format_legacy()` is in `output.py`, but it's actually in `utils.py`. Per the rules, a wrong file citation makes the issue fabricated.

3. **Plausible but false claims**: Issues 003 (SQL injection), 008 (truncation), 010 (race condition), 011 (double-counting), and 015 (import error) describe problems that sound reasonable for a log analyzer but simply aren't present in the code.

4. **The real issues are all verifiable**: Each of the 6 real issues was confirmed by reading the actual source code and, where applicable, running the code.
