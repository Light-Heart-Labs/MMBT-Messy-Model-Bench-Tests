# Nimbus Logistics, Inc. — Investment Brief Package

## Overview

This package contains an executive brief and supporting analysis for evaluating a follow-on investment in Nimbus Logistics, Inc., a Series-B logistics-tech startup.

## Files

- **`brief.md`** — The 1-page executive brief (primary deliverable). Contains recommendation, key facts, analysis, and source attribution.
- **`key-facts.md`** — A list of every material fact incorporated into the brief, with source attribution.
- **`research/notes.md`** — Working notes from reading the five sources, including tensions and contradictions.
- **`decisions/adr.md`** — ADR-style record of framing choices (e.g., why recommend pass, not "more diligence needed").
- **`README.md`** — This file.

## How to Read the Brief

1. **Start with the recommendation** — “PASS” on follow-on at $560M.
2. **Read the key facts** — These are the substantive facts, not the press-release narrative.
3. **Review the analysis** — Understand how the facts were interpreted.
4. **Check the source attribution** — Every fact is tied to one of five sources (S1–S5).

## Source Quality

- **S1 (Press Release)** — Marketing narrative, lowest weight for factual accuracy.
- **S2 (TechCrunch)** — Independent reporting, high weight.
- **S3 (Blog Post)** — One employee’s view, medium weight, but details align with other sources.
- **S4 (Internal Memo)** — Internal strategy, high weight, highly specific.
- **S5 (SEC Filing)** — Factual, but low detail.

## Recommendation Conditions

The brief recommends passing, but would recommend participating if:
- Q2 2026 shows ARR >$38M and positive cash flow.
- Nimbus Lite migration succeeds without significant revenue loss.
- Three claimed $1M+ ARR contracts have closed.

## Final Note

This brief is based solely on the five provided sources. No external research was conducted.
