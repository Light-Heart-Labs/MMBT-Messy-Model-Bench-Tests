# Working Notes — Nimbus Logistics, Inc. Source Review

## Source-by-source summary

### SOURCE 1 — Press Release (company-issued)
- Series B: $84M, led by Lightning Capital, with participation from Sequoia, Accel, FedEx Ventures
- Post-money valuation: $560M (up from $230M in Series A)
- Total funding to date: $128M
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400 customers, 187 employees (Oakland, Austin, Berlin)
- Founded 2021 by Mira Patel and Daniel Wong (CTO)
- Customers: Maevia, Truant Coffee, Brick & Cobble
- Claims: "expansion into international markets and AI-driven inventory optimization"

### SOURCE 2 — TechCrunch News Article
- Nimbus lost two top-5 customers in late 2025:
  - Sundry Brands ($4.2M ARR) — non-renewed in November
  - Klatch (fast-fashion) — exited in December, migrated to competitor
- Company confirmed Sundry but called it "strategic mutual decision"
- TechCrunch source says adjusted ARR after December churn is $36-37M
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026
- CEO claims net retention >110% across 1,400 brands
- Series B originally intended to close at $720M valuation in late 2025, repriced down after Sundry non-renewal

### SOURCE 3 — Former Employee Blog Post
- 14 months at Nimbus as senior engineer
- Engineering quality: "genuinely good", "cleanest distributed-systems code"
- Compensation: $215K base + $50K equity for senior engineers (top quartile)
- Burn rate: ~$4M/month all-in vs ~$3.5M/month revenue (mid-2025)
- Layoffs: 22 people (~11% of org) in February 2025, mostly customer success & BD
- Customer concentration: top 5 = ~38% of ARR
- Recession of layoffs not publicly announced
- Path to survival: "default-alive" with new round, but requires faster growth or cuts

### SOURCE 4 — Internal Memo (leaked)
- CEO memo dated Feb 28, 2026: "Path to Profitability"
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
- Pause new hires in EMEA, reframe Berlin as "support hub" (not sales/expansion)
- Sunset "Nimbus Lite" tier (~310 customers, $5K-$20K ARR each), 90-day migration notice
- New $50M credit facility from Silicon Valley Bridge (described as "insurance, not operating capital")
- Goal: cash-flow breakeven by Q4 2026, extend runway to 36+ months, trigger Series C from strength

### SOURCE 5 — SEC Filing Summary (Form D)
- Filing date: 2026-01-22
- Total offering: $84M
- Total sold: $84M
- Number of investors: 7
- Date of first sale: 2026-01-14
- Security type: Series B Preferred
- Recipients: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures, 3 undisclosed
- Officer/director compensation: $0 disclosed
- Use of proceeds: "expansion, working capital, general corporate purposes"

---

## Key tensions and contradictions

| Topic | Press Release | TechCrunch | Blog Post | Memo | SEC |
|-------|---------------|------------|-----------|------|-----|
| Valuation | $560M (doubled) | Repriced down from $720M | — | — | — |
| ARR | $42M | $36-37M adjusted | — | — | — |
| Customer churn | Not mentioned | 2 top-5 customers lost | Top 5 = 38% of ARR | — | — |
| Burn rate | Not mentioned | — | $4M/month all-in | — | — |
| Revenue | Not mentioned | — | ~$3.5M/month | — | — |
| Layoffs | Not mentioned | — | 22 people (11%) in Feb 2025 | — | — |
| International expansion | Accelerate into international markets | Deferred to 2027 (per memo) | — | Pause EMEA hires, Berlin as support hub | — |
| Runway | Not mentioned | — | "default-alive" with new round | 36+ months with new actions | $50M credit facility secured |
| Pricing tier | Not mentioned | — | Nimbus Lite customers migrating | Sunset Nimbus Lite tier | — |

---

## Material facts to include in brief

1. **Funding & valuation**: $84M Series B at $560M post-money, repriced down from $720M intent [S1, S2]
2. **ARR**: $42M reported, but $36-37M adjusted for December 2025 churn [S1, S2]
3. **Customer concentration & churn**: Top 5 = ~38% of ARR; lost Sundry ($4.2M) and Klatch in late 2025 [S2, S3]
4. **Burn & unit economics**: ~$4M/month all-in spend vs ~$3.5M/month revenue (mid-2025) [S3]
5. **Layoffs**: 22 people (~11%) cut in Feb 2025, unannounced publicly [S3]
6. **International strategy shift**: From "accelerate expansion" to "pause EMEA, Berlin as support hub" [S1, S4]
7. **Pricing tier change**: Sunset Nimbus Lite (~310 customers) [S4]
8. **Runway & path to breakeven**: $50M credit facility + restructuring → cash-flow breakeven by Q4 2026 [S4]
9. **Engineering quality & culture**: Strong technical foundation, high burn, job insecurity risk [S3]
10. **Investor group**: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures, 3 undisclosed [S1, S5]

---

## Potential framing choices

- **Stance**: Recommend *pass* on follow-on, with clear conditions that would change the recommendation.
- **Rationale**: The company is in a defensive posture (layoffs, tier sunset, international deferral) rather than an offensive one (accelerated expansion). The $36-37M ARR vs $42M reported, combined with high burn and customer concentration, suggests underlying weakness masked by the press release.
- **Conditions to recommend**: If Q2 2026 shows >$38M ARR and positive cash flow, recommend participating.
