# ADR: Executive Brief Framing for Nimbus Logistics, Inc.

## Decision: Recommend *pass* on follow-on investment

### Rationale

The company's official narrative (press release) presents a story of explosive growth and strategic expansion. However, the other four sources reveal a more complex reality:

- The $42M ARR figure includes two major customers that churned in December 2025, bringing the adjusted run-rate to $36-37M.
- The Series B was repriced down from a $720M valuation to $560M, indicating investor concern.
- Internal burn rate (~$4M/month) exceeds revenue (~$3.5M/month), and the company is taking defensive actions (layoffs, tier sunset, international deferral) to extend runway.
- Customer concentration is high (top 5 = ~38% of ARR), and the loss of two top-5 customers was not publicly disclosed.

These factors suggest the company is in a defensive, survival-oriented phase rather than an offensive growth phase. The press release is a marketing document; the other sources reveal operational reality.

### Recommendation

**Pass** on the follow-on investment at the current $560M valuation.

### Conditions that would change the recommendation

- Q2 2026 financials show ARR >$38M and positive cash flow.
- Public confirmation of the $50M credit facility and successful migration of Nimbus Lite customers without significant revenue loss.
- Evidence that the three new $1M+ ARR contracts (claimed by CEO) have closed and are contributing to run-rate.

### Why not "more diligence needed"?

The brief is for a partner with 5 minutes. "More diligence needed" is a cop-out when the available evidence already reveals significant red flags. The conditions above are specific and actionable — they are the diligence that would be needed in a real investment process.

### Why not recommend participating?

At $560M, the valuation implies growth at all costs, but the company is cutting costs, laying off staff, and deferring international expansion. The unit economics are negative, and the customer base is concentrated with recent churn. The risk/reward profile is unfavorable at current terms.

### Source quality weighting

- Press release (S1): lowest weight — marketing narrative
- TechCrunch (S2): high weight — independent reporting, corroborated by other sources
- Blog post (S3): medium weight — one employee's view, but details align with other sources (e.g., layoffs, burn rate)
- Internal memo (S4): high weight — internal strategy, highly specific, aligns with TechCrunch and blog post
- SEC filing (S5): factual, but low detail — confirms funding amount and investor count
