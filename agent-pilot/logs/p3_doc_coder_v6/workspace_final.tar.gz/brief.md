# Executive Brief: Nimbus Logistics, Inc. — Follow-on Investment Recommendation

**Date:** 2026-04-01  
**Prepared for:** Investment Partner  
**Recommendation:** **PASS** on follow-on investment at current $560M valuation.

---

## Summary

Nimbus Logistics’ $84M Series B at $560M post-money is not the growth story it appears to be. The company is in a defensive posture: it repriced its round down from $720M, lost two top-5 customers (including $4.2M ARR), operates at a significant cash burn, and is now cutting international staff, sunsetting its lowest pricing tier, and deferring expansion to 2027. While engineering quality and founder credibility are strong, the unit economics and customer concentration pose material risk. **Recommend passing unless Q2 2026 shows ARR >$38M and positive cash flow.**

---

## Key Facts

### Funding & Valuation
- Series B: $84M at $560M post-money, repriced down from $720M intent after losing Sundry in December 2025 [S1, S2].
- New $50M credit facility secured, described internally as “insurance, not operating capital” [S4].
- Total funding to date: $128M [S1].

### Revenue & Growth
- Reported ARR: $42M as of Q4 2025, but includes two customers that churned in December [S1, S2].
- Adjusted run-rate ARR: $36–37M after December 2025 churn [S2].
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 and net retention >110% [S2].

### Customer Concentration & Churn
- Top 5 customers represent ~38% of ARR [S3].
- Lost Sundry Brands ($4.2M ARR) — non-renewed November 2025 [S2, S3].
- Lost Klatch (fast-fashion) — exited December 2025, migrated to competitor [S2].

### Unit Economics
- Burn: ~$4M/month all-in vs. ~$3.5M/month revenue (mid-2025) [S3].
- Layoffs: 22 people (~11% of org) in February 2025, unannounced publicly [S3].
- 187 employees across Oakland, Austin, Berlin [S1].

### Strategic Shifts
- International expansion: From “accelerate into international markets” to “pause EMEA, reduce Berlin from 41 to 28–30 by end Q2, reframe as support hub” [S1, S4].
- Pricing tier: Sunset “Nimbus Lite” (~310 customers, $5K–$20K ARR each), 90-day migration notice [S4].
- Goal: Cash-flow breakeven by Q4 2026 [S4].

---

## Analysis

### Strengths
- Engineering quality is strong: clean distributed-systems code, CTO Daniel Wong is highly capable [S3].
- Compensation is competitive for senior engineers ($215K base + $50K equity) [S3].
- Customer rapport is genuine; mid-market brands depend on the platform [S3].
- Founders Mira Patel and Daniel Wong are credible [S3].

### Risks
- **Customer concentration & churn**: Top 5 = 38% of ARR; loss of two top-5 customers in late 2025 was not disclosed in press release [S2, S3].
- **Negative unit economics**: $4M/month burn vs. $3.5M/month revenue implies unsustainable path [S3].
- **Defensive strategy**: Layoffs, tier sunset, and international deferral indicate survival mode, not growth mode [S4].
- **Valuation mismatch**: $560M valuation implies growth at all costs, but company is cutting costs and deferring expansion [S1, S4].

### Source Quality Assessment
- Press release (S1): marketing narrative — low weight for factual accuracy.
- TechCrunch (S2): independent reporting — high weight, corroborated by other sources.
- Blog post (S3): one employee’s view — medium weight, but details align with other sources (e.g., layoffs, burn rate).
- Internal memo (S4): internal strategy — high weight, highly specific, aligns with TechCrunch and blog post.
- SEC filing (S5): factual, but low detail — confirms funding amount and investor count.

---

## Recommendation

**Pass** on follow-on investment at $560M.

The company’s official narrative (press release) masks operational reality: repriced round, customer churn, negative unit economics, and defensive restructuring. While engineering quality and founder credibility are strengths, the risk/reward profile is unfavorable at current terms.

### Conditions to Recommend Participating
- Q2 2026 financials show ARR >$38M and positive cash flow.
- Public confirmation of successful Nimbus Lite migration without significant revenue loss.
- Evidence that the three claimed $1M+ ARR contracts have closed and are contributing to run-rate.

Without these, the company appears to be in a survival phase rather than a growth phase — a poor fit for a Series B follow-on.

---

## Appendix: Source Attribution
- [S1] Press Release (company-issued)
- [S2] TechCrunch News Article
- [S3] Personal Blog Post (former employee)
- [S4] Internal Memo (leaked to The Information)
- [S5] SEC Filing Summary (Form D)
