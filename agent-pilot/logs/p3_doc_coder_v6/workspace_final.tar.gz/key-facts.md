# Key Facts — Nimbus Logistics, Inc.

## Funding & Valuation
- Series B: $84M raised, led by Lightning Capital, with participation from Sequoia Capital, Accel, FedEx Ventures, and 3 undisclosed investors [S1, S5]
- Post-money valuation: $560M (down from $720M intent before repricing) [S1, S2]
- Total funding to date: $128M [S1]
- New $50M credit facility secured from Silicon Valley Bridge [S4]

## Revenue & Growth
- Reported ARR: $42M as of Q4 2025 [S1]
- Adjusted ARR (after December 2025 churn): $36-37M run-rate [S2]
- ARR growth: from $11M in 2024 to $42M in 2025 [S1]
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 [S2]
- CEO claims net retention >110% across 1,400 brands [S2]

## Customer Base & Churn
- Total customers: 1,400 [S1, S2]
- Top 5 customers: ~38% of ARR [S3]
- Lost Sundry Brands ($4.2M ARR) — non-renewed in November 2025 [S2, S3]
- Lost Klatch (fast-fashion) — exited December 2025, migrated to competitor [S2]

## Unit Economics & Operations
- Burn rate: ~$4M/month all-in (mid-2025) [S3]
- Revenue: ~$3.5M/month (mid-2025) [S3]
- Layoffs: 22 people (~11% of org) in February 2025, mostly customer success and BD [S3]
- Employees: 187 across Oakland, Austin, Berlin [S1]

## Strategic Shifts
- International expansion: From "accelerate into international markets" (press release) to "pause EMEA, reduce Berlin from 41 to 28-30 by end Q2, reframe as support hub" [S1, S4]
- Pricing tier: Sunset "Nimbus Lite" tier (~310 customers, $5K-$20K ARR each), 90-day migration notice [S4]
- Goal: Cash-flow breakeven by Q4 2026 [S4]

## Company Background
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) [S1]
- Platform: cloud-native logistics for mid-market e-commerce brands, combining warehouse management, carrier orchestration, and demand forecasting [S1]
- Customers: Maevia, Truant Coffee, Brick & Cobble [S1]

## Source Attribution Key
- [S1] Press Release (company-issued)
- [S2] TechCrunch News Article
- [S3] Personal Blog Post (former employee)
- [S4] Internal Memo (leaked to The Information)
- [S5] SEC Filing Summary (Form D)
