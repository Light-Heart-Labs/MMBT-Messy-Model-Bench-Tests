# Decision: Ticket 028 is a security incident

Ticket 028 reports "unauthorized API key usage from foreign IP addresses" with active compromise detected "in the last 90 minutes."

Key indicators:
- "freeze account... NOW"
- "revoke all API keys"
- "Compliance team will need full access log"
- From `critical-incident@major-bank.example` domain (implies seriousness)

This is not a general login issue — it's an active security incident requiring immediate response.

Category: `security-incident`
Urgency: `urgent`
