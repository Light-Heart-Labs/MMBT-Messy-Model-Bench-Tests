# Decision Log: Urgent Incidents

## Ticket 003 vs Ticket 016

Both tickets describe urgent production issues, but they are distinct:

- **Ticket 003** (003): Login page 503s affecting entire org (UI issue)
- **Ticket 016** (016): API `/api/v2/exports` endpoint 500s (API issue)

These are separate system components and should be tracked independently.

## Ticket 014, 023, 030 — Duplicate Cluster

All three are from `ops@major-customer.com` and refer to the same underlying issue: API rate limits blocking nightly ingestion.

- 014: Initial report (original)
- 023: Follow-up (duplicate_of: 014)
- 030: Third follow-up (duplicate_of: 014)

Urgency for all three is `urgent` because:
- 014: Explicitly states $48k/yr contract and production impact
- 023: Growing backlog (200 GB/day) and mentions quarterly review deadline
- 030: States blocking $48k of contracted business

## Ticket 007 vs Ticket 011 — Duplicate Cluster

Both from `mid-co.com` org, same account (MC-3309), same issue: dashboard sharing permission denied.

- 007: jordan.lee reports issue
- 011: alex.petrov (the sharer) reports same issue

Duplicate cluster: ["007", "011"] — original is 007 (lower number).

## Ticket 009, 029 — Spam/Noise

- 009: Phishing email impersonating Account Security Team — clear phishing attempt
- 029: Extortion threat — obvious spam/noise

Both are `spam-or-noise` with urgency `n/a`.

## Ticket 004, 021 — Spam/Noise

- 004: Requests "free Pixar character collectables" — fictitious premise
- 021: Affiliate marketing pitch — obvious noise

Both are `spam-or-noise` with urgency `n/a`.

## Ticket 010, 018 — External Business

- 010: Podcast sponsorship pitch — marketing, not support
- 018: Acquisition inquiry — business development, not support

Both are `external-business` with urgency `low` (no SLA applies).

## Ticket 019 — Legal/Compliance

GDPR data export request with case reference and legal firm letterhead — clear `legal-compliance` with `urgent` (30-day window per GDPR).

## Ticket 028 — Security Incident

Account compromise report with active unauthorized API key usage — `security-incident` with `urgent`.

## Ticket 001, 008, 013, 020, 027 — Billing/Refund vs Bug

- 001: Double charge — `billing-refund` (explicit refund ask)
- 008: Pro-rated refund for unused period — `billing-refund`
- 013: Accidental upgrade — `billing-refund`
- 020: Date filter bug — `bug-report` (reproducible issue)
- 027: Low-res PDF charts — `bug-report`

## Ticket 002, 012, 015, 025 — Feature/General

- 002: SAML SSO request — `feature-request`
- 012: Scheduled report emails — `feature-request`
- 015: Dark mode request — `feature-request`
- 025: Non-profit pricing inquiry — `general-question`

## Ticket 005, 017, 024, 026 — Bug/Account/Support

- 005: CSV export bug (spaces in filename) — `bug-report`
- 017: Onboarding/import question — `general-question`
- 024: Webhook delivery issue — `bug-report`
- 026: Seat add/remove — `account-management`

## Ticket 006 — Account Cancellation

Explicit cancellation request — `account-management` with `normal` urgency.

## Ticket 023 — Duplicate Follow-up

Already handled in 014/023/030 cluster.

## Ticket 022 — Billing Refund Due to Service Down

Explicit credit request due to downtime — `billing-refund`.
