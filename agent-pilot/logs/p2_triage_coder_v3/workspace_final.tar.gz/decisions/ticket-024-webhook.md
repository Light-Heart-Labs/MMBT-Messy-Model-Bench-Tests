# Decision: Ticket 024 is a bug-report

Ticket 024 describes a webhook delivery issue:

- Webhook endpoint returns 200 OK to test pings (verified in logs)
- But actual event payloads are not arriving
- Started Tuesday (time-bound)
- Account: PI-1166

This is a reproducible integration failure — the product is not delivering events as expected despite appearing to acknowledge them.

Category: `bug-report`
Urgency: `normal` (no explicit deadline mentioned, but integration failure is blocking)
