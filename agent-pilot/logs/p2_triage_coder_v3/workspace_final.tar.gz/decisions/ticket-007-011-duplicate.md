# Decision: Tickets 007 and 011 are duplicates

Both tickets describe the same dashboard sharing permission issue:

- Ticket 007: jordan.lee reports they can't open dashboards shared by alex.petrov
- Ticket 011: alex.petrov reports he shared dashboards with jordan.lee and they get permission denied

Same account (MC-3309), same users, same issue.

Ticket 007 is the original (lower number), so 011 has `duplicate_of: "007"`.
