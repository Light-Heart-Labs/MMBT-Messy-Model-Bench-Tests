# ADR-003: Chart Convention — Sequential Colormap Over Diverging

**Date:** 2026-04-25
**Status:** Accepted

## Context
For the operating margin improvement chart (Slide 5), need to decide between a
sequential colormap (dark to light) and a diverging colormap (red to blue through
white).

## Decision
**Sequential colormap** (dark navy → teal → light teal) for operating margin
improvement visualization.

## Rationale
1. **The data has a natural zero point at current price** — the operating margin
   is improving from -50% to -7%, but the story is about the trajectory, not
   about crossing zero. A sequential colormap emphasizes the direction of change.
2. **Diverging colormaps imply a meaningful midpoint** — red-to-blue through white
   suggests that zero is the most important point. But for this deck, the
   inflection points (FCF positive, margin improvement) are more important than
   the zero crossing.
3. **Consistency with scenario colors** — the bear/base/bull scenarios use
   red/teal/green, which are diverging. Using a sequential colormap for
   operating margin avoids confusion between the two color systems.
4. **The improvement narrative** — the story is "margins are getting better,"
   not "margins are going from bad to good." A sequential colormap reinforces
   the improvement narrative.

## Alternatives Considered
- **Diverging colormap (red → white → blue):** Would emphasize the zero crossing
  as the most important point. But the zero crossing is not the thesis — the
  trajectory is.
- **Red → green:** Too associated with stock market "up/down." Would confuse
  with price direction.
- **Monochrome:** Too conservative. Would not distinguish between time periods
  effectively.
