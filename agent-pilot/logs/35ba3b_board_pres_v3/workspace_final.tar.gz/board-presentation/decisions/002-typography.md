# ADR-002: Typography Selection

**Date:** 2026-04-25
**Status:** Accepted

## Context
Need a font that is clean, modern, and appropriate for a technical board audience.
Must be available in python-pptx without requiring external font files.

## Decision
**Headings:** Inter Bold (weight 700)
**Body text:** Inter Regular (weight 400)
**Numbers:** Inter Medium (weight 500) with tabular numbers

## Rationale
1. **Inter is a system font** available on most Linux systems and in python-pptx
   without requiring external font files.
2. **Inter is designed for screens** — it has excellent readability at small sizes,
   which matters for a board deck that may be projected or viewed on laptops.
3. **Inter has a technical feel** — it's used in many developer tools and data
   platforms, which signals "this deck was built by an analytical agent" rather
   than a marketing team.
4. **Tabular numbers** ensure that financial figures align vertically in tables,
   making it easier to compare numbers across rows.

## Alternatives Considered
- **Roboto:** Also a system font but has a more "consumer" feel. Less appropriate
  for a technical board.
- **Source Code Pro:** Too monospaced for body text. Would look like code, not
  a financial presentation.
- **Helvetica:** Classic but overused. Would feel generic rather than distinctive.
- **Custom font files:** Would require embedding .ttf files in the repo, increasing
  complexity and potential licensing issues.
