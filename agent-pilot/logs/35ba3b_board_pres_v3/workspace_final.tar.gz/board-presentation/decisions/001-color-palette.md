# ADR-001: Color Palette Selection

**Date:** 2026-04-25
**Status:** Accepted

## Context
Need a color palette for the board presentation that is distinctive but professional,
and that reinforces the data rather than decorating it.

## Decision
**Primary background:** Deep navy (#1a2332)
**Primary text:** White (#ffffff)
**Accent/positive:** Teal (#00b4d8)
**Bear scenario:** Coral/red (#e63946)
**Base scenario:** Teal/blue (#00b4d8)
**Bull scenario:** Green (#2a9d8f)
**Neutral/secondary:** Slate gray (#6c757d)
**Highlight/key numbers:** Amber (#f4a261)

## Rationale
1. **Navy background** conveys seriousness and professionalism appropriate for a board
   deck. It also makes charts pop more than a white background.
2. **Teal as primary accent** is distinctive but not flashy. It signals "this is the
   agent's brand" without being distracting.
3. **Scenario colors are consistent** across all slides: bear = red, base = teal,
   bull = green. This allows the board to instantly recognize scenario context
   regardless of which slide they're looking at.
4. **Amber for key numbers** draws the eye to the most important data points
   (price target, recommendation, upside %) without using red/green which could
   be confused with scenario colors.
5. **No clip art or generic imagery** — charts are the visual centerpiece.

## Alternatives Considered
- **White background:** More traditional but less distinctive. Charts would be
  less visually impactful.
- **Dark mode with blue accent:** Too similar to default IDE themes. Would feel
  like a developer tool, not a board deck.
- **Red/green for bear/bull:** Too associated with stock market "up/down" which
  could confuse with price direction. The scenario colors are about probability,
  not price movement.
