# ADR-005: Competitive Landscape — Scatter Plot Over Pie Chart

**Date:** 2026-04-25
**Status:** Accepted

## Context
The competitive landscape slide needs to show GitLab's position relative to
comparable companies. Need to decide on the visualization type.

## Decision
**Scatter plot: Revenue Growth (x-axis) vs. EV/Revenue (y-axis)** with bubble
size representing market cap. GitLab highlighted in a distinct color.

## Rationale
1. **Pie charts obscure the actual thesis** — a market-share pie would show
   GitLab's small share but would not reveal the key insight: GitLab has high
   growth at a low multiple. The scatter plot makes this visible.
2. **Two dimensions of comparison** — revenue growth shows the growth story,
   EV/Revenue shows the valuation story. Together they reveal the mispricing.
3. **Bubble size adds a third dimension** — market cap shows scale, allowing
   the board to see that GitLab is small-cap despite its growth.
4. **GitLab is the outlier** — in the upper-left quadrant (high growth, low
   multiple). This is the visual embodiment of the mispricing thesis.

## Alternatives Considered
- **Market-share pie chart:** Would show GitLab's small share but would obscure
  the valuation gap. A board member would see "GitLab is small" but not
  "GitLab is cheap for its growth."
- **Bar chart of multiples:** Would show the multiple gap but not the growth
  context. A low multiple could mean "cheap" or "broken." The scatter plot
  resolves this ambiguity.
- **Radar chart:** Too many dimensions for a board presentation. Would be
  hard to read and hard to compare.
- **Heat map:** Would show relative values but not the relationship between
  growth and valuation.
