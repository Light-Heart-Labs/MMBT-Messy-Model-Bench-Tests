# ADR-004: Scenario Visualization — Probability-Weighted Distribution

**Date:** 2026-04-25
**Status:** Accepted

## Context
The bear/base/bull scenarios from the memo must appear as a real visualization,
not three bullet points. Need to decide on the chart type.

## Decision
**Probability-weighted violin plot** showing the distribution of price targets
across scenarios, with probability weights (25%/50%/25%) visualized as width.

## Rationale
1. **Violin plots show distribution shape** — not just three points, but the
   range and density of outcomes within each scenario.
2. **Probability weights are encoded in width** — the base case (50%) is twice
   as wide as bear or bull (25% each), visually communicating the probability
   assignment.
3. **The probability-weighted target ($45.98) appears as a line** across the
   distribution, showing where the weighted average falls.
4. **This is not a bell curve** — the distribution is intentionally asymmetric
   (bear at $18.58, bull at $88.30), reflecting the actual scenario assumptions.

## Alternatives Considered
- **Three-bar chart:** Too simple. Doesn't show the probability weighting.
- **Box plot:** Shows quartiles but not the probability weights clearly.
- **Monte Carlo histogram:** Would require simulating thousands of scenarios.
  The memo only has three discrete scenarios, so a histogram would be misleading.
- **Fan chart:** Good for time series but not for a single-point distribution.
- **Scatter plot with jitter:** Too abstract for a board presentation.
