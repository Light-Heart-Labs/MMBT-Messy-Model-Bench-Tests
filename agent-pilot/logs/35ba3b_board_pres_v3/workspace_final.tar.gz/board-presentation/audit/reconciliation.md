# Reconciliation: 5 Random Numbers from the Deck

This file spot-checks 5 numbers from the deck by fully reconciling each back to the
input repo. A board member should be able to follow each reconciliation and land on
the source data in under two minutes.

---

## Reconciliation #1: Revenue FY2026 = $955M

**Deck location:** Slide 3 (The Thesis), Slide 5 (Financial Trajectory)

**Step 1: Find the source file**
```
$ cat /input/repo/extracted/income_statement_annual.csv | grep "Total Revenue"
Total Revenue,955224000.0,759249000.0,579906000.0,424336000.0,
```

**Step 2: Identify the correct column**
- Column headers: 2026-01-31, 2025-01-31, 2024-01-31, 2023-01-31, 2022-01-31
- FY2026 (ended Jan 31, 2026) = 955,224,000

**Step 3: Convert to deck format**
- 955,224,000 / 1,000,000 = $955.2M → rounded to $955M in the deck
- **MATCH: ✓**

**Step 4: Verify the commit**
```
$ cd /input/repo && git log --oneline --all -- extracted/income_statement_annual.csv
ea3b335 Complete investment memo, financial model, and all supporting documentation
```

**Conclusion:** The $955M figure is correct. It comes from yfinance data (extracted/income_statement_annual.csv),
which sources from SEC filings. The value 955,224,000 rounds to $955M.

---

## Reconciliation #2: NRR FY2026 = 115%

**Deck location:** Slide 3 (The Thesis), Slide 8 (Risk Assessment)

**Step 1: Find the source file**
```
$ python3 -c "import json; d=json.load(open('/input/repo/extracted/financial_summary.json')); print(d['nrr'])"
[120, 118, 117, 116, 115]
```

**Step 2: Map to fiscal years**
```
$ python3 -c "import json; d=json.load(open('/input/repo/extracted/financial_summary.json')); print(list(zip(d['fy_labels'], d['nrr'])))"
[('FY2022', 120), ('FY2023', 118), ('FY2024', 117), ('FY2025', 116), ('FY2026', 115)]
```

**Step 3: Verify the value**
- FY2026 NRR = 115%
- **MATCH: ✓**

**Step 4: Verify the commit**
```
$ cd /input/repo && git log --oneline --all -- extracted/financial_summary.json
ea3b335 Complete investment memo, financial model, and all supporting documentation
```

**Conclusion:** The 115% NRR figure is correct. It comes from financial_summary.json,
which was derived from earnings call transcripts (per the memo's data provenance section).

---

## Reconciliation #3: Probability-Weighted Target = $45.98

**Deck location:** Slide 2 (Recommendation at a Glance), Slide 9 (Scenarios)

**Step 1: Find the source values**
```
$ grep -A6 "Scenario Analysis" /input/repo/memo/gitlab_investment_memo.md
| Bear | 25% | 12% | 12.0% | 2.0% | $18.58 |
| Base | 50% | 20% | 10.5% | 3.0% | $38.52 |
| Bull | 25% | 28% | 9.0% | 4.0% | $88.30 |
| **Probability-Weighted** | **100%** | — | — | — | **$45.98** |
```

**Step 2: Verify the calculation**
```
$ python3 -c "print(0.25 * 18.58 + 0.50 * 38.52 + 0.25 * 88.30)"
45.98
```

**Step 3: Verify the math**
- Bear: 0.25 × $18.58 = $4.645
- Base: 0.50 × $38.52 = $19.260
- Bull: 0.25 × $88.30 = $22.075
- Sum: $4.645 + $19.260 + $22.075 = $45.980
- **MATCH: ✓**

**Conclusion:** The $45.98 probability-weighted target is mathematically correct.
It is the weighted average of the three scenario price targets.

---

## Reconciliation #4: Operating Margin FY2026 = -7.4%

**Deck location:** Slide 5 (Financial Trajectory)

**Step 1: Find the source values**
```
$ python3 -c "
import csv
with open('/input/repo/extracted/income_statement_annual.csv') as f:
    reader = csv.DictReader(f)
    for row in reader:
        if 'Total Revenue' in row and 'Operating Income' in row:
            rev = float(row['2026-01-31'])
            op = float(row['2026-01-31'])  # Need to find operating income
            break
"
```

**Step 2: Extract the correct fields**
```
$ grep "Operating Income" /input/repo/extracted/income_statement_annual.csv
Operating Income,-70481000.0,-142715000.0,-187440000.0,-211411000.0,
$ grep "Total Revenue" /input/repo/extracted/income_statement_annual.csv
Total Revenue,955224000.0,759249000.0,579906000.0,424336000.0,
```

**Step 3: Calculate the margin**
```
$ python3 -c "print(-70481000 / 955224000 * 100)"
-7.378...
```

**Step 4: Round to deck format**
- -7.378% → rounded to -7.4% in the deck
- **MATCH: ✓**

**Conclusion:** The -7.4% operating margin is correct. It is calculated as
Operating Income (-$70.5M) / Total Revenue ($955.2M) = -7.38%, rounded to -7.4%.

---

## Reconciliation #5: GitLab EV/Revenue = 2.56x

**Deck location:** Slide 6 (Competitive Position), Slide 7 (Mispricing Thesis)

**Step 1: Find the source file**
```
$ python3 -c "import json; d=json.load(open('/input/repo/extracted/competitor_data.json')); print(d['GTLB']['ev_revenue'])"
2.559
```

**Step 2: Verify the calculation**
```
$ python3 -c "import json; d=json.load(open('/input/repo/extracted/company_info.json')); print(f'Market Cap: \${d[\"marketCap\"]/1e9:.2f}B, Enterprise Value: \${d[\"enterpriseValue\"]/1e9:.2f}B, Revenue: \${d[\"totalRevenue\"]/1e9:.2f}B')"
Market Cap: $3.66B, Enterprise Value: $2.44B, Revenue: $0.96B
```

**Step 3: Verify EV/Revenue**
```
$ python3 -c "print(2444528128 / 955224000)"
2.559...
```

**Step 4: Round to deck format**
- 2.559x → rounded to 2.56x in the deck
- **MATCH: ✓**

**Conclusion:** The 2.56x EV/Revenue is correct. It is calculated as Enterprise Value
($2.44B) / Revenue ($0.96B) = 2.56x.

---

## Summary

| # | Number | Source | Calculated | Match |
|---|--------|--------|------------|-------|
| 1 | Revenue FY2026: $955M | income_statement_annual.csv | 955,224,000 → $955M | ✓ |
| 2 | NRR FY2026: 115% | financial_summary.json | 115 | ✓ |
| 3 | Weighted target: $45.98 | memo scenario table | 0.25×18.58 + 0.50×38.52 + 0.25×88.30 = 45.98 | ✓ |
| 4 | Op Margin FY2026: -7.4% | income_statement_annual.csv | -70,481,000 / 955,224,000 = -7.38% → -7.4% | ✓ |
| 5 | EV/Revenue: 2.56x | competitor_data.json | 2,444,528,128 / 955,224,000 = 2.559 → 2.56x | ✓ |

All 5 numbers reconcile correctly to their source data in the input repo.
