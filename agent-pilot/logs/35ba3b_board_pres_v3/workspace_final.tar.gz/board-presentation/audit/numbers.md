# Audit: Numbers in the Deck

Every number in the deck, with its source path in the input repo.

## Slide 2 — Recommendation at a Glance

| Number | Source File | Line/Field | Input Repo Path |
|--------|------------|------------|-----------------|
| Current Price: $21.51 | company_info.json | currentPrice | /input/repo/extracted/company_info.json |
| Market Cap: $3.66B | company_info.json | marketCap | /input/repo/extracted/company_info.json |
| Price Target: $42.00 | gitlab_investment_memo.md | 12-Month Price Target | /input/repo/memo/gitlab_investment_memo.md |
| Upside: 95% | gitlab_investment_memo.md | 95% upside | /input/repo/memo/gitlab_investment_memo.md |
| Probability-Weighted: $45.98 | gitlab_investment_memo.md | Probability-Weighted Target | /input/repo/memo/gitlab_investment_memo.md |
| Upside: 114% | gitlab_investment_memo.md | 114% upside | /input/repo/memo/gitlab_investment_memo.md |

## Slide 3 — The Thesis

| Number | Source File | Line/Field | Input Repo Path |
|--------|------------|------------|-----------------|
| Revenue FY2023: $424M | income_statement_annual.csv | Total Revenue 2023-01-31 | /input/repo/extracted/income_statement_annual.csv |
| Revenue FY2026: $955M | income_statement_annual.csv | Total Revenue 2026-01-31 | /input/repo/extracted/income_statement_annual.csv |
| 3-year CAGR: 30% | gitlab_investment_memo.md | 30% CAGR | /input/repo/memo/gitlab_investment_memo.md |
| ARR FY2026: $860M | financial_summary.json | arr[4] | /input/repo/extracted/financial_summary.json |
| NRR FY2026: 115% | financial_summary.json | nrr[4] | /input/repo/extracted/financial_summary.json |
| Cash & Investments: $1.26B | balance_sheet_annual.csv | Cash Cash Equivalents And Short Term Investments 2026-01-31 | /input/repo/extracted/balance_sheet_annual.csv |
| Total Debt: $0.2M | balance_sheet_annual.csv | Total Debt 2026-01-31 | /input/repo/extracted/balance_sheet_annual.csv |

## Slide 4 — What Would Change the Recommendation

| Number | Source File | Line/Field | Input Repo Path |
|--------|------------|------------|-----------------|
| NRR threshold: 110% | gitlab_investment_memo.md | NRR decline risk | /input/repo/memo/gitlab_investment_memo.md |

## Slide 5 — Financial Trajectory

| Number | Source File | Line/Field | Input Repo Path |
|--------|------------|------------|-----------------|
| Revenue FY2023: $424M | income_statement_annual.csv | Total Revenue 2023-01-31 | /input/repo/extracted/income_statement_annual.csv |
| Revenue FY2024: $580M | income_statement_annual.csv | Total Revenue 2024-01-31 | /input/repo/extracted/income_statement_annual.csv |
| Revenue FY2025: $759M | income_statement_annual.csv | Total Revenue 2025-01-31 | /input/repo/extracted/income_statement_annual.csv |
| Revenue FY2026: $955M | income_statement_annual.csv | Total Revenue 2026-01-31 | /input/repo/extracted/income_statement_annual.csv |
| Op Margin FY2023: -49.8% | income_statement_annual.csv | Operating Income / Total Revenue 2023-01-31 | /input/repo/extracted/income_statement_annual.csv |
| Op Margin FY2024: -32.3% | income_statement_annual.csv | Operating Income / Total Revenue 2024-01-31 | /input/repo/extracted/income_statement_annual.csv |
| Op Margin FY2025: -18.8% | income_statement_annual.csv | Operating Income / Total Revenue 2025-01-31 | /input/repo/extracted/income_statement_annual.csv |
| Op Margin FY2026: -7.4% | income_statement_annual.csv | Operating Income / Total Revenue 2026-01-31 | /input/repo/extracted/income_statement_annual.csv |
| FCF FY2023: -$84M | cash_flow_annual.csv | Free Cash Flow 2023-01-31 | /input/repo/extracted/cash_flow_annual.csv |
| FCF FY2024: $33M | cash_flow_annual.csv | Free Cash Flow 2024-01-31 | /input/repo/extracted/cash_flow_annual.csv |
| FCF FY2025: -$68M | cash_flow_annual.csv | Free Cash Flow 2025-01-31 | /input/repo/extracted/cash_flow_annual.csv |
| FCF FY2026: $222M | cash_flow_annual.csv | Free Cash Flow 2026-01-31 | /input/repo/extracted/cash_flow_annual.csv |
| Revenue FY2027E: $1,146M | gitlab_investment_memo.md | FCF Projections table | /input/repo/memo/gitlab_investment_memo.md |
| Revenue FY2028E: $1,352M | gitlab_investment_memo.md | FCF Projections table | /input/repo/memo/gitlab_investment_memo.md |
| Revenue FY2029E: $1,555M | gitlab_investment_memo.md | FCF Projections table | /input/repo/memo/gitlab_investment_memo.md |

## Slide 6 — Competitive Position

| Number | Source File | Line/Field | Input Repo Path |
|--------|------------|------------|-----------------|
| GTLB EV/Revenue: 2.56x | competitor_data.json | GTLB.ev_revenue | /input/repo/extracted/competitor_data.json |
| TEAM EV/Revenue: 3.22x | competitor_data.json | TEAM.ev_revenue | /input/repo/extracted/competitor_data.json |
| DDOG EV/Revenue: 12.39x | competitor_data.json | DDOG.ev_revenue | /input/repo/extracted/competitor_data.json |
| MDB EV/Revenue: 7.33x | competitor_data.json | MDB.ev_revenue | /input/repo/extracted/competitor_data.json |
| Peer avg EV/Revenue: 7.03x | gitlab_investment_memo.md | peer average EV/Revenue multiple | /input/repo/memo/gitlab_investment_memo.md |

## Slide 7 — Mispricing Thesis

| Number | Source File | Line/Field | Input Repo Path |
|--------|------------|------------|-----------------|
| Current EV/Revenue: 2.6x | competitor_data.json | GTLB.ev_revenue | /input/repo/extracted/competitor_data.json |
| Peer avg EV/Revenue: 7.0x | gitlab_investment_memo.md | peer average EV/Revenue multiple | /input/repo/memo/gitlab_investment_memo.md |
| Sell-side mean target: $30.79 | company_info.json | targetMeanPrice | /input/repo/extracted/company_info.json |
| Sell-side mean upside: 43% | calculated | ($30.79 - $21.51) / $21.51 | derived from company_info.json |

## Slide 8 — Risk Assessment

| Number | Source File | Line/Field | Input Repo Path |
|--------|------------|------------|-----------------|
| NRR FY2022: 120% | financial_summary.json | nrr[0] | /input/repo/extracted/financial_summary.json |
| NRR FY2026: 115% | financial_summary.json | nrr[4] | /input/repo/extracted/financial_summary.json |

## Slide 9 — Bear/Base/Bull Scenarios

| Number | Source File | Line/Field | Input Repo Path |
|--------|------------|------------|-----------------|
| Bear price: $18.58 | gitlab_investment_memo.md | Scenario Analysis table | /input/repo/memo/gitlab_investment_memo.md |
| Base price: $38.52 | gitlab_investment_memo.md | Scenario Analysis table | /input/repo/memo/gitlab_investment_memo.md |
| Bull price: $88.30 | gitlab_investment_memo.md | Scenario Analysis table | /input/repo/memo/gitlab_investment_memo.md |
| Weighted target: $45.98 | gitlab_investment_memo.md | Probability-Weighted | /input/repo/memo/gitlab_investment_memo.md |
| Bear probability: 25% | gitlab_investment_memo.md | Scenario Analysis table | /input/repo/memo/gitlab_investment_memo.md |
| Base probability: 50% | gitlab_investment_memo.md | Scenario Analysis table | /input/repo/memo/gitlab_investment_memo.md |
| Bull probability: 25% | gitlab_investment_memo.md | Scenario Analysis table | /input/repo/memo/gitlab_investment_memo.md |
| Bear WACC: 12.0% | gitlab_investment_memo.md | Scenario Analysis table | /input/repo/memo/gitlab_investment_memo.md |
| Base WACC: 10.5% | gitlab_investment_memo.md | Scenario Analysis table | /input/repo/memo/gitlab_investment_memo.md |
| Bull WACC: 9.0% | gitlab_investment_memo.md | Scenario Analysis table | /input/repo/memo/gitlab_investment_memo.md |

## Slide 12 — Confidence & Limitations

| Number | Source File | Line/Field | Input Repo Path |
|--------|------------|------------|-----------------|
| Gross margin FY2026: 87.4% | income_statement_annual.csv | Gross Profit / Total Revenue 2026-01-31 | /input/repo/extracted/income_statement_annual.csv |
| Deferred Revenue FY2026: $572M | balance_sheet_annual.csv | Current Deferred Revenue 2026-01-31 | /input/repo/extracted/balance_sheet_annual.csv |
| Shares outstanding: 170.1M | financial_summary.json | shares_out[4] | /input/repo/extracted/financial_summary.json |
