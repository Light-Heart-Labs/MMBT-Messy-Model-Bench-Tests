# Trace: Slide 12 — Confidence & Limitations

## Claim: "Revenue trajectory: 5 years of consistent growth data"
- **Source file:** /input/repo/extracted/income_statement_annual.csv
- **Field:** Total Revenue
- **Years:** FY2022-FY2026 (5 years)
- **Commit:** ea3b335
- **Verify:** `grep "Total Revenue" /input/repo/extracted/income_statement_annual.csv`

## Claim: "Gross margins stable at 87-90%"
- **Source file:** /input/repo/extracted/income_statement_annual.csv
- **Calculation:** Gross Profit / Total Revenue
- **FY2023:** 87.8%, FY2024: 89.7%, FY2025: 88.8%, FY2026: 87.4%
- **Commit:** ea3b335
- **Verify:** `python3 -c "
gp = [372656000, 520198000, 674109000, 834481000]
rev = [424336000, 579906000, 759249000, 955224000]
for g, r in zip(gp, rev): print(f'{g/r*100:.1f}%')
"`

## Claim: "$1.26B in cash/investments with negligible debt"
- **Source file:** /input/repo/extracted/balance_sheet_annual.csv
- **Cash & Investments:** 1,259,903,000
- **Total Debt:** 187,000
- **Commit:** ea3b335
- **Verify:** `grep "Cash Cash Equivalents\|Total Debt" /input/repo/extracted/balance_sheet_annual.csv`

## Claim: "ARR and NRR are management metrics, not GAAP"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** What We're Estimating
- **Value:** "These are management metrics, not GAAP figures"
- **Commit:** ea3b335
- **Verify:** `grep -A3 "management metrics" /input/repo/memo/gitlab_investment_memo.md`

## Claim: "AI monetization is forward-looking and uncertain"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** What We're Estimating
- **Value:** "The revenue impact of AI features is uncertain and forward-looking"
- **Commit:** ea3b335
- **Verify:** `grep -A3 "AI monetization" /input/repo/memo/gitlab_investment_memo.md`

## Claim: "SEC filings not downloaded (403)"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** Limitations
- **Value:** "We were blocked by SEC's 403 responses"
- **Commit:** ea3b335
- **Verify:** `grep -A3 "SEC filings" /input/repo/memo/gitlab_investment_memo.md`

## Claim: "No customer interviews"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** What a Human Analyst Would Do Differently
- **Value:** "Speaking with GitLab customers would validate NRR and product satisfaction"
- **Commit:** ea3b335
- **Verify:** `grep -A3 "customer interviews" /input/repo/memo/gitlab_investment_memo.md`
