# Trace: Slide 5 — Financial Trajectory

## Claim: "Revenue: $424M → $955M (30% CAGR)"
- **Source file:** /input/repo/extracted/income_statement_annual.csv
- **Field:** Total Revenue
- **FY2023:** $424M, FY2026: $955M
- **Commit:** ea3b335
- **Verify:** `grep "Total Revenue" /input/repo/extracted/income_statement_annual.csv`

## Claim: "Operating margin: -50% → -7% (13pp improvement per year)"
- **Source file:** /input/repo/extracted/income_statement_annual.csv
- **Calculation:** Operating Income / Total Revenue for each year
- **FY2023:** -49.8%, FY2024: -32.3%, FY2025: -18.8%, FY2026: -7.4%
- **Commit:** ea3b335
- **Verify:** `python3 -c "
op = [-211411000, -187440000, -142715000, -70481000]
rev = [424336000, 579906000, 759249000, 955224000]
for o, r in zip(op, rev): print(f'{o/r*100:.1f}%')
"`

## Claim: "FCF: -$84M → +$222M"
- **Source file:** /input/repo/extracted/cash_flow_annual.csv
- **Field:** Free Cash Flow
- **FY2023:** -83,478,000 → -$84M
- **FY2026:** 222,029,000 → $222M
- **Commit:** ea3b335
- **Verify:** `grep "Free Cash Flow" /input/repo/extracted/cash_flow_annual.csv`

## Claim: "FCF positive in FY2024"
- **Source file:** /input/repo/extracted/cash_flow_annual.csv
- **FY2024 Free Cash Flow:** 33,442,000 → positive
- **Commit:** ea3b335
- **Verify:** `grep "Free Cash Flow" /input/repo/extracted/cash_flow_annual.csv`

## Claim: "Revenue FY2027E: $1,146M"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** FCF Projections table
- **Value:** $1,146M
- **Commit:** ea3b335
- **Verify:** `grep -A5 "FY2027E" /input/repo/memo/gitlab_investment_memo.md`

## Claim: "Revenue FY2028E: $1,352M"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** FCF Projections table
- **Value:** $1,352M
- **Commit:** ea3b335
- **Verify:** `grep -A5 "FY2028E" /input/repo/memo/gitlab_investment_memo.md`

## Claim: "Revenue FY2029E: $1,555M"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** FCF Projections table
- **Value:** $1,555M
- **Commit:** ea3b335
- **Verify:** `grep -A5 "FY2029E" /input/repo/memo/gitlab_investment_memo.md`
