# Trace: Slide 11 — Dead Ends

## Claim: "SEC filings blocked (403)"
- **Source file:** /input/repo/research/dead-ends.md
- **Section:** Dead End #1
- **Value:** "SEC's website returns 403 (Forbidden) for all automated requests"
- **Commit:** ea3b335
- **Verify:** `grep -A10 "SEC Filing" /input/repo/research/dead-ends.md`

## Claim: "GitLab IR site unreachable"
- **Source file:** /input/repo/research/dead-ends.md
- **Section:** Dead End #2
- **Value:** "DNS resolution failed - the domain could not be resolved"
- **Commit:** ea3b335
- **Verify:** `grep -A5 "IR Website" /input/repo/research/dead-ends.md`

## Claim: "PRNewswire 404"
- **Source file:** /input/repo/research/dead-ends.md
- **Section:** Dead End #3
- **Value:** "Search URL returned 404"
- **Commit:** ea3b335
- **Verify:** `grep -A5 "PRNewswire" /input/repo/research/dead-ends.md`

## Claim: "Wrong CIK initially"
- **Source file:** /input/repo/research/dead-ends.md
- **Section:** Dead End #4
- **Value:** "CIK 0001687226 mapped to Harper James P, not GitLab Inc."
- **Commit:** ea3b335
- **Verify:** `grep -A5 "CIK Lookup" /input/repo/research/dead-ends.md`

## Claim: "Earnings call audio unavailable"
- **Source file:** /input/repo/research/dead-ends.md
- **Section:** Dead End #5
- **Value:** "No accessible audio sources found. Seeking Alpha has 'Play Call' buttons but these require JavaScript execution."
- **Commit:** ea3b335
- **Verify:** `grep -A5 "Earnings Call Audio" /input/repo/research/dead-ends.md`
