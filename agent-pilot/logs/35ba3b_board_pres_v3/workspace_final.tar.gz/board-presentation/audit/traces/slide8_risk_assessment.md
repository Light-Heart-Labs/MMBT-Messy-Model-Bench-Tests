# Trace: Slide 8 — Risk Assessment

## Claim: "NRR declined from 120% (FY2022) to 115% (FY2026)"
- **Source file:** /input/repo/extracted/financial_summary.json
- **Field:** nrr
- **FY2022:** 120, FY2023: 118, FY2024: 117, FY2025: 116, FY2026: 115
- **Commit:** ea3b335
- **Verify:** `python3 -c "import json; d=json.load(open('/input/repo/extracted/financial_summary.json')); print(d['nrr'])"`

## Claim: "NRR threshold: 110%"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** Risk Assessment → NRR Decline
- **Value:** 110%
- **Commit:** ea3b335
- **Verify:** `grep "110%" /input/repo/memo/gitlab_investment_memo.md`

## Claim: "GitHub Copilot competition risk"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** Competitive Risks
- **Commit:** ea3b335
- **Verify:** `grep -A3 "GitHub Copilot" /input/repo/memo/gitlab_investment_memo.md`

## Claim: "Macro downturn risk"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** Risk Assessment → Macro Downturn
- **Commit:** ea3b335
- **Verify:** `grep -A3 "Macro Downturn" /input/repo/memo/gitlab_investment_memo.md`

## Claim: "AI monetization failure risk"
- **Source file:** /input/repo/memo/gitlab_investment_memo.md
- **Section:** Risk Assessment → AI Monetization Failure
- **Commit:** ea3b335
- **Verify:** `grep -A3 "AI Monetization" /input/repo/memo/gitlab_investment_memo.md`
