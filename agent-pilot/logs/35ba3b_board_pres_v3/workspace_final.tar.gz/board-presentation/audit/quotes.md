# Audit: Quotes in the Deck

Every quote in the deck, with file + line number in the input repo and surrounding context.

## Note on Transcript Availability

The earnings call transcripts in /input/repo/raw/transcripts/ are truncated — they contain
the header (participants, Safe Harbor statement) but not the full Q&A and management commentary.
This is because Seeking Alpha loads transcript content via JavaScript, which was not available
in the automated download environment. This limitation is documented in:
- /input/repo/research/dead-ends.md (Dead End #5: Earnings Call Audio)
- /input/repo/research/questions.md (Q2: SEC filing downloads)

## Quotes from the Investment Memo

### Quote 1: Recommendation Summary
> "We recommend BUY with a 12-month price target of $42.00, implying 95% upside from current levels."

- **File:** /input/repo/memo/gitlab_investment_memo.md
- **Line:** ~12 (Executive Summary)
- **Context:** This is the opening recommendation statement, followed by the DCF and peer comparison
  valuations that support it.

### Quote 2: AI Monetization Thesis
> "GitLab's AI features (Gitter, AI code review, AI security scanning) are embedded directly in the
> developer workflow, creating natural upsell paths. Unlike standalone AI tools, GitLab's AI is part
> of the core platform, making it sticky and defensible."

- **File:** /input/repo/memo/gitlab_investment_memo.md
- **Line:** ~65 (What the Market Is Missing section)
- **Context:** This quote appears in the section explaining why the market is underpricing GitLab's
  AI monetization potential. It follows the discussion of GitLab Duo and precedes the operating
  leverage argument.

### Quote 3: Operating Leverage
> "As revenue grows past $1B, fixed costs (R&D, platform infrastructure) spread over a larger base.
> Our model projects operating margins expanding from -7% (FY2026) to +5% (FY2029) and +12% (FY2031),
> even as R&D investment remains at 20%+ of revenue."

- **File:** /input/repo/memo/gitlab_investment_memo.md
- **Line:** ~72 (Operating Leverage subsection)
- **Context:** This quote is part of the "What the Market Is Missing" section, specifically the
  operating leverage argument. It follows the AI monetization quote and precedes the ARR quality
  discussion.

### Quote 4: NRR Trend
> "NRR has declined from 120% (FY2022) to 115% (FY2026). If this trend continues below 110%,
> revenue growth would slow significantly."

- **File:** /input/repo/memo/gitlab_investment_memo.md
- **Line:** ~130 (Risk Assessment section)
- **Context:** This quote appears in the High Probability / High Impact risk category, specifically
  the NRR decline risk. It is followed by the mitigation statement about AI features and expanded
  product suite.

### Quote 5: Limitations
> "We were blocked by SEC's 403 responses. A human analyst would read the full filings for risk
> factors, segment data, and management discussion."

- **File:** /input/repo/memo/gitlab_investment_memo.md
- **Line:** ~165 (What a Human Analyst Would Do Differently)
- **Context:** This quote is part of the limitations section, acknowledging that the agent could
  not download SEC filings. It is followed by similar statements about earnings calls, customer
  interviews, competitor product evaluation, and management meetings.

## Quotes from Earnings Call Transcripts (Headers Only)

The following quotes are from the transcript headers, which are the only content available:

### Quote 6: Q4 2024 Earnings Summary
> "EPS of $0.15 beats by $0.07 | Revenue of $163.78M (33.25% Y/Y) beats by $5.52M"

- **File:** /input/repo/raw/transcripts/GTLB_Q4_2024_transcript.txt
- **Line:** 17-19
- **Context:** This is the earnings summary header from Seeking Alpha. The full transcript
  commentary is not available (truncated by JS loading).

### Quote 7: Q1 2025 Earnings Summary
> "EPS of $0.03 beats by $0.07 | Revenue of $169.19M (33.35% Y/Y) beats by $3.08M"

- **File:** /input/repo/raw/transcripts/GTLB_Q1_2025_transcript.txt
- **Line:** 17-19
- **Context:** Same as above — earnings summary header only.
