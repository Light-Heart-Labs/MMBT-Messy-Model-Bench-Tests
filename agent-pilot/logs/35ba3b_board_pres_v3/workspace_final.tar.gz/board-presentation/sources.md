# Sources

Any external content fetched for the deck (fonts, icons, reference imagery).

## Fonts

| Source | URL | Usage | Notes |
|--------|-----|-------|-------|
| Inter (Google Fonts) | https://fonts.google.com/specimen/Inter | Typography for deck | System font on most Linux systems; no external files needed for python-pptx |

## Icons / Imagery

None. The deck uses no icons, no stock imagery, no clip art. Charts are the visual centerpiece.

## Reference Materials

| Source | URL | Usage | Notes |
|--------|-----|-------|-------|
| python-pptx documentation | https://python-pptx.readthedocs.io/ | Deck construction | Used for slide layout, chart embedding, text formatting |
| matplotlib documentation | https://matplotlib.org/stable/contents.html | Chart generation | Used for all chart scripts in /assets/charts/ |
| networkx documentation | https://networkx.org/documentation/stable/ | Reasoning trail graph | Used for the decision graph visualization |

## Input Repo Sources (Already Documented)

All data sources from the input repo are documented in:
- /input/repo/sources.md — URLs, timestamps, SHA hashes
- /input/repo/tool-log.md — Every tool call with justification
