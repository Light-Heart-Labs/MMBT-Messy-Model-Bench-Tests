#!/usr/bin/env python3
"""
generate_price_history.py

Generates the stock price history chart for the recommendation slide.
Shows 52-week range and current price.

Data source: /input/repo/extracted/historical_prices.csv,
             /input/repo/extracted/company_info.json
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
import os

NAVY = '#1a2332'
TEAL = '#00b4d8'
CORAL = '#e63946'
GREEN = '#2a9d8f'
AMBER = '#f4a261'
SLATE = '#6c757d'
WHITE = '#ffffff'

# Load company info
with open('/input/repo/extracted/company_info.json', 'r') as f:
    info = json.load(f)

current_price = info['currentPrice']
fifty2w_high = info['fiftyTwoWeekHigh']
fifty2w_low = info['fiftyTwoWeekLow']

# Load price history
prices = pd.read_csv('/input/repo/extracted/historical_prices.csv', header=None,
                     names=['date', 'open', 'high', 'low', 'close', 'volume', 'adj_open', 'adj_close'])
prices['date'] = pd.to_datetime(prices['date'])

fig, ax = plt.subplots(figsize=(12, 5), facecolor=NAVY)
fig.patch.set_facecolor(NAVY)
ax.set_facecolor(NAVY)

# Plot closing prices
ax.plot(prices['date'], prices['close'], color=TEAL, linewidth=1.5, alpha=0.8)

# Current price line
ax.axhline(y=current_price, color=AMBER, linewidth=2, linestyle='--', alpha=0.8)
ax.annotate(f'Current: ${current_price:.2f}',
            xy=(prices['date'].iloc[-1], current_price),
            xytext=(10, 10), textcoords='offset points',
            color=AMBER, fontsize=10, fontweight='bold')

# 52-week high
ax.axhline(y=fifty2w_high, color=CORAL, linewidth=1, linestyle=':', alpha=0.5)
ax.annotate(f'52W High: ${fifty2w_high:.2f}',
            xy=(prices['date'].iloc[-1], fifty2w_high),
            xytext=(10, -15), textcoords='offset points',
            color=CORAL, fontsize=8, alpha=0.7)

# 52-week low
ax.axhline(y=fifty2w_low, color=GREEN, linewidth=1, linestyle=':', alpha=0.5)
ax.annotate(f'52W Low: ${fifty2w_low:.2f}',
            xy=(prices['date'].iloc[-1], fifty2w_low),
            xytext=(10, 10), textcoords='offset points',
            color=GREEN, fontsize=8, alpha=0.7)

# Target price
ax.axhline(y=42.0, color=TEAL, linewidth=1.5, linestyle='-.', alpha=0.6)
ax.annotate('Target: $42.00',
            xy=(prices['date'].iloc[-1], 42.0),
            xytext=(-120, 10), textcoords='offset points',
            color=TEAL, fontsize=9, fontweight='bold')

ax.set_ylabel('Price ($)', color=WHITE, fontsize=11, fontweight='medium')
ax.tick_params(axis='y', labelcolor=WHITE)
ax.tick_params(axis='x', labelcolor=WHITE)

ax.set_title('GitLab (GTLB) Stock Price — 52-Week Range',
             color=WHITE, fontsize=14, fontweight='bold', pad=15)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/price_history.png',
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

print("Chart saved: assets/charts/price_history.png")
