#!/usr/bin/env python3
"""
generate_reasoning_trail.py

Generates the reasoning trail / decision graph visualization for Slide 10.
Shows the dependency chain from filings → data → analysis → conclusion.

Data source: /input/repo/decisions/, /input/repo/research/notes/,
             /input/repo/tool-log.md, git commit history
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx
import os

# Colors from ADR-001
NAVY = '#1a2332'
TEAL = '#00b4d8'
CORAL = '#e63946'
GREEN = '#2a9d8f'
AMBER = '#f4a261'
SLATE = '#6c757d'
WHITE = '#ffffff'

# Create directed graph of the reasoning trail
G = nx.DiGraph()

# Nodes: categories and specific items
# Phase 1: Data Collection
G.add_node('SEC CIK\nLookup', shape='rect', color='#4a5568', size=1.0)
G.add_node('yfinance\nFinancial Data', shape='rect', color='#4a5568', size=1.0)
G.add_node('Seeking Alpha\nTranscripts', shape='rect', color='#4a5568', size=1.0)
G.add_node('yfinance\nCompetitor Data', shape='rect', color='#4a5568', size=1.0)

# Phase 2: Analysis
G.add_node('Company\nSelection', shape='rect', color='#2d3748', size=1.2)
G.add_node('Competitor\nSelection', shape='rect', color='#2d3748', size=1.2)
G.add_node('Valuation\nMethodology', shape='rect', color='#2d3748', size=1.2)

# Phase 3: Financial Model
G.add_node('Three-Statement\nModel', shape='rect', color='#1a365d', size=1.2)
G.add_node('DCF\nAnalysis', shape='rect', color='#1a365d', size=1.2)
G.add_node('Scenario\nAnalysis', shape='rect', color='#1a365d', size=1.2)

# Phase 4: Conclusion
G.add_node('Investment\nMemo', shape='rect', color='#2b6cb0', size=1.3)
G.add_node('BUY\nRecommendation', shape='rect', color='#00b4d8', size=1.5)

# Edges: dependencies
# Data collection → Analysis
G.add_edge('SEC CIK\nLookup', 'Company\nSelection')
G.add_edge('yfinance\nFinancial Data', 'Three-Statement\nModel')
G.add_edge('Seeking Alpha\nTranscripts', 'Company\nSelection')
G.add_edge('Seeking Alpha\nTranscripts', 'Competitor\nSelection')
G.add_edge('yfinance\nCompetitor Data', 'Competitor\nSelection')

# Analysis → Financial Model
G.add_edge('Company\nSelection', 'Three-Statement\nModel')
G.add_edge('Competitor\nSelection', 'DCF\nAnalysis')
G.add_edge('Valuation\nMethodology', 'DCF\nAnalysis')
G.add_edge('Valuation\nMethodology', 'Scenario\nAnalysis')

# Financial Model → Conclusion
G.add_edge('Three-Statement\nModel', 'DCF\nAnalysis')
G.add_edge('Three-Statement\nModel', 'Scenario\nAnalysis')
G.add_edge('DCF\nAnalysis', 'Investment\nMemo')
G.add_edge('Scenario\nAnalysis', 'Investment\nMemo')
G.add_edge('Investment\nMemo', 'BUY\nRecommendation')

# Dead ends (shown as separate branch)
G.add_node('SEC 403\nBlocked', shape='ellipse', color='#e63946', size=0.8)
G.add_node('IR Site\nUnreachable', shape='ellipse', color='#e63946', size=0.8)
G.add_node('PRNewswire\n404', shape='ellipse', color='#e63946', size=0.8)
G.add_node('yfinance\nFallback', shape='ellipse', color='#f4a261', size=0.8)

G.add_edge('SEC 403\nBlocked', 'yfinance\nFallback')
G.add_edge('IR Site\nUnreachable', 'Seeking Alpha\nTranscripts')
G.add_edge('PRNewswire\n404', 'yfinance\nFallback')

# Layout
pos = nx.spring_layout(G, seed=42, k=0.8, iterations=50)

# Create figure
fig, ax = plt.subplots(figsize=(14, 10), facecolor=NAVY)
fig.patch.set_facecolor(NAVY)
ax.set_facecolor(NAVY)

# Draw nodes by color
node_colors = []
node_sizes = []
node_shapes = []

for node in G.nodes():
    info = G.nodes[node]
    node_colors.append(info['color'])
    node_sizes.append(info['size'] * 3000)
    node_shapes.append(info['shape'])

# Draw edges
nx.draw_networkx_edges(G, pos, ax=ax, edge_color=SLATE,
                       arrowstyle='->', arrowsize=15,
                       node_size=[], width=1.5, alpha=0.4,
                       connectionstyle='arc3,rad=0.1')

# Draw nodes
nx.draw_networkx_nodes(G, pos, ax=ax,
                       node_color=node_colors,
                       node_size=node_sizes,
                       node_shape='s',
                       edgecolors=WHITE,
                       linewidths=1.5,
                       alpha=0.9)

# Draw labels
for node, (x, y) in pos.items():
    # Truncate long labels
    label = node.replace('\n', ' ')
    ax.annotate(label, (x, y), color=WHITE, fontsize=8,
                ha='center', va='center', fontweight='medium',
                bbox=dict(boxstyle='round,pad=0.3', facecolor=node_colors[list(G.nodes()).index(node)],
                         edgecolor=WHITE, alpha=0.8))

# Title
ax.set_title('Agent Reasoning Trail: From Filings to Recommendation',
             color=WHITE, fontsize=16, fontweight='bold', pad=20)

# Subtitle
ax.text(0.5, -0.02, 'Red nodes = dead ends (SEC 403, IR unreachable, PRNewswire 404)\n'
             'Orange node = fallback (yfinance). Blue nodes = analysis. Teal = final recommendation.\n'
             'Source: /input/repo/decisions/, /input/repo/tool-log.md, git commit history',
        transform=ax.transAxes, color=SLATE, fontsize=9, ha='center')

# Legend
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor='#4a5568', label='Data Collection'),
    Patch(facecolor='#2d3748', label='Analysis'),
    Patch(facecolor='#1a365d', label='Financial Model'),
    Patch(facecolor='#2b6cb0', label='Conclusion'),
    Patch(facecolor='#00b4d8', label='Recommendation'),
    Patch(facecolor='#e63946', label='Dead Ends'),
    Patch(facecolor='#f4a261', label='Fallback'),
]
ax.legend(handles=legend_elements, loc='upper left', facecolor=NAVY, edgecolor=SLATE,
          fontsize=8, labelcolor=WHITE, title='Phases', title_fontsize=9)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/reasoning_trail.png',
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

print("Chart saved: assets/charts/reasoning_trail.png")
