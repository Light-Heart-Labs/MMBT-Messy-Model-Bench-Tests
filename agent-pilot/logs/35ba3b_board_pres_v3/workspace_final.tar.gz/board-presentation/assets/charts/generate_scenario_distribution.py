#!/usr/bin/env python3
"""
generate_scenario_distribution.py

Generates the probability-weighted scenario distribution chart for Slide 9.
Shows bear/base/bull as a violin-style distribution with probability weights.

Data source: /input/repo/memo/gitlab_investment_memo.md (Scenario Analysis table)
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os

# Colors from ADR-001
NAVY = '#1a2332'
TEAL = '#00b4d8'
CORAL = '#e63946'
GREEN = '#2a9d8f'
AMBER = '#f4a261'
SLATE = '#6c757d'
WHITE = '#ffffff'

# Scenario data from memo
scenarios = {
    'Bear': {'price': 18.58, 'prob': 0.25, 'color': CORAL,
             'revenue_growth': '12%', 'wacc': '12.0%', 'term_growth': '2.0%'},
    'Base': {'price': 38.52, 'prob': 0.50, 'color': TEAL,
             'revenue_growth': '20%', 'wacc': '10.5%', 'term_growth': '3.0%'},
    'Bull': {'price': 88.30, 'prob': 0.25, 'color': GREEN,
             'revenue_growth': '28%', 'wacc': '9.0%', 'term_growth': '4.0%'},
}

weighted_target = 45.98
current_price = 21.51

# Generate violin-like distributions using kernel density estimation
np.random.seed(42)

# For each scenario, generate a distribution centered on the price target
# with width proportional to uncertainty (bear = wider range of downside)
bear_prices = np.random.normal(scenarios['Bear']['price'], 5, 1000)
base_prices = np.random.normal(scenarios['Base']['price'], 8, 1000)
bull_prices = np.random.normal(scenarios['Bull']['price'], 15, 1000)

# Create figure
fig, ax = plt.subplots(figsize=(12, 7), facecolor=NAVY)
fig.patch.set_facecolor(NAVY)
ax.set_facecolor(NAVY)

# Plot violin-style distributions
for name, data, color in [
    ('Bear', bear_prices, CORAL),
    ('Base', base_prices, TEAL),
    ('Bull', bull_prices, GREEN),
]:
    # Use filled area to simulate violin shape
    from scipy.stats import gaussian_kde
    kde = gaussian_kde(data)
    x_vals = np.linspace(min(data) - 2, max(data) + 2, 200)
    y_vals = kde(x_vals)
    # Normalize and scale by probability
    y_scaled = y_vals * scenarios[name]['prob'] * 3
    
    ax.fill_betweenx(x_vals, 0, y_scaled, color=color, alpha=0.3)
    ax.plot(y_scaled, x_vals, color=color, linewidth=2, alpha=0.8)

# Probability-weighted target line
ax.axhline(y=weighted_target, color=AMBER, linewidth=2, linestyle='--', alpha=0.8,
           label=f'Probability-Weighted: ${weighted_target:.2f}')

# Current price line
ax.axhline(y=current_price, color=SLATE, linewidth=1.5, linestyle=':', alpha=0.6,
           label=f'Current Price: ${current_price}')

# Price target dot
ax.scatter([0.01], [weighted_target], color=AMBER, s=200, zorder=10,
           edgecolors=WHITE, linewidth=2)

# Scenario price labels
for name, info in scenarios.items():
    ax.scatter([0.005], [info['price']], color=info['color'], s=150, zorder=10,
               edgecolors=WHITE, linewidth=1.5)
    ax.annotate(f"${info['price']:.0f}", xy=(0.008, info['price']),
                color=info['color'], fontsize=11, fontweight='bold', va='center')
    ax.annotate(f"{name} ({int(info['prob']*100)}%)", xy=(0.008, info['price'] - 5),
                color=info['color'], fontsize=9, va='top')

# Upside annotations
for name, info in scenarios.items():
    upside = (info['price'] - current_price) / current_price * 100
    label = f"+{upside:.0f}%" if upside > 0 else f"{upside:.0f}%"
    ax.annotate(label, xy=(0.015, info['price']),
                color=info['color'], fontsize=9, va='center', fontweight='medium')

# Y-axis (price)
ax.set_ylabel('Price Target ($)', color=WHITE, fontsize=12, fontweight='medium')
ax.tick_params(axis='y', labelcolor=WHITE)
ax.set_ylim(0, 100)

# X-axis is just for violin width, hide labels
ax.set_xticks([])
ax.set_xlabel('')

# Title
ax.set_title('Scenario Analysis: Probability-Weighted Price Distribution',
             color=WHITE, fontsize=16, fontweight='bold', pad=20)

# Assumptions box
assumptions_text = (
    f"Bear: Rev growth {scenarios['Bear']['revenue_growth']}, WACC {scenarios['Bear']['wacc']}, "
    f"Terminal {scenarios['Bear']['term_growth']}\n"
    f"Base: Rev growth {scenarios['Base']['revenue_growth']}, WACC {scenarios['Base']['wacc']}, "
    f"Terminal {scenarios['Base']['term_growth']}\n"
    f"Bull: Rev growth {scenarios['Bull']['revenue_growth']}, WACC {scenarios['Bull']['wacc']}, "
    f"Terminal {scenarios['Bull']['term_growth']}"
)
ax.text(0.01, 95, assumptions_text, color=SLATE, fontsize=8,
        va='top', family='monospace',
        bbox=dict(boxstyle='round,pad=0.5', facecolor=NAVY, edgecolor=SLATE, alpha=0.8))

# Legend
from matplotlib.lines import Line2D
legend_elements = [
    Line2D([0], [0], color=CORAL, linewidth=2, label='Bear (25%)'),
    Line2D([0], [0], color=TEAL, linewidth=2, label='Base (50%)'),
    Line2D([0], [0], color=GREEN, linewidth=2, label='Bull (25%)'),
    Line2D([0], [0], color=AMBER, linewidth=2, linestyle='--', label=f'Weighted: ${weighted_target:.2f}'),
]
ax.legend(handles=legend_elements, loc='lower right', facecolor=NAVY, edgecolor=SLATE,
          fontsize=9, labelcolor=WHITE)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/scenario_distribution.png',
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

print("Chart saved: assets/charts/scenario_distribution.png")
