#!/usr/bin/env python3
"""
generate_competitive_landscape.py

Generates the competitive landscape scatter plot for Slide 6.
Shows Revenue Growth vs. EV/Revenue with bubble size = market cap.

Data source: /input/repo/extracted/competitor_data.json
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
import os

# Colors from ADR-001
NAVY = '#1a2332'
TEAL = '#00b4d8'
CORAL = '#e63946'
GREEN = '#2a9d8f'
AMBER = '#f4a261'
SLATE = '#6c757d'
WHITE = '#ffffff'

# Load competitor data
with open('/input/repo/extracted/competitor_data.json', 'r') as f:
    competitors = json.load(f)

# GTLB data
gtlb = competitors['GTLB']
gtlb_data = {
    'name': 'GitLab',
    'ticker': 'GTLB',
    'revenue_growth': gtlb['revenue_growth'] * 100,
    'ev_revenue': gtlb['ev_revenue'],
    'market_cap_b': gtlb['market_cap_b'],
    'is_gtlb': True
}

# Filter to relevant comps (exclude GTLB itself and non-SaaS)
relevant_comps = []
for ticker, data in competitors.items():
    if ticker == 'GTLB':
        continue
    if data.get('sector') != 'Technology':
        continue
    relevant_comps.append({
        'name': data['name'],
        'ticker': ticker,
        'revenue_growth': data['revenue_growth'] * 100,
        'ev_revenue': data['ev_revenue'],
        'market_cap_b': data['market_cap_b'],
        'is_gtlb': False
    })

# Create figure
fig, ax = plt.subplots(figsize=(12, 7), facecolor=NAVY)
fig.patch.set_facecolor(NAVY)
ax.set_facecolor(NAVY)

# Plot competitors
for comp in relevant_comps:
    size = comp['market_cap_b'] * 20  # Scale market cap to bubble size
    ax.scatter(comp['revenue_growth'], comp['ev_revenue'],
              s=size, c=SLATE, alpha=0.4, edgecolors='none', zorder=1)
    ax.annotate(comp['ticker'], (comp['revenue_growth'], comp['ev_revenue']),
                xytext=(5, 5), textcoords='offset points',
                color=SLATE, fontsize=8, alpha=0.6)

# Plot GitLab prominently
ax.scatter(gtlb_data['revenue_growth'], gtlb_data['ev_revenue'],
           s=gtlb_data['market_cap_b'] * 20, c=TEAL, alpha=0.9,
           edgecolors=WHITE, linewidth=2, zorder=5)
ax.annotate('GitLab (GTLB)', (gtlb_data['revenue_growth'], gtlb_data['ev_revenue']),
            xytext=(10, 10), textcoords='offset points',
            color=TEAL, fontsize=12, fontweight='bold', zorder=6)

# Quadrant lines
ax.axvline(x=20, color=SLATE, linewidth=0.5, alpha=0.3, linestyle='--')
ax.axhline(y=5, color=SLATE, linewidth=0.5, alpha=0.3, linestyle='--')

# Quadrant labels
ax.text(25, 14, 'High Growth\nHigh Multiple', color=SLATE, fontsize=8,
        ha='center', alpha=0.4)
ax.text(12, 14, 'Low Growth\nHigh Multiple', color=SLATE, fontsize=8,
        ha='center', alpha=0.4)
ax.text(25, 2, 'High Growth\nLow Multiple', color=TEAL, fontsize=8,
        ha='center', alpha=0.6, fontweight='bold')
ax.text(12, 2, 'Low Growth\nLow Multiple', color=SLATE, fontsize=8,
        ha='center', alpha=0.4)

# Axes
ax.set_xlabel('Revenue Growth (%)', color=WHITE, fontsize=12, fontweight='medium')
ax.set_ylabel('EV / Revenue', color=WHITE, fontsize=12, fontweight='medium')
ax.tick_params(axis='x', labelcolor=WHITE)
ax.tick_params(axis='y', labelcolor=WHITE)
ax.set_xlim(5, 35)
ax.set_ylim(0, 16)

# Title
ax.set_title('Competitive Landscape: Growth vs. Valuation',
             color=WHITE, fontsize=16, fontweight='bold', pad=20)

# Subtitle
ax.text(0.5, -0.15, 'GitLab is the outlier: high growth (23%) at a low multiple (2.6x)\n'
             'Bubble size = Market Cap (billions). Source: yfinance, /input/repo/extracted/competitor_data.json',
        transform=ax.transAxes, color=SLATE, fontsize=9, ha='center')

# Legend
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor=TEAL, alpha=0.9, edgecolor=WHITE, label='GitLab (GTLB)'),
    Patch(facecolor=SLATE, alpha=0.4, label='SaaS Peers'),
]
ax.legend(handles=legend_elements, loc='upper right', facecolor=NAVY, edgecolor=SLATE,
          fontsize=9, labelcolor=WHITE)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/competitive_landscape.png',
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

print("Chart saved: assets/charts/competitive_landscape.png")
