#!/usr/bin/env python3
"""
generate_valuation_comparison.py

Generates the valuation comparison chart for Slide 7 (Mispricing Thesis).
Shows GitLab's EV/Revenue vs. peer average, with the upside arrow.

Data source: /input/repo/extracted/competitor_data.json,
             /input/repo/memo/gitlab_investment_memo.md
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
import os

# Colors from ADR-001
NAVY = '#1a2332'
TEAL = '#00b4d8'
CORAL = '#e63946'
GREEN = '#2a9d8f'
AMBER = '#f4a261'
SLATE = '#6c757d'
WHITE = '#ffffff'

# Load competitor data
with open('/input/repo/extracted/competitor_data.json', 'r') as f:
    competitors = json.load(f)

# Calculate peer average (excluding GTLB)
peer_ev_revenues = []
peer_names = []
for ticker, data in competitors.items():
    if ticker == 'GTLB':
        continue
    if data.get('sector') == 'Technology':
        peer_ev_revenues.append(data['ev_revenue'])
        peer_names.append(ticker)

peer_avg = np.mean(peer_ev_revenues)
gtlb_ev = competitors['GTLB']['ev_revenue']

# Create figure
fig, ax = plt.subplots(figsize=(10, 6), facecolor=NAVY)
fig.patch.set_facecolor(NAVY)
ax.set_facecolor(NAVY)

# Bar chart
bars_data = [
    ('GitLab\n(GTLB)', gtlb_ev, TEAL),
    ('Peer\nAverage', peer_avg, SLATE),
]

x = [0, 1]
heights = [gtlb_ev, peer_avg]
colors = [TEAL, SLATE]

bars = ax.bar(x, heights, color=colors, width=0.5, edgecolor=WHITE, linewidth=2)

# Add value labels on bars
for i, (name, val, color) in enumerate(bars_data):
    ax.text(i, val + 0.3, f'{val:.1f}x', color=WHITE, fontsize=14,
            ha='center', fontweight='bold')

# Add upside arrow
arrow_x = 0.5
arrow_start = gtlb_ev
arrow_end = peer_avg
ax.annotate('', xy=(arrow_x, arrow_end + 0.3), xytext=(arrow_x, arrow_start),
            arrowprops=dict(arrowstyle='<->', color=AMBER, lw=2.5))
ax.text(arrow_x + 0.15, (arrow_start + arrow_end) / 2,
        f'+{((peer_avg - gtlb_ev) / gtlb_ev * 100):.0f}%\nmultiple gap',
        color=AMBER, fontsize=11, fontweight='bold', va='center')

# Axes
ax.set_xticks(x)
ax.set_xticklabels([b[0] for b in bars_data], color=WHITE, fontsize=11)
ax.set_ylabel('EV / Revenue', color=WHITE, fontsize=12, fontweight='medium')
ax.tick_params(axis='y', labelcolor=WHITE)
ax.set_ylim(0, max(heights) + 2)

# Title
ax.set_title('The Mispricing: GitLab Trades at 2.6x vs. Peer 7.0x',
             color=WHITE, fontsize=16, fontweight='bold', pad=20)

# Subtitle
ax.text(0.5, -0.15, 'GitLab is priced at a 63% discount to peer average EV/Revenue.\n'
             'Peer comps: TEAM, DDOG, MDB, CFLT, SNOW, ZS, OKTA, BILL. Source: yfinance',
        transform=ax.transAxes, color=SLATE, fontsize=9, ha='center')

# Sell-side consensus
ax.text(0.5, -0.25, f'Sell-side mean target: $30.79 (43% upside) vs. our target: $42.00 (95% upside)',
        transform=ax.transAxes, color=AMBER, fontsize=9, ha='center', fontweight='medium')

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/valuation_comparison.png',
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

print("Chart saved: assets/charts/valuation_comparison.png")
