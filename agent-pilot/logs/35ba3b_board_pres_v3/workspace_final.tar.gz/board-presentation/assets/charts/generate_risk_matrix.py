#!/usr/bin/env python3
"""
generate_risk_matrix.py

Generates the risk assessment matrix for Slide 8.
Shows risks on a probability vs. impact grid.

Data source: /input/repo/memo/gitlab_investment_memo.md (Risk Assessment section)
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os

# Colors from ADR-001
NAVY = '#1a2332'
TEAL = '#00b4d8'
CORAL = '#e63946'
GREEN = '#2a9d8f'
AMBER = '#f4a261'
SLATE = '#6c757d'
WHITE = '#ffffff'

# Risk data from memo
risks = [
    {'name': 'NRR Decline', 'prob': 0.7, 'impact': 0.9, 'color': CORAL,
     'trigger': 'NRR < 110%', 'signal': 'Quarterly NRR trend'},
    {'name': 'GitHub Copilot\nCompetition', 'prob': 0.5, 'impact': 0.8, 'color': CORAL,
     'trigger': 'GitHub launches full-stack DevOps', 'signal': 'GitHub DevOps features'},
    {'name': 'Macro\nDownturn', 'prob': 0.4, 'impact': 0.7, 'color': AMBER,
     'trigger': 'Enterprise software spending cuts', 'signal': 'SaaS sector revenue growth'},
    {'name': 'AI Monetization\nFailure', 'prob': 0.3, 'impact': 0.7, 'color': AMBER,
     'trigger': 'AI features show no upsell impact', 'signal': 'Duo adoption rates'},
    {'name': 'Open-Source\nCannibalization', 'prob': 0.2, 'impact': 0.5, 'color': TEAL,
     'trigger': 'Self-hosted conversion rate drops', 'signal': 'Community vs. paid ratio'},
    {'name': 'Key Person\nRisk', 'prob': 0.1, 'impact': 0.6, 'color': TEAL,
     'trigger': 'CEO departure', 'signal': 'Executive turnover'},
]

# Create figure
fig, ax = plt.subplots(figsize=(12, 7), facecolor=NAVY)
fig.patch.set_facecolor(NAVY)
ax.set_facecolor(NAVY)

# Grid
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.set_xticks([0.25, 0.5, 0.75])
ax.set_xticklabels(['Low', 'Medium', 'High'], color=WHITE, fontsize=10)
ax.set_yticks([0.25, 0.5, 0.75])
ax.set_yticklabels(['Low', 'Medium', 'High'], color=WHITE, fontsize=10)
ax.set_xlabel('Probability', color=WHITE, fontsize=12, fontweight='medium')
ax.set_ylabel('Impact', color=WHITE, fontsize=12, fontweight='medium')

# Quadrant shading
ax.axvspan(0, 0.5, alpha=0.05, color=TEAL)
ax.axvspan(0.5, 1, alpha=0.05, color=CORAL)
ax.axhspan(0, 0.5, alpha=0.05, color=TEAL)
ax.axhspan(0.5, 1, alpha=0.05, color=CORAL)

# Quadrant labels
ax.text(0.25, 0.25, 'Monitor', color=SLATE, fontsize=10, ha='center', alpha=0.4)
ax.text(0.75, 0.25, 'Watch', color=SLATE, fontsize=10, ha='center', alpha=0.4)
ax.text(0.25, 0.75, 'Watch', color=SLATE, fontsize=10, ha='center', alpha=0.4)
ax.text(0.75, 0.75, 'Critical', color=CORAL, fontsize=10, ha='center', alpha=0.5, fontweight='bold')

# Plot risks
for risk in risks:
    size = (risk['prob'] * risk['impact']) * 4000 + 500
    ax.scatter(risk['prob'], risk['impact'], s=size, c=risk['color'],
              alpha=0.8, edgecolors=WHITE, linewidth=1.5, zorder=5)
    
    # Label
    label = risk['name'].replace('\n', ' ')
    ax.annotate(label, (risk['prob'], risk['impact']),
                xytext=(10, 10), textcoords='offset points',
                color=WHITE, fontsize=9, fontweight='medium', zorder=6)
    
    # Trigger annotation for top risks
    if risk['impact'] > 0.6 and risk['prob'] > 0.3:
        ax.annotate(f"Trigger: {risk['trigger']}",
                    xytext=(15, -15), textcoords='offset points',
                    color=SLATE, fontsize=7, zorder=6)

# Title
ax.set_title('Risk Assessment: Probability vs. Impact',
             color=WHITE, fontsize=16, fontweight='bold', pad=20)

# Subtitle
ax.text(0.5, -0.02, 'Bubble size = Probability × Impact. Source: /input/repo/memo/gitlab_investment_memo.md',
        transform=ax.transAxes, color=SLATE, fontsize=9, ha='center')

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/risk_matrix.png',
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

print("Chart saved: assets/charts/risk_matrix.png")
