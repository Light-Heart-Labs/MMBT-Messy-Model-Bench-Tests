#!/usr/bin/env python3
"""
generate_nrr_trend.py

Generates the NRR trend chart for Slide 5 (Financial Trajectory).
Shows Net Revenue Retention declining from 120% to 115%.

Data source: /input/repo/extracted/financial_summary.json
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
import os

NAVY = '#1a2332'
TEAL = '#00b4d8'
CORAL = '#e63946'
GREEN = '#2a9d8f'
AMBER = '#f4a261'
SLATE = '#6c757d'
WHITE = '#ffffff'

with open('/input/repo/extracted/financial_summary.json', 'r') as f:
    data = json.load(f)

fy_labels = data['fy_labels']  # FY2022-FY2026
nrr = data['nrr']  # [120, 118, 117, 116, 115]

fig, ax = plt.subplots(figsize=(10, 5), facecolor=NAVY)
fig.patch.set_facecolor(NAVY)
ax.set_facecolor(NAVY)

years = fy_labels[1:]  # Skip FY2022 (NaN)
nrr_values = nrr[1:]

ax.plot(years, nrr_values, color=AMBER, linewidth=2.5, marker='o', markersize=8, zorder=5)
ax.fill_between(years, nrr_values, 100, color=AMBER, alpha=0.1)

# 110% threshold line
ax.axhline(y=110, color=CORAL, linewidth=1.5, linestyle='--', alpha=0.6, label='110% warning threshold')

# Labels
for i, (year, val) in enumerate(zip(years, nrr_values)):
    ax.annotate(f'{val}%', (year, val), xytext=(0, 12), textcoords='offset points',
                color=AMBER, fontsize=10, fontweight='bold', ha='center')

ax.set_ylabel('Net Revenue Retention (%)', color=WHITE, fontsize=12, fontweight='medium')
ax.set_xlabel('Fiscal Year', color=WHITE, fontsize=12, fontweight='medium')
ax.tick_params(axis='x', labelcolor=WHITE)
ax.tick_params(axis='y', labelcolor=WHITE)
ax.set_ylim(108, 122)

ax.set_title('NRR Trend: Declining from 120% to 115%',
             color=WHITE, fontsize=14, fontweight='bold', pad=15)

ax.legend(loc='upper right', facecolor=NAVY, edgecolor=SLATE, fontsize=9, labelcolor=WHITE)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/nrr_trend.png',
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

print("Chart saved: assets/charts/nrr_trend.png")
