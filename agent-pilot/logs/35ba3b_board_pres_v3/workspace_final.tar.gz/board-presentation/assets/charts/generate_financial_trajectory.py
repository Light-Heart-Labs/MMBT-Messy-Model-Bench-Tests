#!/usr/bin/env python3
"""
generate_financial_trajectory.py

Generates the financial trajectory chart for Slide 5 (Financial Trajectory).
Shows revenue, operating margin, and FCF from FY2023-FY2026 with projections
to FY2029.

Data source: /input/repo/extracted/income_statement_annual.csv,
             /input/repo/extracted/cash_flow_annual.csv,
             /input/repo/extracted/financial_summary.json
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import json
import os

# Colors from ADR-001
NAVY = '#1a2332'
TEAL = '#00b4d8'
CORAL = '#e63946'
GREEN = '#2a9d8f'
AMBER = '#f4a261'
SLATE = '#6c757d'
WHITE = '#ffffff'

# Load data
with open('/input/repo/extracted/financial_summary.json', 'r') as f:
    data = json.load(f)

fy_labels = data['fy_labels']  # FY2022-FY2026
revenue = [r/1000 for r in data['revenue'] if not pd.isna(r)]  # Convert to billions
op_income = [o/1000 for o in data['op_income'] if not pd.isna(o)]
fcf = [f/1000 for f in data['fcf'] if not pd.isna(f)]

# Historical years (FY2023-FY2026)
hist_years = ['FY2023', 'FY2024', 'FY2025', 'FY2026']
hist_revenue = [424, 580, 759, 955]  # $M
hist_op_margin = [-49.8, -32.3, -18.8, -7.4]  # %
hist_fcf = [-84, 33, -68, 222]  # $M

# Projections (FY2027-FY2029)
proj_years = ['FY2027E', 'FY2028E', 'FY2029E']
proj_revenue = [1146, 1352, 1555]  # $M
proj_op_margin = [5, 12, 18]  # % (from memo: +5% by FY2028, +12% by FY2029)
proj_fcf = [230, 298, 373]  # $M

# Create figure with two y-axes
fig, ax1 = plt.subplots(figsize=(12, 7), facecolor=NAVY)
fig.patch.set_facecolor(NAVY)
ax1.set_facecolor(NAVY)

# Revenue bars (left axis)
x = range(len(hist_years + proj_years))
all_years = hist_years + proj_years
all_revenue = hist_revenue + proj_revenue

bars = ax1.bar(x, all_revenue, color=[TEAL]*4 + [TEAL]*3, alpha=0.7, width=0.6, edgecolor='none')
ax1.set_ylabel('Revenue ($M)', color=WHITE, fontsize=12, fontweight='medium')
ax1.tick_params(axis='y', labelcolor=WHITE)
ax1.set_ylim(0, 1700)

# Operating margin line (right axis)
ax2 = ax1.twinx()
ax2.plot(x, hist_op_margin + proj_op_margin, color=AMBER, linewidth=2.5, marker='o', markersize=6, zorder=5)
ax2.set_ylabel('Operating Margin (%)', color=AMBER, fontsize=12, fontweight='medium')
ax2.tick_params(axis='y', labelcolor=AMBER)
ax2.set_ylim(-55, 25)

# FCF line (secondary, dashed)
ax3 = ax1.twinx()
ax3.spines['right'].set_position(('outward', 60))
ax3.plot(x, hist_fcf + proj_fcf, color=GREEN, linewidth=2, marker='s', markersize=5,
         linestyle='--', alpha=0.8, zorder=4)
ax3.set_ylabel('Free Cash Flow ($M)', color=GREEN, fontsize=12, fontweight='medium')
ax3.tick_params(axis='y', labelcolor=GREEN)
ax3.set_ylim(-100, 400)

# X-axis labels
ax1.set_xticks(list(x))
ax1.set_xticklabels(all_years, color=WHITE, fontsize=11)

# Title
ax1.set_title('GitLab Financial Trajectory: Revenue, Margin & FCF',
              color=WHITE, fontsize=16, fontweight='bold', pad=20)

# Inflection point annotations
# FCF positive in FY2024
ax1.annotate('FCF turns positive', xy=(1, 33), xytext=(2, 100),
             arrowprops=dict(arrowstyle='->', color=GREEN, lw=1.5),
             color=GREEN, fontsize=9, fontweight='medium')

# GAAP profitability expected FY2028
ax1.annotate('GAAP profitability\nexpected FY2028', xy=(5, 12), xytext=(4, -30),
             arrowprops=dict(arrowstyle='->', color=AMBER, lw=1.5),
             color=AMBER, fontsize=9, fontweight='medium')

# Legend
from matplotlib.lines import Line2D
legend_elements = [
    Line2D([0], [0], color=TEAL, linewidth=8, label='Revenue ($M)'),
    Line2D([0], [0], color=AMBER, linewidth=2.5, marker='o', label='Op. Margin (%)'),
    Line2D([0], [0], color=GREEN, linewidth=2, marker='s', linestyle='--', label='FCF ($M)'),
]
ax1.legend(handles=legend_elements, loc='upper left', facecolor=NAVY, edgecolor=SLATE,
           fontsize=10, labelcolor=WHITE)

# Grid
ax1.grid(True, alpha=0.1, color=WHITE, linestyle='-')
ax2.grid(False)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/financial_trajectory.png',
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

print("Chart saved: assets/charts/financial_trajectory.png")
