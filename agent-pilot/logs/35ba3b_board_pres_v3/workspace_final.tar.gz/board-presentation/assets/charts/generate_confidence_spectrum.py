#!/usr/bin/env python3
"""
generate_confidence_spectrum.py

Generates the confidence and limitations visualization for Slide 12.
Shows a spectrum from "Facts" to "Estimates" to "Unknowns".

Data source: /input/repo/memo/gitlab_investment_memo.md (Confidence and Limitations section)
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os

# Colors from ADR-001
NAVY = '#1a2332'
TEAL = '#00b4d8'
CORAL = '#e63946'
GREEN = '#2a9d8f'
AMBER = '#f4a261'
SLATE = '#6c757d'
WHITE = '#ffffff'

# Confidence data from memo
categories = [
    {'name': 'Revenue\nTrajectory', 'level': 0.9, 'category': 'Fact',
     'detail': '5 years of consistent growth data', 'color': GREEN},
    {'name': 'Gross\nMargins', 'level': 0.95, 'category': 'Fact',
     'detail': 'Stable at 87-90%, documented across filings', 'color': GREEN},
    {'name': 'Balance\nSheet', 'level': 1.0, 'category': 'Fact',
     'detail': '$1.26B cash, $0.2M debt — a fact, not estimate', 'color': GREEN},
    {'name': 'SaaS Model\nQuality', 'level': 0.85, 'category': 'Fact',
     'detail': 'Subscription revenue, high visibility', 'color': GREEN},
    {'name': 'ARR & NRR', 'level': 0.6, 'category': 'Estimate',
     'detail': 'Management metrics, derived from transcripts', 'color': AMBER},
    {'name': 'AI\nMonetization', 'level': 0.4, 'category': 'Estimate',
     'detail': 'Forward-looking, uncertain revenue impact', 'color': AMBER},
    {'name': 'Competitive\nDynamics', 'level': 0.35, 'category': 'Estimate',
     'detail': 'Pace of GitHub/Atlassian AI development unpredictable', 'color': AMBER},
    {'name': '10-K\nReadings', 'level': 0.1, 'category': 'Unknown',
     'detail': 'SEC filings blocked (403), not read', 'color': CORAL},
    {'name': 'Customer\nInterviews', 'level': 0.05, 'category': 'Unknown',
     'detail': 'No customer validation of NRR or satisfaction', 'color': CORAL},
    {'name': 'Management\nMeetings', 'level': 0.05, 'category': 'Unknown',
     'detail': 'No direct conversations with leadership', 'color': CORAL},
]

# Create figure
fig, ax = plt.subplots(figsize=(12, 7), facecolor=NAVY)
fig.patch.set_facecolor(NAVY)
ax.set_facecolor(NAVY)

# Y-axis positions
y_positions = np.arange(len(categories))

# Draw confidence bars
for i, cat in enumerate(categories):
    bar_width = cat['level']
    ax.barh(i, bar_width, color=cat['color'], alpha=0.7, height=0.6, edgecolor='none')
    
    # Label
    ax.text(-0.05, i, cat['name'], color=WHITE, fontsize=9,
            ha='right', va='center', fontweight='medium')
    
    # Confidence value
    ax.text(bar_width + 0.02, i, f"{cat['level']*100:.0f}%", color=cat['color'],
            fontsize=8, va='center', fontweight='bold')
    
    # Detail
    ax.text(bar_width + 0.02, i - 0.15, cat['detail'], color=SLATE,
            fontsize=7, va='top', alpha=0.7)

# Category labels
ax.axvspan(0.8, 1.0, alpha=0.1, color=GREEN)
ax.text(0.9, -0.5, 'FACTS', color=GREEN, fontsize=10, ha='center', fontweight='bold')

ax.axvspan(0.3, 0.8, alpha=0.1, color=AMBER)
ax.text(0.55, -0.5, 'ESTIMATES', color=AMBER, fontsize=10, ha='center', fontweight='bold')

ax.axvspan(0, 0.3, alpha=0.1, color=CORAL)
ax.text(0.15, -0.5, 'UNKNOWN', color=CORAL, fontsize=10, ha='center', fontweight='bold')

# X-axis
ax.set_xlim(-0.15, 1.1)
ax.set_xticks([])
ax.set_xlabel('Confidence Level', color=WHITE, fontsize=12, fontweight='medium')

# Title
ax.set_title('Confidence & Limitations: What We Know vs. What We Estimate',
             color=WHITE, fontsize=16, fontweight='bold', pad=20)

# Subtitle
ax.text(0.5, -0.95, 'Source: /input/repo/memo/gitlab_investment_memo.md (Confidence and Limitations section)',
        transform=ax.transAxes, color=SLATE, fontsize=9, ha='center')

# Remove y-axis
ax.set_yticks([])
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['left'].set_visible(False)

plt.tight_layout()
plt.savefig('/workspace/board-presentation/assets/charts/confidence_spectrum.png',
            dpi=150, bbox_inches='tight', facecolor=NAVY)
plt.close()

print("Chart saved: assets/charts/confidence_spectrum.png")
