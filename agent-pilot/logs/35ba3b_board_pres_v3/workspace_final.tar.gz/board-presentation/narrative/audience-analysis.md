# Audience Analysis: Board of Advisors

## Who's on the Board

The board is described as **technical and skeptical**. This means:

1. **They understand finance:** They can read a DCF, understand EV/Revenue multiples,
   and evaluate SaaS metrics (NRR, ARR, gross margins). No need to explain basic
   concepts.

2. **They question assumptions:** They will challenge WACC, terminal growth rate,
   and the choice of comparables. Every assumption needs a documented rationale.

3. **They value transparency:** They trust analysts who show their dead ends and
   limitations. They distrust analysts who only show wins.

4. **They care about process:** The reasoning trail is as important as the
   conclusion. They want to know HOW the agent got there, not just WHERE it ended up.

5. **They can verify:** They will clone the repo, follow a trace file, and check
   the source data. The deck must be auditable.

## What Each Board Member Cares About

| Concern | How the Deck Addresses It |
|---------|--------------------------|
| "Is this just a rubber-stamp BUY?" | Slide 2 leads with recommendation but Slide 11 shows dead ends. Slide 13 shows how to audit. |
| "What if the agent is wrong?" | Slide 3 shows what would change the recommendation. Slide 8 prioritizes risks. Slide 9 shows bear case. |
| "Where did these numbers come from?" | Every number traces back to /input/repo/. Slide 13 shows the audit mechanism. |
| "Is the valuation methodology sound?" | ADR-003 documents why DCF + EV/Revenue was chosen. Slide 9 shows scenario analysis. |
| "Are the comparables appropriate?" | ADR-002 documents competitor selection. Slide 6 shows the comp set with rationale. |
| "What did the agent miss?" | Slide 12 shows limitations. Slide 11 shows dead ends. Slide 13 shows how to verify. |
| "Can I trust the agent's process?" | Slide 10 visualizes the reasoning trail. The entire repo is the audit trail. |

## Presentation Strategy

1. **Don't over-explain basics:** The board understands SaaS metrics. Skip
   definitions of NRR, ARR, EV/Revenue.

2. **Focus on the non-obvious:** The board knows GitLab is a DevOps company.
   Focus on why it's undervalued, what the market is missing, and what could
   go wrong.

3. **Invite challenge:** The deck is designed for discussion, not redelivery.
   End with catalysts and position sizing to prompt Q&A.

4. **Show, don't tell:** Charts over text. Decision graphs over bullet points.
   Visualizations over tables.

5. **Be honest about limitations:** The SEC filing blockage, the transcript-only
   earnings analysis, the lack of customer interviews — all documented.
   This builds credibility.
