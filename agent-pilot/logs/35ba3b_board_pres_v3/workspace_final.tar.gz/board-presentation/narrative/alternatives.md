# Alternative Narrative Structures Considered

## Structure A: The Classic Analyst Pitch (REJECTED)
**Order:** Market → Company → Financials → Valuation → Recommendation
**Why rejected:** Leads with context, buries the recommendation. Technical boards
want the answer first, then the evidence. This structure is designed for
fundraising, not for a board that needs to evaluate reasoning.

## Structure B: The Detective Story (REJECTED)
**Order:** Mystery (why is GTLB cheap?) → Clues (data) → Suspects (risks) → Verdict
**Why rejected:** Too narrative for a technical audience. The "reveal" at the end
creates false suspense when the board can read the memo. Also, the agent's
reasoning trail is more interesting than a fictional mystery.

## Structure C: The Data Dump (REJECTED)
**Order:** All financial tables → All charts → All analysis → Conclusion
**Why rejected:** No narrative arc. The board would need to reconstruct the
story themselves. We're demonstrating the agent's reasoning, not just
presenting data.

## Structure D: The Pre-Mortem (REJECTED as primary)
**Order:** Start with "what could go wrong" → then show why we still recommend BUY
**Why rejected:** Too negative for a 30-minute deck. The pre-mortem is included
as a dedicated slide (Slide 8: Risk Assessment) but shouldn't lead the deck.
The board needs to understand the thesis before evaluating the risks.

## Structure E: The Hybrid (ACCEPTED)
**Order:** Recommendation → Thesis → Evidence → Model → Audit → Closing
**Why accepted:** Leads with the answer (respecting the board's time), shows
the evidence chain (for verification), visualizes the reasoning process
(demonstrating capability), and ends with the audit mechanism (building trust).
This structure treats the deck as a demonstration of analytical capability,
not just a stock pitch.

## Structure F: The Decision Tree (REJECTED as primary)
**Order:** Decision nodes → Data inputs → Branches → Final recommendation
**Why rejected:** Too abstract for a board presentation. The decision tree is
included as a visualization (Slide 10: Reasoning Trail) but shouldn't be the
narrative structure. The board needs context before they can follow a decision tree.
