# Storyboard: GitLab (GTLB) Board Presentation

**Date:** 2026-04-25
**Audience:** Board of Advisors (technical, skeptical)
**Duration:** 30 min presentation + 15 min Q&A
**Goal:** Walk the board through the recommendation AND the reasoning trail

---

## Narrative Arc

### Act I: The Bottom Line (Slides 1-3)
**Goal:** Lead with the answer. Technical boards respect clarity over suspense.

**Slide 1 — Title**
- GitLab (GTLB) — BUY recommendation
- Current price $21.51, target $42.00
- Date, presenter

**Slide 2 — Recommendation at a Glance**
- Big, bold: BUY
- Price target $42.00 (95% upside)
- Probability-weighted target $45.98 (114% upside)
- Confidence level: High conviction on business model, moderate on timing
- One-line thesis: "The market is underpricing GitLab's AI monetization potential, operating leverage trajectory, and balance sheet strength"

**Slide 3 — The Thesis in One Slide**
- 5 pillars: TAM growth, proven growth engine, path to profitability, strong balance sheet, AI monetization
- Each pillar gets one sentence, one data point
- This is the agent's own words from the memo

### Act II: The Evidence (Slides 4-8)
**Goal:** Show the data that supports the thesis. Every number traces back.

**Slide 4 — What Would Change the Recommendation**
- 3 things: NRR drops below 110%, AI monetization fails to materialize, GitHub Copilot achieves full-stack DevOps
- Each with a trigger and a consequence
- This shows intellectual honesty — we've thought about what could be wrong

**Slide 5 — Financial Trajectory**
- Revenue: $424M → $955M (30% CAGR)
- Operating margin: -50% → -7% (13pp improvement per year)
- FCF: -$84M → +$222M
- Projected to $1.15B+ revenue by FY2027
- Inflection points called out: FCF positive in FY2024, GAAP profitability expected FY2028

**Slide 6 — Competitive Position**
- Scatter plot: Revenue Growth vs. EV/Revenue
- GitLab is the outlier: high growth, low multiple
- Why these comps: SaaS infrastructure, similar growth profiles, public
- Full-stack vs. point-solution differentiation

**Slide 7 — The Mispricing Thesis**
- Current EV/Revenue: 2.6x vs. peer avg 7.0x
- Three factors the market is underpricing:
  1. AI monetization (GitLab Duo embedded in workflow)
  2. Operating leverage (fixed costs spreading over $1B+ revenue)
  3. Balance sheet optionality ($1.26B net cash)
- Sell-side consensus: $30.79 mean (43% upside) vs. our $42.00 (95% upside)

**Slide 8 — Risk Assessment**
- Risk matrix: probability vs. impact
- Top risks: NRR decline, GitHub competition, macro downturn
- Each risk has: what would have to be true, early warning signals, mitigation
- This is the "pre-mortem" — we've thought about what kills the thesis

### Act III: The Model (Slides 9-11)
**Goal:** Show how the agent got from data to conclusion.

**Slide 9 — Bear/Base/Bull Scenarios**
- Probability-weighted visualization (not three bullet points)
- Distribution of price targets: $18.58 (25%), $38.52 (50%), $88.30 (25%)
- Weighted average: $45.98
- Key assumption differences between scenarios

**Slide 10 — The Reasoning Trail**
- Decision graph: Filings → Data Collection → Analysis → Valuation → Conclusion
- Shows the dependency chain: which decisions depended on which data
- Built from the input repo's decisions/ and commit history
- This is the "how we got here" visualization

**Slide 11 — Dead Ends**
- SEC filings blocked (403) → used yfinance instead
- GitLab IR site unreachable → used transcripts
- PRNewswire 404 → no press releases
- Wrong CIK initially → verified through SEC search
- Earnings call audio unavailable → text transcripts only
- Each dead end shows what we tried, why it failed, what we used instead

### Act IV: The Audit (Slides 12-13)
**Goal:** Show the board how to verify everything.

**Slide 12 — Confidence & Limitations (Visual)**
- What we're confident about (facts): revenue trajectory, gross margins, balance sheet, SaaS model
- What we're estimating (assumptions): ARR/NRR, AI monetization, competitive dynamics
- What a human analyst would do differently: read 10-Ks, attend calls, customer interviews
- Visual: confidence thermometer or spectrum

**Slide 13 — How to Audit This Deck**
- Step-by-step: clone repo → pick any claim → follow trace → verify
- Show the trace file structure
- Example: "Revenue grew 26% in FY2026" → audit/traces/slide5-revenue-growth.md → extracted/income_statement_annual.csv → yfinance → SEC filings
- This is the most important slide for a skeptical board

### Act V: Closing (Slide 14)
**Slide 14 — Summary & Next Steps**
- Recommendation: BUY at $21.51, target $42.00
- Key catalysts: FY2027 Q1 earnings, AI feature expansion, GAAP profitability
- Position sizing: 2-3% of portfolio
- Q&A

---

## Design Principles

1. **Lead with the answer** — technical boards don't need suspense
2. **Show the work** — every number traces back to a source
3. **Surface dead ends** — honesty builds trust
4. **Visualize, don't bullet** — charts over text wherever possible
5. **Color consistency** — bear/base/bull colors consistent across all slides
6. **No clip art** — charts are the visual centerpiece

## Color Palette

- **Primary:** Deep navy (#1a2332) for backgrounds, white for text
- **Accent:** Teal (#00b4d8) for positive/upside elements
- **Bear scenario:** Coral/red (#e63946)
- **Base scenario:** Teal/blue (#00b4d8)
- **Bull scenario:** Green (#2a9d8f)
- **Neutral:** Slate gray (#6c757d)
- **Highlight:** Amber (#f4a261) for key numbers

## Typography

- **Headings:** Inter Bold (clean, modern, technical)
- **Body:** Inter Regular
- **Numbers:** Inter Medium (tabular nums for alignment)
