# Research Notes — Session 3: Deck Construction
**Date:** 2026-04-25
**Topic:** Building the PowerPoint deck with python-pptx

## Key Decisions

### Slide Count
Targeted 14 slides (within the 15-25 range). Rationale:
- 30-minute presentation with 15 minutes Q&A
- ~2 minutes per slide on average
- More slides would rush the discussion; fewer would leave gaps

### Slide Order
Followed the storyboard:
1. Title
2. Recommendation at a Glance
3. The Thesis
4. What Would Change the Recommendation
5. Financial Trajectory
6. Competitive Position
7. The Mispricing Thesis
8. Risk Assessment
9. Bear/Base/Bull Scenarios
10. The Reasoning Trail
11. Dead Ends
12. Confidence & Limitations
13. How to Audit This Deck
14. Summary & Next Steps

### python-pptx Implementation
- Used Inter font (system font, no external files needed)
- Navy background on every slide
- Consistent header/footer pattern
- Charts embedded as PNG images
- Tables for data-heavy slides
- No clip art, no stock imagery

### Export
- PPTX as primary deliverable
- PDF export for easy sharing
- Both use the same source files
