# Research Notes — Session 2: Chart Design
**Date:** 2026-04-25
**Topic:** Designing charts for the board presentation

## Design Decisions Made

### Color Palette
Chose navy (#1a2332) background with teal (#00b4d8) accent. Rationale:
- Navy conveys seriousness for a board deck
- Teal is distinctive but not flashy
- Scenario colors (bear=red, base=teal, bull=green) are consistent across all slides
- Amber (#f4a261) for key numbers draws attention without confusion

### Chart Types
1. **Financial Trajectory:** Multi-axis chart (revenue bars + margin line + FCF line)
   - Shows three metrics on one chart to reveal the relationship between growth and profitability
   - Inflection points annotated (FCF positive FY2024, GAAP profitability FY2028)

2. **Scenario Distribution:** Violin-style plot with probability weights
   - Not three bullet points — shows the distribution shape
   - Width encodes probability (base case is twice as wide as bear/bull)
   - Probability-weighted target shown as a line

3. **Competitive Landscape:** Scatter plot (growth vs. EV/Revenue)
   - Bubble size = market cap
   - GitLab highlighted as the outlier (high growth, low multiple)
   - Quadrant labels show the "mispricing zone"

4. **Risk Matrix:** Probability vs. Impact scatter
   - Bubble size = probability × impact
   - Quadrant shading shows risk zones
   - Top risks annotated with triggers

5. **Confidence Spectrum:** Horizontal bar chart
   - Ranks items from most to least confident
   - Color-coded by category (facts/estimates/unknowns)
   - Shows the full range of what we know vs. estimate

6. **Reasoning Trail:** Decision graph (network diagram)
   - Shows the dependency chain from data collection to recommendation
   - Dead ends shown as red nodes
   - Fallback (yfinance) shown as orange node

### Chart Scripts
Each chart has a standalone Python script in /assets/charts/ that:
- Reads data from /input/repo/
- Produces a PNG in /assets/charts/
- Uses the same color palette as the deck
- Is reproducible (run the script, get the chart)
