# Research Notes — Session 1: Input Repo Analysis
**Date:** 2026-04-25
**Topic:** Understanding the input repo structure and content

## Key Findings

### Repo Structure
The input repo has a clean structure:
- `memo/` — Final investment memo (markdown)
- `model/` — Three-statement financial model (Excel)
- `extracted/` — Parsed financial data (CSV, JSON)
- `raw/` — SEC filings (blocked), earnings transcripts (truncated), competitor data
- `analysis/` — Analysis notebook and summary
- `research/` — Notes, questions, dead-ends
- `decisions/` — ADR-style decision records

### Company: GitLab Inc. (GTLB)
- NYSE-listed DevOps platform
- Market cap: $3.66B
- Current price: $21.51
- FY2026 revenue: $955M (26% YoY growth)
- Operating margin: -7.4% (improving from -50% in FY2023)
- FCF: $222M (positive since FY2024)
- Cash & investments: $1.26B
- Shares outstanding: 170.1M

### Data Quality Assessment
- **Financial data (yfinance):** Good quality, sourced from SEC filings
- **Competitor data (yfinance):** Good quality, 10 companies including GTLB
- **Earnings transcripts:** Truncated — only headers available (JS-loaded content)
- **SEC filings:** Blocked (403 errors) — documented in dead-ends.md
- **ARR/NRR:** Derived from transcripts, not GAAP figures

### Commit History
3 commits:
1. `0276dd3` — Initialize repo structure and select GitLab
2. `c690042` — Collect financial data, competitor analysis, earnings transcripts
3. `ea3b335` — Complete investment memo, financial model, and all supporting documentation

### What I Need to Build
1. 15-25 slide deck (pptx + PDF)
2. Chart scripts that regenerate every chart from input repo data
3. Trace files for every claim
4. Audit files (numbers, quotes, reconciliation)
5. Narrative files (storyboard, alternatives, audience analysis)
6. ADRs for design decisions
7. Research notes documenting my process
