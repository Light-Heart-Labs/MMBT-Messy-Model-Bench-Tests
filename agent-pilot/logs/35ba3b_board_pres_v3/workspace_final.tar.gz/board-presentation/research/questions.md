# Questions About the Input Repo

## Q1: Are the earnings call transcripts complete?
**Issue:** The .txt transcript files are truncated — only headers (participants, Safe Harbor) are present. The .html files are mostly CSS/JS with no transcript content.
**Resolution:** The transcripts were loaded via JavaScript on Seeking Alpha's website. The automated download only captured the initial HTML, not the JS-rendered content. This is documented in the input repo's dead-ends.md (Dead End #5). For the deck, I used the financial data from yfinance and the memo's analysis, which is the best available source.
**Status:** Resolved — acknowledged as a limitation in the deck.

## Q2: Why are SEC filings not available?
**Issue:** All attempts to download SEC filings returned 403 errors.
**Resolution:** SEC.gov blocks automated requests. The input repo used yfinance as a secondary source, which sources from SEC filings but is not the original filing. This is documented in dead-ends.md (Dead End #1) and in the memo's limitations section.
**Status:** Resolved — acknowledged as a limitation.

## Q3: What fiscal year does "FY2026" correspond to?
**Issue:** GitLab's fiscal year ends January 31. FY2026 ended January 31, 2026.
**Resolution:** Confirmed from the CSV column headers (2026-01-31) and the memo's notes. FY2026 is the most recent full year. Projections start from FY2027.
**Status:** Resolved.

## Q4: Are ARR and NRR GAAP figures?
**Issue:** ARR and NRR are management metrics, not GAAP figures.
**Resolution:** Confirmed from the memo's "What We're Estimating" section. ARR and NRR are derived from earnings call transcripts and may differ from official figures. This is a key limitation that the deck surfaces.
**Status:** Resolved — surfaced in the confidence slide.

## Q5: What explains the large tax provision in FY2024?
**Issue:** FY2024 shows $289M in tax payable which seems anomalous.
**Resolution:** From the input repo's questions.md (Q8): "This appears to be a one-time tax settlement or adjustment. The effective tax rate was negative (company had a large net loss). Excluded from forward projections; used 21% statutory rate going forward."
**Status:** Resolved — not used in projections.

## Q6: Which competitors are most comparable to GitLab?
**Issue:** GitLab operates in a unique space (full-stack DevOps platform). No perfect comparable exists.
**Resolution:** From ADR-002: Selected 8 SaaS infrastructure/application companies with similar growth profiles and business models. Excluded GitHub (private), ServiceNow (too large), Palo Alto Networks (different sector).
**Status:** Resolved — documented in ADR-002 and the competitive landscape slide.

## Q7: Is the WACC of 10.5% appropriate?
**Issue:** WACC is a critical assumption that significantly impacts DCF valuation.
**Resolution:** From ADR-003: Used CAPM with Rf=4.5% (10Y Treasury), Beta=1.2 (SaaS sector), ERP=5.5%. Cost of equity = 11.1%. With negligible debt, WACC ≈ 10.5%.
**Status:** Resolved — documented in ADR-003 and the scenario analysis slide.

## Q8: How should the scenario visualization be designed?
**Issue:** The bear/base/bull scenarios must appear as a real visualization, not three bullet points.
**Resolution:** Chose a violin-style plot with probability weights encoded in width. This shows the distribution shape, not just three points. The probability-weighted target ($45.98) appears as a line across the distribution.
**Status:** Resolved — implemented in the scenario distribution chart.
