# Dead Ends: Slide Concepts and Visualizations That Didn't Make the Cut

## 1. Pie Chart for Competitive Landscape (REJECTED)
**What I tried:** Market-share pie chart showing GitLab's share of the DevOps market.
**Why it didn't work:** A pie chart would show GitLab's small share but would not reveal the key insight: GitLab has high growth at a low multiple. The scatter plot (growth vs. EV/Revenue) makes the mispricing visible; a pie chart would not.
**What replaced it:** Scatter plot with bubble size = market cap (Slide 6).

## 2. Bell Curve for Scenario Analysis (REJECTED)
**What I tried:** A normal distribution curve centered on the base case price.
**Why it didn't work:** The scenario distribution is intentionally asymmetric (bear at $18.58, bull at $88.30). A bell curve would imply symmetry and hide the actual scenario assumptions. The violin plot shows the actual shape.
**What replaced it:** Violin-style plot with probability weights (Slide 9).

## 3. Timeline for Financial Trajectory (REJECTED)
**What I tried:** A simple line chart showing revenue over time.
**Why it didn't work:** A single line doesn't show the relationship between revenue growth and margin improvement. The multi-axis chart (revenue bars + margin line + FCF line) reveals the operating leverage story.
**What replaced it:** Multi-axis chart with three metrics (Slide 5).

## 4. Heat Map for Risk Assessment (REJECTED)
**What I tried:** A color-coded heat map of risks by category.
**Why it didn't work:** A heat map shows relative values but not the relationship between probability and impact. The scatter plot (probability vs. impact) shows which risks are both likely AND severe — the ones that matter most.
**What replaced it:** Probability vs. Impact scatter plot (Slide 8).

## 5. Decision Tree for Reasoning Trail (REJECTED as primary visualization)
**What I tried:** A traditional decision tree with branches for each decision node.
**Why it didn't work:** Too abstract for a board presentation. The network diagram (dependency graph) is more intuitive — it shows the flow from data collection to conclusion, with dead ends visible as red nodes.
**What replaced it:** Network diagram with colored nodes by phase (Slide 10).

## 6. Word Cloud for Limitations (REJECTED)
**What I tried:** A word cloud showing the frequency of limitation-related terms.
**Why it didn't work:** Word clouds are decorative, not analytical. The confidence spectrum (horizontal bar chart) shows the actual confidence levels for each category of information.
**What replaced it:** Confidence spectrum bar chart (Slide 12).

## 7. Animated Transitions (REJECTED)
**What I tried:** Adding slide transitions and animations to the PPTX.
**Why it didn't work:** The board is technical and skeptical. Animations would feel gimmicky and distract from the content. The charts are the visual centerpiece; they don't need animation to be compelling.
**What replaced it:** Static, clean slides with data as the visual focus.

## 8. Stock Photo Imagery (REJECTED)
**What I tried:** Adding stock photos of developers, code, or office environments.
**Why it didn't work:** The rules explicitly forbid clip art and generic stock imagery. Charts are the visual centerpiece. Adding photos would dilute the data-focused aesthetic.
**What replaced it:** No imagery — charts and data are the visual focus.
