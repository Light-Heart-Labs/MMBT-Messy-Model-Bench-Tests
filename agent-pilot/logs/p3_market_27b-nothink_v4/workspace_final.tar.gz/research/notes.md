# Research Notes — Password Manager Evaluation

**Date:** 2025-07-10
**Researcher:** Security/Engineering Advisory

## Context
- 50-person engineering team, Series-B SaaS company
- Current state: shadow IT (browser, sticky notes, Slack DMs)
- CTO mandate: fix within 90 days
- Need: team-wide standardization on a single password manager

## Products Evaluated
1. 1Password
2. Bitwarden
3. LastPass
4. Dashlane
5. Keeper Security

## Pricing Data Collected

### 1Password
- Individual: $2.99/mo (billed annually) [source: 1password.com/pricing/]
- Teams Starter Pack: $19.95/mo (up to 10 users) [source: 1password.com/pricing/]
- Business: $7.99/user/mo (billed annually) [source: 1password.com/pricing/]
- 50-seat annual: $4,794

### Bitwarden
- Premium: $1.65/mo [source: bitwarden.com/pricing/]
- Families: $3.99/mo [source: bitwarden.com/pricing/]
- Teams: $4.00/user/mo ($48/yr) [source: bitwarden.com/pricing/, pcmag.com]
- Enterprise: $6.00/user/mo ($72/yr) [source: bitwarden.com/pricing/, pcmag.com]
- 50-seat annual (Teams): $2,400

### LastPass
- Premium: $1.65/mo ($19.80/yr) [source: zdnet.com]
- Families: $3.99/mo ($47.88/yr) [source: zdnet.com]
- Teams: $51/yr/user [source: pcmag.com/reviews/lastpass]
- Business: $84/yr/user [source: pcmag.com/reviews/lastpass]
- Business Max: $108/yr/user [source: pcmag.com/reviews/lastpass]
- 50-seat annual (Business): $4,200

### Dashlane
- Personal: $2.71/mo (billed annually) [source: zdnet.com]
- Family: $4.07/mo (up to 10 members) [source: zdnet.com]
- Business: $96/seat/year [source: pcmag.com/reviews/dashlane]
- Omnix: $132/seat/year [source: pcmag.com/reviews/dashlane]
- 50-seat annual (Business): $4,800

### Keeper
- Personal: $1.67/mo [source: zdnet.com]
- Family: $3.54/mo (5 seats) [source: zdnet.com]
- Business: $7.00/mo/user (min 5 seats) [source: zdnet.com]
- 50-seat annual: $4,200

## Security Incident History

### 1Password
- No major security incidents reported [source: en.wikipedia.org/wiki/1Password]

### Bitwarden
- No major security incidents reported [source: en.wikipedia.org/wiki/Bitwarden]
- 2018: Cliqz privacy review found no issues [source: en.wikipedia.org/wiki/Bitwarden]

### LastPass
- 2011: Possible server intrusion, no data exfiltration confirmed [source: en.wikipedia.org/wiki/LastPass]
- 2015: Email addresses, password reminders, salts, and auth hashes compromised [source: en.wikipedia.org/wiki/LastPass]
- 2017: Android app security flaws (improperly stored master passwords, data leakage) [source: en.wikipedia.org/wiki/LastPass]
- 2021: Third-party trackers in Android app; master passwords compromised [source: en.wikipedia.org/wiki/LastPass]
- 2022: Two incidents — dev environment breach (source code, encrypted keys) and DevOps engineer compromise (keystroke logger, vault access) [source: en.wikipedia.org/wiki/LastPass]
- 2024: Injection attack vulnerability [source: en.wikipedia.org/wiki/LastPass]
- 2025: DOM-based extension clickjacking [source: en.wikipedia.org/wiki/LastPass]
- 2026: ETH Zurich study showed zero-knowledge encryption could be bypassed [source: en.wikipedia.org/wiki/LastPass]

### Dashlane
- 2024: Injection attack vulnerability (leaked duplicate-password counts) [source: en.wikipedia.org/wiki/Dashlane]
- 2025: DOM-based extension clickjacking [source: en.wikipedia.org/wiki/Dashlane]

### Keeper
- 2017: Android app security flaws (Fraunhofer SIT analysis) [source: en.wikipedia.org/wiki/Keeper_Security]

## Compliance Certifications

### 1Password
- SOC 2 Type II [source: trust.1password.io]
- ISO 27001 [source: trust.1password.io]
- GDPR [source: trust.1password.io]
- PCI DSS [source: trust.1password.io]
- TX-RAMP Level 1 (FedRAMP) [source: trust.1password.io]

### Bitwarden
- SOC 2 [source: bitwarden.com/compliance/]
- SOC 3 [source: bitwarden.com/compliance/]
- ISO 27001 [source: bitwarden.com/compliance/]
- HIPAA [source: bitwarden.com/compliance/]
- GDPR [source: bitwarden.com/compliance/]

### LastPass
- SOC 2 [source: lastpass.com/compliance]
- (Other certifications not publicly verifiable)

### Dashlane
- ISO 27001 [source: zdnet.com]
- (SOC 2 not publicly verifiable on own site)

### Keeper
- FIPS 140-2 [source: zdnet.com]
- SOC 2 [source: en.wikipedia.org/wiki/Keeper_Security]

## Developer Tooling Assessment

### 1Password
- CLI tool (official) [source: 1password.com/developers/]
- SSH agent [source: 1password.com/developers/]
- Secrets Automation (Service Accounts) [source: 1password.com/developers/]
- CI/CD: GitHub, Terraform, Ansible, Pulumi, Kubernetes [source: 1password.com/developers/]
- SDKs [source: 1password.com/developers/]
- Git commit signing [source: 1password.com/developers/]
- AI agent support [source: 1password.com/developers/]

### Bitwarden
- CLI tool (official) [source: en.wikipedia.org/wiki/Bitwarden]
- API access [source: en.wikipedia.org/wiki/Bitwarden]
- Open-source (self-hostable) [source: en.wikipedia.org/wiki/Bitwarden]
- CI/CD integration (community) [source: en.wikipedia.org/wiki/Bitwarden]

### LastPass
- CLI tool [source: pcmag.com/reviews/lastpass]
- API access [source: pcmag.com/reviews/lastpass]

### Dashlane
- CLI tool [source: zdnet.com]
- API access [source: zdnet.com]

### Keeper
- CLI tool [source: zdnet.com]
- API access [source: zdnet.com]

## Data Gaps & Uncertainties

1. **Keeper pricing:** Website serves cookie consent wall. Business pricing ($7/user/mo) sourced from ZDNET only.
2. **Dashlane business pricing:** Not listed on own website. Sourced from PCMag ($96/seat/year).
3. **LastPass business pricing:** Website uses template variables. Sourced from PCMag ($84/seat/year).
4. **1Password Linux support:** Official Linux desktop app exists but is community-maintained. CLI is officially supported.
5. **All products:** Trustpilot ratings sourced from ZDNET and PCMag, not directly from Trustpilot.

## Final Recommendation

**1Password Business** at $7.99/user/month ($4,794/year for 50 seats) is recommended.

**Runner-up:** Bitwarden Teams at $4.00/user/month ($2,400/year for 50 seats).
