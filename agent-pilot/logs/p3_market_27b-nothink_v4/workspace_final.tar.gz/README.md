# Password Manager Evaluation — Output Files

This directory contains the outputs of a password manager evaluation for a 50-person engineering team at a Series-B SaaS company.

## Files

| File | Description |
|------|-------------|
| `recommendation.md` | **Primary deliverable.** 1-2 page recommendation memo with decision criteria, product recommendation, runner-up, and concerns. |
| `comparison.md` | Side-by-side feature/pricing/security comparison table of the 5 evaluated products. |
| `sources.md` | Every URL fetched during research, with timestamps, descriptions, and SHA-256 hashes. |
| `research/notes.md` | Working notes with raw data, pricing figures, security incident history, and compliance certifications. |
| `decisions/001-product-selection.md` | ADR: Which 5 products were selected and why. |
| `decisions/002-evaluation-criteria.md` | ADR: What criteria were used to evaluate products. |
| `decisions/003-primary-recommendation.md` | ADR: The primary recommendation and rationale. |

## How to Read

1. **Start with `recommendation.md`** — This is the executive summary and final recommendation.
2. **Review `comparison.md`** — For a detailed side-by-side comparison of all 5 products.
3. **Check `sources.md`** — For verification of every factual claim. Every price, feature, and security claim is linked to a source.
4. **Read `research/notes.md`** — For the raw research data and working notes.
5. **Review `decisions/`** — For the decision records on non-obvious calls (product selection, criteria, recommendation).

## Products Evaluated

1. **1Password** — Recommended
2. **Bitwarden** — Runner-up
3. **LastPass** — Disqualified (security incident history)
4. **Dashlane** — Not recommended (pricing, security vulnerabilities)
5. **Keeper Security** — Not recommended (weaker developer tooling, lower satisfaction)

## Key Finding

**1Password Business** at **$7.99/user/month** ($4,794/year for 50 seats) is recommended for its combination of developer tooling, security posture, compliance certifications, and admin UX.

**Bitwarden Teams** at **$4.00/user/month** ($2,400/year for 50 seats) is the runner-up and would be preferred if budget is the top constraint.

## Research Date

All web fetches were performed on 2025-07-10. Pricing and feature data reflects what was available on that date.
