# Sources

All URLs fetched during research, with timestamps, descriptions, and SHA-256 hashes.

**Research Date:** 2025-07-10 (all fetches performed on this date)

## 1Password

| # | URL | Description | SHA-256 |
|---|-----|-------------|---------|
| 1 | https://1password.com/pricing/ | Pricing page — Individual ($2.99/mo), Teams Starter Pack ($19.95/mo for up to 10 users), Business ($7.99/user/mo) | `b5196df8` |
| 2 | https://1password.com/business/ | Business features page — SSO, admin console, developer tools | `345d4625` |
| 3 | https://trust.1password.io/ | Trust Center — SOC 2 Type II, ISO 27001, GDPR, PCI DSS, FedRAMP TX-RAMP Level 1 | `7707e98c` |
| 4 | https://1password.com/developers/ | Developer tools — CLI, SSH agent, Secrets Automation, CI/CD integration, SDKs | `93f85c1c` |
| 5 | https://1password.com/features/secrets-management/ | Secrets Management — infrastructure secrets, Service Accounts | `02d624a5` |
| 6 | https://en.wikipedia.org/wiki/1Password | Wikipedia — no major security incidents reported | `3edf1fd8` |

## Bitwarden

| # | URL | Description | SHA-256 |
|---|-----|-------------|---------|
| 7 | https://bitwarden.com/pricing/ | Pricing page — Premium ($1.65/mo), Families ($3.99/mo), Teams ($4/user/mo), Enterprise ($6/user/mo) | `18067793` |
| 8 | https://bitwarden.com/compliance/ | Compliance page — SOC 2, SOC 3, ISO 27001, HIPAA, GDPR, zero-knowledge architecture | `698e1afac4` |
| 9 | https://en.wikipedia.org/wiki/Bitwarden | Wikipedia — open-source, no major security incidents | `7ab984fd` |
| 10 | https://www.pcmag.com/reviews/bitwarden | PCMag review — Teams $48/year/user, Enterprise $72/year/user | `00f37f81` |

## LastPass

| # | URL | Description | SHA-256 |
|---|-----|-------------|---------|
| 11 | https://www.lastpass.com/pricing | Pricing page — Premium ($1.65/mo), Families ($3.99/mo), Teams ($51/year/user), Business ($84/year/user), Business Max ($108/year/user) | `5c684ab0` |
| 12 | https://www.lastpass.com/compliance | Compliance page — redirects to pricing (JS-rendered) | `51e72a44` |
| 13 | https://en.wikipedia.org/wiki/LastPass | Wikipedia — multiple security incidents: 2011 intrusion, 2015 breach, 2017 Android flaws, 2021 trackers, 2022 vault theft, 2024 injection attacks, 2025 clickjacking, 2026 ETH Zurich zero-knowledge bypass | `4bd439fa` |
| 14 | https://www.pcmag.com/reviews/lastpass | PCMag review — Teams $51/year, Business $84/year, Business Max $108/year | `4969aee0` |

## Dashlane

| # | URL | Description | SHA-256 |
|---|-----|-------------|---------|
| 15 | https://www.dashlane.com/pricing | Pricing page — personal $2.71/mo, family $4.07/mo (no business pricing on page) | `b3d2fdbcc` |
| 16 | https://www.dashlane.com/business-password-manager | Business features page — SSO, SCIM, SIEM, VPN | `bda0230d` |
| 17 | https://www.dashlane.com/business-password-manager/enterprise | Enterprise features page | `368ca985` |
| 18 | https://www.dashlane.com/security | Security page — zero-knowledge, ISO 27001 | `a75fcc29` |
| 19 | https://en.wikipedia.org/wiki/Dashlane | Wikipedia — 2024 injection attack vulnerability, 2025 DOM-based clickjacking | `2a05b9b6` |
| 20 | https://www.pcmag.com/reviews/dashlane | PCMag review — Business $96/seat/year, Omnix $132/seat/year | `99e58c21` |

## Keeper Security

| # | URL | Description | SHA-256 |
|---|-----|-------------|---------|
| 21 | https://www.keepersecurity.com/pricing/ | Pricing page — cookie consent wall (no pricing data) | `c4802c02` |
| 22 | https://www.keepersecurity.com/security/ | Security page — cookie consent wall | `c4802c02` |
| 23 | https://en.wikipedia.org/wiki/Keeper_Security | Wikipedia — FIPS 140-2 validated, 2017 Android security flaws | `b7b6a051` |

## Third-Party Comparison Sources

| # | URL | Description | SHA-256 |
|---|-----|-------------|---------|
| 24 | https://www.zdnet.com/article/best-password-manager/ | ZDNET comparison — 1Password $2.99/mo, Bitwarden $1.65/mo, Keeper $1.67/mo personal / $7/mo business, Dashlane $2.71/mo, LastPass $1.65/mo personal / $4/user/mo business | `e99b605a` |
| 25 | https://www.pcmag.com/picks/best-password-managers-for-business | PCMag business picks — pricing overview | `f25d2ea7` |
| 26 | https://www.pcmag.com/reviews/1password | PCMag 1Password review | `4ab6fcc4` |
| 27 | https://www.pcmag.com/reviews/keeper-security | PCMag Keeper review | `4ab6fcc4` |

## Notes on Data Gaps

- **Keeper pricing:** The Keeper website serves a cookie consent wall that blocks pricing data. Business pricing ($7/user/month) was sourced from ZDNET [24].
- **Dashlane business pricing:** Not listed on Dashlane's own pricing page. Sourced from PCMag [20]: Business $96/seat/year, Omnix $132/seat/year.
- **LastPass business pricing:** The LastPass pricing page uses template variables (`{LPTeams}`, `{LPBusiness}`) that are resolved client-side. Actual pricing sourced from PCMag [14]: Teams $51/year, Business $84/year, Business Max $108/year.
- **1Password Business pricing:** Sourced directly from 1Password's pricing page [1]: $7.99/user/month billed annually.
