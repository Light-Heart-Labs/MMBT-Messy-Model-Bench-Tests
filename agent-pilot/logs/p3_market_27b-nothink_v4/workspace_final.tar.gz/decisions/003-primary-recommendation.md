# ADR-003: Primary Recommendation — 1Password Business

**Date:** 2025-07-10
**Status:** Accepted
**Decision Makers:** Security/Engineering Advisory

## Context

After evaluating 5 password managers against the criteria defined in ADR-002, we need to select a primary recommendation.

## Decision

**1Password Business** at **$7.99/user/month** (billed annually) is recommended as the primary choice.

### Why 1Password Business over Teams Starter Pack

- Teams Starter Pack is capped at 10 users; our team is 50
- Business tier adds SSO integration (Okta, Entra ID, OneLogin, Duo)
- Business tier adds Watchtower alerts for security hygiene
- Business tier adds role-based vault sharing and permissions

### Why 1Password over the other 4 products

1. **vs. Bitwarden:** Bitwarden is cheaper ($4/user/month for Teams) but 1Password has superior developer tooling (CLI, SSH agent, Secrets Automation), better admin UX, and more polished native apps. For an engineering team, the developer experience matters.

2. **vs. LastPass:** LastPass has had multiple significant security breaches (2011, 2015, 2021, 2022) and a 2026 ETH Zurich study showed its "zero-knowledge" claims could be bypassed. This is unacceptable for a SaaS company handling customer data.

3. **vs. Dashlane:** Dashlane is significantly more expensive ($96/seat/year = $8/seat/month for Business, $132/seat/year for Omnix) and has had security vulnerabilities (2024 injection attacks, 2025 DOM-based clickjacking). No free trial for business plans.

4. **vs. Keeper:** Keeper is well-priced ($7/seat/month) and FIPS 140-2 validated, but has weaker developer tooling, lower user satisfaction ratings (Trustpilot 3.6), and less polished UX.

## Consequences

- Annual cost: 50 seats × $7.99 × 12 = **$4,794/year**
- 14-day free trial available for evaluation
- Migration from shadow IT will require admin effort but 1Password provides import tools
- Developer tooling (CLI, SSH agent, Secrets Automation) will benefit the engineering workflow
