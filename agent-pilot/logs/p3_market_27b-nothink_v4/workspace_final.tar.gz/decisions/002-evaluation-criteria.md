# ADR-002: Evaluation Criteria

**Date:** 2025-07-10
**Status:** Accepted
**Decision Makers:** Security/Engineering Advisory

## Context

We need to define the criteria for evaluating password managers to ensure an apples-to-apples comparison.

## Decision

The following criteria were established, weighted by importance:

### Critical (Must-Have)

1. **SSO Integration** — Must support SAML SSO with Google Workspace (our IdP). Okta/Entra ID support is a plus.
2. **Admin Console & Audit Logging** — Must provide admin dashboard with user management, audit logs, and security policy enforcement for SOC 2 compliance.
3. **Zero-Knowledge Architecture** — Vendor must not be able to access user vault data.
4. **Cross-Platform Support** — Must support macOS, Windows, Linux, iOS, Android, and major browsers.
5. **Pricing Transparency** — Must have publicly listed per-seat pricing (no "contact sales" only).

### Important (Should-Have)

6. **Developer Tooling** — CLI tool, API access, CI/CD integration (GitHub Actions, etc.), SSH key management.
7. **Team Collaboration** — Shared vaults, role-based permissions, secure sharing.
8. **Security Certifications** — SOC 2 Type II, ISO 27001, or equivalent.
9. **Mobile + Desktop Coverage** — Native apps on all major platforms.
10. **Password Health / Breach Monitoring** — Dark web monitoring, password strength alerts.

### Nice-to-Have

11. **Passkey Support** — FIDO2/WebAuthn passkey generation and management.
12. **Emergency Access** — Trusted contact access for lost master passwords.
13. **Self-Hosted Option** — Ability to self-host for data sovereignty.
14. **Free Tier / Trial** — Free plan or generous trial for evaluation.

## Rationale

- The team is engineering-focused, so developer tooling is weighted higher than for a non-technical team
- SOC 2 compliance is likely required for a Series-B SaaS company
- SSO integration is critical for reducing friction in adoption
- Pricing transparency is important for budgeting and avoiding vendor lock-in surprises
