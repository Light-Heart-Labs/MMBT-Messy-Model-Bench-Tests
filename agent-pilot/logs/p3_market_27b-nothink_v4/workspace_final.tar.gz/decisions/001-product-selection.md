# ADR-001: Product Selection for Evaluation

**Date:** 2025-07-10
**Status:** Accepted
**Decision Makers:** Security/Engineering Advisory

## Context

We need to evaluate password managers for a 50-person engineering team at a Series-B SaaS company. The team currently has shadow-IT password storage (browser, sticky notes, Slack DMs) and the CTO wants this fixed within 90 days.

## Decision

We selected the following 5 password managers for evaluation:

1. **1Password** — Market leader, strong developer tooling, well-established business tier
2. **Bitwarden** — Open-source, most affordable, strong security posture
3. **LastPass** — Long-standing market presence, but with significant security incident history
4. **Dashlane** — Feature-rich, business-focused, but highest pricing
5. **Keeper Security** — Security-focused, FIPS 140-2 validated, strong enterprise features

## Rationale

- These 5 represent the most commonly recommended password managers in independent reviews (ZDNET, PCMag, TechRadar)
- They span the pricing spectrum from free/open-source (Bitwarden) to premium (Dashlane)
- They cover different security models (zero-knowledge, FIPS-validated, open-source)
- All support SSO integration, which is a key requirement for a SaaS company
- All have developer tooling (CLI, API, CI/CD integration)

## Alternatives Considered

- **NordPass** — Good consumer product but limited business features and admin console
- **Proton Pass** — Growing but relatively new in the business space
- **Enpass** — Offline-first model doesn't fit team collaboration needs
- **Azure Key Vault / AWS Secrets Manager** — These are secrets management infrastructure, not password managers for human users
