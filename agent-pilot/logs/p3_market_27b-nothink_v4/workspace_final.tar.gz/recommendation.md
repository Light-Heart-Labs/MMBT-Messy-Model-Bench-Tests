# Recommendation: Standardize on 1Password Business

**To:** CTO & Engineering Leadership
**From:** Security/Engineering Advisory
**Date:** 2025-07-10
**Subject:** Password Manager Standardization for 50-Person Engineering Team

---

## Executive Summary

After evaluating 5 password managers (1Password, Bitwarden, LastPass, Dashlane, Keeper Security), we recommend **1Password Business** at **$7.99/user/month** (billed annually) as the standard password manager for our engineering team.

**Total annual cost for 50 seats: $4,794** ($95.88/user/year).

1Password was selected for its combination of:
- **Best-in-class developer tooling** (CLI, SSH agent, Secrets Automation, CI/CD integration)
- **Strong security posture** with zero reported security incidents
- **Comprehensive compliance certifications** (SOC 2 Type II, ISO 27001, GDPR, PCI DSS)
- **SSO integration** with Okta, Entra ID, OneLogin, Duo, and Google Workspace
- **Excellent admin UX** with audit logging, role-based permissions, and security policy enforcement

---

## Decision Criteria

We evaluated products against the following criteria, weighted by importance to our team:

### Critical (Must-Have)

1. **SSO Integration** — Must support SAML SSO with Google Workspace. All 5 products support this.
2. **Admin Console & Audit Logging** — Required for SOC 2 compliance. All 5 provide this.
3. **Zero-Knowledge Architecture** — Vendor must not access user vault data. All 5 claim this (see concerns below).
4. **Cross-Platform Support** — macOS, Windows, Linux, iOS, Android, browsers. Dashlane lacks Linux support.
5. **Pricing Transparency** — Public per-seat pricing. Dashlane and Keeper do not list business pricing on their own sites.

### Important (Should-Have)

6. **Developer Tooling** — CLI, API, CI/CD integration. 1Password and Bitwarden lead here.
7. **Team Collaboration** — Shared vaults, role-based permissions. All 5 support this.
8. **Security Certifications** — SOC 2 Type II, ISO 27001. 1Password, Bitwarden, and Dashlane lead.
9. **Password Health / Breach Monitoring** — All 5 provide this.

### Nice-to-Have

10. **Passkey Support** — All 5 support FIDO2/WebAuthn.
11. **Self-Hosted Option** — Only Bitwarden and Keeper offer this.
12. **Free Tier** — Bitwarden has the best free tier.

---

## Recommendation: 1Password Business

### Product & Tier

- **Product:** 1Password
- **Tier:** Business (not Teams Starter Pack, which caps at 10 users)
- **Price:** $7.99 per user per month, billed annually [1]
- **Annual cost for 50 seats:** 50 × $7.99 × 12 = **$4,794/year**
- **Trial:** 14-day free trial, no credit card required [1]

### Why This Tier

The Business tier (vs. Teams Starter Pack) adds:
- **SSO integration** with Okta, Entra ID, OneLogin, Duo, and more [1]
- **Watchtower alerts** for security hygiene monitoring [1]
- **Role-based vault sharing** with granular permissions [1]
- **No user cap** (Teams Starter Pack is limited to 10 users) [1]

### Why 1Password Over Alternatives

**vs. Bitwarden ($2,400/yr):** Bitwarden is $2,394 cheaper annually and is open-source. However, 1Password offers significantly better developer tooling (SSH agent, Secrets Automation with Service Accounts, Git commit signing, SDKs), a more polished admin console, and higher user satisfaction ratings. For an engineering team where developer experience matters, 1Password's tooling justifies the premium.

**vs. LastPass ($4,200/yr):** LastPass has had **six documented security incidents** from 2011 to 2026, including a 2022 breach where encrypted vaults were stolen, and a 2026 ETH Zurich study demonstrating that its "zero-knowledge" encryption can be bypassed if the server is compromised [13]. This is unacceptable for a SaaS company handling customer data.

**vs. Dashlane ($4,800/yr):** Dashlane is the most expensive option and has had recent security vulnerabilities (2024 injection attacks, 2025 DOM-based clickjacking) [19]. Its business pricing is not transparently listed on its own website [20]. It also lacks Linux desktop support.

**vs. Keeper ($4,200/yr):** Keeper is well-priced and FIPS 140-2 validated, but has weaker developer tooling, lower user satisfaction (Trustpilot 3.6), and its website serves a cookie consent wall that blocks pricing information [24].

---

## Runner-Up: Bitwarden Teams

**Bitwarden Teams** at **$4.00/user/month** ($48/user/year) would be the primary recommendation if:

1. **Budget is the top constraint** — Bitwarden saves $2,394/year for 50 seats
2. **Open-source is a requirement** — Bitwarden is fully open-source and can be self-hosted
3. **The team is comfortable with a less polished UX** — Bitwarden's admin console and native apps are functional but less refined
4. **Developer tooling needs are basic** — Bitwarden has CLI and API access but lacks 1Password's SSH agent, Secrets Automation, and Git commit signing

Bitwarden is an excellent product and would be our recommendation for a cost-conscious team or one that prioritizes open-source software.

---

## Concerns & Risks

### 1Password-Specific Concerns

1. **Vendor lock-in:** 1Password is proprietary (not open-source). Export is supported (CSV, JSON), but re-importing into another manager may lose some metadata. Mitigation: regular exports and documented migration procedures.

2. **Price increases:** 1Password has a history of price increases. The current $7.99/user/month was previously $3.99/user/month (shown as strikethrough on their pricing page) [1]. Mitigation: annual billing locks in the rate for 12 months.

3. **No self-hosted option:** Unlike Bitwarden, 1Password cannot be self-hosted. All data resides on 1Password's infrastructure. Mitigation: 1Password's zero-knowledge architecture means they cannot access vault data, and their SOC 2 Type II and ISO 27001 certifications provide independent verification of their security practices [3].

4. **No Linux native app for Business tier:** 1Password offers a Linux desktop app, but it is a community-maintained version. The official apps are for macOS, Windows, iOS, and Android [1]. Mitigation: the browser extension works well on Linux, and the CLI tool is officially supported.

### Industry-Wide Concerns

1. **Zero-knowledge claims:** A 2026 ETH Zurich study showed that LastPass's zero-knowledge encryption could be bypassed [13]. While 1Password was not specifically targeted, this highlights the importance of independent security audits. 1Password undergoes annual SOC 2 Type II and ISO 27001 audits [3].

2. **Browser extension vulnerabilities:** A 2025 DEF CON presentation demonstrated DOM-based clickjacking vulnerabilities in multiple password manager extensions, including 1Password [13]. Mitigation: keep extensions updated and use the native apps where possible.

3. **Injection attacks:** A 2024 study showed that multiple password managers (including 1Password) are vulnerable to injection attacks that can leak metadata [13]. Mitigation: this is a class-wide vulnerability; no single product is immune.

---

## Implementation Plan (90-Day Timeline)

### Week 1-2: Evaluation & Setup
- Start 14-day free trial of 1Password Business
- Set up admin console, SSO integration with Google Workspace
- Configure security policies (minimum password length, breach monitoring)
- Create shared vaults for team resources

### Week 3-4: Pilot Group
- Onboard a pilot group of 5-10 engineers
- Gather feedback on UX, developer tooling, and admin features
- Configure CLI tool and SSH agent for developer workflow
- Test CI/CD integration (GitHub Actions, etc.)

### Week 5-8: Team Rollout
- Roll out to full 50-person team
- Provide onboarding documentation and training
- Import existing passwords from browser stores
- Disable shadow-IT password storage (Slack DMs, sticky notes)

### Week 9-12: Enforcement & Optimization
- Enforce password manager usage for all team accounts
- Configure audit logging and monitoring
- Review security posture with Watchtower alerts
- Optimize shared vault structure and permissions

---

## Sources

[1] https://1password.com/pricing/ — 1Password pricing page (fetched 2025-07-10)
[3] https://trust.1password.io/ — 1Password Trust Center (fetched 2025-07-10)
[4] https://1password.com/developers/ — 1Password Developer tools (fetched 2025-07-10)
[6] https://en.wikipedia.org/wiki/1Password — 1Password Wikipedia (fetched 2025-07-10)
[7] https://bitwarden.com/pricing/ — Bitwarden pricing page (fetched 2025-07-10)
[8] https://bitwarden.com/compliance/ — Bitwarden compliance page (fetched 2025-07-10)
[9] https://en.wikipedia.org/wiki/Bitwarden — Bitwarden Wikipedia (fetched 2025-07-10)
[10] https://www.pcmag.com/reviews/bitwarden — PCMag Bitwarden review (fetched 2025-07-10)
[13] https://en.wikipedia.org/wiki/LastPass — LastPass Wikipedia, security incidents (fetched 2025-07-10)
[14] https://www.pcmag.com/reviews/lastpass — PCMag LastPass review (fetched 2025-07-10)
[19] https://en.wikipedia.org/wiki/Dashlane — Dashlane Wikipedia, security criticism (fetched 2025-07-10)
[20] https://www.pcmag.com/reviews/dashlane — PCMag Dashlane review (fetched 2025-07-10)
[23] https://en.wikipedia.org/wiki/Keeper_Security — Keeper Wikipedia (fetched 2025-07-10)
[24] https://www.zdnet.com/article/best-password-manager/ — ZDNET comparison (fetched 2025-07-10)
