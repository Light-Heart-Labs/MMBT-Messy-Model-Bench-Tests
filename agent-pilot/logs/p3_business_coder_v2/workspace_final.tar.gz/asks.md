# Diligence Asks — Project Lighthouse (Borealis Analytics)

**Goal:** Complete these asks within 2 weeks (by 2026-04-30) to validate the deal recommendation before LOI.

---

## 1. Legal Review of Customer Contracts

- **Ask:** Review Borealis’ standard customer contracts for change-of-control clauses, termination-on-acquisition provisions, and any other contractual risks that could trigger customer attrition post-acquisition.
- **Owner:** General Counsel
- **Deadline:** 2026-04-25
- **Success Criteria:** Written confirmation that ≤10% of ARR is exposed to material change-of-control termination rights.

---

## 2. Financial Deep Dive: Revenue Recognition and Deferred Revenue

- **Ask:** Obtain a detailed breakdown of:
  - Deferred revenue balance as of 2026-03-31
  - ARR by contract term (12-month vs. 36-month)
  - Revenue recognition policy (e.g., straight-line vs. usage-based)
  - Top-10 customer ARR concentration
- **Owner:** CFO
- **Deadline:** 2026-04-25
- **Success Criteria:** Clear understanding of revenue quality and sustainability; top-10 concentration ≤30% of ARR.

---

## 3. Technical Integration Deep Dive

- **Ask:** Conduct a technical deep dive on integration complexity:
  - API compatibility between Aurora and our platform
  - Data model mapping (customer, event, and metric schemas)
  - Custom integration requirements (e.g., legacy systems)
  - Realistic 3-phase integration plan with milestones (e.g., data migration, feature parity, sunsetting)
- **Owner:** VP Eng
- **Deadline:** 2026-04-28
- **Success Criteria:** Integration plan with clear milestones, risk mitigation, and realistic timeline (no more than 6 months).

---

## 4. Customer Validation: NPS and Renewal Data

- **Ask:** Validate customer NPS and renewal data with at least 10 additional customers (including 2–3 from the bottom half of the customer base by ARR).
- **Owner:** VP Sales
- **Deadline:** 2026-04-28
- **Success Criteria:** NPS and renewal rates within 5% of pack claims; no material churn risk identified.

---

## 5. Revenue Synergy Model and Cross-Sell Analysis

- **Ask:** Provide a revenue synergy model showing:
  - Cross-sell potential to our enterprise base (e.g., % of enterprise customers likely to adopt Aurora)
  - Risk-adjusted revenue retention forecast for Borealis’ customer base (e.g., 12-month, 24-month)
  - Impact of integration timeline on synergy realization
- **Owner:** Corp Dev
- **Deadline:** 2026-04-30
- **Success Criteria:** Model with clear assumptions, sensitivity analysis, and alignment with valuation.

---

## 6. Retention Plan for Borealis Team

- **Ask:** Review Borealis’ retention plan for key employees (engineering, product, sales):
  - Retention bonuses, equity rollover, or other incentives
  - Employee contract review (non-compete, confidentiality)
- **Owner:** HR + Corp Dev
- **Deadline:** 2026-04-28
- **Success Criteria:** Formal retention plan covering ≥80% of engineering and product team.

---

## 7. Data Privacy and Compliance Review

- **Ask:** Review Borealis’ data privacy practices (GDPR, CCPA, etc.) and compliance documentation.
- **Owner:** General Counsel + Compliance
- **Deadline:** 2026-04-25
- **Success Criteria:** No material compliance gaps identified.

---

## 8. Competitive Landscape and Market Position

- **Ask:** Provide a brief assessment of Borealis’ competitive positioning:
  - Market share vs. key competitors
  - Differentiation vs. alternatives
  - Pricing power and elasticity
- **Owner:** VP Strategy
- **Deadline:** 2026-04-30
- **Success Criteria:** Clear understanding of Borealis’ market position and growth constraints.

---

## Notes

- All asks should be prioritized by risk and impact on valuation.
- Final decision on LOI should be based on completion of all high-priority asks.
- If any high-priority ask cannot be completed satisfactorily, recommend HOLD.
