# Concerns Log — Project Lighthouse (Borealis Analytics)

## High-Priority Concerns (Must be addressed before LOI)

1. **Revenue Recognition and Deferred Revenue**
   - Pack states GAAP revenue of $9.2M in FY2025, up 80% YoY, but does not disclose deferred revenue balance or revenue recognition policy.
   - Risk: Revenue could be front-loaded, inflating current-year figures while future revenue is compromised.
   - Evidence: No mention of deferred revenue, contract length breakdown, or revenue recognition policy in financials section.

2. **Customer Concentration and Churn Risk**
   - Pack mentions 280 customers but provides no top-10 or top-5 ARR concentration data.
   - Risk: If top customers represent a large share of ARR, their loss would significantly impact valuation.
   - Evidence: “Logo retention 91%” is cited, but no breakdown of churn by customer tier or ARR band.

3. **Change-of-Control Clauses in Customer Contracts**
   - No legal review of standard customer contracts is included.
   - Risk: Many SaaS contracts contain clauses allowing customers to terminate or renegotiate upon acquisition.
   - Evidence: Legal section is absent from the pack; only engineering, finance, and Corp Dev signed off.

4. **Integration Timeline and Technical Debt**
   - Pack claims 4–6 month integration with “clean” tech stack, but no deep dive into data migration, API compatibility, or custom integrations.
   - Risk: Underestimating integration complexity could delay synergy realization and increase costs.
   - Evidence: Engineering review only confirms “modern stack,” not integration feasibility.

5. **Customer Reference Call Methodology**
   - Pack cites NPS in “high 40s” from 4 quoted references out of 5 contacted.
   - Risk: Small sample size and selection bias (only willing-to-quote customers) may overstate satisfaction.
   - Evidence: No methodology for reference calls (how selected, how many contacted, response rate).

## Medium-Priority Concerns (Should be addressed before signing)

6. **Valuation Comparables Justification**
   - Comps (7x–12x ARR) are cited, but no adjustment for growth rate, profitability, or market conditions.
   - Risk: Borealis’ 92% ARR growth may not be comparable to comps’ growth at acquisition time.
   - Evidence: No growth rate or margin comparison for comps in the “Comparable transactions” section.

7. **Synergy Estimate ($3.2M Annual Cost Savings)**
   - Pack states synergy estimate without breakdown (e.g., infra consolidation, headcount overlap, licensing savings).
   - Risk: Overly optimistic synergy assumptions could lead to post-close disappointment.
   - Evidence: “Synergy estimate” section lacks supporting detail or assumptions.

8. **Retention Plan for Borealis Team**
   - Pack claims “85% retention expected” based on conversations with VP Eng, but no formal retention plan or employee contract review.
   - Risk: Key engineers or product managers may leave post-close, derailing integration.
   - Evidence: No mention of retention bonuses, equity rollover, or formal retention plan.

9. **Product Roadmap Alignment**
   - Pack highlights Borealis’ recent features (event-based segmentation, real-time pipelines, embedded dashboards) but does not assess how these align with our product strategy or whether they will be maintained post-acquisition.
   - Risk: Features may be deprioritized post-close, reducing customer value proposition.
   - Evidence: Product roadmap section focuses on Borealis’ past shipping, not future integration plan.

10. **Burn Rate and Runway Analysis**
    - Pack states 22 months runway at $750K monthly burn, but does not project post-acquisition burn (e.g., integration costs, synergy realization timeline).
    - Risk: Integration could increase burn rate, shortening runway and pressuring cash flow.
    - Evidence: Burn rate is presented as static, not dynamic.

## Low-Priority Concerns (Nice to have, but not deal-breakers)

11. **CTO Background Verification**
    - Pack praises CTO Sarah Lin’s experience at Snowflake and Looker, but no verification of tenure or role depth.
    - Risk: Overstated executive experience could impact post-close leadership stability.

12. **Competitive Landscape**
    - Pack does not discuss Borealis’ competitive positioning or market share relative to alternatives.
    - Risk: Borealis may be losing share to competitors, impacting future growth.

13. **Geographic Concentration**
    - Pack does not disclose Borealis’ customer geographic distribution.
    - Risk: Concentration in volatile regions could impact revenue stability.

14. **Sales Cycle Length**
    - Pack does not disclose Borealis’ average sales cycle or customer onboarding time.
    - Risk: Long sales cycles could delay revenue recognition post-close.

15. **Data Privacy and Compliance**
    - Pack does not address GDPR, CCPA, or other data privacy compliance risks.
    - Risk: Non-compliance could lead to fines or customer attrition.
