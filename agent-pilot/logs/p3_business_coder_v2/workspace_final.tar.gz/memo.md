**To:** Executive Committee  
**From:** [Your Name], Executive Committee Member  
**Date:** 2026-04-18  
**Subject:** Independent Review — Project Lighthouse (Borealis Analytics Acquisition)

After reviewing the diligence pack, I recommend **PROCEEDING to LOI at $84M**, but only with explicit conditions. This is a solid tuck-in acquisition with strong strategic and financial attributes, but the pack contains several overclaims and omissions that must be addressed before signing.

### Recommendation and Conditions

I support moving forward to LOI, but **not** on the current timeline or without the diligence asks outlined below. I would change my stance to **HOLD** if:
1. The customer reference calls do not corroborate the NPS and renewal data.
2. The technical review does not confirm the 4–6 month integration timeline is realistic.
3. The legal review does not uncover potential liabilities in Borealis’ customer contracts (e.g., change-of-control clauses).

### Strongest Concerns

1. **Overstated strategic fit.** The pack claims “minimal feature overlap (~12%)” but provides no evidence of how this translates to revenue synergy. There is no analysis of cross-sell potential to our existing enterprise base or risk of cannibalization. The synergy estimate of $3.2M annual cost savings is presented as fact, yet no breakdown is given.

2. **Underexplained financial metrics.** While gross margin (71%) and net retention (118%) look strong, the pack omits how Borealis’ revenue recognition policy impacts reported GAAP revenue. The 80% YoY growth in recognized revenue ($5.1M → $9.2M) is impressive, but without visibility into deferred revenue or contract terms, it’s unclear how sustainable this is. The ARR figure ($11.4M) is stated as “end of period,” but no breakdown of multi-year vs. annual contracts is provided.

3. **Customer testimonial selection bias.** The pack cites NPS in the “high 40s” from five reference calls, but only four were willing to be quoted. With such a small sample size, the NPS could be skewed. There is no mention of churn risk among Borealis’ 280 customers or any analysis of customer concentration (top-10 customer % of ARR is missing).

4. **Valuation context is incomplete.** The comps (7x–12x ARR) are cited, but no adjustment is made for differences in growth profile, profitability, or market conditions. Borealis’ 92% ARR growth is impressive, but the pack does not compare this to the comps’ growth at acquisition time.

5. **Integration risk is downplayed.** The “85% retention expected” is based on “conversations with their VP Eng,” not a formal retention plan or employee contract review. The 4–6 month integration timeline assumes no major technical hurdles, yet no deep dive into data migration complexity or API compatibility is included.

### Diligence Asks for Next 2 Weeks

1. **Legal:** Review Borealis’ standard customer contracts for change-of-control clauses and termination-on-acquisition provisions. *Owner: General Counsel. Deadline: 2026-04-25.*

2. **Finance:** Obtain a detailed breakdown of ARR by contract term (12-month vs. 36-month), deferred revenue balance, and revenue recognition policy. *Owner: CFO. Deadline: 2026-04-25.*

3. **Product/Eng:** Conduct a technical deep dive on integration complexity: API compatibility, data model mapping, and a realistic 3-phase integration plan with milestones. *Owner: VP Eng. Deadline: 2026-04-28.*

4. **Sales:** Validate customer NPS and renewal data with at least 10 additional customers (including 2–3 from the bottom half of the customer base by ARR). *Owner: VP Sales. Deadline: 2026-04-28.*

5. **Strategy:** Provide a revenue synergy model showing cross-sell to our enterprise base and a risk-adjusted revenue retention forecast for Borealis’ customer base. *Owner: Corp Dev. Deadline: 2026-04-30.*

### Conclusion

This deal has merit, but the pack reads like an advocacy document, not an independent analysis. With the above diligence completed, I believe the risk-adjusted IRR and strategic upside justify proceeding. Without it, we risk overpaying for integration complexity and hidden contractual liabilities.
