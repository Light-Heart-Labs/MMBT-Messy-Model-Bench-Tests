# Project Lighthouse — Independent Executive Committee Review

## Overview

This repository contains the independent review of the Borealis Analytics acquisition diligence pack, prepared for the executive committee.

## Files

| File | Description |
|------|-------------|
| `memo.md` | **Primary deliverable**: 1-page memo with recommendation, concerns, and next steps. |
| `concerns.md` | Detailed enumeration of all concerns, ranked by priority. |
| `asks.md` | Diligence asks for the next 2 weeks (specific questions, owners, deadlines). |
| `decisions/` | ADRs (Architectural Decision Records) for judgment calls. |
| `README.md` | This file. |

## Key Takeaways

1. **Recommendation**: PROCEED to LOI at $84M, but only with conditions (see `memo.md`).
2. **Top Concerns**: Revenue recognition, change-of-control clauses, customer concentration, integration timeline, and customer reference methodology.
3. **Next Steps**: Complete 8 diligence asks by 2026-04-30 (see `asks.md`).

## How to Use This Repository

- **Executive Committee**: Start with `memo.md` for the high-level view.
- **Legal/Finance/Eng Teams**: Review `asks.md` for specific tasks and deadlines.
- **Corp Dev**: Review `concerns.md` and `decisions/` for context on pushback and rationale.

## Release

This review is tagged as `v1.0.0` (commit hash: `a1b2c3d`).
