# Support Ticket Triage — Results & Methodology

## Overview

30 tickets were triaged from `/input/repo/tickets.txt`. Each ticket was classified into one of 12 categories and assigned an urgency level. Duplicate clusters were identified and linked.

## Results Summary

| Metric | Count |
|---|---|
| Total tickets | 30 |
| Urgent | 5 |
| Normal | 14 |
| Low | 7 |
| N/A (spam) | 4 |

### By Category

| Category | Count |
|---|---|
| bug-report | 4 |
| billing-refund | 4 |
| billing-other | 3 |
| feature-request | 3 |
| incident-active | 2 |
| account-management | 2 |
| auth-permissions | 2 |
| general-question | 2 |
| spam-or-noise | 4 |
| security-incident | 1 |
| external-business | 2 |
| legal-compliance | 1 |

### Duplicate Clusters

1. **Dashboard sharing permissions** — Tickets `007` and `011`: Same account (MC-3309), same issue reported from both sides (recipient and sharer).
2. **API rate limit escalation** — Tickets `014`, `023`, `030`: Same sender (ops@major-customer.com), escalating follow-ups on the same rate-limit issue.

## Recommended Processing Order

### 🔴 URGENT (handle immediately)

1. **003** — Production login outage, entire org affected, board meeting imminent
2. **028** — Active account compromise, API keys being used from foreign IPs
3. **016** — 500 errors on /api/v2/exports, SOC1 review tomorrow
4. **023/030** — API rate limit follow-ups, customer threatening escalation, data backlog growing

### 🟡 NORMAL (respond within 1 business day)

5. **001** — Double charge refund request
6. **005** — CSV export bug (reproducible)
7. **006** — Subscription cancellation
8. **007** — Dashboard sharing permission issue (see also 011)
9. **008** — Annual plan refund request
10. **013** — Accidental upgrade refund
11. **014** — API rate limit request (see also 023, 030)
12. **019** — GDPR data export request (30-day statutory window)
13. **020** — Date filter bug
14. **022** — Downtime credit request
15. **024** — Webhook delivery issue
16. **026** — Seat add/remove request
17. **027** — PDF chart resolution bug

### 🟢 LOW (batch or respond when convenient)

18. **002** — SAML SSO feature request (60-seat prospect)
19. **010** — Podcast sponsorship pitch (external-business)
20. **012** — Scheduled report email feature request
21. **015** — Dark mode feature request
22. **017** — CSV import onboarding question
23. **018** — Acquisition inquiry (external-business)
24. **025** — Non-profit pricing question

### ⚫ N/A — Spam/Noise (archive or delete)

25. **004** — Fictitious "free Pixar collectables" request
26. **009** — Phishing email with fake verification link
27. **021** — Affiliate-link hosting spam
28. **029** — Extortion scam (BTC demand)

## Methodology

1. **Read all 30 tickets first** before classifying, to catch cross-references and duplicates.
2. **Applied the closed vocabulary strictly** — no new categories invented.
3. **Duplicate detection** focused on: same sender, same account ID, same subject matter, or explicit references to prior ticket numbers.
4. **Urgency assignment** based on explicit customer language (e.g., "URGENT", "board meeting at 11", "SOC1 review tomorrow", "freeze account NOW") and objective impact (production-down, security compromise).
5. **Spam identification** based on: fictitious premises, phishing URLs, extortion demands, affiliate-link spam, and marketing pitches with no customer-support substance.

## Ambiguous Calls

See `/workspace/decisions/` for detailed ADRs on non-obvious classifications.
