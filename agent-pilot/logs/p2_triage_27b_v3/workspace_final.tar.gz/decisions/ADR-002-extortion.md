# ADR-002: TICKET 029 — Extortion Scam Classification

## Decision
Classified as `spam-or-noise` rather than `security-incident`.

## Context
Ticket 029 from hacker@blackhat-forum.example demands $50,000 in BTC or the sender will "post bugs on twitter."

## Rationale
- This is a classic extortion scam, not a legitimate security disclosure.
- Legitimate vulnerability disclosures do not demand payment; they follow responsible disclosure processes.
- The sender domain (blackhat-forum.example), BTC demand, and 48-hour deadline are hallmarks of scam emails.
- No actual vulnerability details are provided — just a vague claim of "3 vulns."

## Action
- Archive/delete the ticket.
- Block the sender domain.
- Do NOT engage or pay.
- If the sender actually posts vulnerabilities, handle as a separate security incident at that point.

## Alternatives Considered
- `security-incident`: Rejected — this is extortion, not a genuine security report. Treating it as a real security incident would waste triage resources.
