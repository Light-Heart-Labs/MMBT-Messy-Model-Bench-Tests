# ADR-003: TICKET 007/011 — Dashboard Sharing Duplicate Cluster

## Decision
Ticket 011 is a duplicate of ticket 007. Both classified as `auth-permissions`.

## Context
- Ticket 007: jordan.lee@mid-co.com reports they can't see dashboards shared by alex.petrov@mid-co.com.
- Ticket 011: alex.petrov@mid-co.com reports the same issue from the sharer's perspective.
- Same account (MC-3309), same three dashboards, same "permission denied" error.

## Rationale
- These are two sides of the same underlying issue: a bug or misconfiguration in the dashboard sharing/permissions system.
- Ticket 007 was filed first (lower ticket number), so it is the "original" and 011 is the duplicate.
- Both are `auth-permissions` because the core issue is about sharing and permission enforcement, not a general bug.

## Action
- Consolidate into a single investigation.
- Respond to 011 acknowledging it's a duplicate of 007 and that the team is already investigating.
