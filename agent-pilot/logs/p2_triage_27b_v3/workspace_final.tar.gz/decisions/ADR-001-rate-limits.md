# ADR-001: TICKET 014/023/030 — API Rate Limits Classification

## Decision
Classified as `billing-other` rather than `bug-report` or `incident-active`.

## Context
The customer (ops@major-customer.com) is hitting the documented 600 req/min rate limit on their Business plan. They are requesting a higher limit or burst allowance, referencing their $48k/yr contract.

## Rationale
- This is not a bug — the rate limiter is working as documented.
- This is not an active incident — the customer is requesting a contract modification, not reporting a system failure.
- The closest fit is `billing-other` because the request involves contract terms, plan limits, and potentially a plan upgrade.
- The follow-ups (023, 030) are marked `urgent` because the customer explicitly references an upcoming quarterly review deadline and a growing data backlog (~200 GB/day).

## Alternatives Considered
- `bug-report`: Rejected — the rate limiter is functioning as designed.
- `incident-active`: Rejected — the system is behaving as documented; the customer needs a contract change, not a system fix.
