# ADR: Executive Brief Framing for Nimbus Logistics

## Decision: Recommend **Pass on Follow-on Investment** (with clear conditions for reconsideration)

### Rationale

The company presents a compelling press-release narrative but the supporting evidence from multiple independent sources reveals significant operational challenges that undermine the growth story. The investor should pass on a follow-on investment at the current valuation unless specific conditions are met.

### Key Framing Choices

1. **Stance**: Clear "Pass" recommendation, not "more diligence needed"
   - Why: The data is sufficient to form a strong opinion. The tensions between sources are clear and material.
   - Alternative considered: "More diligence needed" would be appropriate if sources were contradictory or insufficient, but here multiple sources corroborate key concerns.

2. **Structure**: Lead with recommendation, then facts, then caveats
   - Why: Partner has 5 minutes. They need the conclusion first.
   - Alternative considered: Narrative chronology (funding → growth → challenges) would bury the lede.

3. **Tone**: Calibrated but direct
   - Why: The leaked memo and blog post are real but not perfectly authoritative. Use "according to" language.
   - Alternative considered: Stronger language like "the company lied" would be inaccurate; the press release is optimistic but not necessarily false.

4. **Valuation Treatment**: Focus on repricing signal
   - Why: The $720M → $560M repricing is a concrete data point that tells the story better than abstract arguments.
   - Alternative considered: Attempting to calculate exact fair valuation would require invented assumptions.

5. **ARR Treatment**: Use adjusted run-rate ($36-37M) as primary figure
   - Why: TechCrunch and internal memo context suggest the $42M figure includes non-renewed contracts.
   - Alternative considered: Presenting both figures without clear guidance would confuse the reader.

6. **Caveat Structure**: List specific conditions for reconsideration
   - Why: "Pass" is not forever. The investor should know what would change the recommendation.
   - Alternative considered: Vague caveats like "if things improve" are not actionable.

### What Would Change the Recommendation

1. **Net Retention <100% for two consecutive quarters**: Would confirm the churn problem is structural, not temporary.
2. **Failure to hit cash-flow breakeven by Q4 2026**: Would indicate the restructuring plan is not working.
3. **Additional major customer losses**: Would confirm the concentration risk is material.
4. **Credit facility terms reveal onerous covenants**: Would indicate the "insurance" is actually a lifeline with strings attached.

### What Would Strengthen the Recommendation

1. **New customers from tech stack integrations**: Would confirm product-market fit beyond sales effort.
2. **Positive signals from existing customers**: Would counterbalance the churn narrative.
3. **Leadership team changes**: Would indicate the company is taking operational issues seriously.
