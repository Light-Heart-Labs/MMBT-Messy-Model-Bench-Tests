# Working Notes — Nimbus Logistics, Inc. Source Review

## Key Facts Extracted

### Valuation & Funding
- Series B closed $84M at $560M post-money (press release) [S1]
- Total funding to date: $128M [S1]
- SEC filing confirms $84M raised, 7 investors, preferred equity [S5]
- TechCrunch reports Series B was initially intended to close at $720M valuation but was repriced down after Sundry non-renewal in early December [S2]
- Internal memo mentions $50M credit facility secured (described as "insurance, not operating capital") [S4]

### Financial Metrics
- Reported ARR: $42M as of Q4 2025 [S1]
- ARR one year prior: $11M [S1]
- TechCrunch: Adjusted for December churn, current run-rate is $36-37M [S2]
- Former employee: Company spending ~$4M/month all-in (mid-2025), revenue ~$3.5M/month [S3]
- Internal memo: Path to cash-flow breakeven by Q4 2026 [S4]

### Customer Base & Churn
- Reported customers: >1,400 e-commerce brands [S1]
- TechCrunch: Lost two top-5 customers in late 2025 — Sundry ($4.2M ARR, non-renewed Nov) and Klatch (fast-fashion, Dec) [S2]
- Former employee: Top 5 customers = ~38% of ARR [S3]
- Internal memo: "Nimbus Lite" tier (~310 customers, $5K-$20K ARR) to be sunset with 90-day notice [S4]
- CEO claims net retention >110% and three new $1M+ ARR contracts signed in Q1 [S2]

### Operations & Headcount
- 187 employees across Oakland, Austin, Berlin [S1]
- Former employee: 22 people (~11% of org) quietly laid off in Feb 2025, mostly in customer success and BD [S3]
- Internal memo: 30% reduction in international headcount, Berlin from 41 to ~28-30 by end of Q2 [S4]
- Berlin office to be reframed as "support hub" instead of sales/expansion [S4]
- Internal memo: International expansion deferred to 2027 at earliest [S4]

### Leadership & Culture
- Founders: Mira Patel (CEO) and Daniel Wong (CTO) [S1]
- Former employee: Engineering culture strong, CTO is "the real deal", compensation competitive ($215K base + $50K equity for senior engineers) [S3]
- Former employee: High burn, path to survival requires faster growth or significant cuts [S3]
- Former employee: Would recommend to senior talent but not to those needing job security in next 18 months [S3]

### Strategic Direction
- Platform: cloud-native logistics for mid-market e-commerce, includes warehouse mgmt, carrier orchestration, demand forecasting [S1]
- Original plan: international expansion and AI-driven inventory optimization [S1]
- Revised plan: pause international, focus on U.S. mid-market, sunset lowest tier, secure runway to cash-flow breakeven [S4]

## Tensions & Contradictions

1. **Valuation vs. Reality**: Press release touts $560M valuation; TechCrunch reports repricing from $720M after customer loss [S1 vs S2]
2. **ARR Figure**: Company reports $42M ARR; TechCrunch and former employee suggest adjusted run-rate is $36-37M after December churn [S1 vs S2 vs S3]
3. **Growth Narrative**: Press release emphasizes growth and expansion; internal memo reveals layoffs, customer churn, and retreat from international [S1 vs S3 vs S4]
4. **Customer Concentration**: Company presents broad base (>1,400 customers); internal memo and TechCrunch highlight concentration risk (top 5 = 38%, two top-5 losses) [S1 vs S2 vs S3]
5. **Runway & Strategy**: Press release suggests aggressive expansion; internal memo reveals restructuring to extend runway to 36+ months and defer international [S1 vs S4]

## Source Quality Assessment

- **S1 (Press Release)**: Company's official narrative. High-level, optimistic, omits challenges. Good for official facts (funding, valuation, ARR), but needs cross-checking.
- **S2 (TechCrunch)**: Journalistic reporting with multiple sources. Provides context, challenges company narrative, includes internal data (adjusted ARR, repricing). Strong secondary source.
- **S3 (Former Employee Blog)**: First-hand operational perspective. Confirms technical strengths, reveals internal challenges (burn, layoffs, churn). Subject to individual experience but likely accurate on operational details.
- **S4 (Leaked Memo)**: Internal strategy document. Most candid about challenges and plans. High reliability for strategic intent and operational plans.
- **S5 (SEC Filing)**: Official regulatory filing. Confirms funding amount and structure. Low detail but high reliability for factual confirmation.

## Key Questions for Investor

1. Is the $42M ARR figure inflated by non-renewed contracts? Adjusted run-rate appears $36-37M.
2. Can the company achieve net retention >110% with top-5 concentration and recent churn?
3. Is the $50M credit facility sufficient given the $4M/month burn rate?
4. Will the restructuring (layoffs, tier sunsetting) stabilize operations or further damage customer trust?
5. Is the $560M valuation justified given the repricing signal and operational challenges?

## Recommendation Framework

The investor must decide whether to make a follow-on investment. Key considerations:

- **Bull Case**: Strong engineering, real customer love, path to cash-flow breakeven, $50M credit facility extends runway significantly.
- **Bear Case**: Customer concentration, recent churn, high burn, repriced round, international retreat signals strategic failure.
- **Middle Ground**: Company is in trouble but restructuring could work. Valuation may need to be lower for follow-on.
