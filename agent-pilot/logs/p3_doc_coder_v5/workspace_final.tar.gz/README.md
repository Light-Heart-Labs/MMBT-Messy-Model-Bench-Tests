# Nimbus Logistics, Inc. — Deal Evaluation Package

## Overview

This package contains an executive brief and supporting analysis for evaluating a follow-on investment in Nimbus Logistics, Inc., a Series-B logistics-tech startup.

## Files

- **`brief.md`** — The 1-page executive brief (698 words). This is the primary deliverable for the investor partner.
- **`key-facts.md`** — A list of every material fact incorporated into the brief, with source attribution.
- **`research/notes.md`** — Working notes from reading the five source documents.
- **`decisions/adr.md`** — ADR-style records for framing choices (e.g., why "Pass" recommendation).
- **`README.md`** — This file.

## How to Read This Output

1. **Start with `brief.md`** — This is the deliverable. It leads with a clear recommendation, summarizes key facts, and provides analysis.
2. **Check `key-facts.md`** — Verify that every metric in the brief is sourced to one of the five documents.
3. **Review `research/notes.md`** — See how the analysis was built from the sources.
4. **Read `decisions/adr.md`** — Understand the framing choices (e.g., why "Pass" instead of "More diligence needed").

## Source Documents

The analysis is based on five public documents about Nimbus Logistics:

1. **Press Release** (company-issued) — Official narrative
2. **TechCrunch Article** — Journalistic reporting with multiple sources
3. **Former Employee Blog Post** — First-hand operational perspective
4. **Leaked Internal Memo** — Internal strategy document
5. **SEC Form D Filing** — Official regulatory filing

## Recommendation

**PASS on follow-on investment at current valuation**  
**Reconsider if:** Net retention falls below 100% for two consecutive quarters, or cash-flow breakeven is missed by Q4 2026.

## Key Tensions

- **Valuation**: $560M claimed vs. $720M repricing signal
- **ARR**: $42M claimed vs. $36-37M adjusted run-rate
- **Growth**: International expansion claimed vs. deferral to 2027 in internal memo
- **Customer Base**: >1,400 customers claimed vs. top-5 = 38% concentration

## Source Quality

- **Press Release**: Company's official narrative. Good for facts, needs cross-checking.
- **TechCrunch**: Journalistic reporting. Strong secondary source.
- **Former Employee Blog**: First-hand operational perspective. Likely accurate on details.
- **Leaked Memo**: Internal strategy. High reliability for strategic intent.
- **SEC Filing**: Official regulatory. Low detail but high reliability.
