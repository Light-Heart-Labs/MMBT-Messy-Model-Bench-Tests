# Key Facts — Nimbus Logistics, Inc.

## Valuation & Funding

- Series B closed $84M at $560M post-money valuation [S1]
- Total funding to date: $128M [S1]
- SEC filing confirms $84M raised, 7 investors, preferred equity [S5]
- Series B was initially intended to close at $720M valuation but repriced down after Sundry non-renewal in early December [S2]
- $50M credit facility secured from Silicon Valley Bridge (described as "insurance, not operating capital") [S4]

## Financial Metrics

- Reported ARR: $42M as of Q4 2025 [S1]
- ARR one year prior: $11M [S1]
- Adjusted for December churn, current run-rate is $36-37M [S2]
- Company spending ~$4M/month all-in (mid-2025), revenue ~$3.5M/month [S3]
- Path to cash-flow breakeven by Q4 2026 [S4]

## Customer Base & Churn

- Reported customers: >1,400 e-commerce brands [S1]
- Lost two top-5 customers in late 2025 — Sundry ($4.2M ARR, non-renewed Nov) and Klatch (fast-fashion, Dec) [S2]
- Top 5 customers = ~38% of ARR [S3]
- "Nimbus Lite" tier (~310 customers, $5K-$20K ARR) to be sunset with 90-day notice [S4]
- CEO claims net retention >110% and three new $1M+ ARR contracts signed in Q1 [S2]

## Operations & Headcount

- 187 employees across Oakland, Austin, Berlin [S1]
- 22 people (~11% of org) quietly laid off in Feb 2025, mostly in customer success and BD [S3]
- 30% reduction in international headcount, Berlin from 41 to ~28-30 by end of Q2 [S4]
- Berlin office to be reframed as "support hub" instead of sales/expansion [S4]
- International expansion deferred to 2027 at earliest [S4]

## Leadership & Culture

- Founders: Mira Patel (CEO) and Daniel Wong (CTO) [S1]
- Engineering culture strong, CTO is "the real deal", compensation competitive ($215K base + $50K equity for senior engineers) [S3]
- High burn, path to survival requires faster growth or significant cuts [S3]
- Would recommend to senior talent but not to those needing job security in next 18 months [S3]

## Strategic Direction

- Platform: cloud-native logistics for mid-market e-commerce, includes warehouse mgmt, carrier orchestration, demand forecasting [S1]
- Original plan: international expansion and AI-driven inventory optimization [S1]
- Revised plan: pause international, focus on U.S. mid-market, sunset lowest tier, secure runway to cash-flow breakeven [S4]

## Source Attribution

- [S1] Press Release (company-issued), 2026-01-14
- [S2] TechCrunch News Article, 2026-01-15
- [S3] Personal Blog Post (former employee), 2026-02-22
- [S4] Internal Memo (leaked to The Information), 2026-03-05
- [S5] SEC Filing Summary (Form D), 2026-01-22
