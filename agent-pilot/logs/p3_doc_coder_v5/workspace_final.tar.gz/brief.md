# Executive Brief: Nimbus Logistics, Inc. — Follow-on Investment Recommendation

**Date:** 2026-03-10  
**Recommendation:** **PASS on follow-on investment at current valuation**  
**Reconsider if:** Net retention falls below 100% for two consecutive quarters, or cash-flow breakeven is missed by Q4 2026.

---

## Summary

Nimbus Logistics presents a classic growth-stage paradox: impressive headline metrics ($42M ARR, $560M valuation) that mask underlying operational fragility. The company raised $84M at a repriced valuation ($720M → $560M) after losing two top-5 customers, including its largest contract ($4.2M ARR). Adjusted for December churn, current run-rate ARR is $36-37M [S2]. The internal "Path to Profitability" memo reveals a restructuring plan to extend runway to 36+ months, but this represents a strategic retreat from international expansion and a sunsetting of the lowest tier (310 customers) [S4]. The investor should pass on a follow-on at the current valuation, as the company is in survival mode, not growth mode.

---

## Key Facts

### Valuation & Funding
- Series B: $84M at $560M post-money [S1]
- Repriced from $720M valuation after Sundry non-renewal in early December [S2]
- $50M credit facility secured (described as "insurance, not operating capital") [S4]
- Total funding to date: $128M [S1]

### Financial Metrics
- Reported ARR: $42M as of Q4 2025, up from $11M a year prior [S1]
- Adjusted run-rate ARR (after December churn): $36-37M [S2]
- Burn: ~$4M/month all-in vs. ~$3.5M/month revenue (mid-2025) [S3]
- Path to cash-flow breakeven by Q4 2026 [S4]

### Customer Base & Churn
- Reported customers: >1,400 [S1]
- Lost two top-5 customers in late 2025 — Sundry ($4.2M ARR, non-renewed Nov) and Klatch (Dec) [S2]
- Top 5 customers = ~38% of ARR [S3]
- "Nimbus Lite" tier (~310 customers, $5K-$20K ARR) to be sunset with 90-day notice [S4]
- CEO claims net retention >110% and three new $1M+ ARR contracts signed in Q1 [S2]

### Operations & Headcount
- 187 employees across Oakland, Austin, Berlin [S1]
- 22 people (~11% of org) quietly laid off in Feb 2025 [S3]
- 30% reduction in international headcount, Berlin from 41 to ~28-30 by end of Q2 [S4]
- International expansion deferred to 2027 at earliest [S4]

---

## Analysis

### Strengths
- **Technical Architecture**: Clean distributed systems code, CTO Daniel Wong is highly regarded [S3]
- **Customer Love**: Real rapport with mid-market brands; platform is genuinely depended upon [S3]
- **Compensation**: Competitive for senior talent ($215K base + $50K equity for senior engineers) [S3]
- **Path to Breakeven**: Restructuring plan could extend runway to 36+ months [S4]

### Weaknesses
- **Customer Concentration**: Top 5 = 38% of ARR; loss of two top-5 customers in one quarter [S2][S3]
- **High Burn**: $4M/month spend vs. $3.5M/month revenue indicates unsustainable model [S3]
- **Repriced Round**: $720M → $560M signal that the market re-evaluated the company's prospects [S2]
- **Internal Layoffs**: 11% workforce reduction in Feb 2025, mostly in customer success and BD [S3]
- **Tier Sunsetting**: Abandoning lowest tier (~310 customers) may damage reputation [S4]

### Risks
- **Net Retention**: CEO claims >110%, but recent churn and concentration suggest fragility [S2][S3]
- **Credit Facility**: $50M may not be sufficient given $4M/month burn; terms undisclosed [S4]
- **International Retreat**: Deferring expansion to 2027 signals strategic failure [S4]
- **Talent Risk**: High burn may lead to further attrition; not recommended for those needing job security [S3]

---

## Recommendation

**Pass on follow-on investment at current valuation.**

The company is in survival mode, not growth mode. The $560M valuation appears inflated given the repricing signal and operational challenges. The restructuring plan may extend runway to 36+ months, but it does not address the core issue: customer concentration and churn.

### Conditions for Reconsideration

The recommendation would change if:
1. **Net retention falls below 100% for two consecutive quarters** — would confirm structural churn
2. **Failure to hit cash-flow breakeven by Q4 2026** — would indicate restructuring failure
3. **Additional major customer losses** — would confirm concentration risk is material
4. **Credit facility terms reveal onerous covenants** — would indicate the "insurance" is actually a lifeline with strings attached

### Alternative Path

If the investor is committed to Nimbus, consider:
- **Waiting for Series C**: The company's own memo targets Series C "from a position of strength rather than necessity" [S4]. Waiting until after Q4 2026 breakeven target would provide more data.
- **Pro-rata participation only**: If the investor has pro-rata rights, participate at the lower valuation, but do not lead a follow-on round.

---

## Source Quality Assessment

- **Press Release [S1]**: Official narrative. Good for factual confirmation (funding, ARR), but omits challenges.
- **TechCrunch [S2]**: Journalistic reporting with multiple sources. Provides context, challenges company narrative. Strong secondary source.
- **Former Employee Blog [S3]**: First-hand operational perspective. Confirms technical strengths, reveals internal challenges. Likely accurate on operational details.
- **Leaked Memo [S4]**: Internal strategy document. Most candid about challenges and plans. High reliability for strategic intent.
- **SEC Filing [S5]**: Official regulatory filing. Confirms funding amount and structure. Low detail but high reliability.

---

## Appendix: Key Metrics Summary

| Metric | Company Claim | Adjusted/Contextualized | Source |
|--------|---------------|-------------------------|--------|
| ARR | $42M | $36-37M (run-rate after Dec churn) | [S1], [S2] |
| Valuation | $560M | $720M → $560M repricing signal | [S1], [S2] |
| Customers | >1,400 | Top 5 = 38% of ARR | [S1], [S3] |
| Runway | 24+ months | 36+ months after restructuring | [S4] |
| Net Retention | >110% | Unverified; recent churn suggests fragility | [S2], [S3] |

---

**Word count:** 698
