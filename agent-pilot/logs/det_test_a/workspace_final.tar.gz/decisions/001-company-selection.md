# ADR-001: Company Selection

## Decision

Selected SoundHound AI, Inc. (NASDAQ: SOUN) for investment analysis.

## Context

Need a publicly traded US company with market cap between $1B and $10B that has:
- Sufficient public data (SEC filings, earnings calls)
- Interesting investment dynamics (growth story, clear competitive landscape)
- Active sell-side coverage for comparison

## Alternatives Considered

1. **C3.ai (AI)** - $1.26B. Too small, limited analyst coverage, highly speculative.
2. **CRISPR Therapeutics (CRSP)** - $4.70B. Biotech - requires deep domain expertise, binary outcomes.
3. **Celsius Holdings (CELH)** - $8.89B. Consumer CPG - interesting but less data-rich for AI analysis.
4. **Hims & Hers (HIMS)** - $6.97B. Telehealth - interesting but regulatory complexity.
5. **SentinelOne (S)** - $4.85B. Cybersecurity - crowded space, many competitors.
6. **Elastic (ESTC)** - $4.80B. Data infrastructure - solid but less dynamic.
7. **GitLab (GTLB)** - $3.66B. DevOps - interesting but competitive.
8. **Bill.com (BILL)** - $3.68B. Fintech - mature, less growth story.
9. **SoundHound AI (SOUN)** - $3.49B. Voice AI platform - clear business model, growing market, recent profitability inflection, active analyst coverage.

## Rationale

SoundHound AI was selected because:
- **Clear business model**: Voice AI platform with enterprise and consumer applications
- **Growth trajectory**: Revenue growing rapidly, approaching profitability
- **Market timing**: AI is a hot sector with clear tailwinds
- **Data availability**: Regular SEC filings, earnings calls, analyst coverage
- **Interesting dynamics**: Small-cap AI company with real revenue (not just hype)
- **Sell-side coverage**: Multiple analyst reports to compare against

## Consequences

- Analysis will focus on AI/voice technology sector
- Competitors will include both AI platform companies and voice-specific players
- Valuation will use growth company multiples (revenue-based primarily)
