# Investment Memo: SoundHound AI (SOUN)

## Repository Structure

This repository contains a complete investment analysis of SoundHound AI, Inc. (NASDAQ: SOUN).

### How to Read This Repo

1. **Start here** (`README.md`) - Overview of the analysis
2. **`/decisions/`** - Decision records explaining key analytical choices (read in numerical order)
3. **`/research/notes/`** - Working notes from research sessions (chronological)
4. **`/research/questions.md`** - Questions encountered and how they were resolved
5. **`/research/dead-ends.md`** - Investigated paths that didn't pan out
6. **`/raw/`** - Primary source documents (SEC filings, transcripts, press releases)
7. **`/extracted/`** - Parsed data from raw sources, with extraction scripts
8. **`/model/`** - Three-statement financial model (Excel)
9. **`/analysis/`** - Notebooks and scripts for quantitative analysis
10. **`/memo/`** - Final investment memo (PDF + source markdown)
11. **`/sources.md`** - Complete bibliography with URLs, timestamps, and content hashes
12. **`/tool-log.md`** - Log of all tool calls with justifications

### Traceability

Every number in the memo is traceable:
- Memo claim → Model cell → Extracted data → Raw filing → Source URL

### Company

**SoundHound AI, Inc. (NASDAQ: SOUN)**
- Sector: Technology / AI Software
- Market Cap: ~$2-4B (as of analysis date)
- Business: Voice AI platform for enterprise and consumer applications

### Analysis Date

Analysis conducted: 2025

---

*This analysis is for educational purposes only and does not constitute investment advice.*
