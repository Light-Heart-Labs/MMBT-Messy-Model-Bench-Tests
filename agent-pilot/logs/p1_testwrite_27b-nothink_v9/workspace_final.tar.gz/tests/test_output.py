"""Tests for output formatters: JSON, CSV, plain text, and render_aggregate.

Targets 0% coverage on output.py — tests happy paths, empty inputs,
special characters in URLs, and error paths for render_aggregate.
"""
from __future__ import annotations

from datetime import datetime, timezone

import pytest

from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to build LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── to_json ──────────────────────────────────────────────────────────────────


def test_to_json_empty_list():
    """Empty entry list should produce a valid empty JSON array."""
    assert to_json([]) == "[]"


def test_to_json_single_entry():
    """Single entry should produce a one-element JSON array."""
    entries = [_entry(ip="192.168.1.1", url="/index.html", status=200, bytes=512)]
    result = to_json(entries)
    assert result.startswith("[")
    assert result.endswith("]")
    assert '"ip":"192.168.1.1"' in result
    assert '"url":"/index.html"' in result
    assert '"status":200' in result
    assert '"bytes":512' in result


def test_to_json_multiple_entries():
    """Multiple entries should be comma-separated within the JSON array."""
    entries = [_entry(url="/a"), _entry(url="/b")]
    result = to_json(entries)
    assert '"url":"/a"' in result
    assert '"url":"/b"' in result
    # Two entries means one comma between them
    assert result.count('"url"') == 2


def test_to_json_url_with_special_characters():
    """URLs with query strings and special chars should be included as-is."""
    entry = _entry(url="/search?q=hello+world&lang=en")
    result = to_json([entry])
    assert "/search?q=hello+world&lang=en" in result


def test_to_json_user_with_special_characters():
    """User field with special characters should be included as-is."""
    entry = _entry(user="john.doe@example.com")
    result = to_json([entry])
    assert '"user":"john.doe@example.com"' in result


def test_to_json_zero_bytes():
    """Entries with zero bytes should render correctly."""
    entry = _entry(bytes=0)
    result = to_json([entry])
    assert '"bytes":0' in result


def test_to_json_large_bytes():
    """Large byte values should render correctly."""
    entry = _entry(bytes=999999999)
    result = to_json([entry])
    assert '"bytes":999999999' in result


def test_to_json_various_status_codes():
    """Various HTTP status codes should render correctly."""
    entries = [_entry(status=200), _entry(status=404), _entry(status=500)]
    result = to_json(entries)
    assert '"status":200' in result
    assert '"status":404' in result
    assert '"status":500' in result


# ── to_csv ───────────────────────────────────────────────────────────────────


def test_to_csv_empty_list():
    """Empty entry list should produce CSV with only the header row."""
    result = to_csv([])
    lines = result.strip().split("\n")
    assert len(lines) == 1
    assert "ip,user,timestamp,method,url,protocol,status,bytes" in lines[0]


def test_to_csv_single_entry():
    """Single entry should produce header + one data row."""
    entries = [_entry(ip="10.0.0.1", url="/test", status=200, bytes=500)]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 2
    assert "10.0.0.1" in lines[1]
    assert "/test" in lines[1]


def test_to_csv_multiple_entries():
    """Multiple entries should each get their own row."""
    entries = [_entry(url="/a"), _entry(url="/b"), _entry(url="/c")]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 4  # header + 3 data rows


def test_to_csv_url_with_commas():
    """URLs containing commas should be properly quoted by csv.writer."""
    entry = _entry(url="/path?a=1,b=2")
    result = to_csv([entry])
    # csv.writer should quote fields containing commas
    assert "a=1,b=2" in result


def test_to_csv_preserves_timestamp_format():
    """Timestamps should be rendered in ISO format."""
    entry = _entry(timestamp=datetime(2026, 6, 15, 8, 30, 0, tzinfo=timezone.utc))
    result = to_csv([entry])
    assert "2026-06-15T08:30:00" in result


# ── to_text ──────────────────────────────────────────────────────────────────


def test_to_text_empty_list():
    """Empty entry list should produce an empty string."""
    assert to_text([]) == ""


def test_to_text_single_entry():
    """Single entry should produce one line of formatted text."""
    entries = [_entry(ip="10.0.0.1", method="GET", status=200, url="/home")]
    result = to_text(entries)
    assert "10.0.0.1" in result
    assert "GET" in result
    assert "200" in result
    assert "/home" in result


def test_to_text_multiple_entries_separated_by_newlines():
    """Multiple entries should be separated by newlines."""
    entries = [_entry(url="/a"), _entry(url="/b")]
    result = to_text(entries)
    assert "\n" in result
    assert result.count("\n") == 1


def test_to_text_ip_alignment():
    """IP addresses should be right-aligned in a 15-char field."""
    short_ip = _entry(ip="1.2.3.4")
    long_ip = _entry(ip="192.168.1.100")
    result = to_text([short_ip, long_ip])
    lines = result.split("\n")
    # Both lines should have the method at roughly the same position
    # (IP field is 15 chars wide, right-aligned)
    assert "  1.2.3.4" in lines[0]  # padded
    assert "192.168.1.100" in lines[1]


def test_to_text_method_alignment():
    """Method field should be left-aligned in a 6-char field."""
    entries = [_entry(method="GET"), _entry(method="POST")]
    result = to_text(entries)
    assert "GET   " in result or "GET" in result
    assert "POST  " in result or "POST" in result


# ── render_aggregate ─────────────────────────────────────────────────────────


def test_render_aggregate_text_with_counter():
    """render_aggregate with a Counter-like object in text format."""
    from collections import Counter
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="text")
    assert "200" in result
    assert "10" in result
    assert "404" in result
    assert "3" in result


def test_render_aggregate_text_with_dict():
    """render_aggregate with a plain dict in text format."""
    agg = {"status_200": 5, "status_404": 2}
    result = render_aggregate(agg, fmt="text")
    assert "status_200" in result
    assert "5" in result


def test_render_aggregate_text_with_list_of_tuples():
    """render_aggregate with a list of (key, value) tuples."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="text")
    assert "200" in result
    assert "10" in result


def test_render_aggregate_json_with_counter():
    """render_aggregate in JSON format with a Counter-like object."""
    from collections import Counter
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="json")
    assert result.startswith("{")
    assert result.endswith("}")
    assert '"200":10' in result
    assert '"404":3' in result


def test_render_aggregate_json_with_list():
    """render_aggregate in JSON format with a list of tuples."""
    agg = [("a", 1), ("b", 2)]
    result = render_aggregate(agg, fmt="json")
    assert '"a":1' in result
    assert '"b":2' in result


def test_render_aggregate_unknown_format_raises():
    """render_aggregate should raise ValueError for unknown format strings."""
    with pytest.raises(ValueError, match="unknown format"):
        render_aggregate({"a": 1}, fmt="xml")


def test_render_aggregate_default_format_is_text():
    """When fmt is not specified, default should be 'text'."""
    agg = {"key": 42}
    result = render_aggregate(agg)
    assert "key" in result
    assert "42" in result
