"""Tests for utility functions: format_bytes, parse_iso_date, format_legacy, chunked.

Targets 0% coverage on utils.py — tests edge cases like zero bytes,
very large values, invalid date strings, and chunked iteration boundaries.
"""
from __future__ import annotations

from datetime import datetime, timezone

import pytest

from logalyzer.utils import (
    format_bytes,
    format_legacy,
    parse_iso_date,
    chunked,
)
from logalyzer.parser import LogEntry


# ── parse_iso_date ───────────────────────────────────────────────────────────


def test_parse_iso_date_valid():
    """Valid YYYY-MM-DD string should parse to UTC midnight datetime."""
    dt = parse_iso_date("2026-03-15")
    assert dt == datetime(2026, 3, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_leap_year():
    """Leap year date (Feb 29) should parse correctly."""
    dt = parse_iso_date("2024-02-29")
    assert dt == datetime(2024, 2, 29, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_year_boundary():
    """Year boundary dates should parse correctly."""
    dt = parse_iso_date("2000-12-31")
    assert dt == datetime(2000, 12, 31, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_invalid_format_raises():
    """Invalid date format should raise ValueError from strptime."""
    with pytest.raises(ValueError):
        parse_iso_date("2026/03/15")  # wrong separator


def test_parse_iso_date_invalid_day_raises():
    """Invalid day (e.g., Feb 30) should raise ValueError."""
    with pytest.raises(ValueError):
        parse_iso_date("2026-02-30")


def test_parse_iso_date_empty_string_raises():
    """Empty string should raise ValueError."""
    with pytest.raises(ValueError):
        parse_iso_date("")


def test_parse_iso_date_partial_date_raises():
    """Partial date string should raise ValueError."""
    with pytest.raises(ValueError):
        parse_iso_date("2026-03")


# ── format_bytes ─────────────────────────────────────────────────────────────


def test_format_bytes_zero():
    """Zero bytes should format as '0.0 B'."""
    assert format_bytes(0) == "0.0 B"


def test_format_bytes_small_value():
    """Small byte values (< 1024) should stay in bytes."""
    assert format_bytes(1) == "1.0 B"
    assert format_bytes(500) == "500.0 B"
    assert format_bytes(1023) == "1023.0 B"


def test_format_bytes_exactly_1kb():
    """Exactly 1024 bytes should format as '1.0 KB'."""
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_exactly_1mb():
    """Exactly 1 MB (1024*1024) should format as '1.0 MB'."""
    assert format_bytes(1024 * 1024) == "1.0 MB"


def test_format_bytes_exactly_1gb():
    """Exactly 1 GB should format as '1.0 GB'."""
    assert format_bytes(1024 ** 3) == "1.0 GB"


def test_format_bytes_exactly_1tb():
    """Exactly 1 TB should format as '1.0 TB'."""
    assert format_bytes(1024 ** 4) == "1.0 TB"


def test_format_bytes_fractional_kb():
    """Values between B and KB should show fractional KB."""
    result = format_bytes(1536)  # 1.5 KB
    assert result == "1.5 KB"


def test_format_bytes_fractional_mb():
    """Values between KB and MB should show fractional MB."""
    result = format_bytes(1024 * 1024 * 1.5)  # 1.5 MB
    assert result == "1.5 MB"


def test_format_bytes_very_large_value():
    """Very large values beyond TB should still format (PB fallback)."""
    result = format_bytes(1024 ** 5)  # 1 PB
    assert "PB" in result


def test_format_bytes_negative_value():
    """Negative byte values — the function doesn't guard against this.
    Documents current behavior: negative values go through the loop."""
    result = format_bytes(-1)
    # -1 < 1024, so it returns "-1.0 B"
    assert result == "-1.0 B"


# ── format_legacy ────────────────────────────────────────────────────────────


def test_format_legacy_basic():
    """format_legacy should produce pipe-separated fields."""
    entry = LogEntry(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/index.html",
        protocol="HTTP/1.1",
        status=200,
        bytes=512,
    )
    result = format_legacy(entry)
    assert "10.0.0.1" in result
    assert "200" in result
    assert "/index.html" in result
    assert "|" in result


def test_format_legacy_field_order():
    """format_legacy should output fields in order: ip | timestamp | status | url."""
    entry = LogEntry(
        ip="1.2.3.4",
        user="admin",
        timestamp=datetime(2025, 6, 15, 8, 30, 0, tzinfo=timezone.utc),
        method="POST",
        url="/api/data",
        protocol="HTTP/2.0",
        status=404,
        bytes=0,
    )
    result = format_legacy(entry)
    parts = result.split(" | ")
    assert parts[0] == "1.2.3.4"
    assert "2025-06-15" in parts[1]
    assert parts[2] == "404"
    assert parts[3] == "/api/data"


def test_format_legacy_does_not_include_method_or_bytes():
    """format_legacy intentionally omits method, protocol, user, and bytes fields."""
    entry = LogEntry(
        ip="10.0.0.1",
        user="frank",
        timestamp=datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc),
        method="DELETE",
        url="/resource",
        protocol="HTTP/1.1",
        status=204,
        bytes=9999,
    )
    result = format_legacy(entry)
    # method, protocol, user, and bytes should NOT appear
    assert "DELETE" not in result
    assert "HTTP/1.1" not in result
    assert "frank" not in result
    assert "9999" not in result


# ── chunked ──────────────────────────────────────────────────────────────────


def test_chunked_exact_division():
    """When list length is exactly divisible by chunk size."""
    result = list(chunked([1, 2, 3, 4, 5, 6], 3))
    assert result == [[1, 2, 3], [4, 5, 6]]


def test_chunked_remainder():
    """When list length is not divisible by chunk size, last chunk is smaller."""
    result = list(chunked([1, 2, 3, 4, 5], 2))
    assert result == [[1, 2], [3, 4], [5]]


def test_chunked_single_element_chunks():
    """Chunk size of 1 should produce one-element chunks."""
    result = list(chunked([10, 20, 30], 1))
    assert result == [[10], [20], [30]]


def test_chunked_chunk_larger_than_sequence():
    """Chunk size larger than sequence should return the whole sequence as one chunk."""
    result = list(chunked([1, 2], 10))
    assert result == [[1, 2]]


def test_chunked_empty_sequence():
    """Empty sequence should produce no chunks."""
    result = list(chunked([], 5))
    assert result == []


def test_chunked_generator_input():
    """chunked should work with generator input, not just lists."""
    def gen():
        yield 1
        yield 2
        yield 3
        yield 4
    result = list(chunked(gen(), 2))
    assert result == [[1, 2], [3, 4]]


def test_chunked_preserves_item_identity():
    """chunked should not copy items — same objects in chunks."""
    items = [object(), object(), object()]
    chunks = list(chunked(items, 2))
    assert chunks[0][0] is items[0]
    assert chunks[1][0] is items[2]


def test_chunked_lazy_evaluation():
    """chunked should be lazy — only compute chunks as consumed."""
    computed = []

    def tracking_gen():
        for i in range(10):
            computed.append(i)
            yield i

    gen = tracking_gen()
    chunks = chunked(gen, 3)
    # Nothing computed yet
    assert len(computed) == 0

    # Consume first chunk
    first = next(chunks)
    assert first == [0, 1, 2]
    # Only 3 items computed
    assert len(computed) == 3
