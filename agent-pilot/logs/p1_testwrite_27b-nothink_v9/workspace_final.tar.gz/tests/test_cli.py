"""Tests for CLI entry point: main, build_parser.

Targets 0% coverage on cli.py — tests the full pipeline from CLI args
through file loading, filtering, aggregation, and output formatting.
"""
from __future__ import annotations

import tempfile
import os

from logalyzer.cli import main, build_parser


def _valid_line(ip="127.0.0.1", status=200, url="/test", user="-"):
    """Generate a valid CLF log line."""
    return f'{ip} {user} - [10/Oct/2000:13:55:36 +0000] "GET {url} HTTP/1.1" {status} 1024'


def _make_log_file(lines):
    """Create a temp file with the given log lines and return its path."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        for line in lines:
            f.write(line + "\n")
        return f.name


# ── build_parser ─────────────────────────────────────────────────────────────


def test_build_parser_returns_argument_parser():
    """build_parser should return an argparse.ArgumentParser instance."""
    import argparse
    parser = build_parser()
    assert isinstance(parser, argparse.ArgumentParser)


def test_build_parser_requires_paths():
    """Parser should require at least one path argument."""
    parser = build_parser()
    # parse_args with no positional args should raise
    try:
        parser.parse_args([])
        assert False, "Expected SystemExit"
    except SystemExit:
        pass


def test_build_parser_version_flag():
    """--version flag should be recognized."""
    parser = build_parser()
    try:
        parser.parse_args(["--version"])
    except SystemExit as e:
        # argparse calls sys.exit after printing version
        assert e.code == 0


# ── main integration tests ──────────────────────────────────────────────────


def test_main_text_output_default():
    """Default format (text) should produce readable output."""
    path = _make_log_file([_valid_line(url="/home")])
    try:
        ret = main(["--format", "text", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_json_output():
    """--format json should produce JSON output."""
    path = _make_log_file([_valid_line(url="/api")])
    try:
        ret = main(["--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_csv_output():
    """--format csv should produce CSV output."""
    path = _make_log_file([_valid_line(url="/data")])
    try:
        ret = main(["--format", "csv", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_status_filter():
    """--status filter should only show matching entries."""
    path = _make_log_file([
        _valid_line(status=200, url="/ok"),
        _valid_line(status=404, url="/missing"),
        _valid_line(status=200, url="/also-ok"),
    ])
    try:
        ret = main(["--status", "200", "--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_url_filter():
    """--url regex filter should only show matching entries."""
    path = _make_log_file([
        _valid_line(url="/api/users"),
        _valid_line(url="/api/posts"),
        _valid_line(url="/static/style.css"),
    ])
    try:
        ret = main(["--url", "^/api", "--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_ip_filter():
    """--ip allowlist should only show entries from allowed IPs."""
    path = _make_log_file([
        _valid_line(ip="10.0.0.1", url="/a"),
        _valid_line(ip="10.0.0.2", url="/b"),
        _valid_line(ip="10.0.0.3", url="/c"),
    ])
    try:
        ret = main(["--ip", "10.0.0.1", "--ip", "10.0.0.2", "--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_aggregate_status():
    """--aggregate status should produce status code counts."""
    path = _make_log_file([
        _valid_line(status=200),
        _valid_line(status=200),
        _valid_line(status=404),
    ])
    try:
        ret = main(["--aggregate", "status", "--format", "text", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_aggregate_url():
    """--aggregate url should produce URL counts."""
    path = _make_log_file([
        _valid_line(url="/a"),
        _valid_line(url="/a"),
        _valid_line(url="/b"),
    ])
    try:
        ret = main(["--aggregate", "url", "--format", "text", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_aggregate_url_with_top():
    """--aggregate url --top N should limit results."""
    path = _make_log_file([
        _valid_line(url=f"/u{i}") for i in range(10)
    ])
    try:
        ret = main(["--aggregate", "url", "--top", "3", "--format", "text", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_aggregate_hour():
    """--aggregate hour should produce hourly counts."""
    path = _make_log_file([_valid_line()] * 5)
    try:
        ret = main(["--aggregate", "hour", "--format", "text", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_empty_file():
    """Processing an empty file should succeed with no output entries."""
    path = _make_log_file([])
    try:
        ret = main(["--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_multiple_files():
    """Multiple file paths should all be processed."""
    path1 = _make_log_file([_valid_line(url="/file1")])
    path2 = _make_log_file([_valid_line(url="/file2")])
    try:
        ret = main(["--format", "json", path1, path2])
        assert ret == 0
    finally:
        os.unlink(path1)
        os.unlink(path2)


def test_main_expr_filter():
    """--expr should allow custom Python expression filtering."""
    path = _make_log_file([
        _valid_line(status=200, url="/ok"),
        _valid_line(status=500, url="/error"),
    ])
    try:
        ret = main(["--expr", "entry.status >= 500", "--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_since_filter():
    """--since should filter entries by date."""
    path = _make_log_file([_valid_line()])
    try:
        # All entries are from 2000, so --since 2026 should filter them all out
        ret = main(["--since", "2026-01-01", "--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_until_filter():
    """--until should filter entries by date."""
    path = _make_log_file([_valid_line()])
    try:
        # All entries are from 2000, so --until 1999 should filter them all out
        ret = main(["--until", "1999-12-31", "--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_combined_filters():
    """Multiple filters (--status, --url, --ip) should be combined with AND."""
    path = _make_log_file([
        _valid_line(ip="10.0.0.1", status=200, url="/api/data"),
        _valid_line(ip="10.0.0.1", status=404, url="/api/data"),
        _valid_line(ip="10.0.0.2", status=200, url="/api/data"),
    ])
    try:
        ret = main([
            "--status", "200",
            "--ip", "10.0.0.1",
            "--url", "^/api",
            "--format", "json",
            path,
        ])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_aggregate_json_format():
    """--aggregate with --format json should produce JSON output."""
    path = _make_log_file([
        _valid_line(status=200),
        _valid_line(status=404),
    ])
    try:
        ret = main(["--aggregate", "status", "--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)
