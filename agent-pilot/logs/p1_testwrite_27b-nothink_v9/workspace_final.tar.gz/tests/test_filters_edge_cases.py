"""Additional edge-case tests for filters module.

Complements test_filters.py with tests for expression_filter, combine_and,
and edge cases for existing filters that weren't covered.
"""
from __future__ import annotations

from datetime import datetime, timezone

import pytest

from logalyzer.filters import (
    combine_and,
    date_range_filter,
    expression_filter,
    ip_allowlist_filter,
    status_filter,
    url_regex_filter,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to build LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── expression_filter ────────────────────────────────────────────────────────


def test_expression_filter_status_check():
    """Expression filter with status comparison."""
    pred = expression_filter("entry.status >= 400")
    assert pred(_entry(status=404)) is True
    assert pred(_entry(status=200)) is False


def test_expression_filter_bytes_check():
    """Expression filter with bytes comparison."""
    pred = expression_filter("entry.bytes > 500")
    assert pred(_entry(bytes=1000)) is True
    assert pred(_entry(bytes=100)) is False


def test_expression_filter_method_check():
    """Expression filter with method string comparison."""
    pred = expression_filter("entry.method == 'POST'")
    assert pred(_entry(method="POST")) is True
    assert pred(_entry(method="GET")) is False


def test_expression_filter_combined_conditions():
    """Expression filter with multiple conditions."""
    pred = expression_filter("entry.status >= 500 and entry.bytes > 0")
    assert pred(_entry(status=500, bytes=100)) is True
    assert pred(_entry(status=500, bytes=0)) is False
    assert pred(_entry(status=200, bytes=100)) is False


def test_expression_filter_url_contains():
    """Expression filter checking URL substring."""
    pred = expression_filter("'admin' in entry.url")
    assert pred(_entry(url="/admin/dashboard")) is True
    assert pred(_entry(url="/user/profile")) is False


def test_expression_filter_ip_check():
    """Expression filter checking IP address."""
    pred = expression_filter("entry.ip == '10.0.0.1'")
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="192.168.1.1")) is False


def test_expression_filter_sandboxed_no_builtins():
    """Expression filter should not have access to builtins like open()."""
    pred = expression_filter("open('/etc/passwd').read()")
    with pytest.raises(NameError):
        pred(_entry())


# ── combine_and ──────────────────────────────────────────────────────────────


def test_combine_and_all_match():
    """combine_and with all matching predicates should return True."""
    pred = combine_and(
        status_filter(200),
        ip_allowlist_filter(["10.0.0.1"]),
    )
    assert pred(_entry(status=200, ip="10.0.0.1")) is True


def test_combine_and_one_fails():
    """combine_and with one failing predicate should return False."""
    pred = combine_and(
        status_filter(200),
        ip_allowlist_filter(["10.0.0.1"]),
    )
    assert pred(_entry(status=404, ip="10.0.0.1")) is False


def test_combine_and_short_circuit():
    """combine_and should short-circuit on first failure."""
    call_count = [0]

    def always_false(entry):
        call_count[0] += 1
        return False

    def always_true(entry):
        call_count[0] += 1
        return True

    pred = combine_and(always_false, always_true)
    pred(_entry())
    # Should only call the first predicate (short-circuit)
    assert call_count[0] == 1


def test_combine_and_no_predicates():
    """combine_and with no predicates should return True (vacuous truth)."""
    pred = combine_and()
    assert pred(_entry()) is True


def test_combine_and_single_predicate():
    """combine_and with a single predicate should behave like that predicate."""
    pred = combine_and(status_filter(200))
    assert pred(_entry(status=200)) is True
    assert pred(_entry(status=404)) is False


# ── date_range_filter edge cases ─────────────────────────────────────────────


def test_date_range_filter_since_only():
    """date_range_filter with only since (no until) should have no upper bound."""
    since = datetime(2026, 1, 1, tzinfo=timezone.utc)
    pred = date_range_filter(since, None)
    assert pred(_entry(timestamp=datetime(2026, 6, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2030, 1, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2025, 12, 31, tzinfo=timezone.utc))) is False


def test_date_range_filter_until_only():
    """date_range_filter with only until (no since) should have no lower bound."""
    until = datetime(2026, 1, 1, tzinfo=timezone.utc)
    pred = date_range_filter(None, until)
    assert pred(_entry(timestamp=datetime(2025, 6, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2020, 1, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2026, 6, 1, tzinfo=timezone.utc))) is False


def test_date_range_filter_both_none():
    """date_range_filter with both None should match everything."""
    pred = date_range_filter(None, None)
    assert pred(_entry(timestamp=datetime(2020, 1, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2030, 12, 31, tzinfo=timezone.utc))) is True


# ── ip_allowlist_filter edge cases ───────────────────────────────────────────


def test_ip_allowlist_empty_list():
    """ip_allowlist_filter with empty allowlist should reject all entries."""
    pred = ip_allowlist_filter([])
    assert pred(_entry(ip="10.0.0.1")) is False
    assert pred(_entry(ip="192.168.1.1")) is False


def test_ip_allowlist_with_set():
    """ip_allowlist_filter should work with a set (not just list)."""
    pred = ip_allowlist_filter({"10.0.0.1", "10.0.0.2"})
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="10.0.0.3")) is False


def test_ip_allowlist_with_tuple():
    """ip_allowlist_filter should work with a tuple."""
    pred = ip_allowlist_filter(("10.0.0.1",))
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="10.0.0.2")) is False


# ── url_regex_filter edge cases ──────────────────────────────────────────────


def test_url_regex_exact_match():
    """url_regex_filter with exact URL match."""
    pred = url_regex_filter(r"^/$")
    assert pred(_entry(url="/")) is True
    assert pred(_entry(url="/index.html")) is False


def test_url_regex_special_characters():
    """url_regex_filter with special regex characters in URL."""
    pred = url_regex_filter(r"/api/v\d+")
    assert pred(_entry(url="/api/v1/users")) is True
    assert pred(_entry(url="/api/v2/posts")) is True
    assert pred(_entry(url="/api/users")) is False


def test_url_regex_case_insensitive():
    """url_regex_filter is case-sensitive by default."""
    pred = url_regex_filter(r"/Admin")
    assert pred(_entry(url="/Admin")) is True
    assert pred(_entry(url="/admin")) is False


# ── status_filter edge cases ─────────────────────────────────────────────────


def test_status_filter_zero_status():
    """status_filter with status 0 (edge case)."""
    pred = status_filter(0)
    assert pred(_entry(status=0)) is True
    assert pred(_entry(status=200)) is False


def test_status_filter_high_status():
    """status_filter with high status code."""
    pred = status_filter(599)
    assert pred(_entry(status=599)) is True
    assert pred(_entry(status=500)) is False
