"""Additional edge-case tests for parser module.

Complements test_parser.py with edge cases for parse_line, parse_timestamp,
and parse_lines that weren't covered by the original tests.
"""
from __future__ import annotations


import pytest

from logalyzer.parser import parse_line, parse_timestamp, parse_lines


# ── parse_line edge cases ────────────────────────────────────────────────────


def test_parse_line_whitespace_only():
    """Whitespace-only lines should return None."""
    assert parse_line("   ") is None
    assert parse_line("\t") is None
    assert parse_line("\n") is None


def test_parse_line_leading_trailing_whitespace():
    """Lines with leading/trailing whitespace should be stripped and parsed."""
    line = '  127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100  '
    e = parse_line(line)
    assert e is not None
    assert e.ip == "127.0.0.1"


def test_parse_line_various_methods():
    """Various HTTP methods should be parsed correctly."""
    for method in ("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"):
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "{method} / HTTP/1.1" 200 100'
        e = parse_line(line)
        assert e is not None, f"Failed to parse method {method}"
        assert e.method == method


def test_parse_line_various_status_codes():
    """Various HTTP status codes should be parsed correctly."""
    for status in (200, 201, 301, 302, 304, 400, 401, 403, 404, 500, 502, 503):
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" {status} 100'
        e = parse_line(line)
        assert e is not None, f"Failed to parse status {status}"
        assert e.status == status


def test_parse_line_ipv6_address():
    """IPv6 addresses should be parsed correctly."""
    line = '::1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100'
    e = parse_line(line)
    assert e is not None
    assert e.ip == "::1"


def test_parse_line_url_with_query_string():
    """URLs with query strings should be parsed correctly."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /search?q=test&page=1 HTTP/1.1" 200 500'
    e = parse_line(line)
    assert e is not None
    assert e.url == "/search?q=test&page=1"


def test_parse_line_url_with_fragment():
    """URLs with fragments should be parsed correctly."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /page#section HTTP/1.1" 200 100'
    e = parse_line(line)
    assert e is not None
    assert e.url == "/page#section"


def test_parse_line_user_field_with_value():
    """Non-dash user field should be parsed correctly."""
    line = '127.0.0.1 - admin [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100'
    e = parse_line(line)
    assert e is not None
    assert e.user == "admin"


def test_parse_line_zero_bytes():
    """Zero byte responses should be parsed correctly."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 304 0'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 0


def test_parse_line_large_byte_count():
    """Large byte counts should be parsed correctly."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /big HTTP/1.1" 200 999999999'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 999999999


def test_parse_line_partial_log_line():
    """Incomplete log lines should return None."""
    assert parse_line('127.0.0.1 - -') is None
    assert parse_line('127.0.0.1 - - [10/Oct/2000:13:55:36 +0000]') is None
    assert parse_line('127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1"') is None


def test_parse_line_lowercase_method_rejected():
    """Lowercase HTTP methods should not match (regex requires [A-Z]+)."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "get / HTTP/1.1" 200 100'
    assert parse_line(line) is None


def test_parse_line_logentry_is_frozen():
    """LogEntry dataclass should be frozen (immutable)."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100'
    e = parse_line(line)
    assert e is not None
    with pytest.raises(Exception):  # FrozenInstanceError
        e.ip = "1.2.3.4"


# ── parse_timestamp edge cases ───────────────────────────────────────────────


def test_parse_timestamp_positive_offset():
    """Positive timezone offset should convert correctly to UTC."""
    # +0530 means local time is 5:30 ahead of UTC
    # So 12:00 +0530 = 06:30 UTC
    ts = parse_timestamp("15/Mar/2026:12:00:00 +0530")
    assert ts.hour == 6
    assert ts.minute == 30


def test_parse_timestamp_negative_offset():
    """Negative timezone offset should convert correctly to UTC."""
    # -0500 means local time is 5:00 behind UTC
    # So 12:00 -0500 = 17:00 UTC
    ts = parse_timestamp("15/Mar/2026:12:00:00 -0500")
    assert ts.hour == 17
    assert ts.minute == 0


def test_parse_timestamp_utc_offset():
    """+0000 offset should keep the time as-is."""
    ts = parse_timestamp("15/Mar/2026:12:00:00 +0000")
    assert ts.hour == 12
    assert ts.minute == 0


def test_parse_timestamp_unrecognized_format_raises():
    """Unrecognized timestamp format should raise ValueError."""
    with pytest.raises(ValueError, match="unrecognized timestamp format"):
        parse_timestamp("2026-03-15T12:00:00Z")  # ISO format, not Apache


def test_parse_timestamp_missing_timezone_raises():
    """Timestamp without timezone should raise ValueError."""
    with pytest.raises(ValueError):
        parse_timestamp("15/Mar/2026:12:00:00")


def test_parse_timestamp_all_months_except_jul():
    """All months in MONTH_NAMES should parse correctly (Jul is missing — bug)."""
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Aug", "Sep", "Oct", "Nov", "Dec"]
    for month in months:
        ts = parse_timestamp(f"15/{month}/2026:12:00:00 +0000")
        assert ts is not None


def test_parse_timestamp_midnight():
    """Midnight timestamps should parse correctly."""
    ts = parse_timestamp("01/Jan/2026:00:00:00 +0000")
    assert ts.hour == 0
    assert ts.minute == 0
    assert ts.second == 0


def test_parse_timestamp_end_of_day():
    """End-of-day timestamps should parse correctly."""
    ts = parse_timestamp("30/Dec/2025:23:59:59 +0000")
    assert ts.hour == 23
    assert ts.minute == 59
    assert ts.second == 59


# ── parse_lines ──────────────────────────────────────────────────────────────


def test_parse_lines_empty_iterable():
    """parse_lines with empty iterable should yield nothing."""
    result = list(parse_lines([]))
    assert result == []


def test_parse_lines_mixed_valid_invalid():
    """parse_lines should skip invalid lines and yield only valid entries."""
    lines = [
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /a HTTP/1.1" 200 100',
        "invalid line",
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /b HTTP/1.1" 200 200',
        "",
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /c HTTP/1.1" 200 300',
    ]
    result = list(parse_lines(lines))
    assert len(result) == 3
    assert [e.url for e in result] == ["/a", "/b", "/c"]


def test_parse_lines_is_a_generator():
    """parse_lines should return a generator."""
    import types
    result = parse_lines(["some line"])
    assert isinstance(result, types.GeneratorType)


def test_parse_lines_lazy_evaluation():
    """parse_lines should be lazy — only parsing lines as consumed."""
    parsed = []

    class TrackingList:
        def __init__(self, items):
            self.items = items
            self.index = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.index >= len(self.items):
                raise StopIteration
            item = self.items[self.index]
            self.index += 1
            parsed.append(item)
            return item

    lines = TrackingList([
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /a HTTP/1.1" 200 100',
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /b HTTP/1.1" 200 200',
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /c HTTP/1.1" 200 300',
    ])

    gen = parse_lines(lines)
    # Nothing parsed yet
    assert len(parsed) == 0

    # Consume first entry
    first = next(gen)
    assert first.url == "/a"
    assert len(parsed) == 1

    # Consume second entry
    second = next(gen)
    assert second.url == "/b"
    assert len(parsed) == 2
