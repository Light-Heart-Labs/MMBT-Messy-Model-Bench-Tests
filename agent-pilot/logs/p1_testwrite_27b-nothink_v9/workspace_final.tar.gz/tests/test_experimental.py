"""Tests for experimental features: detect_anomalies, session_window.

Targets 0% coverage on experimental.py — tests anomaly detection with
various distributions, session windowing with edge cases like single
entries per IP, and empty inputs.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone


from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1", **kw):
    """Helper to build LogEntry with a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
        **kw,
    )


# ── detect_anomalies ─────────────────────────────────────────────────────────


def test_detect_anomalies_empty_input():
    """Empty input should return empty list (no anomalies possible)."""
    assert detect_anomalies([]) == []


def test_detect_anomalies_uniform_distribution():
    """Uniform request distribution should have no anomalies."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(60)]
    # Each minute has exactly 1 request — perfectly uniform
    anomalies = detect_anomalies(entries)
    assert anomalies == []


def test_detect_anomalies_single_spike_detected():
    """A single minute with many more requests should be flagged as anomaly.

    Need enough baseline minutes so the z-score threshold is exceeded.
    With 10 minutes at 1 req each and 1 minute at 100 reqs:
    mean=10, std≈28.5, threshold≈95.4, so 100 > 95.4 ✓
    """
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 10 minutes with 1 request each (baseline)
    for i in range(10):
        entries.append(_entry(base + timedelta(minutes=i)))
    # 1 minute with 100 requests (the spike)
    spike_time = base + timedelta(minutes=10)
    for _ in range(100):
        entries.append(_entry(spike_time))
    anomalies = detect_anomalies(entries)
    assert spike_time in anomalies


def test_detect_anomalies_returns_minute_buckets():
    """Anomaly results should be minute-bucketed datetimes (seconds=0, microsecond=0)."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 10 baseline minutes
    for i in range(10):
        entries.append(_entry(base + timedelta(minutes=i)))
    # Spike minute
    spike_time = base + timedelta(minutes=10)
    for _ in range(100):
        entries.append(_entry(spike_time + timedelta(seconds=30)))
    anomalies = detect_anomalies(entries)
    for a in anomalies:
        assert a.second == 0
        assert a.microsecond == 0


def test_detect_anomalies_seconds_within_same_minute_bucketed():
    """Requests at different seconds within the same minute should be bucketed together.

    With 10 baseline minutes (1 req each) and 1 spike minute (10 reqs),
    the spike is not large enough to exceed 3σ. So we use 20 baseline
    minutes and 50 spike requests to ensure detection.
    """
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 20 minutes with 1 request each
    for i in range(20):
        entries.append(_entry(base + timedelta(minutes=i)))
    # 50 requests all in minute 20, at different seconds
    for sec in range(50):
        entries.append(_entry(base + timedelta(minutes=20, seconds=sec % 60)))
    anomalies = detect_anomalies(entries)
    # The bucket should be at minute 20, seconds zeroed
    expected_bucket = base + timedelta(minutes=20)
    assert expected_bucket in anomalies


def test_detect_anomalies_all_same_minute():
    """All entries in the same minute — no variance, no anomalies."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base) for _ in range(100)]
    anomalies = detect_anomalies(entries)
    # All in one bucket, std=0, threshold=mean, no bucket > mean
    assert anomalies == []


def test_detect_anomalies_single_entry():
    """Single entry — one bucket, std=0, no anomalies."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base)]
    anomalies = detect_anomalies(entries)
    assert anomalies == []


def test_detect_anomalies_two_buckets_one_spike():
    """Two minutes with very different counts — need enough baseline
    minutes for the z-score to work. Use 10 baseline + 1 spike.
    """
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 10 minutes with 1 request each
    for i in range(10):
        entries.append(_entry(base + timedelta(minutes=i)))
    # 1 minute with 100 requests
    spike = base + timedelta(minutes=10)
    entries.extend([_entry(spike) for _ in range(100)])
    anomalies = detect_anomalies(entries)
    assert spike in anomalies


def test_detect_anomalies_multiple_spikes():
    """Multiple anomalous minutes should all be detected."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 20 baseline minutes
    for i in range(20):
        entries.append(_entry(base + timedelta(minutes=i)))
    # Two spike minutes
    for spike_min in (20, 21):
        for _ in range(100):
            entries.append(_entry(base + timedelta(minutes=spike_min)))
    anomalies = detect_anomalies(entries)
    assert base + timedelta(minutes=20) in anomalies
    assert base + timedelta(minutes=21) in anomalies


# ── session_window ───────────────────────────────────────────────────────────


def test_session_window_empty_input():
    """Empty input should return empty sessions list."""
    assert session_window([]) == []


def test_session_window_single_entry():
    """Single entry should produce one session."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base)]
    sessions = session_window(entries)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    assert ip == "10.0.0.1"
    assert len(session_entries) == 1


def test_session_window_single_ip_continuous():
    """Single IP with entries within the window should be one session."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        _entry(base + timedelta(minutes=20)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    assert len(session_entries) == 3


def test_session_window_single_ip_gap_exceeds_window():
    """Single IP with a gap exceeding the window should produce two sessions."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        # 40-minute gap exceeds default 30-minute window
        _entry(base + timedelta(minutes=50)),
        _entry(base + timedelta(minutes=60)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    # First session: entries at 0 and 10 min
    assert len(sessions[0][1]) == 2
    # Second session: entries at 50 and 60 min
    assert len(sessions[1][1]) == 2


def test_session_window_multiple_ips():
    """Multiple IPs should each get their own sessions."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base, ip="10.0.0.1"),
        _entry(base + timedelta(minutes=5), ip="10.0.0.2"),
        _entry(base + timedelta(minutes=10), ip="10.0.0.1"),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 2
    ips = {s[0] for s in sessions}
    assert ips == {"10.0.0.1", "10.0.0.2"}


def test_session_window_custom_window_seconds():
    """Custom window_seconds should be respected."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=60)),
        _entry(base + timedelta(seconds=120)),
    ]
    # 30-second window: gaps of 60s exceed it
    sessions = session_window(entries, window_seconds=30)
    assert len(sessions) == 3  # Each entry is its own session


def test_session_window_entries_sorted_by_time():
    """Entries within a session should be sorted by timestamp."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base + timedelta(minutes=10)),
        _entry(base),
        _entry(base + timedelta(minutes=5)),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    timestamps = [e.timestamp for e in session_entries]
    assert timestamps == sorted(timestamps)


def test_session_window_gap_exactly_at_window_boundary():
    """Gap exactly equal to window_seconds should NOT split the session
    (the check is > not >=)."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1800)),  # exactly 30 min
    ]
    sessions = session_window(entries, window_seconds=1800)
    # gap == 1800, check is gap > 1800, so this is one session
    assert len(sessions) == 1


def test_session_window_gap_just_over_window_boundary():
    """Gap just over window_seconds should split the session."""
    base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1801)),  # 30 min + 1 sec
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
