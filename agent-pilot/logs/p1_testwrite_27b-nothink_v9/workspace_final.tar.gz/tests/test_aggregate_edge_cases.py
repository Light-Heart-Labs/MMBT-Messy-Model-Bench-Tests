"""Additional edge-case tests for aggregate module.

Complements test_aggregate.py with edge cases for empty inputs,
single entries, and boundary conditions.
"""
from __future__ import annotations

from datetime import datetime, timezone

from logalyzer.aggregate import by_hour, by_status, by_url, total_bytes
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to build LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── by_status edge cases ─────────────────────────────────────────────────────


def test_by_status_empty_input():
    """by_status with empty input should return empty Counter."""
    result = by_status([])
    assert len(result) == 0


def test_by_status_single_entry():
    """by_status with a single entry should count it."""
    result = by_status([_entry(status=404)])
    assert result[404] == 1
    assert len(result) == 1


def test_by_status_all_same_status():
    """by_status with all entries having the same status."""
    entries = [_entry(status=200) for _ in range(100)]
    result = by_status(entries)
    assert result[200] == 100
    assert len(result) == 1


# ── by_url edge cases ────────────────────────────────────────────────────────


def test_by_url_empty_input():
    """by_url with empty input should return empty list."""
    result = by_url([])
    assert result == []


def test_by_url_single_entry():
    """by_url with a single entry should return one item."""
    result = by_url([_entry(url="/single")])
    assert result == [("/single", 1)]


def test_by_url_top_zero():
    """by_url with top=0 should return empty list."""
    entries = [_entry(url=f"/u{i}") for i in range(10)]
    result = by_url(entries, top=0)
    assert result == []


def test_by_url_top_larger_than_unique():
    """by_url with top larger than unique URLs should return all."""
    entries = [_entry(url="/a"), _entry(url="/b")]
    result = by_url(entries, top=100)
    assert len(result) == 2


def test_by_url_all_same_url():
    """by_url with all entries having the same URL."""
    entries = [_entry(url="/same") for _ in range(50)]
    result = by_url(entries)
    assert result == [("/same", 50)]


# ── by_hour edge cases ───────────────────────────────────────────────────────


def test_by_hour_empty_input():
    """by_hour with empty input should return all 24 hours with 0 counts."""
    result = by_hour([])
    assert len(result) == 24
    assert all(v == 0 for v in result.values())


def test_by_hour_single_entry():
    """by_hour with a single entry should count it in the correct hour."""
    result = by_hour([_entry(timestamp=datetime(2026, 1, 1, 5, 30, 0, tzinfo=timezone.utc))])
    assert result[5] == 1
    assert all(result[h] == 0 for h in range(24) if h != 5)


def test_by_hour_all_24_hours():
    """by_hour should have exactly 24 keys (0-23)."""
    entries = [_entry(timestamp=datetime(2026, 1, 1, h, 0, 0, tzinfo=timezone.utc)) for h in range(24)]
    result = by_hour(entries)
    assert set(result.keys()) == set(range(24))
    assert all(result[h] == 1 for h in range(24))


# ── total_bytes edge cases ───────────────────────────────────────────────────


def test_total_bytes_empty_input():
    """total_bytes with empty input should return 0."""
    assert total_bytes([]) == 0


def test_total_bytes_single_entry():
    """total_bytes with a single entry should return that entry's bytes."""
    assert total_bytes([_entry(bytes=500)]) == 500


def test_total_bytes_all_zero():
    """total_bytes with all zero-byte entries should return 0."""
    entries = [_entry(bytes=0) for _ in range(10)]
    assert total_bytes(entries) == 0


def test_total_bytes_large_values():
    """total_bytes should handle large byte values without overflow."""
    entries = [_entry(bytes=10**9) for _ in range(10)]
    assert total_bytes(entries) == 10 * 10**9
