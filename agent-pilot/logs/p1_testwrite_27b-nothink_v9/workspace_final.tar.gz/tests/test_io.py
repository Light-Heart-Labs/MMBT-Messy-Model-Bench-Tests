"""Tests for I/O functions: load, load_iter.

Targets 0% coverage on io.py — tests file loading with various file
contents: empty files, malformed lines, files without trailing newlines,
and large files.
"""
from __future__ import annotations

import tempfile
import os

from logalyzer.io import load, load_iter
from logalyzer.parser import LogEntry


def _valid_line(ip="127.0.0.1", status=200, url="/test"):
    """Generate a valid CLF log line."""
    return f'{ip} - - [10/Oct/2000:13:55:36 +0000] "GET {url} HTTP/1.1" {status} 1024'


def test_load_empty_file():
    """Loading an empty file should return an empty list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("")
        path = f.name
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_single_valid_line():
    """Loading a file with one valid line should return one entry."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line())
        path = f.name
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_multiple_valid_lines():
    """Loading a file with multiple valid lines should return all entries."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line(url="/a") + "\n")
        f.write(_valid_line(url="/b") + "\n")
        f.write(_valid_line(url="/c") + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 3
        urls = [e.url for e in result]
        assert urls == ["/a", "/b", "/c"]
    finally:
        os.unlink(path)


def test_load_mixed_valid_and_invalid_lines():
    """Invalid lines should be silently skipped; only valid lines returned."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line(url="/valid1") + "\n")
        f.write("this is garbage\n")
        f.write(_valid_line(url="/valid2") + "\n")
        f.write("another bad line\n")
        f.write(_valid_line(url="/valid3") + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 3
        urls = [e.url for e in result]
        assert urls == ["/valid1", "/valid2", "/valid3"]
    finally:
        os.unlink(path)


def test_load_file_without_trailing_newline():
    """A file whose last line has no trailing newline should still be parsed."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line(url="/last"))
        # No trailing newline
        path = f.name
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].url == "/last"
    finally:
        os.unlink(path)


def test_load_file_with_only_invalid_lines():
    """A file with only invalid lines should return an empty list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("garbage line 1\n")
        f.write("garbage line 2\n")
        f.write("garbage line 3\n")
        path = f.name
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_file_with_empty_lines():
    """Empty lines in the file should be skipped."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line(url="/a") + "\n")
        f.write("\n")
        f.write(_valid_line(url="/b") + "\n")
        f.write("\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_returns_list_of_logentry():
    """load should return a list of LogEntry objects."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line())
        path = f.name
    try:
        result = load(path)
        assert isinstance(result, list)
        assert all(isinstance(e, LogEntry) for e in result)
    finally:
        os.unlink(path)


def test_load_iter_empty_file():
    """load_iter on an empty file should yield nothing."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("")
        path = f.name
    try:
        result = list(load_iter(path))
        assert result == []
    finally:
        os.unlink(path)


def test_load_iter_single_valid_line():
    """load_iter on a file with one valid line should yield one entry."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line(url="/iter-test"))
        path = f.name
    try:
        result = list(load_iter(path))
        assert len(result) == 1
        assert result[0].url == "/iter-test"
    finally:
        os.unlink(path)


def test_load_iter_skips_invalid_lines():
    """load_iter should skip invalid lines, just like load."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line(url="/a") + "\n")
        f.write("invalid\n")
        f.write(_valid_line(url="/b") + "\n")
        path = f.name
    try:
        result = list(load_iter(path))
        assert len(result) == 2
        assert [e.url for e in result] == ["/a", "/b"]
    finally:
        os.unlink(path)


def test_load_iter_is_a_generator():
    """load_iter should return a generator, not a list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line())
        path = f.name
    try:
        result = load_iter(path)
        # Should be a generator
        import types
        assert isinstance(result, types.GeneratorType)
    finally:
        os.unlink(path)


def test_load_iter_lazy_evaluation():
    """load_iter should be lazy — only reading lines as consumed."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        for i in range(100):
            f.write(_valid_line(url=f"/page{i}") + "\n")
        path = f.name
    try:
        gen = load_iter(path)
        # Consume only the first entry
        first = next(gen)
        assert first.url == "/page0"
        # Consume the second
        second = next(gen)
        assert second.url == "/page1"
        # The rest are still unconsumed
    finally:
        os.unlink(path)


def test_load_preserves_entry_order():
    """load should preserve the order of entries as they appear in the file."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        for i in range(10):
            f.write(_valid_line(url=f"/url{i}") + "\n")
        path = f.name
    try:
        result = load(path)
        urls = [e.url for e in result]
        assert urls == [f"/url{i}" for i in range(10)]
    finally:
        os.unlink(path)


def test_load_various_status_codes():
    """load should correctly parse entries with different status codes."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line(status=200) + "\n")
        f.write(_valid_line(status=404) + "\n")
        f.write(_valid_line(status=500) + "\n")
        path = f.name
    try:
        result = load(path)
        assert [e.status for e in result] == [200, 404, 500]
    finally:
        os.unlink(path)


def test_load_various_ips():
    """load should correctly parse entries with different IP addresses."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(_valid_line(ip="10.0.0.1") + "\n")
        f.write(_valid_line(ip="192.168.1.1") + "\n")
        f.write(_valid_line(ip="::1") + "\n")
        path = f.name
    try:
        result = load(path)
        assert [e.ip for e in result] == ["10.0.0.1", "192.168.1.1", "::1"]
    finally:
        os.unlink(path)
