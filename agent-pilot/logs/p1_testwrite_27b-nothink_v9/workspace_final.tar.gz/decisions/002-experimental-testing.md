# ADR-002: Testing experimental.py

## Context

`experimental.py` is marked as "experimental" and "not yet wired into the CLI."
It contains two functions: `detect_anomalies` (z-score-based anomaly detection)
and `session_window` (IP-based session grouping).

## Decision

Test both functions thoroughly despite the "experimental" label.

## Rationale

1. **Coverage goal**: The task explicitly states "testing it is fine if the goal is increasing coverage and exercising the code path."
2. **Documentation**: Tests serve as behavioral documentation for code that may later be integrated.
3. **Regression safety**: If the code is later wired into the CLI, existing tests will catch regressions.
4. **Zero risk**: Testing doesn't change behavior or encourage use of experimental code.

## Recommendation (Out of Scope)

The `detect_anomalies` function uses population standard deviation (divides by N, not N-1), which is technically incorrect for sample data. This is a statistical concern, not a bug per se — the function works as implemented. If this code is ever promoted from experimental, the statistical method should be reviewed.

The `session_window` function has a subtle behavior: entries within a session are sorted by timestamp, but the function processes entries in the order they appear in the input. If entries for the same IP arrive out of order, the session boundaries may be incorrect. This is documented in the test `test_session_window_entries_sorted_by_time`.
