# ADR-001: Test Strategy for Under-Covered Modules

## Context

The logalyzer codebase has several modules with 0% or very low test coverage:
- `experimental.py` — 0% coverage (32 statements)
- `output.py` — 0% coverage (35 statements)
- `utils.py` — 0% coverage (21 statements)
- `io.py` — 0% coverage (26 statements)
- `cli.py` — 0% coverage (59 statements)

The existing tests cover `parser.py` (86%), `aggregate.py` (100%), and `filters.py` (74%).

## Decision

Target modules in order of impact:
1. **`output.py`** — Core functionality (JSON, CSV, text rendering). High value because these are used by the CLI.
2. **`utils.py`** — Utility functions (`format_bytes`, `parse_iso_date`, `chunked`, `format_legacy`). Edge cases matter here.
3. **`experimental.py`** — 0% coverage. Test the anomaly detection and session window logic.
4. **`io.py`** — File I/O. Test with temp files, empty files, malformed content.
5. **`cli.py`** — Integration-level tests using `main()` with `argv`.
6. **`parser.py`** — Add edge case tests for timestamps, malformed lines, unicode.
7. **`filters.py`** — Add tests for `expression_filter`, `combine_and`, edge cases.

## Rationale

- `output.py` and `utils.py` are used by the CLI and have no tests at all — highest ROI.
- `experimental.py` is marked experimental but testing it increases coverage and documents behavior.
- `io.py` tests require file system access but are straightforward with temp files.
- `cli.py` integration tests validate the full pipeline.

## Pre-existing Bugs (Not Fixed)

1. `filters.py`: `status_filter` does not convert string status to int — `status_filter("404")` fails to match `entry.status == 404`.
2. `filters.py`: `url_regex_filter` uses `re.match` (start-of-string) instead of `re.search` — patterns like "admin" don't match "/admin/login".
3. `parser.py`: `MONTH_NAMES` list is missing "Jul" — July timestamps raise `ValueError`.

These are documented in `research/dead-ends.md`.

## What We Chose NOT to Test

- We do not test the 3 pre-existing failing tests — they document bugs we are not fixing.
- We do not test `cli.py`'s `argparse` help/version output extensively — that's argparse's job.
- We do not test `experimental.py`'s statistical accuracy — we test that it runs and returns expected types.
