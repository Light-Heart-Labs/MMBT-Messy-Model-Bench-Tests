# Questions

## Resolved

1. **Can I modify conftest.py?** Yes — it's in `/tests/` which is allowed. Used it to monkey-patch the `collections.Iterable` import issue.

2. **Should I test the 3 pre-existing failing tests?** No — they document bugs I'm not fixing. They remain as-is.

3. **Should I test `experimental.py`?** Yes — the task explicitly says "testing it is fine if the goal is increasing coverage."

4. **How to handle `io.py` file tests?** Use `tempfile.NamedTemporaryFile` to create test files on the fly.

## Open

None at this time.
