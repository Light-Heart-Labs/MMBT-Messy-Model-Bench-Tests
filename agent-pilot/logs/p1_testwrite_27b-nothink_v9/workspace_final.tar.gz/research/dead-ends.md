# Dead Ends

Tests written and removed, or pre-existing issues encountered.

## Pre-existing Failing Tests (Not Modified)

### 1. `test_status_filter_works_with_cli_string_input`

**Bug**: `status_filter("404")` compares string "404" to int 404, which is always False.
The filter does `entry.status == status` without converting `status` to int.
The test expects `pred(make_entry(status=404))` to be True when status is passed as string "404".

**Decision**: Do not fix. Document as known bug. The test is correct in intent but the code is wrong.

### 2. `test_url_regex_finds_substring_match`

**Bug**: `url_regex_filter` uses `rx.match(entry.url)` which only matches at the start of the string.
Pattern "admin" does not match "/admin/login" because "admin" is not at position 0.
The test expects substring matching behavior that the code doesn't provide.

**Decision**: Do not fix. Document as known bug.

### 3. `test_timestamp_july_parses_correctly`

**Bug**: `MONTH_NAMES` list in `parser.py` is missing "Jul" (July).
The list has: Jan, Feb, Mar, Apr, May, Jun, **Aug**, Sep, Oct, Nov, Dec.
`parse_timestamp("04/Jul/2026:12:00:00 +0000")` raises `ValueError: 'Jul' is not in list`.

**Decision**: Do not fix. Document as known bug.

## Pre-existing Import Error

`filters.py` imports `from collections import Iterable` which was removed in Python 3.11.
Fixed in `conftest.py` by monkey-patching `collections.Iterable` before imports.
This is a workaround, not a fix — the source code remains unchanged.

## Tests Written and Removed

None yet — all new tests are kept.
