# CHANGELOG

## v0.3.2-test-additions

### Coverage Delta

| Metric | Before | After | Delta |
|--------|--------|-------|-------|
| Total coverage | 34% | 99% | +65% |
| Total statements | 287 | 287 | — |
| Uncovered statements | 190 | 3 | -187 |
| Passing tests | 14 | 184 | +170 |
| Failing tests (pre-existing bugs) | 3 | 3 | — |

### Per-Module Coverage

| Module | Before | After |
|--------|--------|-------|
| `__init__.py` | 100% | 100% |
| `aggregate.py` | 100% | 100% |
| `cli.py` | 0% | 98% |
| `experimental.py` | 0% | 100% |
| `filters.py` | 74% | 100% |
| `io.py` | 0% | 100% |
| `output.py` | 0% | 100% |
| `parser.py` | 86% | 96% |
| `utils.py` | 0% | 100% |

### Test Files Added

1. **`tests/test_output.py`** (25 tests)
   - `to_json`: empty list, single/multiple entries, special characters, zero/large bytes, status codes
   - `to_csv`: empty list, single/multiple entries, commas in URLs, timestamp format
   - `to_text`: empty list, single/multiple entries, IP/method alignment
   - `render_aggregate`: text/JSON with Counter, dict, list of tuples; unknown format error; default format

2. **`tests/test_utils.py`** (28 tests)
   - `parse_iso_date`: valid dates, leap year, year boundary, invalid format/day/empty/partial
   - `format_bytes`: zero, small, exact KB/MB/GB/TB, fractional, very large, negative
   - `format_legacy`: basic output, field order, omitted fields
   - `chunked`: exact division, remainder, single-element, larger-than-sequence, empty, generator, identity, lazy evaluation

3. **`tests/test_experimental.py`** (18 tests)
   - `detect_anomalies`: empty input, uniform distribution, spike detection, minute bucketing, same-minute, single entry, multiple spikes
   - `session_window`: empty input, single entry, continuous, gap exceeds window, multiple IPs, custom window, sorted entries, boundary conditions

4. **`tests/test_io.py`** (16 tests)
   - `load`: empty file, single/multiple valid lines, mixed valid/invalid, no trailing newline, only invalid, empty lines, type checks, order preservation, various statuses/IPs
   - `load_iter`: empty file, single line, skip invalid, generator type, lazy evaluation

5. **`tests/test_cli.py`** (20 tests)
   - `build_parser`: returns ArgumentParser, requires paths, version flag
   - `main`: text/JSON/CSV output, status/url/ip filters, aggregate status/url/hour, top N, empty file, multiple files, expression filter, since/until filters, combined filters, aggregate with JSON format

6. **`tests/test_parser_edge_cases.py`** (25 tests)
   - `parse_line`: whitespace, leading/trailing whitespace, various methods/statuses, IPv6, query strings, fragments, user field, zero/large bytes, partial lines, lowercase method rejection, frozen dataclass
   - `parse_timestamp`: positive/negative/UTC offsets, unrecognized format, missing timezone, all months (except Jul bug), midnight, end of day
   - `parse_lines`: empty iterable, mixed valid/invalid, generator type, lazy evaluation

7. **`tests/test_filters_edge_cases.py`** (23 tests)
   - `expression_filter`: status/bytes/method checks, combined conditions, URL contains, IP check, sandboxed builtins
   - `combine_and`: all match, one fails, short-circuit, no predicates, single predicate
   - `date_range_filter`: since-only, until-only, both None
   - `ip_allowlist_filter`: empty list, set, tuple
   - `url_regex_filter`: exact match, special characters, case sensitivity
   - `status_filter`: zero status, high status

8. **`tests/test_aggregate_edge_cases.py`** (15 tests)
   - `by_status`: empty input, single entry, all same status
   - `by_url`: empty input, single entry, top=0, top larger than unique, all same URL
   - `by_hour`: empty input (24 zeros), single entry, all 24 hours
   - `total_bytes`: empty input, single entry, all zero, large values

### Pre-existing Bugs (Not Fixed)

1. **`filters.py`**: `status_filter("404")` doesn't convert string to int — fails to match `entry.status == 404`
2. **`filters.py`**: `url_regex_filter` uses `re.match` (start-of-string) — "admin" doesn't match "/admin/login"
3. **`parser.py`**: `MONTH_NAMES` missing "Jul" — July timestamps raise `ValueError`; also shifts Aug-Dec by 1 month

### Infrastructure

- **`tests/conftest.py`**: Added monkey-patch for `collections.Iterable` import (Python 3.11 compatibility workaround)
- **`decisions/001-test-strategy.md`**: ADR documenting test strategy and rationale
- **`research/dead-ends.md`**: Documentation of pre-existing bugs and test decisions
- **`research/questions.md`**: Resolved questions during development
