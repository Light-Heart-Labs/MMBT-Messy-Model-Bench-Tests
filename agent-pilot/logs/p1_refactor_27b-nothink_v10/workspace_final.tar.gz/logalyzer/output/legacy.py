"""Legacy output formatting for backwards compatibility.

This module provides format_legacy() which was retained for compatibility
with the v0.1 CLI output. It is not used internally by logalyzer.
"""
from __future__ import annotations

from ..utils import format_legacy

__all__ = ["format_legacy"]
