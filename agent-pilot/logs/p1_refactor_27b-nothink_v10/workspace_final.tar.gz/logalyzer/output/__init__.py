"""Output formatters: JSON, CSV, plain text.

This package replaces the monolithic output.py module.
All public symbols are re-exported here for backward compatibility.
"""
from __future__ import annotations

from .csv_renderer import to_csv
from .json_renderer import to_json
from .legacy import format_legacy
from .plain_renderer import render_aggregate, to_text

__all__ = [
    "format_legacy",
    "render_aggregate",
    "to_csv",
    "to_json",
    "to_text",
]
