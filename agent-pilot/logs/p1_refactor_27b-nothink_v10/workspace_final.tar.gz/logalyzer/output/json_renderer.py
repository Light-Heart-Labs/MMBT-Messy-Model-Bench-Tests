"""JSON output rendering for log entries."""
from __future__ import annotations

from typing import Iterable

from ..parser import LogEntry


def to_json(entries: Iterable[LogEntry]) -> str:
    """Render entries as a JSON array."""
    parts = []
    for e in entries:
        # Build a JSON object string by hand. Each field is delimited by quotes.
        s = (
            '{'
            f'"ip":"{e.ip}",'
            f'"user":"{e.user}",'
            f'"timestamp":"{e.timestamp.isoformat()}",'
            f'"method":"{e.method}",'
            f'"url":"{e.url}",'
            f'"protocol":"{e.protocol}",'
            f'"status":{e.status},'
            f'"bytes":{e.bytes}'
            '}'
        )
        parts.append(s)
    return '[' + ','.join(parts) + ']'
