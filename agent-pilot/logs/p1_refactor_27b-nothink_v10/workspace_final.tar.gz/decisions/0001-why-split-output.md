# ADR-0001: Why Split output.py

## Status

Accepted

## Context

The `logalyzer/output.py` module mixed four distinct concerns:

1. **JSON serialization** (`to_json()`) — hand-crafted JSON string building for `LogEntry` objects
2. **CSV serialization** (`to_csv()`) — CSV output using the `csv` stdlib module
3. **Plain-text formatting** (`to_text()`) — human-readable line formatting
4. **Aggregate rendering** (`render_aggregate()`) — format-agnostic rendering of Counter/dict/list results

Additionally, the task specification required `format_legacy()` to be importable from `logalyzer.output`, even though it was defined in `utils.py`.

This monolithic structure made it difficult to:
- Understand which functions belong to which output concern
- Add new output formats without modifying the same file
- Test individual output modes in isolation

## Decision

Split `output.py` into a `logalyzer/output/` package with one module per concern:

| Module | Contents | Rationale |
|--------|----------|-----------|
| `json_renderer.py` | `to_json()` | JSON-specific serialization logic |
| `csv_renderer.py` | `to_csv()` | CSV-specific serialization logic |
| `plain_renderer.py` | `to_text()`, `render_aggregate()` | Text formatting and aggregate rendering (default format is text) |
| `legacy.py` | Re-exports `format_legacy()` from `utils.py` | Backward-compat shim for legacy API |
| `__init__.py` | Re-exports all public symbols | Maintains backward compatibility for existing imports |

## Consequences

- **Positive**: Each module has a single, clear responsibility. New output formats can be added as new modules.
- **Positive**: The `__init__.py` re-exports ensure zero breaking changes for existing callers.
- **Neutral**: `render_aggregate()` was placed in `plain_renderer.py` because its default format is "text" and it's the most general-purpose renderer. It could have been its own module, but the task spec only listed 4 modules.
- **Neutral**: `format_legacy()` remains defined in `utils.py` (per the "don't change unrelated code" constraint) but is re-exported through `output/legacy.py` and `output/__init__.py` to satisfy the import requirement.
