# ADR-0002: Public API Shape

## Status

Accepted

## Context

The `logalyzer/output` module is imported by `cli.py` with:

```python
from .output import render_aggregate, to_csv, to_json, to_text
```

Additionally, the task requires that `format_legacy` be importable from `logalyzer.output`:

```python
from logalyzer.output import format_legacy
```

## Decision

The `output/__init__.py` re-exports exactly these 5 symbols:

| Symbol | Source Module | Used By |
|--------|--------------|---------|
| `to_json` | `json_renderer.py` | `cli.py` |
| `to_csv` | `csv_renderer.py` | `cli.py` |
| `to_text` | `plain_renderer.py` | `cli.py` |
| `render_aggregate` | `plain_renderer.py` | `cli.py` |
| `format_legacy` | `legacy.py` (re-exported from `utils.py`) | External scripts (backward compat) |

## Rationale

1. **Backward compatibility**: Every symbol that was previously importable from `logalyzer.output` remains importable from the same path.
2. **No new public API**: We don't expose any symbols that weren't already public.
3. **`format_legacy` placement**: Although `format_legacy` is defined in `utils.py`, the task requires it to be importable from `logalyzer.output`. We achieve this by re-exporting it through `output/legacy.py` and `output/__init__.py`. This keeps `utils.py` unchanged while satisfying the import requirement.
4. **`render_aggregate` placement**: This function was placed in `plain_renderer.py` because:
   - Its default format is "text"
   - It's a higher-level rendering function that doesn't fit neatly into JSON/CSV/legacy categories
   - The task spec only listed 4 modules, and text is the closest fit

## Consequences

- All existing import paths continue to work without modification.
- The `__all__` list in `__init__.py` explicitly documents the public API surface.
- Internal module imports (e.g., `from logalyzer.output.json_renderer import to_json`) are possible but not part of the public API.
