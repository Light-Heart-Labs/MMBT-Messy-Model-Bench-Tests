# Dead Ends

## Pre-existing Bugs (Not Fixed)

### Bug 1: `status_filter` doesn't handle string input

**Location**: `logalyzer/filters.py`, `status_filter()`

**Issue**: The function compares `entry.status == status` directly. When the CLI passes `--status "404"` as a string, the comparison `"404" == 404` is `False`. The test `test_status_filter_works_with_cli_string_input` expects this to work.

**Fix would be**: Convert `status` to int, or compare `str(entry.status) == str(status)`.

**Not fixed because**: Out of scope for this refactor.

### Bug 2: `url_regex_filter` uses `re.match()` instead of `re.search()`

**Location**: `logalyzer/filters.py`, `url_regex_filter()`

**Issue**: `re.match()` only matches at the start of the string. The test `test_url_regex_finds_substring_match` expects pattern "admin" to match URL "/api/admin/users", but `re.match("admin", "/api/admin/users")` returns `None` because "admin" doesn't appear at position 0.

**Fix would be**: Use `re.search()` instead of `re.match()`.

**Not fixed because**: Out of scope for this refactor.

### Bug 3: "Jul" missing from `MONTH_NAMES` list

**Location**: `logalyzer/parser.py`, `MONTH_NAMES`

**Issue**: The list has "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Aug", "Sep", "Oct", "Nov", "Dec" — "Jul" is missing. The test `test_timestamp_july_parses_correctly` fails because `parse_timestamp("04/Jul/2026:12:00:00 +0000")` raises `ValueError: 'Jul' is not in list`.

**Fix would be**: Add "Jul" to the list between "Jun" and "Aug".

**Not fixed because**: Out of scope for this refactor.

## Approaches Considered and Rejected

### Approach 1: Move `format_legacy` from `utils.py` to `output/legacy.py`

**Rejected because**: The constraint says "Only `logalyzer/output.py` may be split." Moving a function from `utils.py` would modify `utils.py`, which is not allowed.

### Approach 2: Create a 5th module `aggregate_renderer.py` for `render_aggregate()`

**Rejected because**: The task spec explicitly lists only 4 modules. `render_aggregate()` was placed in `plain_renderer.py` since its default format is text.

### Approach 3: Keep `output.py` as a thin wrapper that imports from submodules

**Rejected because**: The task says to "split" the module, not to create a wrapper. The old `output.py` should be removed and replaced by the `output/` package.

## Minimal Compatibility Fix

### `collections.Iterable` → `collections.abc.Iterable`

**Location**: `logalyzer/filters.py`, line 5

**Issue**: `from collections import Iterable` fails on Python 3.10+ (the import was deprecated in 3.3 and removed in 3.10).

**Fix applied**: Changed to `from collections.abc import Iterable`.

**Rationale**: This is not a behavioral change — it's a Python version compatibility fix required to make the test suite runnable. Without it, no tests can execute. The task requires `pytest -q` to pass, which is impossible without this fix.
