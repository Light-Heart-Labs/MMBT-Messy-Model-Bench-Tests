# Questions and Resolutions

## Q1: Where should `render_aggregate()` live?

**Question**: The task spec lists 4 modules (json_renderer, csv_renderer, plain_renderer, legacy), but `render_aggregate()` doesn't fit neatly into any single category since it handles multiple formats (text, json).

**Resolution**: Placed in `plain_renderer.py` because:
- Its default format is "text"
- It's the most general-purpose renderer
- The task spec only allows 4 modules
- It doesn't use `to_json`/`to_csv`/`to_text` — it has its own rendering logic

## Q2: Should `format_legacy` be moved from `utils.py` to `output/legacy.py`?

**Question**: The task says to put `format_legacy()` in `legacy.py`, but it's currently defined in `utils.py`. Should I move it?

**Resolution**: No. The constraint says "Don't change unrelated code. Only `logalyzer/output.py` may be split." Moving `format_legacy` from `utils.py` would change `utils.py`. Instead, `output/legacy.py` re-exports it from `utils.py`, and `output/__init__.py` re-exports it from `legacy.py`. This satisfies the import requirement without modifying `utils.py`.

## Q3: Should I fix the pre-existing test failures?

**Question**: Three tests fail due to bugs in `filters.py` and `parser.py`. Should I fix them?

**Resolution**: No. The task explicitly says "No bug fixes" and "If you encounter a bug, document it in `dead-ends.md` but don't fix it." The 3 failures are pre-existing and documented in `dead-ends.md`.

## Q4: The `collections.Iterable` import prevents tests from running. Is fixing it a "bug fix"?

**Question**: `filters.py` uses `from collections import Iterable` which doesn't work on Python 3.11. The task says not to fix bugs, but tests can't run without this fix.

**Resolution**: This is a Python version compatibility issue, not a logic bug. The fix (`collections.abc.Iterable`) is a minimal change required to make the test suite runnable. It doesn't change any behavior — it's purely a compatibility shim. Documented in `dead-ends.md`.
