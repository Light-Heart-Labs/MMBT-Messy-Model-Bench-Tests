# Research Notes — Password Manager Evaluation

**Date:** 2025-06-18
**Researcher:** Security Advisory

## Products Evaluated

1. **1Password (Business)** — $7.99/user/month (annual)
2. **Bitwarden (Teams)** — $4.00/user/month
3. **LastPass (Business)** — Pricing not publicly listed
4. **Dashlane (Business)** — $8.00/user/month (annual)
5. **Keeper (Business)** — $4.00/user/month (annual)

## Key Findings

### Pricing Summary (50 seats, annual)
| Product | Per Seat | 50 Seats Annual |
|---|---|---|
| 1Password Business | $7.99/mo | $4,794 |
| Bitwarden Teams | $4.00/mo | $2,400 |
| LastPass Business | Unknown | Unknown |
| Dashlane Business | $8.00/mo | $4,800 |
| Keeper Business | $4.00/mo | $2,400 |

### Security Posture
- **1Password:** SOC 2 Type II, dual-key encryption, no breaches, third-party audits
- **Bitwarden:** SOC 2 Type II, ISO 27001, open source, no breaches
- **LastPass:** AES-256, zero-knowledge, **2022 data breach** (encrypted vault data, master password hashes, 2FA seeds exposed)
- **Dashlane:** Zero-knowledge, AES-256-CBC-HMAC, Argon2d, 8 patents, AWS Nitro Enclaves
- **Keeper:** SOC 2 (10+ years), ISO 27001/27017/27018, FedRAMP High, HIPAA, PCI DSS

### Developer Tooling
- **1Password:** `op` CLI (best-in-class), REST API, GitHub/GitLab/CI/CD integrations, Secrets Automation
- **Bitwarden:** `bw` CLI (open source), REST API, CI/CD integrations, Secrets Manager (separate product)
- **LastPass:** Limited CLI, REST API, Secrets Server (separate product)
- **Dashlane:** API/CLI, REST API, Secrets (separate product)
- **Keeper:** Commander CLI, REST API, Secrets Manager (separate product)

### Data Collection Challenges
- LastPass does not publicly display business pricing on their website
- Dashlane pricing required Playwright browser rendering (JS-rendered page)
- Keeper pricing required Playwright browser rendering
- BleepingComputer articles behind Cloudflare challenge
- 1Password compliance/trust pages returned 404

### Recommendation
**1Password Business** — Best overall for a 50-person engineering team due to:
1. Best developer tooling (CLI, CI/CD integration)
2. Strong security posture with no breach history
3. SOC 2 Type II certification
4. Transparent pricing
5. Excellent admin console with SSO, SCIM, audit logging

**Runner-up: Bitwarden Teams** — Best for budget-conscious teams or those requiring open source/self-hosting.

## Tools Used
- `curl` for initial page fetching
- `python3` with `playwright` for JS-rendered page scraping
- `re` module for text extraction and pattern matching
- PCMag review article as cross-validation source

## Files Generated
- `/workspace/recommendation.md` — Main recommendation memo
- `/workspace/comparison.md` — Side-by-side comparison table
- `/workspace/sources.md` — All URLs with timestamps and descriptions
- `/workspace/research/notes.md` — This file
- `/workspace/decisions/001-product-selection.md` — ADR: which 5 products
- `/workspace/decisions/002-evaluation-criteria.md` — ADR: evaluation criteria
- `/workspace/decisions/003-pricing-sources.md` — ADR: pricing data sources
- `/workspace/README.md` — How to read this output
