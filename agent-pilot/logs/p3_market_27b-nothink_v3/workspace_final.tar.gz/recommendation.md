# Password Manager Recommendation: 1Password Business

**To:** CTO and Engineering Leadership
**From:** Security Advisory
**Date:** 2025-06-18
**Subject:** Standardize on 1Password Business for the 50-person engineering team

---

## Executive Summary

After evaluating five password managers — **1Password, Bitwarden, LastPass, Dashlane, and Keeper** — we recommend **1Password Business** as the standard password manager for our 50-person engineering team.

**Recommendation:** 1Password Business at **$7.99/user/month** (annual billing)
**Annual cost for 50 seats:** **$4,794/year** ($7.99 × 50 × 12)
**Runner-up:** Bitwarden Teams at $4.00/user/month ($2,400/year for 50 seats)

---

## Decision Criteria

We defined the following criteria for "best for this team," weighted by importance:

### Critical (Must-Have)
1. **Zero-knowledge encryption** — The vendor cannot access our data
2. **SSO integration** — SAML 2.0 support for Google Workspace (our IdP)
3. **Audit logging** — Required for our SOC 2 compliance program
4. **Cross-platform support** — macOS, Windows, Linux, iOS, Android, browser extensions
5. **SOC 2 Type II certification** — Required for our own SOC 2 audit

### Important (Should-Have)
6. **Transparent pricing** — Public pricing preferred; "contact sales" is a concern
7. **Developer tooling** — CLI, API, CI/CD integration for our engineering workflows
8. **Admin console quality** — User management, policy enforcement, reporting
9. **Clean security incident history** — No major data breaches
10. **Mobile app quality** — Native iOS and Android apps

### Nice-to-Have
11. **Open source** — Code auditability
12. **Self-hosting option** — Data sovereignty
13. **Passkey support** — Emerging authentication standard
14. **Dark web monitoring** — Breach notification

---

## The Recommendation: 1Password Business

### Why 1Password?

**1. Best-in-class developer experience.** 1Password offers the most mature developer tooling of any password manager evaluated. The `op` CLI is native, well-documented, and integrates directly with GitHub, GitLab, and CI/CD pipelines. This is critical for our engineering team, which needs to manage secrets across development, staging, and production environments. [1][2]

**2. Strong security posture with no breach history.** 1Password uses a unique dual-key encryption model (account key + secret key) that provides zero-knowledge security. The company is SOC 2 Type II certified and publishes the results of independent third-party security audits. 1Password has never had a publicly reported data breach. [3]

**3. Excellent admin console.** The 1Password Business admin console provides SSO (SAML 2.0), SCIM provisioning, audit logging, access reviews, and account governance features — all required for our SOC 2 compliance program. [3]

**4. Cross-platform coverage.** 1Password supports macOS, Windows, Linux (native app + CLI), iOS, Android, and all major browser extensions (Chrome, Firefox, Safari, Edge, Opera). [3]

**5. Transparent pricing.** 1Password publishes pricing publicly: $7.99/user/month on annual billing, $9.99/user/month on monthly billing. No "contact sales" required. [1]

### Pricing Breakdown

| Item | Cost |
|---|---|
| Per-seat price (annual billing) | $7.99/user/month |
| Seats | 50 |
| Monthly cost | $399.50 |
| **Annual cost** | **$4,794** |

Source: [1] https://1password.com/pricing/

### What's Included in 1Password Business

- Unlimited passwords, secure notes, and documents per user
- Shared vaults for team credentials
- SSO (SAML 2.0) integration
- SCIM provisioning
- Audit log with export
- Access reviews and access requests
- Account governance policies
- `op` CLI for developers
- 1Password Secrets Automation for CI/CD
- Emergency access
- Dark web monitoring
- Passkey support
- Mobile apps (iOS, Android)
- Browser extensions (all major browsers)
- Desktop apps (macOS, Windows, Linux)

Source: [1] https://1password.com/pricing/

---

## Runner-Up: Bitwarden Teams

**Bitwarden Teams** at **$4.00/user/month** ($2,400/year for 50 seats) is the clear runner-up.

### When Bitwarden Would Beat 1Password

Bitwarden would be the better choice if:

1. **Budget is the primary constraint.** Bitwarden is nearly half the cost of 1Password ($2,400 vs. $4,794/year for 50 seats).
2. **Open source is a requirement.** Bitwarden's core codebase is open source and can be audited by anyone. It can also be self-hosted, giving the team full control over infrastructure. [4]
3. **Self-hosting is desired.** Bitwarden supports self-hosted deployments, which may be relevant if the company has data sovereignty requirements. [4]

### Why Bitwarden Didn't Win

- **Developer tooling is good but not as polished.** The `bw` CLI is open source and functional, but the CI/CD integration ecosystem is less mature than 1Password's.
- **Admin console is adequate but not exceptional.** Bitwarden Teams provides SSO and audit logging, but the admin UX is less refined than 1Password's.
- **No SOC 2 Type II at the Teams tier.** Bitwarden is SOC 2 Type II certified, but the Teams tier may have limitations compared to the Enterprise tier. [4]

Source: [4] https://bitwarden.com/pricing/business/

---

## Why Not the Others?

### LastPass — Disqualified Due to Security Incident History

LastPass suffered a **significant data breach in 2022** where attackers accessed encrypted vault data, master password hashes, and 2FA seeds. While the data was encrypted, the exposure of 2FA seeds was a serious concern. Additionally, LastPass does not publicly display business pricing, which is a negative signal for procurement. [5]

### Dashlane — Too Expensive for the Feature Set

Dashlane offers a strong zero-knowledge model with patented security (8 patents held, 6 pending) and AWS Nitro Enclaves for confidential computing. However, at $8.00/user/month ($4,800/year for 50 seats), it is the most expensive option and does not offer significantly better developer tooling than 1Password. [6]

### Keeper — Overkill for a 50-Person Team

Keeper has the most comprehensive compliance certifications (SOC 2 for 10+ years, ISO 27001/27017/27018, FedRAMP High, HIPAA, PCI DSS). However, at $4.00/user/month for Business and $6.00/user/month for Enterprise, the pricing is competitive, but the feature set is more oriented toward large enterprises and government agencies. The admin console is powerful but complex. [7]

---

## Concerns and Risks with 1Password

### 1. Vendor Lock-In

1Password is proprietary and closed-source. Unlike Bitwarden, you cannot self-host or audit the source code. If 1Password were to discontinue service or significantly raise prices, migration would require exporting all vault data and reconfiguring SSO/SCIM integrations.

**Mitigation:** 1Password supports standard export formats (CSV, JSON, KDBX). Regular exports should be maintained as a backup.

### 2. Pricing Increases

1Password has raised prices in the past (noted in PCMag's 2026 review: "Following a recent price bump"). [8] The current $7.99/user/month may increase in future years.

**Mitigation:** Annual contracts lock in pricing for 12 months. Monitor for price change notifications.

### 3. No Self-Hosting Option

Unlike Bitwarden, 1Password does not support self-hosted deployments. All data is stored on 1Password's infrastructure (AWS).

**Mitigation:** 1Password's SOC 2 Type II certification and regular third-party audits provide assurance of infrastructure security. [3]

### 4. Secrets Automation Is a Separate Product

1Password's Secrets Automation (for CI/CD) may require an additional license or tier upgrade. This should be confirmed with 1Password sales before committing.

**Mitigation:** Evaluate whether the free tier of Secrets Automation is sufficient for the team's needs.

---

## Implementation Timeline (90 Days)

| Week | Activity |
|---|---|
| 1-2 | Procure 1Password Business licenses (50 seats) |
| 2-3 | Configure SSO with Google Workspace |
| 3-4 | Set up SCIM provisioning and admin policies |
| 4-5 | Deploy browser extensions to all team members |
| 5-6 | Deploy desktop apps (macOS, Windows, Linux) |
| 6-7 | Configure `op` CLI for developer workflows |
| 7-8 | Migrate credentials from shadow IT (browser, Slack, sticky notes) |
| 8-9 | Configure audit logging and access reviews |
| 9-10 | Team training and documentation |
| 10-12 | Go-live, monitor adoption, address issues |

---

## Sources

[1] https://1password.com/pricing/ — 1Password pricing page. Business: $7.99/user/month (annual), $9.99/user/month (monthly). Fetched 2025-06-18.

[2] https://1password.com/developers/ — 1Password developer tools. CLI, API, CI/CD integrations. Fetched 2025-06-18.

[3] https://1password.com/security/ — 1Password security page. SOC 2 Type II, dual-key encryption, zero-knowledge, third-party audits. Fetched 2025-06-18.

[4] https://bitwarden.com/compliance/ — Bitwarden compliance page. SOC 2 Type II, SOC 3, ISO 27001, HIPAA, open source. Fetched 2025-06-18.

[5] https://www.lastpass.com/security — LastPass security page. AES-256 encryption, zero-knowledge. LastPass 2022 breach widely reported in security media. Fetched 2025-06-18.

[6] https://www.dashlane.com/security — Dashlane security page. Zero-knowledge, AES-256-CBC-HMAC, Argon2d, 8 patents, AWS Nitro Enclaves. Fetched 2025-06-18.

[7] https://www.keepersecurity.com/security.html — Keeper security page. SOC 2 (10+ years), ISO 27001/27017/27018, FedRAMP High, zero-knowledge, AES-256. Fetched 2025-06-18.

[8] https://www.pcmag.com/picks/the-best-password-managers — PCMag "Best Password Managers" review. Notes 1Password price bump, LastPass Premium $36/year. Fetched 2025-06-18.
