# Password Manager Evaluation — Output Files

This directory contains the output of a password manager evaluation for a 50-person engineering team at a Series-B SaaS company.

## Files

| File | Description |
|---|---|
| `recommendation.md` | **Primary deliverable.** 1-2 page recommendation memo with decision criteria, product recommendation, pricing, runner-up, and concerns. |
| `comparison.md` | Side-by-side feature/pricing/security comparison of the 5 evaluated products. |
| `sources.md` | Every URL fetched during research, with timestamp and description of what was obtained. |
| `research/notes.md` | Working notes from the research process. |
| `decisions/001-product-selection.md` | ADR: Which 5 products were evaluated and why. |
| `decisions/002-evaluation-criteria.md` | ADR: Decision criteria used for evaluation. |
| `decisions/003-pricing-sources.md` | ADR: How pricing data was sourced and known gaps. |

## How to Read

1. **Start with `recommendation.md`** — This is the primary deliverable with the final recommendation.
2. **Reference `comparison.md`** — For detailed feature-by-feature comparison of all 5 products.
3. **Check `sources.md`** — For verification of every factual claim. Every numeric or factual claim in the recommendation is linked to a source URL.
4. **Review `decisions/`** — For the reasoning behind non-obvious calls (which products, what criteria, how pricing was sourced).
5. **See `research/notes.md`** — For working notes and the research process.

## Products Evaluated

1. **1Password (Business)** — $7.99/user/month (annual billing)
2. **Bitwarden (Teams)** — $4.00/user/month
3. **LastPass (Business)** — Pricing not publicly listed
4. **Dashlane (Business)** — $8.00/user/month (annual billing)
5. **Keeper (Business)** — $4.00/user/month (annual billing)

## Recommendation

**1Password Business** at $7.99/user/month ($4,794/year for 50 seats).

**Runner-up:** Bitwarden Teams at $4.00/user/month ($2,400/year for 50 seats).

## Research Methodology

- Product websites fetched via `curl` and Playwright (for JS-rendered pages)
- Pricing data cross-referenced with PCMag review article
- Security/compliance data obtained from each product's security and compliance pages
- All factual claims are linked to source URLs in `sources.md`
