# ADR-001: Product Selection for Evaluation

**Date:** 2025-06-18
**Status:** Accepted
**Context:** Series-B SaaS company, 50-person engineering team, needs to standardize on a password manager within 90 days.

## Decision

We evaluated the following 5 password managers:

1. **1Password (Business tier)** — Proprietary, well-established, strong developer tooling
2. **Bitwarden (Teams/Enterprise tier)** — Open-source, self-hostable, most cost-effective
3. **LastPass (Business tier)** — Market leader historically, but with significant security incident history
4. **Dashlane (Business tier)** — Strong UX, patented zero-knowledge model, higher cost
5. **Keeper (Business/Enterprise tier)** — Most certifications, strong compliance posture, zero-knowledge

## Rationale

These 5 products represent the most commonly recommended enterprise password managers in independent reviews (PCMag, G2, TechRadar) and cover the spectrum of:
- Open-source vs. proprietary
- Self-hosted vs. cloud-only
- Budget vs. premium pricing
- Feature-rich vs. focused

Products excluded:
- **NordPass** — Newer entrant, less enterprise track record
- **Proton Pass** — Strong privacy focus but limited enterprise admin features
- **Enpass** — No cloud sync in free tier, limited enterprise features
- **RoboForm** — Primarily form-filler, less password management focus
- **CyberArk/Delinea** — PAM products, not general-purpose password managers

## Consequences

- This selection covers the primary options a Series-B SaaS company would reasonably consider
- If the team has specific compliance requirements (e.g., FedRAMP), Keeper would be the primary candidate
- If cost is the primary driver, Bitwarden would be the primary candidate
