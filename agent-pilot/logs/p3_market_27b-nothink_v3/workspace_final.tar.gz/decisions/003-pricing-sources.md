# ADR-003: Pricing Data Sources

**Date:** 2025-06-18
**Status:** Accepted
**Context:** Several password managers do not publicly display pricing on their websites.

## Decision

Pricing data was sourced from:
1. **Direct product websites** — 1Password, Bitwarden, Keeper (via Playwright-rendered pages)
2. **PCMag review article** — For LastPass and cross-validation of other products
3. **Product pricing pages** — Dashlane (via Playwright-rendered pages)

## Rationale

- 1Password, Bitwarden, and Keeper display pricing on their websites
- LastPass does not publicly display business pricing on their website; PCMag was used as a secondary source
- Dashlane pricing was obtained from their pricing page via browser rendering
- All pricing figures are cross-referenced where possible

## Known Gaps

- **LastPass business pricing** — Not publicly listed on LastPass.com; PCMag reports "Plans Starting as Low as $3 Per Month" for personal plans. Business pricing requires contacting sales. This is flagged as a concern.
- **1Password Business pricing** — $7.99/user/month (annual billing) confirmed from 1password.com/pricing
- **Bitwarden Teams pricing** — $4/user/month confirmed from bitwarden.com/pricing
- **Dashlane Business pricing** — $8/user/month (annual billing) confirmed from dashlane.com/pricing
- **Keeper Business pricing** — $4/user/month (annual billing) confirmed from keepersecurity.com/pricing

## Consequences

- LastPass's lack of transparent pricing is a negative signal for procurement
- All other products have publicly verifiable pricing
