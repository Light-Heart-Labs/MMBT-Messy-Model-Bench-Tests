# ADR-002: Evaluation Criteria

**Date:** 2025-06-18
**Status:** Accepted
**Context:** Series-B SaaS company, 50-person engineering team.

## Decision

The following criteria were used to evaluate password managers, weighted by importance:

### Critical (Must-Have)
1. **Zero-knowledge encryption** — Vendor cannot access user data
2. **SSO integration** — SAML 2.0 support for Google Workspace (or other IdP)
3. **Audit logging** — Required for SOC 2 compliance
4. **Cross-platform support** — macOS, Windows, Linux, iOS, Android, browser extensions
5. **SOC 2 Type II certification** — Required for our own SOC 2 compliance

### Important (Should-Have)
6. **Pricing transparency** — Public pricing preferred; "contact sales" is a concern
7. **Developer tooling** — CLI, API, CI/CD integration
8. **Admin console quality** — User management, policy enforcement, reporting
9. **Security incident history** — Past breaches are a negative signal
10. **Mobile app quality** — iOS and Android native apps

### Nice-to-Have
11. **Open source** — Code auditability
12. **Self-hosting option** — Data sovereignty
13. **Passkey support** — Emerging standard
14. **Dark web monitoring** — Breach notification
15. **Emergency access** — Account recovery for departed employees

## Rationale

- SOC 2 Type II is non-negotiable for a Series-B SaaS company preparing for its own SOC 2 audit
- SSO integration is critical for a 50-person team to avoid managing separate credentials
- Developer tooling is important because the team uses CI/CD pipelines and needs CLI access
- Security incident history matters because the team is moving away from insecure practices

## Consequences

- Products without SOC 2 Type II certification are disqualified
- Products without SSO support are disqualified
- Products without transparent pricing are flagged as a concern
