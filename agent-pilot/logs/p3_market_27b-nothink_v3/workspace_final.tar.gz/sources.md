# Sources

All URLs fetched during research, with timestamps and descriptions.

## Product Pricing Pages

| # | URL | Timestamp | Description |
|---|---|---|---|
| 1 | https://1password.com/pricing/ | 2025-06-18 | 1Password pricing page. Business: $7.99/user/month (annual), $9.99/user/month (monthly). Teams: $19.95/month (up to 10 users). Individual: $2.99/user/month (annual). |
| 2 | https://bitwarden.com/pricing/ | 2025-06-18 | Bitwarden pricing page. Free, Premium ($1.65/mo), Families ($3.99/mo). |
| 3 | https://bitwarden.com/pricing/business/ | 2025-06-18 | Bitwarden business pricing. Teams: $4/user/month, Enterprise: $6/user/month. |
| 4 | https://www.lastpass.com/fp/business-password-manager | 2025-06-18 | LastPass business page. No public pricing displayed. |
| 5 | https://www.lastpass.com/pricing | 2025-06-18 | LastPass pricing page. No public pricing displayed. |
| 6 | https://www.dashlane.com/pricing/business | 2025-06-18 | Dashlane business pricing. Password Management: $8/user/month (annual). Credential Protection: $4/user/month. |
| 7 | https://www.keepersecurity.com/pricing/business-and-enterprise.html | 2025-06-18 | Keeper business pricing. Business Starter: $2/user/month, Business: $4/user/month, Enterprise: $6/user/month. |

## Product Security Pages

| # | URL | Timestamp | Description |
|---|---|---|---|
| 8 | https://1password.com/security/ | 2025-06-18 | 1Password security page. SOC 2 Type II, dual-key encryption, zero-knowledge, third-party audits, bug bounty. |
| 9 | https://bitwarden.com/security/ | 2025-06-18 | Bitwarden security page. Zero-knowledge, AES-256-CBC, PBKDF2/Argon2, open source. |
| 10 | https://bitwarden.com/compliance/ | 2025-06-18 | Bitwarden compliance page. SOC 2 Type II, SOC 3, ISO 27001, HIPAA, CCPA, CPRA. |
| 11 | https://www.lastpass.com/security | 2025-06-18 | LastPass security page. AES-256 encryption, zero-knowledge, bug bounty program. |
| 12 | https://www.dashlane.com/security | 2025-06-18 | Dashlane security page. Zero-knowledge, AES-256-CBC-HMAC, Argon2d, 8 patents, AWS Nitro Enclaves, confidential computing. |
| 13 | https://www.keepersecurity.com/security.html | 2025-06-18 | Keeper security page. SOC 2 (10+ years), ISO 27001/27017/27018, FedRAMP High, GovRAMP High, HIPAA, PCI DSS, zero-knowledge, AES-256, ECIES. |

## Third-Party Reviews and Comparisons

| # | URL | Timestamp | Description |
|---|---|---|---|
| 14 | https://www.pcmag.com/picks/the-best-password-managers | 2025-06-18 | PCMag "Best Password Managers" review. Pricing: 1Password $47.88/yr (personal), Bitwarden $19.80/yr (premium), LastPass $36/yr (premium), Keeper $39.99/yr (personal), Dashlane $59.88/yr (personal). |
| 15 | https://www.lastpass.com/compare-password-managers | 2025-06-18 | LastPass comparison page. No pricing data. |
| 16 | https://www.dashlane.com/compare | 2025-06-18 | Dashlane comparison page. |

## Additional Pages Fetched

| # | URL | Timestamp | Description |
|---|---|---|---|
| 17 | https://1password.com/business/ | 2025-06-18 | 1Password business features page. |
| 18 | https://1password.com/compliance/ | 2025-06-18 | 1Password compliance page (404). |
| 19 | https://1password.com/trust/ | 2025-06-18 | 1Password trust page (404). |
| 20 | https://support.1password.com/security-audits/ | 2025-06-18 | 1Password security audits page (Access Denied). |
| 21 | https://www.lastpass.com/compare | 2025-06-18 | LastPass comparison page. |
| 22 | https://www.dashlane.com/business-password-manager | 2025-06-18 | Dashlane business features page. |
| 23 | https://www.keepersecurity.com/pricing | 2025-06-18 | Keeper pricing landing page. |
| 24 | https://www.keepersecurity.com/security | 2025-06-18 | Keeper security landing page. |
| 25 | https://www.keepersecurity.com/pricing/business | 2025-06-18 | Keeper business pricing page. |
| 26 | https://www.keepersecurity.com/compare | 2025-06-18 | Keeper comparison page. |
| 27 | https://www.techradar.com/best/best-password-manager | 2025-06-18 | TechRadar password manager comparison (no pricing data). |
| 28 | https://www.capterra.com/password-management-software/ | 2025-06-18 | Capterra password management software listing (no pricing data). |
| 29 | https://www.softwareadvice.com/password-management/ | 2025-06-18 | SoftwareAdvice password management listing (no pricing data). |
| 30 | https://www.trustedreviews.com/best/best-password-manager | 2025-06-18 | TrustedReviews password manager comparison (no pricing data). |

## Notes on Data Collection

- **1Password, Bitwarden, Keeper:** Pricing obtained directly from product websites via curl and Playwright browser rendering.
- **Dashlane:** Pricing obtained via Playwright browser rendering of https://www.dashlane.com/pricing/business.
- **LastPass:** Business pricing not publicly displayed on LastPass.com. Personal pricing ($36/year) obtained from PCMag review. Business pricing requires contacting sales.
- **Security/compliance data:** Obtained from each product's security and compliance pages via Playwright browser rendering.
- **PCMag review:** Used as a cross-validation source for pricing and feature claims.
