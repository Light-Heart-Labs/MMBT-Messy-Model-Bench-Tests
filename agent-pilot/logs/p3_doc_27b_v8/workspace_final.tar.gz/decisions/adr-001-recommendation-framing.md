# ADR-001: Recommendation Framing — "PASS" vs. "MORE DILIGENCE NEEDED"

**Status:** Accepted
**Date:** 2026-03-10

## Context

The brief requires "one clear recommendation." The evidence presents mixed signals: strong investor syndicate and technology quality vs. customer concentration, ARR overstatement, and negative unit economics.

## Decision

Use **"PASS at current valuation; re-engage at Series C"** as the recommendation.

## Rationale

- "More diligence needed" is hedging. The available evidence is sufficient to form a view: the $560M valuation is not supportable given the known risks.
- "Pass" is a clear stance. The qualifier "at current valuation" acknowledges that the company may become investable later.
- "Re-engage at Series C" provides a constructive path forward, showing the brief isn't dismissive of the company's long-term potential.
- The "What Would Change My View" section provides the specific diligence items that would alter the recommendation, satisfying the need for actionable next steps.

## Consequences

- The recommendation is unambiguous and defensible.
- It avoids the trap of saying "on the one hand X, on the other hand Y."
- It leaves the door open for future engagement without committing capital now.

---

# ADR-002: Treatment of Former Employee's Financial Numbers

**Status:** Accepted
**Date:** 2026-03-10

## Context

The former employee blog post (Source 3) provides specific financial numbers: $4M/month burn, $3.5M/month revenue, 38% customer concentration, 22 layoffs. These are the only source for these figures.

## Decision

Include these numbers but attribute them explicitly to the former employee and use hedging language ("per the former employee," "implying net burn").

## Rationale

- The numbers are internally consistent (the $3.5M/month revenue aligns roughly with the $42M ARR figure when annualized).
- The leaked memo (Source 4) corroborates the general picture: the company needs restructuring, has runway concerns, and is cutting costs.
- However, these are one person's recollection and should not be treated as audited financials.
- The brief uses "per the former employee" and "implying" to maintain appropriate epistemic calibration.

## Consequences

- The brief provides specific financial context that would otherwise be unavailable.
- The attribution makes clear these are not independently verified figures.
- A reviewer can trace the numbers back to Source 3 and assess the credibility themselves.

---

# ADR-003: Structure — Leading with Recommendation

**Status:** Accepted
**Date:** 2026-03-10

## Context

The brief could be structured as: (1) background, (2) findings, (3) recommendation — or as: (1) recommendation, (2) findings, (3) conclusion.

## Decision

Lead with the recommendation, followed by key findings, then positives, source quality notes, and a "what would change my view" section.

## Rationale

- The task specifies the brief is "for a partner who has 5 minutes." Leading with the recommendation respects that constraint.
- The recommendation is the most important piece of information; burying it would be poor practice.
- The "Positives" section is included to show the brief isn't one-sided, but it comes after the key findings so it doesn't dilute the recommendation.
- The "Source Quality Notes" section is included to satisfy the requirement to be "honest about source quality."

## Consequences

- A busy reader can get the recommendation in the first 30 seconds.
- A thorough reader can trace the reasoning through the key findings.
- The structure is scannable and supports the 5-minute reading constraint.
