# Key Facts Incorporated in the Brief

Each fact below traces to one or more of the five source documents.

## Deal Structure & Valuation
| Fact | Source(s) |
|------|-----------|
| $84M Series B raised | [Source 1], [Source 2], [Source 5] |
| Post-money valuation: $560M | [Source 1] |
| Previous Series A valuation: $230M (2023) | [Source 1] |
| Total funding across all rounds: $128M | [Source 1] |
| Lead investor: Lightning Capital | [Source 1], [Source 5] |
| Participating investors: Sequoia, Accel, FedEx Ventures (strategic) | [Source 1], [Source 5] |
| 7 total investors | [Source 5] |
| Security type: Series B Preferred Equity | [Source 5] |
| Filing date: 2026-01-22 | [Source 5] |
| Original target valuation: $720M, repriced down to $560M | [Source 2] |
| Repricing triggered by Sundry non-renewal becoming known in early December | [Source 2] |

## Revenue & Customers
| Fact | Source(s) |
|------|-----------|
| Reported ARR: $42M as of Q4 2025 | [Source 1] |
| Prior-year ARR: $11M | [Source 1] |
| Adjusted run-rate ARR: $36–37M (after churn) | [Source 2] |
| $42M figure includes Sundry and Klatch in their final quarter | [Source 2] |
| 1,400+ e-commerce brands on platform | [Source 1], [Source 2] |
| Named customers: Maevia, Truant Coffee, Brick & Cobble | [Source 1] |
| Sundry Brands: $4.2M ARR, largest contract, non-renewal in November 2025 | [Source 2] |
| Klatch: fast-fashion brand, exited December 2025, migrated to competitor | [Source 2] |
| Company confirmed Sundry non-renewal; characterized as "strategic mutual decision" | [Source 2] |
| Top 5 customers represented ~38% of ARR | [Source 3] |
| CEO claims 110%+ net retention | [Source 2] |
| CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 | [Source 2] |

## Financials & Burn
| Fact | Source(s) |
|------|-----------|
| Monthly burn: ~$4M all-in (mid-2025) | [Source 3] |
| Monthly revenue: ~$3.5M (mid-2025) | [Source 3] |
| Net burn: ~$500K/month (implied) | [Source 3] |
| Runway at current burn: 24+ months | [Source 4] |
| Runway with restructuring: 36+ months | [Source 4] |
| $50M credit facility from Silicon Valley Bridge | [Source 4] |
| Credit facility described as "insurance, not operating capital" | [Source 4] |

## Employees & Organization
| Fact | Source(s) |
|------|-----------|
| 187 employees across Oakland, Austin, Berlin | [Source 1] |
| Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) | [Source 1] |
| 22 people (~11% of org) laid off in February 2025 | [Source 3] |
| Layoffs primarily in customer success and BD | [Source 3] |
| Layoffs not announced publicly | [Source 3] |
| Berlin headcount: 41, planned reduction to 28–30 by end Q2 2026 | [Source 4] |
| 30% reduction in international headcount | [Source 4] |
| Senior engineer compensation: $215K base + $50K equity/year | [Source 3] |

## Product & Strategy
| Fact | Source(s) |
|------|-----------|
| Platform: warehouse management + carrier orchestration + demand forecasting | [Source 1] |
| International expansion deferred to 2027 | [Source 4] |
| Berlin reframed as "support hub" rather than sales/expansion office | [Source 4] |
| Nimbus Lite tier being sunset; ~310 small customers ($5K–$20K ARR each) affected | [Source 4] |
| 90-day notice given to Nimbus Lite customers | [Source 4] |
| Restructuring targets cash-flow breakeven by Q4 2026 | [Source 4] |
| Breakeven is trigger for Series C conversations | [Source 4] |
| Use of proceeds: "expansion, working capital, general corporate purposes" | [Source 5] |

## Technology & Culture
| Fact | Source(s) |
|------|-----------|
| Carrier-orchestration layer described as "some of the cleanest distributed-systems code" | [Source 3] |
| CTO Daniel Wong praised as "the real deal" | [Source 3] |
| "Customer love is real" among mid-market brands | [Source 3] |
| Sundry loss "was not a shock to the team" | [Source 3] |
| Customer concentration "widely understood internally" | [Source 3] |
