# Working Notes — Nimbus Logistics Source Analysis

## Source-by-Source Summary

### Source 1: Press Release (2026-01-14)
- $84M Series B led by Lightning Capital
- Post-money valuation: $560M (up from $230M Series A in 2023)
- Total funding: $128M across all rounds
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400+ e-commerce brands on platform
- 187 employees across Oakland, Austin, Berlin
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (strategic)
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO)
- Platform: warehouse management + carrier orchestration + demand forecasting
- Named customers: Maevia, Truant Coffee, Brick & Cobble

### Source 2: TechCrunch (2026-01-15)
- Lost two top-five customers in late 2025:
  - Sundry Brands: $4.2M ARR, largest contract, non-renewal in November
  - Klatch: fast-fashion brand, exited December, migrated to competitor
- ARR adjusted for churn: $36-37M (vs. $42M in press release)
- $42M figure includes both contracts in their final quarter
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026
- Net retention claimed above 110%
- Series B was meant to close at $720M valuation but repriced down to $560M after Sundry news
- Repricing happened after lead investor learned of Sundry non-renewal in early December

### Source 3: Former Employee Blog (2026-02-22)
- Author: "Daniel R", former senior engineer, 14 months at Nimbus
- Positive: good architecture, strong CTO (Daniel Wong), genuine customer love, competitive comp ($215K base + $50K equity/year)
- Negative:
  - Burn: ~$4M/month all-in (mid-2025), revenue ~$3.5M/month → net burn ~$500K/month
  - Layoffs: 22 people (~11% of org) cut in February 2025, mostly customer success and BD, not publicly announced
  - Customer concentration: top 5 customers = ~38% of ARR
  - Sundry loss was not a shock internally
  - Path to profitability requires faster growth or significant cuts
- Would recommend for senior engineers, not for those needing job security

### Source 4: Leaked Internal Memo (2026-03-05)
- Dated February 28, 2026, from CEO Mira Patel
- Restructuring plan for cash-flow breakeven by Q4 2026
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
- International expansion deferred to 2027; Berlin reframed as "support hub"
- Nimbus Lite tier sunset: ~310 customers ($5K-$20K ARR each), 90-day notice
- New $50M credit facility from Silicon Valley Bridge ("insurance, not operating capital")
- Runway: 24+ months at current burn, extended to 36+ months with restructuring
- Breakeven by Q4 2026 is trigger for Series C conversations

### Source 5: SEC Form D (filed 2026-01-22)
- Confirms $84M offering, all sold
- 7 investors total
- Securities: Series B Preferred Equity
- First sale date: 2026-01-14
- No executive compensation disclosed in connection with offering
- Use of proceeds: "expansion, working capital, general corporate purposes"

## Key Tensions Identified

1. **ARR discrepancy**: $42M (press release) vs. $36-37M adjusted (TechCrunch sources)
2. **Valuation repricing**: $720M → $560M due to customer losses
3. **Customer concentration**: Top 5 = 38% of ARR (blog), loss of largest customer ($4.2M)
4. **Burn rate**: $4M/month vs. $3.5M/month revenue (blog) = net negative
5. **Layoffs not disclosed**: 22 people cut in Feb 2025, not announced publicly
6. **International pivot**: Berlin expansion deferred, headcount cut 30%
7. **Product tier sunset**: Nimbus Lite being killed, ~310 small customers affected
8. **Credit facility**: $50M from Silicon Valley Bridge — signals need for extra runway

## Source Quality Assessment

- **Source 1 (Press Release)**: Company narrative, optimistic framing, selective facts
- **Source 2 (TechCrunch)**: Journalistic, cites unnamed sources, company confirmed Sundry loss
- **Source 3 (Blog)**: One ex-employee's perspective, specific numbers but unverified, potentially biased
- **Source 4 (Leaked Memo)**: Internal document, likely accurate on company plans, leaked to journalist
- **Source 5 (SEC Form D)**: Regulatory filing, factual on deal structure, limited detail

## Numbers Cross-Check

| Metric | Source 1 | Source 2 | Source 3 | Source 4 | Source 5 |
|--------|----------|----------|----------|----------|----------|
| Series B amount | $84M | $84M | - | - | $84M |
| Post-money valuation | $560M | (was $720M) | - | - | - |
| ARR | $42M | $36-37M adj. | ~$42M ($3.5M/mo) | - | - |
| Total funding | $128M | - | - | - | - |
| Employees | 187 | - | - | Berlin: 41→28-30 | - |
| Monthly burn | - | - | ~$4M | - | - |
| Monthly revenue | - | - | ~$3.5M | - | - |
| Customers | 1,400+ | 1,400 | - | - | - |
