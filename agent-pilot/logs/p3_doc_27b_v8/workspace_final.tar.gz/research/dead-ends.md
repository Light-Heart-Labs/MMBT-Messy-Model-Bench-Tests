# Dead Ends — Ideas Considered and Abandoned

## 1. "More Diligence Needed" as the Primary Recommendation

**Considered:** Framing the brief as "more diligence needed" with a list of questions.

**Abandoned because:** The task explicitly requires "one clear recommendation" and warns against hedging. A "more diligence needed" stance is a cop-out when the available evidence already points strongly toward passing at current valuation. The recommendation section can still include specific diligence items (which it does in "What Would Change My View").

## 2. Including the $11M Prior-Year ARR Figure Prominently

**Considered:** Leading with the growth story ($11M → $42M ARR) to show the company's trajectory.

**Abandoned because:** This is the press-release narrative. The brief's job is to synthesize all sources, not repeat the company's preferred story. The growth rate is impressive but irrelevant if the current ARR is overstated and the company is burning cash.

## 3. Calculating an Implied ARR Multiple

**Considered:** Computing the ARR multiple ($560M / $42M = ~13.3x) and comparing to industry benchmarks.

**Abandoned because:** No industry benchmark data is available in the sources. Any comparison would require external research, which is forbidden. The brief does note that 8–10x adjusted ARR would be worth consideration at Series C, but this is framed as a general principle rather than a sourced benchmark.

## 4. Treating the Former Employee's Numbers as Ground Truth

**Considered:** Presenting the $4M/month burn and $3.5M/month revenue figures as facts.

**Abandoned because:** These are one person's recollection, unverified by any other source. The brief uses language like "per the former employee" and "implying net burn" to maintain appropriate epistemic humility. The leaked memo corroborates the general picture (restructuring needed, runway concerns) but doesn't confirm the specific numbers.

## 5. Including the Named Customers (Maevia, Truant Coffee, Brick & Cobble)

**Considered:** Listing the named customers from the press release as evidence of quality.

**Abandoned because:** These names add no analytical value. We don't know their contract sizes, satisfaction levels, or whether they're at risk. The brief focuses on the *unnamed* customers whose departures (Sundry, Klatch) are material to the investment thesis.

## 6. Speculating on the Three Additional Investors

**Considered:** Trying to identify the three additional investors not named in the Form D.

**Abandoned because:** The sources don't name them, and speculation would be fabrication. The brief notes there are 7 total investors but doesn't guess at identities.

## 7. Including the Compensation Data ($215K base + $50K equity)

**Considered:** Using the compensation data as evidence of the company's financial health or talent strategy.

**Abandoned because:** While interesting, compensation data doesn't directly inform the investment decision. It's tangential to the core question of whether to invest at current valuation. The brief focuses on financial metrics, customer risk, and strategic direction instead.
