# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Assessment

**Date:** 2026-03-10
**Subject:** Series-B follow-on evaluation

---

## Recommendation: PASS at current valuation; re-engage at Series C

Nimbus Logistics raised $84M in a Series B at $560M post-money, led by Lightning Capital with participation from Sequoia, Accel, and FedEx Ventures [Source 1, Source 5]. The company reports $42M ARR and 1,400+ customers [Source 1].

**The current valuation is not supportable given customer concentration risk, ARR overstatement, and negative unit economics.** I recommend passing now but maintaining a relationship for Series C engagement if the company's restructuring succeeds.

---

## Key Findings

### ARR Is Inflated; Real Run-Rate Is $36–37M

The press release cites $42M ARR as of Q4 2025 [Source 1]. But two top-five customers departed in late 2025: Sundry Brands ($4.2M ARR, the largest contract) did not renew in November, and Klatch exited in December [Source 2]. The company confirmed the Sundry non-renewal [Source 2]. Adjusted for churn, current run-rate is $36–37M [Source 2]. The $42M figure includes both contracts in their final quarter — a timing artifact.

### Valuation Was Repriced Down

The Series B was originally targeted at $720M but was repriced to $560M after the Sundry non-renewal became known to the lead investor in early December [Source 2]. This $160M repricing signals that sophisticated investors already identified the customer concentration risk before the round closed.

### Customer Concentration Is a Material Risk

According to a former senior engineer, the top five customers represented ~38% of ARR [Source 3]. Losing Sundry ($4.2M) alone represents roughly 10% of reported ARR. This concentration was "widely understood internally" and the Sundry departure "was not a shock to the team" [Source 3]. The company's claim of 110%+ net retention [Source 2] is difficult to reconcile with losing its two largest customers in consecutive months.

### The Company Is Net-Burning Cash

Per the former employee, Nimbus was spending ~$4M/month all-in against ~$3.5M/month in revenue as of mid-2025, implying net burn of ~$500K/month [Source 3]. The leaked internal memo confirms the company is pursuing restructuring to reach cash-flow breakeven by Q4 2026 [Source 4]. At current burn, the Series B provides 24+ months of runway; with restructuring, that extends to 36+ months [Source 4].

### Aggressive Restructuring Is Underway

The leaked internal memo (dated February 28, 2026) outlines significant changes:
- **30% reduction in international headcount** (Berlin: 41 → 28–30) [Source 4]
- **International expansion deferred to 2027**; Berlin reframed as a "support hub" [Source 4]
- **Sunsetting the "Nimbus Lite" tier**, affecting ~310 small customers ($5K–$20K ARR each) [Source 4]
- **$50M credit facility** from Silicon Valley Bridge, described as "insurance, not operating capital" [Source 4]

These moves suggest the original growth strategy was not working and management is pivoting to a conservative, profitability-focused approach.

### Layoffs Were Not Publicly Disclosed

The former employee reports 22 people (~11% of the org) were cut in February 2025, primarily in customer success and BD, and this was "not announced publicly" [Source 3]. This lack of transparency is a governance concern.

---

## Positives

- **Strong investor syndicate:** Sequoia, Accel, Lightning Capital, FedEx Ventures [Source 1, Source 5]
- **Competitive technology:** The ex-engineer describes the carrier-orchestration layer as "some of the cleanest distributed-systems code" and praises CTO Daniel Wong [Source 3]
- **Genuine customer relationships:** "Customer love is real" among mid-market brands [Source 3]
- **Clear profitability plan:** Restructuring targets breakeven by Q4 2026 [Source 4]
- **New business momentum:** CEO claims three new $1M+ ARR contracts signed in Q1 2026 [Source 2]

---

## Source Quality Notes

- **Press release [Source 1]:** Company narrative; optimistic framing.
- **TechCrunch [Source 2]:** Cites unnamed sources, but company confirmed the Sundry non-renewal.
- **Former employee blog [Source 3]:** Specific internal numbers (burn, concentration, layoffs) but one person's unverified perspective.
- **Leaked memo [Source 4]:** Internal document; specificity suggests authenticity, but reflects stated intentions, not guaranteed outcomes.
- **SEC Form D [Source 5]:** Confirms deal structure; limited operational detail.

---

## What Would Change My View

1. Evidence that the three new $1M+ contracts [Source 2] have closed and replaced Sundry/Klatch losses.
2. Demonstrated progress on restructuring — Berlin cuts and Nimbus Lite migration completed without significant additional churn.
3. A Series C at a lower valuation — if breakeven is reached by Q4 2026 [Source 4], a follow-on at 8–10x adjusted ARR would warrant serious consideration.
4. Improved transparency — public disclosure of the February 2025 layoffs and current churn metrics.

---

## Bottom Line

Nimbus has real technology and a credible founding team, but the $560M valuation does not reflect customer concentration risk, ARR overstatement, negative unit economics, or the aggressive restructuring underway. The company has 36+ months of runway [Source 4] and a clear profitability plan. **Pass now, watch closely, re-engage at Series C if the restructuring succeeds.**
