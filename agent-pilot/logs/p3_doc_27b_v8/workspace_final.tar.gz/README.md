# How to Read This Output

## Primary Deliverable

**`/workspace/brief.md`** — A 1-page executive brief (~700 words) for an investor evaluating whether to make a follow-on investment in Nimbus Logistics, Inc.

The brief:
- Leads with a clear recommendation: **PASS at current valuation; re-engage at Series C**
- Synthesizes all five source documents, not just the press release
- Highlights tensions between sources (e.g., $42M ARR vs. $36–37M adjusted)
- Cites sources inline using `[Source 1]`, `[Source 2]`, etc.
- Includes a "Source Quality Notes" section acknowledging the reliability of each source
- Ends with specific conditions that would change the recommendation

## Supporting Files

| File | Purpose |
|------|---------|
| `/workspace/key-facts.md` | Complete list of every material fact incorporated in the brief, with source attribution |
| `/workspace/research/notes.md` | Working notes from reading the five source documents |
| `/workspace/research/dead-ends.md` | Ideas considered and abandoned during the analysis |
| `/workspace/decisions/adr-001-recommendation-framing.md` | ADR-style records for non-obvious framing choices |

## Source Mapping

| Source | Type | Reliability |
|--------|------|-------------|
| Source 1 | Press release (company-issued) | Optimistic framing; selective facts |
| Source 2 | TechCrunch news article | Journalistic; cites unnamed sources but company confirmed key claims |
| Source 3 | Former employee blog post | One person's perspective; specific but unverified numbers |
| Source 4 | Leaked internal memo | Internal document; likely authentic but reflects stated intentions |
| Source 5 | SEC Form D filing | Regulatory filing; factual on deal structure |

## Methodology

1. Read all five sources independently
2. Extract material facts and cross-reference across sources
3. Identify tensions and contradictions between sources
4. Form a recommendation based on the weight of evidence
5. Write the brief with inline citations
6. Create supporting documentation for traceability
