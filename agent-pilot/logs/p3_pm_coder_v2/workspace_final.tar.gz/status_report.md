# Project Aurora — Status Report (as of 2026-04-08)

## Headline
Aurora (dashboard refresh + embedded SDK) is on track for a private-beta V1 release in late May/early June, with GA of the dashboard refresh in late July. The embedded SDK will ship in private-beta with 3–5 customers only, pending legal contracts. Custom branding and native mobile are deferred to V2.

## Workstreams

| Workstream | Owner | Status | Blocking V1? |
|------------|-------|--------|--------------|
| Dashboard refresh backend (query layer) | Marcus | 60% done; mid-May completion (week 6) | No (dashboard can ship without full SDK) |
| Embedded SDK (core) | Marcus | Query-layer in progress; IAM design started (Priya) | Yes, but mitigated via private-beta (week 6) |
| Mobile experience | Jen | Web-responsive in V1 (on track mid-May); native deferred to V2 (week 4) | No |
| Custom branding | Jen | Cut from V1 (Brendan, week 3); deferred to V2 | No |
| Panel-density / architecture fix | Roman | V1.1 fast-follow (August/September); 30% done (week 6) | No (documented limitation for V1) |
| Security / IAM design | Priya | Started; customer-facing API discussion next week (week 6) | Yes for public SDK; mitigated via private-beta |

## Risks

| Severity | Risk | Description |
|----------|------|-------------|
| High | SDK access-control gap | Week 4 discovery: embedded SDK lacks access-control for multi-tenant embedding. Mitigated by Option B (private-beta with 3–5 customers) (week 6). |
| Medium | 40-panel-per-page limit | Week 2/3: current architecture hits lag at ~40 panels. Accepted as documented V1 limitation; V1.1 fix in August. |
| Medium | Maevia customer expectation | Week 6: Maevia was promised GA SDK at conference; they will push back on private-beta. Sara handling (call tomorrow). |
| Low | Query-layer review bottleneck | Week 3: blocked on Lin (PTO). Mitigated by Aanya as sub-reviewer (week 4). |
| Low | Legal delay for private-beta contracts | Week 6: legal hasn’t responded to draft contracts. Sara escalating. |

## Decisions Made

| Date | Decision | Decider |
|------|----------|---------|
| 2026-03-18 (week 3) | Cut custom-branding from V1; accept 40-panel-per-page limit as documented V1 limitation | Brendan |
| 2026-03-25 (week 4) | Mobile = web-responsive in V1; native deferred to V2 | Sara & Jen |
| 2026-04-08 (week 6) | Ship V1 with embedded SDK as private-beta with 3–5 customers (Option B); delay public SDK launch | Brendan |

## Milestones

| Target | Milestone | Owner |
|--------|-----------|-------|
| Mid-May | Query-layer completion | Marcus |
| Mid-May | Mobile-responsive feature complete | Jen |
| Late May/early June | Private-beta V1 (dashboard + SDK with 3–5 customers) | Sara |
| Late July | GA dashboard refresh | Sara |
| August/September | V1.1: architectural fix (panel-density), IAM API | Roman + Priya |

## Open Questions / Asks

1. **Maevia pushback**: Sara will report back after her call (week 6); may need Brendan’s direct involvement if customer insists on GA SDK.
2. **Legal contracts**: Brendan, can you help expedite legal sign-off on the private-beta access-control contracts?
3. **V2 scope**: Custom branding and native mobile are deferred—should we lock V2 scope now for planning?

---

*Prepared from 6 weeks of meeting notes (2026-03-04 to 2026-04-08).*
