# Project Aurora — Working Notes

## Synthesis Process

### Workstreams
- **Dashboard refresh**: core product; backend ready-ish; query-layer in progress (8 weeks estimate → revised to 60% done by week 6, mid-May completion).
- **Embedded SDK**: part of Aurora; blocked on security/access-control; decision made (week 6) to ship as private-beta with 3-5 customers (Option B).
- **Mobile**: UX gap identified week 2; week 4 decision: web-responsive in V1 (4 weeks), native deferred to V2.
- **Custom branding**: week 2 decision: cut from V1 (Brendan directive, week 3).
- **Panel-density / architectural fix**: week 2 concern; week 3 accepted as documented limitation for V1; Roman owns V1.1 fix (August/September).
- **Security / IAM**: week 4 discovery; week 5 Priya (security) estimates 4 weeks; week 6 IAM design started.

### Risks
- **SDK access-control gap** (week 4): blocker for public SDK; mitigated by Option B (private-beta with 3-5 customers).
- **40-panel-per-page limit** (week 2, confirmed week 3): documented limitation for V1; V1.1 fix in August.
- **Maevia customer expectation** (week 6): promised GA SDK at conference; Sara handling pushback.
- **Query-layer review bottleneck** (week 3): Lin on PTO; mitigated by Aanya as sub-reviewer (week 4).
- **Legal delay for private-beta contracts** (week 6): open issue.

### Decisions (chronological)
1. **Week 3**: Cut custom-branding from V1 (Brendan).
2. **Week 3**: Accept 40-panel-per-page limit as documented V1 limitation (Brendan).
3. **Week 4**: Mobile = web-responsive in V1, native in V2 (Sara & Jen).
4. **Week 6**: Ship V1 with embedded SDK as private-beta with 3-5 customers (Brendan, Option B).

### Milestones (from notes)
- Query-layer completion: mid-May (Marcus)
- Mobile-responsive: mid-May (Jen)
- V1.1 architectural fix: August (Roman)
- IAM design: started (Priya); customer-facing API discussion next week (week 6)
- GA target originally end-June → renegotiated to end-July (week 3) → Option B (private-beta) in week 6.

### Owner notes
- Sara (PM): overall owner, customer comms (Maevia), legal contracts.
- Marcus (TL): query-layer, SDK backend.
- Jen (UX): dashboard design, mobile.
- Roman (data): data pipeline, panel-density, IAM API alignment.
- Priya (security): IAM design.
- Brendan (CEO): timeline decisions, scope trade-offs.

### Notes on "not inventing"
- No owners invented where source says "TBD" or doesn't specify.
- Dates pulled directly from meeting notes or inferred from context (e.g., "mid-May", "August").
- Decisions are explicitly attributed to Brendan/Sara/Jen where stated.
