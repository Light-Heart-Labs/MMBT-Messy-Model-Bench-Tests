# Project Aurora — Status Report Output

## Files

- **`status_report.md`** — The structured status report for the CEO (Brendan). Contains headline, workstreams, risks, decisions, milestones, and open asks. ≤500 words.

- **`research/notes.md`** — Working notes showing how the synthesis was derived from the 6 weekly meeting notes. Includes workstream tracking, risk identification, decision log, and milestone extraction.

- **`decisions/`** — Optional ADR-style records (empty in this case; all decisions are captured in `status_report.md` and `research/notes.md`).

## How to Read

1. Start with `status_report.md` for the executive summary.
2. See `research/notes.md` for traceability to source notes (week numbers, quotes, and reasoning).
3. No external assumptions or invented details—every claim traces to one of the 6 weekly notes.

## Release Tag

- Commit tagged `v1.0.0-status-report` after delivery.
