# ADR-001: Test Strategy for logalyzer Coverage Improvement

## Context

The logalyzer codebase has several modules with 0% or low test coverage:
- `experimental.py`: 0% coverage (anomaly detection, session windowing)
- `output.py`: 0% coverage (JSON, CSV, text formatters, render_aggregate)
- `utils.py`: 0% coverage (parse_iso_date, format_bytes, format_legacy, chunked)
- `io.py`: 0% coverage (file loading)
- `cli.py`: 0% coverage (CLI entry point)
- `filters.py`: 74% coverage (missing expression_filter, combine_and tests)
- `parser.py`: 86% coverage (missing edge cases)

## Decision

Target modules in priority order:
1. **experimental.py** — 0% coverage, has real logic worth exercising
2. **output.py** — 0% coverage, formatters are core functionality
3. **utils.py** — 0% coverage, utility functions with edge cases
4. **io.py** — 0% coverage, file I/O with edge cases
5. **filters.py** — 74% coverage, missing expression_filter and combine_and
6. **parser.py** — 86% coverage, edge cases for malformed input

## Rationale

- Modules at 0% coverage provide the most bang-for-buck
- Edge cases (empty input, malformed data, boundary conditions) are higher value than happy-path tests
- `experimental.py` is marked experimental but testing it validates the code works as written

## Known Bugs (Not Fixed)

1. `parser.py`: `MONTH_NAMES` list is missing "Jul" — causes `ValueError` for July timestamps
2. `filters.py`: `status_filter` does not convert string input to int — `"404" != 404`
3. `filters.py`: `url_regex_filter` uses `re.match` (start-of-string) not `re.search` — patterns like "admin" won't match "/admin/login"
4. `filters.py`: `from collections import Iterable` is deprecated in Python 3.11

These bugs are documented but not fixed per project rules. Tests are written to pass against current behavior.
