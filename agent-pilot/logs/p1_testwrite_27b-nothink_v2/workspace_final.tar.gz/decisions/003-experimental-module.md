# ADR-003: Experimental Module Testing Decision

## Context

`experimental.py` is marked as "experimental" and "not yet wired into the CLI." The module contains `detect_anomalies` (z-score-based anomaly detection) and `session_window` (session grouping by IP).

## Decision

**Test the experimental module fully.**

## Rationale

1. **Coverage goal**: The module had 0% coverage. Testing it brings it to 100%.
2. **Code validation**: Even experimental code should be verified to work as written. Tests serve as documentation of expected behavior.
3. **No behavior change**: We are not fixing bugs or refactoring — just exercising the code paths.
4. **Future-proofing**: If the experimental features are ever wired into the CLI, they'll already have test coverage.

## Recommendation (Out of Scope)

The experimental module should either be:
- **Promoted** to stable if the features are valuable (anomaly detection and session windowing are useful)
- **Removed** if the features are abandoned (dead code with no tests is a maintenance burden)

This recommendation is documented here but not acted upon, as it's out of scope for this test-addition task.
