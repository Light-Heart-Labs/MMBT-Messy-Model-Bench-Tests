"""Shared pytest fixtures."""
import sys
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Patch: collections.Iterable was removed in Python 3.3+ (moved to collections.abc).
# The source code uses `from collections import Iterable` which fails on Python 3.11.
# We monkey-patch it so the existing source code can import without modification.
import collections
from collections.abc import Iterable as _Iterable
if not hasattr(collections, "Iterable"):
    collections.Iterable = _Iterable
