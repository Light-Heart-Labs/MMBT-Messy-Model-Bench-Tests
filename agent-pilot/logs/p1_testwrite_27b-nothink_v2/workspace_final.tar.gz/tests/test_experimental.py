"""Tests for experimental.py — anomaly detection and session windowing.

These tests exercise the experimental module which has 0% coverage.
The module is marked "experimental" but testing it validates the code
works as written and increases coverage.
"""
from datetime import datetime, timedelta, timezone

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1"):
    """Helper to create a LogEntry with a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )


class TestDetectAnomalies:
    """Tests for detect_anomalies — z-score based anomaly detection."""

    def test_empty_entries_returns_empty_list(self):
        """No entries → no anomalies."""
        assert detect_anomalies([]) == []

    def test_uniform_traffic_has_no_anomalies(self):
        """When all minutes have the same count, no anomalies are detected."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
        # Each minute has exactly 1 request → std=0, threshold=mean
        result = detect_anomalies(entries)
        assert result == []

    def test_spike_detected_as_anomaly(self):
        """A minute with many more requests than others should be flagged."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = []
        # 10 minutes with 1 request each
        for i in range(10):
            entries.append(_entry(base + timedelta(minutes=i)))
        # 1 minute with 100 requests (the spike)
        spike_time = base + timedelta(minutes=10)
        for _ in range(100):
            entries.append(_entry(spike_time))

        result = detect_anomalies(entries)
        # The spike minute should be in the results
        assert spike_time.replace(second=0, microsecond=0) in result

    def test_single_entry_is_not_anomaly(self):
        """A single entry has std=0, so threshold=mean=count, and count is not > threshold."""
        entries = [_entry(datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc))]
        result = detect_anomalies(entries)
        assert result == []

    def test_buckets_by_minute_not_second(self):
        """Multiple entries in the same minute should be bucketed together."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(seconds=30)),
            _entry(base + timedelta(seconds=59)),
        ]
        # All three are in the same minute bucket
        result = detect_anomalies(entries)
        # With only one bucket, std=0, so no anomalies
        assert result == []

    def test_multiple_anomalous_minutes(self):
        """Multiple minutes with spikes should all be detected."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = []
        # 20 normal minutes with 1 request each
        for i in range(20):
            entries.append(_entry(base + timedelta(minutes=i)))
        # Two spike minutes with 200 requests each
        for spike_min in [30, 40]:
            spike_time = base + timedelta(minutes=spike_min)
            for _ in range(200):
                entries.append(_entry(spike_time))

        result = detect_anomalies(entries)
        expected = [
            (base + timedelta(minutes=30)).replace(second=0, microsecond=0),
            (base + timedelta(minutes=40)).replace(second=0, microsecond=0),
        ]
        for exp in expected:
            assert exp in result

    def test_returns_list_of_datetimes(self):
        """Result should be a list of datetime objects."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [_entry(base)]
        result = detect_anomalies(entries)
        assert isinstance(result, list)


class TestSessionWindow:
    """Tests for session_window — grouping entries into sessions by IP."""

    def test_empty_entries_returns_empty_sessions(self):
        """No entries → no sessions."""
        assert session_window([]) == []

    def test_single_entry_is_one_session(self):
        """A single entry forms one session."""
        entries = [_entry(datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc))]
        sessions = session_window(entries)
        assert len(sessions) == 1
        ip, session_entries = sessions[0]
        assert ip == "10.0.0.1"
        assert len(session_entries) == 1

    def test_multiple_ips_create_separate_sessions(self):
        """Different IPs should have separate sessions."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base, ip="10.0.0.1"),
            _entry(base, ip="10.0.0.2"),
        ]
        sessions = session_window(entries)
        assert len(sessions) == 2
        ips = {s[0] for s in sessions}
        assert ips == {"10.0.0.1", "10.0.0.2"}

    def test_gap_exceeding_window_splits_session(self):
        """A gap larger than window_seconds should split a session."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(seconds=3601)),  # > 1800s default window
        ]
        sessions = session_window(entries)
        assert len(sessions) == 2

    def test_gap_within_window_keeps_session(self):
        """A gap within window_seconds should keep entries in the same session."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(seconds=1799)),  # < 1800s default window
        ]
        sessions = session_window(entries)
        assert len(sessions) == 1
        assert len(sessions[0][1]) == 2

    def test_custom_window_seconds(self):
        """Custom window_seconds parameter should be respected."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(seconds=61)),  # > 60s window
        ]
        sessions = session_window(entries, window_seconds=60)
        assert len(sessions) == 2

    def test_entries_sorted_by_timestamp_within_session(self):
        """Entries within a session should be sorted by timestamp."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base + timedelta(minutes=5)),
            _entry(base),
            _entry(base + timedelta(minutes=3)),
        ]
        sessions = session_window(entries)
        assert len(sessions) == 1
        _, session_entries = sessions[0]
        timestamps = [e.timestamp for e in session_entries]
        assert timestamps == sorted(timestamps)

    def test_exact_window_boundary_splits_session(self):
        """A gap exactly equal to window_seconds should NOT split (gap > window, not >=)."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(seconds=1800)),  # exactly 1800s
        ]
        sessions = session_window(entries)
        # gap == window_seconds, not > window_seconds, so same session
        assert len(sessions) == 1

    def test_multiple_gaps_create_multiple_sessions(self):
        """Multiple gaps exceeding the window should create multiple sessions."""
        base = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        entries = [
            _entry(base),
            _entry(base + timedelta(seconds=3601)),  # gap > 1800
            _entry(base + timedelta(seconds=7202)),  # gap > 1800
        ]
        sessions = session_window(entries)
        assert len(sessions) == 3
