"""Tests for io.py — file loading helpers.

These tests exercise io.py which has 0% coverage.
Tests use tmp_path fixture for realistic file I/O testing.
Edge cases include empty files, malformed lines, and files without trailing newlines.
"""

from logalyzer.io import load, load_iter


def test_load_empty_file_returns_empty_list(tmp_path):
    """An empty file should return an empty list."""
    f = tmp_path / "empty.log"
    f.write_text("")
    assert load(str(f)) == []


def test_load_single_line_with_trailing_newline(tmp_path):
    """A file with one valid log line and trailing newline."""
    f = tmp_path / "single.log"
    f.write_text('127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n')
    entries = load(str(f))
    assert len(entries) == 1
    assert entries[0].ip == "127.0.0.1"
    assert entries[0].status == 200


def test_load_single_line_without_trailing_newline(tmp_path):
    """A file with one valid log line but no trailing newline.
    The load function handles this by checking accumulated after the loop.
    """
    f = tmp_path / "no_newline.log"
    f.write_text('127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326')
    entries = load(str(f))
    assert len(entries) == 1
    assert entries[0].ip == "127.0.0.1"


def test_load_multiple_lines(tmp_path):
    """A file with multiple valid log lines."""
    f = tmp_path / "multi.log"
    f.write_text(
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "POST /api HTTP/1.1" 201 200\n'
    )
    entries = load(str(f))
    assert len(entries) == 2
    assert entries[0].ip == "10.0.0.1"
    assert entries[1].ip == "10.0.0.2"


def test_load_skips_malformed_lines(tmp_path):
    """Malformed lines should be silently skipped."""
    f = tmp_path / "mixed.log"
    f.write_text(
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n'
        'this is not a valid log line\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET / HTTP/1.0" 404 0\n'
    )
    entries = load(str(f))
    assert len(entries) == 2
    assert entries[0].ip == "10.0.0.1"
    assert entries[1].ip == "10.0.0.2"


def test_load_skips_empty_lines(tmp_path):
    """Empty lines should be skipped."""
    f = tmp_path / "empty_lines.log"
    f.write_text(
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n'
        '\n'
        '\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET / HTTP/1.0" 200 200\n'
    )
    entries = load(str(f))
    assert len(entries) == 2


def test_load_nonexistent_file_raises_file_not_found(tmp_path):
    """Loading a nonexistent file should raise FileNotFoundError."""
    try:
        load(str(tmp_path / "nonexistent.log"))
        assert False, "Expected FileNotFoundError"
    except FileNotFoundError:
        pass


def test_load_iter_is_generator(tmp_path):
    """load_iter should return a generator."""
    f = tmp_path / "iter.log"
    f.write_text('10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n')
    import types
    result = load_iter(str(f))
    assert isinstance(result, types.GeneratorType)


def test_load_iter_yields_entries(tmp_path):
    """load_iter should yield LogEntry objects."""
    f = tmp_path / "iter.log"
    f.write_text(
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET / HTTP/1.0" 404 0\n'
    )
    entries = list(load_iter(str(f)))
    assert len(entries) == 2
    assert entries[0].ip == "10.0.0.1"
    assert entries[1].ip == "10.0.0.2"


def test_load_iter_skips_malformed_lines(tmp_path):
    """load_iter should skip malformed lines like load does."""
    f = tmp_path / "mixed_iter.log"
    f.write_text(
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n'
        'garbage line\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET / HTTP/1.0" 200 200\n'
    )
    entries = list(load_iter(str(f)))
    assert len(entries) == 2


def test_load_iter_empty_file(tmp_path):
    """load_iter on an empty file should yield nothing."""
    f = tmp_path / "empty_iter.log"
    f.write_text("")
    entries = list(load_iter(str(f)))
    assert entries == []


def test_load_iter_nonexistent_file_raises(tmp_path):
    """load_iter on a nonexistent file should raise FileNotFoundError."""
    try:
        list(load_iter(str(tmp_path / "nonexistent.log")))
        assert False, "Expected FileNotFoundError"
    except FileNotFoundError:
        pass


def test_load_preserves_bytes_dash_as_zero(tmp_path):
    """Lines with '-' for bytes should have bytes=0."""
    f = tmp_path / "dash_bytes.log"
    f.write_text('10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 304 -\n')
    entries = load(str(f))
    assert len(entries) == 1
    assert entries[0].bytes == 0


def test_load_large_file(tmp_path):
    """Loading a file with many lines should work correctly."""
    f = tmp_path / "large.log"
    lines = []
    for i in range(100):
        lines.append(f'10.0.0.{i % 256} - - [10/Oct/2000:13:55:36 +0000] "GET /page{i} HTTP/1.0" 200 {i * 100}\n')
    f.write_text("".join(lines))
    entries = load(str(f))
    assert len(entries) == 100
