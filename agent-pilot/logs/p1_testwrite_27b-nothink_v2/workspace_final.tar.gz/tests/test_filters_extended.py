"""Tests for filters.py — expression_filter and combine_and.

These tests exercise the uncovered parts of filters.py:
- expression_filter (eval-based filtering)
- combine_and (predicate composition)

The existing tests cover status_filter, url_regex_filter, ip_allowlist_filter,
and date_range_filter. These tests add coverage for the remaining functions.
"""
from datetime import datetime, timezone

from logalyzer.filters import combine_and, expression_filter, status_filter
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


class TestExpressionFilter:
    """Tests for expression_filter — eval-based filtering."""

    def test_status_expression(self):
        """Expression 'entry.status >= 500' should match 5xx errors."""
        pred = expression_filter("entry.status >= 500")
        assert pred(_entry(status=500)) is True
        assert pred(_entry(status=503)) is True
        assert pred(_entry(status=404)) is False
        assert pred(_entry(status=200)) is False

    def test_bytes_expression(self):
        """Expression 'entry.bytes > 1024' should filter by byte size."""
        pred = expression_filter("entry.bytes > 1024")
        assert pred(_entry(bytes=2000)) is True
        assert pred(_entry(bytes=1024)) is False
        assert pred(_entry(bytes=0)) is False

    def test_method_expression(self):
        """Expression 'entry.method == \"POST\"' should match POST requests."""
        pred = expression_filter("entry.method == 'POST'")
        assert pred(_entry(method="POST")) is True
        assert pred(_entry(method="GET")) is False

    def test_combined_expression(self):
        """Complex expression with AND should work."""
        pred = expression_filter("entry.bytes > 1024 and entry.method == 'GET'")
        assert pred(_entry(method="GET", bytes=2000)) is True
        assert pred(_entry(method="POST", bytes=2000)) is False
        assert pred(_entry(method="GET", bytes=500)) is False

    def test_or_expression(self):
        """Expression with OR should work."""
        pred = expression_filter("entry.status == 404 or entry.status == 500")
        assert pred(_entry(status=404)) is True
        assert pred(_entry(status=500)) is True
        assert pred(_entry(status=200)) is False

    def test_url_expression(self):
        """Expression checking URL should work."""
        pred = expression_filter("'api' in entry.url")
        assert pred(_entry(url="/api/users")) is True
        assert pred(_entry(url="/index.html")) is False

    def test_expression_returns_bool(self):
        """The predicate should always return a bool (via bool() wrapper)."""
        pred = expression_filter("entry.status > 0")
        result = pred(_entry(status=200))
        assert isinstance(result, bool)

    def test_expression_with_ip(self):
        """Expression checking IP should work."""
        pred = expression_filter("entry.ip.startswith('10.')")
        assert pred(_entry(ip="10.0.0.1")) is True
        assert pred(_entry(ip="192.168.1.1")) is False


class TestCombineAnd:
    """Tests for combine_and — predicate composition with AND logic."""

    def test_no_predicates_returns_true(self):
        """combine_and with no predicates should return True for all entries."""
        pred = combine_and()
        assert pred(_entry()) is True

    def test_single_predicate(self):
        """combine_and with one predicate should behave like that predicate."""
        pred = combine_and(status_filter(200))
        assert pred(_entry(status=200)) is True
        assert pred(_entry(status=404)) is False

    def test_two_predicates_both_match(self):
        """Two predicates that both match should return True."""
        pred = combine_and(
            status_filter(200),
            expression_filter("entry.method == 'GET'"),
        )
        assert pred(_entry(status=200, method="GET")) is True

    def test_two_predicates_first_fails(self):
        """If the first predicate fails, result should be False (short-circuit)."""
        pred = combine_and(
            status_filter(404),  # will fail for status=200
            expression_filter("entry.method == 'GET'"),  # would pass
        )
        assert pred(_entry(status=200, method="GET")) is False

    def test_two_predicates_second_fails(self):
        """If the second predicate fails, result should be False."""
        pred = combine_and(
            status_filter(200),  # passes
            expression_filter("entry.method == 'POST'"),  # fails for GET
        )
        assert pred(_entry(status=200, method="GET")) is False

    def test_three_predicates_all_match(self):
        """Three predicates that all match should return True."""
        pred = combine_and(
            status_filter(200),
            expression_filter("entry.method == 'GET'"),
            expression_filter("entry.bytes > 0"),
        )
        assert pred(_entry(status=200, method="GET", bytes=100)) is True

    def test_three_predicates_middle_fails(self):
        """If the middle predicate fails, result should be False."""
        pred = combine_and(
            status_filter(200),  # passes
            expression_filter("entry.bytes > 10000"),  # fails for 100 bytes
            expression_filter("entry.method == 'GET'"),  # would pass
        )
        assert pred(_entry(status=200, method="GET", bytes=100)) is False

    def test_short_circuit_on_first_failure(self):
        """combine_and should short-circuit on first failure."""
        call_count = {"count": 0}

        def counting_pred(entry):
            call_count["count"] += 1
            return False

        def always_true_pred(entry):
            return True

        pred = combine_and(counting_pred, always_true_pred, always_true_pred)
        pred(_entry())
        # Should only call the first predicate (short-circuit)
        assert call_count["count"] == 1
