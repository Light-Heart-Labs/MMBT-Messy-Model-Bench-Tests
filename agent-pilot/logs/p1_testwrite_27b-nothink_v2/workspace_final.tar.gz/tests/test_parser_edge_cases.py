"""Tests for parser.py — edge cases and boundary conditions.

These tests exercise uncovered code paths in parser.py:
- parse_timestamp with invalid formats
- parse_line with various malformed inputs
- parse_lines generator behavior
- Edge cases for bytes field (dash, zero, large values)
- Timestamps with various timezone offsets

The existing tests cover basic CLF parsing, dash bytes, garbage lines,
January/July timestamps, and UTC conversion. These tests add edge cases.
"""
from datetime import timezone

from logalyzer.parser import parse_line, parse_lines, parse_timestamp


class TestParseTimestampEdgeCases:
    """Edge cases for parse_timestamp."""

    def test_positive_timezone_offset(self):
        """Positive timezone offset should subtract from UTC."""
        # 13:00 +0500 = 08:00 UTC
        ts = parse_timestamp("10/Oct/2000:13:00:00 +0500")
        assert ts.hour == 8
        assert ts.tzinfo is timezone.utc

    def test_negative_timezone_offset(self):
        """Negative timezone offset should add to UTC."""
        # 13:00 -0500 = 18:00 UTC
        ts = parse_timestamp("10/Oct/2000:13:00:00 -0500")
        assert ts.hour == 18
        assert ts.tzinfo is timezone.utc

    def test_utc_offset_zero(self):
        """+0000 offset should produce the same time in UTC."""
        ts = parse_timestamp("10/Oct/2000:13:00:00 +0000")
        assert ts.hour == 13
        assert ts.minute == 0

    def test_large_positive_offset(self):
        """Large positive offset like +1200 should work."""
        ts = parse_timestamp("10/Oct/2000:13:00:00 +1200")
        assert ts.hour == 1  # 13 - 12 = 1

    def test_large_negative_offset(self):
        """Large negative offset like -1100 should work."""
        ts = parse_timestamp("10/Oct/2000:13:00:00 -1100")
        assert ts.hour == 0  # 13 + 11 = 24 → 0 next day
        assert ts.day == 11  # rolls to next day

    def test_invalid_timestamp_format_raises_value_error(self):
        """Completely invalid timestamp should raise ValueError."""
        try:
            parse_timestamp("not-a-timestamp")
            assert False, "Expected ValueError"
        except ValueError as e:
            assert "unrecognized timestamp format" in str(e)

    def test_missing_timezone_raises_value_error(self):
        """Timestamp without timezone offset should raise ValueError."""
        try:
            parse_timestamp("10/Oct/2000:13:55:36")
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_malformed_date_components_raises_value_error(self):
        """Date with invalid components should raise ValueError."""
        try:
            parse_timestamp("99/Xyz/9999:99:99:99 +0000")
            assert False, "Expected ValueError"
        except (ValueError, IndexError):
            pass


class TestParseLineEdgeCases:
    """Edge cases for parse_line."""

    def test_whitespace_only_returns_none(self):
        """A line with only whitespace should return None."""
        assert parse_line("   ") is None
        assert parse_line("\t") is None
        assert parse_line("\n") is None

    def test_leading_trailing_whitespace_stripped(self):
        """Leading/trailing whitespace should be stripped before parsing."""
        line = '  127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326  '
        e = parse_line(line)
        assert e is not None
        assert e.ip == "127.0.0.1"

    def test_large_byte_count(self):
        """Very large byte counts should parse correctly."""
        line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /big HTTP/1.0" 200 999999999'
        e = parse_line(line)
        assert e is not None
        assert e.bytes == 999999999

    def test_various_status_codes(self):
        """Various HTTP status codes should parse correctly."""
        for status in [100, 201, 301, 302, 400, 403, 404, 500, 502, 503]:
            line = f'10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" {status} 100'
            e = parse_line(line)
            assert e is not None, f"Failed to parse status {status}"
            assert e.status == status

    def test_various_http_methods(self):
        """Various HTTP methods should parse correctly."""
        for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
            line = f'10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "{method} / HTTP/1.1" 200 100'
            e = parse_line(line)
            assert e is not None, f"Failed to parse method {method}"
            assert e.method == method

    def test_url_with_query_string(self):
        """URLs with query strings should parse correctly."""
        line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /search?q=test&page=1 HTTP/1.1" 200 500'
        e = parse_line(line)
        assert e is not None
        assert e.url == "/search?q=test&page=1"

    def test_url_with_fragment(self):
        """URLs with fragments should parse correctly."""
        line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /page#section HTTP/1.1" 200 500'
        e = parse_line(line)
        assert e is not None
        assert e.url == "/page#section"

    def test_ipv6_address(self):
        """IPv6 addresses should parse correctly."""
        line = '::1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100'
        e = parse_line(line)
        assert e is not None
        assert e.ip == "::1"

    def test_user_field_with_username(self):
        """User field with actual username (not dash) should parse."""
        line = '10.0.0.1 - admin [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100'
        e = parse_line(line)
        assert e is not None
        assert e.user == "admin"

    def test_http_protocol_versions(self):
        """Various HTTP protocol versions should parse."""
        for proto in ["HTTP/1.0", "HTTP/1.1", "HTTP/2.0"]:
            line = f'10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / {proto}" 200 100'
            e = parse_line(line)
            assert e is not None, f"Failed to parse protocol {proto}"
            assert e.protocol == proto

    def test_malformed_request_line_returns_none(self):
        """A line with malformed request (e.g., missing method) should return None."""
        line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "/ HTTP/1.1" 200 100'
        assert parse_line(line) is None

    def test_missing_status_code_returns_none(self):
        """A line missing the status code should return None."""
        line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 100'
        assert parse_line(line) is None

    def test_non_numeric_status_returns_none(self):
        """A line with non-numeric status should return None."""
        line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" abc 100'
        assert parse_line(line) is None


class TestParseLines:
    """Tests for parse_lines generator."""

    def test_parse_lines_is_generator(self):
        """parse_lines should return a generator."""
        import types
        result = parse_lines([])
        assert isinstance(result, types.GeneratorType)

    def test_parse_lines_empty_list(self):
        """parse_lines with empty list should yield nothing."""
        entries = list(parse_lines([]))
        assert entries == []

    def test_parse_lines_mixed_valid_invalid(self):
        """parse_lines should skip invalid lines and yield valid ones."""
        lines = [
            '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100',
            'invalid line',
            '',
            '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET / HTTP/1.0" 404 0',
        ]
        entries = list(parse_lines(lines))
        assert len(entries) == 2
        assert entries[0].ip == "10.0.0.1"
        assert entries[1].ip == "10.0.0.2"

    def test_parse_lines_with_generator_input(self):
        """parse_lines should work with generator input."""
        def line_gen():
            yield '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
            yield 'invalid'
            yield '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET / HTTP/1.0" 200 200'

        entries = list(parse_lines(line_gen()))
        assert len(entries) == 2

    def test_parse_lines_all_invalid(self):
        """parse_lines with all invalid lines should yield nothing."""
        lines = ["garbage", "more garbage", ""]
        entries = list(parse_lines(lines))
        assert entries == []
