"""Tests for output.py — JSON, CSV, text formatters and render_aggregate.

These tests exercise the output module which has 0% coverage.
Tests cover edge cases like empty input, special characters in URLs,
and the render_aggregate function with different formats.
"""
from datetime import datetime, timezone

from logalyzer.output import (
    render_aggregate,
    to_csv,
    to_json,
    to_text,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


class TestToJson:
    """Tests for to_json formatter."""

    def test_empty_entries_returns_empty_array(self):
        """No entries → empty JSON array."""
        assert to_json([]) == "[]"

    def test_single_entry_produces_valid_json_array(self):
        """A single entry should produce a JSON array with one object."""
        entries = [_entry()]
        result = to_json(entries)
        assert result.startswith("[")
        assert result.endswith("]")
        assert '"ip":"10.0.0.1"' in result
        assert '"status":200' in result
        assert '"bytes":100' in result

    def test_multiple_entries_produces_array(self):
        """Multiple entries should produce a JSON array with multiple objects."""
        entries = [_entry(status=200), _entry(status=404)]
        result = to_json(entries)
        # Should contain both status codes
        assert '"status":200' in result
        assert '"status":404' in result

    def test_url_with_special_characters(self):
        """URLs with query strings and special chars should be included as-is."""
        entries = [_entry(url="/search?q=hello+world&lang=en")]
        result = to_json(entries)
        assert "/search?q=hello+world&lang=en" in result

    def test_user_field_preserved(self):
        """The user field should be preserved in JSON output."""
        entries = [_entry(user="frank")]
        result = to_json(entries)
        assert '"user":"frank"' in result

    def test_zero_bytes_rendered_correctly(self):
        """Zero bytes should render as 0, not as a dash."""
        entries = [_entry(bytes=0)]
        result = to_json(entries)
        assert '"bytes":0' in result

    def test_timestamp_isoformat(self):
        """Timestamp should be rendered in ISO format."""
        entries = [_entry()]
        result = to_json(entries)
        assert "2026-01-01T12:00:00" in result


class TestToCsv:
    """Tests for to_csv formatter."""

    def test_empty_entries_returns_header_only(self):
        """No entries → CSV with header row only."""
        result = to_csv([])
        lines = result.strip().split("\n")
        assert len(lines) == 1
        assert "ip" in lines[0]
        assert "status" in lines[0]

    def test_single_entry_has_header_and_data_row(self):
        """A single entry should produce header + one data row."""
        entries = [_entry()]
        result = to_csv(entries)
        lines = result.strip().split("\n")
        assert len(lines) == 2

    def test_csv_contains_all_fields(self):
        """CSV should contain all LogEntry fields."""
        entries = [_entry()]
        result = to_csv(entries)
        assert "10.0.0.1" in result
        assert "200" in result
        assert "GET" in result

    def test_csv_handles_commas_in_data(self):
        """CSV writer should properly quote fields containing commas."""
        entries = [_entry(url="/path,with,commas")]
        result = to_csv(entries)
        # csv.writer handles quoting automatically
        assert "path" in result


class TestToText:
    """Tests for to_text formatter."""

    def test_empty_entries_returns_empty_string(self):
        """No entries → empty string."""
        assert to_text([]) == ""

    def test_single_entry_produces_one_line(self):
        """A single entry should produce one line of text."""
        entries = [_entry()]
        result = to_text(entries)
        lines = result.split("\n")
        assert len(lines) == 1

    def test_multiple_entries_produce_multiple_lines(self):
        """Multiple entries should produce multiple lines."""
        entries = [_entry(status=200), _entry(status=404)]
        result = to_text(entries)
        lines = result.split("\n")
        assert len(lines) == 2

    def test_text_output_contains_ip_and_status(self):
        """Text output should contain IP address and status code."""
        entries = [_entry(ip="192.168.1.1", status=500)]
        result = to_text(entries)
        assert "192.168.1.1" in result
        assert "500" in result

    def test_text_output_contains_method_and_url(self):
        """Text output should contain HTTP method and URL."""
        entries = [_entry(method="POST", url="/api/submit")]
        result = to_text(entries)
        assert "POST" in result
        assert "/api/submit" in result


class TestRenderAggregate:
    """Tests for render_aggregate with different formats."""

    def test_text_format_with_counter(self):
        """Text format should render key-value pairs with tab separator."""
        from collections import Counter
        agg = Counter({"200": 10, "404": 3})
        result = render_aggregate(agg, fmt="text")
        assert "200" in result
        assert "10" in result
        assert "404" in result

    def test_text_format_with_dict(self):
        """Text format should work with plain dicts."""
        agg = {"a": 1, "b": 2}
        result = render_aggregate(agg, fmt="text")
        assert "a" in result
        assert "1" in result

    def test_text_format_with_list_of_tuples(self):
        """Text format should work with list of (key, value) tuples."""
        agg = [("url1", 5), ("url2", 3)]
        result = render_aggregate(agg, fmt="text")
        assert "url1" in result
        assert "5" in result

    def test_json_format_with_counter(self):
        """JSON format should render as JSON-like object."""
        from collections import Counter
        agg = Counter({"200": 10, "404": 3})
        result = render_aggregate(agg, fmt="json")
        assert result.startswith("{")
        assert result.endswith("}")
        assert '"200":10' in result

    def test_json_format_with_list_of_tuples(self):
        """JSON format should work with list of tuples."""
        agg = [("a", 1), ("b", 2)]
        result = render_aggregate(agg, fmt="json")
        assert '"a":1' in result
        assert '"b":2' in result

    def test_unknown_format_raises_value_error(self):
        """Unknown format should raise ValueError."""
        agg = {"a": 1}
        try:
            render_aggregate(agg, fmt="xml")
            assert False, "Expected ValueError"
        except ValueError as e:
            assert "unknown format" in str(e)

    def test_default_format_is_text(self):
        """Default format should be text."""
        agg = {"a": 1}
        result = render_aggregate(agg)
        assert "a" in result
        assert "1" in result
