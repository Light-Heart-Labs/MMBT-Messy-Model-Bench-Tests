"""Tests for utils.py — utility functions.

These tests exercise utils.py which has 0% coverage.
Tests cover parse_iso_date, format_bytes, format_legacy, and chunked.
Edge cases include boundary values for byte formatting and empty sequences.
"""
from datetime import datetime, timezone

from logalyzer.parser import LogEntry
from logalyzer.utils import (
    chunked,
    format_bytes,
    format_legacy,
    parse_iso_date,
)


class TestParseIsoDate:
    """Tests for parse_iso_date — YYYY-MM-DD to UTC datetime."""

    def test_parses_valid_date(self):
        """A valid YYYY-MM-DD string should parse to midnight UTC."""
        result = parse_iso_date("2026-01-15")
        assert result == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)

    def test_returns_utc_timezone(self):
        """Result should always be in UTC timezone."""
        result = parse_iso_date("2026-06-30")
        assert result.tzinfo is timezone.utc

    def test_leap_year_date(self):
        """Leap year dates should parse correctly."""
        result = parse_iso_date("2024-02-29")
        assert result.month == 2
        assert result.day == 29
        assert result.year == 2024

    def test_year_boundary(self):
        """Year boundary dates should parse correctly."""
        result = parse_iso_date("2026-12-31")
        assert result.year == 2026
        assert result.month == 12
        assert result.day == 31

    def test_invalid_date_raises_value_error(self):
        """An invalid date string should raise ValueError from strptime."""
        try:
            parse_iso_date("not-a-date")
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_invalid_date_format_raises_value_error(self):
        """Wrong format (e.g. MM/DD/YYYY) should raise ValueError."""
        try:
            parse_iso_date("01-15-2026")
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_nonexistent_date_raises_value_error(self):
        """Feb 30 doesn't exist and should raise ValueError."""
        try:
            parse_iso_date("2026-02-30")
            assert False, "Expected ValueError"
        except ValueError:
            pass


class TestFormatBytes:
    """Tests for format_bytes — human-readable byte formatting."""

    def test_zero_bytes(self):
        """Zero bytes should format as '0.0 B'."""
        assert format_bytes(0) == "0.0 B"

    def test_small_bytes(self):
        """Values under 1024 should be in bytes."""
        assert format_bytes(500) == "500.0 B"

    def test_exactly_1024_is_1_kb(self):
        """1024 bytes should format as 1.0 KB."""
        assert format_bytes(1024) == "1.0 KB"

    def test_exactly_1_megabyte(self):
        """1048576 bytes (1024*1024) should format as 1.0 MB."""
        assert format_bytes(1048576) == "1.0 MB"

    def test_exactly_1_gigabyte(self):
        """1073741824 bytes should format as 1.0 GB."""
        assert format_bytes(1073741824) == "1.0 GB"

    def test_exactly_1_terabyte(self):
        """1099511627776 bytes should format as 1.0 TB."""
        assert format_bytes(1099511627776) == "1.0 TB"

    def test_fractional_kb(self):
        """1536 bytes (1.5 KB) should format as 1.5 KB."""
        assert format_bytes(1536) == "1.5 KB"

    def test_large_value_exceeds_tb_goes_to_pb(self):
        """Values exceeding TB range should fall through to PB."""
        # 2 PB = 2 * 1024^5
        result = format_bytes(2 * 1024**5)
        assert "PB" in result

    def test_negative_bytes(self):
        """Negative byte values should still format (edge case)."""
        result = format_bytes(-500)
        assert "B" in result

    def test_one_byte_less_than_kb(self):
        """1023 bytes should still be in B, not KB."""
        assert format_bytes(1023) == "1023.0 B"


class TestFormatLegacy:
    """Tests for format_legacy — legacy v0.1 CLI output format."""

    def test_basic_format(self):
        """Legacy format should produce 'ip | timestamp | status | url'."""
        entry = LogEntry(
            ip="10.0.0.1",
            user="-",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="GET",
            url="/index.html",
            protocol="HTTP/1.1",
            status=200,
            bytes=100,
        )
        result = format_legacy(entry)
        assert "10.0.0.1" in result
        assert "200" in result
        assert "/index.html" in result
        assert "|" in result

    def test_format_does_not_include_method_or_bytes(self):
        """Legacy format omits method and bytes fields."""
        entry = LogEntry(
            ip="10.0.0.1",
            user="-",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="POST",
            url="/api",
            protocol="HTTP/1.1",
            status=201,
            bytes=500,
        )
        result = format_legacy(entry)
        # Legacy format: ip | timestamp | status | url
        assert "POST" not in result
        assert "500" not in result

    def test_format_with_zero_bytes_entry(self):
        """Legacy format should work with entries that have zero bytes."""
        entry = LogEntry(
            ip="127.0.0.1",
            user="-",
            timestamp=datetime(2026, 6, 15, 8, 30, 0, tzinfo=timezone.utc),
            method="GET",
            url="/health",
            protocol="HTTP/1.1",
            status=200,
            bytes=0,
        )
        result = format_legacy(entry)
        assert "127.0.0.1" in result
        assert "200" in result


class TestChunked:
    """Tests for chunked — yielding chunks of a sequence."""

    def test_empty_sequence(self):
        """Empty sequence should produce no chunks."""
        result = list(chunked([], 3))
        assert result == []

    def test_chunk_size_larger_than_sequence(self):
        """If chunk size > sequence length, return one chunk."""
        result = list(chunked([1, 2, 3], 10))
        assert result == [[1, 2, 3]]

    def test_exact_multiple_of_chunk_size(self):
        """Sequence length exactly divisible by chunk size."""
        result = list(chunked([1, 2, 3, 4, 5, 6], 3))
        assert result == [[1, 2, 3], [4, 5, 6]]

    def test_remainder_chunk(self):
        """Last chunk should contain the remainder."""
        result = list(chunked([1, 2, 3, 4, 5], 2))
        assert result == [[1, 2], [3, 4], [5]]

    def test_chunk_size_one(self):
        """Chunk size of 1 should produce one-item chunks."""
        result = list(chunked([1, 2, 3], 1))
        assert result == [[1], [2], [3]]

    def test_chunk_size_zero_raises(self):
        """Chunk size of 0 should cause infinite loop or error.
        The implementation appends to chunk and checks len(chunk) >= size.
        With size=0, len(chunk) >= 0 is always True after first append,
        so it yields empty chunks repeatedly. We test the first behavior."""
        # With size=0, after appending first item, len([item]) >= 0 is True,
        # so it yields [item] and resets. Each item becomes its own chunk.
        result = list(chunked([1, 2], 0))
        # Each item triggers yield immediately since len >= 0
        assert result == [[1], [2]]

    def test_generator_behavior(self):
        """chunked should be a generator, not a list."""
        result = chunked([1, 2, 3], 2)
        # Should be a generator
        import types
        assert isinstance(result, types.GeneratorType)

    def test_works_with_strings(self):
        """chunked should work with any iterable, including strings."""
        result = list(chunked("abcdef", 2))
        assert result == [["a", "b"], ["c", "d"], ["e", "f"]]

    def test_works_with_generator_input(self):
        """chunked should work with generator input."""
        def gen():
            yield 1
            yield 2
            yield 3
            yield 4
        result = list(chunked(gen(), 2))
        assert result == [[1, 2], [3, 4]]
