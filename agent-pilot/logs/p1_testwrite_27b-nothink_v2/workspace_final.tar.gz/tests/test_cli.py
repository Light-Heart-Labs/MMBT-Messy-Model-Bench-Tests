"""Tests for cli.py — CLI entry point integration tests.

These tests exercise cli.py which has 0% coverage.
Tests use tmp_path for realistic file I/O and test the main() function
with various argument combinations.
"""
from datetime import datetime, timezone

from logalyzer.cli import build_parser, main


def _make_log_file(tmp_path, lines):
    """Helper to create a log file with given lines."""
    f = tmp_path / "test.log"
    f.write_text("\n".join(lines) + "\n")
    return str(f)


class TestBuildParser:
    """Tests for build_parser — argparse configuration."""

    def test_parser_has_required_arguments(self):
        """Parser should have 'paths' as a required positional argument."""
        p = build_parser()
        # Should fail without positional args
        try:
            p.parse_args([])
            assert False, "Expected SystemExit for missing positional args"
        except SystemExit:
            pass

    def test_parser_has_version_flag(self):
        """Parser should have --version flag."""
        p = build_parser()
        try:
            p.parse_args(["--version"])
            assert False, "Expected SystemExit for --version"
        except SystemExit:
            pass  # --version exits with code 0

    def test_parser_has_status_option(self):
        """Parser should have --status option."""
        p = build_parser()
        args = p.parse_args(["--status", "404", "test.log"])
        assert args.status == "404"

    def test_parser_has_url_option(self):
        """Parser should have --url option."""
        p = build_parser()
        args = p.parse_args(["--url", r"/api", "test.log"])
        assert args.url == "/api"

    def test_parser_has_ip_option_repeatable(self):
        """Parser should have --ip option that can be repeated."""
        p = build_parser()
        args = p.parse_args(["--ip", "10.0.0.1", "--ip", "10.0.0.2", "test.log"])
        assert args.ip == ["10.0.0.1", "10.0.0.2"]

    def test_parser_has_since_until_options(self):
        """Parser should have --since and --until options."""
        p = build_parser()
        args = p.parse_args(["--since", "2026-01-01", "--until", "2026-12-31", "test.log"])
        assert args.since == datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        assert args.until == datetime(2026, 12, 31, 0, 0, 0, tzinfo=timezone.utc)

    def test_parser_has_aggregate_option(self):
        """Parser should have --aggregate option with valid choices."""
        p = build_parser()
        args = p.parse_args(["--aggregate", "status", "test.log"])
        assert args.aggregate == "status"

    def test_parser_has_format_option(self):
        """Parser should have --format option with valid choices."""
        p = build_parser()
        for fmt in ["text", "json", "csv"]:
            args = p.parse_args(["--format", fmt, "test.log"])
            assert args.format == fmt

    def test_parser_has_top_option(self):
        """Parser should have --top option."""
        p = build_parser()
        args = p.parse_args(["--top", "10", "test.log"])
        assert args.top == 10

    def test_parser_has_expr_option(self):
        """Parser should have --expr option."""
        p = build_parser()
        args = p.parse_args(["--expr", "entry.status >= 500", "test.log"])
        assert args.expr == "entry.status >= 500"


class TestMain:
    """Integration tests for main() with real log files."""

    def test_main_with_empty_file(self, tmp_path, capsys):
        """main with an empty log file should produce empty output."""
        f = _make_log_file(tmp_path, [])
        result = main([f])
        assert result == 0
        captured = capsys.readouterr()
        assert captured.out.strip() == ""

    def test_main_text_format_default(self, tmp_path, capsys):
        """main with default format should produce text output."""
        line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
        f = _make_log_file(tmp_path, [line])
        result = main([f])
        assert result == 0
        captured = capsys.readouterr()
        assert "10.0.0.1" in captured.out

    def test_main_json_format(self, tmp_path, capsys):
        """main with --format json should produce JSON output."""
        line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
        f = _make_log_file(tmp_path, [line])
        result = main(["--format", "json", f])
        assert result == 0
        captured = capsys.readouterr()
        assert captured.out.strip().startswith("[")
        assert captured.out.strip().endswith("]")

    def test_main_csv_format(self, tmp_path, capsys):
        """main with --format csv should produce CSV output."""
        line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
        f = _make_log_file(tmp_path, [line])
        result = main(["--format", "csv", f])
        assert result == 0
        captured = capsys.readouterr()
        assert "ip" in captured.out  # CSV header

    def test_main_aggregate_status(self, tmp_path, capsys):
        """main with --aggregate status should show status code counts."""
        lines = [
            '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100',
            '10.0.0.1 - - [10/Oct/2000:13:55:37 +0000] "GET / HTTP/1.0" 200 100',
            '10.0.0.1 - - [10/Oct/2000:13:55:38 +0000] "GET / HTTP/1.0" 404 100',
        ]
        f = _make_log_file(tmp_path, lines)
        result = main(["--aggregate", "status", f])
        assert result == 0
        captured = capsys.readouterr()
        assert "200" in captured.out
        assert "404" in captured.out

    def test_main_aggregate_url(self, tmp_path, capsys):
        """main with --aggregate url should show URL counts."""
        lines = [
            '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100',
            '10.0.0.1 - - [10/Oct/2000:13:55:37 +0000] "GET /api HTTP/1.0" 200 100',
            '10.0.0.1 - - [10/Oct/2000:13:55:38 +0000] "GET / HTTP/1.0" 200 100',
        ]
        f = _make_log_file(tmp_path, lines)
        result = main(["--aggregate", "url", f])
        assert result == 0
        captured = capsys.readouterr()
        assert "/" in captured.out

    def test_main_aggregate_hour(self, tmp_path, capsys):
        """main with --aggregate hour should show hourly counts."""
        lines = [
            '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100',
            '10.0.0.1 - - [10/Oct/2000:14:55:36 +0000] "GET / HTTP/1.0" 200 100',
        ]
        f = _make_log_file(tmp_path, lines)
        result = main(["--aggregate", "hour", f])
        assert result == 0
        captured = capsys.readouterr()
        # Should contain hour numbers
        assert captured.out.strip() != ""

    def test_main_with_nonexistent_file(self, tmp_path):
        """main with a nonexistent file should raise FileNotFoundError."""
        try:
            main([str(tmp_path / "nonexistent.log")])
            assert False, "Expected FileNotFoundError"
        except FileNotFoundError:
            pass

    def test_main_returns_zero_on_success(self, tmp_path):
        """main should return 0 on success."""
        f = _make_log_file(tmp_path, [])
        result = main([f])
        assert result == 0

    def test_main_with_multiple_files(self, tmp_path, capsys):
        """main should handle multiple log files."""
        f1 = tmp_path / "a.log"
        f1.write_text('10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /a HTTP/1.0" 200 100\n')
        f2 = tmp_path / "b.log"
        f2.write_text('10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET /b HTTP/1.0" 200 200\n')
        result = main([str(f1), str(f2)])
        assert result == 0
        captured = capsys.readouterr()
        assert "10.0.0.1" in captured.out
        assert "10.0.0.2" in captured.out

    def test_main_aggregate_json_format(self, tmp_path, capsys):
        """main with --aggregate and --format json should produce JSON."""
        line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
        f = _make_log_file(tmp_path, [line])
        result = main(["--aggregate", "status", "--format", "json", f])
        assert result == 0
        captured = capsys.readouterr()
        assert "{" in captured.out
        assert "}" in captured.out
