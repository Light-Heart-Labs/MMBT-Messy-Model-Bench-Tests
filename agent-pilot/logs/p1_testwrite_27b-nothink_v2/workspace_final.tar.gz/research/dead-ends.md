# Dead Ends

## Tests Written and Removed

### 1. test_status_filter_string_input (existing test, not modified)
The existing test `test_status_filter_works_with_cli_string_input` fails because `status_filter("404")` does not convert the string to int. The filter compares `entry.status == "404"` which is always False since status is an int. This is a bug in the source code. Per project rules, we do not fix it. The test remains as-is (failing).

### 2. test_url_regex_finds_substring_match (existing test, not modified)
The existing test fails because `url_regex_filter("admin")` uses `re.match()` which only matches at the start of the string. URL "/admin/login" starts with "/" not "admin". This is a bug. Per project rules, we do not fix it. The test remains as-is (failing).

### 3. test_timestamp_july_parses_correctly (existing test, not modified)
The existing test fails because `MONTH_NAMES` in parser.py is missing "Jul" (the list skips from "Jun" to "Aug"). This is a bug. Per project rules, we do not fix it. The test remains as-is (failing).

### 4. Initial attempt to test `io.load()` with nonexistent file
Initially tried to test `io.load()` with a nonexistent file path. The function raises `FileNotFoundError` which is the expected behavior. This test was kept as it exercises the error path.
