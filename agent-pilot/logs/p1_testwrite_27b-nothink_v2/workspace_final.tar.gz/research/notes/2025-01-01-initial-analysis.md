# Research Notes

## 2025-01-01: Initial Codebase Analysis

### Modules and Coverage
- `experimental.py`: 0% — anomaly detection + session windowing
- `output.py`: 0% — JSON/CSV/text formatters + render_aggregate
- `utils.py`: 0% — parse_iso_date, format_bytes, format_legacy, chunked
- `io.py`: 0% — file loading (load, load_iter)
- `cli.py`: 0% — argparse CLI
- `filters.py`: 74% — missing expression_filter, combine_and
- `parser.py`: 86% — edge cases missing
- `aggregate.py`: 100% — fully covered

### Bugs Found
1. `parser.py` MONTH_NAMES missing "Jul" (index 6)
2. `filters.py` status_filter doesn't handle string-to-int conversion
3. `filters.py` url_regex_filter uses match() not search()
4. `filters.py` imports Iterable from collections (removed in 3.11)

### Workaround
Added `collections.Iterable` monkey-patch in conftest.py to allow imports.
