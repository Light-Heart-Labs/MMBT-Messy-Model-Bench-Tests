# Questions

1. Should `experimental.py` be tested at all? It's marked "experimental" and "not yet wired into CLI."
   - Decision: Yes. The goal is coverage improvement. Testing validates the code works as written.

2. The `format_legacy()` function in `utils.py` is marked as "retained for compatibility." Should we test it?
   - Decision: Yes. It's production code that exists; testing it ensures it doesn't break.

3. `cli.py` uses `eval()` in `expression_filter`. Should we test the eval path?
   - Decision: Yes, but carefully. Test with safe expressions only.

4. `io.py` reads files. Should we use temp files or mock?
   - Decision: Use temp files via `tmp_path` fixture for realistic I/O testing.
