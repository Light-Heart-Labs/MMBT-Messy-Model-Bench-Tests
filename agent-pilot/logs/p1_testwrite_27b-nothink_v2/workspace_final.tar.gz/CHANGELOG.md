# CHANGELOG

## v0.3.2-test-additions

### Coverage Improvement
- **Before**: 34% (190/287 statements missed)
- **After**: 97% (9/287 statements missed)
- **Delta**: +63 percentage points

### Per-Module Coverage

| Module | Before | After | Notes |
|--------|--------|-------|-------|
| `__init__.py` | 100% | 100% | Already covered |
| `aggregate.py` | 100% | 100% | Already covered |
| `cli.py` | 0% | 90% | 6 lines missed (unused filter branches) |
| `experimental.py` | 0% | 100% | Full coverage added |
| `filters.py` | 74% | 97% | 1 line missed (unused Iterable import) |
| `io.py` | 0% | 100% | Full coverage added |
| `output.py` | 0% | 100% | Full coverage added |
| `parser.py` | 86% | 96% | 2 lines missed (unused parse_lines ValueError path) |
| `utils.py` | 0% | 100% | Full coverage added |

### Test Files Added
- `tests/test_experimental.py` — 16 tests for `detect_anomalies` and `session_window`
- `tests/test_output.py` — 23 tests for `to_json`, `to_csv`, `to_text`, `render_aggregate`
- `tests/test_utils.py` — 29 tests for `parse_iso_date`, `format_bytes`, `format_legacy`, `chunked`
- `tests/test_io.py` — 14 tests for `load` and `load_iter`
- `tests/test_filters_extended.py` — 16 tests for `expression_filter` and `combine_and`
- `tests/test_parser_edge_cases.py` — 26 tests for edge cases in `parse_timestamp`, `parse_line`, `parse_lines`
- `tests/test_cli.py` — 21 tests for `build_parser` and `main`

### Test Counts
- **Baseline**: 17 tests (14 passing, 3 failing)
- **Added**: 145 new tests (all passing)
- **Total**: 162 tests (159 passing, 3 failing)

### Pre-existing Test Failures (Unchanged)
The following 3 tests were already failing before this contribution and remain failing:
1. `test_status_filter_works_with_cli_string_input` — `status_filter` doesn't convert string to int
2. `test_url_regex_finds_substring_match` — `url_regex_filter` uses `re.match` not `re.search`
3. `test_timestamp_july_parses_correctly` — `MONTH_NAMES` list is missing "Jul"

These are bugs in the source code. Per project rules, they are documented but not fixed.

### conftest.py Change
- Added `collections.Iterable` monkey-patch to work around Python 3.11 compatibility issue
  (`from collections import Iterable` was removed in Python 3.3+, moved to `collections.abc`)
