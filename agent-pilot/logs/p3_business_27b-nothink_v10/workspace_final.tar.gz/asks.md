# Diligence Asks — Next 2 Weeks

**Target completion:** 2026-04-30 (decision deadline)

## 1. Valuation Deep Dive

| Question | Owner | Deadline |
|---|---|---|
| Obtain full deal structure details for all three comparable transactions (Hexa Insights, Aspen Data, Trellis Analytics): cash vs. stock vs. earn-out splits, contingent consideration, and any post-close adjustments | Corp Dev | 2026-04-22 |
| Build a valuation model with base, upside, and downside scenarios. What is the IRR in each scenario? What assumptions drive the 28-34% range? | Corp Dev + Finance | 2026-04-25 |
| Assess whether Borealis's growth rate (80-92% YoY) commands a premium or discount relative to the comps' growth rates at time of sale | Corp Dev | 2026-04-22 |
| Clarify the "cash-heavy" preference: what split is Borealis seeking, and can our treasury support it? What are the tax implications? | CFO + Corp Dev | 2026-04-25 |

## 2. Customer and Revenue Diligence

| Question | Owner | Deadline |
|---|---|---|
| Obtain customer concentration analysis: % of revenue from top 5, top 10, and top 20 customers. What is the full revenue distribution across the 280 customers? | Corp Dev + Finance | 2026-04-22 |
| Explain the $2.2M gap between recognized revenue ($9.2M) and ARR ($11.4M). What is the contract mix (monthly vs. annual vs. multi-year)? | Corp Dev + Finance | 2026-04-22 |
| Conduct reference calls with at least 5 additional customers, including at least 2 that are not among the top 5. Report any negative feedback. | Corp Dev | 2026-04-25 |
| Obtain the full NPS methodology and raw score. Is "high 40s" the current score or a trailing average? | Corp Dev | 2026-04-22 |

## 3. Integration and Retention

| Question | Owner | Deadline |
|---|---|---|
| Reconcile the integration plan with the strategic rationale: if Aurora is differentiated, why sunset it? What is the alternative integration approach? | VP Eng + Corp Dev | 2026-04-22 |
| Expand retention conversations beyond the VP Eng to include the CTO (Sarah Lin) and at least 3 key individual contributors. What are their intentions? | Corp Dev + VP Eng | 2026-04-25 |
| Develop a detailed customer migration plan: timeline, communication strategy, migration experience, and contingency for customers who resist. | VP Eng + Product | 2026-04-28 |
| Provide a detailed breakdown of the $3.2M synergy estimate: what specific costs are being eliminated, what is the timeline, and what are the one-time migration costs? | Corp Dev + Finance | 2026-04-25 |

## 4. Legal and Regulatory

| Question | Owner | Deadline |
|---|---|---|
| Complete legal review of all material contracts: customer agreements, vendor agreements, employment agreements, and IP assignments. Flag any change-of-control provisions. | Legal | 2026-04-28 |
| Assess Borealis's data privacy and security posture: SOC 2 status, GDPR/CCPA compliance, history of breaches or incidents. | Legal + Security | 2026-04-25 |
| Review Borealis's cap table: existing investors, liquidation preferences, anti-dilution provisions, redemption rights, fully diluted share count. | Legal + Corp Dev | 2026-04-22 |
| Identify any pending or threatened litigation, disputes, or regulatory investigations. | Legal | 2026-04-25 |

## 5. Competitive and Market

| Question | Owner | Deadline |
|---|---|---|
| Map the competitive landscape: who are Borealis's direct competitors, what is their market share, and are any competitors expanding or being acquired? | Corp Dev + Strategy | 2026-04-25 |
| Assess Borealis's win/loss rate and pipeline health. Is growth accelerating or decelerating? | Corp Dev | 2026-04-25 |

## 6. Engineering and Product

| Question | Owner | Deadline |
|---|---|---|
| Expand the engineering review to include a security assessment and compliance review. How many engineers conducted the original review, and how deep was it? | VP Eng | 2026-04-25 |
| Validate the product roadmap: what is the 12-month plan post-acquisition, and how does it align with our platform strategy? | Product + VP Eng | 2026-04-28 |

## 7. Financial

| Question | Owner | Deadline |
|---|---|---|
| Explain the burn rate acceleration: the pack notes 22 months of runway at last cap raise but only ~5.5 months now. Why has burn increased? | Corp Dev + Finance | 2026-04-22 |
| Obtain Borealis's debt schedule: any outstanding debt, convertible notes, or other financial obligations? | Corp Dev + Finance | 2026-04-22 |
| Model the post-acquisition P&L for 4 years, including integration costs, synergy realization timeline, and revenue impact of customer migration. | Finance | 2026-04-28 |
