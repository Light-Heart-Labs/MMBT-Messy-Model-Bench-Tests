# Borealis Analytics Acquisition — Independent Review

## How to Read This Output

This repository contains an independent review of the Corp Dev diligence pack for the proposed acquisition of Borealis Analytics for $84M.

### Files

| File | Description |
|---|---|
| [`memo.md`](memo.md) | **Primary deliverable.** A 1-page memo for the executive committee with recommendation, concerns, and diligence asks. |
| [`concerns.md`](concerns.md) | Full enumeration of every concern identified, ranked by impact (high, moderate, low). Includes 22 distinct concerns. |
| [`asks.md`](asks.md) | Specific diligence questions for the next 2 weeks, with owners and deadlines. Organized by category (valuation, customer, integration, legal, competitive, engineering, financial). |
| [`decisions/`](decisions/) | Architecture Decision Records (ADRs) documenting judgment calls made during the review. |

### Reading Order

1. Start with [`memo.md`](memo.md) for the executive summary and recommendation.
2. Read [`concerns.md`](concerns.md) for the full analysis.
3. Review [`asks.md`](asks.md) for the action items.
4. Check [`decisions/`](decisions/) for context on methodological choices.

### Methodology

- The diligence pack (`/input/repo/deal_pack.md`) is the sole source of facts.
- No external data, customer names, or financial figures were introduced.
- The Corp Dev recommendation was treated as one input, not a conclusion.
- Concerns are ranked by potential impact on the go/no-go decision.

### Recommendation Summary

**HOLD** — Conditional proceed pending targeted diligence. The deal has merit but the pack contains material gaps and internal inconsistencies that must be resolved before committing $84M.
