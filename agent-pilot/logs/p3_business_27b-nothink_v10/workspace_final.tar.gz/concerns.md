# Concerns with the Borealis Analytics Deal Pack

## HIGH-IMPACT CONCERNS

### 1. Valuation: Comps are insufficiently contextualized

The pack justifies the $84M valuation (~7.4x ARR) by citing three comparable transactions: Hexa Insights (~9x ARR), Aspen Data (~12x ARR), and Trellis Analytics (~7x ARR). However:

- **No deal structure detail:** Were these all-cash, stock-heavy, or earn-out deals? An earn-out-heavy deal at 7x ARR is not equivalent to a 7x cash deal.
- **No growth-rate context:** What were the YoY growth rates of these targets at time of acquisition? Borealis grew 80-92% YoY, which may command a premium or discount depending on the comps' growth profiles.
- **No strategic premium context:** Were these buyers acquiring for strategic synergies (as we are)? Strategic deals often carry premiums that make them poor comps for "fair market" valuation.
- **Aspen Data at 12x ARR is an outlier** that pulls the average up. The pack uses it to justify the range but doesn't explain why Borealis should be valued closer to 7.4x rather than 12x — or conversely, why Aspen's premium doesn't suggest Borealis is undervalued.

**Risk:** The valuation could be 15-25% off in either direction.

### 2. Integration plan contradicts strategic rationale

The pack states Aurora "overlaps minimally with our existing offerings (~12% feature overlap)" and that Borealis's product is "differentiated vs current alternatives." Yet the integration plan calls for **Aurora platform sunset at 12 months post-close** with customer migration to our platform.

This is internally inconsistent:
- If Aurora is truly differentiated and complementary, why sunset it?
- If we're migrating customers to our platform, what happens to the features that make Aurora differentiated?
- The 4-6 month integration timeline seems aggressive for a full platform migration of 280 customers.

**Risk:** Customer churn post-acquisition if the migration experience is poor or if key Aurora features are lost.

### 3. Retention estimate is based on a single source

The pack states "~85% retention expected based on conversations with their VP Eng." This is a single-source estimate for a critical assumption. The CTO (Sarah Lin) is not mentioned as part of these conversations. Key individual contributors are not mentioned.

**Risk:** Actual retention could be significantly lower, especially if the CTO or other key engineers decide not to join.

### 4. No customer migration plan is detailed

The pack mentions "customer migration to our integrated platform" but provides no detail on:
- How migration will be communicated to customers
- What the migration experience looks like
- What happens to customers who resist migration
- Timeline for migration (is it all at once or phased?)

**Risk:** Migration could trigger churn that exceeds the synergy savings.

### 5. Revenue recognition vs ARR gap is not explained

The pack reports $9.2M in recognized GAAP revenue but $11.4M in ARR. The $2.2M gap is not explained. While this is typical for SaaS (deferred revenue), the pack doesn't clarify:
- What portion of the gap is deferred revenue vs. other adjustments
- Whether there are any unusual revenue recognition issues
- The contract mix (monthly vs. annual vs. multi-year)

**Risk:** Revenue quality may be lower than implied.

### 6. Customer concentration risk is not addressed

The pack mentions ~280 paid customers and that the "five largest customers" were contacted for reference calls. However:
- What percentage of revenue comes from the top 5, top 10, or top 20 customers?
- Are there any single-customer dependencies?
- The median ARR per customer is $32K, but what is the distribution? A few large customers could dominate revenue.

**Risk:** Loss of a few key customers could materially impact the business.

### 7. No competitive landscape analysis

The pack makes no mention of:
- Who Borealis's direct competitors are
- Whether competitors are acquiring or expanding in this space
- Whether Borealis is losing or winning share
- Any competitive threats that could accelerate or decelerate growth

**Risk:** The market dynamics may be changing in ways that affect the value proposition.

### 8. Synergy estimate lacks detail

The pack estimates "$3.2M annual cost savings from consolidated infra" but provides no breakdown:
- What specific costs are being eliminated?
- What is the timeline for realizing these savings?
- Are there any one-time migration costs?
- Is the $3.2M net of any transition costs?

**Risk:** Synergies may be overstated or take longer to realize than assumed.

### 9. IRR estimate is not explained

The pack states "Risk-adjusted IRR estimate is in the 28-34% range over the 4-year hold" but provides no methodology:
- What assumptions drive this range?
- What is the "risk adjustment"?
- What is the base case vs. upside/downside scenarios?

**Risk:** The IRR may be overly optimistic.

### 10. No legal or regulatory diligence is mentioned

The pack is signed off by VP Corp Dev, VP Eng, and CFO. There is no mention of:
- Legal review of contracts, IP, or employment agreements
- Regulatory considerations (data privacy, GDPR, CCPA compliance)
- Any pending litigation or disputes
- Change-of-control provisions in customer or vendor contracts

**Risk:** Undiscovered legal issues could delay or derail the deal.

---

## MODERATE-IMPACT CONCERNS

### 11. Customer testimonials are curated

The pack presents 4 customer quotes, all positive, from 5 reference calls. This is expected for a deal pack, but:
- No negative feedback is presented
- The quotes are generic and could apply to any analytics tool
- We don't know if the 5 customers contacted were cherry-picked

### 12. NPS "in the high 40s" is not exceptional

The pack describes NPS as "strong" at "the high 40s." In SaaS, NPS of 40-50 is good but not exceptional. Top-tier SaaS companies often report NPS in the 60s or 70s.

### 13. Burn rate and runway

The pack reports a $750K monthly burn rate and $4.1M cash on hand, implying ~5.5 months of runway. However, the pack also states "22 months runway at last cap raise," which suggests the burn rate has increased significantly since the last raise. The pack doesn't explain why burn has accelerated.

### 14. No mention of Borealis's cap table or existing investor positions

The pack doesn't discuss:
- Who Borealis's existing investors are
- What their liquidation preferences are
- Whether there are any anti-dilution or redemption rights
- The fully diluted share count

### 15. Engineering review scope is unclear

The pack states "Engineering review found no concerning patterns" but doesn't specify:
- How many engineers from our side conducted the review
- How deep the review went (code audit, architecture review, security review?)
- Whether the review included security or compliance assessment

### 16. Product roadmap validation is superficial

The pack states "Our PM team validated all three [major features] are differentiated vs current alternatives" but doesn't specify:
- How the validation was conducted
- What "current alternatives" were compared against
- Whether the validation included competitive benchmarking

### 17. No mention of data privacy or security posture

Borealis is a "customer-data-analytics" company. The pack doesn't mention:
- SOC 2 or other security certifications
- Data residency or sovereignty considerations
- History of data breaches or security incidents
- GDPR/CCPA compliance status

### 18. Cash-heavy preference is not addressed

The pack notes "Borealis preference is cash-heavy" but doesn't discuss:
- What "cash-heavy" means in terms of the split
- Whether our treasury can support the cash portion
- The tax implications of the payment structure

---

## LOW-IMPACT CONCERNS

### 19. Logo retention of 91% is "within typical range"

The pack describes 91% logo retention as "within typical range." For a Series A company, this is actually quite good. The pack may be understating this metric.

### 20. No mention of Borealis's hiring plan

The pack doesn't discuss whether Borealis plans to hire post-acquisition, which could affect integration costs and synergy estimates.

### 21. The pack doesn't address cultural fit

There is no discussion of cultural compatibility between Borealis and our organization, which is a significant factor in M&A success.

### 22. No mention of Borealis's debt or other liabilities

The pack doesn't discuss whether Borealis has any debt, convertible notes, or other financial obligations.
