# ADR-002: Treatment of Comparable Transactions

**Status:** Accepted
**Date:** 2026-04-15

## Context

The pack cites three comparable acquisitions (Hexa Insights at ~9x ARR, Aspen Data at ~12x ARR, Trellis Analytics at ~7x ARR) to justify the 7.4x ARR valuation.

## Decision

These comps are treated as suggestive, not determinative. The pack provides no detail on deal structure (earn-outs, contingent consideration), target growth rates at time of sale, or strategic synergies that may have inflated those multiples. The comparison is therefore incomplete.

## Consequences

The valuation assessment in the memo flags the comps as insufficiently contextualized and calls for deeper analysis of deal structures.
