# ADR-003: Treatment of Integration Plan

**Status:** Accepted
**Date:** 2026-04-15

## Context

The pack proposes a 4-6 month integration timeline with Aurora sunset at 12 months post-close, and ~85% team retention based on conversations with the VP Eng only.

## Decision

The integration plan is flagged as high-risk. Key concerns: (a) the plan to sunset Aurora contradicts the strategic rationale that Aurora is differentiated; (b) retention estimate is based on a single source; (c) no customer migration plan is detailed.

## Consequences

The memo recommends that the integration plan be reworked and that retention conversations expand beyond the VP Eng to include the CTO and key individual contributors.
