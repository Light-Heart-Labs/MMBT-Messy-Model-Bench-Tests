# ADR-001: Scope of Review

**Status:** Accepted
**Date:** 2026-04-15

## Context

The executive committee asked for an independent review of the Corp Dev diligence pack for the Borealis Analytics acquisition. The pack is an advocacy document prepared by the deal team.

## Decision

This review treats the pack as one input, not a conclusion. The goal is to surface gaps, overclaims, and missing context that would affect a go/no-go decision. No external data is introduced; all observations reference the pack directly.

## Consequences

- The memo is structured to highlight concerns first, then recommendation, then asks.
- Where the pack is silent on a material topic, that silence is flagged as a concern.
- The recommendation is conditional — it can change based on diligence outcomes.
