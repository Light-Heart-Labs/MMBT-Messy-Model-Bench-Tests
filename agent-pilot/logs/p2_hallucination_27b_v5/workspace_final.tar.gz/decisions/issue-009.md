# ADR: Issue 009 — format_legacy() wrong file citation

## Issue

The report claims `format_legacy()` is in `logalyzer/output.py` and is unused.

## Finding

`format_legacy()` does exist, but in `logalyzer/utils.py:21`, not `output.py`.
It is indeed unused by any other module in the codebase (confirmed by grep).

## Decision

**Verdict: fabricated**

Per the rules: "A wrong file citation makes the issue fabricated. If issue 009 claims a function is in `output.py` but the function actually lives in `utils.py`, the issue as written is fabricated."

The underlying observation (unused function) is valid, but the specific claim about `output.py` is false. A reviewer reading the original report would look in `output.py`, find nothing, and be misled.

## Note

If this were a real code review, the correct action would be to file a new issue citing `utils.py:21` instead. But for verification purposes, the original claim is fabricated.
