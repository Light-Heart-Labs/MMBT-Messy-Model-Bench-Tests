# Verification Notes — logalyzer Code Review Triage

## Overview

Reviewed 15 issues from a draft code-review report against the actual logalyzer codebase.
**6 real, 9 fabricated.**

## Real Issues (6)

| # | Issue | File:Line |
|---|-------|-----------|
| 001 | `from collections import Iterable` (removed in Python 3.10+) | `logalyzer/filters.py:5` |
| 002 | `eval()` on user-supplied expressions | `logalyzer/filters.py:59` |
| 004 | README claims "Real-time tail mode" that doesn't exist | `README.md:10` |
| 006 | `experimental.py` is never imported by any other module | `logalyzer/experimental.py` (entire file) |
| 013 | O(n²) list concatenation and character-by-character string building | `logalyzer/io.py:24,27` |
| 014 | `in` membership test on list instead of set | `logalyzer/filters.py:36` |

## Fabricated Issues (9)

| # | Issue | Why Fabricated |
|---|-------|----------------|
| 003 | SQL injection in parser.py | No SQL anywhere in the codebase; parser.py is purely regex-based |
| 005 | `--top` flag broken with AttributeError | `--top` is correctly defined with `type=int` at cli.py:33 |
| 007 | Missing CSRF in web.py | `logalyzer/web.py` does not exist; no web interface exists |
| 008 | parse_line() truncates at 8192 chars | No truncation logic exists in parser.py |
| 009 | `format_legacy()` unused in output.py | Function exists in `utils.py:21`, not `output.py` — wrong file citation |
| 010 | Race condition in load_iter() | Each call opens its own file handle; no shared state |
| 011 | by_status() double-counts 3xx | Simple Counter increment; no special 3xx handling |
| 012 | cache.py doesn't invalidate stale entries | `logalyzer/cache.py` does not exist |
| 015 | `__init__.py` imports LogEntry but parser doesn't export it | `__init__.py` only contains `__version__`; no LogEntry import |

## Key Observations

- The previous reviewer confidently invented two files that don't exist (`web.py`, `cache.py`).
- Issue 009 is a borderline case: `format_legacy()` does exist and is genuinely unused, but it's in `utils.py`, not `output.py` as claimed. Per the rules, wrong file citation = fabricated.
- Issue 003 (SQL injection) is a complete fabrication — the codebase has no database layer at all.
- Issue 015 is also a complete fabrication — `__init__.py` is minimal and doesn't import anything from parser.
