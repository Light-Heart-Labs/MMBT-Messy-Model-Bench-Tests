# Project Aurora — Working Notes

## Synthesis Process

### Workstreams
- **Dashboard refresh**: core product; backend ready-ish; query-layer in progress (8 weeks estimate → revised to 60% done, mid-May target, week 6).
- **Embedded SDK**: part of Aurora; blocked on security/access-control; decision made (week 6) to ship as private-beta with 3–5 customers (Option B).
- **Mobile**: UX gap identified; scope reduced from native iOS/Android (12+ weeks) to web-responsive (4 weeks); on track for mid-May (week 4, 6).
- **Custom branding**: deferred to V2 (week 3 decision); Jen pivots capacity to mobile.
- **Panel-density / architecture**: 40-panel limit accepted as V1 known limitation; architectural fix planned as V1.1 (week 3, 4, 6).
- **Security / IAM**: access-control gap discovered (week 4); Priya engaged (week 5); IAM design started (week 6).

### Risks
- **SDK V1 blocked on access-control** → resolved via Option B (private-beta with 3–5 customers).
- **Panel-density limit (40 panels/page)** → accepted as V1 limitation with clear docs.
- **Maevia customer commitment** → GA promise at conference conflicts with private-beta plan; Sara handling (week 6).
- **Query-layer review bottleneck** → resolved by adding Aanya as sub-reviewer (week 4).
- **Mobile scope creep** → resolved by deferring native to V2 (week 4).

### Decisions (chronological)
1. **week 3**: Cut custom-branding from V1; document 40-panel limit (Brendan).
2. **week 4**: Mobile = web-responsive in V1, native in V2 (Sara/Jen agreement).
3. **week 6**: Ship SDK V1 as private-beta with 3–5 customers (Brendan, Option B).

### Milestones (from notes)
- **Mid-May**: query-layer completion (Marcus, week 4, 6).
- **Mid-May**: mobile-responsive (Jen, week 4, 6).
- **August**: V1.1 with architectural fix (Roman, week 3, 4, 6).
- **End of June**: original target (Brendan, week 1) — no longer realistic.
- **Mid-July**: revised GA target considered (week 3) — superseded by Option B.

### Open questions / asks for CEO
- Legal timeline for private-beta contracts (Sara needs legal involvement).
- Maevia customer comms strategy (Sara has call with CSM; may need Brendan support).
- Final approval of Option B (private-beta) plan.
