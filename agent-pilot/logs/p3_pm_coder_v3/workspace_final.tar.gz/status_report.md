# Project Aurora — Status Report (as of 2026-04-08)

## Headline

Aurora (dashboard refresh + embedded SDK) is on track for a mid-May query-layer completion and mid-May mobile-responsive delivery, with GA targeted for end-July. SDK V1 will ship as a private-beta with 3–5 customers after legal contracts are in place; custom-branding is deferred to V2.

## Workstreams

| Workstream | Owner | Status | Blocking V1? |
|------------|-------|--------|--------------|
| Dashboard backend / query-layer | Marcus | 60% done; tracking to mid-May (Aanya reviewing) | Yes — query-layer is core to V1 |
| Embedded SDK | Marcus/Sara | Private-beta plan approved (Option B); legal contracts pending | Yes — SDK is part of V1 scope, but delivery is via private-beta with 3–5 customers |
| Mobile (responsive) | Jen | On track for mid-May; native deferred to V2 | No — mobile is nice-to-have for V1; dashboard is core |
| Custom branding | Jen | Deferred to V2 (Brendan decision, week 3) | No |
| Panel-density / architecture | Roman | 40-panel limit accepted as V1 known limitation; architectural fix planned for V1.1 (August) | No — documented limitation |
| Security / IAM | Priya (security) + Roman | IAM design started; API discussion upcoming | Yes — access-control gap was a blocker; mitigated via private-beta |

## Risks

| Severity | Risk | Mitigation |
|----------|------|------------|
| High | Maevia customer pushback (promised GA SDK at conference) | Sara to engage CSM; may need Brendan support |
| High | Legal delay on private-beta contracts | Sara escalating internally |
| Medium | 40-panel-per-page limit causes customer issues | Documented in V1 docs; V1.1 (August) includes architectural fix |
| Medium | Query-layer review bottleneck | Aanya added as sub-reviewer; on track |

## Decisions Made

| Date | Decision | Decider |
|------|----------|---------|
| 2026-03-18 (week 3) | Cut custom-branding from V1; document 40-panel limit | Brendan |
| 2026-03-25 (week 4) | Mobile = web-responsive in V1; native in V2 | Sara/Jen agreement |
| 2026-04-08 (week 6) | Ship SDK V1 as private-beta with 3–5 customers (Option B) | Brendan |

## Milestones

| Target | Owner | Deliverable |
|--------|-------|-------------|
| Mid-May | Marcus | Query-layer completion |
| Mid-May | Jen | Mobile-responsive (web) |
| August | Roman | V1.1 with architectural fix |
| End-July | Team | GA (dashboard + private-beta SDK) |

## Open Questions / Asks

1. **Legal timeline** for private-beta customer contracts — need confirmation to proceed.
2. **Maevia comms strategy** — Brendan support may be needed if pushback occurs.
3. Final approval of Option B (private-beta) plan.
