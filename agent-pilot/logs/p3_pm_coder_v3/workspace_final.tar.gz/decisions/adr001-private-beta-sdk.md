# ADR 001: SDK V1 Delivery Strategy

**Date:** 2026-04-08 (week 6)  
**Decider:** Brendan (CEO)  
**Status:** Approved

## Context

The embedded SDK V1 has an unresolved security/access-control gap (identified week 4). Security team (Priya) estimates 4 weeks minimum for proper IAM design + API + audit logging (week 5). Adding this would push V1 to August, conflicting with customer commitments.

## Options Considered

1. **Ship V1 without SDK** (dashboard only); SDK becomes V1.5 in August.  
2. **Ship V1 with SDK but private-beta only** with 3–5 customers who sign extra contracts about access control.  
3. **Push V1 to August** with everything (full SDK + IAM).

## Decision

**Option B** — Ship SDK V1 as private-beta with 3–5 customers.

## Rationale

- Brendan confirmed Option B via Slack (2026-04-08): “We have access-control commitments to make right but we cannot delay V1 entirely.”
- Maintains Aurora’s timeline while managing risk.
- Legal involvement required for customer contracts.

## Implementation

- Sara to engage legal for contract draft.
- Sara to handle Maevia comms (they were promised GA at conference).
- Security team (Priya) to continue IAM design in parallel.

## Consequences

- **Positive:** Keeps V1 on track; satisfies Brendan’s timeline constraint.
- **Negative:** Requires legal overhead; Maevia may push back; limited customer base for SDK feedback in V1.
