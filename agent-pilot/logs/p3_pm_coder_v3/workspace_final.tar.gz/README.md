# Project Aurora — Status Report Package

## Files

- **`status_report.md`** — The structured status report for the CEO (Brendan). Read this first.
- **`research/notes.md`** — Working notes showing how the report was synthesized from the 6 weekly meeting notes.
- **`decisions/adr001-private-beta-sdk.md`** — Architectural Decision Record for the SDK V1 private-beta strategy.

## How to Read

1. Start with `status_report.md` for the concise, executive summary.
2. Use `research/notes.md` to trace claims back to specific weeks in the meeting log.
3. See the ADR for deeper context on the SDK delivery decision.
