# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Recommendation

**Date:** 2026-03-10
**To:** Investment Committee
**From:** Deal Analysis Team
**Subject:** Series B follow-on evaluation — Nimbus Logistics

---

## Recommendation: PASS

We recommend passing on a follow-on investment in Nimbus Logistics at this time. The company shows genuine product-market fit in mid-market e-commerce logistics, but execution risks — customer concentration, negative unit economics, and active restructuring — outweigh the upside. This recommendation would change only if the diligence items below are satisfactorily resolved.

---

## What the Company Says vs. What the Data Shows

Nimbus closed an $84M Series B in January 2026 at a $560M post-money valuation, led by Lightning Capital with participation from Sequoia, Accel, and FedEx Ventures [Source 1]. The company reports $42M in ARR, up from $11M a year prior, serving 1,400+ e-commerce brands [Source 1].

The picture is more complicated. Two of Nimbus's top-five customers exited in late 2025 — Sundry Brands ($4.2M ARR, November) and Klatch (December, migrated to a competitor) [Source 2]. Adjusted for this churn, the current run-rate ARR is closer to $36–37M [Source 2]. The Series B was originally priced at $720M but was repriced down after the Sundry non-renewal became known to the lead investor [Source 2].

---

## The Economics: Burn, Concentration, and Restructuring

According to a former senior engineer, Nimbus was burning approximately $4M/month against roughly $3.5M/month in revenue as of mid-2025 — a net burn of ~$500K/month [Source 3]. The company quietly laid off 22 people (~11% of the organization) in February 2025, primarily in customer success and business development, without public announcement [Source 3].

Customer concentration is a material risk: the top five customers accounted for approximately 38% of ARR [Source 3]. Losing two of those five in a single quarter is a significant shock.

The company is actively restructuring. An internal memo obtained by The Information outlines a 30% reduction in Berlin headcount (from 41 to 28–30), a deferral of international expansion to 2027, and the sunset of the "Nimbus Lite" product tier affecting ~310 small customers [Source 4]. The memo also discloses a $50M credit facility from Silicon Valley Bridge, described as "insurance, not operating capital" [Source 4].

---

## Source Quality and Confidence

- **Press release [Source 1]:** Company narrative. The $42M ARR figure is technically accurate as a Q4 snapshot but includes terminated contracts.
- **TechCrunch [Source 2]:** Journalistic reporting citing unnamed sources. The Sundry non-renewal was confirmed by a company spokesperson; the Klatch exit was not.
- **Former employee blog [Source 3]:** One person's account. The burn rate and layoff figures are specific but independently unverifiable. The customer concentration figure (38%) is plausible given the Sundry loss.
- **Leaked memo [Source 4]:** Internal document with high specificity. The company declined to confirm details. We treat it as credible but not definitive.
- **SEC Form D [Source 5]:** Regulatory filing. Confirms the $84M raise, seven investors, and Series B Preferred equity. Limited analytical value beyond confirmation.

---

## What Would Change Our View

We would reconsider a follow-on if:
1. **Customer concentration improves:** Top-five customer share drops below 25% of ARR, with evidence of a diversified pipeline.
2. **Path to profitability is credible:** The Q4 2026 breakeven target [Source 4] is supported by audited financials showing declining burn and growing net revenue retention.
3. **International strategy is clarified:** Either the Berlin office is stabilized with a clear go-to-market plan, or the company commits to a U.S.-only focus with corresponding cost reductions.
4. **The $50M credit facility terms are understood:** We need to know the interest rate, covenants, and draw conditions. A high-cost facility could constrain flexibility.

---

## Bottom Line

Nimbus has a strong engineering team and a real product in a large market. But the company is burning cash, has lost significant customers, is restructuring aggressively, and has not yet demonstrated a path to profitability. The $560M valuation implies a company that has solved these problems — and the evidence suggests it hasn't. We recommend passing, with the option to revisit if the above diligence items are addressed.
