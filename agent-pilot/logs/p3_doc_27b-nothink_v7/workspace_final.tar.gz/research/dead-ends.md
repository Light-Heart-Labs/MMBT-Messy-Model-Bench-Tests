# Dead Ends — Ideas Considered and Abandoned

## Considered but not included in brief

1. **Deep dive on FedEx Ventures strategic investment**: The press release mentions FedEx Ventures as a strategic investor, which could signal distribution channel access. However, the internal memo's pivot away from international expansion and the sunset of the Lite tier suggest the strategic value may be limited. Not enough detail to make this a central argument.

2. **CTO Daniel Wong's engineering quality as a moat**: The ex-employee praises the tech stack heavily. While interesting, engineering quality alone doesn't drive investment decisions. Mentioned briefly in the brief but not a primary factor.

3. **Compensation analysis**: The ex-employee's $215K base + $50K equity is interesting for talent retention context, but not directly material to an investment decision. Omitted.

4. **The three new $1M+ contracts claimed by CEO**: TechCrunch reports the CEO's claim but doesn't independently verify. Too uncertain to build an argument on. Mentioned as a counterpoint but not relied upon.

5. **Berlin office real estate implications**: The 30% headcount reduction in Berlin could have lease obligations. No data on this in the sources, so omitted.

6. **Comparison to sector benchmarks**: No external benchmark data available in sources. Avoided making any sector-relative claims.

7. **The three undisclosed investors in Form D**: Could be notable but no information available. Omitted.
