# Nimbus Logistics — Follow-On Investment Brief

## How to Read This Output

### Primary Deliverable
- **`brief.md`** — The 1-page executive brief (677 words). This is the main output. Read this first.

### Supporting Materials
- **`key-facts.md`** — Every material fact incorporated into the brief, with source attribution. Use this to verify that no numbers were invented and all claims trace to the five source documents.
- **`research/notes.md`** — Working notes from reading the five source documents. Includes source-by-source summaries, key tensions identified, and source quality assessment.
- **`research/dead-ends.md`** — Ideas considered during analysis but not included in the final brief, with rationale for exclusion.
- **`decisions/adr-001-recommendation-stance.md`** — ADR explaining why the recommendation is "Pass" rather than "More diligence needed."
- **`decisions/adr-002-arr-figure.md`** — ADR explaining the choice to lead with the adjusted ARR figure ($36–37M) rather than the company's claimed $42M.

### Source Documents
All analysis is based solely on the five documents in `/input/repo/sources.md`:
1. **Source 1:** Company press release (2026-01-14)
2. **Source 2:** TechCrunch news article (2026-01-15)
3. **Source 3:** Former employee blog post (2026-02-22)
4. **Source 4:** Leaked internal memo via The Information (2026-03-05)
5. **Source 5:** SEC Form D filing summary (2026-01-22)

### Citation Convention
The brief uses `[Source N]` inline citations corresponding to the five source documents above. Every factual claim in the brief traces to at least one source. No external data or invented numbers were used.
