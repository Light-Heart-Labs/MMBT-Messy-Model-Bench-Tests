# Key Facts Incorporated in Brief

Each fact is attributed to its source. Sources:
- [S1] = Press Release (company-issued, 2026-01-14)
- [S2] = TechCrunch article (2026-01-15)
- [S3] = Former employee blog post (2026-02-22)
- [S4] = Leaked internal memo via The Information (2026-03-05)
- [S5] = SEC Form D filing (2026-01-22)

## Financial Facts
1. $84M Series B raised, led by Lightning Capital — [S1], [S5]
2. Post-money valuation: $560M — [S1]
3. Previous valuation: $230M (Series A, 2023) — [S1]
4. Total funding across all rounds: $128M — [S1]
5. ARR reported: $42M as of Q4 2025 — [S1]
6. ARR a year prior: $11M — [S1]
7. Adjusted ARR after churn: $36-37M — [S2]
8. Sundry Brands non-renewal: $4.2M ARR, November 2025 — [S2]
9. Klatch exit: December 2025, migrated to competitor — [S2]
10. Burn rate: ~$4M/month (mid-2025) — [S3]
11. Revenue rate: ~$3.5M/month (mid-2025) — [S3]
12. Net burn: ~$500K/month — [S3] (derived from #10 and #11)
13. $50M credit facility from Silicon Valley Bridge — [S4]
14. Runway: 24+ months at current burn, 36+ months with restructuring — [S4]
15. Series B originally priced at $720M, repriced down to $560M — [S2]

## Customer Facts
16. 1,400+ e-commerce brands on platform — [S1]
17. Top 5 customers = ~38% of ARR — [S3]
18. Lost 2 of top 5 customers in late 2025 — [S2]
19. Nimbus Lite tier sunset: ~310 customers affected ($5K-$20K ARR each) — [S4]
20. CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 — [S2]
21. Net retention claimed above 110% — [S2]

## Organizational Facts
22. 187 employees across Oakland, Austin, Berlin — [S1]
23. 22 layoffs in February 2025 (~11% of org), not publicly announced — [S3]
24. Berlin headcount: 41 → 28-30 by end Q2 2026 (30% reduction) — [S4]
25. International expansion deferred to 2027 — [S4]
26. Berlin reframed as "support hub" — [S4]
27. Target: operating-cash-flow breakeven by Q4 2026 — [S4]

## Investor Facts
28. Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (strategic), 3 undisclosed — [S1], [S5]
29. 7 total investors in Series B — [S5]
30. Security type: Series B Preferred Equity — [S5]
31. Use of proceeds: "expansion, working capital, general corporate purposes" — [S5]

## Company Facts
32. Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) — [S1]
33. Platform: warehouse management, carrier orchestration, demand forecasting — [S1]
34. Customers include Maevia, Truant Coffee, Brick & Cobble — [S1]
