# ADR-001: Recommendation Stance — "Pass" vs. "More Diligence"

## Context

The brief needs one clear recommendation. The data shows:
- Strong engineering and product-market fit in mid-market e-commerce
- Significant customer concentration risk (top 5 = 38% ARR, lost 2 of 5)
- ARR discrepancy ($42M claimed vs. $36-37M adjusted)
- Negative cash flow (~$500K/month net burn)
- Restructuring underway (layoffs, international pause, product tier sunset)
- $50M credit facility secured as backup
- Runway extended to 36+ months with restructuring

## Decision

**Recommendation: Pass — unless specific diligence items are resolved.**

Rationale: The company is actively restructuring, has hidden layoffs from the market, repriced its round downward, and is burning cash. While the engineering is strong and the market is large, the execution risks are elevated. The 36-month runway provides time, but the path to profitability requires assumptions about growth that haven't been demonstrated.

The "more diligence needed" framing would be more honest but the instruction requires a clear stance. "Pass" is the clear stance, with specific conditions under which it could change.

## Alternatives Considered

- **"Invest"**: Too optimistic given the churn, burn, and restructuring signals.
- **"More diligence needed"**: More nuanced but hedges. The brief can state "Pass" and then list what would change the recommendation.
