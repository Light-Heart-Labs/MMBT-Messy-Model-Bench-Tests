# ADR-002: ARR Figure to Lead With

## Context

The company claims $42M ARR [Source 1]. TechCrunch sources say adjusted ARR is $36-37M after accounting for the Sundry ($4.2M) and Klatch losses [Source 2]. The ex-employee corroborates the Sundry loss was expected internally [Source 3].

## Decision

**Lead with the adjusted figure ($36-37M) while acknowledging the company's $42M claim.**

Rationale: The $42M figure includes contracts that have already terminated. An investor evaluating current economics should see the run-rate number. The press release figure is technically accurate as a snapshot of Q4 2025 but misleading for forward-looking assessment.

## Language Used

"ARR of $42M per the company's press release, but adjusted for late-2025 churn the current run-rate is closer to $36–37M."
