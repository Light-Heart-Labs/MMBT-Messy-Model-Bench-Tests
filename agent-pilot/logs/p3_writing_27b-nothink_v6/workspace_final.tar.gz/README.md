# Incident Rewrite Output

This directory contains three audience-tailored rewrites of an internal engineering memo documenting a 4-hour API outage on Friday (14:11–18:24 UTC). Each rewrite is constrained by the specifications in `/input/repo/audience_briefs.json` and draws facts exclusively from the source memo at `/input/repo/draft_memo.md`.

## Files

| File | Audience | Max Words | Actual |
|------|----------|-----------|--------|
| `ceo_brief.md` | CEO / Board prep | 250 | 206 |
| `customer_email.md` | Affected customers | 350 | 260 |
| `legal_summary.md` | In-house counsel | 400 | 253 |
| `decisions/adr-rewrite-choices.md` | ADR-style records of non-obvious editorial choices | — | — |
| `research/notes.md` | Working notes with extracted facts and per-audience decisions | — | — |

## How to Read

Each rewrite is a standalone document. The CEO brief is a 5-minute executive summary with board-level signals. The customer email is a mass communication offering accountability and SLA credits. The legal summary is a factual record for SLA-credit determination. The ADR document explains editorial choices such as what was omitted per audience and why.
