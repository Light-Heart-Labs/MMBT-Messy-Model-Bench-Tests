# Architecture Decision Records — Rewrite Choices

## ADR-01: CEO Brief — Omission of Technical Root Cause Detail

**Status:** Accepted

**Context:** The source memo contains a detailed explanation of the root cause involving rate-limit thresholds, a hard-coded MAX value, and internal limiter fraction computation. The CEO brief spec explicitly forbids engineering jargon and detailed fraction-against-MAX explanations.

**Decision:** Replace the technical explanation with a plain-language summary: "A configuration update intended to increase request limits inadvertently triggered an internal safeguard that blocked all authentication requests." This preserves the causal chain (config change → unintended block → API failure) without introducing terms like "rate limiter," "MAX," or "throttling."

**Consequences:** The CEO loses the granular technical understanding but gains a clear, actionable summary. Technical details are available in the separate engineering postmortem referenced in the source memo.

---

## ADR-02: Customer Email — Omission of Named Engineer and "Second Outage" Framing

**Status:** Accepted

**Context:** The source memo names Marcus as the engineer who deployed the config change and frames the incident as the "second outage in 90 days." The customer email spec explicitly forbids both.

**Decision:** Remove all references to Marcus and any framing about this being a recurring pattern. The customer email focuses solely on the current incident, its impact, and remediation commitments.

**Consequences:** Customers receive a single-incident narrative without the potentially alarming context of repeated outages. The "second outage" framing is preserved in the CEO brief where it serves as a board-level signal.

---

## ADR-03: Customer Email — Inclusion of "Trust" Language

**Status:** Accepted

**Context:** The customer email spec requires a warm, accountable tone. The closing line "We understand that trust is earned through action, not words" was included to meet this requirement.

**Decision:** Include a brief trust-building statement in the closing. This is not marketing language — it is an accountability statement appropriate for the customer-facing tone.

**Consequences:** The email closes on a note of accountability rather than a purely transactional SLA-credit offer.

---

## ADR-04: Legal Summary — Use of "Incident" Over "Outage"

**Status:** Accepted

**Context:** The legal summary spec requires using "incident" not "outage."

**Decision:** All instances of "outage" in the source memo are replaced with "incident" in the legal summary. The title reads "Incident Summary" and the body uses "incident window" and "incident" consistently.

**Consequences:** The document maintains a dispassionate, factual tone appropriate for legal review.

---

## ADR-05: Legal Summary — Omission of Engineering Remediation Details

**Status:** Accepted

**Context:** The source memo lists five remediation items (staged config rollout, internal limiter fix, status-page fix, comms policy, runbook update). The legal summary spec explicitly excludes engineering remediation details as irrelevant to counsel.

**Decision:** Omit all remediation details from the legal summary. The document focuses exclusively on facts relevant to SLA-credit determinations: incident window, scope, SLA threshold, downstream harm, and credit-request handling recommendations.

**Consequences:** Legal counsel receives a focused document without extraneous technical information. Remediation details are available in the CEO brief and engineering postmortem.

---

## ADR-06: All Rewrites — Preservation of Source Numbers Only

**Status:** Accepted

**Context:** The rules prohibit inventing facts. Every number in the rewrites must be present in the source memo.

**Decision:** All numerical values (11,400 accounts, 28 enterprise accounts, 4 downstream cases, 217 tickets, 31 refund requests, 14:11–18:24 UTC, 99.9% SLA, 40 minutes, 47 minutes, 15 minutes) are drawn directly from the source memo. No interpolation or estimation was performed.

**Consequences:** The rewrites are faithful to the source material. Any gaps in the source memo (e.g., exact revenue impact figures) are not filled in.
