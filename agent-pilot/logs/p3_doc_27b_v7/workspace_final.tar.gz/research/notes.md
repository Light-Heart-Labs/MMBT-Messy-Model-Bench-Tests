# Working Notes — Nimbus Logistics Source Analysis

## Source-by-Source Summary

### Source 1: Press Release (2026-01-14)
- $84M Series B led by Lightning Capital
- Post-money valuation: $560M (up from $230M Series A in 2023)
- Total funding: $128M across all rounds
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400+ e-commerce brands on platform
- 187 employees across Oakland, Austin, Berlin
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (strategic)
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO)
- Platform: warehouse management + carrier orchestration + demand forecasting
- Named customers: Maevia, Truant Coffee, Brick & Cobble

### Source 2: TechCrunch (2026-01-15)
- Lost two top-five customers in late 2025:
  - Sundry Brands: $4.2M ARR, largest contract, non-renewal in November
  - Klatch: fast-fashion brand, exited December, migrated to competitor
- ARR adjusted for churn: $36-37M (vs. $42M in press release)
- $42M figure includes both contracts in their final quarter
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026
- Net retention claimed above 110%
- Series B was meant to close at $720M valuation but repriced down to $560M after Sundry news
- Repricing happened after lead investor learned of Sundry non-renewal in early December

### Source 3: Former Employee Blog (2026-02-22)
- Author: "Daniel R", former senior engineer, 14 months at Nimbus
- Positive: good architecture, strong CTO (Daniel Wong), genuine customer relationships, competitive comp ($215K base + $50K equity/year)
- Negative:
  - Burn: ~$4M/month all-in (mid-2025), revenue ~$3.5M/month → net burn ~$500K/month
  - Layoffs: 22 people (~11% of org) cut in February 2025, mostly customer success and BD, not publicly announced
  - Customer concentration: top 5 customers = ~38% of ARR
  - Sundry loss was not a shock internally
  - Path to profitability requires faster growth or significant cuts
- Would recommend for senior engineers but not for job security seekers

### Source 4: Leaked Internal Memo (2026-03-05)
- From CEO Mira Patel, dated Feb 28, 2026
- Restructuring plan to reach cash-flow breakeven by Q4 2026
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
- International expansion deferred to 2027; Berlin reframed as "support hub"
- Nimbus Lite tier sunset: ~310 customers ($5K-$20K ARR each) given 90-day notice
- New $50M credit facility from Silicon Valley Bridge secured
- Memo claims 24+ months runway at current burn, extended to 36+ months with restructuring
- Breakeven by Q4 2026 is trigger for Series C conversations

### Source 5: SEC Form D (filed 2026-01-22)
- Confirms $84M Series B, 7 investors total
- Securities: Series B Preferred Equity
- First sale date: 2026-01-14
- Use of proceeds: "expansion, working capital, general corporate purposes"
- No executive compensation disclosed in connection with offering
- Three additional investors beyond the four named in press release

## Key Tensions Identified

1. **ARR discrepancy**: $42M (press release) vs. $36-37M adjusted (TechCrunch sources)
2. **Valuation repricing**: $720M target → $560M actual, due to Sundry loss
3. **Customer concentration**: Top 5 = 38% of ARR (blog), loss of largest ($4.2M) is ~10% of reported ARR
4. **Burn rate**: $4M/month vs. $3.5M/month revenue = net burn ~$500K/month (blog)
5. **Layoffs not disclosed**: 22 people cut in Feb 2025 (blog), not in press materials
6. **International retreat**: Berlin headcount cut 30%, expansion deferred (memo) contradicts press release claim of "accelerate international expansion"
7. **Credit facility**: $50M from Silicon Valley Bridge (memo) not mentioned in press release
8. **Product tier elimination**: Nimbus Lite sunset affecting ~310 customers (memo)

## Numbers Cross-Check

- Employee count: 187 (press release) — but 22 were cut in Feb 2025 (blog), so pre-layoff was ~209
- Berlin headcount: 41 (memo), being cut to 28-30
- Monthly revenue: ~$3.5M (blog) → annualized ~$42M, consistent with press release
- Monthly burn: ~$4M (blog) → annualized ~$48M
- Net burn: ~$500K/month → ~$6M/year
- With $84M + $50M credit facility = $134M total capital, runway at $500K/month = ~27 months, consistent with memo's "24+ months" claim
- After restructuring (30% Berlin cut + Lite tier sunset), runway extended to 36+ months per memo

## Assessment Notes

- The company is raising at a significant discount from its target valuation
- Customer concentration is a real risk (38% in top 5)
- The burn rate is manageable with the new capital but requires the restructuring to work
- The international pivot is a retreat, not an expansion
- Engineering quality appears strong (blog, CTO reputation)
- The $50M credit facility is a positive signal of bankability but also suggests the company is hedging against slower growth
