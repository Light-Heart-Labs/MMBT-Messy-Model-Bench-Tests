# Dead Ends — Ideas Considered and Abandoned

## 1. "More Diligence Needed" as the Recommendation

**Considered:** A middle-ground recommendation of "more diligence needed" with a list of specific questions.

**Abandoned because:** The brief instructions explicitly discourage hedging. The available information is sufficient to form a view: the company is restructuring in ways that contradict its public narrative, and the valuation does not reflect known risks. A "pass" recommendation is more useful to a busy partner than a list of questions they could ask themselves.

## 2. Including the $50M Credit Facility as a Positive Signal

**Considered:** Framing the Silicon Valley Bridge credit facility as evidence of strong institutional confidence.

**Abandoned because:** While it is a positive signal, it is also a hedge against slower growth. The memo itself describes it as "insurance, not operating capital" [Source 4]. Including it as a net positive would understate the caution it implies. It is mentioned briefly in the "What's Working" section but not weighted heavily.

## 3. Quantifying the Impact of Nimbus Lite Sunset on ARR

**Considered:** Calculating the ARR impact of sunseting Nimbus Lite (~310 customers × $5K–$20K ARR each = ~$1.5M–$6.2M ARR).

**Abandoned because:** The range is too wide and the per-customer ARR is a range itself. The memo does not give a total ARR figure for the Lite tier. Including a calculated range would be speculation beyond what the source provides.

## 4. Comparing Nimbus to Industry Benchmarks

**Considered:** Adding context about typical SaaS burn rates, customer concentration norms, or Series B valuation multiples.

**Abandoned because:** No internet research is permitted, and the source pack provides no industry benchmarks. Adding external context would violate the "use only provided sources" rule.

## 5. Recommending a Specific Follow-On Valuation

**Considered:** Suggesting a discount to the $560M valuation that would make the deal attractive.

**Abandoned because:** There is insufficient information to calculate a fair valuation. The adjusted ARR ($36–37M), burn rate, and restructuring plans create too many unknowns. The recommendation is to wait, not to negotiate.

## 6. Including the Former Employee's Compensation Details

**Considered:** Using the $215K base + $50K equity figure as evidence of competitive compensation and financial health.

**Abandoned because:** While interesting, it does not materially affect the investment decision. It is omitted from the brief to save word count.

## 7. Treating the Leaked Memo as Ground Truth

**Considered:** Presenting the memo's claims (breakeven by Q4 2026, 36+ months runway) as facts.

**Abandoned because:** The memo is an internal document, not independently verified. The brief uses language like "the memo states" and "according to the memo" to maintain appropriate epistemic caution.
