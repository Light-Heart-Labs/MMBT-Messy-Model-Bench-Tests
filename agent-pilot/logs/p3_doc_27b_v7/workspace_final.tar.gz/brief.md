# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Assessment

**Date:** 2026-03-15
**Prepared for:** Investment Committee

---

## Recommendation: PASS

Do not commit follow-on capital at this time. Nimbus is executing a significant restructuring that contradicts its public growth narrative, and the $560M post-money valuation does not adequately price in customer concentration risk, recent churn, and the company's retreat from international expansion. Revisit after Q2 2026 restructuring results are visible.

---

## The Core Story

Nimbus Logistics closed an $84M Series B in January 2026 at a $560M post-money valuation, led by Lightning Capital with participation from Sequoia, Accel, and FedEx Ventures [Source 1]. The company reports $42M in ARR and 1,400 e-commerce brand customers [Source 1].

But the full picture is more complicated. The round was originally targeted at a $720M valuation and was repriced down after the lead investor learned of the non-renewal of Sundry Brands, Nimbus's largest customer at $4.2M ARR [Source 2]. A second top-five customer, Klatch, also exited in December 2025 [Source 2]. Adjusted for this churn, current run-rate ARR is closer to $36–37M, not the $42M cited in the press release [Source 2].

## Material Risks

**Customer concentration is acute.** According to a former senior engineer, the top five customers represented approximately 38% of ARR as of mid-2025 [Source 3]. The loss of Sundry alone represents roughly 10% of reported ARR. This concentration was "widely understood internally" [Source 3].

**The company is burning cash.** The former employee reports all-in monthly burn of approximately $4M against roughly $3.5M in monthly revenue, implying net burn of ~$500K/month [Source 3]. The $84M raise plus a separately secured $50M credit facility from Silicon Valley Bridge [Source 4] provides runway, but the path to profitability requires the restructuring to work.

**International expansion is being abandoned.** The press release states the new capital will "accelerate our expansion into international markets" [Source 1]. The leaked internal memo from CEO Mira Patel, dated February 28, 2026, tells a different story: a 30% reduction in Berlin headcount (from 41 to 28–30), a pause on EMEA hiring, and international expansion deferred to 2027 at earliest [Source 4].

**The company is shedding its smallest customers.** The internal memo reveals that the "Nimbus Lite" tier is being sunset entirely, affecting approximately 310 customers with $5K–$20K ARR each [Source 4]. This is a rational move to improve unit economics but signals that the bottom of the funnel is not profitable.

**Layoffs were not disclosed.** The company quietly cut 22 employees (~11% of the organization) in February 2025, primarily in customer success and business development [Source 3]. This was not announced publicly.

## What's Working

Engineering quality appears genuine. The former employee describes the carrier-orchestration layer as "some of the cleanest distributed-systems code" he has worked on, and CTO Daniel Wong is described as "the real deal" [Source 3]. Customer relationships in the mid-market segment are strong [Source 3]. The $50M credit facility suggests institutional confidence in the balance sheet [Source 4].

## Source Quality Notes

- **Press release [Source 1]:** Company's preferred narrative; aspirational.
- **TechCrunch [Source 2]:** Most reliable external account; cites two sources familiar with company finances.
- **Former employee blog [Source 3]:** Single perspective but internally consistent; burn figures and layoff details are plausible but unverified.
- **Leaked memo [Source 4]:** Attributed to CEO Patel, obtained by The Information; most authoritative on internal strategy but not intended for public consumption.
- **SEC Form D [Source 5]:** Confirms $84M raise and seven investors; adds no material new information.

## What Would Change My Mind

- Evidence that the three new $1M+ contracts cited by the CEO [Source 2] have closed and are retained through Q2 2026.
- Confirmation that the restructuring achieves projected burn reduction without material additional churn.
- A valuation reset that better reflects the $36–37M adjusted ARR and concentration risk.

## Bottom Line

Nimbus has a credible product and strong engineering, but it is in a restructuring phase that its public messaging does not reflect. The $560M valuation prices in growth the company is actively de-prioritizing (international expansion) and ignores concentration risk that is already materializing (Sundry, Klatch). Wait for the restructuring to play out, then reassess.
