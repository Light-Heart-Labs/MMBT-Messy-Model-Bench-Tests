# ADR-002: Source Weighting — How to Treat Conflicting Information

**Status:** Accepted
**Date:** 2026-03-15

## Context

The five sources present conflicting information:
- The press release says ARR is $42M; TechCrunch says adjusted ARR is $36–37M.
- The press release says capital will "accelerate international expansion"; the leaked memo says international expansion is deferred to 2027.
- The press release does not mention layoffs; the former employee blog says 22 people were cut.

## Decision

Weight sources by reliability and specificity:

1. **TechCrunch article [Source 2]:** Highest weight for financial facts. Cites two named sources familiar with company finances. The ARR adjustment ($36–37M) is the most credible figure for current run-rate.

2. **Leaked memo [Source 4]:** High weight for strategic direction. Attributed to CEO Patel, obtained by The Information. The restructuring details are specific and internally consistent. Treated as authoritative on the company's internal plans, but with the caveat that internal plans can change.

3. **Former employee blog [Source 3]:** Medium weight. Single perspective, but internally consistent with other sources (burn rate aligns with ARR figures, layoff count is specific, customer concentration figure is plausible). Used for color and context, not as primary evidence.

4. **Press release [Source 1]:** Low weight for factual claims about current state; high weight for stated intentions (which are useful precisely because they contrast with the memo). The $42M ARR figure is treated as the company's reported number, not the adjusted reality.

5. **SEC Form D [Source 5]:** High weight for what it confirms (deal size, investor count, security type); low weight for what it omits (it is a minimal filing).

## Rationale

This weighting reflects the nature of each source:
- Journalistic reporting with multiple sources is more reliable than company-issued messaging.
- Internal documents are authoritative on internal plans but may be aspirational.
- Single-person accounts are valuable for context but require corroboration.
- Regulatory filings are authoritative on what they contain but are not comprehensive.

## Consequences

- The brief leads with the adjusted ARR ($36–37M) rather than the reported ARR ($42M).
- The brief treats the international expansion claim as contradicted by the memo, not as aspirational.
- The brief acknowledges the layoff information as coming from a single source but notes its internal consistency.
