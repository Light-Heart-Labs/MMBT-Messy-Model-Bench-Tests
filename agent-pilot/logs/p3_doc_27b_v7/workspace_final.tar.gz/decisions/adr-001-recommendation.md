# ADR-001: Recommendation Stance — PASS vs. CONDITIONAL

**Status:** Accepted
**Date:** 2026-03-15

## Context

The brief requires a clear stance: invest, pass, or more diligence needed. The sources present mixed signals — strong engineering and credible founders, but significant churn, customer concentration, and a restructuring that contradicts the public narrative.

## Decision

**PASS** — do not commit follow-on capital at this time.

## Rationale

1. **The valuation does not reflect known risks.** The $560M post-money valuation was already repriced down from $720M, but the repricing was a reaction to a single event (Sundry loss). It does not appear to account for the broader pattern: 38% customer concentration, $4M/month burn against $3.5M/month revenue, and the abandonment of international expansion.

2. **The company is in restructuring mode, not growth mode.** The leaked memo reveals a 30% Berlin headcount cut, a pause on EMEA hiring, and the sunset of the Nimbus Lite tier. These are contraction moves, not the expansion moves the press release describes. Investing now would mean buying into a company that is actively shrinking parts of its business.

3. **Information asymmetry is high.** The company did not publicly disclose the February 2025 layoffs, the Sundry/Klatch losses, or the restructuring plan. This suggests that the information available to a follow-on investor is not materially better than what is already public. There is no reason to believe the company will be more transparent with a new investor than it has been with the public.

4. **The wait option has low opportunity cost.** The restructuring timeline is known (Q2 2026 for Berlin cuts, Q4 2026 for breakeven target). Waiting six months provides visibility into whether the plan works without sacrificing deal access — the company has 36+ months of runway per the memo.

## Alternatives Considered

- **CONDITIONAL INVEST:** Would require a valuation reset and board seat with full financial transparency. Not feasible without existing board access.
- **MORE DILIGENCE:** Would require specific questions that the company has already shown reluctance to answer publicly. The cost of diligence is high relative to the information likely to be obtained.

## Consequences

- If the restructuring succeeds and Nimbus reaches breakeven by Q4 2026, the company will be in a stronger position for Series C. A follow-on at that point would be better informed and potentially at a more justified valuation.
- If the restructuring fails, passing now avoids capital loss.
