# Key Facts Incorporated into the Brief

Each fact below is attributed to its source. No numbers were invented.

## Funding & Valuation
- $84M Series B closed January 2026, led by Lightning Capital [Source 1, Source 5]
- Post-money valuation: $560M [Source 1]
- Previous Series A valuation: $230M (2023) [Source 1]
- Total funding across all rounds: $128M [Source 1]
- Seven total investors in the Series B [Source 5]
- Named investors: Lightning Capital (lead), Sequoia Capital, Accel, FedEx Ventures (strategic) [Source 1, Source 5]
- Three additional investors not named in Form D summary [Source 5]
- Round was originally targeted at $720M valuation but repriced down after Sundry non-renewal became known [Source 2]
- Repricing occurred after lead investor learned of Sundry news in early December 2025 [Source 2]
- $50M credit facility secured from Silicon Valley Bridge [Source 4]

## Revenue & Customers
- Reported ARR: $42M as of Q4 2025 [Source 1]
- ARR a year prior: $11M [Source 1]
- Adjusted run-rate ARR after December churn: $36–37M [Source 2]
- 1,400+ e-commerce brands on the platform [Source 1]
- Named customers: Maevia, Truant Coffee, Brick & Cobble [Source 1]
- Sundry Brands: largest customer, $4.2M ARR, non-renewal in November 2025 [Source 2]
- Klatch: fast-fashion brand, exited December 2025, migrated to competitor [Source 2]
- Both Sundry and Klatch were top-five customers [Source 2]
- Top five customers represented ~38% of ARR as of mid-2025 [Source 3]
- CEO claims three new $1M+ ARR contracts signed in Q1 2026 [Source 2]
- CEO claims net retention above 110% [Source 2]
- Nimbus Lite tier sunset affecting ~310 customers ($5K–$20K ARR each) [Source 4]

## Financials & Burn
- Monthly burn: ~$4M all-in (mid-2025) [Source 3]
- Monthly revenue: ~$3.5M (mid-2025) [Source 3]
- Implied net burn: ~$500K/month [Source 3]
- Memo claims 24+ months runway at current burn [Source 4]
- Memo claims 36+ months runway after restructuring [Source 4]
- Target: cash-flow breakeven by Q4 2026 [Source 4]

## Organization & Personnel
- 187 employees across Oakland, Austin, Berlin [Source 1]
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) [Source 1]
- 22 employees (~11% of org) cut in February 2025, mostly customer success and BD [Source 3]
- Layoffs were not publicly announced [Source 3]
- Berlin headcount: 41, being reduced to 28–30 by end Q2 2026 (30% reduction) [Source 4]
- EMEA hiring paused [Source 4]
- International expansion deferred to 2027 at earliest [Source 4]
- Berlin reframed as "support hub" [Source 4]
- Senior engineer compensation: $215K base + $50K equity vest annually [Source 3]

## Product & Platform
- Platform combines warehouse management, carrier orchestration, and demand forecasting [Source 1]
- Carrier-orchestration layer described as high-quality distributed systems code [Source 3]
- Nimbus Lite tier being sunset [Source 4]

## Use of Proceeds
- Declared: "expansion, working capital, general corporate purposes" [Source 5]
- Press release claims: accelerate international expansion and AI-driven inventory optimization [Source 1]
- Internal memo indicates international expansion is deferred, not accelerated [Source 4]
