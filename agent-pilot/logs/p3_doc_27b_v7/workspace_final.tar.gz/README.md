# Nimbus Logistics — Follow-On Investment Brief

## How to Read This Output

### Primary Deliverable
- **`brief.md`** — The 1-page executive brief (695 words). This is the main output. Read this first.

### Supporting Materials
- **`key-facts.md`** — Every material fact incorporated into the brief, with source attribution. Use this to verify that no numbers were invented and all claims trace to the source pack.
- **`research/notes.md`** — Working notes from reading the five sources. Includes source-by-source summaries, key tensions identified, and cross-checks of numbers across sources.
- **`research/dead-ends.md`** — Ideas considered and abandoned during analysis, with rationale for each.
- **`decisions/adr-001-recommendation.md`** — ADR explaining the PASS recommendation and alternatives considered.
- **`decisions/adr-002-source-weighting.md`** — ADR explaining how conflicting information across sources was weighted.

### Source Pack
The five sources are in `/input/repo/sources.md`:
1. **Source 1** — Company press release (2026-01-14)
2. **Source 2** — TechCrunch article (2026-01-15)
3. **Source 3** — Former employee blog post (2026-02-22)
4. **Source 4** — Leaked internal memo via The Information (2026-03-05)
5. **Source 5** — SEC Form D filing summary (2026-01-22)

### Methodology
- All facts in the brief trace to one of the five sources. No external research was conducted.
- Sources were weighted by reliability: TechCrunch (multiple sources) > leaked memo (attributed to CEO) > former employee blog (single perspective, internally consistent) > press release (company narrative) > SEC Form D (minimal but authoritative on what it contains).
- The brief is 695 words, within the 700-word limit.
