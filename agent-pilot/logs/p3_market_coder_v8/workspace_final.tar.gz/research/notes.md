# Research Notes: Password Manager Evaluation

## Initial Scope
- Target: 50-person engineering team at Series-B SaaS company
- Problem: Shadow-IT password storage (browser, sticky notes, Slack DMs)
- Goal: Replace with standardized solution within 90 days
- CTO mandate: Enterprise-grade security and compliance

## Initial Product List (10 candidates)
1. 1Password
2. Bitwarden
3. LastPass
4. Dashlane
5. Keeper Security
6. NordPass
7. Enpass
8. RoboForm
9. Zoho Vault
10. Keeper Password Manager

## Initial Filtering Criteria
- Must be commercially available for teams (not just personal)
- Must have enterprise features (SSO, audit logs, admin controls)
- Must support desktop (macOS/Windows) and mobile (iOS/Android)
- Must have browser extensions for Chrome/Firefox/Edge

## Shortlisted 5 Products
After filtering out consumer-only or infrastructure-focused tools:
1. **1Password** - Strong brand, enterprise features, good UX
2. **Bitwarden** - Open-source, transparent, growing enterprise adoption
3. **LastPass** - Market leader, widespread adoption
4. **Keeper Security** - Security-focused, strong encryption
5. **Dashlane** - User-friendly, good security posture

## Key Evaluation Criteria
1. SSO Integration (Google Workspace) - Critical for this team
2. SOC2 Compliance - Required for Series-B SaaS company
3. Audit Logs - For security monitoring and compliance
4. Per-Seat Pricing - Transparent pricing for 50 seats
5. Admin UX - Easy management for IT/Security team
6. Developer Tools Integration - VS Code, CLI, CI/CD compatibility
7. Mobile + Desktop Coverage - Team needs access everywhere
8. Breach Monitoring & Security Tools - Proactive security features

## Research Plan
- Visit official pricing pages for each product
- Check trust/security pages for SOC2/FedRAMP compliance
- Review feature matrices for team/enterprise tiers
- Look for independent security audits
- Check for any security incidents in past 3 years
