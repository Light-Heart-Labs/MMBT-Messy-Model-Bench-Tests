# Password Manager Evaluation for 50-Person SaaS Engineering Team

## Overview

This repository contains the research and recommendations for selecting a password manager to replace shadow-IT storage practices (browser storage, sticky notes, Slack DMs) across a 50-person engineering team at a Series-B SaaS company.

## Files

- `recommendation.md` - The primary 1-2 page recommendation memo with decision criteria, final choice, pricing, and risks.
- `comparison.md` - Side-by-side comparison of the 5 evaluated password managers across features, pricing, and security.
- `sources.md` - Complete list of all URLs consulted, with timestamps and descriptions of findings.
- `research/notes.md` - Working notes documenting the research process and initial findings.
- `decisions/` - ADR-style records for major decisions (e.g., which 5 products were selected, evaluation criteria).

## How to Use

1. Read `recommendation.md` for the executive summary and final recommendation.
2. Review `comparison.md` to understand how the selected product compares to alternatives.
3. Check `sources.md` to verify all claims and see the raw data sources.
4. Review `research/notes.md` and `decisions/` for deeper context on the evaluation process.

## Methodology

- Evaluated 5 distinct password managers (not adjacent products like SSO or secrets management).
- Criteria included: SSO integration (Google Workspace), SOC2 audit logs, per-seat pricing, admin UX, mobile + desktop coverage, developer tool integrations.
- Every factual claim is cited with a source URL.
- Pricing verified from official sources; if not publicly listed, noted as "contact sales".
