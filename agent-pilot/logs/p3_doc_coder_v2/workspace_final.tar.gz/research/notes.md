# Working Notes — Nimbus Logistics, Inc. Source Review

## Key Facts Extracted

### Valuation & Funding
- Series B closed $84M at $560M post-money (press release) [Source 1]
- TechCrunch reports Series B was originally intended to close at $720M in late 2025, repriced down after Sundry non-renewal [Source 2]
- Total funding to date: $128M [Source 1]
- SEC Form D confirms $84M raised, 7 investors, closed 2026-01-14 [Source 5]
- Internal memo mentions $50M credit facility from Silicon Valley Bridge [Source 4]

### Revenue & Growth
- Company reports $42M ARR as of Q4 2025, up from $11M a year prior [Source 1]
- TechCrunch: adjusted for December churn (Sundry + Klatch), run-rate is $36-37M [Source 2]
- TechCrunch: CEO claims 3 new $1M+ ARR contracts signed in Q1 [Source 2]
- TechCrunch: CEO claims net retention >110% [Source 2]
- Internal memo: lowest tier ("Nimbus Lite") has ~310 customers, $5K-$20K ARR each [Source 4]
- TechCrunch: Sundry contract was $4.2M ARR [Source 2]

### Customer Concentration & Churn
- TechCrunch: top 5 customers = ~38% of ARR [Source 3]
- TechCrunch: lost Sundry ($4.2M ARR) in November, Klatch (fast-fashion) in December [Source 2]
- TechCrunch: company confirmed Sundry non-renewal but called it "strategic mutual decision" [Source 2]
- Internal memo: sunsetting Nimbus Lite tier (~310 customers) with 90-day notice [Source 4]

### Operations & Burn
- Internal memo: ~$4M/month all-in burn, ~$3.5M/month revenue (mid-2025) [Source 3]
- Internal memo: 30% reduction in international headcount, Berlin from 41 to ~28-30 by end of Q2 [Source 4]
- Internal memo: pause new hires in EMEA, Berlin repositioned as "support hub" [Source 4]
- Press release: 187 employees across Oakland, Austin, Berlin [Source 1]
- Former employee blog: 22 people (11% of org) laid off in February 2025, mostly customer success and BD [Source 3]

### Talent & Culture
- Former employee: senior engineer comp $215K base + $50K equity [Source 3]
- Former employee: engineering architecture "genuinely good", CTO Daniel Wong "real deal" [Source 3]
- Former employee: high burn, path to survival requires faster growth or significant cuts [Source 3]
- Former employee: would recommend to senior engineers, not to those needing job security [Source 3]

### Strategic Direction
- Press release: expansion into international markets and AI-driven inventory optimization [Source 1]
- Internal memo: international expansion deferred to 2027, renewed focus on U.S. mid-market [Source 4]
- Internal memo: path to cash-flow breakeven by Q4 2026, trigger for Series C from strength [Source 4]

## Tensions & Contradictions

1. **Valuation**: $560M (press release) vs. $720M intended (TechCrunch) — suggests pressure on valuation
2. **ARR**: $42M (press release) vs. $36-37M adjusted (TechCrunch) — overstatement of run-rate
3. **Growth Narrative**: International expansion (press release) vs. international deferral (internal memo)
4. **Customer Health**: Net retention >110% (CEO claim) vs. top-5 concentration and churn (TechCrunch/Source 3)
5. **Runway**: 24+ months at current burn (memo) vs. need for "default-alive" (blog post)
6. **Layoffs**: Not mentioned in press release, but confirmed in blog post and implied by memo restructuring

## Source Quality Assessment

- **Source 1 (Press Release)**: Company narrative, optimistic, omits negatives
- **Source 2 (TechCrunch)**: Journalistic, cites multiple sources, provides counterpoints to press release
- **Source 3 (Blog Post)**: First-hand ex-employee view, balanced (good/bad), but subjective
- **Source 4 (Leaked Memo)**: Internal strategy, candid about challenges, most reliable on financials
- **Source 5 (SEC Form D)**: Factual, administrative, confirms funding details

## Initial Stance

The data suggests Nimbus is in a precarious position: strong engineering/product, real customer love, but high burn, customer concentration, and recent churn. The internal memo shows they're taking corrective action, but the repriced round and deferred international expansion indicate the original growth plan was over-optimistic.

Recommendation: **Pass on follow-on at current valuation**, but monitor for:
- Successful execution of cost cuts (Q2 headcount reduction)
- Net retention sustainability (beyond CEO claims)
- New customer acquisition pace (Q1 3x $1M+ contracts — need to see Q2 follow-through)
