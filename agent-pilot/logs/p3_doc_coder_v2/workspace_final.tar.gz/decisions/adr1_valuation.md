# ADR: Valuation Framework

## Decision

Use **$475M as the implied "realistic" valuation** for the purpose of evaluating the follow-on investment, rather than the $560M post-money from the press release.

## Rationale

- Press release claims $560M post-money [Source 1]
- TechCrunch reports the round was originally intended to close at $720M but was repriced down after Sundry non-renewal in early December [Source 2]
- Adjusted ARR is $36-37M (not $42M), implying a P/S (price-to-ARR) multiple of ~12.8x ($475M/$37M) vs. the reported 13.3x ($560M/$42M)
- A 12.8x ARR multiple is more in line with late-stage logistics-tech peers, especially given customer churn and concentration issues

## Implications

- At $475M, a follow-on round would need to be at a discount to this to create value for existing shareholders
- The $50M credit facility [Source 4] provides runway but does not increase equity value
- The internal memo's path to $36M+ months of runway [Source 4] is based on current burn, not growth — the valuation should reflect the risk that growth doesn't materialize

## Alternative Considered

Use $560M as stated. Rejected because it ignores the repricing signal from TechCrunch and overstates the run-rate ARR.

## Decision Maker

AI Analyst
Date: 2026-04-11
