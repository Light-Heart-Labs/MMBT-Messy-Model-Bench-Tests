# ADR: Recommendation Framework

## Decision

Recommend **PASS on follow-on investment at current valuation**, with a clear set of **milestone-based re-entry triggers**.

## Rationale

The company is executing corrective actions (cost cuts, focus on U.S. mid-market) but the original growth narrative has been undermined:
- ARR is $36-37M run-rate (not $42M) [Source 2]
- Top-5 customers = 38% of ARR, with 2 major exits in Q4 [Source 2, 3]
- International expansion deferred to 2027 [Source 4]
- Layoffs occurred in February 2025 [Source 3]
- High burn ($4M/month) vs. revenue ($3.5M/month) [Source 3]

The internal memo shows a credible path to cash-flow breakeven by Q4 2026 [Source 4], but that is a *cost-cutting* path, not a *growth* path. The company is trading growth for survival, which is rational but not attractive at a $560M valuation.

## Re-entry Triggers

A follow-on investment would be justified if:
1. **Net retention drops below 100% for two consecutive quarters** — would indicate systemic churn, not one-off customer losses
2. **Q2/Q3 ARR growth stalls below $2M quarterly** — would suggest the three new $1M+ contracts [Source 2] are not leading to sustainable growth
3. **Berlin office reduction exceeds 30%** — would indicate deeper cuts than planned, signaling worse-than-expected unit economics
4. **Nimbus Lite migration fails** — if >50% of the 310 Lite customers churn rather than migrate [Source 4], it would indicate product-market fit issues at the lower end

## Alternative Considered

Recommend "more diligence needed" without a clear stance. Rejected because the task requires a calibrated stance, and the data is sufficient to form a judgment: the company is in a recovery phase, not a growth phase, and the current valuation reflects the latter.

## Decision Maker

AI Analyst
Date: 2026-04-11
