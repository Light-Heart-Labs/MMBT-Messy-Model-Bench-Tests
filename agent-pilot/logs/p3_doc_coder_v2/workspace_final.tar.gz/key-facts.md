# Key Facts — Nimbus Logistics, Inc.

## Valuation & Funding
- Series B closed $84M at $560M post-money [Source 1]
- TechCrunch reports round was originally intended to close at $720M in late 2025, repriced down after Sundry non-renewal [Source 2]
- Total funding to date: $128M [Source 1]
- SEC Form D confirms $84M raised, 7 investors, closed 2026-01-14 [Source 5]
- Internal memo mentions $50M credit facility from Silicon Valley Bridge [Source 4]

## Revenue & Growth
- Company reports $42M ARR as of Q4 2025, up from $11M a year prior [Source 1]
- TechCrunch: adjusted for December churn (Sundry + Klatch), run-rate is $36-37M [Source 2]
- TechCrunch: CEO claims 3 new $1M+ ARR contracts signed in Q1 [Source 2]
- TechCrunch: CEO claims net retention >110% [Source 2]
- Internal memo: lowest tier ("Nimbus Lite") has ~310 customers, $5K-$20K ARR each [Source 4]

## Customer Concentration & Churn
- TechCrunch: top 5 customers = ~38% of ARR [Source 3]
- TechCrunch: lost Sundry ($4.2M ARR) in November, Klatch (fast-fashion) in December [Source 2]
- TechCrunch: company confirmed Sundry non-renewal but called it "strategic mutual decision" [Source 2]
- Internal memo: sunsetting Nimbus Lite tier (~310 customers) with 90-day notice [Source 4]

## Operations & Burn
- Internal memo: ~$4M/month all-in burn, ~$3.5M/month revenue (mid-2025) [Source 3]
- Internal memo: 30% reduction in international headcount, Berlin from 41 to ~28-30 by end of Q2 [Source 4]
- Internal memo: pause new hires in EMEA, Berlin repositioned as "support hub" [Source 4]
- Press release: 187 employees across Oakland, Austin, Berlin [Source 1]
- Former employee blog: 22 people (11% of org) laid off in February 2025, mostly customer success and BD [Source 3]

## Strategic Direction
- Press release: expansion into international markets and AI-driven inventory optimization [Source 1]
- Internal memo: international expansion deferred to 2027, renewed focus on U.S. mid-market [Source 4]
- Internal memo: path to cash-flow breakeven by Q4 2026, trigger for Series C from strength [Source 4]

## Talent & Culture
- Former employee: senior engineer comp $215K base + $50K equity [Source 3]
- Former employee: engineering architecture "genuinely good", CTO Daniel Wong "real deal" [Source 3]
- Former employee: high burn, path to survival requires faster growth or significant cuts [Source 3]
- Former employee: would recommend to senior engineers, not to those needing job security [Source 3]
