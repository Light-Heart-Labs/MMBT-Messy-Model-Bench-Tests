# Executive Brief: Nimbus Logistics, Inc. — Follow-on Investment Recommendation

**Date:** 2026-04-11  
**Prepared for:** Investment Committee  
**Recommendation:** **PASS on follow-on at current valuation ($560M)** — but monitor for re-entry triggers.

---

## Executive Summary

Nimbus Logistics closed a $84M Series B at a $560M post-money valuation in January 2026 [Source 1]. However, the company's financial health is more fragile than the press release suggests: adjusted ARR is $36-37M (not $42M) after two major customer losses in Q4, and the round was repriced from a $720M target [Source 2]. The internal "Path to Profitability" memo reveals a shift from growth to survival: international expansion deferred to 2027, 30% Berlin headcount cuts, and sunsetting of the lowest tier (310 customers) [Source 4]. While engineering quality and product-market fit for mid-market brands are strong [Source 3], high burn ($4M/month vs. $3.5M revenue) and customer concentration (top 5 = 38% of ARR) pose material risks [Source 3].

**Recommendation:** **Pass** on a follow-on investment at the current $560M valuation. The company is executing a cost-cutting plan to reach cash-flow breakeven by Q4 2026 [Source 4], not a growth plan. A follow-on at this valuation would dilute existing shareholders without meaningful upside unless growth accelerates. Re-entry triggers include sustained net retention >105%, quarterly ARR growth >$2M, and successful execution of cost cuts without further layoffs.

---

## Financial Health: ARR Overstated, Burn Unsustainable

The company reports $42M ARR as of Q4 2025, up from $11M a year prior [Source 1]. However, TechCrunch reports that this includes two major customers that churned in Q4: Sundry ($4.2M ARR, non-renewed November) and Klatch (December) [Source 2]. Adjusted for this churn, the run-rate ARR is $36-37M [Source 2].

The internal memo confirms a cash-flow problem: ~$4M/month all-in burn against ~$3.5M/month revenue (mid-2025) [Source 3]. This is not sustainable at scale — the company is burning ~$6M/month net, which would deplete the $84M Series B in under 14 months without further cuts or growth.

The $50M credit facility [Source 4] extends runway but does not improve unit economics. It is described internally as "insurance, not operating capital" [Source 4], meaning it is a buffer, not a growth engine.

---

## Strategic Shift: From Global Growth to U.S. Focus

The press release emphasizes international expansion and AI-driven optimization [Source 1]. The internal memo tells a different story: international expansion is deferred to 2027 at earliest, and the Berlin office (41 people) will be cut to 28-30 by end of Q2 [Source 4]. Berlin will be repositioned as a "support hub" rather than a sales/expansion office [Source 4].

This shift reflects reality: the company lost two major customers in Q4, and the top 5 customers represent 38% of ARR [Source 3]. Customer concentration is a material risk, and the company is responding by retreating to its core U.S. mid-market segment.

The memo also reveals the sunsetting of "Nimbus Lite," the lowest tier with ~310 customers ($5K-$20K ARR each) [Source 4]. This is a strategic winnowing — the company is abandoning low-margin, high-support customers to focus on the profitable mid-market.

---

## Operational Risks: Layoffs, Burn, and Net Retention

The company laid off 22 people (11% of the org) in February 2025, mostly in customer success and BD — not publicly announced [Source 3]. This suggests internal recognition of operational inefficiencies before the Series B.

CEO Mira Patel claims net retention >110% [Source 2], but this is inconsistent with the loss of two top-5 customers and the planned sunsetting of 310 customers. Net retention above 110% would imply strong organic growth, but the company is cutting headcount and tiers — signs of distress, not strength.

The former employee blog post confirms high burn and a path to "default-alive" rather than "default-thriving" [Source 3]. The company is in survival mode, not growth mode.

---

## Strengths: Engineering, Product, Founders

The company has real strengths: the engineering architecture is "genuinely good" [Source 3], CTO Daniel Wong is "the real deal" [Source 3], and customer love is "real" — mid-market brands truly depend on the platform [Source 3]. Founders Mira Patel and Daniel Wong are credible [Source 3].

Compensation is competitive for senior engineers ($215K base + $50K equity) [Source 3], and the company would be a good fit for engineers who can tolerate risk.

---

## Recommendation: Pass, with Re-entry Triggers

**Recommendation:** **Pass** on a follow-on investment at the current $560M valuation.

The company is executing a cost-cutting plan to reach cash-flow breakeven by Q4 2026 [Source 4], not a growth plan. A follow-on at this valuation would dilute existing shareholders without meaningful upside unless growth accelerates. The repriced round (from $720M to $560M) [Source 2] and the internal memo's focus on survival [Source 4] indicate the original growth narrative was over-optimistic.

**Re-entry triggers:**
1. **Net retention >105% for two consecutive quarters** — would indicate systemic churn is under control, not one-off losses.
2. **Quarterly ARR growth >$2M** — would suggest the three new $1M+ contracts [Source 2] are leading to sustainable growth.
3. **Berlin office reduction ≤30%** — would indicate the cuts are on plan, not a sign of deeper issues.
4. **<50% churn of Nimbus Lite customers** — would indicate product-market fit at the lower end, not a systemic failure.

If these triggers are met, a follow-on at a $450-475M valuation (reflecting the $36-37M run-rate ARR) would be justified.

---

## Appendix: Source Quality Assessment

- **Press release [Source 1]**: Optimistic, omits negatives. Use for factual anchors (funding, ARR, employee count) but not for growth narrative.
- **TechCrunch [Source 2]**: Journalistic, cites multiple sources. Most reliable for counterpoints to press release (repricing, churn, adjusted ARR).
- **Blog post [Source 3]**: First-hand ex-employee view. Balanced (good/bad), but subjective. Use for operational details (burn, layoffs, culture).
- **Leaked memo [Source 4]**: Internal strategy. Most reliable on financials and operational plans (burn, cuts, credit facility).
- **SEC Form D [Source 5]**: Factual, administrative. Confirms funding details.
