# Nimbus Logistics, Inc. — Deal Evaluation Package

## Overview

This package contains an executive brief and supporting analysis for evaluating a follow-on investment in Nimbus Logistics, Inc., a Series-B logistics-tech startup.

## Files

- **`brief.md`** — The 1-page executive brief. Read this first. It contains the recommendation (PASS), rationale, and re-entry triggers.
- **`key-facts.md`** — A list of every material fact incorporated into the brief, with source attribution.
- **`research/notes.md`** — Working notes from reading the five sources, including tensions, contradictions, and source quality assessment.
- **`decisions/adr1_valuation.md`** — ADR for valuation framework (why $475M is used as the realistic valuation).
- **`decisions/adr2_recommendation.md`** — ADR for recommendation framework (why PASS, with re-entry triggers).
- **`README.md`** — This file.

## How to Read This Output

1. Start with `brief.md` — the deliverable. It is at most 700 words, leads with a clear stance, and cites sources inline.
2. If you want to verify the reasoning, read `research/notes.md` — it shows how the sources were synthesized.
3. If you want to see the raw facts, read `key-facts.md`.
4. If you want to see the non-obvious framing choices, read the ADRs in `decisions/`.

## Rules of the Road (as Applied)

- **No internet research** — All analysis is based on the five provided sources.
- **No invented numbers** — Every metric traces to a source (e.g., $36-37M run-rate ARR [Source 2], $4M/month burn [Source 3]).
- **One clear recommendation** — The brief states PASS, with caveats that would change it (re-entry triggers).
- **Cite sources inline** — Every factual claim is attributed (e.g., "[Source 2]").
- **Highlight tensions** — The brief contrasts the press release ($42M ARR, international expansion) with the leaked memo ($36-37M run-rate, international deferral).

## Recommendation Summary

**PASS on follow-on at current valuation ($560M)** — but monitor for re-entry triggers:
- Net retention >105% for two consecutive quarters
- Quarterly ARR growth >$2M
- Berlin office reduction ≤30%
- <50% churn of Nimbus Lite customers

If these triggers are met, a follow-on at $450-475M would be justified.
