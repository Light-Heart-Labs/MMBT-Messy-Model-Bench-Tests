# Password Manager Evaluation for 50-Person SaaS Engineering Team

This repository contains the research and recommendations for selecting a password manager to standardize across a 50-person engineering team at a Series-B SaaS company.

## Output Files

- **`recommendation.md`** - The primary 1-2 page recommendation memo with decision criteria, final choice, pricing, runner-up, and risks.
- **`comparison.md`** - Side-by-side feature, pricing, and security comparison of the 5 evaluated products.
- **`sources.md`** - Every URL fetched during research, with timestamp and description of content.
- **`research/notes.md`** - Working notes from the research process.
- **`decisions/`** - ADR-style records for key decisions (which products, criteria, etc.).

## How to Use

1. Read `recommendation.md` for the executive summary and final recommendation.
2. Review `comparison.md` to see how the 5 evaluated products stack up.
3. Check `sources.md` to verify all claims and see the raw research.
4. Review `decisions/` for the rationale behind key decisions.

## Research Methodology

- Evaluated 5 distinct password managers (not adjacent products like SSO or secrets management).
- Criteria focused on team needs: SSO integration, SOC2 compliance, pricing, admin UX, mobile/desktop coverage, and developer tool integration.
- All factual claims are cited with public sources.
- Pricing verified where possible; "contact sales" items are explicitly flagged.
