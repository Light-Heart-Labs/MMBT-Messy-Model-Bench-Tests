# Research Notes - Password Manager Evaluation

## Initial Assessment
- Target: 50-person engineering team at Series-B SaaS company
- Current state: Shadow IT (browser storage, sticky notes, Slack DMs)
- CTO goal: Standardize on a password manager within 90 days
- Key requirements: SSO integration (likely Google Workspace), SOC2 compliance, reasonable pricing, good admin controls

## Initial Product List (10 candidates)
1. LastPass (CyberArk) - https://www.lastpass.com/
2. 1Password - https://1password.com/
3. Bitwarden - https://bitwarden.com/
4. Keeper Security - https://keepersecurity.com/
5. Dashlane - https://dashlane.com/
6. NordPass - https://nordpass.com/
7. RoboForm - https://www.roboform.com/
8. Enpass - https://www.enpass.io/
9. Keeper Secrets Manager - https://keepersecurity.com/products/keeper-secrets-manager/ (secrets management, not consumer password manager)
10. AWS Secrets Manager / HashiCorp Vault (infrastructure, not user password manager)

## Decision: Which 5 to Evaluate?
Criteria for elimination:
- Must be a consumer/business password manager (not secrets management infrastructure)
- Must have clear team/enterprise pricing
- Must have web, desktop, and mobile apps
- Must support SSO integration

Eliminated from initial list:
- NordPass: Limited information on enterprise features and SOC2 compliance
- RoboForm: Pricing not clearly listed for team plans
- Enpass: Self-hosted focus, less cloud-native team features
- Keeper Secrets Manager: This is a secrets management tool for developers, not a general password manager for all employees
- AWS Secrets Manager / HashiCorp Vault: Infrastructure tools, not user password managers

Final 5 to evaluate:
1. LastPass (CyberArk)
2. 1Password
3. Bitwarden
4. Keeper Security
5. Dashlane

## Research Plan
For each product, need to verify:
1. Pricing per seat (especially for 50-seat teams)
2. SSO integration capabilities (Google Workspace)
3. SOC2 compliance status
4. Admin dashboard features
5. Mobile and desktop app support
6. Developer tool integrations (VS Code, JetBrains, etc.)
7. Security incident history (if any)
8. Free trial availability

## First Round of Research
Starting with public pricing pages and feature comparisons.
