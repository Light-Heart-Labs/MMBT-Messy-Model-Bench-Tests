# Research Notes — Password Manager Evaluation

**Date:** 2025-06-18
**Researcher:** Engineering Infrastructure Team

---

## Products Evaluated

1. **1Password** (Teams/Business)
2. **Bitwarden** (Teams/Enterprise)
3. **LastPass** (Business/Business Max)
4. **Dashlane** (Business/Business Plus)
5. **Keeper** (Business)

---

## Pricing Research

### 1Password
- Source: https://1password.com/pricing/
- Business: $7.99/user/month (annual billing), $9.99/user/month (monthly)
- Teams: $19.95/month for up to 10 users (annual), $24.95/month (monthly)
- Extracted from JS-rendered HTML via grep on priceAnnual fields

### Bitwarden
- Source: https://bitwarden.com/pricing/
- Business Teams: $4.00/user/month (annual billing)
- Business Enterprise: $6.00/user/month (annual billing)
- Premium (individual): $1.65/user/month (annual billing)
- Extracted from JS-rendered HTML via grep on price fields

### LastPass
- Source: https://www.pcmag.com/reviews/lastpass (LastPass own site is JS-rendered)
- Teams: $51/year ($4.25/month)
- Business: $84/year ($7.00/month)
- Business Max: $108/year ($9.00/month)
- Premium (individual): $36/year ($3.00/month)
- **Note:** LastPass pricing not available on their own site (fully JS-rendered). Sourced from PCMag review.

### Dashlane
- Source: https://www.dashlane.com/pricing/
- Business: $11.00/user/month (annual billing)
- Business Plus: Custom pricing (contact sales)
- Extracted from JS-rendered HTML via grep on customPrice fields

### Keeper
- Source: https://www.zdnet.com/article/best-password-manager/ (Keeper own site is JS-rendered)
- Business: $7.00/user/month (minimum 5 seats)
- Personal: $1.67/user/month
- Family: $3.54/user/month (5 seats)
- **Note:** Keeper pricing not available on their own site (fully JS-rendered). Sourced from ZDNet review.

---

## Compliance Research

### 1Password
- SOC 2 Type 2: ✅ (https://1password.com/security/)
- SOC 2 report available: ✅ (https://1password.com/resources/soc2)
- Regular third-party security audits: ✅
- Bug bounty program: ✅

### Bitwarden
- SOC 2 Type 2: ✅ (https://bitwarden.com/compliance/)
- SOC 3: ✅
- ISO 27001: ✅
- HIPAA: ✅
- GDPR: ✅
- CCPA: ✅
- DPF (Data Privacy Framework): ✅
- Annual penetration testing: ✅
- Bug bounty program: ✅

### LastPass
- ISO 27001: ✅ (https://www.lastpass.com/security)
- SOC 2 Type II: ✅
- SOC 3: ✅
- BSI C5: ✅
- TRUSTe: ✅
- Regular expert security audits: ✅

### Dashlane
- SOC 2: ✅ (claimed on https://www.dashlane.com/security)
- Zero-knowledge architecture: ✅
- Annual penetration testing: ✅
- Bug bounty program: ✅
- AWS Nitro Enclaves: ✅
- **Note:** Dashlane trust center (https://trust.dashlane.com/) is Vanta-hosted with minimal static content. Specific certifications not clearly listed.

### Keeper
- FIPS 140-2: ✅ (https://www.zdnet.com/article/best-password-manager/)
- Okta, Azure AD, Ping Identity, Google Workspace integrations: ✅
- **Note:** Keeper's own site is JS-rendered. Compliance details sourced from ZDNet review.

---

## Security Incident History

### LastPass
- 2015: Security breach
- 2017: Security vulnerabilities in Android App
- 2021: Third-party trackers and security incident
- 2022: Customer data and partially-encrypted vault theft
- 2024: Leakage via Injection Attacks
- Source: https://en.wikipedia.org/wiki/LastPass

### 1Password, Bitwarden, Dashlane, Keeper
- No major public security incidents found.

---

## Developer Tooling

### 1Password
- CLI: `op` (official, https://github.com/1Password/onepassword-cli)
- Terraform Provider: ✅ (https://github.com/1Password/terraform-provider-onepassword)
- Ansible Collection: ✅ (https://github.com/1Password/ansible-onepasswordconnect-collection)
- Connect API: ✅ (for CI/CD integration)
- Python SDK: ✅ (https://github.com/1Password/connect-sdk-python)

### Bitwarden
- CLI: `bw` (official, https://github.com/bitwarden/cli)
- Open source: ✅ (https://github.com/bitwarden)
- Self-hosted: ✅ (Bitwarden Vault Server)
- No Terraform provider, Ansible collection, or CI/CD API

### LastPass
- CLI: `lpass` (community-maintained, https://github.com/lastpass/lastpass-cli)
- No official Terraform provider, Ansible collection, or CI/CD API

### Dashlane
- CLI: Official (https://github.com/dashlane/dashlane-cli)
- No Terraform provider, Ansible collection, or CI/CD API

### Keeper
- CLI: Commander (https://docs.keeper.io/user-guides/keeper-commander)
- No official Terraform provider, Ansible collection, or CI/CD API
- GitHub org has limited public repos (https://github.com/KeeperSecurity)

---

## SSO Integration

All 5 products support SAML 2.0 SSO. Confirmed integrations:
- **1Password:** Google Workspace, Okta, Azure AD, OneLogin, Ping
- **Bitwarden:** SAML 2.0 (generic, supports any SAML IdP)
- **LastPass:** SAML 2.0 (generic)
- **Dashlane:** SAML 2.0 (generic)
- **Keeper:** Okta, Azure AD, Ping Identity, Google Workspace

---

## Key Findings

1. **1Password has the strongest developer story** — CLI, Terraform, Ansible, Connect API. This is a significant differentiator for an engineering team.
2. **Bitwarden is the most cost-effective** — $4/user/month vs. $7.99 for 1Password. But audit logs require the Enterprise tier ($6/user/month).
3. **LastPass has a concerning security history** — 5 documented incidents over 10 years, including a 2022 vault theft and 2024 injection attacks.
4. **Dashlane is the most expensive** — $11/user/month, nearly 40% more than 1Password.
5. **Keeper is enterprise-focused** — Strong compliance (FIPS 140-2) but less developer-friendly tooling.
6. **All 5 support zero-knowledge architecture** — None can access decrypted vault data.
7. **All 5 support SSO** — All integrate with Google Workspace via SAML 2.0.
8. **Only Bitwarden is open source** — This is a significant differentiator for teams that value code auditability.

---

## Final Recommendation

**1Password Business** at $7.99/user/month ($4,794/year for 50 seats) is the recommended choice.

**Runner-up:** Bitwarden Business Teams at $4.00/user/month ($2,400/year for 50 seats), or Bitwarden Business Enterprise at $6.00/user/month ($3,600/year) if audit logs are required.
