# Password Manager Recommendation: 1Password Business

**To:** CTO & Engineering Leadership
**From:** Engineering Infrastructure Team
**Date:** 2025-06-18
**Subject:** Standardized Password Manager — Recommendation & 90-Day Rollout Plan

---

## Executive Summary

We recommend **1Password Business** as the standardized password manager for our 50-person engineering team. At **$7.99 per user per month** (billed annually), the total annual cost is **$4,794** for 50 seats. The runner-up is Bitwarden Business Teams at $4.00/user/month ($2,400/year), which would be preferable only if budget is the overriding constraint.

This recommendation addresses the CTO's mandate to eliminate shadow-IT password storage (browser saves, sticky notes, Slack DMs) within 90 days.

---

## Decision Criteria

We defined the following criteria for "best for this team," weighted by importance:

### Must-Have (40% weight)
| Criterion | Rationale |
|---|---|
| **SSO Integration** | Must integrate with Google Workspace (our IdP) via SAML 2.0 |
| **Audit Logging** | Required for SOC 2 compliance evidence — admin-visible logs of vault access, sharing, policy changes |
| **Multi-Platform Coverage** | macOS, Windows, Linux, iOS, Android, browser extensions — our team uses all of these |
| **Zero-Knowledge Architecture** | Vendor must not be able to access decrypted vault data |

### Important (35% weight)
| Criterion | Rationale |
|---|---|
| **Developer Tooling** | CLI tool, CI/CD integration, or API access — critical for our engineering workflows |
| **Pricing Transparency** | Publicly listed per-seat pricing — no "contact sales" black box |
| **Admin Console** | Self-service admin console for user management, shared folders, security policies |

### Nice-to-Have (25% weight)
| Criterion | Rationale |
|---|---|
| **Clean Security History** | No major unresolved data breaches |
| **Open Source** | Source code auditable by our security team |
| **Compliance Certifications** | SOC 2 Type 2, ISO 27001, FedRAMP |
| **Onboarding/Migration** | Tools to import from browser saves, other password managers |

---

## Recommendation: 1Password Business

### Product & Tier
- **Product:** 1Password
- **Tier:** Business
- **Per-seat price:** $7.99/user/month, billed annually [1]
- **50-seat annual cost:** $7.99 × 50 × 12 = **$4,794/year**

### Why 1Password Wins

1. **Best-in-class developer tooling.** 1Password offers a native CLI (`op` command) [2], a Terraform provider [3], an Ansible collection [4], and the 1Password Connect API for CI/CD integration [5]. This is the strongest developer story of any password manager evaluated — critical for our engineering team.

2. **Strong SSO integration.** 1Password Business supports SAML 2.0 with Google Workspace, Okta, Azure AD, OneLogin, and other IdPs [6]. Our team uses Google Workspace as the primary IdP, and 1Password integrates natively.

3. **SOC 2 Type 2 certified.** 1Password is SOC 2 Type 2 certified [7], providing the audit evidence we need for SOC 2 compliance. The SOC 2 report is publicly available [8].

4. **Clean security history.** Unlike some competitors, 1Password has no history of major data breaches or security incidents.

5. **Excellent admin console.** The 1Password admin console provides self-service user management, shared folders, security policies, audit logs, and device insights [9].

6. **Transparent pricing.** 1Password publishes pricing publicly — no "contact sales" required for the Business tier [1].

### Key Features for Our Team

| Feature | 1Password Business |
|---|---|
| SSO (SAML 2.0) | ✅ Google Workspace, Okta, Azure AD, OneLogin, Ping |
| Audit Logs | ✅ Full admin audit trail |
| CLI Tool | ✅ `op` CLI for macOS, Windows, Linux |
| CI/CD Integration | ✅ 1Password Connect API, Terraform provider, Ansible collection |
| Browser Extensions | ✅ Chrome, Firefox, Safari, Edge |
| Mobile Apps | ✅ iOS, Android |
| Desktop Apps | ✅ macOS, Windows, Linux |
| Shared Folders | ✅ Team-wide and department-level sharing |
| Security Policies | ✅ Enforce password strength, MFA, device limits |
| Watchtower | ✅ Monitors for breached passwords |
| Passkeys | ✅ Support for passkey authentication |

---

## Runner-Up: Bitwarden Business Teams

### Product & Tier
- **Product:** Bitwarden
- **Tier:** Business Teams
- **Per-seat price:** $4.00/user/month, billed annually [10]
- **50-seat annual cost:** $4.00 × 50 × 12 = **$2,400/year**

### When Bitwarden Would Beat 1Password

Bitwarden would be the better choice if:
1. **Budget is the primary constraint.** Bitwarden is ~50% cheaper ($2,400 vs. $4,794/year).
2. **Open-source auditability is a hard requirement.** Bitwarden is fully open source [11], allowing our security team to audit the codebase.
3. **Self-hosting is desired.** Bitwarden offers a self-hosted option (Bitwarden Vault Server) for teams that want full control over infrastructure.

### Bitwarden Strengths
- SOC 2 Type 2 and SOC 3 certified [12]
- ISO 27001 certified [12]
- Open source (GitHub) [11]
- CLI tool (`bw` command) [13]
- SSO support (SAML 2.0) [14]
- Audit logs available on Business Enterprise tier ($6/user/month) [10]

### Bitwarden Weaknesses vs. 1Password
- Audit logs are only available on the **Business Enterprise** tier ($6/user/month), not the Business Teams tier ($4/user/month) [10]. This means we'd need to pay $3,600/year for audit logs.
- Admin console is functional but less polished than 1Password's.
- No Terraform provider or Ansible collection (though the CLI is capable).
- No native CI/CD API equivalent to 1Password Connect.

---

## Concerns & Risks with 1Password

### 1. Proprietary Software (Not Open Source)
1Password is closed-source. Our security team cannot audit the codebase. **Mitigation:** 1Password publishes its SOC 2 Type 2 report [8] and undergoes regular third-party security audits [7]. The zero-knowledge architecture means even 1Password cannot access our decrypted data.

### 2. Vendor Lock-In
Migrating away from 1Password would require exporting all vault data and re-importing into a new tool. **Mitigation:** 1Password supports export to standard formats (CSV, 1Password format). The cost of switching is moderate, not prohibitive.

### 3. Higher Cost
At $4,794/year, 1Password is more expensive than Bitwarden ($2,400–$3,600/year). **Mitigation:** The developer tooling (CLI, Terraform, Ansible, Connect API) provides value that offsets the cost difference for an engineering team.

### 4. No FedRAMP Authorization
1Password does not appear to have FedRAMP authorization. **Mitigation:** This is not a requirement for our team (we are a commercial SaaS company, not a government contractor). SOC 2 Type 2 certification is sufficient for our compliance needs.

---

## 90-Day Rollout Plan

| Phase | Timeline | Activities |
|---|---|---|
| **Phase 1: Setup** | Week 1-2 | Create 1Password Business account, configure SSO with Google Workspace, set up admin policies, create shared folders |
| **Phase 2: Pilot** | Week 3-4 | Onboard 10 engineers (pilot group), gather feedback, refine policies |
| **Phase 3: Rollout** | Week 5-8 | Onboard remaining 40 engineers, import browser-saved passwords, disable browser password managers |
| **Phase 4: Enforcement** | Week 9-12 | Enforce security policies (MFA, password strength), monitor adoption, address remaining shadow-IT |

---

## Sources

1. 1Password Business pricing: https://1password.com/pricing/ — $7.99/user/month billed annually
2. 1Password CLI: https://github.com/1Password/onepassword-cli
3. 1Password Terraform Provider: https://github.com/1Password/terraform-provider-onepassword
4. 1Password Ansible Collection: https://github.com/1Password/ansible-onepasswordconnect-collection
5. 1Password Connect API: https://1password.com/connect/
6. 1Password SSO: https://1password.com/features/ — SAML 2.0 support with Google Workspace, Okta, Azure AD
7. 1Password Security: https://1password.com/security/ — SOC 2 Type 2 certified, regular third-party audits
8. 1Password SOC 2 Report: https://1password.com/resources/soc2
9. 1Password Features: https://1password.com/features/ — Admin console, shared folders, security policies, audit logs
10. Bitwarden pricing: https://bitwarden.com/pricing/ — Business Teams $4/user/month, Business Enterprise $6/user/month
11. Bitwarden GitHub: https://github.com/bitwarden — Open source
12. Bitwarden Compliance: https://bitwarden.com/compliance/ — SOC 2 Type 2, SOC 3, ISO 27001
13. Bitwarden CLI: https://github.com/bitwarden/cli
14. Bitwarden SSO: https://bitwarden.com/help/enterprise-sso/
