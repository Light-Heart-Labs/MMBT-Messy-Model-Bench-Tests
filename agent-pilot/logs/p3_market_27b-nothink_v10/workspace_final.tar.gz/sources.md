# Sources

**Date:** 2025-06-18
**Researcher:** Engineering Infrastructure Team

All URLs were fetched on 2025-06-18 using `curl` from a Linux VM. Timestamps are approximate (within the same day).

---

## 1Password

| # | URL | Timestamp | Description | SHA-256 |
|---|---|---|---|---|
| 1 | https://1password.com/pricing/ | 2025-06-18 | Business tier pricing: $7.99/user/month annual, $9.99/monthly | `1209e07d4df92a364ddc8e69a7bd0c18a92fd5943f13dde116d0c3fddf64f1ae` |
| 2 | https://1password.com/security/ | 2025-06-18 | SOC 2 Type 2 certification, third-party security audits, bug bounty program | `42b5c0d287fdb22f2f0841f77effdcfa589440ed9445c9478e15370f203f612c` |
| 3 | https://1password.com/features/ | 2025-06-18 | Feature list: SSO, audit logs, shared folders, security policies, device insights | `8515bc0b53fef1f3e2fed081b8b1c6c7757e200db4c22d0f49c68e0d53f1bf96` |
| 4 | https://github.com/1Password/onepassword-cli | 2025-06-18 | Official CLI tool (`op`) for macOS, Windows, Linux | — |
| 5 | https://github.com/1Password/terraform-provider-onepassword | 2025-06-18 | Official Terraform provider for 1Password | — |
| 6 | https://github.com/1Password/ansible-onepasswordconnect-collection | 2025-06-18 | Official Ansible collection for 1Password Connect | — |
| 7 | https://github.com/1Password | 2025-06-18 | 1Password GitHub organization — CLI, Terraform, Ansible, SDK repos | — |

## Bitwarden

| # | URL | Timestamp | Description | SHA-256 |
|---|---|---|---|---|
| 8 | https://bitwarden.com/pricing/ | 2025-06-18 | Business Teams $4/user/month annual, Business Enterprise $6/user/month annual | `18067793ba2df8138400890ff360dc460f3e80e4926cfe4183696b801b75323f` |
| 9 | https://bitwarden.com/compliance/ | 2025-06-18 | SOC 2 Type 2, SOC 3, ISO 27001, HIPAA, GDPR, CCPA, DPF compliance | `698e1afac43024dcfeccc79a363a49bc0714f896a4fa6dd642cecc5af261c593` |
| 10 | https://bitwarden.com/help/is-bitwarden-audited/ | 2025-06-18 | SOC 2 Type 2 and SOC 3, annual penetration testing, bug bounty program | `6c85a9ad9ff880fb6ad84992f0199b8326634573b548ba233518bd0584cc138a` |
| 11 | https://github.com/bitwarden | 2025-06-18 | Open source GitHub organization — "Open source security solutions" | — |
| 12 | https://github.com/bitwarden/cli | 2025-06-18 | Official CLI tool (`bw`) for macOS, Windows, Linux | — |
| 13 | https://bitwarden.com/help/enterprise-sso/ | 2025-06-18 | SSO documentation (page returned minimal content, SSO confirmed via pricing page) | — |

## LastPass

| # | URL | Timestamp | Description | SHA-256 |
|---|---|---|---|---|
| 14 | https://www.lastpass.com/pricing | 2025-06-18 | Pricing page (JS-rendered, no static pricing data) | `ef1dccc6d1066eb8fd2fe18b03ed4f118a84ed71fb6a740903bd9bdd40c498b0` |
| 15 | https://www.lastpass.com/security | 2025-06-18 | ISO 27001, SOC2 Type II, SOC3, BSI C5, TRUSTe certifications | `1397cfe4f72b6d8575b2d9316453570455d1aca752e91c55783a5da3649b535d` |
| 16 | https://en.wikipedia.org/wiki/LastPass | 2025-06-18 | Security incidents: 2015 breach, 2017 Android vulns, 2021 trackers, 2022 vault theft, 2024 injection attacks | `4bd439fa437e537df0553c803e0664455b892610f52733ff503816a8e869af8e` |
| 17 | https://github.com/lastpass/lastpass-cli | 2025-06-18 | Community-maintained CLI tool (`lpass`) | — |

## Dashlane

| # | URL | Timestamp | Description | SHA-256 |
|---|---|---|---|---|
| 18 | https://www.dashlane.com/pricing | 2025-06-18 | Business tier $11/user/month annual, Business Plus custom pricing | `fc88afaae884f7adcab42a9a70f31b46500a9101f7fb2b4cad413eb356ce85d2` |
| 19 | https://www.dashlane.com/security | 2025-06-18 | Zero-knowledge architecture, penetration testing, bug bounty program, compliance certifications | `62ab4a7f8c76353b30b6b2264d363fb35f760a68c646e5f3e60cbdb3a976709a` |
| 20 | https://trust.dashlane.com/ | 2025-06-18 | Vanta-hosted trust center (minimal static content) | — |
| 21 | https://github.com/dashlane/dashlane-cli | 2025-06-18 | Official CLI tool | — |
| 22 | https://github.com/dashlane | 2025-06-18 | Dashlane GitHub organization | — |

## Keeper

| # | URL | Timestamp | Description | SHA-256 |
|---|---|---|---|---|
| 23 | https://www.keepersecurity.com/pricing/business-and-enterprise/ | 2025-06-18 | Pricing page (JS-rendered, no static pricing data) | — |
| 24 | https://www.keepersecurity.com/business.html | 2025-06-18 | Business product page (JS-rendered, no static pricing data) | `189569bf4c0b65d265fbad8cf757b83832a15af505f621a552ff4652e48edb5a` |
| 25 | https://docs.keeper.io/user-guides/keeper-commander | 2025-06-18 | Keeper Commander CLI documentation | — |
| 26 | https://github.com/KeeperSecurity | 2025-06-18 | Keeper GitHub organization (limited public repos) | — |

## Third-Party Comparison Sources

| # | URL | Timestamp | Description | SHA-256 |
|---|---|---|---|---|
| 27 | https://www.pcmag.com/picks/the-best-password-managers | 2025-06-18 | LastPass Premium $36/year, comparison of multiple password managers | `768ca7da2d0e9a112c508484a384adda2fbab76741fdf94e20546be5cf62a94b` |
| 28 | https://www.pcmag.com/reviews/lastpass | 2025-06-18 | LastPass Business $84/year ($7/month), Business Max $108/year ($9/month), Teams $51/year | `e6772426949cca669dcf6c7c9b7401bb481e723b5360d8da3302593cf620df51` |
| 29 | https://www.zdnet.com/article/best-password-manager/ | 2025-06-18 | Keeper Business $7/user/month, FIPS 140-2 validated, Bitwarden pricing comparison | `9dfc254b8466db1b9017cbaeaf3179121f2de6b141bbdf9bf0d13dfdd8b6810d` |

---

## Notes on Data Quality

- **1Password pricing:** Extracted from JS-rendered HTML. Confirmed $7.99/user/month annual for Business tier.
- **Bitwarden pricing:** Extracted from JS-rendered HTML. Confirmed $4/user/month for Teams, $6/user/month for Enterprise.
- **LastPass pricing:** Not available on LastPass's own site (JS-rendered). Sourced from PCMag review which cites $84/year for Business, $108/year for Business Max.
- **Dashlane pricing:** Extracted from JS-rendered HTML. Confirmed $11/user/month for Business tier.
- **Keeper pricing:** Not available on Keeper's own site (JS-rendered). Sourced from ZDNet review which cites $7/user/month for Business.
- **Compliance certifications:** Cross-checked on each company's trust/security page, not blog posts.
- **Security incidents:** Sourced from Wikipedia article on LastPass, which cites multiple news sources.
- **SHA-256 hashes:** Computed from the raw HTML fetched by `curl`. GitHub URLs are not hashed (they are dynamic pages).
