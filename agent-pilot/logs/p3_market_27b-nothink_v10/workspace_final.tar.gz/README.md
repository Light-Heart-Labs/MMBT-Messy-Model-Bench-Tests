# Password Manager Evaluation — Output Files

This directory contains the output of a password manager evaluation for a 50-person engineering team at a Series-B SaaS company.

## Files

| File | Description |
|---|---|
| `recommendation.md` | **Primary deliverable.** 1-2 page recommendation memo with decision criteria, product recommendation, runner-up, and concerns. |
| `comparison.md` | Side-by-side feature/pricing/security comparison of 5 products: 1Password, Bitwarden, LastPass, Dashlane, Keeper. |
| `sources.md` | Every URL fetched during research, with timestamp and description. |
| `research/notes.md` | Working notes with detailed findings from each research step. |
| `decisions/` | ADR-style records for non-obvious calls. |
| `README.md` | This file. |

## Decision Records (ADRs)

| File | Description |
|---|---|
| `decisions/adr-001-product-selection.md` | Why these 5 products were selected for evaluation. |
| `decisions/adr-002-evaluation-criteria.md` | Weighted criteria for "best for this team." |
| `decisions/adr-003-primary-recommendation.md` | Rationale for recommending 1Password Business. |

## Quick Summary

- **Recommended:** 1Password Business at $7.99/user/month ($4,794/year for 50 seats)
- **Runner-up:** Bitwarden Business Teams at $4.00/user/month ($2,400/year for 50 seats)
- **Key differentiator:** 1Password has the strongest developer tooling (CLI, Terraform, Ansible, Connect API)
- **Key concern:** 1Password is proprietary (not open source); Bitwarden is open source but less polished

## How to Read

1. Start with `recommendation.md` for the executive summary and recommendation.
2. Read `comparison.md` for the detailed side-by-side comparison.
3. Check `sources.md` for source URLs and data quality notes.
4. Review `research/notes.md` for detailed research findings.
5. Read the ADRs in `decisions/` for the reasoning behind key calls.

## Methodology

- All pricing, features, and compliance data was fetched from public sources on 2025-06-18.
- JS-rendered pages were parsed via `curl` + `grep`/`python3` to extract data from embedded JSON.
- Where pricing was not available on a vendor's own site, third-party review sites (PCMag, ZDNet) were used.
- Security incident history was sourced from Wikipedia, which cites multiple news sources.
- Compliance certifications were cross-checked on each company's trust/security page, not blog posts.
