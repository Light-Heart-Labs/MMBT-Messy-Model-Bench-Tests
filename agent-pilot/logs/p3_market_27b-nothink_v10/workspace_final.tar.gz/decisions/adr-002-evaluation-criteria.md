# ADR-002: Evaluation Criteria

**Date:** 2025-06-18
**Status:** Accepted
**Decision:** Define weighted criteria for "best for this team"

## Context

A 50-person engineering team at a Series-B SaaS company needs a password manager. The team uses Google Workspace, has developer workflows (CI/CD, CLI tools), and will need SOC 2 compliance evidence.

## Criteria

### Must-Have (Weight: 40%)
1. **SSO Integration** — Must integrate with Google Workspace (our IdP). SAML 2.0 support required.
2. **Audit Logging** — Must provide admin-visible audit logs for SOC 2 compliance evidence.
3. **Multi-Platform Coverage** — Must support macOS, Windows, Linux, iOS, Android, and browser extensions.
4. **Zero-Knowledge Architecture** — Vendor must not be able to access decrypted vault data.

### Important (Weight: 35%)
5. **Developer Tooling** — CLI tool, CI/CD integration, or API access for engineers.
6. **Pricing Transparency** — Publicly listed per-seat pricing (no "contact sales" black box).
7. **Admin Console** — Self-service admin console for user management, shared folders, security policies.

### Nice-to-Have (Weight: 25%)
8. **Security Incident History** — Clean or well-resolved incident history.
9. **Open Source** — Source code auditable by our security team.
10. **Compliance Certifications** — SOC 2 Type 2, ISO 27001, FedRAMP, etc.
11. **Onboarding/Migration** — Tools to import from browser saves, other password managers.

## Scoring

Each criterion scored 1-5 (1 = missing/poor, 5 = excellent). Weighted score = sum of (score × weight).

## Consequences

- This criteria set favors products with strong developer tooling and transparent pricing
- Security incident history is a nice-to-have but will be a disqualifier if severe
- Open source is a differentiator but not a requirement
