# ADR-003: Primary Recommendation — 1Password Business

**Date:** 2025-06-18
**Status:** Accepted
**Decision:** Recommend 1Password Business tier at $7.99/user/month (annual billing)

## Context

After evaluating 5 password managers against the criteria defined in ADR-002, 1Password Business emerged as the best fit for our 50-person engineering team.

## Rationale

1. **Best-in-class developer tooling** — 1Password offers a native CLI (`op`), Terraform provider, Ansible collection, and Connect API for CI/CD integration. This is critical for our engineering team's workflows.
2. **Strong SSO integration** — Supports SAML 2.0 with Google Workspace, Okta, Azure AD, and other IdPs.
3. **SOC 2 Type 2 certified** — Meets our compliance requirements for SOC 2 evidence.
4. **Clean security history** — No major data breaches or security incidents.
5. **Excellent admin console** — Self-service user management, shared folders, security policies, and audit logs.
6. **Transparent pricing** — $7.99/user/month billed annually ($4,794/year for 50 seats).

## Runner-Up

Bitwarden Business Teams at $4.00/user/month ($2,400/year for 50 seats) is the runner-up. It would beat 1Password if:
- Budget is the primary constraint (Bitwarden is ~50% cheaper)
- Open-source auditability is a hard requirement
- The team is comfortable with a slightly less polished admin UX

## Concerns

- 1Password is proprietary (not open source)
- Higher cost than Bitwarden
- Vendor lock-in risk (though export is supported)

## Consequences

- Annual cost: $4,794 for 50 seats
- 90-day rollout plan: Week 1-2 admin setup, Week 3-4 pilot with 10 engineers, Week 5-12 full rollout
- Migration: 1Password supports import from browser saves, LastPass, Dashlane, and other managers
