# ADR-001: Product Selection for Evaluation

**Date:** 2025-06-18
**Status:** Accepted
**Decision:** Evaluate 5 password managers: 1Password, Bitwarden, LastPass, Dashlane, Keeper

## Context

The engineering team needs a standardized password manager to replace shadow-IT storage (browser saves, sticky notes, Slack DMs). The CTO has mandated resolution within 90 days.

## Options Considered

We considered evaluating:
- 1Password
- Bitwarden
- LastPass
- Dashlane
- Keeper
- NordPass
- RoboForm
- Zoho Vault
- CyberArk Endpoint Privilege Manager

## Decision

We selected the top 5 by market presence, feature completeness, and relevance to a 50-person Series-B SaaS engineering team:

1. **1Password** — Market leader, strong developer tooling (CLI, Terraform provider, Ansible collection), SOC 2 Type 2
2. **Bitwarden** — Open-source, lowest cost, strong security posture, SOC 2 Type 2 + ISO 27001
3. **LastPass** — Well-known brand, but with significant security incident history
4. **Dashlane** — Strong UX, patent-protected zero-knowledge, SOC 2 certified
5. **Keeper** — Enterprise-focused, FIPS 140-2 validated, strong compliance posture

We excluded:
- **NordPass** — Newer entrant, less mature admin/SSO features
- **RoboForm** — Declining market presence, limited developer tooling
- **Zoho Vault** — Tied to Zoho ecosystem, less independent
- **CyberArk EPM** — Overkill for 50-person team; more of a secrets management/privileged access product

## Consequences

- This set covers the spectrum from open-source/low-cost (Bitwarden) to premium/feature-rich (1Password, Dashlane)
- All 5 support SSO, audit logs, and multi-platform coverage
- All 5 have CLI tools for developer workflows
