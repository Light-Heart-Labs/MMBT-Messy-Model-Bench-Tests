# Password Manager Comparison: 5 Products Evaluated

**Date:** 2025-06-18
**Team Size:** 50 engineers
**Context:** Series-B SaaS company, Google Workspace IdP, SOC 2 compliance needed

---

## Pricing Comparison (Annual Billing)

| Product | Tier | Per-Seat Price | 50-Seat Annual Cost | Source |
|---|---|---|---|---|
| **1Password** | Business | $7.99/user/month | $4,794/year | [1] |
| **Bitwarden** | Business Teams | $4.00/user/month | $2,400/year | [2] |
| **Bitwarden** | Business Enterprise | $6.00/user/month | $3,600/year | [2] |
| **LastPass** | Business | $7.00/user/month ($84/year) | $3,500/year | [3] |
| **LastPass** | Business Max | $9.00/user/month ($108/year) | $4,500/year | [3] |
| **Dashlane** | Business | $11.00/user/month | $6,600/year | [4] |
| **Dashlane** | Business Plus | Custom pricing (contact sales) | N/A | [4] |
| **Keeper** | Business | $7.00/user/month (min 5 seats) | $4,200/year | [5] |

---

## Feature Comparison

| Feature | 1Password Business | Bitwarden Teams | Bitwarden Enterprise | LastPass Business | Dashlane Business | Keeper Business |
|---|---|---|---|---|---|---|
| **SSO (SAML 2.0)** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Google Workspace SSO** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Audit Logs** | ✅ | ❌ (Enterprise only) | ✅ | ✅ | ✅ | ✅ |
| **CLI Tool** | ✅ (`op`) | ✅ (`bw`) | ✅ (`bw`) | ✅ (`lpass`) | ✅ | ✅ (Commander) |
| **CI/CD API** | ✅ (Connect API) | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Terraform Provider** | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Ansible Collection** | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Browser Extensions** | ✅ (Chrome, Firefox, Safari, Edge) | ✅ (Chrome, Firefox, Safari, Edge) | ✅ | ✅ | ✅ | ✅ |
| **macOS App** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Windows App** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Linux App** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **iOS App** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Android App** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Shared Folders** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Security Policies** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Password Generator** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Emergency Access** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Passkey Support** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Zero-Knowledge** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Open Source** | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ |
| **Self-Hosted Option** | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ |

---

## Security & Compliance Comparison

| Certification | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---|---|---|---|---|---|
| **SOC 2 Type 2** | ✅ [6] | ✅ [7] | ✅ [8] | ✅ (claimed) | ✅ (claimed) |
| **SOC 3** | ❌ | ✅ [7] | ✅ [8] | ❌ | ❌ |
| **ISO 27001** | ❌ | ✅ [7] | ✅ [8] | ❌ | ✅ (claimed) |
| **HIPAA** | ❌ | ✅ [7] | ❌ | ❌ | ❌ |
| **GDPR** | ✅ (compliant) | ✅ [7] | ✅ (compliant) | ✅ (compliant) | ✅ (compliant) |
| **FedRAMP** | ❌ | ❌ | ❌ | ❌ | ❌ |
| **FIPS 140-2** | ❌ | ❌ | ❌ | ❌ | ✅ [9] |
| **BSI C5** | ❌ | ❌ | ✅ [8] | ❌ | ❌ |
| **Bug Bounty Program** | ✅ | ✅ [7] | ✅ | ✅ | ✅ |
| **Penetration Testing** | ✅ (regular) | ✅ (annual) [7] | ✅ (regular) [8] | ✅ (annual) | ✅ (regular) |

---

## Security Incident History

| Product | Incidents | Details |
|---|---|---|
| **1Password** | None known | No major public security incidents |
| **Bitwarden** | None known | No major public security incidents |
| **LastPass** | Multiple | 2015 security breach, 2017 Android vulnerabilities, 2021 third-party trackers, 2022 customer data & partially-encrypted vault theft, 2024 leakage via injection attacks [10] |
| **Dashlane** | None known | No major public security incidents |
| **Keeper** | None known | No major public security incidents |

---

## Developer Tooling Comparison

| Tool | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---|---|---|---|---|---|
| **CLI** | `op` (official) [11] | `bw` (official) [12] | `lpass` (community) [13] | CLI (official) [14] | Commander (official) [15] |
| **Terraform Provider** | ✅ (official) [16] | ❌ | ❌ | ❌ | ❌ |
| **Ansible Collection** | ✅ (official) [17] | ❌ | ❌ | ❌ | ❌ |
| **CI/CD API** | ✅ (Connect API) [18] | ❌ | ❌ | ❌ | ❌ |
| **GitHub Actions** | ✅ (community) | ✅ (community) | ❌ | ❌ | ❌ |
| **Docker Support** | ✅ (Connect) | ✅ (self-hosted) | ❌ | ❌ | ❌ |

---

## Sources

1. 1Password pricing: https://1password.com/pricing/ — Business tier $7.99/user/month annual
2. Bitwarden pricing: https://bitwarden.com/pricing/ — Teams $4/user/month, Enterprise $6/user/month
3. LastPass pricing: https://www.pcmag.com/reviews/lastpass — Business $84/year ($7/month), Business Max $108/year ($9/month)
4. Dashlane pricing: https://www.dashlane.com/pricing — Business $11/user/month
5. Keeper pricing: https://www.zdnet.com/article/best-password-manager/ — Keeper Business $7/user/month
6. 1Password SOC 2: https://1password.com/security/ — SOC 2 Type 2 certified
7. Bitwarden compliance: https://bitwarden.com/compliance/ and https://bitwarden.com/help/is-bitwarden-audited/ — SOC 2 Type 2, SOC 3, ISO 27001, HIPAA, GDPR
8. LastPass compliance: https://www.lastpass.com/security — ISO 27001, SOC2 Type II, SOC3, BSI C5, TRUSTe
9. Keeper FIPS: https://www.zdnet.com/article/best-password-manager/ — FIPS 140-2 validated
10. LastPass incidents: https://en.wikipedia.org/wiki/LastPass — 2015 breach, 2017 Android vulns, 2021 trackers, 2022 vault theft, 2024 injection attacks
11. 1Password CLI: https://github.com/1Password/onepassword-cli
12. Bitwarden CLI: https://github.com/bitwarden/cli
13. LastPass CLI: https://github.com/lastpass/lastpass-cli
14. Dashlane CLI: https://github.com/dashlane/dashlane-cli
15. Keeper Commander: https://docs.keeper.io/user-guides/keeper-commander
16. 1Password Terraform: https://github.com/1Password/terraform-provider-onepassword
17. 1Password Ansible: https://github.com/1Password/ansible-onepasswordconnect-collection
18. 1Password Connect: https://1password.com/connect/
