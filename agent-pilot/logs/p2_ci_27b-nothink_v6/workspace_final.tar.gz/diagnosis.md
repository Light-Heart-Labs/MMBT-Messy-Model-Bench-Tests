# Diagnosis

## CI Failure Analysis

The CI log showed 1 ruff error and 3 test failures. Here's the breakdown:

### 1. Ruff F401: Unused `import json` in `cart.py`

**What was wrong:** Line 4 of `cart.py` had `import json` with a comment `# PLANTED BUG #3: unused import`. This import was never used anywhere in the file.

**Fix:** Removed the import line.

**Decision:** Code fix — the import was clearly a bug, not intentional.

---

### 2. `test_discount_amount` — `assert 2000.0 == 20.0`

**What was wrong:** `discount_amount(100.0, 20.0)` returned 2000.0 instead of 20.0. The function computes `price * percent_off` but since v0.3.0 the API takes percent (0–100), not fraction (0.0–1.0). The implementation was never updated to match the new API — it still treated the input as a raw multiplier.

**Fix:** Changed `price * percent_off` to `price * percent_off / 100` in `discount.py`.

**Decision:** Code fix — the docstring examples (`discount_amount(100.0, 20.0) -> 20.0`) and the changelog both confirm the correct behavior. The test was right; the implementation was wrong.

---

### 3. `test_apply_discount` — `assert -1900.0 == 80.0`

**What was wrong:** `apply_discount(100.0, 20.0)` returned -1900.0. This is a cascading failure from the `discount_amount` bug: `apply_discount` calls `discount_amount`, which returned 2000.0, so `100.0 - 2000.0 = -1900.0`.

**Fix:** Fixed automatically by fixing `discount_amount` (issue #2 above).

**Decision:** Code fix — same root cause as #2.

---

### 4. `test_line_count_matches_qty_sum` — `assert 2 == 5`

**What was wrong:** The test expected `line_count()` to return 5 (total quantity across lines), but the code returned 2 (number of lines). The v0.3.0 changelog explicitly documented this breaking change: `Cart.line_count()` now returns the number of lines, not total quantity. The test was never updated.

**Fix:** Updated the test to expect 2 (number of lines) and updated the docstring comment.

**Decision:** Test fix — the code correctly implements the v0.3.0 API. The test was stale and still reflected the v0.2.0 behavior. The changelog confirms the code is correct.

---

### 5. Additional ruff lint issues (I001, UP006, UP035, UP045)

**What was wrong:** Import sorting issues, use of deprecated `typing.List` instead of builtin `list`, and use of `Optional[X]` instead of `X | None`.

**Fix:** Reorganized imports, replaced `List` with `list`, replaced `Optional[float]` with `float | None`, removed unused `Optional` import.

**Decision:** Code fix — these are style/modernization issues that ruff flags.
