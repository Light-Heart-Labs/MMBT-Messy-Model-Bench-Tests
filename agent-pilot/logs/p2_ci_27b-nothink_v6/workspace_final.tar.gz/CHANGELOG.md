# Changelog

## v0.3.2 (2025-01-XX)

**Bug fixes:**

- **`discount_amount()` was not dividing by 100.** The v0.3.0 breaking change switched the API from fraction (0.0–1.0) to percent (0–100), but the implementation still multiplied `price * percent_off` directly instead of `price * percent_off / 100`. This caused `discount_amount(100.0, 20.0)` to return 2000.0 instead of 20.0. Fixed by dividing by 100.
- **Unused `import json` in `cart.py`.** A leftover import triggered ruff F401. Removed.
- **`test_line_count_matches_qty_sum` test was not updated for v0.3.0 API change.** The changelog documented that `Cart.line_count()` now returns the number of lines (not total quantity), but the test still expected the old behavior (total qty = 5). Updated the test to expect 2 (number of lines).
- **Ruff lint issues:** Fixed import sorting (I001), replaced deprecated `typing.List` with builtin `list` (UP006/UP035), replaced `Optional[X]` with `X | None` (UP045), and removed unused imports.

**Verification:**
- `ruff check src/ tests/` → All checks passed (exit 0)
- `pytest -q` → 7 passed, 0 failed (exit 0)

## v0.3.1 (previous — CI red)

CI was failing on this version. See `ci_failure.log` for the full output.

## v0.3.0

- **BREAKING**: `discount_amount()` and `apply_discount()` now take percent (0-100)
  instead of fraction (0.0-1.0). Update callers from `apply_discount(p, 0.2)` to
  `apply_discount(p, 20.0)`.
- `Cart.line_count()` now returns the number of lines, not the total quantity
  across lines. Tests should be updated where they relied on the old behavior.

## v0.2.0

- Added `Cart.set_discount()` for cart-wide discounts.
- `Cart.line_count()` returns total quantity across lines.

## v0.1.0

- Initial release.
