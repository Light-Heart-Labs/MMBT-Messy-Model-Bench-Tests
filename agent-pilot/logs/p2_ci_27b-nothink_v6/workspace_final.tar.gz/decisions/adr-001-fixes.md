# ADR-001: Fix discount_amount implementation, not the tests

## Context

The `discount_amount()` function was returning `price * percent_off` (e.g., 100 * 20 = 2000) instead of `price * percent_off / 100` (e.g., 100 * 20 / 100 = 20).

The v0.3.0 changelog documented a breaking API change: the function now takes percent (0–100) instead of fraction (0.0–1.0). However, the implementation was never updated to match — it still treated the input as a raw multiplier.

## Decision

Fix the implementation by dividing by 100. Do not change the tests.

## Rationale

- The docstring examples in the code explicitly state `discount_amount(100.0, 20.0) -> 20.0`
- The changelog confirms the API takes percent (0–100)
- The tests correctly expect 20.0 for a 20% discount on $100
- The implementation was simply never updated when the API changed

## Consequences

- `discount_amount` now correctly computes percentage discounts
- `apply_discount` (which depends on `discount_amount`) is also fixed as a cascading effect

---

# ADR-002: Fix the line_count test, not the implementation

## Context

`Cart.line_count()` returns `len(self.lines)` (number of lines). The test `test_line_count_matches_qty_sum` expected it to return the total quantity across all lines (5).

The v0.3.0 changelog explicitly states: `Cart.line_count()` now returns the number of lines, not the total quantity across lines.

## Decision

Fix the test to expect 2 (number of lines). Do not change the implementation.

## Rationale

- The changelog documents this as an intentional breaking change in v0.3.0
- The code correctly implements the documented API
- The test was simply never updated after the v0.3.0 release
- The test name `test_line_count_matches_qty_sum` is misleading but the docstring was updated to clarify the intent

## Consequences

- The test now correctly validates the v0.3.0+ behavior of `line_count()`
- No API surface change needed
