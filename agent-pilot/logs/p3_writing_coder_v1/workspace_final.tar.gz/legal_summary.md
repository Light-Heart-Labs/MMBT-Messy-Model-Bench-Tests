# Legal Summary: SLA Credit Obligations — Friday Incident

## Incident Facts

- **Time window**: 14:11 UTC to 18:24 UTC on Friday (4 hours 13 minutes)
- **Scope**: 11,400 customer accounts impacted
- **Enterprise accounts**: 28 accounts with named CSMs experienced revenue impact during business hours
- **Known downstream harm**: 4 customers reported downstream automation failures requiring manual cleanup

## SLA Framework

- Contractual SLA: 99.9% monthly uptime
- SLA breach occurred for impacted accounts during the incident window

## Credit Obligation Assessment

- **Contractual credits**: SLA credits are due to all impacted accounts where uptime fell below 99.9% for the month. These should be processed automatically per the MSA terms.
- **Special cases**: The 4 customers with confirmed downstream automation failures may warrant additional goodwill gestures beyond standard SLA credits (e.g., hands-on data cleanup support).
- **No-impact accounts**: Accounts that experienced no measurable business impact but request credits on relationship grounds are not contractually obligated; these should be handled case-by-case by Finance and Customer Success.

## Recommendation

Process SLA credits for all accounts that experienced measurable service degradation during the incident window. For the 4 downstream-automation cases, consider additional support engagement as a goodwill gesture.
