# Working Notes

## Source Memo Summary

- **Incident time**: 14:11 UTC to 18:24 UTC on Friday
- **Root cause**: A config change doubled rate-limit thresholds for the internal authentication service. An internal limiter used a fraction of the global threshold, but computed against a hard-coded MAX value instead of the new configured value, causing all auth requests to be throttled.
- **Impact**: 
  - 11,400 customer accounts impacted
  - 28 enterprise accounts (named CSMs) had real revenue impact during business hours
  - 4 downstream automation cases broke and required manual cleanup
  - 217 support tickets, 31 refund requests
- **Recovery**: Config reverted at 18:18 UTC; traffic fully recovered by 18:24 UTC
- **Remediations**:
  1. Add canary deploys for config changes (1 sprint)
  2. Fix internal limiter to use actual global config instead of hard-coded MAX (2 weeks)
  3. Fix status-page check to use correct endpoints (already done)
  4. Improve incident communication (15-min acknowledgment)
  5. Update runbooks

## Key Numbers to Preserve

- 11,400 total impacted accounts
- 28 enterprise accounts with named CSMs
- 4 downstream automation cases with manual cleanup
- 217 support tickets
- 31 refund requests
- Incident duration: 14:11–18:24 UTC (4 hours 13 minutes)
- Config change at 14:09 UTC
- Recovery completed at 18:24 UTC

## Audience-Specific Constraints

### CEO Brief
- Must include: one-line summary, scope (accounts, revenue), second-occurrence-in-90-days, top 3-4 remediations
- Must NOT include: internal nicknames, engineering jargon, detailed technical explanations
- Max: 250 words

### Customer Email
- Must include: outage acknowledgment, root cause in plain language, commitments, SLA credit offer, contact path
- Must NOT include: named engineer, engineering jargon, "second outage in 90 days", internal candor
- Max: 350 words

### Legal Summary
- Must include: exact time window, account count, tier breakdown, SLA threshold (99.9%), 4 downstream cases, credit handling recommendation
- Must NOT include: speculation, named blame, informal candor, marketing language, remediation details
- Max: 400 words
