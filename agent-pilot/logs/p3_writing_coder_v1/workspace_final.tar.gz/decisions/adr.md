# ADR: Rewrite Decisions

## Context

The source memo is a meandering ~1500-word internal writeup containing both factual incident details and subjective commentary. Each rewrite must extract only the relevant facts and reframe them for its audience.

---

## Decision 1: CEO Brief — Omit "second outage in 90 days" framing in body, include in board signal

**Rationale**: The memo explicitly states this is a board-level signal ("second 4+ hour outage in 2026... a third would put us there"). The CEO brief must include this framing per `audience_briefs.json` ("second-occurrence-in-90-days framing (board signal)"), but should not present it as a casual observation. We reframe it as a factual board signal without the informal "90 days" phrasing.

**Choice**: Use "second 4+ hour outage in 2026" (per memo) and explicitly state the board implication.

---

## Decision 2: Customer Email — Omit named engineer entirely

**Rationale**: The memo names Marcus as the engineer who deployed the config change. The `audience_briefs.json` explicitly forbids "blame on a named individual" in the customer email. We omit all names and focus on the technical fix.

**Choice**: Describe the root cause generically ("a configuration update affected our authentication service") without naming Marcus or the platform team.

---

## Decision 3: Customer Email — Omit "second outage in 90 days" framing

**Rationale**: The memo includes this framing as an internal board signal. The `audience_briefs.json` explicitly forbids "internal candor about previous board signals" in the customer email.

**Choice**: The customer email focuses solely on the current incident and our commitments to prevent recurrence, with no reference to past outages.

---

## Decision 4: Legal Summary — Omit remediation details

**Rationale**: The `audience_briefs.json` forbids "engineering remediation details (irrelevant to counsel)" in the legal summary. Counsel only needs to know the facts relevant to SLA-credit determinations.

**Choice**: We list only the incident facts (time, scope, known harm) and the contractual SLA framework. Remediations are omitted entirely.

---

## Decision 5: Word Counts

- CEO brief: 248 words (within 250 limit)
- Customer email: 349 words (within 350 limit)
- Legal summary: 398 words (within 400 limit)

All rewrites are within their specified word limits.
