# Important Update: Service Issue on Friday

Hi [Customer Name],

We experienced a service issue on Friday from 14:11 to 18:24 UTC that caused our API to return errors for many of our customers. We know this disrupted your workflows, and we sincerely apologize.

Our engineering team identified the root cause: a configuration update affected our authentication service in an unexpected way, leading to widespread request failures. The issue was fully resolved by 18:24 UTC.

We’re taking concrete steps to prevent this from happening again:
- Implementing staged configuration rollouts to catch issues earlier
- Fixing the internal logic that caused the failure
- Updating our monitoring to detect this type of problem faster
- Improving our incident response communications

As part of our service commitment, we’re offering SLA credits to all affected accounts. If you’d like to request a credit, please contact your CSM or support team with your account details.

If your automation workflows were impacted, our support team is available to help you review and restore any affected data.

You can always check our status page for real-time updates, or reply to this email with questions.

Thanks for your continued trust,

— The Customer Success Team
