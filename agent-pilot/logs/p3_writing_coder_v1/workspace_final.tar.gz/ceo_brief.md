# CEO Brief: Friday Outage Summary

**What happened**: A configuration change caused our primary API to return 502 errors for approximately 4 hours (14:11–18:24 UTC), affecting 11,400 customer accounts.

**Scope**: 28 enterprise accounts (those with named CSMs) experienced real revenue impact during business hours. Four customers reported downstream automation failures requiring manual cleanup. Total support tickets: 217.

**Board signal**: This is the second 4+ hour outage in 2026 (the other was in February). A third such incident would trigger a full reliability program review.

**What we’re doing**:
1. Adding staged config rollouts (canary deploys for configuration changes) — estimated 1 sprint.
2. Fixing the internal rate-limit logic that caused the failure — estimated 2 weeks.
3. Updating status-page checks to use customer-facing endpoints — completed.
4. Implementing a 15-minute incident acknowledgment policy — in progress.

We will issue SLA credits to impacted accounts and provide hands-on support for the four customers with automation failures.

— M., Engineering
