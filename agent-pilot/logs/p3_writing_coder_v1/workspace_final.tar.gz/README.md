# Incident Rewrite Package

This directory contains three audience-specific rewrites of the internal draft memo (`/input/repo/draft_memo.md`), each tailored to its target audience per the specifications in `/input/repo/audience_briefs.json`.

## Output Files

- `ceo_brief.md` — 5-minute board-prep read for the CEO (≤250 words)
- `customer_email.md` — mass email to affected customers (≤350 words)
- `legal_summary.md` — for in-house counsel reviewing SLA-credit obligations (≤400 words)

## Supporting Materials

- `decisions/adr.md` — ADR-style records for non-obvious choices (e.g., what to omit per audience)
- `research/notes.md` — Working notes summarizing the source memo and key constraints

## Key Constraints Applied

- **CEO brief**: Executive tone, no engineering jargon, includes "second outage in 2026" as a board signal, omits named individuals
- **Customer email**: Warm, accountable tone, no blame or jargon, explicit SLA credit offer, omits internal signals
- **Legal summary**: Precise, factual tone, omits speculation and remediation details, focuses on SLA breach facts

All rewrites preserve the substantive facts from the source memo and avoid any invented details.
