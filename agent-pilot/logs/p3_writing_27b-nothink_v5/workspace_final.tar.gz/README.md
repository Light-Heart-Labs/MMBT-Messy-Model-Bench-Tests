# Incident Rewrite Output

This directory contains three audience-specific rewrites of an internal engineering memo documenting a ~4-hour API outage on Friday (14:11–18:24 UTC). Each rewrite is tailored to its target audience per the specifications in `/input/repo/audience_briefs.json`.

## Files

| File | Audience | Word Count | Limit |
|------|----------|------------|-------|
| `ceo_brief.md` | CEO / Board prep | 219 | ≤250 |
| `customer_email.md` | Affected customers (mass email) | 268 | ≤350 |
| `legal_summary.md` | In-house counsel (SLA review) | 278 | ≤400 |
| `decisions/adr-001-omission-decisions.md` | ADR for key omission choices | — | — |
| `research/notes.md` | Working notes and fact extraction | — | — |

All facts, numbers, times, and counts are drawn exclusively from the source memo at `/input/repo/draft_memo.md`. No external information was introduced.
