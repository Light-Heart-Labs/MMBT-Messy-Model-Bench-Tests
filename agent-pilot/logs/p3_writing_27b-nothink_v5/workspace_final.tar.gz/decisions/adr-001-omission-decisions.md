# ADR-001: Omission Decisions Per Audience

## Status: Accepted

## Context
The source memo contains information relevant to some audiences but inappropriate for others. This document records the rationale for key omission decisions.

---

## Decision 1: Named Engineer (Marcus) — Omitted from Customer Email and Legal Summary

**Rationale:** The customer email must not blame a named individual per the audience brief. The legal summary must not include named-employee blame. The CEO brief omits the name because it is not material to board-level understanding — the issue is systemic (no canary for config), not individual.

**Source reference:** "someone on the platform team (it was Marcus...)"

---

## Decision 2: "Second Outage in 90 Days" — Included in CEO Brief, Omitted from Customer Email

**Rationale:** The audience brief explicitly requires the second-occurrence framing for the CEO brief (board signal) and explicitly forbids it in the customer email ("that's an internal signal, not a customer-facing one"). The legal summary omits it because it is not relevant to SLA-credit determination.

**Source reference:** "this is the second 4+ hour outage in 2026 (the other was in February with the database storage issue)... second data point in 90 days"

---

## Decision 3: Sarah's Warning — Omitted from All Rewrites

**Rationale:** The "sorry Sarah, you were right" reference is internal candor and an informal apology. It is excluded from the CEO brief (no informal apologies), the customer email (no internal candor about unaddressed warnings), and the legal summary (no informal candor). The underlying fact (the code defect was known) is relevant to the CEO brief's remediation item but the personal reference is not.

**Source reference:** "I personally was told about it last June by Sarah, who left in September; sorry Sarah, you were right"

---

## Decision 4: Technical Root Cause Detail Level

**Rationale:**
- **CEO brief:** Described at high level ("configuration change... inadvertently blocked all inbound requests") without engineering jargon. The fraction-against-MAX explanation is excluded per the must_not_include list.
- **Customer email:** Described in plain language ("configuration update... caused our system to reject all incoming authentication requests"). No mention of rate limiters, MAX values, or throttling internals.
- **Legal summary:** Root cause is not included at all, as it is irrelevant to SLA-credit determination. Engineering remediation details are excluded per the must_not_include list.

---

## Decision 5: SLA Credit Language Per Audience

**Rationale:**
- **CEO brief:** States SLA credits are owed and that legal/finance are processing — factual, no commitment language.
- **Customer email:** Explicitly offers SLA credit with a clear path to request — per the must_include requirement.
- **Legal summary:** Provides a structured recommendation distinguishing contractual vs. relationship-driven requests — per the must_include requirement.

---

## Decision 6: Word Count Management

**Rationale:** Each rewrite was kept well within its word limit to allow for clarity without sacrificing required content. The CEO brief (219/250), customer email (268/350), and legal summary (278/400) all have margin for potential edits.
