# Outage Brief — Friday, 14:11–18:24 UTC

**Summary:** Our primary API returned errors for approximately 4 hours on Friday, impacting roughly 11,400 customer accounts.

**Impact:** Of the affected accounts, 28 enterprise customers experienced revenue impact during business hours. At least 4 customers had downstream automation failures requiring manual cleanup. We received 217 support tickets and 31 refund requests.

**Root Cause (high level):** A configuration change to our authentication service inadvertently blocked all inbound requests. The change was reverted at 18:18 UTC; full recovery by 18:24 UTC.

**Board Signal:** This is the second 4+ hour incident in 90 days (the first was a database storage issue in February). A third occurrence would warrant a reliability program overhaul discussion.

**Remediations Underway:**
1. **Staged config rollout** — Adding per-region canary deployment for configuration changes (~1 sprint).
2. **Fix underlying code defect** — The internal limiter was computing thresholds against a hard-coded value rather than live configuration (~2 weeks).
3. **Status-page monitoring corrected** — The check was pointing at the wrong endpoint; fixed Friday evening.
4. **Faster customer communication** — On-call commander will issue an acknowledgment within 15 minutes of confirmed impact, regardless of root-cause status.

**Customer Obligations:** SLA credits are owed to affected accounts per our 99.9% monthly uptime commitment. Legal and finance are processing the 31 refund requests case by case.
