# Research Notes — Password Manager Evaluation

## Date: 2025-06-18

## Products to Evaluate
1. 1Password (Teams/Business)
2. Bitwarden (Teams/Business)
3. LastPass (Business)
4. Dashlane (Business)
5. Keeper (Business)

## Criteria to Research
- Per-seat pricing (annual)
- SSO integration (Google Workspace, Okta, etc.)
- Audit logging
- SOC 2 / FedRAMP compliance
- Mobile + desktop coverage
- Developer tool integrations (CLI, CI/CD, browser extensions)
- Admin console UX
- Security incident history
- Onboarding/migration tools

## Methodology
- Visit each product's pricing page
- Visit each product's trust/compliance page
- Check GitHub for CLI tools
- Search for security incidents
- Cross-reference with independent reviews
