# ADR: Executive Brief Framing for Nimbus Logistics, Inc.

## Decision: Recommendation stance

**Choice**: Pass on follow-on investment, but keep watchlist position.

**Rationale**:
- The company is executing a painful but necessary pivot from growth-at-all-costs to sustainability.
- The $84M raise was not a clean win — it was repriced down from $720M to $560M, and the company is already cutting costs aggressively.
- The run-rate ARR ($36-37M) and negative unit economics (burn > revenue) suggest the path to Q4 2026 breakeven is narrow.
- If they hit the breakeven target, it's a great story for Series C. If not, more dilution.
- The investor should wait for Q2/Q3 2026 results before committing more capital.

**Alternative considered**: "More diligence needed"
- Rejected because the data is sufficient to form a clear stance, even if the outcome is uncertain.
- "More diligence needed" is a cop-out when the evidence already suggests caution.

## Decision: Structure of the brief

**Choice**: Lead with the recommendation, then present the evidence, then restate the recommendation with caveats.

**Rationale**:
- The partner has 5 minutes — they need to know the stance immediately.
- The press release narrative is optimistic; the work is in synthesizing it with the contradictory signals.
- The brief must be honest about source quality — e.g., "according to" for the blog post, "reported" for the press release, "leaked memo states" for the internal memo.

## Decision: How to handle ARR discrepancy

**Choice**: Lead with the adjusted run-rate ARR ($36-37M) as the more accurate number, with a note that the company reported $42M.

**Rationale**:
- The TechCrunch article is a credible third-party source that provides context for the company's claim.
- The blog post's revenue figure (~$3.5M/month) aligns with the $42M annualized figure, but the TechCrunch adjustment for December churn is the more relevant metric for a follow-on investor.

## Decision: How to handle international expansion

**Choice**: Frame it as a strategic pivot — from "accelerate expansion" to "pause EMEA and focus on U.S. mid-market."

**Rationale**:
- The press release and the leaked memo are in direct contradiction.
- The memo is dated after the press release and reflects current strategy, not aspirational goals.
- This is a key signal that the company is in "runway preservation" mode.

## Decision: How to handle layoffs

**Choice**: Mention both the Feb 2025 layoffs (22 people) and the planned Q2 reductions (11-13 from Berlin).

**Rationale**:
- The blog post and the memo corroborate each other on layoffs.
- Layoffs are a red flag for morale and execution, but also a signal that the company is taking painful steps to survive.

## Decision: How to handle customer concentration

**Choice**: Highlight that top 5 customers = ~38% of ARR, and two of them were lost in late 2025.

**Rationale**:
- High customer concentration is a risk for any business, especially a startup.
- The loss of two top customers in quick succession is a material risk that the press release omits.

## Decision: How to handle unit economics

**Choice**: State that burn (~$4M/month) exceeds revenue (~$3.5M/month), implying negative unit economics.

**Rationale**:
- The blog post provides these numbers, and they are consistent with the need for cost-cutting in the memo.
- Negative unit economics are a red flag for scalability, but the company is taking steps to fix them.

## Decision: How to handle the credit facility

**Choice**: Frame the $50M credit facility as "insurance, not operating capital" (per the memo), extending runway to 36+ months.

**Rationale**:
- The memo's description is more accurate than the SEC filing's vague "working capital" language.
- The credit facility is a sign of preparedness, but not a sign of growth momentum.

## Decision: How to handle net retention claim

**Choice**: Mention the CEO's claim of >110% net retention, but note that it's uncorroborated and contradicted by the loss of two top customers.

**Rationale**:
- The TechCrunch article reports the claim, but also reports the churn.
- The claim is likely optimistic given the recent churn, so it should be presented with context.

## Decision: How to handle engineering quality

**Choice**: Acknowledge the high engineering quality (per the blog post), but note that it's not a substitute for unit economics.

**Rationale**:
- The blog post is positive about the engineering work, but the author still recommends against joining if you need job security.
- Engineering quality is a strength, but not a reason to invest more capital at this stage.

## Decision: How to handle the recommendation

**Choice**: Pass on follow-on, but keep watchlist position.

**Rationale**:
- The company is executing a painful but necessary pivot to sustainability.
- If they hit Q4 2026 breakeven target, it's a great story. If not, more dilution.
- The investor should wait for Q2/Q3 2026 results before committing more capital.
