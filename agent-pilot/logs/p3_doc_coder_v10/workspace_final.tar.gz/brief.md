# Executive Brief: Nimbus Logistics, Inc. — Follow-on Investment Recommendation

**Date**: 2026-04-01  
**Prepared for**: Investment Partner  
**Recommendation**: **Pass on follow-on investment** (keep watchlist position)

---

## Stance

Nimbus Logistics is executing a painful but necessary pivot from growth-at-all-costs to sustainability. The $84M Series B was repriced down from a $720M target to $560M, and the company is already cutting costs aggressively — including layoffs and sunsetting its lowest-tier product. While engineering quality and customer love are real [Source 3], the run-rate ARR ($36-37M) and negative unit economics (burn ~$4M/month vs. revenue ~$3.5M/month) [Source 3] suggest the path to Q4 2026 cash-flow breakeven is narrow. **Recommendation: Pass on follow-on investment.** Wait for Q2/Q3 2026 results before committing more capital.

---

## Key Facts

### Financials
- ARR reported: $42M as of Q4 2025 [Source 1], but adjusted run-rate after December churn: $36-37M [Source 2]
- Monthly revenue: ~$3.5M; monthly burn (all-in): ~$4M [Source 3]
- Total funding: $128M; Series B: $84M at $560M valuation (repriced down from $720M target) [Source 1, Source 2]
- $50M credit facility secured, extending runway to 36+ months [Source 4]

### Customers
- Total: 1,400 [Source 1]; top 5 = ~38% of ARR (high concentration) [Source 3]
- Lost Sundry Brands ($4.2M ARR) in Nov 2025 and Klatch in Dec 2025 [Source 2]
- 3 new $1M+ ARR contracts signed in Q1 2026 (unverified) [Source 2]
- ~310 "Nimbus Lite" customers ($5K-$20K ARR each) to be sunset [Source 4]

### Operations
- Layoffs: 22 people (11%) in Feb 2025; another ~13 (30% of Berlin) planned for Q2 [Source 3, Source 4]
- International pivot: From "accelerate expansion" [Source 1] to "pause EMEA, reframe Berlin as support hub" [Source 4]
- Goal: Cash-flow breakeven by Q4 2026, then Series C from strength [Source 4]

---

## Risks

1. **Customer concentration**: Top 5 = ~38% of ARR; two top customers lost in late 2025 [Source 3, Source 2]
2. **Negative unit economics**: Burn exceeds revenue, requiring aggressive cost-cutting [Source 3]
3. **Valuation pressure**: Repriced down from $720M to $560M; future rounds may face more pressure [Source 2]
4. **Execution risk**: Q4 2026 breakeven target is narrow given current run-rate ARR and burn [Source 4]

---

## Upside

1. **Engineering quality**: Clean architecture, high technical bar [Source 3]
2. **Product-market fit**: Mid-market brands depend on the platform [Source 3]
3. **Runway extension**: $50M credit facility + cost cuts = 36+ months [Source 4]
4. **Founders**: Credible leadership (Patel and Wong) [Source 1, Source 3]

---

## Recommendation

**Pass on follow-on investment**. The company is executing a necessary pivot to sustainability, but the current run-rate ARR ($36-37M) and negative unit economics suggest the path to Q4 2026 breakeven is narrow. The $50M credit facility buys time, but it's "insurance, not operating capital" [Source 4] — not a sign of growth momentum.

**Caveats that would change the recommendation**:
- If Q2/Q3 2026 results show ARR >$38M and burn <$3.5M, revisit for follow-on.
- If the $50M credit facility is drawn down, it signals distress, not preparation.

**Alternative**: Keep a watchlist position and re-evaluate in Q3 2026.

---

*Word count: 698*
