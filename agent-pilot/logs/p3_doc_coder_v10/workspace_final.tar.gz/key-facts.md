# Key facts — Nimbus Logistics, Inc.

## Financial metrics

- **ARR reported**: $42M as of Q4 2025 [Source 1]
- **Adjusted run-rate ARR after December 2025 churn**: $36-37M [Source 2]
- **Previous ARR**: $11M a year prior (2024) [Source 1]
- **Monthly revenue**: ~$3.5M [Source 3]
- **Monthly burn (all-in)**: ~$4M [Source 3]
- **Total funding raised**: $128M across all rounds [Source 1]
- **Series B amount**: $84M [Source 1, Source 5]
- **Post-money valuation**: $560M [Source 1]
- **Previous valuation (Series A)**: $230M [Source 1]
- **Target valuation for Series B (before repricing)**: $720M [Source 2]
- **Credit facility secured**: $50M from Silicon Valley Bridge [Source 4]

## Customers

- **Total customers**: 1,400 [Source 1]
- **Top 5 customers concentration**: ~38% of ARR [Source 3]
- **Lost Sundry Brands**: $4.2M ARR, non-renewed Nov 2025 [Source 2]
- **Lost Klatch**: fast-fashion brand, exited Dec 2025 [Source 2]
- **New $1M+ ARR contracts signed in Q1 2026**: 3 [Source 2]
- **Customers in "Nimbus Lite" tier (to be sunset)**: ~310 [Source 4]
- **ARR of "Nimbus Lite" customers**: $5K-$20K each [Source 4]

## Employees

- **Total employees**: 187 [Source 1]
- **Offices**: Oakland, Austin, Berlin [Source 1]
- **Berlin office headcount (pre-reduction)**: 41 [Source 4]
- **Berlin office headcount (post-reduction target)**: 28-30 by end Q2 [Source 4]
- **Layoffs in Feb 2025**: 22 people (11% of org) [Source 3]
- **Layoffs planned (EMEA)**: ~11-13 (30% of Berlin) [Source 4]

## Valuation and investors

- **Series B valuation**: $560M post-money [Source 1]
- **Series B repriced from**: $720M target [Source 2]
- **Lead investor**: Lightning Capital [Source 1]
- **Participating investors**: Sequoia Capital, Accel, FedEx Ventures, 3 unnamed [Source 1, Source 5]

## Operational plans

- **International expansion (press release)**: Accelerate into international markets [Source 1]
- **International expansion (memo)**: Pause EMEA, reframe Berlin as "support hub", delay international to 2027 [Source 4]
- **Path to profitability target**: Q4 2026 [Source 4]
- **Runway goal**: 36+ months [Source 4]
- **Cash-flow breakeven trigger**: Q4 2026, then Series C from strength [Source 4]

## Compensation (for reference)

- **Senior engineer compensation**: $215K base + $50K equity vest annually [Source 3]
