# Nimbus Logistics, Inc. — Executive Brief

## How to read this output

This directory contains the deliverables for an executive brief evaluating a follow-on investment in Nimbus Logistics, Inc.

### Primary deliverable

- **`/workspace/brief.md`** — The 1-page executive brief (max 700 words). This is the main deliverable for the investor.

### Supporting files

- **`/workspace/key-facts.md`** — A list of every material fact incorporated into the brief, with source attribution.
- **`/workspace/research/notes.md`** — Working notes from reading the five sources, including tensions and contradictions.
- **`/workspace/research/dead-ends.md`** — (Optional) Ideas considered and abandoned.
- **`/workspace/decisions/adr.md`** — ADR-style records for framing choices (recommendation, structure, handling of discrepancies, etc.).

### Sources

All five sources are included in `/input/repo/sources.md`:
1. Company press release
2. TechCrunch news article
3. Former employee blog post
4. Leaked internal memo
5. SEC Form D filing summary

### Key tensions

The brief synthesizes the optimistic press release with contradictory signals from the other four sources:
- ARR: $42M reported vs. $36-37M run-rate after December churn
- Valuation: $560M reported vs. repriced down from $720M target
- International expansion: "accelerate" vs. "pause EMEA"
- Customer concentration: 1,400 customers vs. top 5 = ~38% of ARR
- Unit economics: growth narrative vs. burn > revenue

### Recommendation

**Pass on follow-on investment, but keep a watchlist position.** The company is executing a painful but necessary pivot to sustainability. If they hit Q4 2026 breakeven target, it's a great story. If not, more dilution. Wait for Q2/Q3 2026 results before committing more capital.
