# Working notes — Nimbus Logistics, Inc.

## Source summary

### Source 1 — Press Release (company-issued)
- $84M Series B led by Lightning Capital, closed Jan 14, 2026
- Post-money valuation: $560M (up from $230M in Series A)
- Total funding: $128M
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400 customers, 187 employees (Oakland, Austin, Berlin)
- Founded 2021 by Mira Patel and Daniel Wong (CTO)
- Investors: Lightning Capital, Sequoia, Accel, FedEx Ventures

### Source 2 — TechCrunch News Article
- Lost two top-5 customers in late 2025:
  - Sundry Brands ($4.2M ARR) — non-renewed Nov 2025, called "strategic mutual decision"
  - Klatch (fast-fashion) — exited Dec 2025, migrated to competitor
- Adjusted ARR after December churn: $36-37M run-rate
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026
- Net retention claimed >110%
- Series B originally meant to close at $720M valuation but repriced down after Sundry non-renewal

### Source 3 — Former Employee Blog Post
- Engineering quality: high, clean architecture
- Customer love: real, mid-market brands depend on platform
- Compensation: competitive ($215K base + $50K equity for senior engineer)
- Burn rate: ~$4M/month all-in vs ~$3.5M/month revenue
- Layoffs: 22 people (11% of org) in Feb 2025, mostly customer success & BD
- Customer concentration: top 5 = ~38% of ARR
- Recommendation: join if senior (interesting work, good equity), avoid if need job security

### Source 4 — Leaked Internal Memo (Feb 28, 2026)
- Path to profitability by Q4 2026
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
- Pause new hires in EMEA, reframe Berlin as "support hub"
- Sunset "Nimbus Lite" tier (~310 customers, $5K-$20K ARR each), 90-day migration notice
- Secured $50M credit facility from Silicon Valley Bridge
- Goal: 36+ months runway, cash-flow breakeven by Q4 2026, then Series C from strength

### Source 5 — SEC Form D Filing
- Filed Jan 22, 2026
- Total offering: $84M
- 7 investors (including Lightning, Sequoia, Accel, FedEx Ventures + 3 unnamed)
- Use of proceeds: "expansion, working capital, general corporate purposes"

## Key tensions / contradictions

1. ARR:
   - Press release: $42M
   - TechCrunch: $36-37M adjusted after December churn
   - Blog: revenue ~$3.5M/month → $42M annualized (matches press release)
   - Memo: implies need to cut costs because revenue < burn

2. Valuation:
   - Press release: $560M
   - TechCrunch: repriced down from $720M target
   - Memo: suggests company is in "runway preservation" mode, not growth-at-all-costs

3. Customer concentration:
   - Press release: 1,400 customers (no mention of concentration)
   - TechCrunch: lost two top-5 customers
   - Blog: top 5 = ~38% of ARR (high concentration)

4. Layoffs:
   - Press release: no mention
   - Blog: 22 layoffs (11%) in Feb 2025
   - Memo: another 11-13 layoffs (30% of Berlin 41) planned for Q2

5. International expansion:
   - Press release: "accelerate our expansion into international markets"
   - Memo: pause EMEA, reframe Berlin as support hub, delay international to 2027

6. Runway:
   - Press release: implies growth-oriented use of proceeds
   - Memo: $50M credit facility is "insurance, not operating capital", goal is 36+ months runway

## Critical facts to include in brief

- ARR: $42M reported, but $36-37M run-rate after December churn (TechCrunch)
- Customer concentration: top 5 = ~38% of ARR (blog), lost two top-5 customers (TechCrunch)
- Burn: ~$4M/month all-in vs ~$3.5M/month revenue (blog)
- Layoffs: 22 in Feb 2025, another ~13 planned (30% of Berlin) (blog + memo)
- International pivot: from "accelerate expansion" to "pause EMEA" (press release vs memo)
- Runway: $50M credit facility + current burn → ~36 months (memo)
- Valuation: $560M reported, repriced down from $720M target (TechCrunch)

## Recommendation framing

The company is in a "runway preservation" mode, not growth-at-all-costs. The $84M raise was not a clean win — it was repriced down, and the company is already cutting costs aggressively.

The good:
- Engineering quality is high (blog)
- Product is loved by customers (blog)
- Founders are credible (blog, press release)
- $50M credit facility extends runway significantly (memo)

The bad:
- High customer concentration (blog)
- Recent churn of top customers (TechCrunch)
- Negative unit economics (burn > revenue) (blog)
- Layoffs (blog + memo)

The investment case now is not about growth — it's about whether the company can achieve cash-flow breakeven by Q4 2026. If they do, Series C from strength. If not, more dilution.

Stance: **Pass on follow-on, but keep a watchlist position.** The company is executing a painful but necessary pivot to sustainability. If they hit Q4 2026 breakeven target, it's a great story. But the current run-rate ARR ($36-37M) and negative unit economics suggest the path to breakeven is narrow. Need to see Q2/Q3 2026 results before committing more capital.
