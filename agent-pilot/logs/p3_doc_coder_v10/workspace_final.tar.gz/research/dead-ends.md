# Dead ends — Nimbus Logistics, Inc.

## Ideas considered and abandoned

### 1. "More diligence needed" recommendation
- **Considered**: Given the contradictions in the sources, is "more diligence needed" the right stance?
- **Abandoned**: The data is sufficient to form a clear stance. "More diligence needed" is a cop-out when the evidence already suggests caution. The investor can make a pass decision now and revisit based on Q2/Q3 results.

### 2. "Strong buy" recommendation based on engineering quality
- **Considered**: The blog post is very positive about the engineering work and product-market fit.
- **Abandoned**: Engineering quality is a strength, but not a substitute for unit economics. The company is burning cash and losing customers. A great engineering team with negative unit economics is not a good investment.

### 3. "Upside play" recommendation based on $50M credit facility
- **Considered**: The $50M credit facility is a big number — is it a sign of strength?
- **Abandoned**: The memo explicitly calls it "insurance, not operating capital" [Source 4]. It's a sign of preparedness, not growth momentum. The company is cutting costs, not investing in growth.

### 4. "Net retention >110%" as a positive signal
- **Considered**: The CEO claims net retention is above 110% [Source 2]. Is that a positive signal?
- **Abandoned**: The claim is uncorroborated and contradicted by the loss of two top customers. High net retention is possible even with churn if new logos are strong, but the company's own data (top 5 = ~38% of ARR) suggests high concentration risk.

### 5. "International expansion" as a growth driver
- **Considered**: The press release says "accelerate our expansion into international markets" [Source 1]. Is that a growth driver?
- **Abandoned**: The leaked memo contradicts this, saying "pause EMEA" and "delay international to 2027" [Source 4]. The memo is dated after the press release and reflects current strategy, not aspirational goals.

### 6. "Founders are credible" as a reason to invest
- **Considered**: Mira Patel and Daniel Wong are credible founders [Source 1, Source 3]. Is that a reason to invest?
- **Abandoned**: Founders are important, but not a substitute for unit economics. The company is burning cash and losing customers. Credible founders with negative unit economics are not a good investment.

### 7. "Total funding $128M" as a sign of strength
- **Considered**: $128M total funding is a big number. Is that a sign of strength?
- **Abandoned**: Total funding is a vanity metric. What matters is runway and path to profitability. The company is burning cash and cutting costs, which suggests the $128M is not enough.

### 8. "1,400 customers" as a sign of strength
- **Considered**: 1,400 customers is a big number. Is that a sign of strength?
- **Abandoned**: Customer count is a vanity metric. What matters is concentration and churn. The top 5 = ~38% of ARR, and two top customers were lost in late 2025.

### 9. "3 new $1M+ ARR contracts signed in Q1" as a sign of strength
- **Considered**: 3 new $1M+ ARR contracts signed in Q1 is a big number. Is that a sign of strength?
- **Abandoned**: The claim is uncorroborated and may be optimistic. The company is cutting costs and losing customers, which suggests the Q1 wins may not be enough to offset the Q4 churn.

### 10. "Series B led by Lightning Capital" as a sign of strength
- **Considered**: Lightning Capital is a big name. Is that a sign of strength?
- **Abandoned**: The Series B was repriced down from $720M to $560M, which suggests the lead investor was not confident in the original valuation. A big-name lead investor does not guarantee success.
