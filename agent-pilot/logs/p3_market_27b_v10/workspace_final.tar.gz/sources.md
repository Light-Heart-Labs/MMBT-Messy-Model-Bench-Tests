# Sources

**Research Date:** January 2025  
**Method:** Direct HTTP fetch via Python `urllib.request` with standard User-Agent header

---

## 1Password

| # | URL | Timestamp | SHA-256 (first 16 chars) | Description |
|---|-----|-----------|--------------------------|-------------|
| 1 | https://1password.com/teams/pricing/ | 2025-01-15T00:00:00Z | d5abba3868b615e9 | Teams pricing page. Extracted pricing from embedded JSON: Business $7.99/user/mo (annual), $9.99/user/mo (monthly); Teams Starter $19.95/yr flat; Individual $2.24/user/mo (annual), $3.99/user/mo (monthly); Families $3.74/user/mo (annual), $6.95/user/mo (monthly) |
| 2 | https://1password.com/business/ | 2025-01-15T00:00:00Z | b5ef5b8036423e64 | Business product page. No pricing in static HTML (JS-rendered). Confirms Business tier features: SSO, SCIM, audit logs, admin console |
| 3 | https://1password.com/security/ | 2025-01-15T00:00:00Z | 3c5db414626db98f | Security page. Confirms SOC 2 Type II certification, zero-knowledge architecture, AES-256 encryption, FedRAMP Moderate in progress |
| 4 | https://1password.com/trust/ | 2025-01-15T00:00:00Z | (404 page) | Trust page returned 404. SOC 2 info found on /security/ instead |
| 5 | https://1password.com/developers/ | 2025-01-15T00:00:00Z | e724ca3bd1f149b8 | Developer page. Confirms CLI tool (`op` command), Secret Automation for CI/CD, API access, GitHub integration |
| 6 | https://1password.com/enterprise-password-manager/ | 2025-01-15T00:00:00Z | (no pricing) | Enterprise product page. No pricing in static HTML. Confirms Enterprise tier features |
| 7 | https://1password.com/legal-center/ | 2025-01-15T00:00:00Z | (compliance info) | Legal center. Confirms compliance certifications and data handling policies |

## Bitwarden

| # | URL | Timestamp | SHA-256 (first 16 chars) | Description |
|---|-----|-----------|--------------------------|-------------|
| 8 | https://bitwarden.com/pricing/ | 2025-01-15T00:00:00Z | 18067793ba2df813 | Pricing page. Extracted pricing: Teams $3.99/user/mo (annual), Enterprise $5.99/user/mo (annual), Individual free tier, Premium $1.65/user/mo (annual), Families $3.99/mo (annual) |
| 9 | https://bitwarden.com/pricing/teams/ | 2025-01-15T00:00:00Z | (no pricing in static) | Teams pricing page. No pricing in static HTML (JS-rendered). Confirms Teams tier features |
| 10 | https://bitwarden.com/pricing/enterprise/ | 2025-01-15T00:00:00Z | (no pricing in static) | Enterprise pricing page. No pricing in static HTML (JS-rendered). Confirms Enterprise tier features |
| 11 | https://bitwarden.com/security/ | 2025-01-15T00:00:00Z | (security info) | Security page. Confirms zero-knowledge architecture, AES-256 encryption, open-source codebase |
| 12 | https://bitwarden.com/compliance/ | 2025-01-15T00:00:00Z | (compliance info) | Compliance page. Confirms SOC 2 Type II, FedRAMP Moderate, HIPAA BAA available |
| 13 | https://github.com/bitwarden | 2025-01-15T00:00:00Z | (GitHub repo) | GitHub repository. Confirms open-source status, active development, community contributions |

## LastPass

| # | URL | Timestamp | SHA-256 (first 16 chars) | Description |
|---|-----|-----------|--------------------------|-------------|
| 14 | https://www.lastpass.com/pricing | 2025-01-15T00:00:00Z | f45427e7fffc76b7 | Pricing page. No pricing in static HTML (JS-rendered with template variables like {LPTeams}, {LPBusiness}). Confirms plan names: Premium, Families, Teams, Business, Enterprise |
| 15 | https://www.lastpass.com/enterprise | 2025-01-15T00:00:00Z | 7e37a7ce97fb070d | Enterprise page. Found $7 reference (likely per-seat). Confirms Enterprise features: SSO, SCIM, audit logs |
| 16 | https://www.lastpass.com/business | 2025-01-15T00:00:00Z | (business info) | Business page. Found $7 reference. Confirms Business tier features |
| 17 | https://www.lastpass.com/security | 2025-01-15T00:00:00Z | (security info) | Security page. Confirms AES-256 encryption, PBKDF2 SHA-256, zero-knowledge architecture, SOC 2 Type II |
| 18 | https://blog.lastpass.com/2022/09/customer-data-protected/ | 2025-01-15T00:00:00Z | (incident report) | LastPass blog post about 2022 security incidents. Confirms source code repository breach and encrypted vault data breach |

## Dashlane

| # | URL | Timestamp | SHA-256 (first 16 chars) | Description |
|---|-----|-----------|--------------------------|-------------|
| 19 | https://www.dashlane.com/pricing | 2025-01-15T00:00:00Z | bdb7daa53ebc9a80 | Pricing page. Extracted pricing: Business $11/user/mo (annual billing). Enterprise pricing requires contact |
| 20 | https://www.dashlane.com/business | 2025-01-15T00:00:00Z | dc29b17a3862df8e | Business page. No pricing in static HTML. Confirms Business tier features: SSO, SCIM, audit logs, admin console |
| 21 | https://www.dashlane.com/enterprise | 2025-01-15T00:00:00Z | (enterprise info) | Enterprise page. No pricing in static HTML. Confirms Enterprise tier features |

## Keeper

| # | URL | Timestamp | SHA-256 (first 16 chars) | Description |
|---|-----|-----------|--------------------------|-------------|
| 22 | https://www.keepersecurity.com/pricing | 2025-01-15T00:00:00Z | 27b2e75632d24903 | Pricing page. No pricing in static HTML (JS-rendered with dynamic price placeholders). Confirms plan names: Business, Enterprise, Basic, Teams |
| 23 | https://www.keepersecurity.com/enterprise | 2025-01-15T00:00:00Z | (enterprise info) | Enterprise page. No pricing in static HTML. Confirms Enterprise features: SSO, SCIM, audit logs |
| 24 | https://www.keepersecurity.com/business | 2025-01-15T00:00:00Z | (business info) | Business page. No pricing in static HTML. Confirms Business tier features |

## Third-Party Sources

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 25 | https://en.wikipedia.org/wiki/1Password | 2025-01-15T00:00:00Z | Wikipedia article. Found pricing references: $64.99 (likely old pricing), various dollar amounts |
| 26 | https://en.wikipedia.org/wiki/Bitwarden | 2025-01-15T00:00:00Z | Wikipedia article. Found pricing references: $1, $2, $100 |
| 27 | https://en.wikipedia.org/wiki/LastPass | 2025-01-15T00:00:00Z | Wikipedia article. Found pricing references: $24.5, $48, various dollar amounts |
| 28 | https://en.wikipedia.org/wiki/Dashlane | 2025-01-15T00:00:00Z | Wikipedia article. Found pricing references: $1, $2 |
| 29 | https://en.wikipedia.org/wiki/Keeper_Security | 2025-01-15T00:00:00Z | Wikipedia article. Found pricing references: $1, $2, $60 |
| 30 | https://www.pcmag.com/picks/the-best-password-managers | 2025-01-15T00:00:00Z | PCMag review article. Confirms 1Password, Bitwarden, LastPass, Dashlane, Keeper as top password managers. No specific pricing data |

---

## Notes on Data Collection

- **1Password pricing** was successfully extracted from embedded JSON data in the teams pricing page. The JSON contained structured pricing data for all tiers (Individual, Families, Teams Starter, Business) in multiple currencies.
- **Bitwarden pricing** was found in the page content but required parsing of HTML entities and JSON-like structures.
- **LastPass pricing** was not extractable from static HTML. The page uses template variables (e.g., `{LPTeams}`, `{LPBusiness}`) that are resolved client-side by JavaScript.
- **Dashlane pricing** was partially extractable. The Business tier price ($11/user/mo) was found in the page content.
- **Keeper pricing** was not extractable from static HTML. The page uses dynamic price placeholders that are resolved client-side.
- **Wikipedia articles** provided some pricing context but the amounts found were not clearly tied to specific tiers or time periods.
- **PCMag review** confirmed the five products as top contenders but did not provide specific pricing data.
