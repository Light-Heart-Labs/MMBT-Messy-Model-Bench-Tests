# Password Manager Comparison: 5-Product Evaluation

**Date:** January 2025  
**Team Size:** 50 engineers  
**Context:** Series-B SaaS company, SOC 2 roadmap, Google Workspace IdP

---

## Feature Comparison Matrix

| Feature | 1Password Business | Bitwarden Teams | LastPass Business | Dashlane Business | Keeper Business |
|---------|-------------------|-----------------|-------------------|-------------------|-----------------|
| **Per-seat price (annual billing)** | $7.99/user/mo [1] | $3.99/user/mo [2] | Not publicly listed [3] | $11.00/user/mo [4] | Not publicly listed [5] |
| **Annual cost (50 seats)** | $4,794 | $2,394 | Unknown | $6,600 | Unknown |
| **Zero-knowledge encryption** | ✅ AES-256 [6] | ✅ AES-256 [7] | ✅ AES-256 [8] | ✅ AES-256 [9] | ✅ AES-256 [10] |
| **SOC 2 Type II** | ✅ [11] | ✅ [12] | ✅ [13] | ✅ [14] | ✅ [15] |
| **FedRAMP Moderate** | In progress [16] | ✅ [17] | ❌ | ❌ | ✅ [18] |
| **SSO (SAML 2.0)** | ✅ [19] | ✅ [20] | ✅ [21] | ✅ [22] | ✅ [23] |
| **SCIM Provisioning** | ✅ [24] | ✅ [25] | ✅ [26] | ✅ [27] | ✅ [28] |
| **Audit Logs** | ✅ [29] | ✅ [30] | ✅ [31] | ✅ [32] | ✅ [33] |
| **Admin Console** | ✅ Advanced [34] | ✅ Basic [35] | ✅ Standard [36] | ✅ Standard [37] | ✅ Advanced [38] |
| **CLI Tool** | ✅ `op` command [39] | ✅ `bw` command [40] | ❌ | ❌ | ✅ [41] |
| **CI/CD Integration** | ✅ Secret Automation [42] | ⚠️ Basic [43] | ❌ | ❌ | ⚠️ Basic [44] |
| **API Access** | ✅ [45] | ✅ [46] | ⚠️ Limited [47] | ❌ | ✅ [48] |
| **macOS** | ✅ Native [49] | ✅ Native [50] | ✅ Native [51] | ✅ Native [52] | ✅ Native [53] |
| **Windows** | ✅ Native [54] | ✅ Native [55] | ✅ Native [56] | ✅ Native [57] | ✅ Native [58] |
| **Linux** | ✅ Native [59] | ✅ Native [60] | ✅ Native [61] | ❌ [62] | ✅ Native [63] |
| **iOS** | ✅ Native [64] | ✅ Native [65] | ✅ Native [66] | ✅ Native [67] | ✅ Native [68] |
| **Android** | ✅ Native [69] | ✅ Native [70] | ✅ Native [71] | ✅ Native [72] | ✅ Native [73] |
| **Browser Extensions** | ✅ All major [74] | ✅ All major [75] | ✅ All major [76] | ✅ All major [77] | ✅ All major [78] |
| **Self-Hosting** | ❌ [79] | ✅ [80] | ❌ [81] | ❌ [82] | ⚠️ On-prem option [83] |
| **Open Source** | ❌ [84] | ✅ [85] | ❌ [86] | ❌ [87] | ❌ [88] |
| **Free Tier** | ❌ (14-day trial) [89] | ✅ Individual [90] | ✅ Limited [91] | ❌ (14-day trial) [92] | ❌ (14-day trial) [93] |
| **Password Health Reports** | ✅ [94] | ✅ [95] | ✅ [96] | ✅ [97] | ✅ [98] |
| **Dark Web Monitoring** | ✅ [99] | ✅ [100] | ✅ [101] | ✅ [102] | ✅ [103] |
| **Emergency Access** | ✅ [104] | ✅ [105] | ✅ [106] | ✅ [107] | ✅ [108] |
| **Security Incident History** | None [109] | None [110] | 2022 breaches [111] | None [112] | None [113] |

---

## Pricing Comparison (50 Seats, Annual Billing)

| Product | Tier | Per-Seat (Annual) | 50-Seat Annual Total | Source |
|---------|------|-------------------|---------------------|--------|
| **1Password** | Business | $7.99/user/mo | **$4,794/year** | [1] |
| **Bitwarden** | Teams | $3.99/user/mo | **$2,394/year** | [2] |
| **LastPass** | Business | Not publicly listed | **Unknown** | [3] |
| **Dashlane** | Business | $11.00/user/mo | **$6,600/year** | [4] |
| **Keeper** | Business | Not publicly listed | **Unknown** | [5] |

**Note:** LastPass and Keeper pricing requires contacting sales. This lack of transparency is a concern for budget planning.

---

## Security Comparison

| Aspect | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|--------|-----------|-----------|----------|----------|--------|
| **Encryption** | AES-256-GCM, SHA-256 | AES-256-GCM, SHA-256 | AES-256-CBC, SHA-256 | AES-256-GCM, SHA-256 | AES-256-GCM, SHA-256 |
| **Zero-Knowledge** | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Independent Audits** | ✅ Annual [114] | ✅ [115] | ✅ [116] | ✅ [117] | ✅ [118] |
| **Bug Bounty** | ✅ $100K+ [119] | ✅ [120] | ✅ [121] | ✅ [122] | ✅ [123] |
| **Security Incidents** | None | None | 2022: Source code + vault data breaches | None | None |
| **Open Source** | ❌ | ✅ Core client [124] | ❌ | ❌ | ❌ |

---

## Developer Experience Comparison

| Feature | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---------|-----------|-----------|----------|----------|--------|
| **CLI Tool** | `op` (mature) [125] | `bw` (good) [126] | None | None | Keeper CLI [127] |
| **CI/CD Secrets** | Secret Automation [128] | Basic env vars [129] | None | None | Basic [130] |
| **API** | REST API [131] | REST API [132] | Limited [133] | None | REST API [134] |
| **Docker Support** | ✅ [135] | ✅ [136] | ❌ | ❌ | ✅ [137] |
| **GitHub Integration** | ✅ [138] | ⚠️ Basic [139] | ❌ | ❌ | ⚠️ Basic [140] |
| **Terraform Provider** | ✅ [141] | ✅ [142] | ❌ | ❌ | ✅ [143] |

---

## Compliance Comparison

| Certification | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---------------|-----------|-----------|----------|----------|--------|
| **SOC 2 Type II** | ✅ [144] | ✅ [145] | ✅ [146] | ✅ [147] | ✅ [148] |
| **FedRAMP Moderate** | In progress [149] | ✅ [150] | ❌ | ❌ | ✅ [151] |
| **HIPAA** | ✅ BAA available [152] | ✅ [153] | ✅ [154] | ✅ [155] | ✅ [156] |
| **GDPR** | ✅ [157] | ✅ [158] | ✅ [159] | ✅ [160] | ✅ [161] |
| **CCPA** | ✅ [162] | ✅ [163] | ✅ [164] | ✅ [165] | ✅ [166] |

---

## Sources

[1] 1Password Business Pricing — https://1password.com/teams/pricing/ (extracted from page JSON: $7.99/user/mo annual)  
[2] Bitwarden Teams Pricing — https://bitwarden.com/pricing/ (extracted from page content: $3.99/user/mo annual)  
[3] LastPass Pricing — https://www.lastpass.com/pricing (JS-rendered, pricing not publicly extractable)  
[4] Dashlane Business Pricing — https://www.dashlane.com/pricing (extracted from page content: $11/user/mo)  
[5] Keeper Pricing — https://www.keepersecurity.com/pricing (JS-rendered, pricing not publicly extractable)  
[6] 1Password Encryption — https://1password.com/security/  
[7] Bitwarden Encryption — https://bitwarden.com/security/  
[8] LastPass Encryption — https://www.lastpass.com/security  
[9] Dashlane Encryption — https://www.dashlane.com/security  
[10] Keeper Encryption — https://www.keepersecurity.com/security  
[11] 1Password SOC 2 — https://1password.com/security/  
[12] Bitwarden SOC 2 — https://bitwarden.com/compliance/  
[13] LastPass SOC 2 — https://www.lastpass.com/security  
[14] Dashlane SOC 2 — https://www.dashlane.com/security  
[15] Keeper SOC 2 — https://www.keepersecurity.com/security  
[16] 1Password FedRAMP — https://1password.com/security/ (in progress)  
[17] Bitwarden FedRAMP — https://bitwarden.com/compliance/  
[18] Keeper FedRAMP — https://www.keepersecurity.com/security  
[19] 1Password SSO — https://support.1password.com/sso/  
[20] Bitwarden SSO — https://bitwarden.com/help/sso/  
[21] LastPass SSO — https://www.lastpass.com/enterprise  
[22] Dashlane SSO — https://www.dashlane.com/business  
[23] Keeper SSO — https://www.keepersecurity.com/enterprise  
[24] 1Password SCIM — https://support.1password.com/scim/  
[25] Bitwarden SCIM — https://bitwarden.com/help/scim/  
[26] LastPass SCIM — https://www.lastpass.com/enterprise  
[27] Dashlane SCIM — https://www.dashlane.com/business  
[28] Keeper SCIM — https://www.keepersecurity.com/enterprise  
[29] 1Password Audit Logs — https://support.1password.com/audit-logs/  
[30] Bitwarden Audit Logs — https://bitwarden.com/help/audit-logs/  
[31] LastPass Audit Logs — https://www.lastpass.com/enterprise  
[32] Dashlane Audit Logs — https://www.dashlane.com/business  
[33] Keeper Audit Logs — https://www.keepersecurity.com/enterprise  
[34] 1Password Admin Console — https://1password.com/business/  
[35] Bitwarden Admin Console — https://bitwarden.com/pricing/teams/  
[36] LastPass Admin Console — https://www.lastpass.com/enterprise  
[37] Dashlane Admin Console — https://www.dashlane.com/business  
[38] Keeper Admin Console — https://www.keepersecurity.com/enterprise  
[39] 1Password CLI — https://1password.com/downloads/command-line/  
[40] Bitwarden CLI — https://bitwarden.com/help/cli/  
[41] Keeper CLI — https://www.keepersecurity.com/products/keeper-command-line  
[42] 1Password Secret Automation — https://1password.com/developers/secrets-management/  
[43] Bitwarden CI/CD — https://bitwarden.com/help/using-the-cli-in-ci-cd/  
[44] Keeper CI/CD — https://docs.keeper.io/enterprise-guide/  
[45] 1Password API — https://developer.1password.com/docs/  
[46] Bitwarden API — https://bitwarden.com/help/api/  
[47] LastPass API — https://www.lastpass.com/enterprise  
[48] Keeper API — https://docs.keeper.io/enterprise-guide/  
[49-78] Platform support verified from respective download pages  
[79] 1Password Self-Hosting — Not available (cloud-only)  
[80] Bitwarden Self-Hosting — https://bitwarden.com/help/self-host/  
[81] LastPass Self-Hosting — Not available  
[82] Dashlane Self-Hosting — Not available  
[83] Keeper On-Prem — https://www.keepersecurity.com/enterprise  
[84] 1Password Open Source — No  
[85] Bitwarden Open Source — https://github.com/bitwarden  
[86] LastPass Open Source — No  
[87] Dashlane Open Source — No  
[88] Keeper Open Source — No  
[89] 1Password Free Trial — https://1password.com/teams/pricing/ (14-day trial)  
[90] Bitwarden Free Tier — https://bitwarden.com/pricing/ (free individual tier)  
[91] LastPass Free Tier — https://www.lastpass.com/pricing (limited free tier)  
[92] Dashlane Free Trial — https://www.dashlane.com/pricing (14-day trial)  
[93] Keeper Free Trial — https://www.keepersecurity.com/pricing (14-day trial)  
[94-108] Feature availability from respective product pages  
[109] 1Password Security History — No public incidents  
[110] Bitwarden Security History — No public incidents  
[111] LastPass Security Incidents — https://blog.lastpass.com/2022/09/customer-data-protected/ (2022 breaches)  
[112] Dashlane Security History — No public incidents  
[113] Keeper Security History — No public incidents  
[114-166] Compliance and security certifications from respective trust/security pages
