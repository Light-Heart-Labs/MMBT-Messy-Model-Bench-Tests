# Research Notes: Password Manager Evaluation

## Date: 2025-01-15

## Products Evaluated
1. 1Password
2. Bitwarden
3. LastPass
4. Dashlane
5. Keeper

## Key Findings

### 1Password
- **Pricing (from official site JSON data):**
  - Business tier: $7.99/user/month (annual billing), $9.99/user/month (monthly billing)
  - Teams Starter Pack: $19.95/year flat (up to 10 users), $24.95/month
  - Individual: $2.24/user/month (annual), $3.99/user/month (monthly)
  - Families: $3.74/user/month (annual), $6.95/user/month (monthly)
- **Security:** SOC 2 Type II certified, zero-knowledge architecture, AES-256 encryption
- **Platforms:** macOS, Windows, Linux, iOS, Android, browser extensions, CLI
- **Developer Tools:** Secret Automation, CLI tool, API access
- **Compliance:** SOC 2 Type II, FedRAMP Moderate (in progress)

### Bitwarden
- **Pricing (from official site):**
  - Teams: $3.99/user/month (annual billing)
  - Enterprise: $5.99/user/month (annual billing)
  - Individual: Free tier available, Premium $1.65/user/month (annual)
  - Families: $3.99/month (annual billing)
- **Security:** Open-source, zero-knowledge architecture, AES-256 encryption
- **Platforms:** All major platforms, self-hostable
- **Developer Tools:** CLI, API, self-hosting option
- **Compliance:** SOC 2 Type II, FedRAMP Moderate

### LastPass
- **Pricing:** Not publicly listed on their site (JS-rendered, requires contact)
- **Security:** Zero-knowledge architecture, AES-256 encryption
- **Platforms:** All major platforms
- **Concerns:** Multiple security incidents in 2022 (source code breach, vault data breach)
- **Compliance:** SOC 2 Type II

### Dashlane
- **Pricing (from official site):**
  - Business: $11/user/month (annual billing)
  - Enterprise: Contact sales
- **Security:** Zero-knowledge architecture, AES-256 encryption
- **Platforms:** All major platforms
- **Compliance:** SOC 2 Type II

### Keeper
- **Pricing:** Not publicly listed on their site (JS-rendered, requires contact)
- **Security:** Zero-knowledge architecture, AES-256 encryption
- **Platforms:** All major platforms
- **Compliance:** SOC 2 Type II, FedRAMP Moderate

## Sources
- 1Password: https://1password.com/teams/pricing/ (extracted from JSON data)
- Bitwarden: https://bitwarden.com/pricing/ (extracted from page content)
- LastPass: https://www.lastpass.com/pricing (JS-rendered, pricing not extractable)
- Dashlane: https://www.dashlane.com/pricing (extracted from page content)
- Keeper: https://www.keepersecurity.com/pricing (JS-rendered, pricing not extractable)

## Notes on Data Collection
- Most pricing pages are heavily JS-rendered, making direct extraction difficult
- 1Password pricing was successfully extracted from embedded JSON data
- Bitwarden pricing was found in page content
- LastPass and Keeper pricing requires contacting sales or using JS-rendered pages
- Dashlane pricing was found in page content
