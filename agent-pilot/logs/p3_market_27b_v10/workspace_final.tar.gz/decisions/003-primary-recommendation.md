# ADR-003: Selection of 1Password Business as Primary Recommendation

## Status
Accepted

## Context
After evaluating 5 password managers (1Password, Bitwarden, LastPass, Dashlane, Keeper) against our defined criteria, we need to select a primary recommendation and runner-up.

## Decision
**Primary Recommendation:** 1Password Business at $7.99/user/month (annual billing)  
**Runner-Up:** Bitwarden Teams at $3.99/user/month (annual billing)

## Rationale

### Why 1Password Won
1. **Best-in-class security track record** — No public security incidents; independent annual audits; bug bounty program with $100K+ payouts
2. **SOC 2 Type II certified** — Directly supports our SOC 2 compliance roadmap
3. **Superior developer experience** — Native CLI (`op` command), Secret Automation for CI/CD, API access, GitHub integration, Terraform provider
4. **Google Workspace SSO** — SAML 2.0 integration out of the box
5. **Comprehensive admin console** — Audit logs, usage reports, policy enforcement, role-based access control
6. **Full platform coverage** — Including native Linux support (important for engineering team)

### Why Bitwarden is the Runner-Up
- **Significantly cheaper** — $2,394/year vs. $4,794/year for 50 seats (49% cost savings)
- **Open-source** — Code is publicly auditable on GitHub
- **Self-hostable** — Full control over infrastructure
- **SOC 2 Type II and FedRAMP Moderate certified** — Meets compliance requirements

### Why Bitwarden Didn't Win
- Admin console is less polished than 1Password's
- Developer tooling (CI/CD integration, secrets management) is less mature
- SOC 2 certification is newer; compliance documentation is less comprehensive

### Why Other Products Were Rejected
- **LastPass:** Multiple security incidents in 2022 (source code breach, vault data breach)
- **Dashlane:** Higher pricing ($11/user/mo = $6,600/year) without clear feature advantage
- **Keeper:** No transparent pricing (requires contacting sales); less polished developer experience

## Consequences
- Annual budget of $4,794 for 50 seats (vs. $2,394 for Bitwarden)
- 90-day implementation timeline with SSO configuration, policy setup, and team onboarding
- No self-hosting option (cloud-only, but zero-knowledge encryption mitigates this concern)
