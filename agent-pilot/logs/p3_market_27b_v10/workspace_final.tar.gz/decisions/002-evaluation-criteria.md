# ADR-002: Evaluation Criteria for Password Manager Selection

## Status
Accepted

## Context
We need to evaluate 5 password managers for a 50-person engineering team at a Series-B SaaS company. The team currently uses shadow-IT password storage (browser, sticky notes, Slack DMs). The CTO wants this fixed in 90 days.

## Decision
We established the following weighted criteria for evaluation:

### High Weight (Must-Have)
1. **Security Architecture** — Zero-knowledge encryption, AES-256, independent audits
2. **Compliance Certifications** — SOC 2 Type II required for our SOC 2 roadmap
3. **SSO Integration** — Must integrate with Google Workspace via SAML 2.0
4. **Admin Console & Audit Logs** — Usage reports, policy enforcement, audit trails
5. **Vendor Stability & Incident History** — No major security breaches

### Medium Weight (Should-Have)
6. **Developer Tooling** — CLI access, CI/CD integration, secrets management
7. **Platform Coverage** — macOS, Windows, Linux, iOS, Android, browser extensions
8. **Pricing Transparency** — Per-seat pricing publicly listed and predictable
9. **Migration & Onboarding** — Easy import from browser password managers
10. **Mobile + Desktop Coverage** — Native apps on all platforms

## Rationale
- **SOC 2 Type II** is non-negotiable because our company is pursuing SOC 2 certification and customers will ask about our tooling.
- **SSO with Google Workspace** is required because we use Google Workspace as our IdP and want seamless authentication.
- **Developer tooling** is weighted medium (not high) because while engineers value CLI/CI/CD integration, the primary use case is password storage and management.
- **Pricing transparency** is medium because while we prefer transparent pricing, we're willing to contact sales if needed.
- **Vendor stability** is high because a password manager breach would be catastrophic for our team.

## Consequences
- Products without SOC 2 Type II certification are disqualified.
- Products without SSO support are disqualified.
- Products with major security incidents (e.g., LastPass 2022 breaches) are heavily penalized.
- Products without transparent pricing (LastPass, Keeper) are penalized for budget planning uncertainty.
