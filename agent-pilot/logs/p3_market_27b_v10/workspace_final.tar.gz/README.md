# Password Manager Evaluation — Output Guide

## How to Read This Output

This directory contains the complete research and recommendation for standardizing a password manager across a 50-person engineering team at a Series-B SaaS company.

### Files

| File | Description |
|------|-------------|
| `recommendation.md` | **Primary deliverable.** 1-2 page memo with the recommendation (1Password Business), pricing math, runner-up (Bitwarden), and concerns/risks. |
| `comparison.md` | Side-by-side feature/pricing/security comparison of all 5 evaluated products (1Password, Bitwarden, LastPass, Dashlane, Keeper). |
| `sources.md` | Every URL fetched during research, with timestamps, SHA-256 hashes (first 16 chars), and descriptions of what was extracted. |
| `research/notes.md` | Working notes from the research process, including key findings and data collection notes. |
| `decisions/001-select-5-products.md` | ADR documenting which 5 products were selected and why. |
| `decisions/002-evaluation-criteria.md` | ADR documenting the weighted evaluation criteria. |
| `decisions/003-primary-recommendation.md` | ADR documenting the final recommendation and rationale. |

### Quick Start

1. Read `recommendation.md` for the executive summary and final recommendation.
2. Read `comparison.md` for the detailed feature/pricing comparison.
3. Read `sources.md` for the full list of sources and data extraction notes.
4. Read `decisions/` for the ADR-style records of non-obvious calls.

### Key Findings

- **Recommended:** 1Password Business at $7.99/user/month (annual billing) = $4,794/year for 50 seats
- **Runner-up:** Bitwarden Teams at $3.99/user/month (annual billing) = $2,394/year for 50 seats
- **Rejected:** LastPass (security incidents), Dashlane (overpriced), Keeper (no transparent pricing)

### Data Collection Notes

- Most pricing pages are heavily JS-rendered, making direct extraction difficult.
- 1Password pricing was successfully extracted from embedded JSON data.
- Bitwarden pricing was found in page content.
- LastPass and Keeper pricing requires contacting sales or using JS-rendered pages.
- Dashlane pricing was found in page content.
- All factual claims are cited with source URLs in the recommendation and comparison documents.
