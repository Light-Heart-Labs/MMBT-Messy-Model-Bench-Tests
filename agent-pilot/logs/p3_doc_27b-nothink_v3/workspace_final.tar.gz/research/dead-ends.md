# Dead Ends — Ideas Considered and Abandoned

## Considered but not included in brief

1. **Detailed engineering assessment**: The blog post praises the carrier-orchestration layer and CTO Daniel Wong. Interesting for a technical due diligence memo, but not material for an investment decision brief focused on financial/strategic risk.

2. **Compensation benchmarking**: The blog post's salary data ($215K base + $50K equity) is useful for recruiting context but irrelevant to investment thesis.

3. **FedEx Ventures strategic value**: The press release highlights FedEx as a strategic investor. While potentially valuable for distribution, the brief doesn't have enough information to assess the depth of this relationship, so it's mentioned but not over-weighted.

4. **AI-driven inventory optimization**: Press release mentions this as a use of proceeds. No other source discusses it, so it's noted but not a focus — it's a forward-looking claim without independent corroboration.

5. **Specific customer names (Maevia, Truant Coffee, Brick & Cobble)**: Named in press release but no other information about them. Not material to the investment thesis.

6. **Three additional unnamed investors in Form D**: The Form D shows 7 investors total but only names 4. The identity of the other 3 is unknown and not material.

7. **Berlin office specifics beyond headcount reduction**: The memo gives headcount numbers (41 → 28-30) but no revenue attribution to Berlin. Without knowing how much ARR the Berlin team was generating, the impact is assessed qualitatively.

8. **Net retention claim of 110%**: CEO told TechCrunch this figure. It's noted as a claim but not independently verified. The churn of two top-5 customers makes this claim worth skepticism.
