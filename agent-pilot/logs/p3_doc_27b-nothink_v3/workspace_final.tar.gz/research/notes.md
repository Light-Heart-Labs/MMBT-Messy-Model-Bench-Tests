# Working Notes — Nimbus Logistics Source Analysis

## Source-by-Source Summary

### Source 1: Press Release (2026-01-14)
- $84M Series B, led by Lightning Capital
- Post-money valuation: $560M (up from $230M Series A in 2023)
- Total funding: $128M across all rounds
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400+ e-commerce brands on platform
- 187 employees across Oakland, Austin, Berlin
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (strategic)
- Use of proceeds: international expansion, AI-driven inventory optimization
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO)

### Source 2: TechCrunch (2026-01-15)
- Lost two top-5 customers in late 2025
- Sundry Brands: $4.2M ARR, did not renew in November
- Klatch (fast-fashion): exited in December, migrated to competitor
- Adjusted ARR after churn: $36-37M (vs. $42M in press release)
- Series B was originally priced at $720M, repriced down to $560M after Sundry news
- CEO claims 3 new $1M+ ARR contracts signed in Q1
- Net retention claimed above 110%

### Source 3: Former Employee Blog (2026-02-22)
- 14 months tenure, left recently
- Engineering quality praised; CTO Daniel Wong is strong
- Burn rate: ~$4M/month (mid-2025), revenue ~$3.5M/month → net burn ~$500K/month
- 22 layoffs in Feb 2025 (~11% of org), mostly customer success and BD — not publicly announced
- Top 5 customers = ~38% of ARR (customer concentration risk)
- Sundry loss was expected internally
- Compensation competitive: $215K base + $50K equity vest annually for senior engineers

### Source 4: Leaked Internal Memo (2026-03-05)
- CEO memo dated Feb 28, 2026
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
- International expansion deferred to 2027
- Berlin reframed as "support hub"
- Nimbus Lite tier being sunset (~310 customers, $5K-$20K ARR each)
- $50M credit facility from Silicon Valley Bridge secured
- Runway: 24+ months at current burn, extended to 36+ months with restructuring
- Target: operating-cash-flow breakeven by Q4 2026
- Series C conversations planned from "position of strength"

### Source 5: SEC Form D (filed 2026-01-22)
- Confirms $84M total offering, all sold
- 7 investors total
- Security type: Series B Preferred Equity
- Use of proceeds: "expansion, working capital, general corporate purposes"
- No executive compensation disclosed in connection with offering

## Key Tensions Identified

1. **ARR discrepancy**: $42M (press release) vs. $36-37M adjusted for churn (TechCrunch sources)
2. **Valuation repricing**: Originally $720M, came down to $560M after customer losses
3. **Burn vs. revenue**: $4M/month burn vs. ~$3.5M/month revenue (ex-employee)
4. **Hidden layoffs**: 22 people cut in Feb 2025, not publicly announced
5. **International pivot**: Press release touts international expansion; internal memo defers it to 2027
6. **Customer concentration**: Top 5 = 38% of ARR; lost 2 of top 5 in late 2025
7. **Product tier elimination**: Nimbus Lite sunset affects ~310 small customers
8. **Credit facility**: $50M from Silicon Valley Bridge — "insurance, not operating capital"

## Source Quality Assessment

- **Press Release**: Company narrative, optimistic framing
- **TechCrunch**: Journalistic, cites unnamed sources, some claims confirmed by company
- **Blog Post**: One ex-employee's perspective, but specific numbers and details
- **Internal Memo**: Leaked, attributed to CEO, highly specific operational details
- **SEC Form D**: Regulatory filing, factual but limited scope
