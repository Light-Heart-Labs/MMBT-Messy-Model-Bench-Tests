# ADR-001: Recommendation Stance — "Cautious Pass"

## Context
The brief requires a clear stance: follow-on investment, pass, or more diligence needed.

## Decision
**"Cautious Pass"** — recommend passing on a follow-on investment at this time, with the caveat that a deeper diligence process could change the recommendation.

## Rationale
- The company has real product-market fit (strong engineering, genuine customer love per ex-employee [Source 3])
- But the financial picture is materially worse than the press release suggests: adjusted ARR is $36-37M not $42M [Source 2], burn exceeds revenue [Source 3], and the valuation was repriced down from $720M to $560M [Source 2]
- The internal restructuring memo [Source 4] reveals the company is in damage-control mode: cutting international, killing a product tier, and relying on a credit facility
- Customer concentration (top 5 = 38% of ARR [Source 3]) combined with losing 2 of those 5 in late 2025 [Source 2] is a structural risk
- The company hid layoffs from the public [Source 3], suggesting governance concerns

## Alternatives Considered
- **"More diligence needed"**: This would be the most honest answer, but the brief requires a clear stance. The signals are negative enough that "pass" is the appropriate default position.
- **"Follow-on"**: Would require ignoring the churn, burn, and restructuring signals. Not defensible.

## Caveats That Would Change the Recommendation
- Evidence that the 3 new $1M+ contracts [Source 2] are on track and larger than expected
- Confirmation that the restructuring plan is working (breakeven on track for Q4 2026 [Source 4])
- A lower entry valuation in a down-round scenario
