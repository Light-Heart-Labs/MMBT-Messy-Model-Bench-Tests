# ADR-002: ARR Figure to Lead With

## Context
The company reports $42M ARR [Source 1]. TechCrunch sources say adjusted ARR is $36-37M after accounting for December churn [Source 2]. Which figure should the brief lead with?

## Decision
Lead with the **adjusted $36-37M figure**, while noting the company's stated $42M.

## Rationale
- The $42M figure includes contracts that have already terminated (Sundry Brands at $4.2M and Klatch) [Source 2]
- An investor evaluating a follow-on needs to know the current run-rate, not the historical snapshot
- The gap between $42M and $36-37M is itself a material fact that signals the quality of the company's reporting

## Alternatives Considered
- Leading with $42M and noting the adjustment: This would give the company's number undue prominence and require the reader to do the math.
- Using a midpoint ($39M): This would obscure the tension between sources rather than highlight it.
