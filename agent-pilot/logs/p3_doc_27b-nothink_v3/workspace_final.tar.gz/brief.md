# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Recommendation

**Date:** 2026-03-10
**To:** Investment Committee
**From:** Due Diligence Team
**Recommendation:** **PASS** — do not commit follow-on capital at this time

---

## Bottom Line

Nimbus Logistics has genuine product-market fit in mid-market e-commerce logistics, but the company is in active restructuring mode with material discrepancies between its public narrative and internal reality. We recommend passing on a follow-on investment until the next reporting cycle demonstrates that the restructuring plan is working and customer concentration risk has been meaningfully reduced.

---

## The Financial Picture: Worse Than Advertised

Nimbus closed an $84M Series B at a $560M post-money valuation on January 14, 2026 [Source 1, Source 5]. The company reports $42M in ARR as of Q4 2025, up from $11M a year prior [Source 1]. However, two sources familiar with the company's finances report that adjusted for December churn — the non-renewal of Sundry Brands ($4.2M ARR) and the exit of Klatch — current run-rate ARR is closer to $36–37M [Source 2]. The company confirmed the Sundry non-renewal but declined to comment on Klatch [Source 2].

The valuation tells its own story: the round was originally priced at $720M but was repriced down to $560M after the Sundry loss became known to the lead investor in early December [Source 2].

Burn is a concern. According to a former senior engineer, the company was spending approximately $4M/month against roughly $3.5M/month in revenue as of mid-2025, implying a net burn of ~$500K/month [Source 3]. The company has secured a $50M credit facility from Silicon Valley Bridge, which the CEO's internal memo characterizes as "insurance, not operating capital" [Source 4].

---

## Customer Concentration and Churn

The top five customers represent approximately 38% of ARR [Source 3]. Losing two of those five in late 2025 — including the largest contract — is a structural risk, not a one-off event [Source 2]. The former employee notes the Sundry loss "was not a shock to the team," suggesting the concentration problem was known internally for some time [Source 3].

The CEO claims three new $1M+ ARR contracts have been signed in Q1 2026 and that net revenue retention remains above 110% [Source 2]. These claims are unverified and should be treated as management assertions pending confirmation.

---

## The Restructuring: Damage Control, Not Strategy

An internal memo from CEO Mira Patel dated February 28, 2026, outlines a significant pivot [Source 4]:

- **International expansion deferred to 2027** — a direct contradiction of the press release's stated use of proceeds for "expansion into international markets" [Source 1, Source 4]. Berlin headcount will be cut by 30% (41 to 28–30) and reframed as a "support hub" [Source 4].
- **Nimbus Lite tier sunset** — approximately 310 small customers ($5K–$20K ARR each) will be migrated or churned [Source 4].
- **Target: operating-cash-flow breakeven by Q4 2026** [Source 4].

The company also quietly laid off 22 employees (~11% of the org) in February 2025 without public announcement, primarily in customer success and business development [Source 3]. This pattern of non-disclosure is a governance concern.

---

## What's Working

The company is not without merit. The engineering architecture is praised by a former senior engineer as "genuinely good" [Source 3]. Customer relationships at the mid-market level appear authentic [Source 3]. The founding team — CEO Mira Patel and CTO Daniel Wong — are described as credible [Source 3]. FedEx Ventures' participation as a strategic investor [Source 1] could provide distribution value, though the depth of that relationship is unknown.

---

## Recommendation and Caveats

**We recommend passing.** The combination of repriced valuation, hidden churn, customer concentration, undisclosed layoffs, and a restructuring plan that contradicts the company's public narrative creates an unfavorable risk profile for a follow-on investment.

**This recommendation would change if:**
1. The three new $1M+ contracts are confirmed and larger than expected, offsetting the Sundry and Klatch losses.
2. The restructuring plan shows measurable progress toward the Q4 2026 breakeven target.
3. A down-round opportunity emerges at a materially lower valuation, providing adequate margin of safety.

Until then, the prudent course is to watch and wait.
