# Key Facts Incorporated into Brief

## Financial Metrics
| Fact | Value | Source |
|------|-------|--------|
| Series B amount | $84M | [Source 1], [Source 5] |
| Post-money valuation | $560M | [Source 1] |
| Previous valuation (Series A, 2023) | $230M | [Source 1] |
| Total funding raised | $128M | [Source 1] |
| Reported ARR (Q4 2025) | $42M | [Source 1] |
| ARR one year prior | $11M | [Source 1] |
| Adjusted ARR (post-churn) | $36-37M | [Source 2] |
| Monthly burn rate (mid-2025) | ~$4M/month | [Source 3] |
| Monthly revenue (mid-2025) | ~$3.5M/month | [Source 3] |
| Original Series B valuation target | $720M | [Source 2] |
| Credit facility secured | $50M from Silicon Valley Bridge | [Source 4] |

## Customer Metrics
| Fact | Value | Source |
|------|-------|--------|
| Total customers | 1,400+ brands | [Source 1] |
| Top 5 customer concentration | ~38% of ARR | [Source 3] |
| Sundry Brands contract size | $4.2M ARR | [Source 2] |
| Sundry Brands status | Non-renewal, November 2025 | [Source 2] |
| Klatch status | Exited December 2025, migrated to competitor | [Source 2] |
| New contracts signed in Q1 2026 | 3 contracts, $1M+ ARR each | [Source 2] |
| Net revenue retention (claimed) | Above 110% | [Source 2] |
| Nimbus Lite customers being sunset | ~310 customers, $5K-$20K ARR each | [Source 4] |

## Organizational Metrics
| Fact | Value | Source |
|------|-------|--------|
| Total employees | 187 | [Source 1] |
| Offices | Oakland, Austin, Berlin | [Source 1] |
| Layoffs (Feb 2025) | 22 people (~11% of org) | [Source 3] |
| Berlin headcount reduction | 41 → 28-30 by end Q2 2026 | [Source 4] |
| International headcount reduction | 30% | [Source 4] |

## Timeline
| Event | Date | Source |
|-------|------|--------|
| Company founded | 2021 | [Source 1] |
| Series A | 2023 | [Source 1] |
| Layoffs | February 2025 | [Source 3] |
| Sundry non-renewal | November 2025 | [Source 2] |
| Klatch exit | December 2025 | [Source 2] |
| Series B close | January 14, 2026 | [Source 1], [Source 5] |
| TechCrunch article | January 15, 2026 | [Source 2] |
| SEC Form D filed | January 22, 2026 | [Source 5] |
| CEO restructuring memo | February 28, 2026 | [Source 4] |
| Former employee blog post | February 22, 2026 | [Source 3] |
| Memo leaked to The Information | March 5, 2026 | [Source 4] |

## Investor Details
| Fact | Value | Source |
|------|-------|--------|
| Lead investor | Lightning Capital | [Source 1], [Source 5] |
| Participating investors | Sequoia Capital, Accel, FedEx Ventures (strategic), 3 unnamed | [Source 1], [Source 5] |
| Number of investors | 7 | [Source 5] |
| Security type | Series B Preferred Equity | [Source 5] |
| Use of proceeds | "Expansion, working capital, general corporate purposes" | [Source 5] |

## Strategic/Operational
| Fact | Value | Source |
|------|-------|--------|
| International expansion deferred | To 2027 at earliest | [Source 4] |
| Berlin office reframed | "Support hub" not sales/expansion | [Source 4] |
| Target breakeven | Q4 2026 | [Source 4] |
| Runway at current burn | 24+ months | [Source 4] |
| Runway with restructuring | 36+ months | [Source 4] |
| Product/platform | Warehouse management, carrier orchestration, demand forecasting | [Source 1] |
| Named customers | Maevia, Truant Coffee, Brick & Cobble | [Source 1] |
