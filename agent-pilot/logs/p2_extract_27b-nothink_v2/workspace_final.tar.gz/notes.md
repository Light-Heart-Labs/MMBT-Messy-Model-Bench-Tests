# Extraction Notes

## Summary
All 20 fields from the schema were successfully extracted from the press release. No fields were uncertain or missing.

## Field-by-Field Decisions

### company_name
- **Value:** `Veridyne Networks, Inc.`
- **Source:** Dateline and body text use the full legal name "Veridyne Networks, Inc."
- **Decision:** Used the formal legal name as it appears in the press release.

### ticker_symbol
- **Value:** `VRDN`
- **Source:** "(NASDAQ: VRDN)" in the first paragraph.
- **Decision:** Extracted just the symbol, not the exchange prefix.

### fiscal_period
- **Value:** `Q3 FY2026`
- **Source:** Headline "Veridyne Networks Reports Fiscal Q3 2026 Results" and body "third fiscal quarter ended February 28, 2026."
- **Decision:** Used the compact form matching the headline.

### fiscal_period_end_date
- **Value:** `2026-02-28`
- **Source:** "quarter ended February 28, 2026"
- **Decision:** Converted to ISO 8601 format.

### total_revenue_usd_millions
- **Value:** `187.4`
- **Source:** "Total revenue of $187.4 million"
- **Decision:** Direct extraction, already in millions.

### revenue_yoy_growth_pct
- **Value:** `38`
- **Source:** "up 38% year-over-year"
- **Decision:** Integer percent value as stated.

### subscription_revenue_usd_millions
- **Value:** `171.2`
- **Source:** "Subscription revenue of $171.2 million"
- **Decision:** Direct extraction.

### gaap_gross_margin_pct
- **Value:** `76.3`
- **Source:** "GAAP gross margin of 76.3%"
- **Decision:** Direct extraction.

### non_gaap_operating_income_usd_millions
- **Value:** `9.8`
- **Source:** "Non-GAAP operating income of $9.8 million"
- **Decision:** Positive value as it is income (not loss). The prior year was a loss of $4.1M, but current quarter is income.

### total_customers
- **Value:** `4117`
- **Source:** "Total customers grew to 4,117"
- **Decision:** Integer, no commas.

### customers_above_100k_arr
- **Value:** `1082`
- **Source:** "Customers contributing more than $100,000 in annual recurring revenue (ARR) grew to 1,082"
- **Decision:** Integer.

### customers_above_1m_arr
- **Value:** `71`
- **Source:** "Customers contributing more than $1 million in ARR grew to 71"
- **Decision:** Integer.

### net_dollar_retention_pct
- **Value:** `124`
- **Source:** "Net dollar retention rate of 124%"
- **Decision:** Integer percent.

### total_arr_usd_millions
- **Value:** `710`
- **Source:** "Total ARR exceeded $710 million as of quarter-end"
- **Decision:** Used 710 as the stated figure per instructions ("extract the press release's stated figure, not your own back-calculation").

### fte_count_end_of_q3
- **Value:** `1847`
- **Source:** "The Company ended the quarter with 1,847 full-time employees"
- **Decision:** Integer, end-of-quarter count.

### stitchwise_acquisition_total_consideration_usd_millions
- **Value:** `115`
- **Source:** "Total consideration was approximately $115 million"
- **Decision:** Used the stated approximate total of $115M, not the sum of components ($87M cash + stock value).

### stitchwise_close_date
- **Value:** `2026-01-22`
- **Source:** "closed its acquisition of Stitchwise Labs, Inc. ... on January 22, 2026"
- **Decision:** Converted to ISO 8601.

### fy2026_revenue_guidance_low_usd_millions
- **Value:** `722`
- **Source:** "Total revenue: $722-$726 million"
- **Decision:** Low end of the raised guidance range.

### fy2026_revenue_guidance_high_usd_millions
- **Value:** `726`
- **Source:** "Total revenue: $722-$726 million"
- **Decision:** High end of the raised guidance range.

### share_repurchase_authorization_usd_millions
- **Value:** `200`
- **Source:** "share repurchase program of up to $200 million"
- **Decision:** Direct extraction.
