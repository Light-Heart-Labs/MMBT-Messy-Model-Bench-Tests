# An Update on Friday's Service Disruption

Dear Customer,

On Friday, our primary API experienced a disruption lasting approximately 4 hours, from 14:11 UTC to 18:24 UTC. During this time, roughly 11,400 customer accounts were affected, with some requests returning errors.

**What happened:** A configuration update to our authentication service was deployed at 14:09 UTC. The change was intended to adjust request-handling thresholds, but it had an unintended side effect: it caused our system to reject all incoming authentication requests. We identified the issue, reverted the change at 18:18 UTC, and service fully recovered by 18:24 UTC.

**What we're doing differently:**
- We are adding staged rollout for configuration changes, so future updates will be tested on a small subset of traffic before going live.
- We are fixing the underlying code issue that allowed this configuration change to have such a broad effect.
- Our status-page monitoring has been corrected to accurately reflect customer-facing service health.
- We are updating our incident response process so that we acknowledge known service disruptions within 15 minutes, even before we have a full diagnosis.

**SLA credit:** If your account was impacted, you are eligible for service credits under our SLA. To request your credit, please contact your Customer Success Manager or reach out to our support team. We will process all valid credit requests promptly.

We understand that this disruption affected your operations, and we take full responsibility. We are committed to earning back your trust through the improvements outlined above.

If you have questions, please contact your Customer Success Manager or our support team directly.

Sincerely,

The Engineering Team
