# ADR-001: Omission Decisions Per Audience

## Status: Accepted

## Context
The source memo contains information relevant to some audiences but inappropriate for others. This document records the rationale for key omission decisions.

---

## Decision 1: Named Engineer (Marcus) — Omitted from Customer Email and Legal Summary

**Rationale:** The customer email must not blame a named individual per the audience brief. The legal summary must not include named-employee blame. The CEO brief omits the name because it is not material to board-level understanding — the issue is systemic (no canary for config), not individual.

**Source reference:** "someone on the platform team (it was Marcus...)"

---

## Decision 2: "Second Outage in 90 Days" — Included in CEO Brief, Omitted from Customer Email

**Rationale:** The audience brief explicitly requires the second-occurrence framing for the CEO brief (board signal) and explicitly forbids it in the customer email ("that's an internal signal, not a customer-facing one"). The legal summary omits it because it is not relevant to SLA-credit determination.

**Source reference:** "this is the second 4+ hour outage in 2026 (the other was in February with the database storage issue)... second data point in 90 days"

---

## Decision 3: Sarah's Warning — Omitted from All Rewrites

**Rationale:** The "sorry Sarah, you were right" reference is internal candor and an informal apology. It is excluded from the CEO brief (no informal apologies), the customer email (no internal candor about unaddressed warnings), and the legal summary (no informal candor). The underlying fact (the code defect was known) is relevant to the CEO brief's remediation item but the personal reference is not.

**Source reference:** "I personally was told about it last June by Sarah, who left in September; sorry Sarah, you were right"

---

## Decision 4: Technical Root Cause Detail Level

**Rationale:** The source memo's explanation of the rate-limit threshold doubling, the internal limiter's fraction computation against a hard-coded MAX, and the cascading failure is highly technical. Per audience constraints:
- **CEO brief:** Translated to "configuration change to authentication service inadvertently blocked all inbound requests" — no engineering jargon.
- **Customer email:** Translated to "configuration update... had an unintended side effect: it caused our system to reject all incoming authentication requests" — plain language, no jargon.
- **Legal summary:** Root cause is irrelevant to SLA-credit determination; omitted entirely per the must_not_include rule for engineering remediation details.

---

## Decision 5: SLA Credit Language Per Audience

**Rationale:** The source memo discusses SLA credits in multiple contexts. Each audience receives only the relevant framing:
- **CEO brief:** States SLA credits are owed and that legal/finance are processing — high-level status.
- **Customer email:** Explicitly offers SLA credit and provides a contact path — actionable for the customer.
- **Legal summary:** Provides the contractual basis (99.9% monthly uptime), breach determination, and handling recommendation — precise for counsel.

---

## Decision 6: Word Count Management

**Rationale:** All three rewrites are within their respective word limits:
- CEO brief: 219 words (limit: 250)
- Customer email: 268 words (limit: 350)
- Legal summary: 278 words (limit: 400)

No facts were added to meet word count targets. Each rewrite is concise by design.
