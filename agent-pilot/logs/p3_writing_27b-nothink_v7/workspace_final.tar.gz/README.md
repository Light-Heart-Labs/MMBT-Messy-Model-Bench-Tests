# Incident Rewrite Output

This directory contains three audience-tailored rewrites of the internal outage memo (`/input/repo/draft_memo.md`), produced according to the specifications in `/input/repo/audience_briefs.json`.

## Files

| File | Audience | Word Count | Limit |
|------|----------|------------|-------|
| `ceo_brief.md` | CEO / Board prep | 219 | ≤250 |
| `customer_email.md` | Affected customers (mass email) | 268 | ≤350 |
| `legal_summary.md` | In-house counsel | 278 | ≤400 |
| `decisions/adr-001-omission-decisions.md` | Internal — ADR for non-obvious choices | — | — |
| `research/notes.md` | Internal — working notes and fact extraction | — | — |

## How to Read

Each rewrite is a standalone document tailored to its audience. The CEO brief is a concise executive summary with board-level framing. The customer email is a warm, accountable message with an explicit SLA-credit offer. The legal summary is a dispassionate factual record for SLA-credit determination. All facts are sourced exclusively from the original memo — no external information was introduced.

The ADR in `decisions/` documents the rationale for key omission choices (e.g., why the named engineer was excluded from certain audiences, why the "second outage in 90 days" framing appears only in the CEO brief).
