# Incident Summary — SLA Credit Obligation Review

**Incident Window:** 14:11 UTC to 18:24 UTC on Friday (approximately 4 hours 13 minutes).

**Scope of Impact:**
- Total customer accounts affected: approximately 11,400.
- Enterprise accounts with named Customer Success Managers experiencing revenue impact during business hours: 28.
- Cases of known downstream-automation harm requiring manual cleanup: 4.
- Inbound support tickets received: 217.
- Refund/credit requests received to date: 31 (mix of SLA-credit-only requests and full-month credit requests).

**Contractual SLA:** The company's standard Master Service Agreement provides a 99.9% monthly uptime commitment, with service credits for breach. The 4-hour 13-minute incident window constitutes a nominal breach of the 99.9% monthly uptime threshold for the affected accounts.

**Credit-Request Handling Recommendation:**
- **SLA-driven requests:** For accounts where the 99.9% monthly uptime threshold was clearly breached, credits should be processed per the MSA terms. The company should not contest these requests.
- **Non-contractual requests:** For accounts that request credits without a demonstrable SLA breach, these should be handled on a case-by-case basis by Finance and Customer Success, not as a contractual obligation.
- **Downstream-automation harm (4 cases):** These accounts are owed both the standard SLA credit and additional remediation support (hands-on data-cleanup engagement at no charge), as proposed by engineering leadership.

**Additional Notes:**
- The 28 enterprise accounts with confirmed revenue impact during business hours fall within the SLA-driven category.
- The remaining approximately 11,372 accounts experienced bounded impact (automation stalled and resumed upon recovery); SLA credits are owed to those that explicitly request them.
- Legal and Finance are currently working through the 31 received requests on a case-by-case basis.
