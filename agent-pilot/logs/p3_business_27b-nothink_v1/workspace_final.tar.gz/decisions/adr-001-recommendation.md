# ADR-001: Recommendation Stance — HOLD, Not PROCEED

**Status:** Accepted
**Date:** 2026-04-15
**Decision Maker:** Executive Committee Reviewer

## Context

The Corp Dev team recommends proceeding to LOI at $84M for Borealis Analytics. The diligence pack presents a favorable view of the target but contains several material gaps and optimistic assumptions that warrant further investigation before committing to a binding LOI.

## Decision

**Recommendation: HOLD.** Do not proceed to LOI until the diligence asks in `asks.md` are completed and the following conditions are met:

1. The Aurora sunset/migration plan is fully scoped with a realistic timeline and cost estimate.
2. A proper comparable transaction analysis is completed with at least 5-8 relevant comps.
3. The IRR model is disclosed and stress-tested.
4. Customer reference calls include a representative sample (not just the top 5).
5. The revenue recognition vs. ARR gap is explained and validated.

## Consequences

- If diligence reveals the concerns are manageable, we can proceed to LOI within the 2-week window.
- If diligence reveals material issues (e.g., customer concentration, migration risk, valuation overpayment), we should PASS.
- If Borealis is actively seeking other buyers, holding for 2 weeks carries a risk of losing the deal. However, proceeding without adequate diligence carries a greater risk of overpaying or acquiring a problematic asset.

## Rationale

The pack is an advocacy document, not a balanced analysis. The most critical issue is the plan to sunset Aurora 12 months post-close — this fundamentally changes the nature of the acquisition from a product acquisition to a customer-and-talent acquisition, which requires different diligence and valuation. The pack does not address this distinction.

---

# ADR-002: Treatment of the Aurora Sunset Plan

**Status:** Accepted
**Date:** 2026-04-15

## Context

The pack states that the Aurora platform will be sunset 12 months post-close with customer migration to our integrated platform. This is a material fact that significantly impacts the deal's value proposition and risk profile.

## Decision

The Aurora sunset plan must be treated as a **critical risk factor** and not as a standard integration detail. The following must be addressed before LOI:

1. A detailed migration plan with customer impact assessment.
2. A churn risk model for the migration period.
3. A cost estimate for migration (separate from the $3.2M synergy estimate).
4. Customer communication strategy and consent requirements.

## Rationale

Sunsetting a product 12 months after acquisition is aggressive and risky. If migration is difficult or customers resist, we could lose a significant portion of the 280 customers we're paying $84M to acquire. The pack's 118% NRR and 91% logo retention metrics are irrelevant if we're forcing a platform switch.

---

# ADR-003: Valuation Benchmarking Approach

**Status:** Accepted
**Date:** 2026-04-15

## Context

The pack uses three comparable transactions to justify the 7.4x ARR multiple. These comps lack detail on the targets' characteristics at time of acquisition and the acquirers' strategic rationale.

## Decision

A proper comparable transaction analysis must be completed before LOI, including:

1. At least 5-8 recent SaaS acquisitions with similar growth rates, margins, and stage.
2. Detail on deal structure (cash vs. stock, earn-outs, retention packages).
3. Analysis of strategic vs. financial rationale for each comp.
4. Adjustment for differences in growth rate, margin profile, and market position.

## Rationale

The current comp analysis is insufficient to validate the $84M price. The pack cherry-picks the lower comp (Trellis at 7x) without explaining why Borealis should be valued at the low end of the range given its strong growth metrics.
