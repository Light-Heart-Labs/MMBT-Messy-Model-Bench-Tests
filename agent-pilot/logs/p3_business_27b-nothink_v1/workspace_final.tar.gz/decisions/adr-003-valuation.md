# ADR-003: Valuation Benchmarking Approach

**Status:** Accepted
**Date:** 2026-04-15
**Decision Maker:** Executive Committee Reviewer

## Context

The pack uses three comparable transactions to justify the 7.4x ARR multiple. These comps lack detail on the targets' characteristics at time of acquisition and the acquirers' strategic rationale.

## Decision

A proper comparable transaction analysis must be completed before LOI, including:

1. At least 5-8 recent SaaS acquisitions with similar growth rates, margins, and stage.
2. Detail on deal structure (cash vs. stock, earn-outs, retention packages).
3. Analysis of strategic vs. financial rationale for each comp.
4. Adjustment for differences in growth rate, margin profile, and market position.

## Rationale

The current comp analysis is insufficient to validate the $84M price. The pack cherry-picks the lower comp (Trellis at 7x) without explaining why Borealis should be valued at the low end of the range given its strong growth metrics.
