# Diligence Asks — Next 2 Weeks

**Target:** Complete by 2026-04-30 (LOI decision date)

## Priority 1: Financial & Valuation (Owner: CFO / Corp Dev)

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| 1.1 | Obtain Borealis's full cap table, last round terms (valuation, investor rights, liquidation preferences), and any bridge financing in place. | Corp Dev | 2026-04-22 |
| 1.2 | Reconcile the $9.2M GAAP revenue vs. $11.4M ARR gap. Provide a deferred revenue schedule and revenue recognition policy. | CFO | 2026-04-22 |
| 1.3 | Obtain 12-month monthly burn rate trend (not just average). Has burn increased or decreased? | Corp Dev | 2026-04-22 |
| 1.4 | Build a proper comparable transaction analysis: identify 5-8 recent SaaS acquisitions with similar growth rates, margins, and stage. Include deal structure details. | Corp Dev | 2026-04-25 |
| 1.5 | Obtain the IRR model used for the 28-34% estimate. Run sensitivity analysis on: (a) integration timeline (4mo vs. 9mo), (b) post-close retention (118% vs. 95%), (c) synergy realization (100% vs. 50%). | CFO | 2026-04-25 |
| 1.6 | Clarify the cash vs. stock split range and model the impact on our balance sheet and dilution. | CFO | 2026-04-22 |

## Priority 2: Customer & Product (Owner: VP Eng / PM)

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| 2.1 | Conduct reference calls with a stratified sample of 10-15 customers (not just the top 5). Include customers who have churned in the last 12 months. | PM | 2026-04-25 |
| 2.2 | Obtain the customer list with ARR per customer, contract start/end dates, and renewal history. Calculate top-10 and top-20 customer concentration. | Corp Dev | 2026-04-22 |
| 2.3 | Get the full customer churn analysis: monthly logo churn, dollar churn, and reasons for churn over the last 12 months. | Corp Dev | 2026-04-25 |
| 2.4 | Obtain Borealis's CAC, payback period, and LTV:CAC ratio. Assess whether their growth is capital-efficient. | Corp Dev | 2026-04-25 |
| 2.5 | Review the Aurora product roadmap for the next 6-12 months. What features are in development? How do they align with our platform? | PM | 2026-04-25 |

## Priority 3: Integration & Migration (Owner: VP Eng)

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| 3.1 | Develop a detailed Aurora migration plan: architecture, data migration strategy, testing approach, customer communication plan, and rollback plan. | VP Eng | 2026-04-25 |
| 3.2 | Estimate the cost and timeline of migration separately from integration. What is the customer-facing impact? | VP Eng | 2026-04-25 |
| 3.3 | Reassess the 4-6 month integration timeline with the engineering team. Provide a best/base/worst case. | VP Eng | 2026-04-22 |
| 3.4 | Model the synergy estimate ($3.2M) in detail. What costs are being eliminated? What new costs are being added? | CFO | 2026-04-25 |

## Priority 4: People & Culture (Owner: HR / Corp Dev)

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| 4.1 | Obtain the full org chart, headcount by function, and compensation benchmarks. | Corp Dev | 2026-04-22 |
| 4.2 | Conduct individual conversations with the CTO, VP Eng, and 3-4 other key engineers about post-close expectations and retention needs. | HR | 2026-04-25 |
| 4.3 | Draft retention package proposals for the CTO and other critical hires. Estimate total cost. | HR | 2026-04-25 |
| 4.4 | Assess cultural fit: work style, decision-making norms, engineering practices. | HR | 2026-04-25 |

## Priority 5: Legal & Compliance (Owner: General Counsel)

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| 5.1 | Review all material customer contracts for change-of-control provisions, consent requirements, and auto-termination clauses. | GC | 2026-04-25 |
| 5.2 | Conduct IP audit: confirm ownership of all code, check open-source license compliance, review any pending or threatened litigation. | GC | 2026-04-25 |
| 5.3 | Assess data privacy compliance (GDPR, CCPA) for the customer data analytics product. | GC | 2026-04-25 |
| 5.4 | Review Borealis's employment agreements, non-competes, and IP assignment agreements. | GC | 2026-04-22 |
