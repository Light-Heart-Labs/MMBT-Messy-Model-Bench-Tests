# Concerns with the Borealis Analytics Deal Pack

## HIGH-SEVERITY CONCERNS

### 1. Valuation Comps Are Not Comparable
The pack cites three comparable transactions (Hexa Insights at ~9x ARR, Aspen Data at ~12x ARR, Trellis Analytics at ~7x ARR) to justify the 7.4x ARR multiple. However:
- No detail is provided on the acquirers' strategic rationale for those deals (platform vs. tuck-in, talent acquisition, market entry).
- No detail on the growth rates, gross margins, or net retention of those targets at time of acquisition.
- The pack cherry-picks the lower comp (Trellis at 7x) to anchor the valuation but doesn't explain why Borealis should be valued at the low end of the range given its 92% ARR growth and 118% net retention.
- **Risk:** The $84M price may actually be at or above fair value once proper comps are analyzed.

### 2. Aurora Sunset Plan Is a Major Red Flag
The pack states: "Aurora platform sunset planned for 12 months post-close, with customer migration to our integrated platform." This is deeply concerning:
- If we're sunsetting their flagship product, we're buying a customer list and an engineering team, not a product.
- Migrating 280 customers off Aurora in 12 months is a massive operational lift that the pack does not quantify.
- Customer churn risk during migration is not addressed. The 118% NRR and 91% logo retention are meaningless if we're forcing a platform switch.
- The $3.2M synergy estimate from "consolidated infra" assumes successful migration — but what if migration fails or takes longer?
- **Risk:** The deal's value proposition collapses if migration is harder than assumed.

### 3. Customer Concentration and Reference Call Bias
- 280 paid customers with median ARR of $32K implies ~$8.96M in median-based revenue, which is close to the $9.2M reported — suggesting a relatively flat distribution. But the pack only references the "five largest customers" for pre-LOI conversations.
- We have no visibility into the bottom 90% of the customer base. Are there concentration risks? Churn risks in smaller accounts?
- Only 4 of 5 reference customers were willing to be quoted. The pack does not explain who declined or why.
- Testimonials are uniformly positive with no nuance — no mention of pain points, feature gaps, or pricing concerns.
- **Risk:** Customer satisfaction may be overstated; we lack a representative sample.

### 4. Revenue Recognition vs. ARR Gap
- Recognized GAAP revenue is $9.2M but ARR is $11.4M — a $2.2M gap (24% higher ARR).
- The pack does not explain this gap. Is it due to deferred revenue, multi-year contracts, or something else?
- For diligence, we need to understand the revenue quality: what % is deferred, what % is in the first year of multi-year deals, what % is at risk of churn before recognition.
- **Risk:** Revenue quality may be lower than the headline numbers suggest.

### 5. Burn Rate and Runway Math Doesn't Fully Add Up
- Burn rate: $750K/month. Cash on hand: $4.1M. That's ~5.5 months of runway, not 22 months.
- The pack says "22 months runway at last cap raise" — implying the last raise was ~$12.4M (22 × $750K = $16.5M, minus $4.1M remaining = ~$12.4M raised). But this is not stated.
- If burn has been constant, the company is running out of cash in ~5.5 months. This creates urgency that could work against us in negotiations (they need a deal) but also raises questions about financial management.
- **Risk:** The company may be in a tighter financial position than portrayed.

## MEDIUM-SEVERITY CONCERNS

### 6. Team Retention Assumptions Are Thin
- "~85% retention expected based on conversations with their VP Eng" — this is a single data point from one person.
- No mention of retention packages, equity refresh, or severance costs.
- The CTO (Sarah Lin) is highlighted as a key asset, but there's no mention of whether she has a retention agreement or what her post-close role would be.
- 14 engineers × 15% attrition = ~2 engineers leaving. If those are key people, the integration plan is at risk.
- **Risk:** Talent loss could undermine the deal's value.

### 7. Integration Timeline Is Optimistic
- 4-6 months for "full integration" of a product with "only 12% feature overlap" is aggressive.
- The pack doesn't describe the integration architecture, data migration plan, or testing strategy.
- No mention of customer-facing downtime or degradation during integration.
- **Risk:** Integration may take 9-12 months, extending costs and customer friction.

### 8. No Discussion of Competitive Response
- The pack doesn't address how competitors might react to our acquisition of Borealis.
- No mention of whether Borealis faces competitive threats that could erode ARR before close.
- **Risk:** Competitive dynamics could change the deal's value between now and close.

### 9. IRR Estimate Lacks Transparency
- "Risk-adjusted IRR estimate is in the 28-34% range over the 4-year hold" — but no model is provided.
- What assumptions drive the high vs. low end? What is the "risk adjustment"?
- No sensitivity analysis on key variables (retention, integration timeline, synergy realization).
- **Risk:** The IRR may be based on optimistic assumptions not disclosed in the pack.

### 10. No Mention of Legal, Regulatory, or IP Issues
- No discussion of material contracts, change-of-control provisions, or customer consent requirements.
- No mention of IP ownership, open-source compliance, or litigation exposure.
- No mention of data privacy (GDPR, CCPA) considerations for the customer data analytics product.
- **Risk:** Hidden legal issues could delay or derail the deal.

## LOWER-SEVERITY CONCERNS

### 11. Stock vs. Cash Split Not Defined
- "Cash + stock split TBD; Borealis preference is cash-heavy" — but no numbers.
- This affects our cash outlay, dilution, and accounting treatment.

### 12. "Mid-market e-commerce" Segment Strategy Unclear
- The pack says Borealis extends our reach into "mid-market e-commerce" but doesn't define the TAM, our current penetration, or the strategic importance of this segment.

### 13. No Mention of Borealis's Go-to-Market Strategy
- How does Borealis acquire customers? What's their CAC and payback period?
- Without this, we can't assess whether their growth is sustainable post-acquisition.

### 14. Engineering Review Scope Unclear
- "Our engineering review found no concerning patterns" — but what was the scope? How many hours? Which engineers?

### 15. No Discussion of Cultural Fit
- No assessment of cultural compatibility between Borealis and our organization.
