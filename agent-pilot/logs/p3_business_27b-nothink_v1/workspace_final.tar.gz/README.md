# Borealis Analytics Acquisition — Independent Review

## How to Read This Output

This directory contains an independent review of the Corp Dev diligence pack for the proposed acquisition of Borealis Analytics, Inc. for $84M.

### Files

| File | Description |
|------|-------------|
| [`memo.md`](memo.md) | **Primary deliverable.** A 1-page memo for the executive committee with the recommendation, key concerns, and diligence asks. |
| [`concerns.md`](concerns.md) | Full enumeration of every concern identified, ranked by severity (high, medium, low). Includes concerns not elevated to the memo. |
| [`asks.md`](asks.md) | Detailed diligence-ask list for the next 2 weeks, organized by workstream with owners and deadlines. |
| [`decisions/`](decisions/) | Architecture Decision Records (ADRs) documenting key judgment calls made during the review. |

### Reading Order

1. Start with [`memo.md`](memo.md) for the executive summary and recommendation.
2. Read [`concerns.md`](concerns.md) for the full analysis of issues.
3. Review [`asks.md`](asks.md) for the action items if the committee wants to keep the deal alive.
4. Check [`decisions/`](decisions/) for the rationale behind key judgment calls.

### Recommendation Summary

**HOLD** — Do not proceed to LOI until the diligence gaps are addressed. The deal has strategic merit but the pack contains material gaps in valuation justification, migration risk assessment, and customer diligence.

### Source Material

The sole source for this review is the Corp Dev diligence pack at `/input/repo/deal_pack.md`. No external data, customer names, or financial figures have been introduced.
