# Executive Committee Memo — Borealis Analytics Acquisition Review

**To:** Executive Committee
**From:** Independent Reviewer
**Date:** 2026-04-15
**Re:** Project Lighthouse — Acquisition of Borealis Analytics for $84M

---

## Recommendation: HOLD

I recommend **holding** the deal and not proceeding to LOI until the diligence gaps identified below are addressed. The Corp Dev pack is well-structured but reads as advocacy, not balanced analysis. Several material issues require resolution before we commit $84M.

**I would change my stance to PROCEED if:** (a) the Aurora migration plan is fully scoped and deemed feasible, (b) a proper comparable transaction analysis validates the 7.4x ARR multiple, (c) the IRR model is disclosed and survives stress-testing, and (d) customer diligence confirms satisfaction across a representative sample.

**I would change my stance to PASS if:** (a) migration risk is high and customer churn during transition is likely to exceed 20%, (b) the valuation is above fair value once proper comps are analyzed, or (c) key talent (especially CTO Sarah Lin) cannot be retained.

---

## Strongest Concerns

### 1. The Aurora Sunset Plan Fundamentally Changes the Deal

The pack states the Aurora platform will be sunset 12 months post-close with customer migration to our platform. This means we are buying a customer list and an engineering team, not a product. The pack does not address the migration risk: how many of the 280 customers will churn during a forced platform switch? The 118% net retention and 91% logo retention cited are irrelevant if we're forcing a migration. No migration cost estimate is provided, and the $3.2M synergy estimate assumes successful migration. If migration is difficult, the deal's value proposition collapses.

### 2. Valuation Comps Are Insufficient

The pack cites three comparable transactions (Hexa Insights at ~9x ARR, Aspen Data at ~12x ARR, Trellis Analytics at ~7x ARR) to justify the 7.4x multiple. No detail is provided on the targets' growth rates, margins, or the acquirers' strategic rationale. The pack implicitly anchors to the lowest comp (Trellis at 7x) without explaining why Borealis — with 92% ARR growth and 118% net retention — should be valued at the bottom of the range. A proper analysis with 5-8 relevant comps is needed.

### 3. Financial Inconsistencies

The pack reports $9.2M in recognized GAAP revenue but $11.4M in ARR — a 24% gap that is unexplained. Additionally, the burn rate of $750K/month against $4.1M in cash yields only ~5.5 months of runway, yet the pack references "22 months runway at last cap raise." This suggests the company may be in a tighter financial position than portrayed.

### 4. Customer Diligence Is Not Representative

Reference calls were made only to the five largest customers, and only 4 of 5 were willing to be quoted. The pack does not explain who declined or why. Testimonials are uniformly positive with no nuance. We have no visibility into the bottom 90% of the customer base, churned customers, or customer concentration risk.

### 5. IRR Model Is Undisclosed

The pack cites a "risk-adjusted IRR estimate of 28-34% over the 4-year hold" but provides no model, assumptions, or sensitivity analysis. Without seeing the model, we cannot assess whether this range is realistic.

---

## Diligence Asks (Next 2 Weeks)

See `asks.md` for the full list. Key priorities:

1. **Financial:** Reconcile the revenue/ARR gap; obtain the cap table and last round terms; build a proper comp analysis; disclose and stress-test the IRR model.
2. **Customer:** Conduct reference calls with a stratified sample of 10-15 customers (including churned accounts); obtain the full customer list with concentration analysis.
3. **Integration:** Develop a detailed Aurora migration plan with cost, timeline, and churn risk estimates; reassess the 4-6 month integration timeline with engineering.
4. **People:** Conduct individual conversations with the CTO and key engineers about retention; draft retention packages.
5. **Legal:** Review material customer contracts for change-of-control provisions; conduct IP and data privacy audits.

---

## Bottom Line

The strategic rationale is sound — Borealis extends our reach into mid-market e-commerce with a complementary product and a strong team. But the pack overclaims on valuation justification, underexplains the migration risk, and omits critical financial and customer context. I recommend holding for two weeks of targeted diligence before deciding whether to proceed.
