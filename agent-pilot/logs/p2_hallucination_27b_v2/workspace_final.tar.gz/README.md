# How to Read the Triage Output

## Files

- **`triage.json`** — The primary output. Contains verdict (`real` or `fabricated`) and evidence for each of the 15 issues, plus a summary count.
- **`notes.md`** — Extended reasoning, tables, and context that doesn't fit in the JSON evidence fields.
- **`decisions/issue-009.md`** — ADR for the borderline call on issue 009 (function exists but in wrong file).

## Methodology

1. Read the full issue report to understand all 15 claims.
2. Listed all Python files in the codebase to verify file existence.
3. Read every source file in full to verify each claim.
4. Used `grep` to cross-reference imports, function names, and keywords.
5. Ran Python 3.11 to confirm the `collections.Iterable` ImportError.
6. Applied the rule: wrong file citation = fabricated, even if the underlying observation is partially correct.

## Summary

| Verdict | Count |
|---------|-------|
| Real | 6 |
| Fabricated | 9 |

The previous reviewer was confident but wrong on 60% of issues, inventing files that don't exist (`web.py`, `cache.py`), claiming bugs where the code is fine (SQL injection, race condition, double-counting), and citing wrong file paths.
