# ADR: Issue 009 — `format_legacy()` file citation

## Issue Claim
The report claims `format_legacy()` is in `logalyzer/output.py` and is unused dead code.

## Investigation
- `logalyzer/output.py` does NOT contain `format_legacy()`.
- `logalyzer/utils.py:21` DOES contain `format_legacy()`.
- `format_legacy()` is indeed unused — no other module imports it.

## Decision
**Verdict: fabricated**

Per the triage rules: "A wrong file citation makes the issue fabricated." The claim specifically says the function is in `output.py`, but it's actually in `utils.py`. Even though the underlying observation (the function exists and is unused) is partially correct, the issue as written is about the wrong file.

## Note
If the reviewer had cited `utils.py` instead of `output.py`, this would have been a real issue. The dead code observation is valid, but the file citation is wrong.
