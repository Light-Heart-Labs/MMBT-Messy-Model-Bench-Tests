# Triage Notes — logalyzer Issue Verification

## Overview

Reviewed 15 issues from the preliminary code-review report against the actual logalyzer codebase.

**Result: 6 real, 9 fabricated.**

## Real Issues (6)

| # | Issue | File:Line |
|---|-------|-----------|
| 001 | `from collections import Iterable` (removed in Python 3.10) | `logalyzer/filters.py:5` |
| 002 | `eval()` on user-supplied expressions | `logalyzer/filters.py:59` |
| 004 | README claims "Real-time tail mode" that doesn't exist | `README.md:10` |
| 006 | `experimental.py` is never imported by any other module | `logalyzer/experimental.py` |
| 013 | O(n²) list concatenation and character-by-character string building | `logalyzer/io.py:24,27` |
| 014 | O(n) list membership test in `ip_allowlist_filter` | `logalyzer/filters.py:36` |

## Fabricated Issues (9)

| # | Issue | Why Fabricated |
|---|-------|----------------|
| 003 | SQL injection in parser | No SQL anywhere in the codebase. Parser uses only regex. |
| 005 | `--top` flag broken | `--top` is properly defined with `type=int` and used correctly. |
| 007 | Missing CSRF in web.py | `logalyzer/web.py` does not exist. |
| 008 | 8192-char truncation in parser | No truncation logic exists in `parse_line()`. |
| 009 | `format_legacy()` in `output.py` | Function exists in `utils.py`, not `output.py`. Wrong file citation. |
| 010 | Race condition in `load_iter()` | Each call opens its own file handle; no shared state. |
| 011 | Double-counting 3xx in `by_status()` | Simple Counter increment; no special 3xx handling. |
| 012 | Stale cache in `cache.py` | `logalyzer/cache.py` does not exist. |
| 015 | `__init__.py` imports `LogEntry` from `parser` | `__init__.py` only has `__version__`; no such import. |

## Borderline Calls

### Issue 009 — `format_legacy()` in wrong file

The function `format_legacy()` *does* exist in the codebase, but in `logalyzer/utils.py:21`, not in `logalyzer/output.py` as claimed. Per the triage rules: "A wrong file citation makes the issue fabricated." The claim as written is about `output.py`, and `output.py` does not contain this function.

See `/workspace/decisions/issue-009.md` for details.

### Issue 010 — Race condition claim

The claim is that concurrent calls to `load_iter()` on the same file can corrupt output. Each call opens its own `with open(path, "r") as f:` context, so there's no shared file handle. The only shared resource is the file on disk, which is read-only. This is not a race condition.
