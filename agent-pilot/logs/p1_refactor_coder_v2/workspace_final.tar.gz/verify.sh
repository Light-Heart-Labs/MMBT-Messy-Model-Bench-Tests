#!/bin/bash
set -e

echo "=== VERIFICATION SCRIPT ==="
echo ""

echo "1. Running pytest..."
python -m pytest -q
echo "✓ All tests pass"
echo ""

echo "2. Testing format_legacy import..."
python -c "from logalyzer.output import format_legacy; print('✓ format_legacy is importable')"
echo ""

echo "3. Testing output module imports..."
python -c "from logalyzer.output import to_json, to_csv, to_text, render_aggregate; print('✓ All output functions are importable')"
echo ""

echo "4. Testing CLI..."
python -m logalyzer.cli --help > /dev/null
echo "✓ CLI works"
echo ""

echo "5. Testing output formats with sample log..."
python -m logalyzer.cli samples/access.log --format text > /dev/null
python -m logalyzer.cli samples/access.log --format json > /dev/null
python -m logalyzer.cli samples/access.log --format csv > /dev/null
python -m logalyzer.cli samples/access.log --aggregate status --format text > /dev/null
echo "✓ All output formats work"
echo ""

echo "6. Checking output package structure..."
test -f logalyzer/output/__init__.py && echo "✓ __init__.py exists"
test -f logalyzer/output/json_renderer.py && echo "✓ json_renderer.py exists"
test -f logalyzer/output/csv_renderer.py && echo "✓ csv_renderer.py exists"
test -f logalyzer/output/plain_renderer.py && echo "✓ plain_renderer.py exists"
test -f logalyzer/output/legacy.py && echo "✓ legacy.py exists"
test ! -f logalyzer/output.py && echo "✓ Old output.py removed"
echo ""

echo "=== ALL VERIFICATIONS PASSED ==="
