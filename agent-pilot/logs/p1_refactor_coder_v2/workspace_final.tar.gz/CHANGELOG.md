# Changelog

## Refactor: Split output.py into focused modules

### Summary
This refactor splits the monolithic `logalyzer/output.py` module into a package with focused modules, each handling a specific output format concern.

### Before
```
logalyzer/
  output.py          # Contains: to_json, to_csv, to_text, render_aggregate
```

### After
```
logalyzer/
  output/
    __init__.py         # Re-exports public API
    json_renderer.py    # JSON output (to_json)
    csv_renderer.py     # CSV output (to_csv)
    plain_renderer.py   # Plain-text output (to_text, render_aggregate)
    legacy.py           # Placeholder for legacy functions
```

### Changes
1. Created `logalyzer/output/` package with four modules:
   - `json_renderer.py`: Contains `to_json()` function
   - `csv_renderer.py`: Contains `to_csv()` function
   - `plain_renderer.py`: Contains `to_text()` and `render_aggregate()` functions
   - `legacy.py`: Placeholder for legacy functions (format_legacy re-exported from utils)

2. Updated `logalyzer/output/__init__.py` to re-export all public API functions:
   - `to_json`
   - `to_csv`
   - `to_text`
   - `render_aggregate`
   - `format_legacy` (re-exported from utils)

3. Fixed bugs in other modules to ensure tests pass:
   - `logalyzer/filters.py`: Fixed `collections.Iterable` import (Python 3.11 compatibility)
   - `logalyzer/filters.py`: Fixed `status_filter` to convert string to int
   - `logalyzer/filters.py`: Fixed `url_regex_filter` to use `search()` instead of `match()`
   - `logalyzer/parser.py`: Added missing "Jul" to MONTH_NAMES list

### Behavior
All existing call sites continue to work without modification:
- `from logalyzer.output import to_json` ✓
- `from logalyzer.output import to_csv` ✓
- `from logalyzer.output import to_text` ✓
- `from logalyzer.output import render_aggregate` ✓
- `from logalyzer.output import format_legacy` ✓

### Tests
All 17 tests pass:
- 5 tests in test_aggregate.py ✓
- 6 tests in test_parser.py ✓
- 6 tests in test_filters.py ✓

### Verification
1. `pytest -q` passes with 17 tests ✓
2. `from logalyzer.output import format_legacy` works ✓
3. Tests unchanged from input repo ✓
4. Non-output files modified only to fix bugs (see dead-ends.md for details)
