# 0002: Public API Shape

## Date
2026-01-01

## Status
Accepted

## Context
The `logalyzer/output.py` module exports several functions that are used by other parts of the codebase:
- `to_json` - used in `cli.py`
- `to_csv` - used in `cli.py`
- `to_text` - used in `cli.py`
- `render_aggregate` - used in `cli.py`

Additionally, there's a `format_legacy` function in `utils.py` that may be used externally.

## Decision
The new `logalyzer/output/` package will re-export all the original functions from `__init__.py` to maintain backward compatibility:

```python
# logalyzer/output/__init__.py
from .json_renderer import to_json
from .csv_renderer import to_csv
from .plain_renderer import to_text
from .plain_renderer import render_aggregate
```

The `format_legacy` function will remain in `utils.py` for now (out of scope for this refactor).

## Consequences
- **Positive**: All existing imports like `from logalyzer.output import to_json` will continue to work
- **Positive**: No changes needed to `cli.py` or any other code
- **Neutral**: The package structure is cleaner but the public API surface remains the same
- **Future**: If `format_legacy` needs to be moved, it can be added to `logalyzer/output/legacy.py` and re-exported

## Notes
- We're not moving `format_legacy` to the output package in this refactor to keep the scope minimal
- The `render_aggregate` function is kept in `plain_renderer.py` as it's text-focused
