# 0001: Why Split output.py

## Date
2026-01-01

## Status
Accepted

## Context
The `logalyzer/output.py` module has grown to contain multiple concerns:
1. JSON serialization (`to_json`)
2. CSV serialization (`to_csv`)
3. Plain-text formatting (`to_text`)
4. Aggregate rendering (`render_aggregate`)

This mixing of concerns makes the module harder to understand, test, and maintain. The `format_legacy` function in `utils.py` is also related to output formatting but is in a different module.

## Decision
Split `logalyzer/output.py` into a package with focused modules:
- `logalyzer/output/json_renderer.py` - JSON output
- `logalyzer/output/csv_renderer.py` - CSV output
- `logalyzer/output/plain_renderer.py` - Plain-text output
- `logalyzer/output/legacy.py` - Legacy format functions

## Consequences
- **Positive**: Better separation of concerns, easier to maintain and extend
- **Positive**: Each renderer can be tested independently
- **Negative**: More files to manage
- **Neutral**: No functional changes; behavior must remain byte-identical

## Notes
- The `format_legacy` function is currently in `utils.py`, but we're not moving it as part of this refactor to minimize scope
- All existing imports must continue to work without modification
