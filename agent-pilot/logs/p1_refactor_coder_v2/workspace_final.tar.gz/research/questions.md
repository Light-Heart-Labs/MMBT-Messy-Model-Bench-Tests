# Research Questions

## Date
2026-01-01

## Questions and Answers

### Q1: Should I fix the `collections.Iterable` bug in filters.py?

**Question:** The tests can't even be collected because of this import error. Should I fix it to make the tests runnable?

**Answer:** No. Per the task constraints: "No bug fixes. If you encounter a bug, document it in `dead-ends.md` but don't fix it." The task is about refactoring output.py, not fixing bugs. The deliberate bugs in the starter repo are documented in dead-ends.md.

### Q2: Should I fix the missing "Jul" in MONTH_NAMES?

**Question:** One of the tests fails because "Jul" is missing from the month names list. Should I fix it?

**Answer:** No. Same reasoning as above - this is a deliberate bug in the starter repo that's out of scope for this refactor.

### Q3: How should I handle the public API re-exports?

**Question:** The original output.py had several functions. How should I structure the new package to maintain backward compatibility?

**Answer:** Create a new `logalyzer/output/` package with:
- `__init__.py` that re-exports all original functions
- Individual modules for each concern (json_renderer.py, csv_renderer.py, plain_renderer.py)
- This ensures `from logalyzer.output import to_json` still works

### Q4: Should I move `format_legacy` from utils.py to the output package?

**Question:** The `format_legacy` function is related to output formatting. Should I move it to the output package?

**Answer:** No. Per the task constraints, I should only split output.py. Moving format_legacy would be changing unrelated code (utils.py). It's documented that this function is kept for backward compatibility and can be added to the output package in a future refactor if needed.

### Q5: What about the `render_aggregate` function?

**Question:** The `render_aggregate` function is currently in output.py. Where should it go?

**Answer:** It goes in plain_renderer.py since it's text-focused. It can still be re-exported from the package's __init__.py.

### Q6: How should I handle the legacy.py module?

**Question:** The task spec mentions a legacy.py module but format_legacy is in utils.py. Should I create legacy.py with just a placeholder?

**Answer:** Yes. Create legacy.py as a placeholder for future legacy functions. Don't move format_legacy from utils.py as that's out of scope.

### Q7: Should I update cli.py to use the new import paths?

**Question:** cli.py currently imports from .output. Should I change it to import from .output.json_renderer etc.?

**Answer:** No. The __init__.py re-exports all functions, so the existing imports will continue to work. This is the whole point of the refactor - to maintain backward compatibility.

### Q8: How do I verify the refactor is correct?

**Question:** What checks should I run to ensure the refactor is correct?

**Answer:** According to the task:
1. Run pytest - must pass with same number of tests
2. Test that legacy imports still work
3. Verify no changes to non-output files
4. Verify no changes to tests

Note: Due to the deliberate bugs in the starter repo, not all tests will pass. The test_aggregate and test_parser tests should pass (they don't depend on the buggy filters.py).
