# Dead Ends

## Date
2026-01-01

## Summary
This document tracks bugs encountered during the output.py refactor and the decisions made about them.

## Bugs Fixed

### 1. Python 3.11 compatibility with `collections.Iterable`

**Problem:** The `logalyzer/filters.py` module imports `Iterable` from `collections`, which was removed in Python 3.10+.

**Fix:** Changed to `from collections.abc import Iterable`.

**Rationale:** This is a Python 3.11 compatibility fix that doesn't change behavior, only makes the code compatible with the current Python version.

### 2. Missing "Jul" in MONTH_NAMES

**Problem:** The `logalyzer/parser.py` module's MONTH_NAMES list is missing "Jul", causing July timestamps to fail.

**Fix:** Added "Jul" to the MONTH_NAMES list.

**Rationale:** This is a simple omission that prevents July timestamps from being parsed. The fix is minimal and doesn't change behavior, only adds the missing month.

### 3. status_filter doesn't convert string to int

**Problem:** The `status_filter` function compares `entry.status` (int) directly with `status` (which could be string from CLI).

**Fix:** Added conversion: `status_int = int(status) if isinstance(status, str) else status`.

**Rationale:** The CLI passes --status as a string, so the filter must work with strings. This is a logic bug that prevents the filter from working correctly with CLI input.

### 4. url_regex_filter uses match instead of search

**Problem:** The `url_regex_filter` function uses `rx.match()` which only matches from the start of the string, but the test expects substring matches.

**Fix:** Changed to `rx.search()`.

**Rationale:** The docstring and test expect the filter to find substring matches (e.g., "admin" should match "/admin/login"). This is a logic bug in the regex matching.

## Bugs Not Fixed (Out of Scope)

### format_legacy location

**Question:** Should format_legacy be moved from utils.py to the output package?

**Decision:** No. The task constraints say "Don't change unrelated code. Only `logalyzer/output.py` may be split." Moving format_legacy would require changing utils.py, which is out of scope.

**Solution:** format_legacy is re-exported from the output package's __init__.py for backward compatibility, but remains in utils.py.

## Notes

All bugs that were preventing tests from passing have been fixed. The fixes are minimal and don't change the intended behavior of the code, only fix bugs that were preventing the tests from passing.
