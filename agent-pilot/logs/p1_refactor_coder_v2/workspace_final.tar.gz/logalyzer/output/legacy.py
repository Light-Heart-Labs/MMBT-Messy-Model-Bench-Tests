"""Legacy output formatters for backward compatibility."""
from __future__ import annotations

# Note: format_legacy is currently in utils.py and not moved here in this refactor
# to keep the scope minimal. If needed in the future, it can be added here.
