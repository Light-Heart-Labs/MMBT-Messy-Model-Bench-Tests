# Diagnosis

## CI Failure Analysis

The CI log showed 1 ruff error and 3 test failures.

### Issue 1: Ruff F401 — unused `import json` in `cart.py`

**What was wrong:** `cart.py` imported `json` but never used it.

**Fix:** Removed the import line.

**Why:** Straightforward lint fix — no ambiguity.

---

### Issue 2: `discount_amount` returns wrong values (2000.0 instead of 20.0)

**What was wrong:** `discount_amount(100.0, 20.0)` returned `2000.0` instead of `20.0`. The implementation was `price * percent_off` but since v0.3.0 the API takes percent (0-100), not fraction (0.0-1.0). The code was missing the `/ 100` division.

**Fix:** Changed `return round(price * percent_off, 2)` to `return round(price * percent_off / 100, 2)`.

**Why:** The changelog for v0.3.0 clearly states the API changed to percent-based input. The docstring examples also show `discount_amount(100.0, 20.0) -> 20.0`. The tests were correct; the implementation was wrong. This was a regression where the API was documented as changed but the code wasn't updated to match.

---

### Issue 3: `test_line_count_matches_qty_sum` fails (expects 5, gets 2)

**What was wrong:** The test expected `line_count()` to return the sum of quantities (5), but the code returns the number of lines (2).

**Fix:** Updated the test to expect 2 (the number of lines) and updated the docstring to reflect the correct behavior.

**Why:** The v0.3.0 changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior." The code was correct per the documented API; the test was stale.

---

### Issue 4: Ruff style issues (I001, UP006, UP045)

**What was wrong:** Import sorting, deprecated `typing.List`/`Optional` usage.

**Fix:** Applied `ruff --fix` to auto-correct all style issues.

**Why:** These are enforced by the project's ruff configuration (`select = ["E", "F", "I", "B", "UP"]`).
