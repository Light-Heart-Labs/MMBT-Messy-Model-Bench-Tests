# Changelog

## v0.3.2 (2025-01-XX)

**Bug fixes:**

- **`discount_amount()` was not dividing by 100.** The v0.3.0 changelog documented that the API changed from fraction (0.0-1.0) to percent (0-100), but the implementation still multiplied `price * percent_off` without dividing by 100. This caused `discount_amount(100.0, 20.0)` to return `2000.0` instead of `20.0`. Fixed by changing the return to `round(price * percent_off / 100, 2)`.
- **Removed unused `import json` from `cart.py`.** This was flagged by ruff F401.
- **Updated `test_line_count_matches_qty_sum` to match v0.3.0 API.** The v0.3.0 changelog stated that `Cart.line_count()` now returns the number of lines (not total quantity). The test was still asserting the old behavior (expecting 5 for total qty). Updated to expect 2 (number of lines).
- **Applied ruff auto-fixes:** import sorting (I001), deprecated `typing.List` → `list` (UP006), deprecated `Optional` → `X | None` (UP045).

**Verification:**
- `ruff check src/ tests/` → 0 errors
- `pytest -q` → 7 passed, 0 failed

## v0.3.1 (current — CI red)

CI is failing on this version. See `ci_failure.log` for the full output.

## v0.3.0

- **BREAKING**: `discount_amount()` and `apply_discount()` now take percent (0-100)
  instead of fraction (0.0-1.0). Update callers from `apply_discount(p, 0.2)` to
  `apply_discount(p, 20.0)`.
- `Cart.line_count()` now returns the number of lines, not the total quantity
  across lines. Tests should be updated where they relied on the old behavior.

## v0.2.0

- Added `Cart.set_discount()` for cart-wide discounts.
- `Cart.line_count()` returns total quantity across lines.

## v0.1.0

- Initial release.
