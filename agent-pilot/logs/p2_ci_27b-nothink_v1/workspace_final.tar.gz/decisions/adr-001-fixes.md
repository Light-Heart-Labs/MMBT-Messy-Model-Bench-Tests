# ADR-001: Fix discount_amount implementation, not the tests

## Context

`discount_amount(100.0, 20.0)` returned `2000.0` instead of `20.0`. The v0.3.0 changelog documented that the API changed from fraction (0.0-1.0) to percent (0-100), but the implementation was never updated to match.

## Decision

Fix the implementation by dividing by 100: `price * percent_off / 100`.

## Rationale

- The docstring examples show `discount_amount(100.0, 20.0) -> 20.0`
- The tests encode the expected behavior correctly
- The changelog documents the API contract
- The implementation was simply missing the `/ 100` — a clear regression

## Consequences

`apply_discount` also benefits since it calls `discount_amount` internally. Both tests pass after this fix.

---

# ADR-002: Update test_line_count to match v0.3.0 API, not the code

## Context

`test_line_count_matches_qty_sum` expected `line_count()` to return total quantity (5), but the code returned number of lines (2).

## Decision

Update the test to expect 2 (number of lines).

## Rationale

- The v0.3.0 changelog explicitly says: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior."
- The code correctly implements the documented API
- The test was stale — it still reflected v0.2.0 behavior

## Consequences

Test now correctly validates the v0.3.0 API contract.
