# ADR-002: Pre-existing Bugs Found

## Date
2026-01-15

## Bugs Discovered

### Bug 1: Missing "Jul" in MONTH_NAMES (parser.py)
- **Location:** `logalyzer/parser.py`, line 22-24
- **Issue:** The `MONTH_NAMES` list is missing "Jul" (July). It goes from "Jun" to "Aug".
- **Impact:** `parse_timestamp()` raises `ValueError` for any log line with a July date.
- **Test affected:** `test_timestamp_july_parses_correctly` in `tests/test_parser.py` fails.
- **Action:** Documented. Not fixed (out of scope). The test is a starter test that fails due to a production bug.

### Bug 2: Deprecated import in filters.py
- **Location:** `logalyzer/filters.py`, line 5
- **Issue:** `from collections import Iterable` was removed in Python 3.3+ (moved to `collections.abc`). Python 3.11 raises `ImportError`.
- **Impact:** The entire `filters.py` module cannot be imported. `test_filters.py` fails to collect.
- **Action:** Documented. Not fixed (out of scope). Cannot write new tests for filters.py because the module cannot be imported.

## Rationale for Not Fixing
The task explicitly states: "No production code changes. The /logalyzer/ package files at the end must be byte-identical to the input." These are pre-existing bugs in the starter codebase. We document them but do not fix them.

## Consequences
- `test_filters.py` cannot be run at all (collection error)
- `test_timestamp_july_parses_correctly` fails (pre-existing bug)
- Our new tests must work around these issues where applicable
