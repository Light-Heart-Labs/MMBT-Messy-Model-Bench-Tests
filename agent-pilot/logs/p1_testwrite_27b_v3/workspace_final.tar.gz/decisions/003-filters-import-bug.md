# ADR-003: Approach to filters.py Import Bug

## Date
2026-01-15

## Problem
`logalyzer/filters.py` has `from collections import Iterable` which fails on Python 3.11+. This prevents the entire module from being imported, which means:
1. The existing `test_filters.py` cannot be collected
2. We cannot write new tests for filters.py functions directly

## Decision
We will NOT write new tests for `filters.py` because the module cannot be imported on the target Python version. The existing `test_filters.py` is broken by a production bug, not by our changes.

## Rationale
- The task says "No production code changes" — we cannot fix the import
- Writing tests that monkey-patch the import would be fragile and not "high-value"
- The existing `test_filters.py` already covers the filter logic well (when it works)

## Alternative Considered
- Monkey-patching `collections.Iterable` before import: rejected because it's fragile and tests the workaround, not the code
- Importing via `collections.abc.Iterable` in a test helper: rejected because it changes behavior

## Consequences
- `filters.py` remains at 0% coverage
- Overall coverage will be lower than it could be
- This is documented as a known limitation
