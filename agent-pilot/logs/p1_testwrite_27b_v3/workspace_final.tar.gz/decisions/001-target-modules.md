# ADR-001: Target Modules for Test Coverage

## Date
2026-01-15

## Context
The logalyzer codebase has significant gaps in test coverage. The following modules have 0% or near-0% coverage:

| Module | Coverage | Key Functions |
|--------|----------|---------------|
| `experimental.py` | 0% | `detect_anomalies()`, `session_window()` |
| `output.py` | 0% | `to_json()`, `to_csv()`, `to_text()`, `render_aggregate()` |
| `utils.py` | 0% | `parse_iso_date()`, `format_bytes()`, `format_legacy()`, `chunked()` |
| `io.py` | 0% | `load()`, `load_iter()` |
| `cli.py` | 0% | `build_parser()`, `main()` |
| `filters.py` | 0% | All filter functions (but import error prevents collection) |

## Decision
Target all six modules above for new test coverage. Priority order:
1. `experimental.py` — completely untested, has interesting edge cases (empty input, single entry, anomaly detection math)
2. `output.py` — 0% coverage, `format_legacy()` specifically called out as uncovered
3. `utils.py` — 0% coverage, edge cases for `format_bytes()` (large numbers, zero, negative), `chunked()` (empty, single item)
4. `io.py` — 0% coverage, file I/O edge cases (empty file, no trailing newline, binary content)
5. `cli.py` — 0% coverage, integration-level testing via `main()`
6. `filters.py` — 0% coverage, but has a pre-existing import bug (see ADR-003)

## Rationale
These modules represent the bulk of untested code. Testing them provides the most coverage delta per test written. Edge cases in `experimental.py` (empty entries, single-entry anomaly detection) and `utils.py` (byte formatting boundaries) are particularly valuable because they exercise math and boundary logic.

## Consequences
- Coverage will increase significantly (estimated from 24% to 60%+)
- We will discover and document bugs without fixing them
- The `filters.py` import bug means we can only test it indirectly or work around it
