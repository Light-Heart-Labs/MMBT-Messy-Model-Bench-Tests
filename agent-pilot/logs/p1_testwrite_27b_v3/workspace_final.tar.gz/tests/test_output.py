"""Tests for output.py — JSON, CSV, text formatters and render_aggregate.

These tests exercise the output module which had 0% coverage.
Focus on edge cases: empty entries, special characters, format variations.
"""
from __future__ import annotations

from datetime import datetime, timezone
from collections import Counter

from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.parser import LogEntry


def _entry(**kw) -> LogEntry:
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── to_json ───────────────────────────────────────────────────────────────


class TestToJson:
    """Tests for to_json() — JSON array output."""

    def test_empty_entries_returns_empty_array(self):
        """No entries → empty JSON array."""
        assert to_json([]) == "[]"

    def test_single_entry_produces_valid_json_array(self):
        """A single entry produces a JSON array with one object."""
        entries = [_entry()]
        result = to_json(entries)
        assert result.startswith("[")
        assert result.endswith("]")
        assert '"ip":"10.0.0.1"' in result
        assert '"status":200' in result
        assert '"bytes":100' in result

    def test_multiple_entries_all_in_array(self):
        """Multiple entries produce a JSON array with all entries."""
        entries = [_entry(ip="10.0.0.1"), _entry(ip="10.0.0.2")]
        result = to_json(entries)
        assert '"ip":"10.0.0.1"' in result
        assert '"ip":"10.0.0.2"' in result

    def test_zero_bytes_rendered_as_0(self):
        """Entries with 0 bytes should show bytes:0."""
        entries = [_entry(bytes=0)]
        result = to_json(entries)
        assert '"bytes":0' in result

    def test_iso_timestamp_format(self):
        """Timestamps should be in ISO format."""
        entries = [_entry()]
        result = to_json(entries)
        assert "2026-01-01T12:00:00" in result

    def test_all_fields_present(self):
        """All LogEntry fields should appear in the JSON output."""
        entries = [_entry()]
        result = to_json(entries)
        for field in ("ip", "user", "timestamp", "method", "url", "protocol", "status", "bytes"):
            assert f'"{field}"' in result


# ── to_csv ────────────────────────────────────────────────────────────────


class TestToCsv:
    """Tests for to_csv() — CSV output."""

    def test_empty_entries_returns_header_only(self):
        """No entries → CSV with header row only."""
        result = to_csv([])
        assert "ip,user,timestamp,method,url,protocol,status,bytes" in result
        lines = result.strip().split("\n")
        assert len(lines) == 1

    def test_single_entry_has_header_and_data(self):
        """A single entry produces header + one data row."""
        entries = [_entry()]
        result = to_csv(entries)
        lines = result.strip().split("\n")
        assert len(lines) == 2
        assert "ip,user,timestamp" in lines[0]

    def test_multiple_entries_all_rows_present(self):
        """Multiple entries produce corresponding CSV rows."""
        entries = [_entry(ip="10.0.0.1"), _entry(ip="10.0.0.2")]
        result = to_csv(entries)
        lines = result.strip().split("\n")
        assert len(lines) == 3  # header + 2 data rows

    def test_csv_uses_proper_quoting_for_special_chars(self):
        """URLs with commas should be properly quoted in CSV."""
        entries = [_entry(url="/path,with,commas")]
        result = to_csv(entries)
        assert '"/path,with,commas"' in result


# ── to_text ───────────────────────────────────────────────────────────────


class TestToText:
    """Tests for to_text() — plain text output."""

    def test_empty_entries_returns_empty_string(self):
        """No entries → empty string."""
        assert to_text([]) == ""

    def test_single_entry_produces_one_line(self):
        """A single entry produces one line of text."""
        entries = [_entry()]
        result = to_text(entries)
        lines = result.split("\n")
        assert len(lines) == 1
        assert "10.0.0.1" in lines[0]
        assert "GET" in lines[0]
        assert "200" in lines[0]

    def test_multiple_entries_one_line_each(self):
        """Multiple entries produce one line each, joined by newlines."""
        entries = [_entry(ip="10.0.0.1"), _entry(ip="10.0.0.2")]
        result = to_text(entries)
        lines = result.split("\n")
        assert len(lines) == 2

    def test_ip_right_aligned(self):
        """IP addresses should be right-aligned in the output."""
        entries = [_entry(ip="1.2.3.4"), _entry(ip="10.20.30.40")]
        result = to_text(entries)
        # Both IPs should appear in the output
        assert "1.2.3.4" in result
        assert "10.20.30.40" in result


# ── render_aggregate ──────────────────────────────────────────────────────


class TestRenderAggregate:
    """Tests for render_aggregate() — aggregate result rendering."""

    def test_text_format_with_counter(self):
        """Counter objects should render as key\tvalue lines."""
        agg = Counter({"200": 10, "404": 3})
        result = render_aggregate(agg, fmt="text")
        assert "200\t10" in result
        assert "404\t3" in result

    def test_text_format_with_dict(self):
        """Dict-like objects should render as key\tvalue lines."""
        agg = {"a": 1, "b": 2}
        result = render_aggregate(agg, fmt="text")
        assert "a\t1" in result
        assert "b\t2" in result

    def test_text_format_with_list_of_tuples(self):
        """List of (key, value) tuples should render as key\tvalue lines."""
        agg = [("200", 10), ("404", 3)]
        result = render_aggregate(agg, fmt="text")
        assert "200\t10" in result
        assert "404\t3" in result

    def test_json_format_with_counter(self):
        """Counter objects should render as JSON-like key:value pairs."""
        agg = Counter({"200": 10, "404": 3})
        result = render_aggregate(agg, fmt="json")
        assert '"200":10' in result
        assert '"404":3' in result

    def test_json_format_with_list_of_tuples(self):
        """List of tuples should render as JSON-like key:value pairs."""
        agg = [("200", 10), ("404", 3)]
        result = render_aggregate(agg, fmt="json")
        assert '"200":10' in result
        assert '"404":3' in result

    def test_unknown_format_raises_value_error(self):
        """An unknown format string should raise ValueError."""
        agg = {"a": 1}
        try:
            render_aggregate(agg, fmt="xml")
            assert False, "Expected ValueError"
        except ValueError as e:
            assert "unknown format" in str(e)

    def test_default_format_is_text(self):
        """When fmt is not specified, default should be 'text'."""
        agg = Counter({"200": 10})
        result = render_aggregate(agg)
        assert "200\t10" in result
