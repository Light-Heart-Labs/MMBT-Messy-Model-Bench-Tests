"""Tests for experimental.py — anomaly detection and session windowing.

These tests exercise the experimental module which had 0% coverage.
Focus on edge cases: empty input, single entries, boundary conditions.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts: datetime, ip: str = "10.0.0.1") -> LogEntry:
    """Helper to create a LogEntry with a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )


# ── detect_anomalies ──────────────────────────────────────────────────────


class TestDetectAnomalies:
    """Tests for detect_anomalies() — z-score anomaly detection."""

    def test_empty_input_returns_empty_list(self):
        """No entries → no anomalies."""
        assert detect_anomalies([]) == []

    def test_single_entry_returns_empty(self):
        """A single entry has zero std-dev, so threshold equals the mean.
        The count (1) is not > threshold (1), so no anomalies."""
        entries = [_entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))]
        assert detect_anomalies(entries) == []

    def test_uniform_traffic_no_anomalies(self):
        """When every minute has the same count, std=0, threshold=mean.
        No bucket exceeds the threshold."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
        assert detect_anomalies(entries) == []

    def test_spike_detected_as_anomaly(self):
        """A minute with many more requests than others should be flagged.

        The z-score threshold is mean + 3*std. With 100 baseline minutes
        at 1 request each and a spike of 1000, the spike exceeds the
        threshold (mean=11, std≈99.5, threshold≈309.5, spike=1001).
        """
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        # 100 minutes with 1 request each
        entries = [_entry(base + timedelta(minutes=i)) for i in range(100)]
        # Add 1000 requests in one minute (minute 50)
        spike_time = base + timedelta(minutes=50)
        entries += [_entry(spike_time) for _ in range(1000)]
        anomalies = detect_anomalies(entries)
        assert spike_time in anomalies

    def test_buckets_by_minute_not_second(self):
        """Entries within the same minute should be bucketed together."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        # Two entries in the same minute but different seconds
        entries = [
            _entry(base),
            _entry(base + timedelta(seconds=30)),
        ]
        anomalies = detect_anomalies(entries)
        # Both in same bucket, so count=2 for that minute.
        # With only one bucket, std=0, so no anomaly.
        assert anomalies == []

    def test_multiple_anomalous_minutes(self):
        """Multiple minutes can be anomalous simultaneously."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        # 100 baseline minutes
        entries = [_entry(base + timedelta(minutes=i)) for i in range(100)]
        # Spike at minutes 3 and 17
        for _ in range(500):
            entries.append(_entry(base + timedelta(minutes=3)))
            entries.append(_entry(base + timedelta(minutes=17)))
        anomalies = detect_anomalies(entries)
        assert base + timedelta(minutes=3) in anomalies
        assert base + timedelta(minutes=17) in anomalies

    def test_returns_list_of_datetimes(self):
        """Anomaly buckets should be datetime objects (minute-truncated)."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [_entry(base + timedelta(minutes=i)) for i in range(50)]
        entries += [_entry(base) for _ in range(500)]
        anomalies = detect_anomalies(entries)
        for a in anomalies:
            assert isinstance(a, datetime)
            assert a.second == 0
            assert a.microsecond == 0

    def test_zero_std_dev_no_false_positives(self):
        """When all buckets have identical counts, std=0 and threshold=mean.
        No bucket should exceed its own count."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        # 3 minutes, each with exactly 2 requests
        entries = []
        for i in range(3):
            t = base + timedelta(minutes=i)
            entries.append(_entry(t))
            entries.append(_entry(t))
        assert detect_anomalies(entries) == []

    def test_boundary_value_not_flagged(self):
        """A bucket whose count exactly equals the threshold is NOT flagged.
        The code uses strict > (not >=), so boundary values pass through."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        # 10 minutes with 1 request each, spike of 100 at minute 5
        # This gives: values=[1]*9 + [101], mean=11, std=30, threshold=101
        # 101 is NOT > 101, so no anomaly
        entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
        spike_time = base + timedelta(minutes=5)
        entries += [_entry(spike_time) for _ in range(100)]
        anomalies = detect_anomalies(entries)
        assert spike_time not in anomalies
