"""Tests for utils.py — utility functions.

These tests exercise utils.py which had 0% coverage.
Focus on edge cases: boundary values for format_bytes, empty chunked,
invalid ISO dates, and the legacy format_legacy function.
"""
from __future__ import annotations

from datetime import datetime, timezone

from logalyzer.utils import parse_iso_date, format_bytes, format_legacy, chunked
from logalyzer.parser import LogEntry


def _entry(**kw) -> LogEntry:
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── parse_iso_date ────────────────────────────────────────────────────────


class TestParseIsoDate:
    """Tests for parse_iso_date() — YYYY-MM-DD parsing."""

    def test_valid_date(self):
        """A valid ISO date string parses correctly."""
        dt = parse_iso_date("2026-01-15")
        assert dt.year == 2026
        assert dt.month == 1
        assert dt.day == 15
        assert dt.hour == 0
        assert dt.minute == 0
        assert dt.second == 0
        assert dt.tzinfo is timezone.utc

    def test_leap_year_date(self):
        """A leap year date like 2024-02-29 should parse."""
        dt = parse_iso_date("2024-02-29")
        assert dt.month == 2
        assert dt.day == 29

    def test_invalid_date_raises_value_error(self):
        """An invalid date string should raise ValueError."""
        try:
            parse_iso_date("not-a-date")
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_out_of_range_month_raises_value_error(self):
        """Month 13 should raise ValueError."""
        try:
            parse_iso_date("2026-13-01")
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_nonexistent_day_raises_value_error(self):
        """Feb 30 should raise ValueError."""
        try:
            parse_iso_date("2026-02-30")
            assert False, "Expected ValueError"
        except ValueError:
            pass

    def test_returns_utc_datetime(self):
        """The returned datetime should be in UTC timezone."""
        dt = parse_iso_date("2026-06-15")
        assert dt.tzinfo is timezone.utc


# ── format_bytes ──────────────────────────────────────────────────────────


class TestFormatBytes:
    """Tests for format_bytes() — human-readable byte formatting."""

    def test_zero_bytes(self):
        """Zero bytes should format as '0.0 B'."""
        assert format_bytes(0) == "0.0 B"

    def test_small_bytes(self):
        """Values under 1024 should be in bytes."""
        assert format_bytes(500) == "500.0 B"

    def test_exactly_1024_is_kb(self):
        """1024 bytes should format as '1.0 KB'."""
        assert format_bytes(1024) == "1.0 KB"

    def test_exactly_1024_squared_is_mb(self):
        """1024*1024 bytes should format as '1.0 MB'."""
        assert format_bytes(1024 * 1024) == "1.0 MB"

    def test_exactly_1024_cubed_is_gb(self):
        """1024^3 bytes should format as '1.0 GB'."""
        assert format_bytes(1024 ** 3) == "1.0 GB"

    def test_exactly_1024_to_fourth_is_tb(self):
        """1024^4 bytes should format as '1.0 TB'."""
        assert format_bytes(1024 ** 4) == "1.0 TB"

    def test_very_large_value_exceeds_tb(self):
        """Values larger than 1024^4 should still produce output
        (the function has a fallback path after the loop)."""
        result = format_bytes(1024 ** 5)
        # The loop exits after TB, so 1024^5 / 1024 = 1024 TB
        # But the loop only goes up to TB, so it returns "1024.0 TB"
        assert "TB" in result

    def test_fractional_kb(self):
        """1500 bytes should format as ~1.5 KB."""
        result = format_bytes(1500)
        assert "KB" in result
        assert "1.5" in result

    def test_fractional_mb(self):
        """1.5 MB worth of bytes should show ~1.5 MB."""
        result = format_bytes(int(1.5 * 1024 * 1024))
        assert "MB" in result

    def test_one_byte(self):
        """A single byte should format as '1.0 B'."""
        assert format_bytes(1) == "1.0 B"

    def test_just_under_kb_boundary(self):
        """1023 bytes should still be in B, not KB."""
        assert format_bytes(1023) == "1023.0 B"


# ── format_legacy ─────────────────────────────────────────────────────────


class TestFormatLegacy:
    """Tests for format_legacy() — legacy v0.1 output format.

    This function is marked as legacy but still exists in the codebase.
    We test it to ensure coverage and document its behavior.
    """

    def test_basic_format(self):
        """format_legacy produces 'ip | timestamp | status | url'."""
        entry = _entry()
        result = format_legacy(entry)
        assert "10.0.0.1" in result
        assert "200" in result
        assert "/" in result

    def test_pipe_delimited(self):
        """Fields are separated by ' | '."""
        entry = _entry()
        result = format_legacy(entry)
        parts = result.split(" | ")
        assert len(parts) == 4

    def test_field_order(self):
        """Field order is: ip, timestamp, status, url."""
        entry = _entry(ip="1.2.3.4", status=404, url="/test")
        result = format_legacy(entry)
        parts = result.split(" | ")
        assert parts[0] == "1.2.3.4"
        assert parts[2] == "404"
        assert parts[3] == "/test"

    def test_timestamp_is_iso_format(self):
        """The timestamp in legacy format uses isoformat()."""
        entry = _entry()
        result = format_legacy(entry)
        assert "2026-01-01T12:00:00" in result


# ── chunked ───────────────────────────────────────────────────────────────


class TestChunked:
    """Tests for chunked() — sequence chunking utility."""

    def test_empty_sequence(self):
        """An empty sequence produces no chunks."""
        result = list(chunked([], 3))
        assert result == []

    def test_single_chunk(self):
        """A sequence smaller than chunk size produces one chunk."""
        result = list(chunked([1, 2], 3))
        assert result == [[1, 2]]

    def test_exact_multiple(self):
        """A sequence exactly divisible by chunk size produces full chunks."""
        result = list(chunked([1, 2, 3, 4, 5, 6], 3))
        assert result == [[1, 2, 3], [4, 5, 6]]

    def test_remainder_chunk(self):
        """A sequence not evenly divisible produces a smaller final chunk."""
        result = list(chunked([1, 2, 3, 4, 5], 3))
        assert result == [[1, 2, 3], [4, 5]]

    def test_chunk_size_one(self):
        """Chunk size of 1 produces one-element chunks."""
        result = list(chunked([1, 2, 3], 1))
        assert result == [[1], [2], [3]]

    def test_chunk_size_larger_than_sequence(self):
        """Chunk size larger than sequence length produces one chunk."""
        result = list(chunked([1, 2], 100))
        assert result == [[1, 2]]

    def test_works_with_generator(self):
        """chunked should work with any iterable, including generators."""
        def gen():
            yield 1
            yield 2
            yield 3
            yield 4
        result = list(chunked(gen(), 2))
        assert result == [[1, 2], [3, 4]]

    def test_works_with_strings(self):
        """chunked works with string iterables (each char is an item)."""
        result = list(chunked("abcde", 2))
        assert result == [["a", "b"], ["c", "d"], ["e"]]

    def test_single_element_sequence(self):
        """A single element produces one chunk with one element."""
        result = list(chunked([42], 5))
        assert result == [[42]]
