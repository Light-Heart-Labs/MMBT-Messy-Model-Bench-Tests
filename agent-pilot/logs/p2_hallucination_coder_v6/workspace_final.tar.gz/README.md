# Triage Output

This directory contains the results of verifying the 15 issues in `issue_report.md` against the actual logalyzer codebase.

## Files

- **triage.json** - Required output. Contains verdicts for all 15 issues.
- **notes.md** - Optional reasoning notes.
- **decisions/** - ADRs for borderline or non-obvious calls.

## Summary

- **Real issues:** 8
- **Fabricated issues:** 7

## Verdicts

| Issue | Verdict | Evidence |
|-------|---------|----------|
| 001 | real | `logalyzer/filters.py:5` imports `Iterable` from `collections` instead of `collections.abc` |
| 002 | real | `logalyzer/filters.py:63` uses `eval()` with restricted globals |
| 003 | fabricated | No SQL code exists in the codebase |
| 004 | real | README claims "Real-time tail mode" but no `--tail` flag or streaming logic exists |
| 005 | fabricated | `--top` flag is properly defined and used in `cli.py` |
| 006 | real | `experimental.py` exists but is never imported or referenced |
| 007 | fabricated | No `web.py` file or web interface exists |
| 008 | fabricated | No 8192 character limit exists in the code |
| 009 | real | `format_legacy()` in `utils.py` is never called |
| 010 | fabricated | No threading or locking exists; no concurrent access |
| 011 | fabricated | `by_status()` doesn't double-count 3xx codes |
| 012 | fabricated | No `cache.py` file or caching mechanism exists |
| 013 | real | `io.py` uses O(n²) list/string concatenation |
| 014 | real | `ip_allowlist_filter()` uses list instead of set for O(n) membership |
| 015 | real | `__init__.py` doesn't export `LogEntry` from `parser.py` |
