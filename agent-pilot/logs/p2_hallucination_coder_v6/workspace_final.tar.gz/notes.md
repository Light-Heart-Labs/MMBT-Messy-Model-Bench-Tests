# Triage Notes

## Issue 001: `collections.Iterable` import
**Status: real**

The file `/input/repo/logalyzer/filters.py` line 5 imports `Iterable` from `collections`:
```python
from collections import Iterable  # used by some downstream callers; ensure compatibility
```

This raises `ImportError` on Python 3.10+ because `Iterable` was removed from `collections` and moved to `collections.abc`.

## Issue 002: `eval()` usage
**Status: real**

The file `/input/repo/logalyzer/filters.py` line 63 uses `eval()`:
```python
return bool(eval(expr, {"__builtins__": {}}, {"entry": entry}))
```

This is a security concern even with restricted globals.

## Issue 003: SQL injection
**Status: fabricated**

No SQL-related code exists in the codebase. The report mentions `parser.py` line 42, but there's no SQL query construction anywhere.

## Issue 004: README claims "Real-time tail mode"
**Status: real**

The README.md claims "Real-time tail mode for live log streams" but:
- No `--tail` flag exists in cli.py
- No streaming/tail logic exists in any module

## Issue 005: `--top` flag broken
**Status: fabricated**

The `--top` flag is defined in cli.py line 27:
```python
p.add_argument("--top", type=int, default=None, help="Limit aggregate results to top N")
```

It's used correctly in line 63:
```python
agg = by_url(entries, top=args.top)
```

No `AttributeError` occurs.

## Issue 006: `experimental.py` unused
**Status: real**

No module imports from `experimental.py`. It's not referenced anywhere in the codebase.

## Issue 007: Missing CSRF validation
**Status: fabricated**

No `web.py` file exists in the codebase. No web interface or POST endpoints exist.

## Issue 008: Line truncation at 8192 chars
**Status: fabricated**

No 8192 character limit exists in the codebase. The `parse_line()` function processes the full line.

## Issue 009: `format_legacy()` unused
**Status: real**

The `format_legacy()` function in `/input/repo/logalyzer/utils.py` exists but is never called by any other module.

## Issue 010: Race condition in `load_iter()`
**Status: fabricated**

No threading or locking exists in the codebase. The report mentions concurrent access but no such usage exists.

## Issue 011: `by_status()` double-counts 3xx
**Status: fabricated**

The `by_status()` function simply counts status codes:
```python
c[e.status] += 1
```

There's no special handling or double-counting of 3xx codes. The report mentions `chain()` but no chaining logic exists.

## Issue 012: Cache doesn't invalidate on rotation
**Status: fabricated**

No `cache.py` file exists in the codebase. No caching mechanism exists.

## Issue 013: O(n²) performance in `load()`
**Status: real**

The file `/input/repo/logalyzer/io.py` uses inefficient list concatenation:
```python
result = result + [entry]
```

And string concatenation:
```python
accumulated = accumulated + ch
```

Both are O(n²) operations.

## Issue 014: `ip_allowlist_filter()` uses list instead of set
**Status: real**

The `ip_allowlist_filter()` function uses `entry.ip in allowlist` where `allowlist` is typically a list from `args.ip`. This is O(n) per check instead of O(1) for a set.

## Issue 015: `LogEntry` not exported from `__init__.py`
**Status: real**

The file `/input/repo/logalyzer/__init__.py` does not import or export `LogEntry` from `parser.py`. The report is correct that this would cause import failures if someone tried `from logalyzer import LogEntry`.
