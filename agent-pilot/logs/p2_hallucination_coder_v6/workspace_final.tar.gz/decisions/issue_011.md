# Decision: Issue 011 (by_status double-counts 3xx) is Fabricated

## Reasoning

The issue report claims that `by_status()` double-counts 3xx redirects when called with chained iterators. Upon inspection:

1. `by_status()` simply counts status codes: `c[e.status] += 1`
2. No special handling for 3xx codes exists
3. No `chain()` usage exists in the codebase
4. The Counter naturally deduplicates by key

The report is fabricating a bug. The code correctly counts each status code once per entry.
