# Decision: line_count() Returns Total Quantity

## Context

The `Cart.line_count()` method had its behavior changed in v0.3.0 to return the number of lines instead of the total quantity across lines. This change was documented in the CHANGELOG as a breaking change.

However, the test suite expects `line_count()` to return the total quantity (sum of all `qty` values across lines).

## Decision

We chose to fix the implementation to match the test expectations (returning total quantity) rather than updating the tests.

## Rationale

1. **Test as source of truth**: The constraint states "The test suite was right before someone made a change" and explicitly forbids disabling tests. This means tests are the authoritative specification for expected behavior.

2. **Semantic clarity**: The name `line_count()` is ambiguous - it could mean "number of lines" or "count of items in lines". The test suggests the latter (total quantity) is the intended meaning.

3. **Backward compatibility**: The v0.3.0 CHANGELOG entry may have been documenting an incorrect or incomplete change. By reverting to the test-expected behavior, we restore compatibility with existing test expectations.

4. **Minimal changes**: Fixing the implementation is simpler than potentially breaking other code that might rely on the current test behavior.

## Alternative Considered

Update the test to match the v0.3.0 behavior (returning number of lines). This was rejected because:
- It violates the constraint "Don't disable tests"
- It would require understanding and updating all test expectations
- The test name `test_line_count_matches_qty_sum` clearly indicates it should sum quantities

## Consequences

- The v0.3.0 CHANGELOG entry about `line_count()` is effectively incorrect or incomplete
- Users of v0.3.0 who relied on the new "number of lines" behavior may need to adjust
- The method name `line_count()` remains somewhat ambiguous, but the implementation now matches test expectations
