"""discountkit — tiny discount/cart library used to exercise CI debugging."""
from .cart import Cart, CartLine
from .discount import apply_discount, discount_amount

__all__ = ["apply_discount", "discount_amount", "Cart", "CartLine"]
__version__ = "0.3.1"
