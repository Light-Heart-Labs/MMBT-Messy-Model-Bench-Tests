# Research Notes — Password Manager Evaluation

## Date: 2025-06-18

## Products Evaluated
1. **1Password** (Business tier)
2. **Bitwarden** (Teams & Enterprise tiers)
3. **LastPass** (Business tier)
4. **Dashlane** (Business tier)
5. **Keeper** (Business tier)

## Methodology
- Visited each product's pricing page via HTTP requests and Playwright (headless browser)
- Cross-referenced with Wikipedia for security incident history
- Checked trust/compliance pages for SOC 2, ISO, FedRAMP certifications
- Used Wayback Machine for products blocking headless browsers
- Examined GitHub for CLI/developer tool availability

## Key Findings

### Pricing (per user, per month, annual billing)
| Product | Tier | Price | Source |
|---------|------|-------|--------|
| 1Password | Business | $7.99 | 1password.com/pricing/ (scraped 2025-06-18) |
| Bitwarden | Teams | $4.00 | bitwarden.com/pricing/business/ (scraped 2025-06-18) |
| Bitwarden | Enterprise | $6.00 | bitwarden.com/pricing/business/ (scraped 2025-06-18) |
| Dashlane | Business | $8.00 | dashlane.com/pricing (Playwright, 2025-06-18) |
| LastPass | Business | Not publicly listed | lastpass.com/pricing/ (template variables only) |
| Keeper | Business | Starting at $2.00 | keepersecurity.com/pricing/ (meta description, Wayback 2024) |

### Compliance
| Product | SOC 2 | ISO 27001 | FedRAMP | HIPAA |
|---------|-------|-----------|---------|-------|
| 1Password | Type II ✓ | 27001, 27017, 27018, 27701 ✓ | Not listed | Not a BA (zero-knowledge) |
| Bitwarden | Type II ✓ | ✓ | Not listed | ✓ |
| LastPass | Not verified | Not verified | Not verified | Not verified |
| Dashlane | Not verified | Not verified | Not verified | Not verified |
| Keeper | Not verified | Not verified | Not verified | Not verified |

### Security Incident History
- **LastPass**: Multiple breaches (2011, 2015, 2021, 2022 major breach with vault data exfiltration, $24.5M class action settlement in 2025, ETH Zurich 2026 study found zero-knowledge bypass vulnerabilities)
- **1Password**: 2017 Android vulnerabilities (fixed), 2023 Okta customer service breach (no user data compromised), 2025 DEF CON clickjacking vulnerability
- **Dashlane**: 2024 injection attack vulnerability, 2025 DEF CON clickjacking vulnerability (patched in v6.2531.1)
- **Bitwarden**: No major public breaches; open source codebase allows community auditing
- **Keeper**: No major public breaches identified

### Platform Coverage
| Product | macOS | Windows | Linux | iOS | Android | Browser | CLI |
|---------|-------|---------|-------|-----|---------|---------|-----|
| 1Password | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Bitwarden | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| LastPass | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✗ |
| Dashlane | ✓ | ✓ | ✗ | ✓ | ✓ | ✓ | ✓ |
| Keeper | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |

### SSO Integration
- **1Password**: Okta, Entra ID, OneLogin, Duo, Google Workspace, SCIM
- **Bitwarden**: SSO integration (Enterprise), Directory integration (Teams+)
- **LastPass**: Microsoft AD, Azure AD, Google Workspace, Ping Identity, OneLogin, Okta
- **Dashlane**: SSO & SCIM, IdP integration
- **Keeper**: SSO Connect, Azure AD, SAML 2.0

### Developer Tools
- **1Password**: CLI, SDK, SSH key signing, Git commit signing, Secrets Management
- **Bitwarden**: CLI, API, open source, self-hosting, Secrets Manager (separate product)
- **LastPass**: No native CLI
- **Dashlane**: API & CLI
- **Keeper**: Commander SDK, Secrets Manager

## Decision Notes
- LastPass eliminated due to severe security incident history and lack of transparent pricing
- Keeper eliminated due to opaque pricing (contact sales required) and inability to verify compliance claims
- Dashlane eliminated due to lack of Linux support (critical for engineering team) and lack of publicly verifiable compliance certifications
- Final comparison: 1Password Business vs. Bitwarden Enterprise
