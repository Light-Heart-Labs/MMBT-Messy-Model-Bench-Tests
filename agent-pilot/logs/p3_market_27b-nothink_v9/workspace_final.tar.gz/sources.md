# Sources
## URLs Fetched During Research
## Date: 2025-06-18

---

## 1Password

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 1 | https://1password.com/pricing/ | 2025-06-18 | Pricing page. Extracted Business tier at $7.99/user/month (annual billing), Teams Starter Pack at $19.95/month (up to 10 users), Individual at $2.99/month, Families at $4.49/month. |
| 2 | https://1password.com/security/ | 2025-06-18 | Security page. Confirmed SOC 2 Type II certification, zero-knowledge architecture, dual-key encryption (password + Secret Key), SRP protocol for transit encryption. |
| 3 | https://1password.com/legal/ | 2025-06-18 | Legal Center. Confirmed ISO 27001, 27017, 27018, 27701 certifications. SOC 2 Type II. HIPAA: not a Business Associate (zero-knowledge). |
| 4 | https://1password.com/trust/ | 2025-06-18 | Trust Center (404 — page not found). |
| 5 | https://en.wikipedia.org/wiki/1Password | 2025-06-18 | Wikipedia article. Security history: 2017 Android vulnerabilities (fixed), 2023 Okta breach (no user data compromised), 2025 DEF CON clickjacking vulnerability. ARR: $400M+ (Nov 2025). |

## Bitwarden

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 6 | https://bitwarden.com/pricing/ | 2025-06-18 | Pricing page. Free tier, Premium at $1.65/month, Families at $3.99/month. |
| 7 | https://bitwarden.com/pricing/business/ | 2025-06-18 | Business pricing page. Teams at $4.00/user/month (annual), Enterprise at $6.00/user/month (annual). |
| 8 | https://bitwarden.com/compliance/ | 2025-06-18 | Compliance page. SOC 2 Type II, SOC 3, ISO 27001, HIPAA compliant, GDPR compliant, CCPA/CPRA compliant, Data Privacy Framework compliant. Open source, annual third-party audits, HackerOne bug bounty. |
| 9 | https://bitwarden.com/security/ | 2025-06-18 | Security page (redirected to compliance page). |
| 10 | https://en.wikipedia.org/wiki/Bitwarden | 2025-06-18 | Wikipedia article. No major security incidents. PC Magazine criticized business tier pricing as too high. |

## LastPass

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 11 | https://lastpass.com/pricing/ | 2025-06-18 | Pricing page. Heavily JS-rendered, no pricing data in static HTML. |
| 12 | https://lastpass.com/fp/business/ | 2025-06-18 | Business pricing page. Blocks headless browsers. No pricing data extractable. |
| 13 | https://web.archive.org/web/2023/https://lastpass.com/pricing/ | 2025-06-18 | Wayback Machine snapshot. Pricing uses template variables ({LPPremium}, {LPBusiness}, etc.) — not resolved. Shows plan structure: Free, Premium, Families, Teams, Business. |
| 14 | https://en.wikipedia.org/wiki/LastPass | 2025-06-18 | Wikipedia article. Extensive security incident history: 2011 intrusion, 2015 breach (hashes/salts), 2017 Android vulnerabilities, 2021 trackers + master password compromise, **2022 major breach (vault data exfiltrated, $24.5M settlement)**, 2024 injection attacks, 2025 clickjacking, **2026 ETH Zurich zero-knowledge bypass study**. |

## Dashlane

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 15 | https://www.dashlane.com/pricing | 2025-06-18 | Pricing page. JS-rendered. Playwright extracted: Teams at $4/user/month, Business at $8/user/month (annual billing). |
| 16 | https://www.dashlane.com/security | 2025-06-18 | Security page. Zero-knowledge architecture, AES-256-CBC-HMAC encryption, Argon2d key derivation, AWS Nitro Enclaves (confidential computing), 8 patents held. SSO & SCIM, activity logs, role-based access, API & CLI. |
| 17 | https://www.dashlane.com/trust-center | 2025-06-18 | Trust Center (blocked headless browsers, no content extractable). |
| 18 | https://en.wikipedia.org/wiki/Dashlane | 2025-06-18 | Wikipedia article. 2024 injection attack vulnerability, 2024 password checkup tool study, 2025 DEF CON clickjacking (patched in v6.2531.1). AES-256 encryption. |

## Keeper

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 19 | https://www.keepersecurity.com/pricing/ | 2025-06-18 | Pricing page. Blocks headless browsers. No pricing data in static HTML. |
| 20 | https://web.archive.org/web/2024/https://www.keepersecurity.com/pricing/ | 2025-06-18 | Wayback Machine snapshot. Meta description: "Protect your business starting at just $2/user/month." Pricing loaded dynamically via JavaScript — actual Business tier price not in static HTML. |
| 21 | https://web.archive.org/web/2024/https://www.keepersecurity.com/pricing/business-and-enterprise.html | 2025-06-18 | Wayback Machine snapshot. Same dynamic pricing. Meta description confirms $2/user/month starting price. |
| 22 | https://www.keepersecurity.com/security/ | 2025-06-18 | Security page (404 — page not found). |
| 23 | https://www.keepersecurity.com/gdpr-compliance/ | 2025-06-18 | GDPR compliance page (blocked headless browsers). |

## Third-Party Sources

| # | URL | Timestamp | Description |
|---|-----|-----------|-------------|
| 24 | https://en.wikipedia.org/wiki/LastPass | 2025-06-18 | Security incident history for LastPass. |
| 25 | https://en.wikipedia.org/wiki/1Password | 2025-06-18 | Security incident history for 1Password. |
| 26 | https://en.wikipedia.org/wiki/Dashlane | 2025-06-18 | Security incident history for Dashlane. |
| 27 | https://en.wikipedia.org/wiki/Bitwarden | 2025-06-18 | General info for Bitwarden. |
| 28 | https://en.wikipedia.org/wiki/Keeper_Security | 2025-06-18 | General info for Keeper. |

---

## Notes on Data Quality

- **1Password and Bitwarden**: Pricing and features verified directly from company websites via HTTP scraping. Compliance verified from trust/legal pages.
- **LastPass**: Pricing could not be extracted (template variables, headless browser blocking). Security history verified from Wikipedia.
- **Dashlane**: Pricing extracted via Playwright headless browser. Security info from company website. Compliance certifications could not be independently verified.
- **Keeper**: Pricing could not be extracted (dynamic loading, headless browser blocking). Meta description from Wayback Machine confirms "starting at $2/user/month" but actual Business tier pricing requires contacting sales. Compliance certifications could not be independently verified.
