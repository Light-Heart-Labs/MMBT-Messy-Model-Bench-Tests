# Password Manager Comparison
## 5-Product Side-by-Side Evaluation
## Date: 2025-06-18

---

## Pricing (Annual Billing, Per User, Per Month)

| Feature | 1Password Business | Bitwarden Teams | Bitwarden Enterprise | LastPass Business | Dashlane Business | Keeper Business |
|---------|-------------------|-----------------|---------------------|-------------------|-------------------|-----------------|
| **Price** | $7.99 [1] | $4.00 [2] | $6.00 [2] | Not publicly listed [3] | $8.00 [4] | Starting at $2.00 [5] |
| **50-seat annual cost** | $4,794 | $2,400 | $3,600 | Unknown | $4,800 | Unknown (contact sales) |
| **Free trial** | 14 days [1] | 14 days [2] | 14 days [2] | 14 days [3] | 14 days [4] | 14 days [5] |
| **Minimum seats** | None [1] | None [2] | None [2] | None [3] | None [4] | 5 (Starter) [5] |

---

## Platform Support

| Platform | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|----------|-----------|-----------|----------|----------|--------|
| macOS | ✓ [1] | ✓ [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| Windows | ✓ [1] | ✓ [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| Linux | ✓ [1] | ✓ [2] | ✓ [6] | ✗ [4] | ✓ [5] |
| iOS | ✓ [1] | ✓ [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| Android | ✓ [1] | ✓ [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| Browser Extensions | ✓ [1] | ✓ [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| CLI | ✓ [1] | ✓ [2] | ✗ [6] | ✓ [4] | ✓ [5] |
| Web Vault | ✓ [1] | ✓ [2] | ✓ [6] | ✓ [4] | ✓ [5] |

---

## Enterprise Features

| Feature | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---------|-----------|-----------|----------|----------|--------|
| SSO (SAML 2.0) | ✓ [1] | ✓ (Enterprise) [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| SCIM Provisioning | ✓ [1] | ✓ (Enterprise) [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| Audit Logging | ✓ [1] | ✓ [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| Role-Based Permissions | ✓ [1] | ✓ [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| Custom Policies | ✓ [1] | ✓ (Enterprise) [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| SIEM Integration | ✓ (Splunk, Elastic, Sumo Logic, Panther) [1] | Not natively listed | Not natively listed | ✓ (encrypted audit trails) [4] | ✓ [5] |
| Directory Integration | ✓ (Azure AD, Google Workspace, Okta, OneLogin, Rippling, JumpCloud) [1] | ✓ (Teams+) [2] | ✓ (Microsoft AD, Azure AD, Google Workspace, Ping, OneLogin, Okta) [6] | ✓ [4] | ✓ (Azure AD, SAML 2.0) [5] |
| Guest Accounts | ✓ [1] | ✓ [2] | ✓ [6] | ✓ [4] | ✓ [5] |
| Travel Mode | ✓ [1] | ✗ | ✗ | ✗ | ✗ |
| Self-Hosting | ✗ | ✓ (Enterprise) [2] | ✗ | ✗ | ✗ |

---

## Developer Tools

| Feature | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---------|-----------|-----------|----------|----------|--------|
| CLI | ✓ [1] | ✓ [2] | ✗ [6] | ✓ [4] | ✓ [5] |
| API/SDK | ✓ [1] | ✓ [2] | ✓ [6] | ✓ [4] | ✓ (Commander SDK) [5] |
| SSH Key Signing | ✓ [1] | ✗ | ✗ | ✗ | ✗ |
| Git Commit Signing | ✓ [1] | ✗ | ✗ | ✗ | ✗ |
| Secrets Management | ✓ (built-in) [1] | ✓ (separate product) [2] | ✗ | ✗ | ✓ (separate product) [5] |
| CI/CD Integration | ✓ [1] | ✓ (CLI) [2] | ✗ | ✓ (API) [4] | ✓ [5] |
| Open Source | ✗ | ✓ [2] | ✗ | ✗ | ✗ |

---

## Security & Compliance

| Certification/Feature | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|----------------------|-----------|-----------|----------|----------|--------|
| SOC 2 Type II | ✓ [7] | ✓ [8] | Not verified | Not verified | Not verified |
| ISO 27001 | ✓ [7] | ✓ [8] | Not verified | Not verified | Not verified |
| ISO 27017 (Cloud) | ✓ [7] | Not listed | Not verified | Not verified | Not verified |
| ISO 27018 (Private Data) | ✓ [7] | Not listed | Not verified | Not verified | Not verified |
| ISO 27701 (PII) | ✓ [7] | Not listed | Not verified | Not verified | Not verified |
| HIPAA Compliant | Not a BA (zero-knowledge) [7] | ✓ [8] | Not verified | Not verified | Not verified |
| GDPR Compliant | ✓ [7] | ✓ [8] | Not verified | Not verified | ✓ (GDPR page exists) [5] |
| FedRAMP | Not listed | Not listed | Not verified | Not verified | Not verified |
| Zero-Knowledge Architecture | ✓ [1] | ✓ [8] | ✓ [6] | ✓ [4] | ✓ [5] |
| End-to-End Encryption | ✓ (AES-256, SRP) [1] | ✓ (AES-256, PBKDF2/Argon2) [8] | ✓ (AES-256, PBKDF2) [6] | ✓ (AES-256-CBC-HMAC, Argon2d) [4] | ✓ [5] |
| Bug Bounty Program | ✓ [1] | ✓ (HackerOne) [8] | Not verified | ✓ [4] | ✓ [5] |
| Third-Party Security Audits | ✓ [1] | ✓ (annual) [8] | Not verified | Not verified | Not verified |

---

## Security Incident History

| Product | Incidents |
|---------|-----------|
| **1Password** | 2017: Android vulnerabilities (fixed) [9]. 2023: Okta customer service breach — no user data compromised [9]. 2025: DEF CON clickjacking vulnerability in browser extension (notified April 2025, patch status unclear) [9]. |
| **Bitwarden** | No major public breaches. Open source codebase allows community auditing. [8] |
| **LastPass** | 2011: Possible server intrusion [9]. 2015: Email addresses, password reminders, salts, and auth hashes compromised [9]. 2017: Android vulnerabilities [9]. 2021: Third-party trackers in Android app; master passwords compromised [9]. **2022: Major breach — vault data (partially encrypted) exfiltrated, $24.5M class action settlement in 2025** [9]. 2024: Injection attack vulnerability [9]. 2025: DEF CON clickjacking (patch may be incomplete) [9]. **2026: ETH Zurich study found zero-knowledge bypass vulnerabilities** [9]. |
| **Dashlane** | 2024: Injection attack vulnerability [10]. 2025: DEF CON clickjacking vulnerability (patched in v6.2531.1) [10]. |
| **Keeper** | No major public breaches identified. |

---

## Sources

[1] 1Password pricing page — https://1password.com/pricing/ (scraped 2025-06-18)
[2] Bitwarden pricing page — https://bitwarden.com/pricing/business/ (scraped 2025-06-18)
[3] LastPass pricing page — https://lastpass.com/pricing/ (scraped 2025-06-18; pricing uses template variables, not publicly resolved)
[4] Dashlane pricing page — https://www.dashlane.com/pricing (scraped via Playwright 2025-06-18)
[5] Keeper pricing page — https://www.keepersecurity.com/pricing/ (meta description via Wayback Machine 2024; actual pricing requires contacting sales)
[6] LastPass features — https://lastpass.com/fp/business/ (scraped 2025-06-18; page blocks headless browsers)
[7] 1Password Legal Center — https://1password.com/legal/ (scraped 2025-06-18)
[8] Bitwarden Compliance page — https://bitwarden.com/compliance/ (scraped 2025-06-18)
[9] Wikipedia — https://en.wikipedia.org/wiki/1Password and https://en.wikipedia.org/wiki/LastPass (accessed 2025-06-18)
[10] Wikipedia — https://en.wikipedia.org/wiki/Dashlane (accessed 2025-06-18)
