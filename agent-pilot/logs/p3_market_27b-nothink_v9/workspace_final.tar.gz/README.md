# Password Manager Evaluation — Output Guide

## Overview

This repository contains the results of a comprehensive evaluation of 5 password managers for a 50-person engineering team at a Series-B SaaS company. The team currently has shadow-IT password storage (browser, sticky notes, Slack DMs) and needs a standardized solution within 90 days.

## Files

| File | Description |
|------|-------------|
| `recommendation.md` | **Primary deliverable** — 1-2 page recommendation memo with decision criteria, product recommendation, runner-up, and risk analysis. |
| `comparison.md` | Side-by-side feature/pricing/security comparison of all 5 evaluated products. |
| `sources.md` | Every URL fetched during research, with timestamps and descriptions of what was obtained. |
| `research/notes.md` | Working notes with methodology, key findings, and decision rationale. |
| `decisions/001-product-selection.md` | ADR: Which 5 products were selected and why. |
| `decisions/002-evaluation-criteria.md` | ADR: Decision criteria defined before evaluation. |
| `decisions/003-final-recommendation.md` | ADR: Final recommendation with rationale. |

## How to Read

1. **Start with `recommendation.md`** for the executive summary and final recommendation.
2. **Read `comparison.md`** for the detailed side-by-side comparison.
3. **Check `sources.md`** for source URLs and data quality notes.
4. **Review `decisions/`** for the reasoning behind non-obvious calls.
5. **See `research/notes.md`** for working notes and methodology.

## Recommendation Summary

- **Recommended**: 1Password Business at $7.99/user/month ($4,794/year for 50 seats)
- **Runner-up**: Bitwarden Enterprise at $6.00/user/month ($3,600/year for 50 seats)
- **Eliminated**: LastPass (security breaches), Keeper (opaque pricing), Dashlane (no Linux support)

## Methodology

- HTTP scraping of pricing pages (Python `requests` + `BeautifulSoup`)
- Headless browser rendering (Playwright) for JS-heavy pages
- Wayback Machine for products blocking automated access
- Wikipedia for security incident history
- Cross-referencing of compliance claims against trust/legal pages

## Date

Research conducted: 2025-06-18
