# ADR-002: Evaluation Criteria

## Status
Accepted

## Context
To make an objective recommendation, we defined evaluation criteria before reviewing products. These criteria reflect the needs of a 50-person engineering team at a Series-B SaaS company.

## Decision
The following criteria were established, ranked by importance:

### Critical (Must-Have)
1. **SSO Integration** — Must integrate with Google Workspace (or major IdPs like Okta, Entra ID) for single sign-on. The team uses Google Workspace.
2. **Audit Logging** — Must provide admin-visible audit logs for SOC 2 compliance requirements.
3. **Multi-Platform Support** — Must support macOS, Windows, Linux, iOS, Android, and major browsers. Linux is critical for engineering team.
4. **CLI/Developer Tools** — Must have a command-line interface for CI/CD integration and developer workflows.
5. **Transparent Pricing** — Must have publicly listed per-seat pricing. "Contact sales" pricing is a disqualifier for a Series-B company needing budget predictability.

### Important (Should-Have)
6. **SOC 2 Type II Certification** — Required for SOC 2 compliance at the company level.
7. **SCIM Provisioning** — Automated user provisioning/deprovisioning via SCIM.
8. **Zero-Knowledge Architecture** — End-to-end encryption where the vendor cannot access user data.
9. **Mobile App Quality** — Native iOS and Android apps with biometric unlock.
10. **Security Incident History** — No major data breaches in the past 3 years.

### Nice-to-Have
11. **Open Source** — Code auditable by the team or third parties.
12. **Self-Hosting Option** — Ability to self-host for data sovereignty.
13. **Secrets Management** — Native support for API keys, SSH keys, and CI/CD secrets.
14. **SIEM Integration** — Ability to stream audit logs to SIEM tools (Splunk, etc.).
15. **Passkey Support** — Support for passwordless authentication.

## Consequences
- Products missing any Critical criterion were eliminated
- LastPass eliminated: No CLI, severe security incident history
- Keeper eliminated: Opaque pricing (contact sales), compliance unverifiable
- Dashlane eliminated: No Linux support
- Finalists: 1Password and Bitwarden
