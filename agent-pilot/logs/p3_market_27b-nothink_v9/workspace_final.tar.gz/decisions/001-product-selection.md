# ADR-001: Product Selection for Evaluation

## Status
Accepted

## Context
We need to evaluate password managers for a 50-person engineering team at a Series-B SaaS company. The team currently has shadow-IT password storage (browser, sticky notes, Slack DMs) and the CTO wants this fixed in 90 days.

## Decision
We selected 5 products for evaluation based on:
1. Market presence and adoption in the engineering/tech sector
2. Availability of public pricing information
3. Support for engineering-relevant platforms (Linux, CLI, developer tools)
4. Active maintenance and security posture

### Selected Products
1. **1Password** — Market leader in enterprise password management, strong developer tooling
2. **Bitwarden** — Open-source, strong engineering community adoption, transparent pricing
3. **LastPass** — Historically popular, included for completeness despite known issues
4. **Dashlane** — Popular consumer/business product, included for comparison
5. **Keeper** — Enterprise-focused, included for comparison

### Excluded Products
- **KeePass** — No cloud sync, no admin console, not suitable for 50-person team standardization
- **NordPass** — Primarily consumer-focused, limited enterprise features
- **RoboForm** — Limited market presence, no active developer tooling
- **Avast Passwords** — Consumer-focused, limited enterprise features
- **Enpass** — No cloud sync by default, limited admin features

## Consequences
- LastPass was eliminated during evaluation due to severe security incident history
- Keeper was eliminated due to opaque pricing and inability to verify compliance
- Dashlane was eliminated due to lack of Linux support
- Final recommendation narrowed to 1Password vs. Bitwarden
