# ADR-003: Final Recommendation — 1Password Business

## Status
Accepted

## Context
After evaluating 5 password managers against the criteria defined in ADR-002, two finalists remained: 1Password Business ($7.99/user/month) and Bitwarden Enterprise ($6.00/user/month).

## Decision
**1Password Business** is recommended as the primary choice.

### Rationale
1. **Superior Developer Experience** — 1Password has the most comprehensive developer tooling: CLI, SDK, SSH key signing, Git commit signing, and Secrets Management. This is critical for an engineering team.
2. **Best-in-Class Admin UX** — 1Password's admin console is consistently rated as the most intuitive in the category, reducing onboarding friction for a 90-day rollout.
3. **Strongest Compliance Posture** — SOC 2 Type II, ISO 27001/27017/27018/27701 certifications, with publicly available audit reports.
4. **Clean Security History** — No data breaches. The 2023 Okta incident was contained with no user data compromised.
5. **SIEM Integration** — Native streaming to Splunk, Elastic, Sumo Logic, and Panther.
6. **Extended Access Management** — 1Password's XAM platform provides additional identity governance capabilities that may be valuable as the company scales.

### Why Not Bitwarden?
Bitwarden is the runner-up and would be the better choice if:
- Budget is the primary constraint ($6.00 vs $7.99/user/month = $11,940 annual savings for 50 seats)
- Open source code auditability is a hard requirement
- Self-hosting is required for data sovereignty
- The team prefers a product with a more active open-source community

However, for a Series-B SaaS company prioritizing rapid deployment, developer experience, and compliance readiness, 1Password's polished product and comprehensive feature set justify the premium.

## Consequences
- Annual cost: $7.99 × 50 users × 12 months = $4,794
- 14-day free trial available for evaluation
- Migration tools available from LastPass, Dashlane, and other password managers
- Expected rollout timeline: 2-3 weeks for full team adoption
