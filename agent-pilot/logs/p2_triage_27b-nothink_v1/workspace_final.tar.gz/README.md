# Support Ticket Triage — Results & Methodology

## Overview

30 tickets were triaged from `/input/repo/tickets.txt`. Each ticket was classified into one of 12 categories and assigned an urgency level. Duplicate clusters were identified and linked.

## Quick Stats

| Metric | Value |
|---|---|
| Total tickets | 30 |
| Urgent | 6 |
| Normal | 14 |
| Low | 6 |
| N/A (spam) | 4 |
| Duplicate clusters | 2 |
| Spam/noise | 4 |

## Urgency Breakdown

### 🔴 URGENT (5 tickets) — Act on these first

| Ticket | Category | Summary |
|---|---|---|
| **028** | security-incident | Active account compromise — unauthorized API key usage from foreign IPs. Freeze account MB-8821 immediately. |
| **003** | incident-active | Entire org locked out with 503s on login. Board meeting in progress. Account BC-44218. |
| **016** | incident-active | 30% of POST /api/v2/exports returning 500 since 14:00 UTC. SOC1 review tomorrow. Account PE-5510. |
| **014** | bug-report | API rate limits blocking nightly data ingestion for $48k/yr customer. Follow-ups in 023 and 030. |
| **023** | bug-report | (Duplicate of 014) Rate limit issue recurred. Backlog growing 200 GB/day. Quarterly review deadline. |

> **Note:** Ticket 030 is also urgent but is a third follow-up to 014 — no new information, just escalation pressure.

### 🟡 NORMAL (14 tickets) — Respond within 1 business day

| Ticket | Category | Summary |
|---|---|---|
| 001 | billing-refund | Double charge on Pro plan ($29). Refund one charge. |
| 002 | feature-request | SAML SSO needed to close 60-seat deal. |
| 005 | bug-report | CSV export drops last row when filename has spaces. |
| 006 | account-management | Cancel subscription end of month. No refund needed. |
| 007 | auth-permissions | Shared dashboards show "permission denied" on open. |
| 008 | billing-refund | Pro-rated refund request for Annual plan (4 months used, 8 remaining). |
| 011 | auth-permissions | (Duplicate of 007) Sharer's side of the dashboard permission issue. |
| 013 | billing-refund | Accidental Enterprise upgrade. Wants downgrade + refund of difference. |
| 019 | legal-compliance | GDPR data export request for former user. 30-day window. |
| 020 | bug-report | Date filter excludes today's data even with "include today" checked. |
| 022 | billing-refund | Credit request for 11 hours of weekend downtime during product launch. |
| 024 | bug-report | Webhook receiver returns 200 but events not arriving. |
| 026 | account-management | Add 12 seats, remove 3. Bulk update needed. |
| 027 | bug-report | PDF exports render charts at low resolution (pixelated). |

### 🟢 LOW (6 tickets) — Can be batched

| Ticket | Category | Summary |
|---|---|---|
| 010 | external-business | Podcast sponsorship pitch (18K downloads/month). |
| 012 | feature-request | Schedule weekly email of dashboards as PDFs. |
| 015 | feature-request | Dark mode request. |
| 017 | general-question | New user: CSV import wizard says "no valid columns found." |
| 018 | external-business | Acquisition inquiry from VC-backed analytics platform. |
| 025 | general-question | Non-profit pricing/discount inquiry. |

### ⚫ N/A — Spam/Noise (4 tickets) — Delete or archive

| Ticket | Category | Summary |
|---|---|---|
| 004 | spam-or-noise | Fictitious "free Pixar character collectables" request. |
| 009 | spam-or-noise | Phishing email from noreply@phishing-site.example. |
| 021 | spam-or-noise | Affiliate-link hosting spam. |
| 029 | spam-or-noise | Extortion email demanding $50K BTC for "vulns." |

## Duplicate Clusters

### Cluster 1: Dashboard Sharing Permission Bug
- **007** (original) — jordan.lee@mid-co.com reports can't open shared dashboards
- **011** (duplicate) — alex.petrov@mid-co.com reports the same issue from the sharer's side
- Same account (MC-3309), same team, same symptom

### Cluster 2: API Rate Limit Blocking Ingestion
- **014** (original) — ops@major-customer.com reports nightly 429s during data ingestion
- **023** (duplicate) — Follow-up: issue recurred, backlog growing
- **030** (duplicate) — Third message: still no response, SLA concern
- Same sender (ops@major-customer.com), same account (MC-4221), same issue

## Methodology

1. **Read all 30 tickets first** before classifying — later tickets (023, 030) provided context for 014, and 011 confirmed 007's issue.
2. **Duplicate detection** based on: same sender, same account ID, same underlying issue, or cross-referencing between tickets (007↔011).
3. **Urgency assignment** based on explicit time pressure (board meetings, SOC1 reviews, active outages, security compromises) or implicit impact ($48k contract at risk).
4. **Spam identification** based on: fictitious premises (Pixar collectables), phishing URLs, affiliate-link spam, and extortion demands.

## Ambiguous Calls

See `/workspace/decisions/` for detailed reasoning on non-obvious classifications.

## Recommended Action Order

1. **028** — Freeze account, revoke API keys (security incident)
2. **003** — Investigate login 503s (production outage)
3. **016** — Investigate /api/v2/exports 500s (impending SOC1 review)
4. **014/023/030** — Escalate rate limit issue to engineering + notify account exec
5. **019** — Route GDPR request to legal/compliance team
6. Remaining tickets in normal/low order as capacity allows
