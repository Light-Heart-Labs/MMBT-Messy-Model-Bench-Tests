# ADR-001: Ticket 014 — API Rate Limits: bug-report vs billing-other

## Decision
Classified as **bug-report** with **urgent** urgency.

## Context
Ticket 014 from ops@major-customer.com reports hitting the documented 600 req/min rate limit during nightly data ingestion, causing 4 hours of 429 errors. They're on the Business plan and have a $48k/yr contract.

## Alternatives Considered
- **billing-other**: Could be seen as a plan upgrade inquiry (requesting higher limits). However, the core issue is that the documented limits are insufficient for their use case, and they're asking for a burst allowance or exception — not just a plan change.
- **incident-active**: The 429s are recurring nightly but aren't a platform-wide outage. The impact is contained to this one customer's ingestion pipeline.

## Rationale
This is a product limitation that's actively blocking a high-value customer's operations. The "bug" is that the rate limit configuration doesn't accommodate their documented workload pattern. Marked urgent because:
1. It's actively blocking data ingestion (4 hours of failures per night)
2. A $48k/yr contract is at risk
3. They have a quarterly review deadline approaching
4. Follow-ups (023, 030) show the issue is recurring and escalating

## Action
Route to engineering for rate limit review + notify account executive.

---

# ADR-002: Ticket 029 — Extortion Email: spam-or-noise vs security-incident

## Decision
Classified as **spam-or-noise** with **n/a** urgency.

## Context
Ticket 029 from hacker@blackhat-forum.example demands $50,000 in BTC or they will "post vulns on twitter." Includes a Bitcoin address and a 48-hour deadline.

## Alternatives Considered
- **security-incident**: The sender claims to have found vulnerabilities. However, this is not a legitimate vulnerability disclosure — it's extortion.

## Rationale
This is a classic extortion attempt:
1. The sender's email domain (blackhat-forum.example) is not a legitimate security researcher
2. No proof of vulnerability is provided
3. Payment is demanded in cryptocurrency (BTC)
4. A public shaming threat is used as leverage
5. No responsible disclosure process is being followed

This should NOT be treated as a legitimate security report. It should be archived, and the email forwarded to the legal/security team for record-keeping. Do not engage or pay.

---

# ADR-003: Ticket 007/011 — Dashboard Sharing: Two Tickets, One Issue

## Decision
Ticket 007 is the original; ticket 011 is marked as **duplicate_of: 007**.

## Context
- Ticket 007: jordan.lee@mid-co.com reports seeing shared dashboards in sidebar but getting "permission denied" on open
- Ticket 011: alex.petrov@mid-co.com (the sharer) reports the same issue from their perspective — they set jordan to Editor but it's not working

## Rationale
Both tickets describe the same underlying bug: dashboard sharing permissions are not being applied correctly. Same account (MC-3309), same team, same symptom. The second ticket adds useful context (the sharer's perspective) but doesn't represent a separate issue.

Marked 011 as duplicate_of 007 because 007 was filed first and describes the user-facing impact. The engineering team should review both tickets for complete context.

---

# ADR-004: Ticket 016 — 500 Errors: incident-active vs bug-report

## Decision
Classified as **incident-active** with **urgent** urgency.

## Context
Ticket 016 reports ~30% of POST requests to /api/v2/exports returning 500 since 14:00 UTC today. Status page shows green. SOC1 review tomorrow morning depends on exports completing.

## Alternatives Considered
- **bug-report**: This could be a new bug in the exports endpoint. However, the key differentiator is that it's an *ongoing* outage with a specific start time and active impact.

## Rationale
This is an active incident because:
1. There's a specific start time (14:00 UTC today)
2. The impact is ongoing (30% failure rate)
3. There's a hard deadline (SOC1 review tomorrow)
4. The status page is green, meaning this hasn't been detected by monitoring — it needs immediate manual triage

Unlike a bug report (which describes a reproducible issue that may or may not be happening now), this describes something that IS happening now and needs immediate attention.

---

# ADR-005: Ticket 022 — Downtime Credit: billing-refund vs incident-active

## Decision
Classified as **billing-refund** with **normal** urgency.

## Context
Ticket 022 from brian@retailer.example requests a credit for 11 hours of platform downtime over the weekend during their product launch. The status page confirms the outage.

## Alternatives Considered
- **incident-active**: The outage has already passed (it was over the weekend). This is a post-incident credit request, not an active incident.

## Rationale
This is a billing/credit request triggered by a past outage. The customer is asking for compensation (credit for the affected period), which falls squarely under billing-refund. Not marked urgent because:
1. The outage has already been resolved
2. No active impact is occurring
3. Credit requests are typically handled within 1-2 business days
