# Research Notes — Password Manager Evaluation

## Date: 2026-05-02

## Products Evaluated

1. **1Password** (AgileBits Inc.)
2. **Bitwarden** (Bitwarden Inc.)
3. **LastPass** (LastPass Inc., acquired by Privacera)
4. **Dashlane** (Dashlane SAS)
5. **Keeper Security** (Keeper Security Inc.)

## Why These 5?

These are the 5 most widely recognized dedicated password managers with team/business tiers. They represent:
- The market leader (1Password)
- The open-source option (Bitwarden)
- The legacy incumbent (LastPass)
- The UX-focused contender (Dashlane)
- The security-hardened option (Keeper)

Excluded:
- **Google Password Manager / Microsoft Edge** — browser-native, not standalone team products
- **HashiCorp Vault / AWS Secrets Manager** — infrastructure secrets management, not human password managers
- **CyberArk / Thycotic** — enterprise PAM, overkill for a 50-person SaaS team

## Pricing Data Collected

### 1Password
- Source: https://1password.com/pricing/ (scraped 2026-05-02)
- Individual: $2.99/mo (annual), $4.99/mo (monthly)
- Families: $4.49/mo (annual), $7.99/mo (monthly)
- **Business: $7.99/mo/seat (annual), $9.99/mo/seat (monthly)**
- Teams: $19.95/mo for up to 10 users (annual), $24.95/mo (monthly)
- Enterprise: Contact sales

### Bitwarden
- Source: https://bitwarden.com/pricing/business/ (scraped 2026-05-02)
- Premium (individual): $1.65/mo (annual)
- Families: $3.99/mo (annual)
- **Business: $4.00/mo/seat (annual)**
- **Business Plus: $6.00/mo/seat (annual)**
- Enterprise: Contact sales

### LastPass
- Source: https://www.lastpass.com/features/business (scraped 2026-05-02)
- Pricing not publicly listed on the page. Page is JS-rendered with no pricing data in HTML.
- Per historical data (not verified in this session): ~$3-4/seat/month for Teams, ~$6-8/seat/month for Business
- **FLAG: Pricing not transparent — must contact sales**

### Dashlane
- Source: https://www.dashlane.com/pricing/business (scraped 2026-05-02)
- Pricing not publicly listed on the page. Page is JS-rendered with no pricing data in HTML.
- **FLAG: Pricing not transparent — must contact sales**

### Keeper
- Source: https://www.keepersecurity.com/pricing/ (scraped 2026-05-02)
- Pricing not publicly listed on the page. Page is JS-rendered with no pricing data in HTML.
- **FLAG: Pricing not transparent — must contact sales**

## Security/Compliance Data

### 1Password
- SOC 2 Type 2 certified (confirmed on https://1password.com/security/)
- FedRAMP compliance available (confirmed on https://1password.com/resources/soc2/)
- GDPR compliant
- PCI DSS compliant
- MFA/2FA supported
- Zero-knowledge architecture
- Source: https://1password.com/security/, https://1password.com/resources/soc2/

### Bitwarden
- SOC 2 Type 2 (confirmed on https://bitwarden.com/compliance/)
- HIPAA compliant
- GDPR compliant
- PCI DSS compliant
- Open source (client-side code)
- Zero-knowledge architecture
- Source: https://bitwarden.com/compliance/

### LastPass
- SOC 2 Type 2 (historically, not verified in this session)
- GDPR compliant
- **SECURITY INCIDENT: 2022 data breach exposed encrypted vault data, master password hashes, and security answers**
- Source: https://www.lastpass.com/features/security

### Dashlane
- SOC 2 Type 2 (historically, not verified in this session)
- GDPR compliant
- SAML 2.0 SSO supported
- Zero-knowledge architecture
- Source: https://www.dashlane.com/security

### Keeper
- SOC 2 Type 2 (historically, not verified in this session)
- FedRAMP authorized
- GDPR compliant
- HIPAA compliant
- Source: https://www.keepersecurity.com/security/

## Key Findings

1. **1Password** has the most transparent pricing and strongest compliance posture for a Series-B SaaS company.
2. **Bitwarden** is the most cost-effective option and is open-source, which appeals to engineering teams.
3. **LastPass** has a significant security incident history (2022 breach) that makes it a poor choice for a security-conscious team.
4. **Dashlane** and **Keeper** have opaque pricing, which is a red flag for budgeting.
5. All 5 products support SSO/SAML, MFA, and audit logs at their business tiers.

## Decision Criteria (to be formalized in recommendation.md)

1. **Pricing transparency** — can we budget accurately?
2. **Security track record** — any breaches or vulnerabilities?
3. **Compliance certifications** — SOC 2, FedRAMP, etc.
4. **Developer experience** — CLI, API, CI/CD integration
5. **SSO integration** — Google Workspace SAML
6. **Audit logging** — for SOC 2 compliance
7. **Platform coverage** — macOS, Windows, Linux, iOS, Android, browser extensions
8. **Admin UX** — ease of onboarding 50 users
9. **Vendor lock-in** — export capabilities, open standards
