# Password Manager Recommendation for Engineering Team

**To:** CTO & Engineering Leadership
**From:** Engineering Infrastructure Team
**Date:** 2026-05-02
**Subject:** Standardize on 1Password Business for 50-person engineering team

---

## Executive Summary

We recommend **1Password Business** as the team's standardized password manager. At **$7.99/seat/month** (annual billing), the total cost for 50 seats is **$4,794/year**. The runner-up is **Bitwarden Business Plus** at $6.00/seat/month ($3,600/year), which would be preferable if budget is the primary constraint.

This recommendation addresses the CTO's mandate to eliminate shadow-IT password storage (browser defaults, sticky notes, Slack DMs) within 90 days.

---

## 1. Decision Criteria

We evaluated products against these criteria, weighted by importance to our team:

| # | Criterion | Weight | Why It Matters |
|---|-----------|--------|----------------|
| 1 | **Security track record** | Critical | A password manager breach would be catastrophic; no unresolved incidents |
| 2 | **Pricing transparency** | High | Must budget accurately for 50 seats; opaque pricing introduces financial risk |
| 3 | **Compliance certifications** | High | SOC 2 Type 2 required for our own SOC 2 compliance; FedRAMP a plus |
| 4 | **Developer experience** | High | CLI, API, CI/CD integration for an engineering-heavy team |
| 5 | **SSO integration** | High | Google Workspace SAML to reduce password fatigue and enforce MFA |
| 6 | **Audit logging** | High | Required for SOC 2 compliance and security monitoring |
| 7 | **Platform coverage** | Medium | macOS, Windows, Linux, iOS, Android, browser extensions |
| 8 | **Admin UX** | Medium | Ease of onboarding 50 users within 90 days |
| 9 | **Vendor lock-in** | Medium | Export capabilities, open standards, migration ease |

---

## 2. Products Evaluated

We evaluated 5 dedicated password managers:

| Product | Company | Open Source? | Pricing Transparent? |
|---------|---------|-------------|---------------------|
| 1Password | AgileBits Inc. | No | Yes |
| Bitwarden | Bitwarden Inc. | Yes (client-side) | Yes |
| LastPass | LastPass Inc. | No | No |
| Dashlane | Dashlane SAS | No | No |
| Keeper Security | Keeper Security Inc. | No | No |

**Sources:**
- 1Password pricing: https://1password.com/pricing/ [1]
- Bitwarden pricing: https://bitwarden.com/pricing/business/ [2]
- LastPass: https://www.lastpass.com/features/business [3]
- Dashlane: https://www.dashlane.com/pricing/business [4]
- Keeper: https://www.keepersecurity.com/pricing/ [5]

---

## 3. Recommendation: 1Password Business

### Product & Tier

- **Product:** 1Password
- **Tier:** Business
- **Per-seat price:** $7.99/seat/month (billed annually) [1]
- **Monthly billing option:** $9.99/seat/month [1]

### Cost for 50 Seats

| Billing | Per Seat | 50 Seats/Month | Annual Total |
|---------|----------|----------------|-------------|
| Annual | $7.99 | $399.50 | **$4,794** |
| Monthly | $9.99 | $499.50 | $5,994 |

**Recommended: Annual billing at $4,794/year.**

### Why 1Password Wins

1. **Security track record:** No public security incidents. SOC 2 Type 2 certified [6]. FedRAMP compliance available [7].
2. **Pricing transparency:** Clear, published pricing. No need to contact sales.
3. **Developer experience:** Dedicated CLI tool (`op` command), API, CI/CD integration, SSH agent, secret detection in Git repos [8].
4. **SSO integration:** Native Google Workspace SAML integration, SSO enforcement at Business tier [9].
5. **Audit logging:** Comprehensive audit log available at Business tier, exportable for SOC 2 evidence [10].
6. **Platform coverage:** macOS, Windows, Linux, iOS, Android, all major browsers, CLI [11].
7. **Admin UX:** Clean admin console, easy user provisioning via SSO, group-based access controls, Single Sign-On enforcement [12].
8. **Zero-knowledge architecture:** 1Password cannot read your vault data; encryption happens client-side [13].

---

## 4. Runner-Up: Bitwarden Business Plus

### Product & Tier

- **Product:** Bitwarden
- **Tier:** Business Plus
- **Per-seat price:** $6.00/seat/month (billed annually) [2]
- **Annual cost for 50 seats:** $6.00 × 50 × 12 = **$3,600/year**

### When Bitwarden Would Beat 1Password

Bitwarden is the better choice if:

1. **Budget is the primary constraint:** Saves ~$1,194/year vs. 1Password.
2. **Open-source auditability is required:** Bitwarden's client-side code is open source and independently auditable [14].
3. **Self-hosting is desired:** Bitwarden offers self-hosted deployments (Bitwarden Server) for teams that want full control over their infrastructure [15].
4. **The team strongly prefers open-source tooling:** Bitwarden is a community favorite among developers.

### Trade-offs vs. 1Password

- **Admin UX:** Bitwarden's admin console is functional but less polished than 1Password's.
- **Developer tooling:** Bitwarden has a CLI (`bw` command) but 1Password's `op` CLI is more mature with better CI/CD integrations.
- **Secret detection:** 1Password has built-in secret detection for Git repos; Bitwarden does not.
- **SSH agent:** 1Password has a native SSH agent; Bitwarden does not.

---

## 5. Products Not Recommended

### LastPass — Disqualified

**Reason:** 2022 security breach exposed encrypted vault data, master password hashes, and security answers [16]. For a security-conscious engineering team, this is a disqualifying factor. Additionally, pricing is not publicly listed [3].

### Dashlane — Not Recommended

**Reason:** Pricing is not publicly listed [4], making it impossible to budget accurately. While Dashlane has good UX and zero-knowledge architecture [17], the lack of pricing transparency is a significant concern for a Series-B company.

### Keeper Security — Not Recommended

**Reason:** Pricing is not publicly listed [5], making it impossible to budget accurately. Keeper has strong compliance credentials (FedRAMP, HIPAA) [18], but the lack of pricing transparency and less developer-friendly tooling make it a poor fit for our team.

---

## 6. Concerns & Risks with 1Password

### Security

- **No public security incidents** to date, but the closed-source nature means the codebase is not independently auditable by the community.
- **Mitigation:** 1Password publishes a bug bounty program and undergoes regular third-party security audits [19].

### Vendor Lock-in

- **Risk:** Migrating 50 users from 1Password to another product would require re-exporting all vault data and re-provisioning users.
- **Mitigation:** 1Password supports standard export formats (CSV, 1Password format). The team should maintain regular exports as a precaution.

### Cost

- **Risk:** At $4,794/year, 1Password is more expensive than Bitwarden ($3,600/year).
- **Mitigation:** The additional cost is justified by superior developer tooling, admin UX, and zero security incident history. If budget becomes a constraint, Bitwarden is a viable alternative.

### Missing Features

- **No self-hosted option:** Unlike Bitwarden, 1Password does not offer self-hosted deployments. If the company later requires on-premises deployment, migration would be necessary.
- **No passkey management at Business tier:** Passkey management is available at the Enterprise tier, which requires contacting sales.

---

## 7. Implementation Plan (90-Day Timeline)

### Week 1-2: Procurement & Setup
- Purchase 1Password Business annual plan (50 seats)
- Configure Google Workspace SAML SSO
- Set up admin account and security policies

### Week 3-4: Pilot Group
- Onboard 5-10 engineers as pilot users
- Gather feedback on UX, CLI integration, and SSO flow
- Configure CI/CD integrations for the pilot group

### Week 5-8: Full Rollout
- Onboard remaining 40 engineers
- Disable browser password saving company-wide
- Configure secret detection for Git repos
- Train team on CLI usage and best practices

### Week 9-12: Enforcement & Monitoring
- Enforce SSO login for all users
- Review audit logs for compliance
- Document password management policies
- Plan for ongoing admin maintenance

---

## 8. Sources

[1] https://1password.com/pricing/ — 1Password pricing page (scraped 2026-05-02)
[2] https://bitwarden.com/pricing/business/ — Bitwarden business pricing page (scraped 2026-05-02)
[3] https://www.lastpass.com/features/business — LastPass business features page (scraped 2026-05-02)
[4] https://www.dashlane.com/pricing/business — Dashlane business pricing page (scraped 2026-05-02)
[5] https://www.keepersecurity.com/pricing/ — Keeper pricing page (scraped 2026-05-02)
[6] https://1password.com/security/ — 1Password security page (scraped 2026-05-02)
[7] https://1password.com/resources/soc2/ — 1Password SOC 2 / compliance page (scraped 2026-05-02)
[8] https://1password.com/downloads/command-line/ — 1Password CLI documentation
[9] https://1password.com/business/ — 1Password business features page
[10] https://support.1password.com/audit-log/ — 1Password audit log documentation
[11] https://1password.com/downloads/ — 1Password downloads page
[12] https://1password.com/business/ — 1Password business features page
[13] https://1password.com/security/ — 1Password zero-knowledge architecture
[14] https://github.com/bitwarden — Bitwarden GitHub repository
[15] https://bitwarden.com/help/self-host/ — Bitwarden self-hosting documentation
[16] https://blog.lastpass.com/2022/09/update-regarding-recent-cyberattack/ — LastPass 2022 breach disclosure
[17] https://www.dashlane.com/security — Dashlane security page (scraped 2026-05-02)
[18] https://www.keepersecurity.com/security/ — Keeper security page (scraped 2026-05-02)
[19] https://1password.com/security/ — 1Password bug bounty and audit information
