# ADR-001: Products Evaluated

**Status:** Accepted
**Date:** 2026-05-02
**Decision Maker:** Engineering Infrastructure Team

## Context

We need to select a password manager for a 50-person engineering team at a Series-B SaaS company. The team currently uses shadow-IT password storage (browser defaults, sticky notes, Slack DMs). The CTO has mandated a fix within 90 days.

## Decision

We evaluated the following 5 dedicated password managers:

1. **1Password** (AgileBits Inc.) — Market leader, strong security posture
2. **Bitwarden** (Bitwarden Inc.) — Open-source, most cost-effective
3. **LastPass** (LastPass Inc.) — Legacy incumbent, notable security incidents
4. **Dashlane** (Dashlane SAS) — UX-focused, opaque pricing
5. **Keeper Security** (Keeper Security Inc.) — Security-hardened, opaque pricing

## Rationale

These 5 represent the most widely recognized dedicated password managers with team/business tiers. They span the key decision dimensions:
- Market leadership (1Password)
- Open-source / cost (Bitwarden)
- Legacy / brand recognition (LastPass)
- UX / design (Dashlane)
- Security focus (Keeper)

## Excluded Products

- **Google Password Manager / Microsoft Edge** — Browser-native, not standalone team products with admin controls
- **HashiCorp Vault / AWS Secrets Manager** — Infrastructure secrets management, not human password managers
- **CyberArk / Thycotic** — Enterprise PAM solutions, overkill for a 50-person team
- **RoboForm / Passbolt / Psono** — Smaller market share, less mature admin features

## Consequences

- This evaluation excludes niche or emerging products that may offer unique features
- The focus on dedicated password managers means we are not evaluating SSO or secrets-management infrastructure as alternatives
