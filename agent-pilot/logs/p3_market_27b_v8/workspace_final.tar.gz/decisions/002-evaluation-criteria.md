# ADR-002: Evaluation Criteria

**Status:** Accepted
**Date:** 2026-05-02
**Decision Maker:** Engineering Infrastructure Team

## Context

We need a structured set of criteria to evaluate password managers for our 50-person engineering team.

## Decision

The following criteria were established, weighted by importance:

| # | Criterion | Weight | Rationale |
|---|-----------|--------|-----------|
| 1 | **Pricing transparency & cost** | High | Must budget accurately for 50 seats; opaque pricing is a red flag |
| 2 | **Security track record** | Critical | No breaches or unresolved vulnerabilities |
| 3 | **Compliance certifications** | High | SOC 2 Type 2 required for our SOC 2 compliance; FedRAMP a plus |
| 4 | **Developer experience** | High | CLI, API, CI/CD integration for engineering team |
| 5 | **SSO integration** | High | Google Workspace SAML for single sign-on |
| 6 | **Audit logging** | High | Required for SOC 2 compliance and security monitoring |
| 7 | **Platform coverage** | Medium | macOS, Windows, Linux, iOS, Android, browser extensions |
| 8 | **Admin UX** | Medium | Ease of onboarding 50 users within 90 days |
| 9 | **Vendor lock-in** | Medium | Export capabilities, open standards, migration ease |

## Rationale

- **Security track record** is critical because a password manager breach would be catastrophic
- **Pricing transparency** is weighted high because we need to budget for 50 seats and opaque pricing introduces risk
- **Developer experience** is weighted high because our team is engineering-focused and needs CLI/CI/CD integration
- **SSO integration** is weighted high because we use Google Workspace and want to reduce password fatigue
- **Audit logging** is weighted high because it's required for our SOC 2 compliance

## Consequences

- Products with opaque pricing (LastPass, Dashlane, Keeper) are at a disadvantage
- Products with security incidents (LastPass) are at a significant disadvantage
- Open-source products (Bitwarden) get a bonus for auditability
