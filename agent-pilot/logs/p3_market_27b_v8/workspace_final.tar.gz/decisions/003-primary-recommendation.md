# ADR-003: Primary Recommendation — 1Password Business

**Status:** Accepted
**Date:** 2026-05-02
**Decision Maker:** Engineering Infrastructure Team

## Context

After evaluating 5 password managers against our criteria, we need to select a primary recommendation.

## Decision

**1Password Business** is the recommended password manager for our 50-person engineering team.

**Tier:** Business
**Pricing:** $7.99/seat/month (annual billing)
**Annual cost:** $7.99 × 50 seats × 12 months = $4,794/year

## Rationale

1. **Pricing transparency:** 1Password publishes clear pricing on their website. No need to contact sales.
2. **Security track record:** No public security incidents. SOC 2 Type 2 certified.
3. **Compliance:** SOC 2 Type 2, FedRAMP available, GDPR, PCI DSS.
4. **Developer experience:** CLI tool, API, CI/CD integration, SSH agent, secret detection.
5. **SSO integration:** Native Google Workspace SAML integration.
6. **Audit logging:** Comprehensive audit log available at Business tier.
7. **Platform coverage:** macOS, Windows, Linux, iOS, Android, all major browsers, CLI.
8. **Admin UX:** Clean admin console, easy user provisioning, group management.
9. **Vendor lock-in:** Standard export formats, reasonable migration path.

## Runner-Up

**Bitwarden Business Plus** ($6.00/seat/month annual = $3,600/year for 50 seats) is the runner-up. It would beat 1Password if:
- Budget is the primary constraint (saves ~$1,194/year)
- Open-source auditability is a hard requirement
- Self-hosting is desired (Bitwarden offers self-hosted options)

## Concerns

1. **Cost:** 1Password is more expensive than Bitwarden (~33% more per seat)
2. **Closed source:** Unlike Bitwarden, 1Password's code is not publicly auditable
3. **Vendor lock-in:** While export is possible, migrating 50 users is non-trivial

## Alternatives Considered

- **Bitwarden:** Lower cost, open-source, but slightly less polished admin UX
- **LastPass:** Disqualified due to 2022 security breach
- **Dashlane:** Disqualified due to opaque pricing
- **Keeper:** Disqualified due to opaque pricing
