# Sources

**Date:** 2026-05-02
**Researcher:** Engineering Infrastructure Team

All URLs were fetched via `curl` from a Linux VM with internet access. Timestamps are approximate to the minute.

---

## 1Password

| # | URL | Timestamp | Description | SHA-256 |
|---|-----|-----------|-------------|---------|
| 1 | https://1password.com/pricing/ | 2026-05-02 ~09:00 UTC | Main pricing page. Extracted pricing data for Individual ($2.99/mo annual), Families ($4.49/mo annual), Teams ($19.95/mo annual for 10 users), and Business ($7.99/mo/seat annual, $9.99/mo/seat monthly). Data found in embedded JSON within the HTML. | N/A |
| 2 | https://1password.com/security/ | 2026-05-02 ~09:01 UTC | Security page. Confirmed SOC 2 Type 2 certification, zero-knowledge architecture, MFA/2FA support. | N/A |
| 3 | https://1password.com/resources/soc2/ | 2026-05-02 ~09:05 UTC | SOC 2 / compliance page. Confirmed SOC 2 Type 2, FedRAMP availability, GDPR, PCI DSS compliance. | N/A |
| 4 | https://1password.com/business/ | 2026-05-02 ~09:02 UTC | Business features page. Confirmed SSO/SAML, audit logging, group-based access, admin console features. | N/A |
| 5 | https://1password.com/downloads/command-line/ | 2026-05-02 ~09:03 UTC | CLI documentation. Confirmed `op` CLI tool availability, CI/CD integration, SSH agent support. | N/A |
| 6 | https://1password.com/downloads/ | 2026-05-02 ~09:03 UTC | Downloads page. Confirmed platform coverage: macOS, Windows, Linux, iOS, Android, browser extensions, CLI. | N/A |
| 7 | https://support.1password.com/audit-log/ | 2026-05-02 ~09:04 UTC | Audit log documentation. Confirmed audit log availability at Business tier. | N/A |

## Bitwarden

| # | URL | Timestamp | Description | SHA-256 |
|---|-----|-----------|-------------|---------|
| 8 | https://bitwarden.com/pricing/business/ | 2026-05-02 ~09:01 UTC | Business pricing page. Extracted pricing: Premium individual ($1.65/mo annual), Families ($3.99/mo annual), Business ($4.00/mo/seat annual), Business Plus ($6.00/mo/seat annual). Data found in embedded JSON within the HTML. | N/A |
| 9 | https://bitwarden.com/compliance/ | 2026-05-02 ~09:05 UTC | Compliance page. Confirmed SOC 2 Type 2, HIPAA, GDPR, PCI DSS compliance. | N/A |
| 10 | https://bitwarden.com/security/ | 2026-05-02 ~09:01 UTC | Security page. 404 — page not found. | N/A |
| 11 | https://github.com/bitwarden | 2026-05-02 ~09:06 UTC | GitHub repository. Confirmed open-source client-side code. | N/A |
| 12 | https://bitwarden.com/help/self-host/ | 2026-05-02 ~09:06 UTC | Self-hosting documentation. Confirmed self-hosted deployment option available. | N/A |
| 13 | https://bitwarden.com/help/using-the-bitwarden-cli/ | 2026-05-02 ~09:06 UTC | CLI documentation. Confirmed `bw` CLI tool availability. | N/A |

## LastPass

| # | URL | Timestamp | Description | SHA-256 |
|---|-----|-----------|-------------|---------|
| 14 | https://www.lastpass.com/features/business | 2026-05-02 ~09:00 UTC | Business features page. No pricing data found in HTML (JS-rendered). Page confirmed business features but no transparent pricing. | N/A |
| 15 | https://www.lastpass.com/features/security | 2026-05-02 ~09:01 UTC | Security page. Confirmed SSO support. No pricing data. | N/A |
| 16 | https://blog.lastpass.com/2022/09/update-regarding-recent-cyberattack/ | 2026-05-02 ~09:07 UTC | 2022 breach disclosure blog post. Confirmed security incident: encrypted vault data, master password hashes, and security answers were exposed. | N/A |

## Dashlane

| # | URL | Timestamp | Description | SHA-256 |
|---|-----|-----------|-------------|---------|
| 17 | https://www.dashlane.com/pricing/business | 2026-05-02 ~09:00 UTC | Business pricing page. No pricing data found in HTML (JS-rendered). Page confirmed business features but no transparent pricing. | N/A |
| 18 | https://www.dashlane.com/security | 2026-05-02 ~09:01 UTC | Security page. Confirmed zero-knowledge architecture, SAML 2.0 SSO support, audit logging. | N/A |

## Keeper Security

| # | URL | Timestamp | Description | SHA-256 |
|---|-----|-----------|-------------|---------|
| 19 | https://www.keepersecurity.com/pricing/ | 2026-05-02 ~09:00 UTC | Pricing page. No pricing data found in HTML (JS-rendered). Page confirmed business features but no transparent pricing. | N/A |
| 20 | https://www.keepersecurity.com/security/ | 2026-05-02 ~09:01 UTC | Security page. Confirmed GDPR compliance, SSO support. | N/A |

---

## Notes on Data Collection

- All pages were fetched using `curl -sL` with default user agent.
- Pricing data for 1Password and Bitwarden was extracted from embedded JSON within the HTML source.
- LastPass, Dashlane, and Keeper pricing pages are JS-rendered and do not contain pricing data in the raw HTML. This is flagged as a concern in the recommendation.
- SHA-256 hashes were not computed for the fetched pages, as the data was processed in-memory. For reproducibility, the raw HTML files are available in `/tmp/` (1password_pricing.html, bitwarden_pricing.html, etc.).
- Some URLs returned 404 (e.g., Bitwarden's /security/ page) — this is noted above.
