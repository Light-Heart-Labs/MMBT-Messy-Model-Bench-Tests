# ADR-0001: Why Split output.py

## Status

Accepted

## Context

The `logalyzer/output.py` module mixed four distinct concerns:

1. **JSON serialization** (`to_json`) — hand-crafted JSON string building
2. **CSV serialization** (`to_csv`) — uses `csv` stdlib module
3. **Plain-text formatting** (`to_text`) — human-readable line formatting
4. **Aggregate rendering** (`render_aggregate`) — dispatches by format for aggregate data

Additionally, the task specification required `format_legacy()` to be importable from `logalyzer.output`, even though it lives in `utils.py`. This is a backwards-compatibility concern.

The single-file approach made it harder to:
- Understand what each function does at a glance
- Add new output formats without bloating the file
- Test individual renderers in isolation
- Reason about dependencies (e.g., `csv` import only needed by CSV renderer)

## Decision

Split `output.py` into a `logalyzer/output/` package with one module per concern:

| Module | Contents |
|--------|----------|
| `json_renderer.py` | `to_json()` |
| `csv_renderer.py` | `to_csv()` |
| `plain_renderer.py` | `to_text()`, `render_aggregate()` |
| `legacy.py` | `format_legacy()` (re-exported from `utils.py`) |
| `__init__.py` | Re-exports all public names |

`render_aggregate()` was placed in `plain_renderer.py` because it is primarily a text-formatting concern (the default format is "text") and it operates on aggregate data structures rather than `LogEntry` objects.

## Consequences

- **Positive**: Each module has a single, clear responsibility. New output formats can be added as new modules without touching existing code.
- **Positive**: The `__init__.py` re-exports maintain full backward compatibility — no import changes needed in any caller.
- **Neutral**: Slightly more files, but each is small and focused.
- **No behavioral change**: All output is byte-identical to the original.
