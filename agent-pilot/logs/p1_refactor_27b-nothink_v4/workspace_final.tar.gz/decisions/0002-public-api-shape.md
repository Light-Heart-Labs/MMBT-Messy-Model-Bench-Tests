# ADR-0002: Public API Shape

## Status

Accepted

## Context

The `logalyzer/output` package must maintain full backward compatibility with all existing import patterns. The key question is: what names must be importable from `logalyzer.output`?

## Decision

The `__init__.py` re-exports exactly these names:

| Name | Source Module | Used By |
|------|--------------|---------|
| `to_json` | `json_renderer.py` | `cli.py` |
| `to_csv` | `csv_renderer.py` | `cli.py` |
| `to_text` | `plain_renderer.py` | `cli.py` |
| `render_aggregate` | `plain_renderer.py` | `cli.py` |
| `format_legacy` | `legacy.py` (via `utils.py`) | External scripts (backwards compat) |

### Why `format_legacy` is in the output package

The task specification requires `from logalyzer.output import format_legacy` to work. The function itself lives in `utils.py` (it was never in `output.py` in the original codebase). The `legacy.py` module re-exports it from `utils.py` so that:

1. The function remains defined in one place (`utils.py`) — no duplication
2. It's importable from `logalyzer.output` as required
3. It's clearly marked as legacy/backwards-compat code

### Why `render_aggregate` is in `plain_renderer.py`

`render_aggregate()` handles aggregate data (Counters, dicts, lists) and dispatches by format string. It was placed in `plain_renderer.py` rather than its own module because:

1. It's primarily a text-formatting concern (default format is "text")
2. It doesn't operate on `LogEntry` objects, so it's distinct from the entry renderers
3. It's small enough to coexist with `to_text()` without creating a separate file

## Consequences

- All existing `from logalyzer.output import X` statements continue to work
- The `__all__` list in `__init__.py` documents the complete public API
- Internal module names (`json_renderer`, `csv_renderer`, etc.) are not part of the public API
