"""Plain-text output renderer."""
from __future__ import annotations

from typing import Any, Iterable

from ..parser import LogEntry


def to_text(entries: Iterable[LogEntry]) -> str:
    """Render entries as readable plain text, one entry per line."""
    lines = []
    for e in entries:
        lines.append(
            f'{e.timestamp.isoformat()}  {e.ip:>15}  {e.method:<6} {e.status} {e.url}'
        )
    return '\n'.join(lines)


def render_aggregate(agg: Any, fmt: str = "text") -> str:
    """Render an aggregate result (Counter, dict, list) as text/json/csv."""
    if fmt == "text":
        if hasattr(agg, "items"):
            return '\n'.join(f"{k}\t{v}" for k, v in agg.items())
        return '\n'.join(f"{k}\t{v}" for k, v in agg)
    elif fmt == "json":
        if hasattr(agg, "items"):
            items = list(agg.items())
        else:
            items = list(agg)
        parts = [f'"{k}":{v}' for k, v in items]
        return '{' + ','.join(parts) + '}'
    else:
        raise ValueError(f"unknown format: {fmt}")
