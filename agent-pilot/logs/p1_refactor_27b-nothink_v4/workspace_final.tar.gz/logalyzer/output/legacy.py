"""Legacy output formatters for backwards compatibility."""
from __future__ import annotations

from ..utils import format_legacy

__all__ = ["format_legacy"]
