"""Output formatters: JSON, CSV, plain text.

This package replaces the old output.py module. All public names are
re-exported here so that existing import statements continue to work:

    from logalyzer.output import to_json, to_csv, to_text, render_aggregate
    from logalyzer.output import format_legacy
"""
from __future__ import annotations

from .csv_renderer import to_csv
from .json_renderer import to_json
from .legacy import format_legacy
from .plain_renderer import render_aggregate, to_text

__all__ = [
    "to_json",
    "to_csv",
    "to_text",
    "render_aggregate",
    "format_legacy",
]
