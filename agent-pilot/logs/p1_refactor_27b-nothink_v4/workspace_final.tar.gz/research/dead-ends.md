# Dead Ends

## Approach 1: Keep `format_legacy` in `utils.py` only

**Attempt**: Initially considered not creating a `legacy.py` module and instead re-exporting `format_legacy` directly from `__init__.py`.

**Why it was rejected**: The task specification explicitly requires a `legacy.py` module in the output package. Having a dedicated module makes the backwards-compat nature of the function explicit and keeps `__init__.py` clean.

## Approach 2: Put `render_aggregate` in `__init__.py`

**Attempt**: Considered putting `render_aggregate` directly in `__init__.py` since it doesn't fit neatly into any single renderer.

**Why it was rejected**: `__init__.py` should only contain re-exports, not implementation code. Placing implementation in `__init__.py` would make it harder to understand the package structure and would mix concerns. `plain_renderer.py` is the natural home since the function is primarily text-formatting.

## Pre-existing bugs (documented, not fixed)

### Bug 1: `collections.Iterable` import in `filters.py`

`filters.py` line 5: `from collections import Iterable` — This import was removed in Python 3.10. The correct import is `from collections.abc import Iterable`. This causes test collection to fail on Python 3.11+.

**Not fixed** because the task explicitly says "No bug fixes" and "Don't change unrelated code."

### Bug 2: Missing "Jul" in `MONTH_NAMES` in `parser.py`

`parser.py` line 27-29: The `MONTH_NAMES` list skips "Jul":
```python
MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Aug", "Sep", "Oct", "Nov", "Dec",
]
```
This causes `test_timestamp_july_parses_correctly` to fail with `ValueError: 'Jul' is not in list`.

**Not fixed** because the task explicitly says "No bug fixes" and "Don't change unrelated code."
