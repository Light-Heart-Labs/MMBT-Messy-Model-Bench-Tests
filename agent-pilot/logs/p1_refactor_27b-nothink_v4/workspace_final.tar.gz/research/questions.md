# Questions and Resolutions

## Q1: Where does `render_aggregate` belong?

**Question**: `render_aggregate()` dispatches by format string ("text", "json", "csv"). Should it have its own module, or go with one of the renderers?

**Resolution**: Placed in `plain_renderer.py` because:
- Its default format is "text"
- It operates on aggregate data structures, not `LogEntry` objects
- It's small enough to coexist with `to_text()`
- Creating a separate `aggregate_renderer.py` would be over-engineering for a 15-line function

## Q2: Should `format_legacy` be duplicated or re-exported?

**Question**: The task says `format_legacy` should be in `legacy.py`, but it currently lives in `utils.py`. Should I copy it or re-export it?

**Resolution**: Re-export from `utils.py`. This avoids code duplication and keeps the single source of truth. The `legacy.py` module simply imports and re-exports it.

## Q3: What about the `Iterable` type hint in the original `output.py`?

**Question**: The original `output.py` imports `Iterable` from `typing`. Should the split modules keep this?

**Resolution**: Yes, each module that uses `Iterable` in its type hints imports it from `typing`. This is consistent with the original code and doesn't introduce any new dependencies.

## Q4: Should `render_aggregate` raise on "csv" format?

**Question**: The original `render_aggregate` raises `ValueError` for "csv" format. Should this behavior be preserved?

**Resolution**: Yes, behavior must be byte-identical. The function only supports "text" and "json" formats. The CLI code works around this by converting "csv" to "text" before calling `render_aggregate`.
