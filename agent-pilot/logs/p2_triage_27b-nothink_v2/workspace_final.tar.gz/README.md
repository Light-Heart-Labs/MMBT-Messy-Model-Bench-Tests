# Support Ticket Triage — Results & Methodology

## Overview

30 tickets were triaged from `/input/repo/tickets.txt`. Results are in
`/workspace/triage_results.json`.

## Summary

| Category | Count |
|---|---|
| bug-report | 7 |
| billing-refund | 4 |
| feature-request | 3 |
| incident-active | 2 |
| account-management | 2 |
| auth-permissions | 2 |
| general-question | 2 |
| spam-or-noise | 4 |
| external-business | 2 |
| security-incident | 1 |
| legal-compliance | 1 |
| **Total** | **30** |

- **Urgent tickets:** 5 (003, 014, 016, 023, 028, 030 — note 023 and 030 are follow-ups to 014)
- **Duplicate clusters:** 2
  - `[007, 011]` — Dashboard sharing permission bug (same team, same account)
  - `[014, 023, 030]` — API rate limit blocking nightly ingestion (same org, escalating follow-ups)

## Recommended Processing Order

1. **TICKET 028** — Security incident: active account compromise, needs immediate freeze
2. **TICKET 003** — Incident: entire org locked out, board meeting imminent
3. **TICKET 016** — Incident: 500 errors on exports API, SOC1 review tomorrow
4. **TICKET 014** (with 023, 030) — Urgent bug: rate limits blocking $48k contract customer
5. **TICKET 001** — Billing refund: double charge
6. **TICKET 013** — Billing refund: accidental upgrade
7. **TICKET 008** — Billing refund: pro-rated annual plan
8. **TICKET 022** — Billing refund: downtime credit
9. **TICKET 019** — Legal: GDPR data export (30-day deadline)
10. **TICKET 006** — Account: cancellation
11. **TICKET 026** — Account: seat changes
12. **TICKET 007** (with 011) — Auth/permissions bug
13. **TICKET 005** — Bug: CSV export
14. **TICKET 020** — Bug: date filter
15. **TICKET 024** — Bug: webhooks
16. **TICKET 027** — Bug: PDF chart resolution
17. **TICKET 002** — Feature: SAML SSO (60-seat deal at stake)
18. **TICKET 012** — Feature: scheduled reports
19. **TICKET 015** — Feature: dark mode
20. **TICKET 017** — General: onboarding question
21. **TICKET 025** — General: non-profit pricing
22. **TICKET 010** — External: podcast pitch
23. **TICKET 018** — External: acquisition inquiry
24. **TICKET 004, 009, 021, 029** — Spam/noise: discard

## Tickets with Ambiguous Calls

See `/workspace/decisions/` for detailed reasoning on non-obvious classifications.

### Quick highlights:

- **014** could be `billing-other` (contract dispute) but is classified as `bug-report` because the core ask is a technical fix (higher rate limits), not a billing adjustment.
- **029** is extortion, not a legitimate vulnerability disclosure — classified as `spam-or-noise`.
- **022** is a refund request tied to documented downtime — classified as `billing-refund`.
- **007/011** are two sides of the same permission bug — 011 is marked as duplicate of 007.
