# ADR-001: Ticket 014 — API Rate Limits Classification

## Context

Ticket 014 from ops@major-customer.com reports that API rate limits (600 req/min on Business plan) are blocking nightly data ingestion, causing 4 hours of 429 errors. The customer mentions their $48k/yr contract.

## Decision

Classified as **bug-report** with **urgent** urgency.

## Rationale

- The core ask is technical: "can we get a higher limit or some kind of burst allowance?"
- This is not a billing dispute — the customer is not disputing charges or asking for a refund.
- The mention of contract value is to emphasize business impact, not to initiate a billing conversation.
- Urgency is elevated because:
  - The issue is actively recurring (confirmed by follow-ups 023 and 030)
  - Backlog is growing (~200 GB/day)
  - A quarterly review deadline is approaching
  - This is a high-value customer ($48k/yr)

## Alternatives Considered

- `billing-other`: Rejected because no billing action is requested.
- `feature-request`: Rejected because rate limits are an existing documented feature; the customer is asking for an exception/adjustment, not a new capability.
