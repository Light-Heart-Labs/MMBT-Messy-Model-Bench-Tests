# ADR-005: Ticket 022 — Downtime Refund Classification

## Context

Ticket 022 from brian@retailer.example requests a credit/refund because the platform was down 11 hours over the weekend during their product launch. They reference the status page as confirmation.

## Decision

Classified as **billing-refund** with **normal** urgency.

## Rationale

- The explicit ask is a credit/refund for the affected period.
- The customer references the public status page, so the downtime claim is verifiable.
- This is a legitimate business request, not spam.
- Urgency is `normal` (not `urgent`) because:
  - The downtime has already ended (it was over the weekend)
  - There is no active production impact
  - This is a post-incident billing adjustment

## Alternatives Considered

- `billing-other`: Rejected because the customer explicitly asks for a credit/refund, which falls squarely under `billing-refund`.
