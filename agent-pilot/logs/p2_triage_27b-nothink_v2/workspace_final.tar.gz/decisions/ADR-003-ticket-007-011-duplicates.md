# ADR-003: Ticket 007/011 — Duplicate Cluster Detection

## Context

- Ticket 007 (jordan.lee@mid-co.com): "Can't see my teammate's dashboards" — permission denied when clicking shared dashboards.
- Ticket 011 (alex.petrov@mid-co.com): "Sharing dashboards with teammate fails" — same account (MC-3309), same symptom, reported by the other party.

## Decision

Both classified as **auth-permissions**. Ticket 011 is marked as `duplicate_of: "007"`.

## Rationale

- Both tickets describe the same underlying issue: a dashboard sharing/permissions bug on account MC-3309.
- They are reported by two different people on the same team, each describing their side of the problem.
- The root cause is likely a permissions sync bug in the sharing system.
- Ticket 007 is the original (lower number), so 011 is the duplicate.
- Both are `auth-permissions` because the symptom is a permission-denied error on shared resources, not a general bug.

## Note

Even though both are duplicates, both should be acknowledged to the senders. The duplicate_of field is for internal routing — the support agent should still reply to both parties.
