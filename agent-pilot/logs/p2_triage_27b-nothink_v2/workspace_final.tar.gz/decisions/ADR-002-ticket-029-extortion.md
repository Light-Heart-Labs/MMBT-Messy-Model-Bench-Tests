# ADR-002: Ticket 029 — Extortion Email Classification

## Context

Ticket 029 from hacker@blackhat-forum.example claims to have found 3 vulnerabilities and demands $50,000 in BTC, threatening to publish them on Twitter.

## Decision

Classified as **spam-or-noise** with **n/a** urgency.

## Rationale

- This is a classic extortion attempt, not a legitimate vulnerability disclosure.
- Legitimate bug bounty reports do not demand cryptocurrency payments via anonymous email.
- The sender address (hacker@blackhat-forum.example) is not a known security researcher or customer.
- No proof of vulnerability is provided.
- No action is warranted beyond logging the attempt for security team awareness.

## Alternatives Considered

- `security-incident`: Rejected because this is not a customer-reported compromise or legitimate vuln disclosure. The extortion attempt itself is not a security incident against our platform — it's noise targeting our support channel.
- If the sender had provided a verifiable proof-of-concept and used a responsible disclosure channel, this would be `security-incident`.
