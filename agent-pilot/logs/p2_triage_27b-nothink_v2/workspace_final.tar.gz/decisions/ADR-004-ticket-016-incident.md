# ADR-004: Ticket 016 — 500 Errors Classification

## Context

Ticket 016 reports ~30% of POST requests to /api/v2/exports returning 500 since 14:00 UTC. Status page shows green. Customer has a SOC1 review the next morning.

## Decision

Classified as **incident-active** with **urgent** urgency.

## Rationale

- This is an ongoing outage affecting a specific API endpoint.
- The status page discrepancy (green while customers see 500s) is itself a concern.
- There is a time-sensitive deadline: SOC1 review the next morning.
- Unlike a bug-report (which describes a reproducible but non-urgent issue), this is actively breaking production workflows.

## Alternatives Considered

- `bug-report`: Rejected because the issue is actively ongoing with a specific start time and immediate business impact, not a general reproducibility report.
