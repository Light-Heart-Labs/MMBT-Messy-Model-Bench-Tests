# ADR-001: Fix discount_amount implementation, not the tests

## Context

The `discount_amount` function was computing `price * percent_off` without dividing by 100. The v0.3.0 changelog announced a breaking API change from fraction (0.0–1.0) to percent (0–100), but the implementation was never updated.

## Decision

Fix the implementation code (`discount.py`) to divide by 100, rather than adjusting the tests to match the broken output.

## Rationale

- The docstring examples in `discount.py` clearly state `discount_amount(100.0, 20.0) -> 20.0`
- The changelog documents the intended API (percent 0–100)
- The tests were written against the documented API, not the broken implementation
- The implementation was the bug; the tests were correct

## Consequences

- `discount_amount(100, 20)` now correctly returns 20.0
- `apply_discount(100, 20)` now correctly returns 80.0 (cascading fix)
- All discount-related tests pass

---

# ADR-002: Update line_count test, not the implementation

## Context

`Cart.line_count()` returns `len(self.lines)` (number of lines), but the test expected total quantity across lines (sum of all `qty` values).

## Decision

Update the test to match the current implementation, rather than changing the implementation.

## Rationale

- The v0.3.0 changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior."
- The implementation matches the documented API
- The test was stale — it reflected the v0.2.0 behavior

## Consequences

- Test now expects 2 (number of lines) instead of 5 (total quantity)
- The test name `test_line_count_matches_qty_sum` is slightly misleading but the docstring was updated to clarify the intent
