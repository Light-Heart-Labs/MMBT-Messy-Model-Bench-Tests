# Changelog

## v0.3.2 (2025-01-XX)

**Bug fixes:**

1. **`discount_amount()` was not dividing by 100** — The v0.3.0 changelog
   announced a breaking change from fraction (0.0–1.0) to percent (0–100),
   but the implementation was never updated. `discount_amount(100, 20)`
   returned 2000 instead of 20. Fixed by dividing `price * percent_off` by 100.

2. **Unused `json` import in `cart.py`** — Removed `import json` which was
   flagged by ruff F401.

3. **`test_line_count_matches_qty_sum` test not updated for v0.3.0 API** —
   The v0.3.0 changelog states `Cart.line_count()` now returns the number of
   lines (not total quantity). The test still expected the old behavior
   (total qty = 5). Updated to expect 2 (number of lines).

4. **Ruff lint errors (I001, UP006, UP035, UP045)** — Applied auto-fixes for
   import sorting and modernized type annotations (`list` instead of
   `typing.List`, `X | None` instead of `Optional[X]`).

**Verification:**

- `ruff check src/ tests/` → All checks passed (exit 0)
- `pytest -q` → 7 passed, 0 failed (exit 0)

## v0.3.1 (previous — CI red)

CI was failing on this version. See `ci_failure.log` for the full output.

## v0.3.0

- **BREAKING**: `discount_amount()` and `apply_discount()` now take percent (0-100)
  instead of fraction (0.0-1.0). Update callers from `apply_discount(p, 0.2)` to
  `apply_discount(p, 20.0)`.
- `Cart.line_count()` now returns the number of lines, not the total quantity
  across lines. Tests should be updated where they relied on the old behavior.

## v0.2.0

- Added `Cart.set_discount()` for cart-wide discounts.
- `Cart.line_count()` returns total quantity across lines.

## v0.1.0

- Initial release.
