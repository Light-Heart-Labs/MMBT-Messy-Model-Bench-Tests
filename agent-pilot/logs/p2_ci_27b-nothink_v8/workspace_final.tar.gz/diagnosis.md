# Diagnosis

## CI Failure Analysis

The CI log showed 1 ruff error and 3 test failures.

### Issue 1: Ruff F401 — unused `json` import in `cart.py`

**What was wrong:** `import json` was present but never used.
**Fix:** Removed the import line.
**Why:** Straightforward lint fix — no ambiguity.

### Issue 2: `test_discount_amount` — `discount_amount(100.0, 20.0)` returned 2000.0 instead of 20.0

**What was wrong:** The `discount_amount` function computes `price * percent_off` but does not divide by 100. Since v0.3.0 changed the API from fraction (0.0–1.0) to percent (0–100), the implementation should divide by 100.
**Fix:** Changed `return round(price * percent_off, 2)` to `return round(price * percent_off / 100, 2)`.
**Why:** The code was wrong. The docstring examples (`discount_amount(100.0, 20.0) -> 20.0`) and the changelog both confirm percent-based input. The tests were correct.

### Issue 3: `test_apply_discount` — `apply_discount(100.0, 20.0)` returned -1900.0 instead of 80.0

**What was wrong:** This is a cascading failure from Issue 2. `apply_discount` calls `discount_amount`, so when `discount_amount` returned 2000 instead of 20, `apply_discount` computed `100 - 2000 = -1900`.
**Fix:** Resolved by fixing Issue 2. No separate code change needed.
**Why:** Same root cause as Issue 2.

### Issue 4: `test_line_count_matches_qty_sum` — expected 5 but got 2

**What was wrong:** The test expected `line_count()` to return total quantity (5), but the code returns number of lines (2).
**Fix:** Updated the test to expect 2 (number of lines).
**Why:** The v0.3.0 changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior." The code is correct per the documented API; the test was stale.

### Issue 5: Ruff I001/UP006/UP035/UP045 — import sorting and typing modernization

**What was wrong:** Import blocks were unsorted, and deprecated `typing.List`/`typing.Optional` were used.
**Fix:** Applied `ruff --fix` auto-fixes.
**Why:** These are style/modernization issues caught by the configured ruff rules.
