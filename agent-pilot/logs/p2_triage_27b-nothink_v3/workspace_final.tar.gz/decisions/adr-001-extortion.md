# ADR-001: TICKET 029 — Extortion Email Classification

## Context
Ticket 029 from `hacker@blackhat-forum.example` claims to have found 3 vulnerabilities and demands $50,000 in BTC, threatening to publish on Twitter within 48 hours.

## Decision
Classified as `spam-or-noise` with urgency `n/a`.

## Rationale
This is a classic extortion attempt, not a legitimate security disclosure:
- No vulnerability details provided (just a vague claim of "3 vulns")
- Payment demanded in Bitcoin (untraceable, no receipt)
- Threat to publish on social media (reputational extortion)
- Sender address from a "blackhat forum" domain
- No use of responsible disclosure channels

A legitimate security researcher would:
- Provide at least a proof-of-concept or description
- Use a responsible disclosure channel or encrypted email
- Not demand payment via cryptocurrency
- Not threaten public disclosure

## Action
Do not engage. Forward to legal/security team for record-keeping. Consider blocking the sender domain.

---

# ADR-002: TICKET 014 — Rate Limit Classification

## Context
Ticket 014 from `ops@major-customer.com` reports hitting API rate limits (600 req/min on Business plan) during nightly data ingestion, causing 4 hours of failed requests. They have a $48k/yr contract.

## Decision
Classified as `bug-report` with urgency `urgent`.

## Rationale
While this could be seen as a billing/plan issue, the core problem is technical: the rate limit is blocking a critical data pipeline. The customer isn't disputing charges — they're asking for a technical solution (higher limit or burst allowance). This is a product limitation that's actively blocking a paying customer's operations.

Marked `urgent` because:
- The issue is actively recurring (confirmed by follow-ups 023 and 030)
- A $48k/yr customer is affected
- They have a quarterly review deadline approaching
- Data backlog is growing (~200 GB/day)

## Action
Escalate to engineering for rate-limit review and to account management for contract discussion.

---

# ADR-003: TICKET 007/011 — Duplicate Detection

## Context
- Ticket 007: jordan.lee@mid-co.com reports "permission denied" when opening shared dashboards
- Ticket 011: alex.petrov@mid-co.com reports the same issue from the sharer's perspective

## Decision
Ticket 011 is a duplicate of 007. Both classified as `auth-permissions`.

## Rationale
Same account (MC-3309), same team, same symptom (permission denied on shared dashboards), same set of dashboards (three). The two tickets are two sides of the same issue — one from the viewer, one from the sharer.

## Action
Merge into single investigation. The bug appears to be in the permission-checking logic for shared dashboards where the "Editor" role isn't being properly applied.

---

# ADR-004: TICKET 014/023/030 — Duplicate Cluster

## Context
Three tickets from `ops@major-customer.com` about API rate limits:
- 014: Initial report
- 023: Follow-up, issue recurred
- 030: Third message, escalating frustration

## Decision
Tickets 023 and 030 are duplicates of 014. All classified as `bug-report`.

## Rationale
Same sender, same account (MC-4221), same underlying issue (rate limits blocking nightly ingestion). The follow-ups add urgency context but don't represent new issues.

## Action
Treat as a single escalated issue. The lack of response to 014 caused the follow-ups — ensure this gets immediate attention.

---

# ADR-005: TICKET 004 — Pixar Collectables Spam

## Context
Ticket 004 from `kevin.tom@school.edu` asks about "free Pixar character collectables" claimed to be available on Reddit.

## Decision
Classified as `spam-or-noise` with urgency `n/a`.

## Rationale
No such program exists. The ticket references a Reddit post (likely fabricated or from a scam thread). The request for "50 of them" for friends is a telltale sign of a spam/fictitious request.

## Action
No response needed. Archive as spam.
