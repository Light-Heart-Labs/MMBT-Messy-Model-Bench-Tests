# Acquisition Review Memo — Borealis Analytics

**To:** Executive Committee
**From:** [Reviewer], Executive Committee
**Date:** 2026-04-16
**Re:** Assessment of Corp Dev recommendation to proceed to LOI at $84M

---

## Recommendation: HOLD — do not issue LOI until critical diligence gaps are closed

I would **not** approve the LOI in its current form. The deal has merit — the growth trajectory, net retention, and engineering quality are attractive — but the diligence pack contains material gaps, optimistic assumptions, and insufficient scrutiny of downside risks. I would reverse to **PROCEED** if the items below are satisfactorily addressed within two weeks. I would move to **PASS** if any red-flag items (marked ★) prove true.

---

## Strongest Concerns

### 1. ★ Valuation anchor is fragile

The pack justifies $84M (~7.4x ARR) by citing three comparable transactions at 7x–12x ARR. But no detail is provided on deal structure, earnouts, or post-close performance of those targets. The lowest comp (Trellis at 7x) is used as the floor, yet no explanation is given for why Borealis should be valued above it. If the comps included significant earnout components, the effective multiples could be materially lower. **The pack overclaims comparability without substantiating it.**

### 2. ★ Customer concentration and reference-call bias

With ~280 customers and median ARR of $32K, the implied total customer ARR (~$8.96M) is notably below the reported $11.4M ARR, suggesting a right-skewed distribution with a few large customers. The pack does not disclose what percentage of ARR the top five reference-called customers represent. If the top five account for >25% of ARR, the loss of any one would be material. All four quoted testimonials are uniformly positive. **The pack omits any discussion of churned customers, detractors, or the one customer who declined to be quoted.**

### 3. ★ Integration plan assumes 85% retention and a 12-month product sunset

The pack states "~85% retention expected based on conversations with their VP Eng" — a single-source estimate from one person with an incentive to overstate retention. The plan also calls for sunsetting the Aurora platform within 12 months post-close, which is aggressive for 280 active customers. **The pack underexplains the risk of customer attrition during migration.**

### 4. ★ Synergy estimate is asserted, not derived

The $3.2M annual cost savings from "consolidated infra" is stated without any breakdown. We do not know whether this assumes headcount reductions, infrastructure consolidation, or both. **The pack omits the methodology behind this figure entirely.**

### 5. ★ Runway calculation is misleading

The pack states "22 months runway at last cap raise" but current cash is $4.1M at $750K/month burn = ~5.5 months. The 22-month figure is historical and no longer relevant. No explanation is given for why cash dropped from the implied ~$16.5M to $4.1M. **The pack conflates historical runway with current runway without flagging the gap.**

### 6. No competitive landscape discussion

The pack makes no mention of Borealis's competitive landscape, market size, or barriers to entry. **This omission is notable for a strategic rationale section.**

### 7. IRR estimate lacks transparency

The "28-34% risk-adjusted IRR over 4 years" is stated without showing the model inputs. Given the concerns above about valuation, synergies, and retention, this range appears to be an assertion rather than a demonstrated calculation.

---

## Specific Diligence Asks (Next 2 Weeks)

See `/workspace/asks.md` for the full list with owners and deadlines. Key items:

1. **Customer concentration** — What % of ARR do the top 5, 10, and 20 customers represent?
2. **Churned customer interviews** — Speak to at least 3 customers who left Borealis in the past 12 months.
3. **Comp deal deep-dive** — Obtain deal structure details (earnouts, holdbacks) for all three cited comparables.
4. **Retention risk model** — Independent assessment of the 85% retention assumption; stress-test at 60% and 40%.
5. **Synergy derivation** — Detailed breakdown of the $3.2M savings estimate with supporting assumptions.
6. **Current runway recalculation** — Confirm months of runway from current cash at current burn rate.
7. **Competitive landscape memo** — Brief analysis of competitors, market size, and positioning.
8. **IRR model transparency** — Share the model with all inputs visible.

---

## Bottom Line

The deal is not a pass — it has genuine strategic and financial merit. But the diligence pack reads as advocacy, not analysis. Before committing $84M, we need to close the gaps above. I recommend holding the LOI for two weeks to complete these asks, then reconvening.
