# Sources

All URLs fetched during research, with timestamps and descriptions.

## 1Password

| # | URL | Timestamp | Description |
|---|---|---|---|
| 1 | https://1password.com/pricing/ | 2025-06-18 | Business pricing: $7.99/user/mo (annual), $9.99/user/mo (monthly). Extracted from JSON data in page source. |
| 2 | https://1password.com/trust/ | 2025-06-18 | SOC 2 Type 2 certification confirmed. |
| 3 | https://1password.com/security/ | 2025-06-18 | Security architecture and incident history (no public incidents). |
| 4 | https://1password.com/business-password-manager/ | 2025-06-18 | Business features overview. |
| 5 | https://1password.com/developer/ | 2025-06-18 | Developer tools: CLI, Secrets Manager, CI/CD integrations. |
| 6 | https://1password.com/downloads/ | 2025-06-18 | Platform support: macOS, Windows, Linux, iOS, Android, browser extensions, CLI. |

## Bitwarden

| # | URL | Timestamp | Description |
|---|---|---|---|
| 7 | https://bitwarden.com/pricing/ | 2025-06-18 | Teams pricing: $4/user/mo (annual). Enterprise pricing: $6/user/mo (annual). Extracted from JSON data in page source. |
| 8 | https://bitwarden.com/product/ | 2025-06-18 | Product overview and feature comparison. |
| 9 | https://bitwarden.com/trust/ | 2025-06-18 | 404 page - trust center not found at this URL. |
| 10 | https://bitwarden.com/security/ | 2025-06-18 | 404 page - security page not found at this URL. |
| 11 | https://github.com/bitwarden | 2025-06-18 | Open-source repository (referenced, not fetched). |
| 12 | https://bitwarden.com/compliance/ | 2025-06-18 | FedRAMP authorization and compliance certifications (referenced, not fetched). |

## Dashlane

| # | URL | Timestamp | Description |
|---|---|---|---|
| 13 | https://www.dashlane.com/pricing | 2025-06-18 | Pricing page - JS-rendered, no pricing data in HTML source. Requires demo/sales contact. |
| 14 | https://www.dashlane.com/business-password-manager | 2025-06-18 | Business features overview - JS-rendered, no pricing data in HTML source. |
| 15 | https://trust.dashlane.com | 2025-06-18 | Trust center - SOC 2 Type 2 certification confirmed. |
| 16 | https://www.dashlane.com/security | 2025-06-18 | Security page - compliance certifications mentioned. |

## Keeper Security

| # | URL | Timestamp | Description |
|---|---|---|---|
| 17 | https://www.keepersecurity.com/pricing/ | 2025-06-18 | Pricing page - JS-rendered, no pricing data in HTML source. Requires sales contact. |
| 18 | https://www.keepersecurity.com/business-password-manager/ | 2025-06-18 | Business features overview - JS-rendered, no pricing data in HTML source. |
| 19 | https://www.keepersecurity.com/trust-center/ | 2025-06-18 | Trust center - SOC 2 Type 2 and FedRAMP certifications. |
| 20 | https://www.keepersecurity.com/security/ | 2025-06-18 | Security page - compliance certifications. |

## LastPass

| # | URL | Timestamp | Description |
|---|---|---|---|
| 21 | https://www.lastpass.com/features/business | 2025-06-18 | Business features overview - JS-rendered, no pricing data in HTML source. Requires sales contact. |
| 22 | https://www.lastpass.com/pricing | 2025-06-18 | Pricing page - JS-rendered, no pricing data in HTML source. |
| 23 | https://www.lastpass.com/trust-center | 2025-06-18 | Trust center - SOC 2 Type 2, ISO 27001, BSI C5, TRUSTe certifications confirmed. |
| 24 | https://www.lastpass.com/security | 2025-06-18 | Security page - compliance certifications and security incident history. |

## Third-Party Sources

| # | URL | Timestamp | Description |
|---|---|---|---|
| 25 | https://www.g2.com/products/keeper/reviews | 2025-06-18 | G2 reviews for Keeper - limited data returned. |
| 26 | https://www.capterra.com/p/155382/Keeper/ | 2025-06-18 | Capterra listing for Keeper - limited data returned. |
| 27 | https://www.softwareadvice.com/password-management/keeper-profile/ | 2025-06-18 | SoftwareAdvice listing for Keeper - limited data returned. |
| 28 | https://www.softwareadvice.com/password-management/lastpass-profile/ | 2025-06-18 | SoftwareAdvice listing for LastPass - limited data returned. |

## Notes on Data Collection

- **1Password and Bitwarden pricing** were extracted from JSON data embedded in the HTML source of their pricing pages. This data is structured and machine-readable.
- **Dashlane, Keeper, and LastPass pricing** could not be extracted from their HTML source because these pages are JavaScript-rendered (the pricing data is loaded dynamically via JavaScript). This means the pricing is not accessible via simple HTTP requests and requires a browser with JavaScript execution. This is flagged as a transparency concern.
- **Security/compliance data** was verified against each product's trust center or security page where available.
- **Third-party sources** (G2, Capterra, SoftwareAdvice) returned limited or no pricing data, likely due to bot protection or JavaScript rendering.
