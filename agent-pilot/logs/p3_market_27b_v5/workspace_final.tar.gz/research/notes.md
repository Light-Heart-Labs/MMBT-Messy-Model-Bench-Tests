# Research Notes: Password Manager Evaluation

## Date: 2025-06-18
## Context: 50-person engineering team at Series-B SaaS company
## Goal: Standardize on a password manager to replace shadow-IT storage (browser, sticky notes, Slack DMs)

## Products Evaluated
1. **1Password** (AgileBits Inc., Toronto, Canada)
2. **Bitwarden** (8bit Solutions LLC, Austin, TX)
3. **Dashlane** (Dashlane SAS, Paris, France)
4. **Keeper Security** (Keeper Security Inc., San Francisco, CA)
5. **LastPass** (LastPass US LP, Austin, TX)

## Pricing Data Collected

### 1Password (from https://1password.com/pricing/)
- Individual: $2.99/mo (billed annually) / $4.99/mo (monthly)
- Families: $4.49/mo (billed annually) / $7.99/mo (monthly)
- Teams: $19.95/mo (up to 10 users, billed annually) / $24.95/mo (monthly)
- **Business: $7.99/user/mo (billed annually) / $9.99/user/mo (monthly)**

### Bitwarden (from https://bitwarden.com/pricing/)
- Premium (Personal): $1.65/user/mo (billed annually)
- Families: $3.99/mo (billed annually)
- **Teams: $4/user/mo (billed annually)**
- **Enterprise: $6/user/mo (billed annually)**

### Dashlane
- Pricing not publicly listed on website; requires demo/sales contact
- Business and Enterprise tiers available
- AWS Marketplace listing exists

### Keeper Security
- Pricing not publicly listed on website; requires sales contact
- Business and Enterprise tiers available
- No transparent per-seat pricing found

### LastPass
- Pricing not publicly listed on website; requires sales contact
- Teams, Business, and Business SSO+MFA tiers available
- No transparent per-seat pricing found

## Security/Compliance Data

### 1Password
- SOC 2 Type 2 certified (from https://1password.com/trust/)
- Zero-knowledge architecture
- Canadian company (AgileBits Inc.)

### Bitwarden
- Open-source (GitHub: https://github.com/bitwarden)
- SOC 2 Type 2 certified
- FedRAMP authorized

### Dashlane
- SOC 2 Type 2 certified
- Trust Center: https://trust.dashlane.com

### Keeper Security
- SOC 2 Type 2 certified
- FedRAMP authorized

### LastPass
- SOC 2 Type 2 certified
- ISO 27001 certified
- BSI C5 certified
- TRUSTe certified
- **Security incidents: Multiple breaches in 2022 (on-prem and cloud data)**

## Key Findings

1. **Pricing transparency**: Only 1Password and Bitwarden have transparent, publicly listed pricing. Dashlane, Keeper, and LastPass require sales contact.
2. **Open source**: Bitwarden is the only open-source option, allowing independent security audits.
3. **Security incidents**: LastPass had significant breaches in 2022. No major public incidents for 1Password, Bitwarden, Dashlane, or Keeper.
4. **Developer tools**: 1Password has a CLI tool and Secrets Manager. Bitwarden has a CLI and API. Both support CI/CD integration.
5. **SSO integration**: All products support SSO, but Bitwarden's SSO is only in the Enterprise tier ($6/user/mo).

## Decision Criteria
1. SSO integration with Google Workspace
2. Audit log for SOC2 compliance
3. Pricing per seat (transparent)
4. Admin UX
5. Mobile + desktop coverage
6. Developer tool integration (CLI, CI/CD)
7. Security track record
8. Vendor lock-in risk
9. Open-source option (for auditability)
