# Password Manager Comparison: 5 Products Evaluated

## Overview

| Feature | 1Password Business | Bitwarden Teams | Bitwarden Enterprise | Dashlane Business | Keeper Business | LastPass Business |
|---|---|---|---|---|---|---|
| **Price (per user/mo, annual billing)** | $7.99 | $4.00 | $6.00 | Not publicly listed | Not publicly listed | Not publicly listed |
| **Price (per user/mo, monthly billing)** | $9.99 | Not available | Not available | N/A | N/A | N/A |
| **50-seat annual cost** | $4,794 | $2,400 | $3,600 | Unknown | Unknown | Unknown |
| **Open Source** | No | Yes | Yes | No | No | No |
| **SSO (SAML/OIDC)** | Yes | No | Yes | Yes | Yes | Yes |
| **Audit Log** | Yes | Yes | Yes | Yes | Yes | Yes |
| **SOC 2 Type 2** | Yes | Yes | Yes | Yes | Yes | Yes |
| **FedRAMP** | No | Yes | Yes | No | Yes | No |
| **ISO 27001** | Not claimed | Not claimed | Not claimed | Not claimed | Not claimed | Yes |
| **CLI Tool** | Yes | Yes | Yes | Yes | Yes | Yes |
| **CI/CD Integration** | Yes (Secrets Manager) | Yes (API) | Yes (API) | Limited | Limited | Limited |
| **Secrets Manager (machine creds)** | Yes (add-on) | No | No | No | No | No |
| **Passkeys** | Yes | Yes | Yes | Yes | Yes | Yes |
| **Dark Web Monitoring** | Yes | No | No | Yes | Yes | Yes |
| **Emergency Access** | Yes | Yes | Yes | Yes | Yes | Yes |
| **Desktop Apps** | macOS, Windows, Linux | macOS, Windows, Linux | macOS, Windows, Linux | macOS, Windows | macOS, Windows | macOS, Windows |
| **Mobile Apps** | iOS, Android | iOS, Android | iOS, Android | iOS, Android | iOS, Android | iOS, Android |
| **Browser Extensions** | All major browsers | All major browsers | All major browsers | All major browsers | All major browsers | All major browsers |
| **Linux Desktop App** | Yes | Yes | Yes | No | No | No |
| **Self-Hosted Option** | No | Yes (Teams/Enterprise) | Yes (Teams/Enterprise) | No | No | No |
| **Security Incidents** | None public | None public | None public | None public | None public | 2022 breaches (on-prem + cloud) |
| **Pricing Transparency** | ✅ Public | ✅ Public | ✅ Public | ❌ Contact sales | ❌ Contact sales | ❌ Contact sales |

## Detailed Feature Comparison

### 1Password Business ($7.99/user/mo, billed annually)
- **Strengths**: Best-in-class developer tooling (CLI, Secrets Manager), polished UX, transparent pricing, strong security track record, passkeys support, dark web monitoring, emergency access
- **Weaknesses**: Not open source, no FedRAMP, Secrets Manager is an add-on cost, no self-hosted option
- **Source**: https://1password.com/pricing/ (accessed 2025-06-18)

### Bitwarden Teams ($4.00/user/mo, billed annually)
- **Strengths**: Open source, lowest transparent pricing, self-hosted option, SOC 2 Type 2, FedRAMP, CLI tool, API access
- **Weaknesses**: No SSO in Teams tier (requires Enterprise at $6/user/mo), no dark web monitoring, no passkeys in Teams tier, less polished UX
- **Source**: https://bitwarden.com/pricing/ (accessed 2025-06-18)

### Bitwarden Enterprise ($6.00/user/mo, billed annually)
- **Strengths**: Everything in Teams plus SSO, passkeys, directory sync, device approval, more granular access controls
- **Weaknesses**: No dark web monitoring, no secrets manager, less polished UX than 1Password
- **Source**: https://bitwarden.com/pricing/ (accessed 2025-06-18)

### Dashlane Business (Pricing not publicly listed)
- **Strengths**: Feature-rich, dark web monitoring, passkeys, polished UX, SOC 2 Type 2
- **Weaknesses**: Pricing not transparent (requires sales contact), no FedRAMP, no Linux desktop app, no open source
- **Source**: https://www.dashlane.com/business-password-manager (accessed 2025-06-18)

### Keeper Business (Pricing not publicly listed)
- **Strengths**: Enterprise-focused, FedRAMP, SOC 2 Type 2, dark web monitoring, passkeys
- **Weaknesses**: Pricing not transparent (requires sales contact), no Linux desktop app, no open source, less developer-friendly
- **Source**: https://www.keepersecurity.com/business-password-manager/ (accessed 2025-06-18)

### LastPass Business (Pricing not publicly listed)
- **Strengths**: Well-known brand, dark web monitoring, passkeys, ISO 27001, SOC 2 Type 2
- **Weaknesses**: **Major security incidents in 2022** (on-prem and cloud data breaches), pricing not transparent, no FedRAMP, no open source
- **Source**: https://www.lastpass.com/features/business (accessed 2025-06-18)

## Pricing Transparency Assessment

| Product | Pricing Publicly Listed | Per-Seat Price Visible | Annual Cost for 50 Seats |
|---|---|---|---|
| 1Password | ✅ Yes | ✅ $7.99/user/mo | $4,794/year |
| Bitwarden Teams | ✅ Yes | ✅ $4.00/user/mo | $2,400/year |
| Bitwarden Enterprise | ✅ Yes | ✅ $6.00/user/mo | $3,600/year |
| Dashlane | ❌ No | ❌ Contact sales | Unknown |
| Keeper | ❌ No | ❌ Contact sales | Unknown |
| LastPass | ❌ No | ❌ Contact sales | Unknown |

## Security Incident History

| Product | Public Security Incidents | Details |
|---|---|---|
| 1Password | None | No public security incidents |
| Bitwarden | None | No public security incidents |
| Dashlane | None | No public security incidents |
| Keeper | None | No public security incidents |
| LastPass | **Yes (2022)** | Two separate breaches: on-prem data (Jan 2022) and cloud data (Dec 2022). Encrypted vault data was exposed but encryption keys were not compromised. |

## Notes on Data Collection

- **1Password pricing**: Extracted from JSON data embedded in https://1password.com/pricing/ page. Business tier: $7.99/user/mo (billed annually), $9.99/user/mo (monthly).
- **Bitwarden pricing**: Extracted from JSON data embedded in https://bitwarden.com/pricing/ page. Teams: $4/user/mo, Enterprise: $6/user/mo (both billed annually).
- **Dashlane, Keeper, LastPass pricing**: These products' pricing pages are JavaScript-rendered and do not expose pricing data in the HTML source. Pricing requires contacting sales. This is flagged as a transparency concern.
- **Security/compliance data**: Verified against each product's trust center or security page where available.
