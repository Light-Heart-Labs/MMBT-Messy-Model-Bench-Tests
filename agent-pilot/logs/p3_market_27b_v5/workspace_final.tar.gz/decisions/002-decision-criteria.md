# ADR-002: Decision Criteria for "Best for This Team"

## Status
Accepted

## Context
We need to define clear criteria for evaluating which password manager is "best" for our 50-person engineering team at a Series-B SaaS company.

## Decision
The following criteria were established, in order of importance:

### Primary Criteria (Must-Have)
1. **SSO Integration** - Must support SSO with Google Workspace (our IdP)
2. **Audit Logging** - Must provide audit logs for SOC2 compliance
3. **Transparent Pricing** - Per-seat pricing must be publicly available (no "contact sales")
4. **Platform Coverage** - Must support macOS, Windows, Linux, iOS, Android, and browser extensions
5. **Developer Tooling** - Must have CLI tool and CI/CD integration capabilities

### Secondary Criteria (Nice-to-Have)
6. **Open Source** - Codebase should be auditable by third parties
7. **Admin UX** - Admin console should be intuitive for non-security staff
8. **Secrets Management** - Native support for machine/API credentials
9. **Security Track Record** - No major public security incidents
10. **Vendor Lock-in** - Easy export of credentials if switching later

## Rationale
- **SSO** is critical because our team already uses Google Workspace for identity management
- **Audit logging** is required for our SOC2 compliance efforts
- **Transparent pricing** is essential for budget planning at a Series-B company
- **Platform coverage** is non-negotiable for a distributed engineering team
- **Developer tooling** is critical because our team uses CI/CD pipelines and needs to manage secrets
- **Open source** is preferred for security auditability but not required
- **Admin UX** matters because our IT team is small and needs easy management
- **Secrets management** is important for managing API keys and service accounts
- **Security track record** is critical for trust
- **Vendor lock-in** is a concern for long-term flexibility

## Alternatives Considered
- We considered weighting criteria differently, but the above order reflects the team's priorities
- We considered adding "cost" as a primary criterion, but it's already captured in "Transparent Pricing"

## Consequences
- Products without transparent pricing (Dashlane, Keeper, LastPass) are at a significant disadvantage
- Products without SSO in their base tier (Bitwarden Teams) may need to upgrade to Enterprise
- Products without CLI tools or CI/CD integration may not meet developer needs
