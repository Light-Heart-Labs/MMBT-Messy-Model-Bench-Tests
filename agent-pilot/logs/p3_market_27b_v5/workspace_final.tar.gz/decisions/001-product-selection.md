# ADR-001: Product Selection for Password Manager Evaluation

## Status
Accepted

## Context
The engineering team needs to standardize on a password manager. We need to evaluate the most relevant options for a 50-person engineering team at a Series-B SaaS company.

## Decision
We evaluated 5 password managers:
1. **1Password** - Market leader, strong developer tooling, transparent pricing
2. **Bitwarden** - Open-source, lowest pricing, strong security posture
3. **Dashlane** - Feature-rich, but pricing not transparent
4. **Keeper Security** - Enterprise-focused, but pricing not transparent
5. **LastPass** - Well-known brand, but significant security incident history

## Rationale
- These 5 represent the most commonly recommended password managers for teams
- They span the spectrum from open-source (Bitwarden) to proprietary (1Password, Dashlane, Keeper, LastPass)
- They cover different pricing models (transparent vs. sales-contact required)
- They represent different security postures (open-source auditable vs. proprietary)

## Alternatives Considered
- **Passbolt** - Open-source but less mature for team use
- **Proton Pass** - Newer entrant, limited enterprise features
- **NordPass** - Consumer-focused, limited team features
- **RoboForm** - Less commonly recommended for teams

## Consequences
- Products without transparent pricing (Dashlane, Keeper, LastPass) are at a disadvantage for budget planning
- LastPass's security incident history is a significant concern
- Bitwarden's open-source nature provides auditability but may have less polished UX
