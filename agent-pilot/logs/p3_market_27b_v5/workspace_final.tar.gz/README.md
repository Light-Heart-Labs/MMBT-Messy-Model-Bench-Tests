# Password Manager Recommendation — How to Read This Output

## Quick Start

- **📄 Recommendation memo:** [`recommendation.md`](recommendation.md) — The 1-2 page decision memo with our primary recommendation (1Password Business), runner-up (Bitwarden Enterprise), pricing math, and risks.
- **📊 Side-by-side comparison:** [`comparison.md`](comparison.md) — Feature/pricing/security table for all 5 products evaluated.
- **🔗 Sources:** [`sources.md`](sources.md) — Every URL fetched, with timestamps and descriptions of what was obtained.

## Detailed Structure

| File | Purpose |
|---|---|
| `recommendation.md` | Primary deliverable: decision criteria, product recommendation, runner-up, concerns/risks, implementation timeline |
| `comparison.md` | Side-by-side comparison of 1Password, Bitwarden (Teams + Enterprise), Dashlane, Keeper, and LastPass |
| `sources.md` | Complete list of URLs fetched with timestamps and descriptions |
| `research/notes.md` | Working notes from the research process |
| `decisions/001-product-selection.md` | ADR: Which 5 products were evaluated and why |
| `decisions/002-decision-criteria.md` | ADR: Decision criteria for "best for this team" |

## Key Findings at a Glance

| Product | Price (50 seats/year) | SSO | Audit Log | Open Source | Pricing Transparent |
|---|---|---|---|---|---|
| **1Password Business** | **$4,794** | ✅ | ✅ | ❌ | ✅ |
| **Bitwarden Enterprise** | **$3,600** | ✅ | ✅ | ✅ | ✅ |
| Bitwarden Teams | $2,400 | ❌ | ✅ | ✅ | ✅ |
| Dashlane | Unknown | ✅ | ✅ | ❌ | ❌ |
| Keeper | Unknown | ✅ | ✅ | ❌ | ❌ |
| LastPass | Unknown | ✅ | ✅ | ❌ | ❌ |

## Recommendation

**1Password Business at $7.99/user/month (billed annually)** — $4,794/year for 50 seats.

**Runner-up: Bitwarden Enterprise at $6.00/user/month (billed annually)** — $3,600/year for 50 seats.

See `recommendation.md` for full rationale.

## Methodology

- All pricing data was extracted from official product websites via HTTP requests.
- Security/compliance claims were verified against each product's trust center or security page.
- Products with JavaScript-rendered pricing pages (Dashlane, Keeper, LastPass) were flagged for pricing opacity.
- No fabricated data: where pricing could not be verified, "Unknown" or "Contact sales" is stated explicitly.
