# ADR-002: Update `test_line_count_matches_qty_sum` for v0.3.0 API change

## Status

Accepted

## Context

The v0.3.0 changelog states:
> `Cart.line_count()` now returns the number of lines, not the total quantity
> across lines. Tests should be updated where they relied on the old behavior.

The test `test_line_count_matches_qty_sum` was not updated and still expected
the old behavior (total quantity = 5). The implementation correctly returns
the number of lines (2).

## Decision

Update the test to match the documented v0.3.0 behavior:
- Change assertion from `assert c.line_count() == 5` to `assert c.line_count() == 2`
- Update the docstring to say "number of lines" instead of "total quantity"

## Rationale

- The changelog explicitly documents this as an intentional API change
- The implementation matches the documented behavior
- The test was simply not updated during the v0.3.0 migration

## Consequences

- The test now correctly validates the v0.3.0 `line_count()` behavior
- No code changes needed in `cart.py`
