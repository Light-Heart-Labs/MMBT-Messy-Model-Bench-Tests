# ADR-001: Fix `discount_amount` to divide by 100

## Status

Accepted

## Context

The v0.3.0 changelog documents a breaking change: `discount_amount()` and
`apply_discount()` now take percent (0–100) instead of fraction (0.0–1.0).
However, the implementation in `discount.py` was updated to validate the new
range but never added the `/100` conversion. This caused `discount_amount(100, 20)`
to return `2000` instead of `20`.

## Decision

Fix the implementation by adding `/100` to the calculation:
```python
return round(price * percent_off / 100, 2)
```

## Rationale

- The docstring examples show `discount_amount(100.0, 20.0) -> 20.0`
- The tests expect the same behavior
- The changelog documents percent-based input
- The code was clearly a migration oversight

## Consequences

- `discount_amount` and `apply_discount` now return correct values
- All discount-related tests pass
