# Extraction Notes — Veridyne Networks Q3 FY2026 Press Release

## Summary
All 20 schema fields were found in the press release. No fields required `null` or placement in the `uncertain` array.

## Field-by-Field Decisions

### `company_name`
- Extracted: `"Veridyne Networks, Inc."`
- Source: First paragraph — "Veridyne Networks, Inc. (NASDAQ: VRDN)"
- This is the full legal name as used in the dateline.

### `ticker_symbol`
- Extracted: `"VRDN"`
- Source: "(NASDAQ: VRDN)" in first paragraph.
- Schema notes say "Accept 'NASDAQ: VRDN' if separated" — extracted just the symbol.

### `fiscal_period`
- Extracted: `"Q3 FY2026"`
- Source: Headline "Veridyne Networks Reports Fiscal Q3 2026 Results" and section header "Q3 FY2026 Financial Highlights".

### `fiscal_period_end_date`
- Extracted: `"2026-02-28"`
- Source: "third fiscal quarter ended February 28, 2026".

### `total_revenue_usd_millions`
- Extracted: `187.4`
- Source: "Total revenue of $187.4 million"

### `revenue_yoy_growth_pct`
- Extracted: `38`
- Source: "up 38% year-over-year"

### `subscription_revenue_usd_millions`
- Extracted: `171.2`
- Source: "Subscription revenue of $171.2 million"

### `gaap_gross_margin_pct`
- Extracted: `76.3`
- Source: "GAAP gross margin of 76.3%"

### `non_gaap_operating_income_usd_millions`
- Extracted: `9.8`
- Source: "Non-GAAP operating income of $9.8 million"
- Note: This is positive income (not loss). The year-ago quarter had a loss of $4.1M, but the current quarter is positive.

### `total_customers`
- Extracted: `4117`
- Source: "Total customers grew to 4,117"

### `customers_above_100k_arr`
- Extracted: `1082`
- Source: "Customers contributing more than $100,000 in annual recurring revenue (ARR) grew to 1,082"

### `customers_above_1m_arr`
- Extracted: `71`
- Source: "Customers contributing more than $1 million in ARR grew to 71"

### `net_dollar_retention_pct`
- Extracted: `124`
- Source: "Net dollar retention rate of 124% for the trailing twelve months"

### `total_arr_usd_millions`
- Extracted: `710`
- Source: "Total ARR exceeded $710 million as of quarter-end"
- Note: The press release says "exceeded" — per schema guidance, extracted the stated figure of 710.

### `fte_count_end_of_q3`
- Extracted: `1847`
- Source: "The Company ended the quarter with 1,847 full-time employees"

### `stitchwise_acquisition_total_consideration_usd_millions`
- Extracted: `115`
- Source: "Total consideration was approximately $115 million"
- Note: The press release says "approximately" — per schema guidance, extracted the stated figure of 115.

### `stitchwise_close_date`
- Extracted: `"2026-01-22"`
- Source: "closed its acquisition of Stitchwise Labs, Inc. ... on January 22, 2026"

### `fy2026_revenue_guidance_low_usd_millions`
- Extracted: `722`
- Source: "Total revenue: $722-$726 million"

### `fy2026_revenue_guidance_high_usd_millions`
- Extracted: `726`
- Source: "Total revenue: $722-$726 million"

### `share_repurchase_authorization_usd_millions`
- Extracted: `200`
- Source: "share repurchase program of up to $200 million"
