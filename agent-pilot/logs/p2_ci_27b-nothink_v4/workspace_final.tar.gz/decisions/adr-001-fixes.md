# ADR-001: Fix `discount_amount` implementation, not the tests

**Status:** Accepted

**Context:** The v0.3.0 changelog documented a breaking API change from fraction (0.0–1.0) to percent (0–100). The tests were written for the new percent-based API (e.g., `discount_amount(100.0, 20.0) == 20.0`), but the implementation still used the old fraction-style multiplication (`price * percent_off` without dividing by 100).

**Decision:** Fix the implementation to divide by 100. The tests were correct; the code was buggy.

**Consequences:** `discount_amount` and `apply_discount` now work correctly with percent values.

---

# ADR-002: Fix `test_line_count_matches_qty_sum` test, not the code

**Status:** Accepted

**Context:** The v0.3.0 changelog explicitly states that `Cart.line_count()` was changed to return the number of lines (not total quantity). The code was correctly updated (`return len(self.lines)`), but the test still expected the old behavior (total quantity = 5).

**Decision:** Update the test to match the documented v0.3.0 API. The code was correct; the test was stale.

**Consequences:** The test now correctly validates that `line_count()` returns the number of cart lines.
