# Diagnosis

## CI Failure Analysis

The CI log showed 1 ruff error and 3 test failures.

### Issue 1: Ruff F401 — unused `import json` in `cart.py`

**What was wrong:** `cart.py` imported `json` but never used it. The comment in the code even says "PLANTED BUG #3".

**Fix:** Removed the import line.

**Decision:** Code fix (trivial, no ambiguity).

---

### Issue 2: `discount_amount(100.0, 20.0)` returns `2000.0` instead of `20.0`

**What was wrong:** The v0.3.0 changelog says the API changed from fraction (0.0–1.0) to percent (0–100). The docstring examples confirm: `discount_amount(100.0, 20.0) -> 20.0`. But the implementation was `price * percent_off` (no division by 100), so it treated the percent as if it were already a multiplier.

**Fix:** Changed `return round(price * percent_off, 2)` to `return round(price * percent_off / 100, 2)`.

**Decision:** Code fix. The tests were correct (they matched the documented API). The implementation was buggy — the v0.3.0 migration was incomplete.

---

### Issue 3: `test_line_count_matches_qty_sum` expects 5 but gets 2

**What was wrong:** The v0.3.0 changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines." The code was correctly updated to `return len(self.lines)`, but the test was not updated and still expected the old behavior (sum of quantities = 5).

**Fix:** Updated the test to expect 2 (the number of lines) and updated the docstring comment.

**Decision:** Test fix. The code was correct per the v0.3.0 changelog. The test was stale.

---

### Issue 4: Ruff I001, UP006, UP035, UP045 — import sorting and typing modernization

**What was wrong:** Import blocks were unsorted, and `typing.List` / `typing.Optional` were used instead of modern Python 3.10+ syntax.

**Fix:** Applied `ruff --fix` to auto-correct all of these.

**Decision:** Code fix (auto-fixable, no ambiguity).
