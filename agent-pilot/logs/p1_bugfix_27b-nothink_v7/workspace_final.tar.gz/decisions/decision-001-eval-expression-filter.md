# Decision-001: Expression filter uses eval() — alternatives considered

## Context

The `--expr` CLI flag allows users to filter log entries using Python
expressions (e.g., `--expr "entry.status >= 500"`). This is implemented
using `eval()` with `__builtins__` set to an empty dict.

## Alternatives Considered

1. **Remove `--expr` entirely** — Safest option, but removes a useful
   feature that power users may depend on.

2. **Use `ast.literal_eval`** — Only supports literals (numbers, strings,
   lists, dicts), not expressions with comparisons. Not viable.

3. **Use a proper expression parser** (e.g., `asteval`, `simpleeval`) —
   Would require adding a dependency. Overkill for a small CLI tool.

4. **Keep `eval()` with restricted builtins** — The current approach.
   With `__builtins__={}`, the expression can only access the `entry`
   variable and its attributes. While not perfectly sandboxed (Python's
   `eval` can be exploited through object introspection in some cases),
   the risk is low for a CLI tool where the user controls the expression.

## Decision

Keep `eval()` with restricted builtins. The `--expr` feature is useful
for advanced filtering, and the security risk is acceptable for a CLI
tool where the user is running the expression on their own machine against
their own data.

## Rationale

- The user who runs `logalyzer --expr "..."` is the one providing the
  expression, so they are essentially running code on their own machine.
- The restricted builtins prevent access to `__import__`, `open`, etc.
- Adding a dependency for a proper sandbox would increase maintenance
  burden for a small project.

## Note

If this tool were to be used in a web service context where untrusted
users could supply expressions, the `eval()` approach would need to be
replaced with a proper sandbox.
