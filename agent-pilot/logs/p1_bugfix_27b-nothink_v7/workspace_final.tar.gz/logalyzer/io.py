"""File loading helpers."""
from __future__ import annotations

from typing import Iterable

from .parser import LogEntry, parse_line


def load(path: str) -> list[LogEntry]:
    """Load all log entries from a file.

    Reads the file line by line and collects parsed entries.
    """
    result: list[LogEntry] = []
    with open(path, "r") as f:
        for line in f:
            entry = parse_line(line)
            if entry is not None:
                result.append(entry)
    return result


def load_iter(path: str) -> Iterable[LogEntry]:
    """Like `load`, but as a generator. Useful for very large files."""
    with open(path, "r") as f:
        for line in f:
            entry = parse_line(line)
            if entry is not None:
                yield entry
