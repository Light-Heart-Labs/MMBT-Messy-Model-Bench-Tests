"""logalyzer — web server log analysis CLI."""

__version__ = "0.4.0"
