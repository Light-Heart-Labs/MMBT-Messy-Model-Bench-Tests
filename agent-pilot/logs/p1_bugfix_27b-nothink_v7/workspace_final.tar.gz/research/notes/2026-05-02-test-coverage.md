# Research Notes — Session 3: Test Coverage Expansion (2026-05-02)

## Objective
Increase test coverage from 34% to a reasonable level.

## Modules with 0% Coverage (Before)
- `cli.py` — No tests at all
- `io.py` — No tests at all
- `output.py` — No tests at all
- `utils.py` — No tests at all
- `experimental.py` — No tests at all

## Actions Taken
Created 5 new test files:
- `test_cli.py` — 8 tests covering argument parsing and main() flow
- `test_io.py` — 7 tests covering load() and load_iter()
- `test_output.py` — 12 tests covering all formatters
- `test_utils.py` — 7 tests covering parse_iso_date and format_bytes
- `test_experimental.py` — 8 tests covering anomaly detection and sessions

## Result
Coverage increased from 34% to 93%.

## Remaining Uncovered Lines
- `cli.py` lines 70-76, 91, 109 — Edge cases in main() (empty entries,
  version flag, __main__ guard)
- `filters.py` line 58 — expression_filter's eval call (hard to test
  without actually running eval)
- `output.py` lines 66, 76-77 — CSV rendering edge cases
- `parser.py` lines 50, 79-80, 99-102 — Error paths and parse_lines()
- `utils.py` line 18 — format_bytes edge case for very large numbers
