# Research Notes — Session 1: Initial Audit (2026-05-02)

## Objective
Catalog all issues in the starter codebase before making any changes.

## Findings

### Critical Issues
1. **Missing "Jul" in MONTH_NAMES** — `parse_timestamp()` fails for July
   dates. The list has 11 entries instead of 12.
2. **`from collections import Iterable`** — Removed in Python 3.10.
   Prevents module import entirely.
3. **`status_filter` type mismatch** — CLI passes string, filter compares
   with int. Never matches.

### Performance Issues
4. **`io.load()` is O(n²)** — Character-by-character string concatenation
   and list concatenation. The 50 MB benchmark times out (>300s).
5. **`ip_allowlist_filter` uses list** — O(n) lookup per entry. Should
   be a set for O(1).

### Bugs
6. **`by_hour` uses `time.localtime()`** — Depends on system timezone.
   Should use UTC directly from the datetime.
7. **`url_regex_filter` uses `re.match`** — Only matches at start of
   string. Should use `re.search`.
8. **`to_json` builds JSON by hand** — Produces invalid JSON for values
   with quotes.
9. **`render_aggregate` doesn't support CSV** — CLI accepts `--format csv`
   but the function raises ValueError.

### Dead Code
10. **`experimental.py`** — Never imported anywhere.
11. **`format_legacy()`** — Unused legacy function.
12. **`chunked()`** — Unused utility.

### Documentation Lies
13. **README claims "Real-time tail mode"** — Not implemented.
14. **README claims "feature-complete and ready for production"** —
    Multiple critical bugs exist.
15. **Version mismatch** — `__init__.py` says 0.2.0, `pyproject.toml`
    says 0.3.1.

### Security
16. **`eval()` in expression_filter** — Even with empty builtins, eval
    can be exploited through object introspection.
