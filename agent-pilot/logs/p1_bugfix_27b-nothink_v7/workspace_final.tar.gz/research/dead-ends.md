# Dead Ends — Fixes Attempted and Reverted

## 1. Attempted to replace eval() with ast-based expression evaluation

**What I tried:** Replaced `eval(expr, {"__builtins__": {}}, {"entry": entry})`
with an `ast.parse()` + custom visitor approach that would only allow
attribute access, comparisons, and boolean operations.

**Why it didn't work:** The ast-based approach was significantly more
complex (60+ lines of visitor code) and still had edge cases (e.g.,
handling `entry.timestamp.hour` requires traversing nested attribute
access). For a small CLI tool, the complexity wasn't justified.

**Resolution:** Kept `eval()` with restricted builtins. Documented the
trade-off in `decisions/decision-001-eval-expression-filter.md`.

## 2. Attempted to use `datetime.fromisoformat()` for timestamp parsing

**What I tried:** Replaced the custom `parse_timestamp()` regex-based
parser with `datetime.fromisoformat()` after converting the Apache
timestamp format to ISO 8601.

**Why it didn't work:** `datetime.fromisoformat()` in Python 3.11 doesn't
handle the Apache timestamp format directly. The conversion step
(DD/Mon/YYYY:HH:MM:SS ±HHMM → YYYY-MM-DDTHH:MM:SS±HH:MM) was just as
complex as the original regex approach, and the regex approach is more
readable for this specific format.

**Resolution:** Kept the regex-based parser. It's clear, well-tested, and
handles the Apache format correctly.

## 3. Attempted to delete experimental.py entirely

**What I tried:** Removed the entire `experimental.py` module since it
wasn't used anywhere.

**Why it didn't work:** The functions (`detect_anomalies` and
`session_window`) are genuinely useful for log analysis. Deleting them
would mean reimplementing them later if someone wanted anomaly detection.
The module docstring indicated it was "in-progress" — suggesting the
previous maintainer intended to wire it in.

**Resolution:** Kept the module but marked it as experimental with a
clear `__all__` export list and updated docstring. Documented in
`architecture/adr-001-dead-code.md`.
