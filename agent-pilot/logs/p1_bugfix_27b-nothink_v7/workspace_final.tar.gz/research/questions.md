# Questions and Resolutions

## 1. Should the benchmark use `load()` or `load_iter()`?

**Question:** The benchmark uses `load()` which loads all entries into
memory. The CLI uses `load_iter()` which streams. Should the benchmark
test the streaming path instead?

**Resolution:** Keep `load()` in the benchmark because it tests the
function that had the O(n²) bug. The streaming path (`load_iter`) was
already efficient. The benchmark measures the fix that matters most.

## 2. Should `format_legacy()` and `chunked()` be deprecated instead of removed?

**Question:** These functions in `utils.py` are unused but might be
called by external scripts. Should we add deprecation warnings instead
of removing them?

**Resolution:** Removed them. No evidence of external dependents exists,
and keeping dead code increases maintenance burden. If someone needs
them, they can be restored from git history.

## 3. Should the `--expr` flag be removed due to security concerns?

**Question:** `eval()` is a security risk. Should we remove the
`--expr` feature entirely?

**Resolution:** Kept it. The user runs the expression on their own machine
against their own data. The risk is low for a CLI tool. Documented in
`decisions/decision-001-eval-expression-filter.md`.

## 4. Should `by_hour` use `e.timestamp.hour` or `e.timestamp.astimezone().hour`?

**Question:** The original code used `time.localtime()` which converts to
the system timezone. Should we preserve that behavior or always use UTC?

**Resolution:** Always use UTC. The timestamps are stored in UTC, and
using the system timezone would produce inconsistent results across
machines. The test `test_by_hour_uses_utc_not_local_time` validates this.

## 5. Should the README claim about "Real-time tail mode" be implemented?

**Question:** The README claims a "Real-time tail mode" feature that
doesn't exist. Should I implement it or remove the claim?

**Resolution:** Removed the claim. Implementing a tail mode would require
significant additional work (file watching, signal handling) that is
beyond the scope of stabilization. The README now accurately reflects
what the tool does.

## 6. Should I fix the `render_aggregate` CSV format or just the CLI workaround?

**Question:** The CLI had a workaround that converted CSV to text for
aggregate output. Should I fix `render_aggregate` to support CSV, or
just keep the workaround?

**Resolution:** Fixed `render_aggregate` to properly support CSV format.
This makes the feature work as documented and removes the silent
degradation in the CLI.

## 7. What version should the final release be?

**Question:** The pyproject.toml says 0.3.1 but the code had critical
bugs. Should I bump to 0.4.0 or keep 0.3.1?

**Resolution:** Bumped to 0.4.0 since this release fixes critical bugs
that were present in the 0.3.x line. The version bump signals to users
that significant fixes have been made.
