"""Tests for experimental module."""
from __future__ import annotations

from datetime import datetime, timezone, timedelta

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def make_entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


def test_detect_anomalies_empty():
    assert detect_anomalies([]) == []


def test_detect_anomalies_no_anomalies():
    """Uniform traffic should produce no anomalies."""
    entries = [make_entry(timestamp=datetime(2026, 1, 1, 12, i, 0, tzinfo=timezone.utc))
               for i in range(10)]
    result = detect_anomalies(entries)
    assert result == []


def test_detect_anomalies_detects_spike():
    """A large spike in one minute should be detected as anomalous."""
    entries = []
    # Normal traffic: 1 request per minute for 100 minutes
    for i in range(100):
        entries.append(make_entry(
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
            + timedelta(minutes=i)
        ))
    # Spike: 100 requests in one minute
    spike_time = datetime(2026, 1, 1, 13, 0, 0, tzinfo=timezone.utc)
    for _ in range(100):
        entries.append(make_entry(timestamp=spike_time))

    result = detect_anomalies(entries)
    assert len(result) > 0
    assert spike_time.replace(second=0, microsecond=0) in result


def test_session_window_empty():
    assert session_window([]) == []


def test_session_window_single_entry():
    entries = [make_entry()]
    sessions = session_window(entries)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    assert ip == "10.0.0.1"
    assert len(session_entries) == 1


def test_session_window_splits_on_gap():
    """Entries with a gap > window_seconds should be split into sessions."""
    t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    t2 = t1 + timedelta(minutes=40)  # 40 min gap > 30 min default
    entries = [
        make_entry(timestamp=t1),
        make_entry(timestamp=t2),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2


def test_session_window_groups_same_ip():
    """Entries from the same IP within the window should be one session."""
    t1 = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    t2 = t1 + timedelta(minutes=10)  # 10 min gap < 30 min default
    entries = [
        make_entry(timestamp=t1),
        make_entry(timestamp=t2),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    assert len(sessions[0][1]) == 2


def test_session_window_separate_ips():
    """Entries from different IPs should be separate sessions."""
    entries = [
        make_entry(ip="10.0.0.1"),
        make_entry(ip="10.0.0.2"),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 2
