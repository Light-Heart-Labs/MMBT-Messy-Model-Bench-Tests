"""Tests for file I/O helpers."""
from __future__ import annotations

import os
import tempfile

from logalyzer.io import load, load_iter
from logalyzer.parser import LogEntry


SAMPLE_LINE = (
    '10.0.0.1 - - [15/Jan/2026:08:30:00 +0000] '
    '"GET /index.html HTTP/1.1" 200 1234\n'
)


def test_load_returns_list_of_entries():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(SAMPLE_LINE)
        f.write(SAMPLE_LINE)
        path = f.name
    try:
        entries = load(path)
        assert isinstance(entries, list)
        assert len(entries) == 2
        assert all(isinstance(e, LogEntry) for e in entries)
    finally:
        os.unlink(path)


def test_load_handles_empty_file():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        path = f.name
    try:
        entries = load(path)
        assert entries == []
    finally:
        os.unlink(path)


def test_load_handles_file_without_trailing_newline():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(SAMPLE_LINE.rstrip("\n"))
        path = f.name
    try:
        entries = load(path)
        assert len(entries) == 1
    finally:
        os.unlink(path)


def test_load_skips_malformed_lines():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(SAMPLE_LINE)
        f.write("this is garbage\n")
        f.write(SAMPLE_LINE)
        path = f.name
    try:
        entries = load(path)
        assert len(entries) == 2
    finally:
        os.unlink(path)


def test_load_iter_is_a_generator():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(SAMPLE_LINE)
        path = f.name
    try:
        result = load_iter(path)
        entries = list(result)
        assert len(entries) == 1
    finally:
        os.unlink(path)


def test_load_and_load_iter_produce_same_results():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(SAMPLE_LINE * 5)
        path = f.name
    try:
        loaded = load(path)
        iterated = list(load_iter(path))
        assert loaded == iterated
    finally:
        os.unlink(path)


def test_load_handles_dash_bytes():
    line = (
        '10.0.0.1 - - [15/Jan/2026:08:30:00 +0000] '
        '"GET / HTTP/1.1" 304 -\n'
    )
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(line)
        path = f.name
    try:
        entries = load(path)
        assert len(entries) == 1
        assert entries[0].bytes == 0
    finally:
        os.unlink(path)
