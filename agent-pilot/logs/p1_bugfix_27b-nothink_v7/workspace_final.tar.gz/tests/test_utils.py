"""Tests for utility functions."""
from __future__ import annotations

from datetime import datetime, timezone

from logalyzer.utils import format_bytes, parse_iso_date


def test_parse_iso_date_midnight_utc():
    result = parse_iso_date("2026-01-15")
    assert result == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_december():
    result = parse_iso_date("2026-12-31")
    assert result == datetime(2026, 12, 31, 0, 0, 0, tzinfo=timezone.utc)


def test_format_bytes_small():
    assert format_bytes(0) == "0.0 B"
    assert format_bytes(500) == "500.0 B"


def test_format_bytes_kb():
    assert format_bytes(1024) == "1.0 KB"
    assert format_bytes(2048) == "2.0 KB"


def test_format_bytes_mb():
    assert format_bytes(1024 * 1024) == "1.0 MB"


def test_format_bytes_gb():
    assert format_bytes(1024 ** 3) == "1.0 GB"


def test_format_bytes_tb():
    assert format_bytes(1024 ** 4) == "1.0 TB"
