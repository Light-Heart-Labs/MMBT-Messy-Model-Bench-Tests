"""Tests for output formatters."""
from __future__ import annotations

import json

from datetime import datetime, timezone

from logalyzer.output import (
    render_aggregate,
    to_csv,
    to_json,
    to_text,
)
from logalyzer.parser import LogEntry


def make_entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


def test_to_json_produces_valid_json():
    entries = [make_entry(ip="1.2.3.4", url="/test")]
    result = to_json(entries)
    parsed = json.loads(result)
    assert isinstance(parsed, list)
    assert len(parsed) == 1
    assert parsed[0]["ip"] == "1.2.3.4"
    assert parsed[0]["url"] == "/test"


def test_to_json_escapes_special_characters():
    """URLs with quotes must be properly escaped in JSON output."""
    entries = [make_entry(url='/search?q="test"')]
    result = to_json(entries)
    # Should be valid JSON
    parsed = json.loads(result)
    assert parsed[0]["url"] == '/search?q="test"'


def test_to_json_empty_list():
    result = to_json([])
    assert result == "[]"


def test_to_csv_has_header_row():
    entries = [make_entry()]
    result = to_csv(entries)
    # csv.writer uses \r\n line endings
    lines = result.strip().splitlines()
    assert lines[0] == "ip,user,timestamp,method,url,protocol,status,bytes"
    assert len(lines) == 2


def test_to_csv_escapes_commas_in_values():
    """Values containing commas must be properly quoted in CSV."""
    entries = [make_entry(url="/path?a=1,b=2")]
    result = to_csv(entries)
    lines = result.strip().splitlines()
    # The URL with comma should be quoted
    assert len(lines) == 2


def test_to_text_one_line_per_entry():
    entries = [
        make_entry(ip="10.0.0.1", url="/a"),
        make_entry(ip="10.0.0.2", url="/b"),
    ]
    result = to_text(entries)
    lines = result.split("\n")
    assert len(lines) == 2
    assert "10.0.0.1" in lines[0]
    assert "/a" in lines[0]


def test_to_text_empty_list():
    result = to_text([])
    assert result == ""


def test_render_aggregate_text_format():
    from collections import Counter
    agg = Counter({"200": 5, "404": 2})
    result = render_aggregate(agg, fmt="text")
    assert "200" in result
    assert "5" in result


def test_render_aggregate_json_format():
    from collections import Counter
    agg = Counter({"200": 5, "404": 2})
    result = render_aggregate(agg, fmt="json")
    parsed = json.loads(result)
    assert parsed["200"] == 5
    assert parsed["404"] == 2


def test_render_aggregate_csv_format():
    from collections import Counter
    agg = Counter({"200": 5, "404": 2})
    result = render_aggregate(agg, fmt="csv")
    lines = result.strip().splitlines()
    assert lines[0] == "key,value"
    assert len(lines) == 3


def test_render_aggregate_list_format():
    """Test with list of tuples (as returned by by_url)."""
    agg = [("/a", 3), ("/b", 1)]
    result = render_aggregate(agg, fmt="text")
    assert "/a" in result
    assert "3" in result


def test_render_aggregate_unknown_format_raises():
    import pytest
    with pytest.raises(ValueError, match="unknown format"):
        render_aggregate({}, fmt="xml")
