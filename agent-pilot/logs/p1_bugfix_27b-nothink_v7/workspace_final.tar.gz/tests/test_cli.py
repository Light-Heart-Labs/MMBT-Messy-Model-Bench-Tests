"""Tests for CLI entry point."""
from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import patch

from logalyzer.cli import build_parser, main
from logalyzer.parser import LogEntry


def make_entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


def test_build_parser_has_all_expected_args():
    p = build_parser()
    # Check that all expected arguments are present
    actions = {a.dest for a in p._actions}
    assert "paths" in actions
    assert "status" in actions
    assert "url" in actions
    assert "ip" in actions
    assert "since" in actions
    assert "until" in actions
    assert "expr" in actions
    assert "aggregate" in actions
    assert "top" in actions
    assert "format" in actions


def test_main_with_no_filters_prints_entries(capsys):
    entries = [make_entry(url="/hello", status=200)]
    with patch("logalyzer.cli.load_iter", return_value=iter(entries)):
        main(["/fake/path.log"])
    captured = capsys.readouterr()
    assert "/hello" in captured.out


def test_main_with_status_filter(capsys):
    entries = [
        make_entry(status=200, url="/ok"),
        make_entry(status=500, url="/error"),
    ]
    with patch("logalyzer.cli.load_iter", return_value=iter(entries)):
        main(["--status", "500", "/fake/path.log"])
    captured = capsys.readouterr()
    assert "/error" in captured.out
    assert "/ok" not in captured.out


def test_main_with_aggregate_status(capsys):
    entries = [
        make_entry(status=200),
        make_entry(status=200),
        make_entry(status=404),
    ]
    with patch("logalyzer.cli.load_iter", return_value=iter(entries)):
        main(["--aggregate", "status", "/fake/path.log"])
    captured = capsys.readouterr()
    assert "200" in captured.out
    assert "404" in captured.out


def test_main_with_aggregate_url_top(capsys):
    entries = [make_entry(url=f"/page{i}") for i in range(10)]
    with patch("logalyzer.cli.load_iter", return_value=iter(entries)):
        main(["--aggregate", "url", "--top", "3", "/fake/path.log"])
    captured = capsys.readouterr()
    lines = captured.out.strip().split("\n")
    assert len(lines) == 3


def test_main_json_format(capsys):
    entries = [make_entry(ip="1.2.3.4", url="/test")]
    with patch("logalyzer.cli.load_iter", return_value=iter(entries)):
        main(["--format", "json", "/fake/path.log"])
    captured = capsys.readouterr()
    assert '"ip"' in captured.out
    assert '"1.2.3.4"' in captured.out


def test_main_csv_format(capsys):
    entries = [make_entry(ip="1.2.3.4", url="/test")]
    with patch("logalyzer.cli.load_iter", return_value=iter(entries)):
        main(["--format", "csv", "/fake/path.log"])
    captured = capsys.readouterr()
    assert "ip" in captured.out
    assert "1.2.3.4" in captured.out


def test_main_aggregate_csv_format(capsys):
    entries = [make_entry(status=200), make_entry(status=404)]
    with patch("logalyzer.cli.load_iter", return_value=iter(entries)):
        main(["--aggregate", "status", "--format", "csv", "/fake/path.log"])
    captured = capsys.readouterr()
    assert "key" in captured.out
    assert "value" in captured.out
