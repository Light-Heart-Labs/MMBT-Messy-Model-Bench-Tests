"""Tests for expression filter and edge cases."""
from __future__ import annotations

from datetime import datetime, timezone

from logalyzer.filters import expression_filter, combine_and
from logalyzer.parser import LogEntry


def make_entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


def test_expression_filter_status_check():
    pred = expression_filter("entry.status >= 500")
    assert pred(make_entry(status=500)) is True
    assert pred(make_entry(status=499)) is False


def test_expression_filter_bytes_check():
    pred = expression_filter("entry.bytes > 1024")
    assert pred(make_entry(bytes=2000)) is True
    assert pred(make_entry(bytes=100)) is False


def test_expression_filter_method_check():
    pred = expression_filter("entry.method == 'POST'")
    assert pred(make_entry(method="POST")) is True
    assert pred(make_entry(method="GET")) is False


def test_expression_filter_combined_condition():
    pred = expression_filter("entry.status >= 500 and entry.method == 'POST'")
    assert pred(make_entry(status=500, method="POST")) is True
    assert pred(make_entry(status=500, method="GET")) is False
    assert pred(make_entry(status=200, method="POST")) is False


def test_combine_and_with_no_predicates():
    pred = combine_and()
    assert pred(make_entry()) is True


def test_combine_and_with_single_predicate():
    pred = combine_and(lambda e: e.status == 200)
    assert pred(make_entry(status=200)) is True
    assert pred(make_entry(status=404)) is False


def test_combine_and_with_multiple_predicates():
    pred = combine_and(
        lambda e: e.status == 200,
        lambda e: e.method == "GET",
    )
    assert pred(make_entry(status=200, method="GET")) is True
    assert pred(make_entry(status=200, method="POST")) is False
    assert pred(make_entry(status=404, method="GET")) is False
