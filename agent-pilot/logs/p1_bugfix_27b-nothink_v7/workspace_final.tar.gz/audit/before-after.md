# Before / After Metrics

## Measurement Methodology

All "before" measurements were taken against the original starter code
at `/input/repo/`. All "after" measurements were taken against the
final code at `/workspace/`.

### Test Pass Rate
- **Command**: `python -m pytest --tb=short`
- **Before**: 11/11 tests collected, but 1 collection error (ImportError
  from `collections.Iterable`). Effectively 0/11 tests runnable.
- **After**: 66/66 tests pass.

### Coverage
- **Command**: `python -m pytest --cov=logalyzer --cov-report=term-missing`
- **Before**: 34% (190/287 statements missed)
- **After**: 93% (18/275 statements missed)

### Ruff Issues (E, F, W rules on logalyzer/)
- **Command**: `RUFF_CACHE_DIR=/tmp ruff check logalyzer/ --select E,F,W`
- **Before**: 18 issues (1 F401 unused import, 17 E501 line too long)
- **After**: 0 issues

### Benchmark (20 MB synthetic log)
- **Command**: `python benchmarks/bench.py --size 20`
- **Before**: 88.7 seconds (2,820 entries/sec, 0.23 MB/s)
- **After**: 1.2 seconds (213,227 entries/sec, 17.05 MB/s)
- **Speedup**: ~74x

### Benchmark (50 MB synthetic log)
- **Command**: `python benchmarks/bench.py --size 50`
- **Before**: >300 seconds (timed out)
- **After**: 3.3 seconds (189,727 entries/sec, 15.17 MB/s)
- **Speedup**: >90x

## Summary Table

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| Tests passable | 0/11 (collection error) | 66/66 | +66 tests |
| Test pass rate | 0% | 100% | +100% |
| Coverage | 34% | 93% | +59% |
| Ruff issues (E,F,W) | 18 | 0 | -18 |
| Benchmark 20 MB | 88.7s | 1.2s | 74x faster |
| Benchmark 50 MB | >300s | 3.3s | >90x faster |

## Notes

- The "before" test count of 0 is because the `collections.Iterable`
  import error prevented test collection entirely.
- The benchmark speedup is primarily due to fixing the O(n²) string
  concatenation in `io.load()`.
- Coverage increased by adding 49 new tests across 5 previously
  untested modules.
