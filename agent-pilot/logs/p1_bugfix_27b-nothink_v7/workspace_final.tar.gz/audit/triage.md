# Triage Report — logalyzer v0.2.0 → v0.4.0

## Methodology

Every issue was identified through code review, test execution, and
benchmarking. Each entry includes severity, category, and disposition.

Severity levels:
- **Critical**: Data loss, security vulnerability, or complete failure
- **High**: Feature broken, incorrect results, or major performance issue
- **Medium**: Minor bug, code quality issue, or documentation inaccuracy
- **Low**: Style, naming, or minor improvement

## Issue Catalog

### CRITICAL

| # | Issue | Category | Disposition | Evidence |
|---|-------|----------|-------------|----------|
| 1 | Missing "Jul" in MONTH_NAMES — July log entries silently dropped | Bug | **Fixed** | `parse_timestamp("04/Jul/2026:12:00:00 +0000")` raises `ValueError: 'Jul' is not in list` |
| 2 | `from collections import Iterable` — module fails to import on Python 3.10+ | Deprecated API | **Fixed** | `ImportError: cannot import name 'Iterable' from 'collections'` on Python 3.11 |
| 3 | `status_filter` compares string input with int status — never matches | Bug | **Fixed** | `status_filter("404")` returns False for entry with status=404 |
| 4 | `io.load()` is O(n²) — 50 MB log takes >300 seconds | Performance | **Fixed** | Benchmark: 88.7s → 1.2s on 20 MB log (74x speedup) |

### HIGH

| # | Issue | Category | Disposition | Evidence |
|---|-------|----------|-------------|----------|
| 5 | `by_hour` uses `time.localtime()` — results depend on system timezone | Bug | **Fixed** | Entry at 12:00 UTC bucketed into different hours on different machines |
| 6 | `url_regex_filter` uses `re.match` — only matches at start of URL | Bug | **Fixed** | Pattern "admin" fails to match "/api/admin/users" |
| 7 | `to_json` builds JSON by hand — invalid JSON for values with quotes | Bug | **Fixed** | URL `/search?q="test"` produces invalid JSON |
| 8 | `render_aggregate` doesn't support CSV format — raises ValueError | Bug | **Fixed** | `--aggregate status --format csv` crashes |
| 9 | `ip_allowlist_filter` uses list — O(n) lookup per entry | Performance | **Fixed** | Converted to set for O(1) lookup |

### MEDIUM

| # | Issue | Category | Disposition | Evidence |
|---|-------|----------|-------------|----------|
| 10 | `eval()` in expression_filter — potential security risk | Security | **Deferred** | Documented in decisions/decision-001-eval-expression-filter.md |
| 11 | Version mismatch: `__init__.py` says 0.2.0, `pyproject.toml` says 0.3.1 | Bug | **Fixed** | `logalyzer --version` reported wrong version |
| 12 | README claims "Real-time tail mode" — not implemented | Documentation | **Fixed** | Removed false claim from README |
| 13 | README claims "feature-complete and ready for production" — multiple bugs exist | Documentation | **Fixed** | Updated status section |
| 14 | `format_legacy()` is dead code — never called | Dead Code | **Fixed** | Removed from utils.py |
| 15 | `chunked()` is dead code — never called | Dead Code | **Fixed** | Removed from utils.py |
| 16 | `experimental.py` never imported — dead module | Dead Code | **Retained** | Useful functions, documented as experimental |

### LOW

| # | Issue | Category | Disposition | Evidence |
|---|-------|----------|-------------|----------|
| 17 | Line length violations (E501) | Style | **Fixed** | Reformatted to stay within 88 chars |
| 18 | Unused imports in test files | Style | **Fixed** | Removed unused imports |
| 19 | Missing type annotations in some functions | Style | **Deferred** | Not critical for functionality |
| 20 | No tests for cli.py, io.py, output.py, utils.py, experimental.py | Coverage | **Fixed** | Added 49 new tests, coverage 34% → 93% |

## Summary

- **Critical issues fixed**: 4
- **High issues fixed**: 5
- **Medium issues fixed**: 5, deferred: 1
- **Low issues fixed**: 3, deferred: 1
- **Total issues found**: 20
- **Issues fixed**: 17
- **Issues deferred**: 2 (with documented rationale)
- **Issues wontfix**: 1 (experimental module retained by design)
