# Changelog

## [0.4.0] — 2026-05-02

### Fixed

- **Critical**: Added missing "Jul" to month names list. July log entries
  were silently dropped because `parse_timestamp()` raised `ValueError`
  for July dates.
- **Critical**: Fixed `from collections import Iterable` import that
  prevented the module from loading on Python 3.10+. Replaced with
  `collections.abc.Iterable` (though the import was unused and removed).
- **Critical**: Fixed `status_filter` to convert string input to int.
  The CLI passes `--status` as a string (e.g., "404"), but
  `entry.status` is always an int. Without conversion, the filter
  never matched anything.
- **Critical**: Fixed O(n²) performance in `io.load()`. The original
  implementation used character-by-character string concatenation and
  list concatenation, both O(n) per iteration. Now uses line-by-line
  reading with `list.append()`, bringing complexity to O(n). Benchmark
  shows ~74x speedup on a 20 MB log.
- Fixed `by_hour` to use UTC hour directly instead of `time.localtime()`.
  The original code depended on the system timezone, producing different
  results on different machines.
- Fixed `url_regex_filter` to use `re.search` instead of `re.match`.
  The original only matched patterns at the start of the URL, so a
  pattern like "admin" would fail to match "/api/admin/users".
- Fixed `to_json` to use `json.dumps()` instead of manual string
  building. The original produced invalid JSON when values contained
  quotes or special characters.
- Added CSV format support to `render_aggregate()`. The CLI accepted
  `--format csv` for aggregate output but the function raised ValueError.
- Converted `ip_allowlist_filter` to use a set for O(1) lookup instead
  of O(n) linear search.

### Changed

- Bumped version from 0.3.1 to 0.4.0 to reflect critical bug fixes.
- Synced `__version__` in `__init__.py` with `pyproject.toml`.
- Removed dead code: `format_legacy()` and `chunked()` from `utils.py`.
- Marked `experimental.py` as experimental with clear `__all__` exports.
- Reformatted code to stay within 88-character line limit.

### Added

- 49 new tests across 5 previously untested modules (cli, io, output,
  utils, experimental). Test coverage increased from 34% to 93%.
- Comprehensive test suite for CLI argument parsing, file I/O, output
  formatters, utility functions, and experimental features.

### Removed

- `format_legacy()` from `utils.py` — unused legacy formatter.
- `chunked()` from `utils.py` — unused generic utility.

### Documentation

- Removed false "Real-time tail mode" claim from README.
- Updated README status section to reflect actual state.
- Added triage report, before/after metrics, and architecture decisions.
