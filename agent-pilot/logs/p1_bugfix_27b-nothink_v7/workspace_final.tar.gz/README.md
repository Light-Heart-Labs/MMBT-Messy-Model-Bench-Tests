# logalyzer

A small CLI tool for analyzing web server access logs. Parses Apache/NGINX-style
log files, lets you filter by various criteria, and produces aggregate reports.

## Features

- Parse Common Log Format (CLF) and Combined Log Format
- Filter by status code, IP, URL pattern, and date range
- Aggregate output: counts by URL, status, hour-of-day
- Output as JSON, CSV, or plain text
- Custom expression filtering for advanced queries (`--expr`)
- Experimental: anomaly detection and session windowing (see `logalyzer.experimental`)

## Install

```bash
pip install -e .
```

## Quick start

```bash
# Show all 5xx errors in the sample log
logalyzer --status 500 samples/access.log

# Top 10 URLs by hit count
logalyzer --aggregate url --top 10 samples/access.log

# Filter by IP and date range
logalyzer --ip 10.0.0.1 --since 2026-01-01 samples/access.log

# Output as JSON
logalyzer --format json samples/access.log

# Custom expression filter
logalyzer --expr "entry.status >= 500 and entry.method == 'POST'" samples/access.log
```

## Run tests

```bash
pytest
```

## Run benchmark

```bash
python benchmarks/bench.py
```

## What was wrong, what got fixed

This project was adopted in a state with multiple critical bugs and
accumulated technical debt. See the full triage report in
[`audit/triage.md`](audit/triage.md) and the before/after metrics in
[`audit/before-after.md`](audit/before-after.md).

### Key fixes in v0.4.0

- **July dates were silently dropped** — The month names list was missing
  "Jul", causing all July log entries to fail parsing.
- **Status filter never matched** — The CLI passes `--status` as a string,
  but the filter compared it directly with the int status code.
- **74x performance regression** — `io.load()` used O(n²) string
  concatenation. Fixed to O(n) with line-by-line reading.
- **Timezone-dependent hour bucketing** — `by_hour` used `time.localtime()`
  which depends on the system timezone. Now uses UTC directly.
- **Broken JSON output** — Manual JSON building produced invalid output
  for values with quotes. Now uses `json.dumps()`.
- **Import error on Python 3.10+** — `from collections import Iterable`
  was removed in Python 3.10. Fixed.
- **Test coverage from 34% to 93%** — Added 49 new tests across 5
  previously untested modules.

### Architecture decisions

See [`architecture/`](architecture/) for ADRs on structural choices,
and [`decisions/`](decisions/) for individual technical decisions.

## Status

Stable. v0.4.0 fixes all critical bugs from the 0.3.x line.
