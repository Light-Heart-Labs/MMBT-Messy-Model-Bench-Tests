# ADR-001: Handling of dead code and experimental module

## Status

Accepted

## Context

The codebase contains several pieces of dead code:

1. **`logalyzer/experimental.py`** — Contains `detect_anomalies()` and
   `session_window()` functions. Never imported anywhere in the codebase.
   The module docstring says "Keep this file untouched for now — it's
   part of an in-progress feature."

2. **`logalyzer/utils.format_legacy()`** — A legacy formatter "retained
   for compatibility with the v0.1 CLI output." No external scripts are
   known to depend on it, and it's not imported anywhere.

3. **`logalyzer/utils.chunked()`** — A generic utility to yield chunks
   from a sequence. Not used anywhere in the codebase.

## Decision

- **`experimental.py`**: Retain but mark as experimental with a clear
  deprecation notice. The functions are useful (anomaly detection and
  session windowing) and may be wired into the CLI in a future release.
  Adding a `__all__` export list to make the public API explicit.

- **`format_legacy()`**: Remove. It's not used anywhere, the v0.1 CLI
  is long gone, and keeping dead code increases maintenance burden.

- **`chunked()`**: Remove. It's a generic utility not specific to log
  analysis, and Python's `itertools` or list slicing can replace it if
  needed.

## Consequences

- The experimental module remains available for import but is not part
  of the CLI. Future work can wire it in.
- `format_legacy` and `chunked` are removed from `utils.py`.
- Test coverage for `utils.py` will need to be added for the remaining
  functions (`parse_iso_date`, `format_bytes`).
