# ADR-002: Streaming architecture for log processing

## Status

Accepted

## Context

The original `io.load()` function read the entire file into memory as a
single string, then iterated character by character. This had two problems:
1. O(n²) time complexity due to string concatenation
2. O(n) memory overhead from holding the entire file content

The CLI already used `io.load_iter()` which streams line by line, but the
benchmark tested `io.load()` which was the slow path.

## Decision

- `io.load()` is now O(n) using line-by-line reading with `list.append()`
- `io.load_iter()` remains as the streaming generator for large files
- The CLI uses `io.load_iter()` for memory efficiency
- The benchmark tests `io.load()` to validate the performance fix

## Consequences

- Both `load()` and `load_iter()` now have the same O(n) complexity
- `load()` still loads all entries into memory (useful for small files)
- `load_iter()` streams entries (useful for very large files)
- The benchmark shows a ~74x speedup on a 20 MB log
