# CEO Brief — API Incident, Friday

**What happened:** A configuration change to our authentication service caused our primary API to return errors for approximately 4 hours (14:11–18:24 UTC Friday), impacting roughly 11,400 customer accounts.

**Impact:** About 28 enterprise accounts experienced revenue impact during business hours. At least 4 customers had downstream automation break, requiring manual cleanup. We received 217 support tickets and 31 refund requests.

**Board signal:** This is the second 4+ hour incident in 90 days (the first was a database storage issue in February). A third would require a full reliability program review.

**Remediations in progress:**
1. Staged config rollout — adding canary deployment for configuration changes so future changes roll out per-region rather than globally at once.
2. Status-page monitoring fix — already deployed; checks now validate the same endpoints customers use.
3. Faster incident comms — on-call commander will issue an initial "we see it, we're working it" message within 15 minutes of confirmed impact, regardless of root-cause status.
4. Internal system fix — updating the authentication service so its internal thresholds respond correctly to configuration changes instead of relying on fixed values.

**Customer obligations:** SLA credits are owed to affected accounts per our 99.9% monthly uptime commitment. Legal and finance are processing 31 refund requests case by case. We are offering hands-on data-cleanup support to the 4 customers whose downstream automation broke.

**Recommendation:** Flag this trend in board prep without escalation. The remediation plan is concrete and underway.
