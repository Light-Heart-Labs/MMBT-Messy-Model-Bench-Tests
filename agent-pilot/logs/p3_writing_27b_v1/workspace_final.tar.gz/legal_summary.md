# Legal Summary — Incident of [Friday Date], 2026

## 1. Incident Window

The incident occurred from 14:11 UTC to 18:24 UTC on Friday, 2026. Service was fully restored at 18:24 UTC following a configuration revert at 18:18 UTC.

## 2. Scope of Impact

Approximately 11,400 customer accounts were impacted. Of these:
- Approximately 28 enterprise accounts (those with named Customer Success Managers) experienced revenue impact during business hours.
- At least 4 accounts experienced downstream automation failure requiring manual data cleanup.
- 217 inbound support tickets were received.
- 31 refund requests have been submitted to date (a subset request SLA-credit-only; others request full-month credit).

## 3. SLA Threshold and Breach Determination

The contractual SLA sold to customers specifies 99.9% monthly uptime, with service credits for breach. The approximately 4-hour, 13-minute incident window constitutes a nominal breach of the 99.9% monthly uptime threshold for the affected accounts. The SLA was breached for the impacted accounts.

## 4. Known Downstream Harm

Four customer accounts are confirmed to have experienced downstream automation failure as a direct result of the incident. These accounts required manual data cleanup. The source memo recommends hands-on data-cleanup support engagements for these four accounts, in addition to standard SLA credits.

## 5. Recommendation on Credit-Request Handling

- **SLA-driven requests:** For accounts where the SLA was clearly breached (the ~11,400 impacted accounts), credit requests should be honored per the contractual terms of the MSA. These should not be contested.
- **Relationship-driven requests:** For accounts that were not demonstrably impacted but are requesting credits on non-contractual grounds, these are relationship matters, not contractual obligations. Finance and Customer Success should handle these on a case-by-case basis.
- **Full-month credit requests:** Of the 31 refund requests, some seek full-month credit rather than SLA-credit-only. Legal and finance are working through these individually.

## 6. Prior Incident

A separate 4+ hour incident occurred in February 2026 involving a database storage issue. This is the second such incident in 2026.
