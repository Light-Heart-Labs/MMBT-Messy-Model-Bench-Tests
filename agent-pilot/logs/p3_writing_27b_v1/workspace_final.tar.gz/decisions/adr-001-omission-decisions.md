# ADR-001: Omission Decisions by Audience

## CEO Brief

### Omitted: Named individuals (Marcus, Priya, Sarah)
**Rationale:** The brief spec explicitly prohibits internal nicknames and informal apologies. Named engineers are irrelevant to board-level decision-making and could create liability exposure if the brief leaks.

### Omitted: Detailed root-cause mechanics (rate limiter, hard-coded MAX, fraction computation)
**Rationale:** The spec prohibits engineering-jargon without translation. The CEO needs to know "a configuration change caused the problem" — not the internal limiter mechanics. Translated to "configuration change to our authentication service."

### Omitted: Runbook gap discussion
**Rationale:** This is a process detail of lower materiality compared to the four remediations selected (staged rollout, status-page fix, faster comms, internal system fix). The runbook gap is a minor improvement, not a material remediation.

### Omitted: Specific refund dollar amounts
**Rationale:** No dollar amounts are provided in the source memo. 31 refund requests are mentioned but no monetary values. Cannot invent figures.

### Included: "Second occurrence in 90 days" framing
**Rationale:** Explicitly required by the spec as a board signal. The source memo states this is the second 4+ hour outage in 2026 (February and this Friday).

---

## Customer Email

### Omitted: Named engineer (Marcus)
**Rationale:** Explicitly prohibited by spec. Blaming a named individual in a mass customer email would be inappropriate and potentially create legal exposure.

### Omitted: "Second outage in 90 days" framing
**Rationale:** Explicitly prohibited by spec. This is an internal board signal, not customer-facing information. Including it would undermine customer confidence.

### Omitted: Engineering jargon (rate limiter, MAX, throttling, 502)
**Rationale:** Explicitly prohibited by spec. Translated to "configuration change... caused our internal systems to reject authentication requests."

### Omitted: Internal candor about unaddressed warnings (Sarah's June warning)
**Rationale:** Explicitly prohibited by spec. Revealing that a known issue was not addressed for months would damage trust.

### Omitted: Status page being green during outage
**Rationale:** While we mention fixing status-page monitoring, we don't highlight that it was wrong during the incident. This would undermine confidence without adding value to the customer.

### Included: Explicit SLA credit offer
**Rationale:** Required by spec. Customers need to know their rights and how to exercise them.

---

## Legal Summary

### Omitted: Engineering remediation details
**Rationale:** Explicitly prohibited by spec. Remediation details are irrelevant to SLA-credit determinations.

### Omitted: Named employees (Marcus, Priya, Sarah)
**Rationale:** Explicitly prohibited by spec. Named-employee blame is not relevant to contractual analysis.

### Omitted: Speculation about future outages or "third would put us there"
**Rationale:** Explicitly prohibited by spec. Speculation is not appropriate for legal counsel.

### Omitted: Marketing language and apologies
**Rationale:** Explicitly prohibited by spec. Legal counsel needs facts, not sentiment.

### Used: "Incident" instead of "outage"
**Rationale:** Spec requires using "incident" not "outage." This is a deliberate terminological choice for legal precision.

### Included: Prior February 2026 incident
**Rationale:** Relevant for counsel to understand the pattern and potential cumulative SLA implications. The source memo explicitly references this.
