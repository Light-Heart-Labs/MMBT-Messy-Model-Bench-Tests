# Customer Email — API Service Disruption on Friday

**Subject: What happened on Friday and what we're doing about it**

Dear customer,

On Friday between 14:11 and 18:24 UTC, our primary API returned errors for a significant portion of requests across all customer accounts. We know this disrupted your workflows, and we take full responsibility.

**What happened:** A configuration change to our authentication service was deployed at 14:09 UTC. The change was intended to increase capacity, but it inadvertently caused our internal systems to reject authentication requests. When authentication fails, the API cannot serve requests, which is why you saw errors. We identified the issue, reverted the change at 18:18 UTC, and full service was restored by 18:24 UTC.

**What we're doing differently:**
- We are adding staged rollout for configuration changes so future updates are tested on a small subset of systems before going live globally.
- We have already fixed our status-page monitoring so it accurately reflects the endpoints you use.
- We are implementing a policy to issue an initial acknowledgment within 15 minutes of any confirmed service impact, even before we have a full diagnosis.

**SLA credit:** If your account was affected, you are eligible for service credits under our SLA. To request a credit, please contact your Customer Success Manager or reach out to our support team at support@[company].com. We will process eligible requests promptly.

For the four customers whose downstream automation was directly impacted, we are offering hands-on data-cleanup support at no charge, in addition to your SLA credit.

We understand that trust is earned through reliability, and we fell short this time. We are committed to doing better.

Sincerely,

The Engineering Team
