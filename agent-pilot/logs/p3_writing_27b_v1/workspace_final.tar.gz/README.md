# Incident Rewrite Output

This directory contains three audience-tailored rewrites of an internal engineering memo documenting a ~4-hour API incident on Friday, 2026. Each rewrite is constrained by the specifications in `/input/repo/audience_briefs.json` and draws exclusively from facts present in the source memo at `/input/repo/draft_memo.md`.

## Files

| File | Audience | Word Count | Limit |
|------|----------|------------|-------|
| `ceo_brief.md` | CEO / Board prep | 242 | ≤250 |
| `customer_email.md` | Affected customers (mass email) | 279 | ≤350 |
| `legal_summary.md` | In-house counsel | 329 | ≤400 |
| `decisions/adr-001-omission-decisions.md` | ADR records for non-obvious inclusion/omission choices | — | — |
| `research/notes.md` | Working notes with extracted facts and audience decisions | — | — |

## How to Read

Each rewrite follows the tone, content requirements, and prohibitions specified for its audience. The CEO brief is concise and executive, highlighting board-relevant signals. The customer email is warm and accountable, with an explicit SLA-credit offer and no engineering jargon or internal framing. The legal summary is dispassionate and factual, using "incident" terminology and focusing on contractual obligations. All numbers, times, and counts are sourced directly from the original memo — no facts were invented.
