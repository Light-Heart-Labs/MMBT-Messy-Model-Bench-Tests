# Working Notes — Incident Rewrite Project

## Source Facts Extracted

| Fact | Value |
|------|-------|
| Incident window | 14:11 UTC – 18:24 UTC, Friday |
| Duration | ~4 hours, 13 minutes |
| Symptom | Primary API returning 502s for 60%–100% of inbound requests |
| Accounts impacted | ~11,400 |
| Enterprise accounts with revenue impact | ~28 (those with named CSMs) |
| Known downstream automation breakage | At least 4 cases |
| Support tickets | 217 |
| Refund requests | 31 (mix of SLA-credit-only and full-month credit) |
| SLA term | 99.9% monthly uptime, credits for breach |
| Prior outage | February 2026, database storage issue (second 4+ hour outage in 2026) |
| Status page issue | Green for first ~40 minutes; check pointed at wrong endpoint |
| Root cause | Config change at 14:09 UTC doubled rate-limit thresholds; internal limiter computed fraction against hard-coded MAX, not new config |
| Revert time | 18:18 UTC; full recovery by 18:24 UTC |
| First proactive comms | 47 minutes after outage was known |

## Remediations Identified
1. Add canary/staged rollout for config changes (est. 1 sprint)
2. Fix internal limiter to compute fraction against actual global config, not hard-coded constant (est. 2 weeks)
3. Status-page check fix (completed Friday evening)
4. 15-minute initial comms policy for on-call commander
5. Runbook update for 502s with green LB → check auth service metrics

## Audience-Specific Decisions

### CEO Brief
- Include "second occurrence in 90 days" framing as required
- Omit all engineering details; translate root cause to "configuration change"
- Omit named individuals (Marcus, Priya, Sarah)
- Omit "sorry Sarah" and similar informal language
- Keep remediations to 3-4 most material items

### Customer Email
- NO mention of Marcus or any named engineer
- NO "second outage in 90 days" framing
- NO engineering jargon (rate limiter, MAX, throttling)
- Must explicitly offer SLA credit
- Must include contact path
- Warm, accountable tone

### Legal Summary
- Use "incident" not "outage"
- NO named employees
- NO speculation about future outages
- NO marketing language
- NO engineering remediation details
- Precise, dispassionate tone
- Include SLA threshold and breach determination
- Include recommendation on credit handling
