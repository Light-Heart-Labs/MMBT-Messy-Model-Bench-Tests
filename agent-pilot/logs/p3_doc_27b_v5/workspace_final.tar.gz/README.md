# Nimbus Logistics — Follow-On Investment Brief

## How to Read This Output

### Primary Deliverable
- **`brief.md`** — The 1-page executive brief. This is the main deliverable for the investment committee. It is at most 700 words and leads with a clear recommendation.

### Supporting Materials
- **`key-facts.md`** — A complete list of every material fact incorporated into the brief, with source attribution. Use this to verify that no numbers were invented and all claims trace to the five source documents.
- **`research/notes.md`** — Working notes from reading the five sources. Includes source-by-source summaries, key tensions identified, and credibility assessments.
- **`research/dead-ends.md`** — Ideas that were considered during analysis but abandoned, with explanations for why.
- **`decisions/adr-001-recommendation-stance.md`** — ADR-style records documenting non-obvious framing choices: the recommendation stance, source weighting methodology, treatment of the ARR discrepancy, and handling of the credit facility.

### Source Documents
The five source documents are located at `/input/repo/sources.md`:
1. **Source 1** — Company press release (2026-01-14)
2. **Source 2** — TechCrunch news article (2026-01-15)
3. **Source 3** — Former employee blog post (2026-02-22)
4. **Source 4** — Leaked internal memo via The Information (2026-03-05)
5. **Source 5** — SEC Form D filing summary (2026-01-22)

### Citation Convention
All facts in the brief are cited inline using `[Source N]` format, where N corresponds to the source number above. No facts were invented or sourced from outside the provided documents.
