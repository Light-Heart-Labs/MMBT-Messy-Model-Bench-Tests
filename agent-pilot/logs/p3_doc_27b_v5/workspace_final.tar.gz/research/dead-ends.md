# Dead Ends — Ideas Considered and Abandoned

## 1. Including a detailed financial model

**Considered:** Building a projected P&L through Q4 2026 based on the burn rate, restructuring, and breakeven target.

**Abandoned because:** The data is insufficient. We have one data point for burn (~$4M/month, mid-2025) and one for revenue (~$3.5M/month, mid-2025), both from a single source (the former employee blog). The restructuring's impact on burn is stated as a goal, not a projection with supporting numbers. Any model would be speculative.

## 2. Recommending "conditional invest" with specific terms

**Considered:** Suggesting a follow-on at a lower valuation (e.g., $400M) with protective provisions.

**Abandoned because:** We have no basis for negotiating terms. The brief is an evaluation, not a term sheet. The "pass" recommendation is cleaner and more actionable — the investor can revisit at Series C.

## 3. Deep dive on the FedEx Ventures strategic investment

**Considered:** Analyzing what FedEx Ventures' participation means for distribution and channel strategy.

**Abandoned because:** The sources provide no detail on the size or terms of FedEx Ventures' investment. Speculating about strategic implications would go beyond the available evidence.

## 4. Including the former employee's compensation data

**Considered:** Using the $215K base + $50K equity/year as evidence of competitive compensation and company health.

**Abandoned because:** While interesting, it doesn't materially affect the investment decision. It was mentioned in passing in the positive signals section but not given its own analysis.

## 5. Analyzing the 3 unnamed investors from the Form D

**Considered:** Trying to identify the 3 additional investors beyond the 4 named in the press release.

**Abandoned because:** The Form D summary explicitly states their names are not disclosed. There is no information available to identify them.

## 6. Including a competitive landscape analysis

**Considered:** Positioning Nimbus against other logistics-tech platforms.

**Abandoned because:** No competitive data is available in the sources. The only competitive signal is Klatch migrating to "a competing platform" (unnamed).
