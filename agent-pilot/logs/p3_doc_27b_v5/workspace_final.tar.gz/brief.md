# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Assessment

**Date:** 2026-03-15 | **Subject:** Series-B follow-on evaluation

---

## Recommendation: PASS at current valuation; monitor for Series C

Nimbus Logistics raised $84M in a Series B at a $560M post-money valuation [Source 1], with backing from Lightning Capital, Sequoia, Accel, and FedEx Ventures [Source 1, Source 5]. The company reports $42M ARR and 1,400+ customers [Source 1].

**But the operational picture is more fragile than the press release suggests.** The round was repriced down from $720M after the company's largest customer departed [Source 2]. Burn exceeds revenue, customer concentration is high, and the company is executing a significant restructuring including international retreat and product-tier elimination.

A follow-on at current valuation is not advisable. The company has 36+ months of runway and a stated path to breakeven by Q4 2026 [Source 4], creating a natural inflection point. If that path materializes, a Series C from a position of operating leverage would be a more attractive entry. If it does not, the current valuation is unjustified.

---

## Revenue and Churn

The company reports $42M ARR as of Q4 2025 [Source 1]. However, two top-five customers departed in late 2025: Sundry Brands ($4.2M ARR, the largest contract) did not renew in November, and Klatch exited in December [Source 2]. Adjusted for churn, current run-rate ARR is closer to $36–37M [Source 2]. The $42M figure includes both contracts in their final quarter [Source 2].

Customer concentration is a structural risk: the top five customers represent ~38% of ARR [Source 3]. The Sundry loss alone is roughly 10% of reported ARR and was not a surprise internally [Source 3], suggesting the churn risk was known but not disclosed.

## Unit Economics and Burn

A former senior engineer reports burn of ~$4M/month all-in against ~$3.5M/month in revenue (mid-2025) [Source 3], implying net burn of ~$500K/month. The company quietly laid off 22 people (~11% of the org) in February 2025, mostly in customer success and BD, without public announcement [Source 3].

An internal restructuring memo (dated Feb 28, 2026) confirms aggressive cost actions: 30% Berlin headcount reduction (41 → 28–30), international expansion deferred to 2027, and elimination of the "Nimbus Lite" tier affecting ~310 small customers [Source 4]. These moves signal the current growth model is not sustainable at current burn.

## Capital Position

Total funding is $128M [Source 1]. The company also secured a $50M credit facility from Silicon Valley Bridge, described internally as "insurance, not operating capital" [Source 4]. At current burn, runway is 24+ months; post-restructuring, management projects 36+ months [Source 4]. The goal is operating-cash-flow breakeven by Q4 2026, the trigger for Series C conversations [Source 4].

## Valuation Concerns

The $560M valuation is roughly 15x adjusted ARR ($36–37M) [Source 2]. More telling, the round was originally targeted at $720M but repriced downward after the Sundry non-renewal became known to the lead investor in early December [Source 2]. This signals that sophisticated capital already downgraded its view.

## Positive Signals

The engineering architecture is praised by a former senior engineer, and CTO Daniel Wong is described as "the real deal" [Source 3]. Mid-market customer relationships appear genuine [Source 3]. The CEO signed three new $1M+ ARR contracts in Q1 2026 [Source 2], and FedEx Ventures' strategic participation [Source 1] suggests distribution-channel credibility.

---

## Source Quality Notes

- **Press release [Source 1]:** Company narrative. Confirmed by SEC Form D on deal mechanics [Source 5], but selectively optimistic.
- **TechCrunch [Source 2]:** Two sources familiar with finances. Company confirmed Sundry loss but spun it.
- **Former employee blog [Source 3]:** Single-source perspective. Numbers are plausible but uncorroborated.
- **Leaked memo [Source 4]:** Internal document obtained by journalist. High credibility for strategic intent; company declined to confirm specifics.
- **SEC Form D [Source 5]:** Regulatory filing. High credibility for deal structure.

---

## What Would Change This Recommendation

- Evidence that Q1 new bookings ($3M+ in new contracts) are durable and growing.
- Confirmation that restructuring achieves projected burn reduction.
- A down-round at a significantly lower valuation creating a more attractive entry point.

---

## Bottom Line

Nimbus has credible founders, strong technology, and adequate runway. But the company is executing a significant pivot — retreating from international expansion, cutting its smallest customers, and restructuring to survive — while carrying a valuation that does not reflect known churn and concentration risks. The repricing from $720M to $560M tells us the lead investor already adjusted its thesis.

**Recommendation: Pass on follow-on at current valuation. Set a watch for Q4 2026 breakeven milestone and evaluate Series C from a position of operating leverage.**
