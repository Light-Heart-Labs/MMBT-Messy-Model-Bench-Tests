# ADR-001: Recommendation Stance — Pass vs. More Diligence

## Decision

**Recommendation: PASS at current valuation; monitor for Series C.**

## Context

The brief needed a clear stance. Three options were considered:

1. **Invest** — The company has strong backers, credible technology, and 36+ months of runway.
2. **More diligence needed** — The data is incomplete; we need customer references, audited financials, etc.
3. **Pass** — The known risks (churn, concentration, burn, repricing) are sufficient to decline at current valuation.

## Rationale

"More diligence needed" was rejected because it hedges. The known facts already paint a clear picture: the company is restructuring, burning more than it earns, and was repriced down by its own lead investor. These are not unknowns that diligence would resolve — they are known risks that the current valuation does not reflect.

"Pass" was chosen over "invest" because:
- The $560M valuation is ~15x adjusted ARR ($36–37M), which is premium for a company with negative unit economics.
- The repricing from $720M to $560M signals that the lead investor already downgraded its thesis.
- The company has 36+ months of runway, so there is no urgency to act now.
- The Q4 2026 breakeven target creates a natural inflection point for re-evaluation.

## Caveats

This recommendation would change if:
- Q1 new bookings prove durable and growing (offsetting churn).
- A down-round at a significantly lower valuation creates a more attractive entry point.
- The restructuring achieves projected burn reduction, validating the path to breakeven.

---

# ADR-002: Source Weighting — How to Treat Contradictory Signals

## Decision

Sources were weighted by credibility and corroboration:

| Source | Weight | Rationale |
|--------|--------|-----------|
| SEC Form D | High | Regulatory filing; deal mechanics confirmed |
| Leaked memo | High | Internal document; strategic intent is credible |
| TechCrunch | Medium-High | Two sources; company confirmed Sundry loss |
| Former employee blog | Medium | Single source; specific numbers plausible but uncorroborated |
| Press release | Medium | Company narrative; selectively optimistic |

## Rationale

The press release was not ignored but was treated as the company's preferred narrative. Facts from the press release that were corroborated by other sources (e.g., deal size, investor names) were treated as confirmed. Facts that were contradicted (e.g., ARR figure) were presented with the contradiction.

The leaked memo was given high weight for strategic intent (restructuring, breakeven target) because it is an internal document from the CEO. However, the company's refusal to confirm specifics was noted.

The former employee blog was given medium weight. The burn rate, layoff count, and customer concentration figures are specific and plausible, but they come from a single source with potential bias (departing employee). They were used to flag risks rather than as definitive facts.

---

# ADR-003: Framing the ARR Discrepancy

## Decision

Present both the reported ARR ($42M) and the adjusted run-rate ($36–37M), with clear attribution.

## Rationale

The $42M figure is the company's official number and is not "wrong" — it includes contracts that were active in Q4 2025. However, presenting it without context is misleading because two of those contracts have since departed. The adjusted figure from TechCrunch sources provides a more accurate picture of current revenue.

The brief presents both numbers with clear source attribution, allowing the reader to understand the discrepancy without dismissing either figure.

---

# ADR-004: Treatment of the $50M Credit Facility

## Decision

Include the credit facility as a positive signal (additional runway) but note the "insurance, not operating capital" characterization.

## Rationale

The $50M credit facility from Silicon Valley Bridge is a material fact that affects runway calculations. However, the internal memo's characterization of it as "insurance" suggests it is not expected to be drawn down under normal operations. This was noted to avoid overstating its impact on the company's financial position.
