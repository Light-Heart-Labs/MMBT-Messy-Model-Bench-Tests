# Key Facts Incorporated into Brief

Each fact below traces to one or more of the five source documents.

## Deal Mechanics
- $84M Series B at $560M post-money valuation — [Source 1, Source 5]
- Total funding across all rounds: $128M — [Source 1]
- Lead investor: Lightning Capital — [Source 1, Source 5]
- Participating investors: Sequoia Capital, Accel, FedEx Ventures (strategic), plus 3 unnamed — [Source 1, Source 5]
- 7 total investors — [Source 5]
- Security type: Series B Preferred Equity — [Source 5]
- Filing date: 2026-01-22; first sale: 2026-01-14 — [Source 5]
- Use of proceeds: "expansion, working capital, general corporate purposes" — [Source 5]

## Revenue and Customers
- Reported ARR: $42M as of Q4 2025 — [Source 1]
- ARR a year prior: $11M — [Source 1]
- Customer count: 1,400+ e-commerce brands — [Source 1]
- Named customers: Maevia, Truant Coffee, Brick & Cobble — [Source 1]
- Adjusted run-rate ARR (post-churn): $36–37M — [Source 2]
- $42M figure includes departed contracts in their final quarter — [Source 2]

## Churn and Concentration
- Sundry Brands (largest contract, $4.2M ARR) did not renew in November 2025 — [Source 2]
- Klatch (fast-fashion brand) exited in December 2025, migrated to competitor — [Source 2]
- Company confirmed Sundry loss as "strategic mutual decision" — [Source 2]
- Top 5 customers represent ~38% of ARR — [Source 3]
- Sundry loss was not a surprise internally — [Source 3]
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 — [Source 2]
- CEO claims net retention above 110% — [Source 2]

## Valuation
- Previous Series A valuation: $230M (2023) — [Source 1]
- Initial Series B target: $720M — [Source 2]
- Final Series B valuation: $560M (repriced down) — [Source 1, Source 2]
- Repricing occurred after Sundry non-renewal became known to lead investor in early December — [Source 2]

## Burn and Unit Economics
- Monthly burn: ~$4M all-in (mid-2025) — [Source 3]
- Monthly revenue: ~$3.5M (mid-2025) — [Source 3]
- Net burn: ~$500K/month — [Source 3]
- 22 layoffs (~11% of org) in February 2025, mostly customer success and BD — [Source 3]
- Layoffs were not publicly announced — [Source 3]

## Restructuring (Internal Memo)
- 30% reduction in Berlin headcount: 41 → 28–30 by end Q2 — [Source 4]
- International expansion deferred to 2027 — [Source 4]
- Berlin reframed as "support hub" — [Source 4]
- Nimbus Lite tier sunset: ~310 customers ($5K–$20K ARR each), 90-day notice — [Source 4]
- $50M credit facility from Silicon Valley Bridge — [Source 4]
- Runway: 24+ months at current burn, 36+ months post-restructuring — [Source 4]
- Target: operating-cash-flow breakeven by Q4 2026 — [Source 4]
- Breakeven is trigger for Series C conversations — [Source 4]
- Company declined to confirm memo specifics — [Source 4]

## Company Profile
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) — [Source 1]
- 187 employees across Oakland, Austin, Berlin — [Source 1]
- Platform: warehouse management + carrier orchestration + demand forecasting — [Source 1]
- Engineering praised as "cleanest distributed-systems code" by former senior engineer — [Source 3]
- CTO Daniel Wong described as "the real deal" — [Source 3]
- Former engineer compensation: $215K base + $50K equity/year — [Source 3]

## No Executive Compensation Disclosed
- $0 officer/director compensation in connection with offering — [Source 5]
