# Diagnosis Report

## CI Failure Summary

The CI is failing with 4 issues:
1. Ruff linting error (F401): unused import `json` in `cart.py`
2. Test failure: `test_discount_amount` - wrong calculation
3. Test failure: `test_apply_discount` - wrong calculation
4. Test failure: `test_line_count_matches_qty_sum` - test expectation mismatch

## Root Cause Analysis

### Issue 1: Unused import (Ruff F401)
**Location**: `src/discountkit/cart.py:4`
**Problem**: The `json` module is imported but never used.
**Fix**: Remove the unused import.

### Issue 2 & 3: Discount calculation errors
**Location**: `src/discountkit/discount.py`
**Problem**: The `discount_amount()` function is calculating `price * percent_off` which gives `100 * 20 = 2000` instead of `100 * 20 / 100 = 20`.

The CHANGELOG v0.3.0 states that the API changed from fractions (0.0-1.0) to percents (0-100), but the implementation wasn't updated to divide by 100.

**Fix**: Change `price * percent_off` to `price * percent_off / 100` in `discount_amount()`.

### Issue 4: line_count() test failure
**Location**: `tests/test_cart.py::test_line_count_matches_qty_sum`
**Problem**: The test expects `line_count()` to return the total quantity (5), but according to CHANGELOG v0.3.0, `line_count()` was changed to return the number of lines (2).

The CHANGELOG says: "Cart.line_count() now returns the number of lines, not the total quantity across lines."

**Fix**: Update the test to expect the correct behavior (2 lines, not 5 total quantity).

## Decision Log

### Decision 1: Fix code vs fix test for discount calculations
**Choice**: Fix the code
**Reason**: The test expectations are correct (20% of $100 = $20), and the CHANGELOG confirms the API should accept percents. The implementation is wrong, not the tests.

### Decision 2: Fix code vs fix test for line_count()
**Choice**: Fix the test
**Reason**: The CHANGELOG v0.3.0 explicitly states that `line_count()` was changed to return the number of lines, not total quantity. This is a documented breaking change, so the test needs to be updated to match the new behavior.
