# Decision 1: line_count() Test Update

## Context

The `Cart.line_count()` method was changed in v0.3.0 to return the number of lines instead of the total quantity across lines. The CHANGELOG documented this as a breaking change.

However, the test `test_line_count_matches_qty_sum` was still expecting the old behavior (total quantity = 5).

## Decision

We chose to **update the test** rather than revert the method's behavior.

## Rationale

1. **Documented breaking change**: The CHANGELOG v0.3.0 explicitly states this was an intentional API change.
2. **Test was wrong**: The test was testing the old behavior (v0.2.0), not the current API (v0.3.0).
3. **Method name clarity**: `line_count()` is more semantically correct for "number of lines" than "total quantity".
4. **No API surface change needed**: We're not changing what the method returns, just fixing the test to match the documented behavior.

## Alternative Considered

Revert the method to return total quantity and update the CHANGELOG to document this as a bug fix.

**Rejected because**: This would undo a documented breaking change without a valid reason, and the method name `line_count()` is clearer for counting lines.

## Status

Accepted and implemented.
