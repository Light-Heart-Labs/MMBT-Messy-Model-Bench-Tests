# Diagnosis

## CI Failure Analysis

The CI log showed 1 ruff error and 3 test failures.

### Issue 1: Ruff F401 — unused `json` import in `cart.py`

**What was wrong:** `import json` was present in `src/discountkit/cart.py` but never used.

**Fix:** Removed the import line.

**Why:** Straightforward lint fix — the import served no purpose.

---

### Issue 2: `discount_amount()` returns wrong values

**What was wrong:** `discount_amount(100.0, 20.0)` returned `2000.0` instead of `20.0`. The function computes `price * percent_off` but since v0.3.0 the parameter is a percent (0–100), not a fraction (0.0–1.0). The implementation was never updated to match the new API.

**Fix:** Changed `return round(price * percent_off, 2)` to `return round(price * percent_off / 100, 2)`.

**Why:** The docstring examples (`discount_amount(100.0, 20.0) -> 20.0`) and the v0.3.0 changelog both confirm the function should take percent. The tests were correct; the code was wrong.

---

### Issue 3: `test_line_count_matches_qty_sum` fails

**What was wrong:** The test expected `line_count()` to return the total quantity across all lines (5), but the code returns the number of lines (2).

**Fix:** Updated the test to expect 2 (the number of lines) and updated the docstring comment.

**Why:** The v0.3.0 changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior." The code was correct per the documented API; the test was stale.

---

### Issue 4: Ruff import sorting and typing modernization

**What was wrong:** After fixing the above, ruff still flagged:
- I001: Import blocks not sorted (in `__init__.py`, `cart.py`, `test_discount.py`)
- UP006/UP035: `typing.List` deprecated, should use `list`
- UP045: `Optional[float]` should be `float | None`

**Fix:** Applied `ruff --fix` to auto-correct all of these.

**Why:** These are style/modernization rules enforced by the project's ruff configuration (`select = ["E", "F", "I", "B", "UP"]`).
