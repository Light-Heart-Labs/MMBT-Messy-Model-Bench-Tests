# ADR-001: Fix `discount_amount` code, not the tests

**Status:** Accepted

**Context:** `discount_amount(100.0, 20.0)` returned `2000.0` instead of `20.0`. The function was supposed to take a percent (0–100) per the v0.3.0 breaking change, but the implementation still treated the input as if it were a raw multiplier.

**Decision:** Fix the code (`price * percent_off / 100`) rather than changing the tests.

**Rationale:**
- The docstring examples in `discount.py` clearly show `discount_amount(100.0, 20.0) -> 20.0`.
- The v0.3.0 changelog documents the API change to percent-based input.
- The tests match the documented API; the code was the regression.

---

# ADR-002: Fix `line_count` test, not the code

**Status:** Accepted

**Context:** `test_line_count_matches_qty_sum` expected `line_count()` to return total quantity (5), but the code returned number of lines (2).

**Decision:** Update the test to match the v0.3.0 API, not change the code back.

**Rationale:**
- The v0.3.0 changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior."
- The code correctly implements the documented v0.3.0 API.
- The test was written for the v0.2.0 behavior and never updated.
