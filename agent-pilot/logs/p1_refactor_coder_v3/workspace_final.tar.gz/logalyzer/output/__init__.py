"""Output formatters package.

This package provides various output formatters for log entries and aggregate results.
"""
from __future__ import annotations

from .csv_renderer import to_csv
from .json_renderer import to_json
from .legacy import format_legacy
from .plain_renderer import to_text
from .render_aggregate import render_aggregate

__all__ = [
    "format_legacy",
    "render_aggregate",
    "to_csv",
    "to_json",
    "to_text",
]
