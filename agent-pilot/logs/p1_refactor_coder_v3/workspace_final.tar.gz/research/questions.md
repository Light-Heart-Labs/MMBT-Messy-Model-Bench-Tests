# Research Questions

## Questions and Answers

### Q1: Should format_legacy be moved from utils.py to output/legacy.py?

**Question**: The task says to put format_legacy in output/legacy.py, but it's currently in utils.py. Should I move it?

**Answer**: Yes. The task explicitly states that output.py "mixes ... the legacy format_legacy() function" and that legacy.py should contain "format_legacy() and any backward-compat shims". Even though format_legacy is not currently in output.py, the task wants it to be in the output package for logical grouping.

**Resolution**: Moved format_legacy from utils.py to output/legacy.py. The function is unchanged, only its location.

### Q2: Should render_aggregate be in its own module or stay in __init__.py?

**Question**: render_aggregate is a relatively small function. Should it be in its own module or just in __init__.py?

**Answer**: It should be in its own module (render_aggregate.py) for consistency with the other formatters. Even though it's small, it's a distinct concern (rendering aggregates vs. rendering entries).

**Resolution**: Created render_aggregate.py as a separate module.

### Q3: Should I preserve the exact JSON/CSV/text formatting?

**Question**: The current implementation has some quirks (e.g., manual JSON string building). Should I preserve these or improve them?

**Answer**: Preserve them exactly. The task says "Behavior must be byte-identical for all current call sites" and "No bug fixes". Even if the implementation is suboptimal, it must be preserved.

**Resolution**: Copied the implementations exactly as they were in output.py.

### Q4: How should I handle the __all__ list?

**Question**: Should I include format_legacy in __all__ even though it wasn't in the original output.py?

**Answer**: Yes. Since the task wants format_legacy in the output package, and it's a public function, it should be in __all__. This makes it clear that it's part of the public API.

**Resolution**: Included format_legacy in __all__.

### Q5: Should I keep the old output.py file for backward compatibility?

**Question**: Should I keep output.py as a wrapper that imports from the new modules?

**Answer**: No. The task says to "split" output.py, not to keep it as a wrapper. The old file should be deleted and replaced with the package.

**Resolution**: Deleted output.py and created the output package.
