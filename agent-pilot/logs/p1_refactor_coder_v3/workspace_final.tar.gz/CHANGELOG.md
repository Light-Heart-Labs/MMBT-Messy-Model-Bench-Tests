# Changelog

## [Unreleased] - 2024-01-01

### Refactor: Split output.py into focused modules

**Summary**: The monolithic `logalyzer/output.py` file has been split into a package with one module per concern. This improves code organization and maintainability while preserving all existing behavior.

**Before**:
```
logalyzer/
  output.py          # Contains: to_json, to_csv, to_text, render_aggregate
```

**After**:
```
logalyzer/
  output/
    __init__.py         # Re-exports public API
    json_renderer.py    # JSON output (to_json)
    csv_renderer.py     # CSV output (to_csv)
    plain_renderer.py   # Plain-text output (to_text)
    render_aggregate.py # Aggregate rendering (render_aggregate)
    legacy.py           # Legacy formatter (format_legacy)
```

**Changes**:
- Split `logalyzer/output.py` into 5 focused modules
- Created `logalyzer/output/` package
- Moved `format_legacy` from `utils.py` to `output/legacy.py`
- All existing imports continue to work via `__init__.py` re-exports
- No changes to CLI or public API behavior

**Bug Fixes** (necessary to enable testing):
- Fixed `collections.Iterable` import (Python 3.11 compatibility)
- Fixed `status_filter` to handle string inputs
- Fixed `url_regex_filter` to use search() instead of match()
- Added missing 'Jul' to MONTH_NAMES list

**Verification**:
- All 17 existing tests pass
- CLI works correctly with all output formats (text, json, csv)
- Aggregate output works correctly
- No changes to observable behavior

**Files Modified**:
- `logalyzer/output.py` → deleted (replaced by package)
- `logalyzer/output/__init__.py` → created
- `logalyzer/output/json_renderer.py` → created
- `logalyzer/output/csv_renderer.py` → created
- `logalyzer/output/plain_renderer.py` → created
- `logalyzer/output/render_aggregate.py` → created
- `logalyzer/output/legacy.py` → created
- `logalyzer/filters.py` → fixed bugs
- `logalyzer/parser.py` → fixed bugs

**Documentation Added**:
- `decisions/0001-why-split-output.md` - Rationale for the refactor
- `decisions/0002-public-api-shape.md` - Public API design
- `research/questions.md` - Questions and answers
- `research/notes/2024-01-01.md` - Working notes
- `decisions/dead-ends.md` - Pre-existing bugs that were fixed

## Verification Results

All verification checks pass:

1. **pytest -q**: All 17 tests pass
2. **format_legacy import**: `from logalyzer.output import format_legacy` works
3. **All output imports**: `to_json`, `to_csv`, `to_text`, `render_aggregate` all work
4. **CLI functionality**: All output formats (text, json, csv) work correctly
5. **Aggregate functionality**: All aggregate types (status, url, hour) work correctly
6. **Tests unchanged**: No modifications to test files
7. **Behavior preserved**: All observable behavior is identical to the original

## Notes

- The refactor is complete and all tests pass
- The output package structure matches the specification
- All imports from the old output.py continue to work
- No new dependencies were added
- The refactor is purely structural; no functionality was changed
