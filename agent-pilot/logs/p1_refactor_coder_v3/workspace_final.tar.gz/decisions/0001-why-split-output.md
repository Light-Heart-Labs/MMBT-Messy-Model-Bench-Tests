# 0001: Why Split output.py

Date: 2024-01-01

## Status

Accepted

## Context

The `logalyzer/output.py` file has grown to contain multiple concerns:
1. JSON serialization (`to_json`)
2. CSV serialization (`to_csv`)
3. Plain-text formatting (`to_text`)
4. Aggregate result rendering (`render_aggregate`)

This mixing of concerns makes the file harder to understand, test, and maintain. As the codebase evolves, adding new output formats or modifying existing ones becomes increasingly difficult without risking breaking changes to other functionality.

## Decision

We will split `output.py` into a package with one module per concern:

```
logalyzer/output/
  __init__.py         Re-exports the public API
  json_renderer.py    JSON output
  csv_renderer.py     CSV output
  plain_renderer.py   Plain-text output
  render_aggregate.py Aggregate result rendering
  legacy.py           format_legacy() for backward compatibility
```

## Consequences

### Positive
- **Clearer organization**: Each module has a single, well-defined responsibility
- **Easier testing**: Each formatter can be tested in isolation
- **Better maintainability**: Changes to one format don't affect others
- **Easier to extend**: Adding new output formats is straightforward

### Negative
- **More files**: The package now has more modules to navigate
- **Import changes**: Callers need to understand the new package structure (though this is mitigated by the __init__.py re-exports)

## Notes

- The refactor is behavior-preserving: all existing imports continue to work
- The public API surface remains unchanged (via __init__.py re-exports)
- No functionality is added or removed, only reorganized
