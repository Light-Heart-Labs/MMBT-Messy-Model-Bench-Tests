# 0002: Public API Shape

Date: 2024-01-01

## Status

Accepted

## Context

The `output.py` module had several functions that were exported:
- `to_json(entries)` - Render entries as JSON
- `to_csv(entries)` - Render entries as CSV
- `to_text(entries)` - Render entries as plain text
- `render_aggregate(agg, fmt)` - Render aggregate results

Additionally, `format_legacy(entry)` was in `utils.py` but should be moved to the output package for consistency.

## Decision

The public API will be re-exported from `logalyzer/output/__init__.py`:

```python
from .csv_renderer import to_csv
from .json_renderer import to_json
from .legacy import format_legacy
from .plain_renderer import to_text
from .render_aggregate import render_aggregate

__all__ = [
    "format_legacy",
    "render_aggregate",
    "to_csv",
    "to_json",
    "to_text",
]
```

This ensures:
1. **Backward compatibility**: All existing imports continue to work
2. **Clear API surface**: The __all__ list documents what's public
3. **Flexibility**: Internal modules can be reorganized without affecting callers

## Consequences

### Positive
- Callers can continue using `from logalyzer.output import X`
- The __all__ list makes the public API explicit
- Internal refactoring is easier (modules can be renamed/reorganized)

### Negative
- Slight indirection (imports go through __init__.py)
- Need to maintain __all__ list as API evolves

## Notes

- The `format_legacy` function is now in `output/legacy.py` instead of `utils.py`
- This is a logical grouping: legacy formatters belong with other formatters
- The function itself is unchanged, only its location
