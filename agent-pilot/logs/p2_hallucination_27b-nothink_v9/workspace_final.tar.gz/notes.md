# Verification Notes for logalyzer Code Review Triage

## Overview

Reviewed 15 issues from a draft code-review report against the actual logalyzer codebase. Found **6 real** issues and **9 fabricated** ones.

## Real Issues (6)

### 001 — `from collections import Iterable` (filters.py:5)
Confirmed. This import was removed in Python 3.10. Running the code on Python 3.11 raises `ImportError`. The fix is to use `from collections.abc import Iterable`.

### 002 — `eval()` usage (filters.py:59)
Confirmed. The `expression_filter()` function uses `eval()` with `{"__builtins__": {}}`. While this restricts built-in functions, it still allows arbitrary attribute access on the `entry` object, which could be exploited.

### 004 — README claims "Real-time tail mode" (README.md:12)
Confirmed. The README lists "Real-time tail mode for live log streams" as a feature, but there is no `--tail` flag, no streaming logic, and no tail-related code anywhere in the codebase.

### 006 — experimental.py is dead code
Confirmed. `logalyzer/experimental.py` exists with `detect_anomalies()` and `session_window()` functions, but no other module in the codebase imports from it. A grep for "experimental" across all .py files returns zero results.

### 013 — O(n²) performance in io.py load()
Confirmed. `logalyzer/io.py:24` uses `result = result + [entry]` (creates new list each iteration) and `io.py:27` uses `accumulated = accumulated + ch` (character-by-character string concatenation). Both are O(n²) operations.

### 014 — Linear membership test in ip_allowlist_filter
Confirmed. `logalyzer/filters.py:36` uses `entry.ip in allowlist` where `allowlist` is typically a list from argparse. For large allowlists, this should use a set for O(1) lookups.

## Fabricated Issues (9)

### 003 — SQL injection in parser.py
Fabricated. `parser.py` contains only regex-based log parsing. There is no SQL query construction, no database interaction, and no "database export pipeline" anywhere in the codebase.

### 005 — `--top` flag broken
Fabricated. The `--top` flag is properly defined with `type=int` in cli.py:33 and correctly passed to `by_url()` in cli.py:64. The `by_url()` function in aggregate.py:18 accepts and handles the `top` parameter correctly.

### 007 — Missing CSRF in web.py
Fabricated. `logalyzer/web.py` does not exist. This is a CLI-only tool with no web interface.

### 008 — 8192-character truncation in parser.py
Fabricated. `parse_line()` in parser.py does not truncate input. It strips whitespace and applies a regex match on the full line. No 8192-character limit exists.

### 009 — format_legacy() in output.py
Fabricated. The `format_legacy()` function exists in `logalyzer/utils.py:21`, NOT in `logalyzer/output.py`. Per the rules, a wrong file citation makes the issue fabricated.

### 010 — Race condition in load_iter()
Fabricated. `load_iter()` opens its own file handle per call. There is no shared mutable state between concurrent calls. Each invocation is independent.

### 011 — Double-counting 3xx in by_status()
Fabricated. `by_status()` simply counts each entry's status code once. There is no special handling of 3xx codes and no deduplication logic. The claim is nonsensical for a counting function.

### 012 — Stale cache in cache.py
Fabricated. `logalyzer/cache.py` does not exist. There is no caching layer in the codebase.

### 015 — LogEntry import in __init__.py
Fabricated. `logalyzer/__init__.py` contains only a docstring and `__version__`. It does not import `LogEntry` from anywhere.
