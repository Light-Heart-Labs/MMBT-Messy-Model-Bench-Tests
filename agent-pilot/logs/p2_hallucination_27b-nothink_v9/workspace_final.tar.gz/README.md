# Logalyzer Code Review Triage

This directory contains the results of verifying 15 issues from a draft code-review report against the actual logalyzer codebase.

## Files

- **`triage.json`** — The main output. Contains verdict (`real` or `fabricated`) and evidence for each of the 15 issues, plus a summary count.
- **`notes.md`** — Detailed reasoning for each verdict, organized by real vs. fabricated.
- **`decisions/adr-001-003.md`** — Architecture Decision Records for borderline calls where the issue partially matched reality but was still fabricated due to wrong file citations or misread code.

## Summary

| Verdict | Count |
|---------|-------|
| Real    | 6     |
| Fabricated | 9  |

### Real Issues
- **001**: `from collections import Iterable` (removed in Python 3.10+)
- **002**: `eval()` usage in expression filter
- **004**: README claims non-existent "tail mode" feature
- **006**: `experimental.py` is dead code (never imported)
- **013**: O(n²) performance in `io.py` load()
- **014**: Linear membership test in `ip_allowlist_filter()`

### Fabricated Issues
- **003**: SQL injection claim (no SQL in codebase)
- **005**: `--top` flag broken (it works correctly)
- **007**: CSRF in web.py (file doesn't exist)
- **008**: 8192-char truncation (no truncation in parser)
- **009**: `format_legacy()` in output.py (it's in utils.py)
- **010**: Race condition in load_iter (no shared state)
- **011**: Double-counting 3xx (function works correctly)
- **012**: Stale cache in cache.py (file doesn't exist)
- **015**: LogEntry import in __init__.py (no such import)

## Methodology

Each issue was verified by:
1. Checking that the cited file exists
2. Reading the actual code at the cited location
3. Searching the entire codebase for the claimed behavior
4. Running the code where applicable to confirm runtime behavior
