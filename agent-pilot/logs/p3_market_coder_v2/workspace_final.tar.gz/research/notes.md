# Research Notes

## Initial Goal
Research and recommend a password manager for a 50-person engineering team at a Series-B SaaS company.

## Key Constraints
- Current state: shadow IT (browser storage, sticky notes, Slack DMs)
- CTO wants solution in 90 days
- Need to replace insecure practices with a standardized, secure solution

## Evaluation Criteria (to be defined)
1. Security posture (encryption, breach history)
2. Compliance (SOC2, GDPR, etc.)
3. Pricing and transparency
4. Admin features (audit logs, SSO, provisioning)
5. Developer tool integration (VS Code, CLI, etc.)
6. Mobile + desktop coverage
7. Ease of adoption and migration

## Products to Evaluate
Based on research from ZDNet and other sources, the top 5 password managers are:
1. 1Password
2. Bitwarden
3. LastPass (now part of Thycentric)
4. Keeper Security
5. Dashlane

## Research Plan
1. Identify top 5 password managers based on market share, reviews, and security reputation
2. For each product, gather:
   - Security model (encryption, zero-knowledge)
   - Compliance certifications
   - Pricing (per seat, annual vs monthly)
   - Admin features (SSO, audit logs, SCIM)
   - Developer integrations
   - Mobile and desktop support
   - Migration tools
3. Compare against criteria
4. Make recommendation with runner-up and risks
