# Incident Rewrite Output

This directory contains three audience-tailored rewrites of the internal outage memo (`/input/repo/draft_memo.md`), produced according to the specifications in `/input/repo/audience_briefs.json`.

## Files

| File | Audience | Word Count | Limit |
|------|----------|------------|-------|
| `ceo_brief.md` | CEO / Board prep | 211 | ≤250 |
| `customer_email.md` | Affected customers (mass email) | 298 | ≤350 |
| `legal_summary.md` | In-house counsel | 272 | ≤400 |
| `decisions/adr-001-omission-decisions.md` | ADR records for non-obvious choices | — | — |
| `research/notes.md` | Working notes and fact extraction | — | — |

## How to Read

Each rewrite is a standalone document tailored to its audience's information needs, tone, and constraints. The CEO brief is a concise executive summary focused on impact, board signal, and remediations. The customer email is a warm, accountable message that explains the incident in plain language and offers SLA credits. The legal summary is a dispassionate, factual record for counsel to evaluate SLA-credit obligations.

All facts, numbers, and time references in the rewrites are drawn exclusively from the source memo. No external information was introduced. Omission decisions are documented in the ADR file.
