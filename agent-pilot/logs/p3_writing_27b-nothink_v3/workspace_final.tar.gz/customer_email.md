# Service Disruption — What Happened and What We're Doing About It

Dear Customer,

On Friday between 14:11 and 18:24 UTC, our API returned errors for approximately four hours. We know this disrupted your operations, and we own that.

**What happened:** A configuration update to our authentication service was deployed at 14:09 UTC. The change was intended to increase capacity, but it inadvertently triggered a safeguard that blocked authentication requests. Without successful authentication, our API could not process your requests, resulting in the errors you experienced. We identified the issue, reverted the change at 18:18 UTC, and confirmed full recovery by 18:24 UTC.

**Who was affected:** Approximately 11,400 customer accounts experienced errors during this window. We know that some of you had downstream processes that were interrupted, and we are reaching out individually to those accounts to help with any cleanup needed.

**What we're changing:**
- We are adding staged rollouts for configuration changes so that updates are tested in a single region before going global.
- We are fixing the safeguard that triggered this incident so it responds correctly to configuration changes.
- We have corrected our status-page monitoring so it accurately reflects the endpoints you use.
- We are updating our incident response protocol so that we acknowledge confirmed disruptions within 15 minutes, even before we have a full diagnosis.

**SLA credit:** If your account was impacted, you are eligible for an SLA credit per the terms of our service agreement. To request your credit, contact your Customer Success Manager or reach out to support at support@[company].com. We will process all valid requests promptly.

We are committed to earning back your trust. If you have questions, your CSM is your first point of contact, and our support team is available at support@[company].com.

Sincerely,

The Engineering Team
