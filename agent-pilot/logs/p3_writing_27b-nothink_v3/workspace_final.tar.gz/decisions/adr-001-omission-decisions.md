# ADR-001: Omission Decisions Per Audience

## Decision: What to omit from the CEO brief

**Context:** The source memo contains extensive technical detail about the rate-limiter mechanism, named individuals (Marcus, Priya, Sarah), and informal asides ("sorry Sarah, you were right").

**Decision:** The CEO brief omits:
- All named individuals (Marcus, Priya, Sarah) — the CEO needs outcomes, not personnel details.
- The technical explanation of the fraction-against-MAX mechanism — replaced with a plain-language summary ("triggered an internal safeguard").
- The "sorry Sarah" aside — informal and inappropriate for board prep.
- The runbook discussion — too granular for a 5-minute read.

**Rationale:** The audience brief explicitly prohibits engineering jargon and internal nicknames. The CEO needs to know what happened, who was impacted, what we're doing, and the board-level signal.

---

# ADR-002: Omission Decisions for Customer Email

**Context:** The source memo names Marcus as the deployer, references the "second outage in 90 days" board signal, and includes internal candor about unaddressed warnings from Sarah.

**Decision:** The customer email omits:
- Marcus's name — the brief explicitly prohibits blaming a named individual.
- The "second outage in 90 days" framing — this is an internal board signal, not customer-facing.
- The reference to Sarah's prior warning — this is internal candor that would undermine customer confidence.
- Technical details about rate limiters, MAX values, and throttling internals — replaced with plain-language explanation.
- The 28 enterprise / 4 downstream breakdown — replaced with a general "approximately 11,400 accounts" statement to avoid singling out tiers in a mass email.

**Rationale:** The customer email must be warm, accountable, and free of jargon. The brief explicitly prohibits named individuals and the "second outage in 90 days" framing.

---

# ADR-003: Omission Decisions for Legal Summary

**Context:** The source memo includes remediation plans, informal language, and speculation about future outages.

**Decision:** The legal summary omits:
- All remediation details (staged rollouts, runbook updates, etc.) — irrelevant to SLA credit determination.
- Named individuals (Marcus, Priya, Sarah) — the brief prohibits named-employee blame.
- Speculation about a potential third outage triggering a reliability overhaul — the brief prohibits speculation about future outages.
- Marketing language and apologies — the brief requires dispassionate, factual tone.
- The "sorry Sarah" aside and other informal candor.

**Rationale:** Counsel needs precise facts for SLA credit determinations: time window, scope, contractual threshold, downstream harm cases, and credit recommendations. Everything else is noise.

---

# ADR-004: Use of "support@[company].com" in Customer Email

**Context:** The source memo does not provide a specific support email address or contact path.

**Decision:** Used "support@[company].com" as a placeholder contact path, since the brief requires "a contact path (CSM, support, named exec)." The memo mentions CSMs and support tickets but no specific email.

**Rationale:** The brief requires a contact path. Since no specific email is in the source, a generic placeholder is the most faithful option. In production, this would be replaced with the actual support email.
