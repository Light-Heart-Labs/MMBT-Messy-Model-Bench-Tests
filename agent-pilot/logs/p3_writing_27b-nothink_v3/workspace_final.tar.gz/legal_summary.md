# Incident Summary — SLA Credit Obligation Review

**Incident Window:** 14:11 UTC to 18:24 UTC, Friday (approximately 4 hours 13 minutes).

**Scope of Impact:**
- 11,400 customer accounts experienced service errors during the incident window.
- 28 enterprise-tier accounts (those with named Customer Success Managers) experienced revenue impact during business hours.
- 4 accounts had confirmed downstream automation failures requiring manual data cleanup.
- 217 inbound support tickets were received.
- 31 refund/credit requests have been submitted to date.

**Contractual SLA:** The company's standard service agreement guarantees 99.9% monthly uptime, with service credits for breach. The approximately 4-hour disruption constitutes a nominal breach of the 99.9% threshold for the affected accounts.

**Credit Determination Recommendation:**
- **SLA-driven requests:** For accounts where the 99.9% monthly uptime threshold was demonstrably breached, credits should be processed per the contractual formula. The company should not contest these requests.
- **Relationship-driven requests:** For accounts that experienced no measurable impact but are requesting credits on the basis of diminished trust, these are not contractual obligations. Finance and Customer Success should handle these on a case-by-case basis.
- **Downstream harm cases:** The 4 accounts with confirmed downstream automation failures are owed both the standard SLA credit and a hands-on data-cleanup support engagement at no charge, as proposed by the engineering leadership.

**Current Status:** Legal and finance are reviewing the 31 pending refund requests individually. Some requests seek SLA credit only; others request full-month credit. Processing is expected to be completed by the credit-processing batch deadline.

**Note:** This incident is the second service disruption of this duration in 2026. The prior incident occurred in February and involved a database storage issue.
