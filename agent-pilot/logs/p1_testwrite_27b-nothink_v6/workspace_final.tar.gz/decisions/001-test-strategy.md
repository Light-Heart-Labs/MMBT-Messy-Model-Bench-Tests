# ADR-001: Test Strategy for logalyzer Coverage Gaps

## Context

The logalyzer codebase has significant coverage gaps:
- `experimental.py`: 0% coverage (anomaly detection, session windowing)
- `output.py`: 0% coverage (JSON, CSV, text formatters, render_aggregate)
- `utils.py`: 0% coverage (parse_iso_date, format_bytes, format_legacy, chunked)
- `io.py`: 0% coverage (file loading)
- `cli.py`: 0% coverage (CLI entry point)
- `filters.py`: 74% coverage (missing expression_filter, combine_and edge cases)
- `parser.py`: 86% coverage (missing edge cases)

## Decision

Target modules in order of highest value:
1. **experimental.py** — 0% coverage, complex logic (z-score, session grouping)
2. **output.py** — 0% coverage, critical output formatting
3. **utils.py** — 0% coverage, utility functions with edge cases
4. **io.py** — 0% coverage, file I/O paths
5. **cli.py** — 0% coverage, integration-level testing
6. **filters.py** — 74% coverage, missing expression_filter and combine_and
7. **parser.py** — 86% coverage, edge cases for malformed input

## Rationale

- experimental.py and output.py represent the largest coverage gaps
- utils.py has functions with clear edge cases (empty input, boundary values)
- io.py tests file I/O which is critical for the CLI tool
- cli.py tests integration between modules

## Pre-existing Test Failures

Three starter tests fail due to bugs in the source code:
1. `test_status_filter_works_with_cli_string_input` — status_filter doesn't convert string to int
2. `test_url_regex_finds_substring_match` — url_regex_filter uses `match` (start-anchored) not `search`
3. `test_timestamp_july_parses_correctly` — MONTH_NAMES list is missing "Jul"

These are documented in `research/dead-ends.md`. Per instructions, we do not fix these bugs or modify these tests.

## What We Chose NOT to Test

- We do not test the three failing starter tests — they document bugs, not expected behavior
- We do not test `benchmarks/bench.py` — it's a benchmark, not production code
- We do not modify any source files in `/logalyzer/`
