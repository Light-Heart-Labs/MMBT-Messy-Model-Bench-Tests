# ADR-002: Testing experimental.py — Dead Code Coverage

## Context

`experimental.py` contains two functions (`detect_anomalies` and `session_window`) that are:
- Not wired into the CLI
- Marked as "experimental" and "in-progress"
- At 0% test coverage

## Decision

We wrote comprehensive tests for both functions, achieving 100% coverage.

## Rationale

1. **Coverage goal**: The task explicitly requires testing dead code to increase coverage
2. **Regression protection**: If someone later wires these into the CLI, tests ensure they work
3. **Documentation**: Tests serve as executable documentation of expected behavior
4. **Bug surface**: Testing revealed the z-score threshold uses strict `>` (not `>=`), which we documented in test comments

## Recommendation (Out of Scope)

The experimental module should either be:
- **Integrated** into the CLI with proper feature flags, or
- **Removed** if the feature is abandoned

Keeping dead code with tests is acceptable as a middle ground — the tests prevent silent bit-rot.

## What We Tested

- `detect_anomalies`: empty input, single entry, uniform distribution, spike detection, minute bucketing, multiple anomalies
- `session_window`: empty input, single entry, single IP, multiple IPs, gap splitting, custom window, boundary conditions, sorting
