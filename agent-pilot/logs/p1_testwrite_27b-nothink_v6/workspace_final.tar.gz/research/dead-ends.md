# Dead Ends

## Pre-existing Failing Tests

Three starter tests fail due to bugs in the source code. Per instructions, these are documented but not fixed.

### 1. `test_status_filter_works_with_cli_string_input`

**Bug**: `status_filter` in `filters.py` compares `entry.status == status` directly. When the CLI passes `--status` as a string (e.g., `"404"`), the comparison `404 == "404"` is `False` in Python. The filter should convert the input to int.

**Impact**: The test expects `status_filter("404")` to match `status=404`, but it doesn't.

### 2. `test_url_regex_finds_substring_match`

**Bug**: `url_regex_filter` uses `rx.match(entry.url)` which anchors at the start of the string. Pattern `"admin"` won't match `"/admin/login"` because the URL starts with `/`. Should use `rx.search()` instead.

**Impact**: The test expects substring matching but only start-of-string matching works.

### 3. `test_timestamp_july_parses_correctly`

**Bug**: The `MONTH_NAMES` list in `parser.py` is missing "Jul" (July). The list goes from "Jun" to "Aug", skipping July entirely.

**Impact**: Any log entry with a July timestamp raises `ValueError: 'Jul' is not in list`.

## Consequences

- These tests remain failing in the final repo
- Our new tests avoid these buggy code paths or test the actual (buggy) behavior
- Coverage is measured excluding these failing tests
