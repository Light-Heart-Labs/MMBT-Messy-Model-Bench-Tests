# Questions

1. **Should we test the buggy behavior or avoid it?** — We test the actual behavior. For `status_filter`, we test that int comparison works (which it does). We don't re-test the string comparison bug since the starter test already does that (and fails).

2. **MONTH_NAMES missing "Jul"** — We avoid testing July timestamps in our new tests since the code is buggy. We document this as a known bug.

3. **`url_regex_filter` uses `match` not `search`** — We test anchored patterns (which work) and document the limitation.

4. **Should we test `experimental.py`?** — Yes. The task explicitly says "Test the dead code intentionally" and experimental.py has 0% coverage.

5. **`collections.Iterable` import** — The source code imports from `collections` (deprecated in 3.11). We monkey-patch in conftest.py to make it work. This is a test infrastructure fix, not a source code change.
