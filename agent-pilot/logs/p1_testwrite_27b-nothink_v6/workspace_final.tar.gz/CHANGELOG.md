# CHANGELOG

## v0.3.2 — Test Coverage Expansion

### Coverage Delta

| Metric | Before | After | Delta |
|--------|--------|-------|-------|
| Total coverage | 34% | 98% | +64% |
| Passing tests | 14 | 182 | +168 |
| Failing tests | 3 | 3 | 0 (pre-existing bugs) |

### Per-Module Coverage

| Module | Before | After |
|--------|--------|-------|
| `__init__.py` | 100% | 100% |
| `aggregate.py` | 100% | 100% |
| `cli.py` | 0% | 97% |
| `experimental.py` | 0% | 100% |
| `filters.py` | 74% | 97% |
| `io.py` | 0% | 100% |
| `output.py` | 0% | 100% |
| `parser.py` | 86% | 96% |
| `utils.py` | 0% | 95% |

### Test Files Added

1. **`tests/test_experimental.py`** (16 tests)
   - `detect_anomalies`: empty input, single entry, uniform distribution, spike detection, minute bucketing, multiple anomalies, all-same-minute
   - `session_window`: empty input, single entry, single IP no gaps, single IP with gap, multiple IPs, custom window, sorted entries, boundary gap

2. **`tests/test_output.py`** (22 tests)
   - `to_json`: empty input, single/multiple entries, special chars, unicode, zero bytes, ISO timestamp
   - `to_csv`: empty input, single/multiple entries, commas in URL
   - `to_text`: empty input, single/multiple entries, IP alignment
   - `render_aggregate`: text/json formats with dict and list, unknown format raises ValueError, empty inputs

3. **`tests/test_utils.py`** (29 tests)
   - `parse_iso_date`: valid dates, leap year, end/beginning of year, invalid format, nonexistent date, empty string, partial date
   - `format_bytes`: zero, one byte, boundary values (B→KB→MB→GB→TB), fractional, large values
   - `format_legacy`: basic format, structure verification, dash user
   - `chunked`: empty sequence, exact fit, remainder, single element, chunk size 1, oversized chunk, generator behavior, strings

4. **`tests/test_io.py`** (14 tests)
   - `load`: empty file, single line, no trailing newline, mixed valid/invalid, all invalid, only empty lines, multiple valid, file not found
   - `load_iter`: empty file, single line, skips invalid, is generator, file not found, no trailing newline

5. **`tests/test_cli.py`** (26 tests)
   - `build_parser`: argument parser creation, required paths, --version, --status, --url, --ip repeatable, --since/--until, --aggregate choices, --format choices, --top
   - `main`: return code, text/json/csv output, aggregate status/url/hour, aggregate with JSON format, status filter, multiple files, empty file, file not found, expression filter, IP filter, date range filter, top N

6. **`tests/test_filters_extended.py`** (19 tests)
   - `expression_filter`: status check, bytes check, method check, combined conditions, URL contains, sandboxed builtins, IP check
   - `combine_and`: single predicate, two predicates, three predicates, short-circuit, no predicates
   - Edge cases: zero status, large status, empty allowlist, set allowlist, regex special chars, empty pattern, case sensitivity

7. **`tests/test_parser_extended.py`** (26 tests)
   - `parse_line`: whitespace handling, tabs, dash bytes, large bytes, various methods, various status codes, unicode URL, query strings, IPv6, auth user, malformed method, missing protocol, partial lines
   - `parse_timestamp`: positive offset, UTC offset, malformed, missing timezone, invalid month, March, December (documents Jul bug), August (documents Jul bug)
   - `parse_lines`: empty list, mixed valid/invalid, is generator, all invalid

8. **`tests/test_aggregate_extended.py`** (16 tests)
   - `by_status`: empty input, single entry, all same status
   - `by_url`: empty input, single entry, top=0, top larger than unique, all same URL
   - `by_hour`: empty input, single entry, midnight, 23:59
   - `total_bytes`: empty input, single entry, all zero, large values

### Pre-existing Failing Tests (Not Modified)

Three starter tests fail due to bugs in the source code:
1. `test_status_filter_works_with_cli_string_input` — `status_filter` doesn't convert string to int
2. `test_url_regex_finds_substring_match` — `url_regex_filter` uses `match` (start-anchored) not `search`
3. `test_timestamp_july_parses_correctly` — `MONTH_NAMES` list is missing "Jul"

These are documented in `research/dead-ends.md`.

### Infrastructure

- `tests/conftest.py` — Added monkey-patch for `collections.Iterable` (removed from `collections` in Python 3.11, moved to `collections.abc`)
- `decisions/001-test-strategy.md` — ADR documenting test strategy and rationale
- `research/dead-ends.md` — Documentation of pre-existing bugs and test decisions
- `research/questions.md` — Open questions and design decisions
- `research/notes/2026-05-02.md` — Working notes
