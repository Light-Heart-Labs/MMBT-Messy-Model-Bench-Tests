"""Shared pytest fixtures."""
import sys
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Monkey-patch: Python 3.11 removed `collections.Iterable` (moved to collections.abc).
# The source code imports it from collections, so we backport it for compatibility.
import collections
if not hasattr(collections, "Iterable"):
    from collections.abc import Iterable as _Iterable
    collections.Iterable = _Iterable
