"""Tests for io.py — file loading (load and load_iter).

Targets 0% coverage module. Tests edge cases: empty files, malformed lines,
no trailing newline, mixed valid/invalid lines.
"""
import os
import tempfile

from logalyzer.io import load, load_iter


def _write_log(content):
    """Write content to a temp file and return the path."""
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False)
    f.write(content)
    f.close()
    return f.name


# ── load ────────────────────────────────────────────────────────────────────


def test_load_empty_file():
    """Empty file should return empty list."""
    path = _write_log("")
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_single_valid_line():
    """Single valid log line should return one entry."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    path = _write_log(line + "\n")
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_no_trailing_newline():
    """File without trailing newline should still parse the last line."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    path = _write_log(line)  # no trailing newline
    try:
        result = load(path)
        assert len(result) == 1
    finally:
        os.unlink(path)


def test_load_mixed_valid_invalid_lines():
    """File with mixed valid and invalid lines should skip invalid ones."""
    content = (
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
        'this is garbage\n'
        '192.168.1.1 - admin [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512\n'
        '\n'
        'more garbage here\n'
    )
    path = _write_log(content)
    try:
        result = load(path)
        assert len(result) == 2
        assert result[0].ip == "127.0.0.1"
        assert result[1].ip == "192.168.1.1"
    finally:
        os.unlink(path)


def test_load_all_invalid_lines():
    """File with only invalid lines should return empty list."""
    content = "garbage line 1\ngarbage line 2\ngarbage line 3\n"
    path = _write_log(content)
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_only_empty_lines():
    """File with only empty lines should return empty list."""
    content = "\n\n\n"
    path = _write_log(content)
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_multiple_valid_lines():
    """Multiple valid lines should all be parsed."""
    lines = [
        '10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "GET /a HTTP/1.1" 200 100\n',
        '10.0.0.2 - - [01/Jan/2026:00:01:00 +0000] "GET /b HTTP/1.1" 404 0\n',
        '10.0.0.3 - - [01/Jan/2026:00:02:00 +0000] "POST /c HTTP/1.1" 500 200\n',
    ]
    path = _write_log("".join(lines))
    try:
        result = load(path)
        assert len(result) == 3
        assert result[0].status == 200
        assert result[1].status == 404
        assert result[2].status == 500
    finally:
        os.unlink(path)


def test_load_file_not_found_raises():
    """Loading a non-existent file should raise FileNotFoundError."""
    try:
        load("/nonexistent/path/to/file.log")
        assert False, "Expected FileNotFoundError"
    except FileNotFoundError:
        pass


# ── load_iter ───────────────────────────────────────────────────────────────


def test_load_iter_empty_file():
    """Empty file should yield no entries."""
    path = _write_log("")
    try:
        result = list(load_iter(path))
        assert result == []
    finally:
        os.unlink(path)


def test_load_iter_single_line():
    """Single valid line should yield one entry."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
    path = _write_log(line)
    try:
        result = list(load_iter(path))
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_iter_skips_invalid_lines():
    """Invalid lines should be silently skipped by the generator."""
    content = (
        '10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "GET / HTTP/1.1" 200 100\n'
        'invalid line\n'
        '10.0.0.2 - - [01/Jan/2026:00:01:00 +0000] "GET / HTTP/1.1" 404 0\n'
    )
    path = _write_log(content)
    try:
        result = list(load_iter(path))
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_is_generator():
    """load_iter should return a generator, not a list."""
    path = _write_log('10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "GET / HTTP/1.1" 200 100\n')
    try:
        result = load_iter(path)
        assert hasattr(result, "__next__")
        assert hasattr(result, "__iter__")
    finally:
        os.unlink(path)


def test_load_iter_file_not_found_raises():
    """Loading a non-existent file should raise FileNotFoundError."""
    try:
        list(load_iter("/nonexistent/path/to/file.log"))
        assert False, "Expected FileNotFoundError"
    except FileNotFoundError:
        pass


def test_load_iter_no_trailing_newline():
    """File without trailing newline should still yield the last line."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    path = _write_log(line)
    try:
        result = list(load_iter(path))
        assert len(result) == 1
    finally:
        os.unlink(path)
