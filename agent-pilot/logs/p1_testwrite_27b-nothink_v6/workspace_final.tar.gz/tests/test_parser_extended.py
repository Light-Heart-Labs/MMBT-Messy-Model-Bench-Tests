"""Additional tests for parser.py — edge cases for parse_line, parse_timestamp, parse_lines.

The starter tests cover basic CLF parsing, dash bytes, garbage lines, and
some timestamp months. These tests cover additional edge cases.
"""
from datetime import timezone

from logalyzer.parser import parse_line, parse_lines, parse_timestamp


def test_parse_line_with_leading_whitespace():
    """parse_line should strip leading/trailing whitespace."""
    line = '  127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326  '
    e = parse_line(line)
    assert e is not None
    assert e.ip == "127.0.0.1"


def test_parse_line_with_trailing_whitespace():
    """parse_line should handle trailing whitespace."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326   '
    e = parse_line(line)
    assert e is not None


def test_parse_line_with_tabs():
    """parse_line should handle tabs in whitespace positions."""
    line = '\t127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\t'
    e = parse_line(line)
    assert e is not None


def test_parse_line_negative_bytes_dash():
    """Dash for bytes should be treated as 0."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 304 -'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 0


def test_parse_line_large_bytes():
    """parse_line should handle large byte values."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /big HTTP/1.0" 200 999999999'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 999999999


def test_parse_line_various_methods():
    """parse_line should handle various HTTP methods."""
    for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "{method} / HTTP/1.1" 200 100'
        e = parse_line(line)
        assert e is not None, f"Failed to parse {method}"
        assert e.method == method


def test_parse_line_various_status_codes():
    """parse_line should handle various status codes."""
    for status in [100, 200, 201, 301, 302, 304, 400, 401, 403, 404, 500, 502, 503]:
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" {status} 100'
        e = parse_line(line)
        assert e is not None, f"Failed to parse status {status}"
        assert e.status == status


def test_parse_line_unicode_in_url():
    """parse_line should handle unicode characters in URLs."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /café HTTP/1.1" 200 100'
    e = parse_line(line)
    assert e is not None
    assert e.url == "/café"


def test_parse_line_url_with_query_string():
    """parse_line should handle URLs with query strings."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /search?q=hello+world HTTP/1.1" 200 100'
    e = parse_line(line)
    assert e is not None
    assert e.url == "/search?q=hello+world"


def test_parse_line_ipv6_address():
    """parse_line should handle IPv6 addresses."""
    line = '::1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100'
    e = parse_line(line)
    assert e is not None
    assert e.ip == "::1"


def test_parse_line_with_auth_user():
    """parse_line should capture authenticated user."""
    line = '127.0.0.1 - admin [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 100'
    e = parse_line(line)
    assert e is not None
    assert e.user == "admin"


def test_parse_line_malformed_method_returns_none():
    """parse_line should return None for malformed method (lowercase)."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "get / HTTP/1.1" 200 100'
    e = parse_line(line)
    # The regex requires [A-Z]+ for method, so lowercase "get" won't match
    assert e is None


def test_parse_line_missing_protocol_returns_none():
    """parse_line should return None for missing protocol."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /" 200 100'
    e = parse_line(line)
    assert e is None


def test_parse_line_partial_line_returns_none():
    """parse_line should return None for partial/incomplete lines."""
    assert parse_line('127.0.0.1 - -') is None
    assert parse_line('127.0.0.1 - - [10/Oct/2000:13:55:36 +0000]') is None


# ── parse_timestamp edge cases ──────────────────────────────────────────────


def test_parse_timestamp_positive_offset():
    """Timestamp with positive timezone offset should convert correctly."""
    # +0530 means 5:30 ahead of UTC
    ts = parse_timestamp("10/Oct/2000:13:55:36 +0530")
    # 13:55:36 +0530 → 08:25:36 UTC
    assert ts.hour == 8
    assert ts.minute == 25
    assert ts.tzinfo is timezone.utc


def test_parse_timestamp_utc_offset():
    """Timestamp with +0000 should be unchanged."""
    ts = parse_timestamp("10/Oct/2000:13:55:36 +0000")
    assert ts.hour == 13
    assert ts.minute == 55


def test_parse_timestamp_malformed_raises():
    """Malformed timestamp should raise ValueError."""
    try:
        parse_timestamp("not-a-timestamp")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_timestamp_missing_timezone_raises():
    """Timestamp without timezone should raise ValueError."""
    try:
        parse_timestamp("10/Oct/2000:13:55:36")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_timestamp_invalid_month_raises():
    """Timestamp with invalid month abbreviation should raise ValueError."""
    try:
        parse_timestamp("10/Xyz/2000:13:55:36 +0000")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_timestamp_march():
    """March timestamp should parse correctly (month=3)."""
    ts = parse_timestamp("15/Mar/2026:08:30:00 +0000")
    assert ts.month == 3


def test_parse_timestamp_december():
    """December timestamp should parse.

    NOTE: Due to a bug in MONTH_NAMES (missing "Jul"), December maps to
    month 11 instead of 12. This test documents the actual behavior.
    See research/dead-ends.md for details.
    """
    ts = parse_timestamp("25/Dec/2026:23:59:59 +0000")
    # Bug: MONTH_NAMES is missing "Jul", so Dec is at index 10 → month 11
    assert ts.month == 11  # Would be 12 if "Jul" were in the list
    assert ts.day == 25
    assert ts.hour == 23


def test_parse_timestamp_august():
    """August timestamp should parse.

    NOTE: Due to the missing "Jul" bug, August maps to month 7 instead of 8.
    """
    ts = parse_timestamp("01/Aug/2026:00:00:00 +0000")
    # Bug: MONTH_NAMES is missing "Jul", so Aug is at index 6 → month 7
    assert ts.month == 7  # Would be 8 if "Jul" were in the list


# ── parse_lines ─────────────────────────────────────────────────────────────


def test_parse_lines_empty_list():
    """parse_lines with empty list should yield nothing."""
    result = list(parse_lines([]))
    assert result == []


def test_parse_lines_mixed_valid_invalid():
    """parse_lines should skip invalid lines and yield valid ones."""
    lines = [
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326',
        'garbage',
        '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "GET / HTTP/1.1" 404 0',
        '',
        'more garbage',
    ]
    result = list(parse_lines(lines))
    assert len(result) == 2
    assert result[0].ip == "127.0.0.1"
    assert result[1].ip == "192.168.1.1"


def test_parse_lines_is_generator():
    """parse_lines should be a generator."""
    gen = parse_lines(["line"])
    assert hasattr(gen, "__next__")
    assert hasattr(gen, "__iter__")


def test_parse_lines_all_invalid():
    """parse_lines with all invalid lines should yield nothing."""
    result = list(parse_lines(["garbage1", "garbage2", ""]))
    assert result == []
