"""Additional tests for aggregate.py — edge cases for by_status, by_url, by_hour, total_bytes.

The starter tests cover basic aggregation. These tests cover empty input,
single entry, and boundary conditions.
"""
from datetime import datetime, timezone

from logalyzer.aggregate import by_hour, by_status, by_url, total_bytes
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── by_status edge cases ────────────────────────────────────────────────────


def test_by_status_empty_input():
    """Empty input should return empty Counter."""
    result = by_status([])
    assert len(result) == 0


def test_by_status_single_entry():
    """Single entry should return Counter with one key."""
    result = by_status([_entry(status=404)])
    assert result[404] == 1
    assert len(result) == 1


def test_by_status_all_same_status():
    """All entries with same status should have one key with count=N."""
    entries = [_entry(status=200) for _ in range(100)]
    result = by_status(entries)
    assert result[200] == 100
    assert len(result) == 1


# ── by_url edge cases ───────────────────────────────────────────────────────


def test_by_url_empty_input():
    """Empty input should return empty list."""
    result = by_url([])
    assert result == []


def test_by_url_single_entry():
    """Single entry should return list with one tuple."""
    result = by_url([_entry(url="/home")])
    assert result == [("/home", 1)]


def test_by_url_top_zero():
    """top=0 should return empty list."""
    entries = [_entry(url=f"/u{i}") for i in range(10)]
    result = by_url(entries, top=0)
    assert result == []


def test_by_url_top_larger_than_unique():
    """top larger than number of unique URLs should return all."""
    entries = [_entry(url="/a"), _entry(url="/b")]
    result = by_url(entries, top=100)
    assert len(result) == 2


def test_by_url_all_same_url():
    """All entries with same URL should return one tuple."""
    entries = [_entry(url="/same") for _ in range(50)]
    result = by_url(entries)
    assert result == [("/same", 50)]


# ── by_hour edge cases ──────────────────────────────────────────────────────


def test_by_hour_empty_input():
    """Empty input should return dict with all hours at 0."""
    result = by_hour([])
    assert len(result) == 24
    assert all(v == 0 for v in result.values())


def test_by_hour_single_entry():
    """Single entry should increment one hour bucket."""
    result = by_hour([_entry(timestamp=datetime(2026, 1, 1, 5, 30, 0, tzinfo=timezone.utc))])
    assert result[5] == 1
    assert all(v == 0 for h, v in result.items() if h != 5)


def test_by_hour_midnight():
    """Entry at midnight should be in hour 0."""
    result = by_hour([_entry(timestamp=datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc))])
    assert result[0] == 1


def test_by_hour_23_59():
    """Entry at 23:59 should be in hour 23."""
    result = by_hour([_entry(timestamp=datetime(2026, 1, 1, 23, 59, 59, tzinfo=timezone.utc))])
    assert result[23] == 1


# ── total_bytes edge cases ──────────────────────────────────────────────────


def test_total_bytes_empty_input():
    """Empty input should return 0."""
    assert total_bytes([]) == 0


def test_total_bytes_single_entry():
    """Single entry should return its byte count."""
    assert total_bytes([_entry(bytes=512)]) == 512


def test_total_bytes_all_zero():
    """All entries with zero bytes should return 0."""
    entries = [_entry(bytes=0) for _ in range(10)]
    assert total_bytes(entries) == 0


def test_total_bytes_large_values():
    """Large byte values should sum correctly."""
    entries = [_entry(bytes=10**9) for _ in range(10)]
    assert total_bytes(entries) == 10 * 10**9
