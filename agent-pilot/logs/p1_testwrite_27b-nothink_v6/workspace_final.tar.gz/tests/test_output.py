"""Tests for output.py — JSON, CSV, text formatters and render_aggregate.

Targets 0% coverage module. Tests edge cases: empty input, special characters
in URLs, unicode, large byte counts, aggregate rendering formats.
"""
from datetime import datetime, timezone

from logalyzer.output import (
    render_aggregate,
    to_csv,
    to_json,
    to_text,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── to_json ─────────────────────────────────────────────────────────────────


def test_to_json_empty_input():
    """Empty input should produce an empty JSON array."""
    assert to_json([]) == "[]"


def test_to_json_single_entry():
    """Single entry should produce a JSON array with one object."""
    entries = [_entry()]
    result = to_json(entries)
    assert result.startswith("[")
    assert result.endswith("]")
    assert '"ip":"10.0.0.1"' in result
    assert '"status":200' in result
    assert '"bytes":100' in result


def test_to_json_multiple_entries():
    """Multiple entries should produce a JSON array with comma-separated objects."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_json(entries)
    assert result.count('"status":200') == 1
    assert result.count('"status":404') == 1


def test_to_json_special_characters_in_url():
    """URLs with special characters should be included as-is in JSON output.

    Note: the hand-built JSON doesn't escape special chars — this tests
    the actual behavior, not ideal JSON encoding.
    """
    entries = [_entry(url='/path?q=1&b=2')]
    result = to_json(entries)
    assert '/path?q=1&b=2' in result


def test_to_json_unicode_url():
    """Unicode URLs should pass through to JSON output."""
    entries = [_entry(url="/café")]
    result = to_json(entries)
    assert "café" in result


def test_to_json_zero_bytes():
    """Entries with zero bytes should render correctly."""
    entries = [_entry(bytes=0)]
    result = to_json(entries)
    assert '"bytes":0' in result


def test_to_json_iso_timestamp_format():
    """Timestamps should be rendered in ISO format."""
    entries = [_entry()]
    result = to_json(entries)
    assert "2026-01-01T12:00:00" in result


# ── to_csv ──────────────────────────────────────────────────────────────────


def test_to_csv_empty_input():
    """Empty input should produce CSV with only the header row."""
    result = to_csv([])
    lines = result.strip().split("\n")
    assert len(lines) == 1
    assert "ip,user,timestamp,method,url,protocol,status,bytes" in lines[0]


def test_to_csv_single_entry():
    """Single entry should produce header + one data row."""
    entries = [_entry()]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 2
    assert "10.0.0.1" in lines[1]


def test_to_csv_multiple_entries():
    """Multiple entries should produce header + N data rows."""
    entries = [_entry(status=200), _entry(status=404), _entry(status=500)]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 4  # header + 3 rows


def test_to_csv_commas_in_url():
    """URLs with commas should be properly quoted by csv.writer."""
    entries = [_entry(url="/path,a,b")]
    result = to_csv(entries)
    # csv.writer should quote the field containing commas
    assert '"/path,a,b"' in result or "/path,a,b" in result


# ── to_text ─────────────────────────────────────────────────────────────────


def test_to_text_empty_input():
    """Empty input should produce empty string."""
    assert to_text([]) == ""


def test_to_text_single_entry():
    """Single entry should produce one line of formatted text."""
    entries = [_entry()]
    result = to_text(entries)
    assert "10.0.0.1" in result
    assert "GET" in result
    assert "200" in result
    assert "/" in result


def test_to_text_multiple_entries():
    """Multiple entries should be separated by newlines."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_text(entries)
    lines = result.split("\n")
    assert len(lines) == 2


def test_to_text_ip_alignment():
    """IPs should be right-aligned in a 15-char field."""
    short_ip = _entry(ip="1.2.3.4")
    long_ip = _entry(ip="192.168.1.100")
    result = to_text([short_ip, long_ip])
    lines = result.split("\n")
    # Both IPs should appear in their respective lines
    assert "1.2.3.4" in lines[0]
    assert "192.168.1.100" in lines[1]


# ── render_aggregate ────────────────────────────────────────────────────────


def test_render_aggregate_text_format_with_dict():
    """Text format with dict-like aggregate should produce key\\tvalue lines."""
    from collections import Counter
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_text_format_with_list():
    """Text format with list of tuples should produce key\\tvalue lines."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_json_format_with_dict():
    """JSON format with dict-like aggregate should produce JSON object."""
    from collections import Counter
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="json")
    assert result.startswith("{")
    assert result.endswith("}")
    assert '"200":10' in result


def test_render_aggregate_json_format_with_list():
    """JSON format with list of tuples should produce JSON object."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="json")
    assert result.startswith("{")
    assert '"200":10' in result


def test_render_aggregate_unknown_format_raises():
    """Unknown format should raise ValueError."""
    agg = {"200": 10}
    try:
        render_aggregate(agg, fmt="xml")
        assert False, "Expected ValueError"
    except ValueError as e:
        assert "unknown format" in str(e)


def test_render_aggregate_empty_counter():
    """Empty Counter should produce empty output."""
    from collections import Counter
    agg = Counter()
    result = render_aggregate(agg, fmt="text")
    assert result == ""


def test_render_aggregate_empty_list():
    """Empty list should produce empty output."""
    agg = []
    result = render_aggregate(agg, fmt="text")
    assert result == ""
