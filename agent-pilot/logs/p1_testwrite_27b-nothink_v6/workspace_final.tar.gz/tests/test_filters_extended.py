"""Additional tests for filters.py — expression_filter, combine_and, edge cases.

The starter tests cover status_filter, url_regex_filter, ip_allowlist_filter,
and date_range_filter. These tests cover the remaining uncovered functions
and edge cases.
"""
from datetime import datetime, timezone

from logalyzer.filters import (
    combine_and,
    expression_filter,
    ip_allowlist_filter,
    status_filter,
    url_regex_filter,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── expression_filter ───────────────────────────────────────────────────────


def test_expression_filter_status_check():
    """Expression filter should evaluate Python expressions against entry."""
    pred = expression_filter("entry.status >= 400")
    assert pred(_entry(status=404)) is True
    assert pred(_entry(status=200)) is False


def test_expression_filter_bytes_check():
    """Expression filter should work with bytes field."""
    pred = expression_filter("entry.bytes > 1024")
    assert pred(_entry(bytes=2048)) is True
    assert pred(_entry(bytes=512)) is False


def test_expression_filter_method_check():
    """Expression filter should work with method field."""
    pred = expression_filter("entry.method == 'POST'")
    assert pred(_entry(method="POST")) is True
    assert pred(_entry(method="GET")) is False


def test_expression_filter_combined_conditions():
    """Expression filter should support compound conditions."""
    pred = expression_filter("entry.status >= 500 and entry.method == 'POST'")
    assert pred(_entry(status=500, method="POST")) is True
    assert pred(_entry(status=500, method="GET")) is False
    assert pred(_entry(status=200, method="POST")) is False


def test_expression_filter_url_contains():
    """Expression filter should work with string operations on url."""
    pred = expression_filter("'api' in entry.url")
    assert pred(_entry(url="/api/users")) is True
    assert pred(_entry(url="/index.html")) is False


def test_expression_filter_sandboxed():
    """Expression filter should have restricted builtins.

    The eval uses {"__builtins__": {}} so dangerous functions are unavailable.
    This tests that the sandbox is in place (even if eval itself is risky).
    """
    pred = expression_filter("entry.status == 200")
    # Should work with basic comparisons
    assert pred(_entry(status=200)) is True


def test_expression_filter_ip_check():
    """Expression filter should work with IP field."""
    pred = expression_filter("entry.ip.startswith('10.')")
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="192.168.1.1")) is False


# ── combine_and ─────────────────────────────────────────────────────────────


def test_combine_and_single_predicate():
    """combine_and with a single predicate should behave like that predicate."""
    pred = combine_and(status_filter(200))
    assert pred(_entry(status=200)) is True
    assert pred(_entry(status=404)) is False


def test_combine_and_two_predicates():
    """combine_and with two predicates should require both to match."""
    pred = combine_and(status_filter(200), url_regex_filter(r"^/api"))
    assert pred(_entry(status=200, url="/api/data")) is True
    assert pred(_entry(status=404, url="/api/data")) is False
    assert pred(_entry(status=200, url="/index")) is False


def test_combine_and_three_predicates():
    """combine_and with three predicates should require all to match."""
    pred = combine_and(
        status_filter(200),
        ip_allowlist_filter(["10.0.0.1", "10.0.0.2"]),
        url_regex_filter(r"^/"),
    )
    assert pred(_entry(status=200, ip="10.0.0.1", url="/api")) is True
    assert pred(_entry(status=200, ip="10.0.0.3", url="/api")) is False
    assert pred(_entry(status=404, ip="10.0.0.1", url="/api")) is False


def test_combine_and_short_circuits():
    """combine_and should short-circuit on first False predicate."""
    call_count = [0]

    def counting_pred(entry):
        call_count[0] += 1
        return False

    def second_pred(entry):
        return True

    combined = combine_and(counting_pred, second_pred)
    combined(_entry())
    # second_pred should not be called due to short-circuit
    assert call_count[0] == 1


def test_combine_and_no_predicates():
    """combine_and with no predicates should return True for all entries."""
    pred = combine_and()
    assert pred(_entry(status=200)) is True
    assert pred(_entry(status=404)) is True


# ── Edge cases for existing filters ─────────────────────────────────────────


def test_status_filter_zero_status():
    """status_filter should work with status code 0 (edge case)."""
    pred = status_filter(0)
    assert pred(_entry(status=0)) is True
    assert pred(_entry(status=200)) is False


def test_status_filter_large_status():
    """status_filter should work with large status codes."""
    pred = status_filter(999)
    assert pred(_entry(status=999)) is True
    assert pred(_entry(status=200)) is False


def test_ip_allowlist_empty_list():
    """ip_allowlist_filter with empty list should never match."""
    pred = ip_allowlist_filter([])
    assert pred(_entry(ip="10.0.0.1")) is False
    assert pred(_entry(ip="192.168.1.1")) is False


def test_ip_allowlist_with_set():
    """ip_allowlist_filter should work with a set (not just list)."""
    pred = ip_allowlist_filter({"10.0.0.1", "10.0.0.2"})
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="10.0.0.3")) is False


def test_url_regex_special_characters():
    """url_regex_filter should handle regex special characters."""
    # Dot in regex matches any character
    pred = url_regex_filter(r"^/api\.json$")
    assert pred(_entry(url="/api.json")) is True
    assert pred(_entry(url="/apiXjson")) is False  # . matches X in regex


def test_url_regex_empty_pattern():
    """url_regex_filter with empty pattern should match all URLs (empty regex matches start)."""
    pred = url_regex_filter("")
    # Empty regex matches at position 0 of any string
    assert pred(_entry(url="/anything")) is True


def test_url_regex_case_sensitive():
    """url_regex_filter should be case-sensitive by default."""
    pred = url_regex_filter(r"^/API")
    assert pred(_entry(url="/API/data")) is True
    assert pred(_entry(url="/api/data")) is False
