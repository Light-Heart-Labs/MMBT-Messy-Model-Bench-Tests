"""Tests for experimental.py — anomaly detection and session windowing.

Targets 0% coverage module. Tests edge cases: empty input, single entry,
anomaly thresholds, session gaps, multiple IPs.
"""
from datetime import datetime, timedelta, timezone

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1", **kw):
    """Helper to create a LogEntry with a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
        **kw,
    )


# ── detect_anomalies ────────────────────────────────────────────────────────


def test_detect_anomalies_empty_input():
    """Empty input should return empty list (no buckets to analyze)."""
    assert detect_anomalies([]) == []


def test_detect_anomalies_single_entry():
    """A single entry has std=0, threshold=mean. No value exceeds mean+0."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts)]
    # With one entry: mean=1, std=0, threshold=1. Value=1 is not > 1.
    assert detect_anomalies(entries) == []


def test_detect_anomalies_uniform_distribution():
    """Uniform request counts should produce no anomalies."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    # 10 entries in 10 different minutes → 1 per minute, std=0
    assert detect_anomalies(entries) == []


def test_detect_anomalies_spike_detected():
    """A minute with many more requests than others should be flagged.

    The code uses strict > comparison, so the spike must exceed mean + 3*std.
    With 10 normal minutes (1 req each) and 1 spike minute (200 req),
    mean ≈ 19.1, std ≈ 56.8, threshold ≈ 189.5, spike=200 > 189.5 ✓
    """
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    # 10 minutes with 1 request each
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    # 1 minute with 200 requests (the spike)
    spike_time = base + timedelta(minutes=10)
    entries += [_entry(spike_time) for _ in range(200)]
    result = detect_anomalies(entries)
    assert spike_time in result


def test_detect_anomalies_buckets_by_minute():
    """Entries in the same minute should be bucketed together."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    # 5 entries all in the same minute (different seconds)
    entries = [_entry(base + timedelta(seconds=i * 10)) for i in range(5)]
    result = detect_anomalies(entries)
    # Only 1 bucket with 5 entries; mean=5, std=0, threshold=5; 5 is not > 5
    assert result == []


def test_detect_anomalies_returns_minute_buckets_not_seconds():
    """Returned buckets should have second=0 and microsecond=0."""
    base = datetime(2026, 1, 1, 12, 30, 45, tzinfo=timezone.utc)
    entries = [_entry(base) for _ in range(200)]
    result = detect_anomalies(entries)
    if result:
        for bucket in result:
            assert bucket.second == 0
            assert bucket.microsecond == 0


def test_detect_anomalies_multiple_anomalous_minutes():
    """Multiple minutes exceeding threshold should all be returned."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    # Normal minutes: 1 request each
    for i in range(20):
        entries.append(_entry(base + timedelta(minutes=i)))
    # Two anomalous minutes: 100 requests each
    for spike_min in [20, 21]:
        spike_time = base + timedelta(minutes=spike_min)
        entries += [_entry(spike_time) for _ in range(100)]
    result = detect_anomalies(entries)
    assert len(result) == 2


def test_detect_anomalies_all_same_minute():
    """All entries in one minute: std=0, threshold=mean, no anomalies."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base) for _ in range(50)]
    assert detect_anomalies(entries) == []


# ── session_window ──────────────────────────────────────────────────────────


def test_session_window_empty_input():
    """Empty input should return empty sessions list."""
    assert session_window([]) == []


def test_session_window_single_entry():
    """A single entry should produce one session."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts)]
    sessions = session_window(entries)
    assert len(sessions) == 1
    ip, evts = sessions[0]
    assert ip == "10.0.0.1"
    assert len(evts) == 1


def test_session_window_single_ip_no_gaps():
    """All entries from one IP within window should be one session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    assert len(sessions[0][1]) == 10


def test_session_window_single_ip_with_gap():
    """A gap larger than window_seconds should split into two sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        # 40-minute gap (exceeds default 30-minute window)
        _entry(base + timedelta(minutes=50)),
        _entry(base + timedelta(minutes=60)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    assert len(sessions[0][1]) == 2
    assert len(sessions[1][1]) == 2


def test_session_window_multiple_ips():
    """Entries from different IPs should be in separate sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base, ip="10.0.0.1"),
        _entry(base + timedelta(minutes=5), ip="10.0.0.2"),
        _entry(base + timedelta(minutes=10), ip="10.0.0.1"),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 2
    ips = {s[0] for s in sessions}
    assert ips == {"10.0.0.1", "10.0.0.2"}


def test_session_window_custom_window():
    """Custom window_seconds should be respected."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=5)),
        _entry(base + timedelta(minutes=10)),
    ]
    # 5-minute window: gap between entries is 5 min = 300s, which equals window
    # The code uses `>` not `>=`, so 300 > 300 is False → same session
    sessions = session_window(entries, window_seconds=300)
    assert len(sessions) == 1

    # 4-minute window: 300 > 240 is True → split
    sessions = session_window(entries, window_seconds=240)
    assert len(sessions) == 3


def test_session_window_entries_sorted_by_time():
    """Entries within a session should be sorted by timestamp."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base + timedelta(minutes=5)),
        _entry(base),
        _entry(base + timedelta(minutes=10)),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 1
    timestamps = [e.timestamp for e in sessions[0][1]]
    assert timestamps == sorted(timestamps)


def test_session_window_gap_exactly_at_boundary():
    """A gap exactly equal to window_seconds should NOT split (uses > not >=)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    window = 600  # 10 minutes
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=window)),  # exactly at boundary
    ]
    sessions = session_window(entries, window_seconds=window)
    # gap == window, but code checks gap > window, so same session
    assert len(sessions) == 1
