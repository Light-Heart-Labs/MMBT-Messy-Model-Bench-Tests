"""Tests for utils.py — parse_iso_date, format_bytes, format_legacy, chunked.

Targets 0% coverage module. Tests edge cases: invalid dates, boundary byte
values, empty sequences, chunk size edge cases.
"""
from datetime import datetime, timezone

from logalyzer.parser import LogEntry
from logalyzer.utils import (
    chunked,
    format_bytes,
    format_legacy,
    parse_iso_date,
)


# ── parse_iso_date ──────────────────────────────────────────────────────────


def test_parse_iso_date_valid():
    """Valid YYYY-MM-DD should parse to UTC midnight."""
    dt = parse_iso_date("2026-01-15")
    assert dt == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_leap_year():
    """Leap year date should parse correctly."""
    dt = parse_iso_date("2024-02-29")
    assert dt == datetime(2024, 2, 29, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_end_of_year():
    """Last day of year should parse correctly."""
    dt = parse_iso_date("2025-12-31")
    assert dt == datetime(2025, 12, 31, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_beginning_of_year():
    """First day of year should parse correctly."""
    dt = parse_iso_date("2026-01-01")
    assert dt == datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_invalid_format_raises():
    """Invalid date format should raise ValueError from strptime."""
    try:
        parse_iso_date("01-15-2026")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_nonexistent_date_raises():
    """Nonexistent date (Feb 30) should raise ValueError."""
    try:
        parse_iso_date("2026-02-30")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_empty_string_raises():
    """Empty string should raise ValueError."""
    try:
        parse_iso_date("")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_partial_date_raises():
    """Partial date like '2026-01' should raise ValueError."""
    try:
        parse_iso_date("2026-01")
        assert False, "Expected ValueError"
    except ValueError:
        pass


# ── format_bytes ────────────────────────────────────────────────────────────


def test_format_bytes_zero():
    """Zero bytes should format as '0.0 B'."""
    assert format_bytes(0) == "0.0 B"


def test_format_bytes_one_byte():
    """One byte should format as '1.0 B'."""
    assert format_bytes(1) == "1.0 B"


def test_format_bytes_just_below_kb():
    """1023 bytes should still be in B, not KB."""
    assert format_bytes(1023) == "1023.0 B"


def test_format_bytes_exactly_one_kb():
    """1024 bytes should format as '1.0 KB'."""
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_exactly_one_mb():
    """1 MB (1024*1024) should format as '1.0 MB'."""
    assert format_bytes(1024 * 1024) == "1.0 MB"


def test_format_bytes_exactly_one_gb():
    """1 GB should format as '1.0 GB'."""
    assert format_bytes(1024 ** 3) == "1.0 GB"


def test_format_bytes_exactly_one_tb():
    """1 TB should format as '1.0 TB'."""
    assert format_bytes(1024 ** 4) == "1.0 TB"


def test_format_bytes_over_tb():
    """Values over 1 TB should still be formatted (the loop continues)."""
    result = format_bytes(1024 ** 4 * 2)
    assert "TB" in result


def test_format_bytes_fractional_kb():
    """1500 bytes should format as fractional KB."""
    result = format_bytes(1500)
    assert "KB" in result
    # 1500/1024 ≈ 1.5
    assert result == "1.5 KB"


def test_format_bytes_large_value():
    """Very large byte count should format correctly."""
    result = format_bytes(1024 ** 3 * 1.5)
    assert "GB" in result


# ── format_legacy ───────────────────────────────────────────────────────────


def test_format_legacy_basic():
    """Legacy format should produce pipe-delimited string."""
    entry = LogEntry(
        ip="192.168.1.1",
        user="admin",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/dashboard",
        protocol="HTTP/1.1",
        status=200,
        bytes=512,
    )
    result = format_legacy(entry)
    assert "192.168.1.1" in result
    assert "200" in result
    assert "/dashboard" in result
    assert "|" in result


def test_format_legacy_format_structure():
    """Legacy format follows: ip | timestamp | status | url.

    Note: timestamp uses datetime.__str__ (space-separated), not isoformat().
    """
    entry = LogEntry(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 6, 15, 8, 30, 0, tzinfo=timezone.utc),
        method="POST",
        url="/api/data",
        protocol="HTTP/2.0",
        status=500,
        bytes=0,
    )
    result = format_legacy(entry)
    parts = result.split(" | ")
    assert len(parts) == 4
    assert parts[0] == "10.0.0.1"
    # datetime.__str__ uses space separator: "2026-06-15 08:30:00+00:00"
    assert "2026-06-15" in parts[1]
    assert "08:30:00" in parts[1]
    assert parts[2] == "500"
    assert parts[3] == "/api/data"


def test_format_legacy_with_dash_user():
    """Legacy format should handle dash user (common in logs)."""
    entry = LogEntry(
        ip="127.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.0",
        status=304,
        bytes=0,
    )
    result = format_legacy(entry)
    assert "127.0.0.1" in result


# ── chunked ─────────────────────────────────────────────────────────────────


def test_chunked_empty_sequence():
    """Empty sequence should produce no chunks."""
    result = list(chunked([], 3))
    assert result == []


def test_chunked_exact_fit():
    """Sequence length exactly divisible by chunk size."""
    result = list(chunked([1, 2, 3, 4, 5, 6], 3))
    assert result == [[1, 2, 3], [4, 5, 6]]


def test_chunked_with_remainder():
    """Sequence with remainder should have a final smaller chunk."""
    result = list(chunked([1, 2, 3, 4, 5], 2))
    assert result == [[1, 2], [3, 4], [5]]


def test_chunked_single_element():
    """Single element should produce one chunk."""
    result = list(chunked([42], 5))
    assert result == [[42]]


def test_chunked_chunk_size_one():
    """Chunk size of 1 should produce one-element chunks."""
    result = list(chunked([1, 2, 3], 1))
    assert result == [[1], [2], [3]]


def test_chunked_chunk_size_larger_than_sequence():
    """Chunk size larger than sequence should produce one chunk."""
    result = list(chunked([1, 2], 10))
    assert result == [[1, 2]]


def test_chunked_generator_behavior():
    """chunked should be a generator (lazy evaluation)."""
    gen = chunked([1, 2, 3, 4], 2)
    # Should be a generator
    assert hasattr(gen, "__next__")
    assert hasattr(gen, "__iter__")


def test_chunked_with_strings():
    """chunked should work with any iterable, not just numbers."""
    result = list(chunked(["a", "b", "c", "d"], 2))
    assert result == [["a", "b"], ["c", "d"]]
