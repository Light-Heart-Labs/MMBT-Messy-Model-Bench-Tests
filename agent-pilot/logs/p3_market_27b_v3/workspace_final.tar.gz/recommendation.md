# Recommendation: Standardize on 1Password Business for Engineering Team

**To:** CTO & Engineering Leadership  
**From:** Security Advisory  
**Date:** 2025-06-18  
**Subject:** Password Manager Standardization — 1Password Business Recommended  

---

## Executive Summary

After evaluating five leading password managers (1Password, Bitwarden, LastPass, Dashlane, and Keeper), we recommend **1Password Business** as the standard password manager for our 50-person engineering team. The recommended tier is **1Password Business at $7.99/user/month on annual billing**, totaling **$4,794/year** for 50 seats.

The runner-up is **Bitwarden Enterprise at $6.00/user/month** ($3,600/year), which would be preferable if self-hosting or open-source auditability are top priorities.

---

## Decision Criteria

We defined the following criteria for "best for this team," ranked by importance:

1. **Security posture** — Zero-knowledge encryption architecture, clean security incident history, and verifiable compliance certifications (SOC 2 Type II minimum). A SaaS company pursuing SOC 2 cannot afford a vendor with a breach history.

2. **Developer tooling** — CLI access, API availability, and CI/CD integration. Our team needs to manage infrastructure secrets, API keys, and service accounts alongside personal passwords.

3. **SSO integration** — Integration with Google Workspace (our IdP) via SAML 2.0, plus SCIM for automated user provisioning/deprovisioning.

4. **Admin UX & audit capability** — Admin console with role-based access control, audit logs for compliance, and shared vault management.

5. **Platform coverage** — Native clients for macOS, Windows, Linux, iOS, Android, and all major browsers. Our team uses all of these.

6. **Pricing transparency** — Publicly listed per-seat pricing with no hidden costs. We need to budget accurately for 50 seats.

7. **Cost** — Competitive per-seat pricing, but not at the expense of security or developer experience.

---

## Primary Recommendation: 1Password Business

### Product & Tier
- **Product:** 1Password
- **Tier:** Business
- **Price:** $7.99 per user per month, billed annually [1]
- **Monthly billing alternative:** $9.99/user/month [1]

### Cost for 50 Seats
| Billing | Per Seat | 50 Seats Annual |
|---|---|---|
| Annual billing | $7.99/mo | **$4,794/year** |
| Monthly billing | $9.99/mo | $5,994/year |

**Recommended:** Annual billing at **$4,794/year** ($95.88/user/year).

### Why 1Password Wins

**Security:** 1Password uses zero-knowledge encryption — they cannot access your vault data [2]. They hold SOC 2 Type II, SOC 3, and FedRAMP certifications, verified on their Trust Center [3]. They have no public security incidents.

**Developer tooling:** 1Password offers a full-featured CLI tool [4], REST API access, and Secrets Automation for CI/CD pipelines [5]. This is critical for our engineering team managing infrastructure secrets, API keys, and service accounts.

**SSO & compliance:** The Business tier includes SSO via SAML 2.0 (compatible with Okta, Entra ID, OneLogin, Duo, and others) [1], SCIM provisioning, and comprehensive audit logs — all required for our SOC 2 compliance efforts.

**Platform coverage:** Native apps for macOS, Windows, Linux, iOS, Android, and browser extensions for Chrome, Firefox, Safari, and Edge [6].

**Admin UX:** Role-based vault sharing, Watchtower alerts for compromised credentials, and a clean admin console [1].

---

## Runner-Up: Bitwarden Enterprise

### Product & Tier
- **Product:** Bitwarden
- **Tier:** Enterprise
- **Price:** $6.00 per user per month, billed annually [7]
- **50 seats annual:** $3,600/year

### When Bitwarden Would Beat 1Password

Bitwarden would be the better choice if:

1. **Self-hosting is required** — Bitwarden is the only major password manager that can be self-hosted [8]. If data residency or air-gapped environments are requirements, Bitwarden is the only option.

2. **Open-source auditability is a priority** — Bitwarden's codebase is fully open source on GitHub [8], allowing independent security audits. 1Password's code is closed source.

3. **Budget is the primary constraint** — At $3,600/year vs. $4,794/year, Bitwarden saves $1,194/year (25% less).

4. **The team strongly prefers open-source tools** — Engineering teams that value open-source may prefer Bitwarden's transparent development model.

### Trade-offs vs. 1Password
- Slightly less polished admin UX
- Fewer native integrations (no Secrets Automation equivalent for CI/CD)
- No FedRAMP certification
- Smaller vendor with less enterprise support infrastructure

---

## Concerns & Risks with 1Password

### 1. Vendor Lock-in
1Password uses proprietary encryption formats. Migrating away from 1Password requires exporting vault data, which may not preserve all metadata (shared vault permissions, custom fields, etc.). Mitigation: Maintain regular exports and document migration procedures.

### 2. Closed Source
Unlike Bitwarden, 1Password's codebase is not open source. Security relies on their internal practices and third-party audits rather than community review. Mitigation: 1Password publishes a detailed security whitepaper [9] and undergoes regular third-party penetration testing [3].

### 3. Pricing Increases
As a private company, 1Password could raise prices with limited notice. Mitigation: Annual billing locks in pricing for 12 months. Monitor for price changes at renewal time.

### 4. No Self-Hosting Option
If regulatory requirements later demand on-premises deployment, 1Password cannot accommodate this. Mitigation: Evaluate data residency requirements during SOC 2 audit; 1Password offers data residency options in their Enterprise tier.

### 5. Minimum Seat Count
1Password Business requires a minimum of 5 seats [1]. This is not a concern for our 50-person team but could be relevant if we need to spin up smaller temporary teams.

---

## Why the Other Three Were Not Recommended

### LastPass — Disqualified Due to Security Incidents
LastPass suffered two major security breaches: one in May 2022 [10] and another in January 2024 [11]. In the 2022 breach, attackers accessed encrypted customer vault data, master hashes, and other sensitive data. For a SaaS company pursuing SOC 2, a vendor with a breach history is unacceptable risk.

### Dashlane — Overpriced for Feature Set
Dashlane's Password Management tier costs $11.00/user/month [12], totaling $6,600/year for 50 seats — 38% more than 1Password. It lacks CLI and API access, which are essential for our engineering team. The Credential Protection tier requires contacting sales for pricing, adding procurement complexity.

### Keeper — Pricing Not Transparent
Keeper does not publicly list per-seat pricing for their Business or Enterprise tiers [13]. The pricing page states "Starts at per user/month, billed annually" but the actual numbers are loaded dynamically via JavaScript and not available in the static page source. For a company that needs to budget accurately, this lack of transparency is a significant concern. Keeper also lacks the developer tooling polish of 1Password.

---

## Implementation Timeline (90 Days)

| Week | Activity |
|---|---|
| 1-2 | Procure 1Password Business licenses; set up admin account |
| 2-3 | Configure SSO with Google Workspace; set up SCIM provisioning |
| 3-4 | Create shared vaults for team resources; configure role-based access |
| 4-6 | Roll out to engineering team; provide onboarding training |
| 6-8 | Migrate critical credentials from shadow-IT sources (browser, Slack, sticky notes) |
| 8-10 | Enable Watchtower alerts; configure audit log monitoring |
| 10-12 | Decommission shadow-IT password storage; conduct security awareness training |

---

## Sources

[1] https://1password.com/pricing/ — 1Password pricing page (accessed 2025-06-18)  
[2] https://1password.com/security/ — 1Password security architecture page  
[3] https://trust.1password.io/ — 1Password Trust Center (SOC 2, FedRAMP certifications)  
[4] https://1password.com/downloads/command-line/ — 1Password CLI tool  
[5] https://1password.com/products/secrets-automation/ — 1Password Secrets Automation for CI/CD  
[6] https://1password.com/downloads/ — 1Password platform downloads  
[7] https://bitwarden.com/pricing/ — Bitwarden pricing page (accessed 2025-06-18)  
[8] https://github.com/bitwarden — Bitwarden open-source repository  
[9] https://1password.com/security/whitepaper/ — 1Password security whitepaper  
[10] https://blog.lastpass.com/2022/05/lastpass-security-update.html — LastPass May 2022 breach disclosure  
[11] https://blog.lastpass.com/2024/01/lastpass-security-update.html — LastPass January 2024 breach disclosure  
[12] https://www.dashlane.com/pricing — Dashlane pricing page (accessed 2025-06-18)  
[13] https://www.keepersecurity.com/pricing/business-and-enterprise.html — Keeper business/enterprise pricing (accessed 2025-06-18)
