# Research Notes — Password Manager Evaluation

## Date: 2025-06-18

## Products Evaluated
1. 1Password
2. Bitwarden
3. LastPass
4. Dashlane
5. Keeper

---

## 1Password

### Pricing (from https://1password.com/pricing/)
- **Individual**: $3.99/mo (annual), $5.99/mo (monthly)
- **Families**: $2.99/mo (annual), $4.99/mo (monthly) — up to 5 members
- **Teams Starter Pack**: $2.99/user/mo (annual), $4.99/user/mo (monthly)
- **Business**: $7.99/user/mo (annual), $9.99/user/mo (monthly)
- **Enterprise**: Contact sales / Buy with AWS available

### Features (from pricing page)
- Teams Starter Pack: Shared vaults, basic admin controls
- Business: SSO (Okta, Entra ID, OneLogin, Duo), role-based vault sharing, Watchtower alerts, CLI, API
- Zero-knowledge architecture
- SOC 2 compliance (confirmed on trust.1password.io)
- Platforms: macOS, Windows, Linux, iOS, Android, browser extensions, CLI

### Security
- Zero-knowledge encryption
- SOC 2 Type II certified
- Trust center: https://trust.1password.io/
- No major public security incidents found

---

## Bitwarden

### Pricing (from https://bitwarden.com/pricing/)
- **Personal**: Free
- **Premium**: $10/year ($0.83/mo)
- **Teams**: $4/user/month (billed annually)
- **Enterprise**: $6/user/month (billed annually)

### Features
- Open source (GitHub: https://github.com/bitwarden)
- Self-hostable
- Teams: Shared collections, admin console, basic SSO
- Enterprise: SSO/SAML, SCIM, audit logs, directory watch, custom branding
- Zero-knowledge architecture
- SOC 2 Type II certified
- Platforms: macOS, Windows, Linux, iOS, Android, browser extensions, CLI

### Security
- Open source codebase (auditable)
- SOC 2 Type II certified
- No major public security incidents found

---

## LastPass

### Pricing (from https://www.lastpass.com/business)
- **Business**: $7/user/month (or site license via custom contract)
- Enterprise: Contact sales

### Features
- Business: Shared folders, admin console, SSO, audit logs
- Zero-knowledge architecture
- SOC 2 compliance
- Platforms: macOS, Windows, Linux, iOS, Android, browser extensions

### Security Concerns
- **2022 breach**: May 2022 — attackers accessed encrypted customer vault data, master hashes, and other data. See https://blog.lastpass.com/2022/05/lastpass-security-update.html
- **2024 breach**: January 2024 — another security incident involving customer data
- These incidents are significant concerns for a SaaS company pursuing SOC 2

---

## Dashlane

### Pricing (from https://www.dashlane.com/pricing)
- **Password Management**: $11/user/month (billed annually)
- **Credential Protection**: Contact sales (custom pricing)
- **Enterprise**: Contact sales

### Features
- Password Management: Shared vaults, admin console, SSO
- Credential Protection: Advanced credential risk detection, omnix™ technology
- Zero-knowledge architecture
- SOC 2 compliance
- Platforms: macOS, Windows, Linux, iOS, Android, browser extensions

### Security
- Zero-knowledge encryption
- SOC 2 Type II certified
- No major public security incidents found

---

## Keeper

### Pricing (from https://www.keepersecurity.com/pricing/business-and-enterprise.html)
- **Business**: Starts at per user/month, billed annually (exact price loaded dynamically via JS — not publicly listed in static HTML)
- **Enterprise**: Starts at per user/month, billed annually (exact price loaded dynamically via JS — not publicly listed in static HTML)
- KeeperPAM: Custom pricing, contact sales

### Features
- Business: Encrypted vaults, shared team folders, role-based policies, basic 2FA
- Enterprise: SSO/SAML 2.0, SCIM provisioning, advanced MFA, role-based access control, developer APIs
- Zero-knowledge encryption
- SOC 2 Type 2 and SOC 3 certified
- Platforms: macOS, Windows, Linux, iOS, Android, browser extensions

### Security
- Zero-knowledge encryption
- SOC 2 Type 2 and SOC 3 certified
- Trust center: https://trust.keeper.io/
- No major public security incidents found

---

## Key Observations

1. **1Password Business** at $7.99/user/month (annual) is the clear recommendation for this team:
   - Strong security posture with no public incidents
   - Excellent developer tooling (CLI, API, GitHub integration)
   - SSO integration with Google Workspace (via Okta, Entra ID, etc.)
   - SOC 2 compliance
   - Good admin UX with audit logs

2. **Bitwarden Enterprise** at $6/user/month is the runner-up:
   - Open source (appeals to engineering teams)
   - Self-hostable option
   - Lower cost
   - But slightly less polished UX and fewer integrations

3. **LastPass** is a concern due to two major security breaches (2022, 2024)

4. **Dashlane** is the most expensive at $11/user/month

5. **Keeper** pricing is not transparent — requires contact sales
