# Sources

All URLs fetched during research for the password manager evaluation. Timestamps are approximate based on when the fetch occurred (2025-06-18).

## 1Password

| # | URL | Timestamp | Description |
|---|---|---|---|
| 1 | https://1password.com/pricing/ | 2025-06-18 | Main pricing page. Extracted per-seat pricing: Individual $3.99/mo (annual), Families $2.99/mo (annual), Teams Starter Pack $2.99/user/mo (annual), Business $7.99/user/mo (annual), Business monthly $9.99/user/mo. |
| 2 | https://1password.com/business/ | 2025-06-18 | Business product page. Confirmed SSO integrations (Okta, Entra ID, OneLogin, Duo), role-based vault sharing, Watchtower alerts. |
| 3 | https://1password.com/security/ | 2025-06-18 | Security architecture page. Confirmed zero-knowledge encryption model. |
| 4 | https://1password.com/compliance/ | 2025-06-18 | Compliance page. Referenced SOC 2 and FedRAMP certifications. |
| 5 | https://trust.1password.io/ | 2025-06-18 | Trust Center. Verified SOC 2 Type II, SOC 3, and FedRAMP certifications. |
| 6 | https://1password.com/security/whitepaper/ | 2025-06-18 | Security whitepaper (redirected to compliance page). |
| 7 | https://1password.com/downloads/command-line/ | 2025-06-18 | CLI tool download page. Confirmed CLI availability. |
| 8 | https://1password.com/downloads/ | 2025-06-18 | Platform downloads page. Confirmed macOS, Windows, Linux, iOS, Android, browser extensions, CLI. |

## Bitwarden

| # | URL | Timestamp | Description |
|---|---|---|---|
| 9 | https://bitwarden.com/pricing/ | 2025-06-18 | Main pricing page. Extracted pricing: Teams $4/user/month (annual), Enterprise $6/user/month (annual). |
| 10 | https://bitwarden.com/compliance/ | 2025-06-18 | Compliance page. Confirmed SOC 2 Type II certification. |
| 11 | https://github.com/bitwarden | 2025-06-18 | GitHub repository. Confirmed open-source status and self-hosting capability. |

## LastPass

| # | URL | Timestamp | Description |
|---|---|---|---|
| 12 | https://www.lastpass.com/pricing | 2025-06-18 | Pricing page. No per-seat pricing found in static HTML. |
| 13 | https://www.lastpass.com/business | 2025-06-18 | Business page. Found $7/user/month pricing and "site license" option. |
| 14 | https://www.lastpass.com/security | 2025-06-18 | Security page. Confirmed zero-knowledge architecture. |
| 15 | https://www.lastpass.com/compliance | 2025-06-18 | Compliance page. Confirmed SOC 2 certification. |
| 16 | https://blog.lastpass.com/2022/05/lastpass-security-update.html | 2025-06-18 | May 2022 security breach disclosure. Attackers accessed encrypted vault data, master hashes. |
| 17 | https://blog.lastpass.com/2024/01/lastpass-security-update.html | 2025-06-18 | January 2024 security breach disclosure. |

## Dashlane

| # | URL | Timestamp | Description |
|---|---|---|---|
| 18 | https://www.dashlane.com/pricing | 2025-06-18 | Pricing page. Found $11/user/month (billed annually) for Password Management. Credential Protection and Enterprise require "Contact Sales". |
| 19 | https://www.dashlane.com/business | 2025-06-18 | Business product page. No pricing found. |
| 20 | https://www.dashlane.com/security | 2025-06-18 | Security page. Confirmed zero-knowledge encryption. |
| 21 | https://www.dashlane.com/compliance | 2025-06-18 | Compliance page. Confirmed SOC 2 Type II certification. |

## Keeper

| # | URL | Timestamp | Description |
|---|---|---|---|
| 22 | https://www.keepersecurity.com/pricing | 2025-06-18 | Pricing page (redirected to business-and-enterprise). No static pricing found. |
| 23 | https://www.keepersecurity.com/pricing/business-and-enterprise.html | 2025-06-18 | Business/Enterprise pricing page. Pricing loaded dynamically via JavaScript. Found "Starts at per user/month, billed annually" for both Business and Enterprise tiers. No specific dollar amounts in static HTML. |
| 24 | https://www.keepersecurity.com/business.html | 2025-06-18 | Business product page. No pricing found. |
| 25 | https://www.keepersecurity.com/security.html | 2025-06-18 | Security page. Confirmed zero-knowledge encryption, SOC 2 Type 2, SOC 3. |
| 26 | https://trust.keeper.io/ | 2025-06-18 | Trust Center. Confirmed SOC 2 Type 2, SOC 3, and FedRAMP certifications. |
| 27 | https://www.keepersecurity.com/vs/1password/ | 2025-06-18 | Keeper vs 1Password comparison page. No pricing found. |

## Third-Party Sources

| # | URL | Timestamp | Description |
|---|---|---|---|
| 28 | https://www.pcmag.com/picks/what-are-the-best-password-managers | 2025-06-18 | PCMag password manager comparison. Limited Keeper data found. |
| 29 | https://www.techradar.com/best/best-password-manager | 2025-06-18 | TechRadar password manager comparison. |
| 30 | https://www.capterra.com/password-management-software/ | 2025-06-18 | Capterra password management software listing. |
| 31 | https://www.g2.com/products/keeper/reviews | 2025-06-18 | G2 Keeper reviews. |
| 32 | https://www.gartner.com/reviews/market/password-management | 2025-06-18 | Gartner password management market reviews. |

## Notes on Data Quality

- **1Password pricing:** Confirmed via static HTML extraction from pricing page. Prices are clearly listed in the page source.
- **Bitwarden pricing:** Confirmed via static HTML extraction. Prices are in JSON-like structures within the page.
- **LastPass pricing:** Found $7/user/month in the business page HTML. Enterprise pricing requires contact sales.
- **Dashlane pricing:** Found $11/user/month in the pricing page. Credential Protection and Enterprise require "Contact Sales".
- **Keeper pricing:** NOT publicly listed in static HTML. Pricing is loaded dynamically via JavaScript. The page states "Starts at per user/month, billed annually" but no specific dollar amounts are available without executing JavaScript. This is flagged as a concern for budgeting purposes.
