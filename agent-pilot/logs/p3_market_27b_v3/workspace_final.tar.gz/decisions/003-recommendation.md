# ADR-003: Recommendation — 1Password Business

## Status
Accepted

## Context
After evaluating five password managers (1Password, Bitwarden, LastPass, Dashlane, Keeper) against the criteria defined in ADR-002, we need to select a single product to standardize on.

## Decision
**1Password Business at $7.99/user/month (annual billing)** is recommended as the standard password manager.

**Runner-up:** Bitwarden Enterprise at $6.00/user/month (annual billing).

## Rationale

### Why 1Password over Bitwarden (the runner-up)
1. **Developer tooling:** 1Password's Secrets Automation provides native CI/CD integration for managing infrastructure secrets, which Bitwarden does not offer at the same level.
2. **Admin UX:** 1Password's admin console is more polished with better role-based vault sharing and Watchtower alerts.
3. **Compliance:** 1Password holds SOC 2 Type II, SOC 3, and FedRAMP — more comprehensive than Bitwarden's SOC 2 Type II alone.
4. **Vendor maturity:** 1Password is a more established enterprise vendor with larger support infrastructure.

### Why not Bitwarden
Bitwarden would be the better choice if:
- Self-hosting is required (Bitwarden is the only self-hostable option)
- Open-source auditability is a top priority
- Budget is the primary constraint ($1,194/year savings)

### Why not the other three
- **LastPass:** Disqualified due to two major security breaches (2022, 2024). Unacceptable risk for a SOC 2-bound company.
- **Dashlane:** Overpriced ($11/user/month vs. $7.99) and lacks CLI/API access essential for engineering teams.
- **Keeper:** Pricing not publicly listed, making budgeting impossible. Lacks the developer tooling polish of 1Password.

## Consequences
- Annual cost: $4,794 for 50 seats (vs. $3,600 for Bitwarden)
- No self-hosting option — if regulatory requirements later demand on-premises deployment, migration would be needed
- Proprietary encryption format — migration away from 1Password would require data export
- Vendor lock-in risk — mitigate with regular exports and documented migration procedures
