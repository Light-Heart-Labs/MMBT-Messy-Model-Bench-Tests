# ADR-002: Evaluation Criteria Definition

## Status
Accepted

## Context
We need to define clear, objective criteria for evaluating password managers for a 50-person engineering team at a Series-B SaaS company. The team currently uses shadow-IT password storage (browser, sticky notes, Slack DMs). The CTO wants this fixed in 90 days.

## Decision
We established the following weighted criteria:

| Criterion | Weight | Rationale |
|---|---|---|
| Security posture | 25% | Zero-knowledge encryption, clean incident history, SOC 2 Type II minimum |
| Developer tooling | 20% | CLI, API, CI/CD integration — essential for engineering team |
| SSO integration | 15% | Google Workspace integration via SAML 2.0, SCIM provisioning |
| Admin UX & audit | 15% | Role-based access, audit logs, shared vault management |
| Platform coverage | 10% | macOS, Windows, Linux, iOS, Android, browser extensions |
| Pricing transparency | 10% | Publicly listed per-seat pricing for accurate budgeting |
| Cost | 5% | Competitive pricing, but not at expense of security/UX |

## Rationale
- **Security is weighted highest** because a SaaS company pursuing SOC 2 cannot afford a vendor with breach history. LastPass was effectively disqualified by this criterion alone.
- **Developer tooling is weighted second** because our team needs to manage infrastructure secrets, API keys, and service accounts — not just personal passwords. Products without CLI/API access (LastPass, Dashlane) are at a significant disadvantage.
- **SSO integration is critical** for our 90-day rollout timeline. Manual user provisioning for 50 people is not feasible.
- **Pricing transparency matters** because we need to budget accurately. Keeper's lack of public pricing is a concern.
- **Cost is weighted lowest** because the price difference between options ($3,600-$6,600/year) is material but not decisive compared to security and developer experience.

## Consequences
- Products without CLI/API access (LastPass, Dashlane) are effectively disqualified for an engineering team.
- Products with breach history (LastPass) are disqualified for a SOC 2-bound company.
- Products without transparent pricing (Keeper) are at a disadvantage for budgeting purposes.
