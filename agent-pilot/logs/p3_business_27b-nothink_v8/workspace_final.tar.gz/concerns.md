# Concerns with the Borealis Analytics Deal Pack

## HIGH-IMPACT CONCERNS

### 1. Customer Concentration Risk — Not Addressed
The pack states ~280 paid customers with a median ARR of $32K per customer. However, it provides **no concentration analysis**. With $11.4M ARR and 280 customers, the average is ~$40.7K per customer, but the median is $32K — suggesting a right-skewed distribution with some large accounts. The pack only references "five largest customers" in pre-LOI conversations but never discloses what percentage of ARR they represent. If the top 5 customers represent >20% of ARR, that's a material concentration risk not flagged anywhere.

### 2. The Aurora Sunset Plan Is a Retention Bomb
The integration plan states: "Aurora platform sunset planned for 12 months post-close, with customer migration to our integrated platform." This is one of the most aggressive integration plans in a tuck-in acquisition. The pack provides **zero evidence** that:
- Customers would accept being migrated off Aurora
- Our integrated platform can match Aurora's feature set (the pack only claims ~12% feature overlap, meaning 88% of Aurora is unique)
- The 12-month migration timeline is realistic

If customers leave during migration, the $3.2M synergy estimate becomes irrelevant. This plan should have been validated with customers, not just internally decided.

### 3. Valuation Comps Are Cherry-Picked and Unadjusted
The pack cites three comps:
- Hexa Insights: ~9x ARR (Salesforce, Q4 2024)
- Aspen Data: ~12x ARR (Snowflake, Q1 2025)
- Trellis Analytics: ~7x ARR (HubSpot, Q3 2025)

And concludes Borealis at ~7.4x is "in line with the lower comps." This is problematic because:
- No adjustment is made for growth differences (Borealis grew 80-92% YoY — is that better or worse than the comps?)
- No adjustment for strategic value (were the comps more or less strategic to their acquirers?)
- No adjustment for profitability or margin profile
- The pack anchors to the lowest comp (Trellis at 7x) without explaining why Borealis deserves the lowest multiple in the set
- Only three comps is a thin sample

### 4. "Pre-LOI Conversations" With Top 5 Customers — What Were They About?
The pack states: "Pre-LOI conversations with their five largest customers indicate strong satisfaction (NPS in the high 40s)." But:
- Were these customers told about the potential acquisition?
- Were they asked about their willingness to stay if Aurora is sunset?
- "NPS in the high 40s" is good but not exceptional — and this is only 5 customers
- 4 of 5 were "willing to be quoted" but the quotes are generic and could be cherry-picked

### 5. Team Retention Risk Is Underestimated
The pack claims "~85% retention expected based on conversations with their VP Eng." This is a single data point from one person. The pack provides no information about:
- Retention packages or earn-out structures
- Which 15% are expected to leave and what roles they fill
- The CTO's personal stance on the acquisition (she's described as "strong" but her views on the deal are unknown)
- Whether the 14 engineers have been surveyed

### 6. IRR Estimate of 28-34% Is Unsubstantiated
The pack states: "Risk-adjusted IRR estimate is in the 28-34% range over the 4-year hold." But:
- No model or assumptions are provided
- No sensitivity analysis
- The $3.2M synergy is stated without derivation
- No discussion of integration costs (relocation, migration, dual-platform costs)
- No discussion of revenue impact from the Aurora sunset

### 7. Revenue Recognition vs ARR Gap
The pack shows $9.2M recognized revenue vs $11.4M ARR. The $2.2M gap is normal for SaaS (deferred revenue), but the pack doesn't explain the composition. More importantly, the 80% YoY revenue growth vs 92% ARR growth suggests the growth rate may be decelerating when viewed through the revenue lens. The pack presents both numbers as equally strong without noting this nuance.

### 8. Burn Rate and Runway
The pack states $750K monthly burn with $4.1M cash = "22 months runway at last cap raise." But:
- This is "at last cap raise" — is the burn rate current?
- If burn has increased since the last raise, runway is shorter
- Post-acquisition, the burn dynamics change entirely (relocation costs, integration costs)
- The pack doesn't discuss whether Borealis needs additional funding before close

## MEDIUM-IMPACT CONCERNS

### 9. Customer Testimonials Are Generic and Unverifiable
The four quoted testimonials are all positive but none are specific enough to be meaningful. "Best vendor experience" and "pricing has been fair" are not the kind of quotes that signal deep product-market fit. The pack doesn't provide any negative feedback or churn reasons.

### 10. Engineering Review Is Superficial
"Clean, well-tested" and "no concerning patterns" are vague assessments. The pack doesn't mention:
- Test coverage percentage
- CI/CD maturity
- Security audit status
- Data privacy compliance (GDPR, CCPA)
- Infrastructure costs vs revenue

### 11. No Legal or IP Diligence Mentioned
The pack is silent on:
- IP ownership (is Aurora fully owned by Borealis?)
- Pending or threatened litigation
- Open-source license compliance
- Customer contract terms (auto-renewal, termination clauses)
- Employee agreements (non-competes, IP assignment)

### 12. No Discussion of Competitive Threats
The pack doesn't address:
- Who are Borealis's competitors?
- Is Borealis growing because the market is growing or because they're winning share?
- What happens if a competitor launches a similar product?

### 13. "Mid-Market E-Commerce" Segment Strategy
The strategic rationale says Borealis extends into "mid-market e-commerce, a segment we currently service only via partner integrations." But:
- Why was the partner integration strategy insufficient?
- What's the total addressable market for this segment?
- Is this a strategic priority for the company, or just a nice-to-have?

### 14. Cash-Heavy Preference vs Our Capital Structure
Borealis prefers "cash-heavy" consideration. The pack doesn't discuss:
- What percentage is cash vs stock
- Impact on our balance sheet
- Tax implications
- Whether stock-heavy would be acceptable to Borealis

### 15. No Mention of Data Room or Financial Audit
The pack references "clean financials" but doesn't mention:
- Whether a formal financial audit has been conducted
- Quality of revenue (recurring vs one-time)
- Customer contract terms and renewal dates
- Whether the data room has been fully reviewed

## LOW-IMPACT CONCERNS

### 16. Timeline Pressure
"Decision needed by: 2026-04-30" — only 15 days from pack date. This is aggressive and may indicate the Corp Dev team is trying to force a decision before additional diligence could surface issues.

### 17. "Strongest Tuck-In We've Seen This Year"
This is a subjective claim with no benchmarking against other deals considered.

### 18. Product Roadmap Validation
"Our PM team validated all three are differentiated vs current alternatives" — but no details on the validation methodology or criteria.
