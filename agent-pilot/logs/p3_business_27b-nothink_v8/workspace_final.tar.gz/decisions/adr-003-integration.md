# ADR-003: Treatment of Integration Plan

**Status:** Accepted
**Date:** 2026-04-16

## Context

The pack states Aurora will be "sunset planned for 12 months post-close" with customer migration to our platform. This is a significant strategic decision with customer-retention implications.

## Decision

- The sunset plan is treated as a major risk, not a minor integration detail.
- The pack provides no evidence that customers would accept migration to our platform.
- The 85% retention expectation is based on conversations with only the VP Eng, not the broader team or customers.

## Consequences

- The memo will flag the sunset plan as a critical risk.
- An ask will be raised for customer migration validation.
