# ADR-001: Scope of Analysis

**Status:** Accepted
**Date:** 2026-04-16

## Context

The diligence pack is the sole source of information. No external data may be introduced. All concerns must be traceable to claims, omissions, or inconsistencies within the pack itself.

## Decision

- The memo will not invent customer names, financial figures, or market data.
- Where the pack is silent on a material topic (e.g., legal, IP, concentration risk), the omission itself is flagged as a concern.
- The recommendation is independent of the Corp Dev team's recommendation.

## Consequences

- Some concerns will be "absence of evidence" rather than "evidence of absence."
- The asks list will focus on closing the gaps identified.
