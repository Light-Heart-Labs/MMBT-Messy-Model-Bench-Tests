# ADR-002: Treatment of Comparable Transactions

**Status:** Accepted
**Date:** 2026-04-16

## Context

The pack cites three comparable acquisitions (Hexa Insights at ~9x ARR, Aspen Data at ~12x ARR, Trellis Analytics at ~7x ARR) and concludes Borealis at ~7.4x is "in line with the lower comps."

## Decision

- The comps are treated as a red flag, not a green light. The pack cherry-picks the range and anchors to the low end without explaining why Borealis deserves the lowest multiple.
- No adjustment is made for differences in growth rate, profitability, market position, or strategic value between Borealis and the comps.
- The memo will flag this as an overclaim.

## Consequences

- The valuation section of the memo will question the comp methodology.
- An ask will be raised for a more rigorous valuation analysis.
