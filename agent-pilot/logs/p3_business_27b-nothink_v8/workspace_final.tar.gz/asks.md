# Diligence Asks — Next 2 Weeks (by 2026-05-01)

## Priority 1: Customer & Retention Risk

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| 1 | Obtain full customer list with ARR per customer. Calculate top-5 and top-10 concentration ratios. | Corp Dev / Finance | 2026-04-22 |
| 2 | Re-contact the top 5 customers (and 5 additional mid-tier customers) with explicit disclosure of the acquisition and the planned Aurora sunset. Ask: (a) Would you stay if migrated to our platform? (b) What features of Aurora are non-negotiable? | Corp Dev / Sales | 2026-04-25 |
| 3 | Obtain churn data for the last 12 months: reasons for departure, timing, and whether any churned customers were large accounts. | Corp Dev / Finance | 2026-04-22 |
| 4 | Survey all 14 engineers on their intent to stay post-acquisition. Identify any who are likely to leave and assess the impact of their departure. | VP Eng | 2026-04-25 |

## Priority 2: Valuation & Financial Rigor

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| 5 | Build a formal valuation model with explicit assumptions for: revenue growth post-close, margin trajectory, synergy realization timeline, and integration costs. Provide sensitivity analysis (base, upside, downside). | CFO / Corp Dev | 2026-04-28 |
| 6 | Expand the comparable transaction analysis to at least 8-10 deals. Adjust for growth rate, margin profile, strategic value, and market position. | Corp Dev / Finance | 2026-04-25 |
| 7 | Obtain audited financials or at minimum a detailed revenue breakdown: recurring vs one-time, by customer cohort, by product feature. | Corp Dev / Finance | 2026-04-22 |
| 8 | Derive the $3.2M synergy estimate line by line. What infra costs are being eliminated? What are the offsetting migration costs? | VP Eng / Finance | 2026-04-25 |

## Priority 3: Integration & Product Risk

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| 9 | Conduct a detailed feature-gap analysis between Aurora and our platform. What percentage of Aurora's features can be matched? What would require new development? | VP Eng / PM | 2026-04-25 |
| 10 | Develop a revised integration plan that considers: (a) keeping Aurora as a standalone product, (b) partial integration, (c) full sunset. Model the customer-retention impact of each scenario. | Corp Dev / PM / Eng | 2026-04-28 |
| 11 | Assess the 4-6 month integration timeline against the feature-gap analysis. Is it realistic? | VP Eng | 2026-04-25 |

## Priority 4: Legal & Compliance

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| 12 | Complete IP diligence: confirm Borealis owns all IP in Aurora, review open-source dependencies, check for IP assignment clauses in employee contracts. | Legal | 2026-04-28 |
| 13 | Review customer contracts for: auto-renewal terms, termination clauses, data portability requirements, and any change-of-control provisions. | Legal | 2026-04-28 |
| 14 | Confirm data privacy compliance (GDPR, CCPA, SOC 2) and identify any gaps. | Legal / Security | 2026-04-25 |
| 15 | Check for pending or threatened litigation, regulatory investigations, or compliance issues. | Legal | 2026-04-22 |

## Priority 5: Strategic Context

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| 16 | Articulate the competitive landscape for Borealis: who are their competitors, what is their market share, and what is the TAM for mid-market e-commerce analytics? | Corp Dev / Strategy | 2026-04-28 |
| 17 | Clarify the cash vs stock split. Model the impact on our balance sheet and on Borealis's retention incentives. | CFO / Corp Dev | 2026-04-22 |
| 18 | Obtain the CTO's personal view on the acquisition and her conditions for staying. | VP Eng / Corp Dev | 2026-04-22 |
