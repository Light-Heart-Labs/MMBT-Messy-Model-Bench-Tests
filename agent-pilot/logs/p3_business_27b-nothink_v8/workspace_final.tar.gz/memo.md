# Executive Committee Memo — Borealis Analytics Acquisition Review

**To:** Executive Committee
**From:** [Reviewer], Executive Committee
**Date:** 2026-04-16
**Re:** Independent review of Corp Dev diligence pack — Project Lighthouse

---

## Recommendation: HOLD

I recommend **holding** the LOI decision until the diligence gaps identified below are addressed. The Corp Dev pack makes a reasonable case for strategic fit, but it reads as an advocacy document that overclaims on several fronts and omits material risk areas. I would move to **PROCEED** if, within the next two weeks, the committee receives satisfactory answers to the diligence asks in the accompanying document — particularly on customer retention risk, valuation rigor, and the Aurora sunset plan. I would move to **PASS** if customer concentration proves severe, if the top customers decline to stay post-sunset, or if the valuation model cannot support a 20%+ IRR under base-case assumptions.

---

## Strongest Concerns

### 1. The Aurora Sunset Plan Is the Deal's Biggest Risk

The integration plan states that the Aurora platform will be sunset within 12 months post-close, with customers migrated to our platform. The pack provides **no evidence** that customers would accept this migration. Aurora has ~12% feature overlap with our platform (per the pack's own engineering review), meaning 88% of its functionality is unique. If customers leave during migration, the $3.2M synergy estimate becomes irrelevant and the deal's economics collapse. This plan should have been validated with customers before being presented as a given.

### 2. Customer Concentration Is Not Analyzed

The pack reports ~280 paid customers, $11.4M ARR, and a median ARR of $32K per customer. The average is ~$40.7K, which is higher than the median — suggesting a right-skewed distribution with outsized accounts. The pack references "five largest customers" but never discloses what share of ARR they represent. If the top 5 accounts represent >20% of ARR, that is a material concentration risk that the pack should have flagged.

### 3. The Valuation Comps Are Cherry-Picked

The pack cites three comparable acquisitions (Hexa Insights at ~9x ARR, Aspen Data at ~12x ARR, Trellis Analytics at ~7x ARR) and concludes Borealis at ~7.4x is "in line with the lower comps." This is a thin sample with no adjustments for growth rate, margin profile, strategic value, or market position. The pack anchors to the lowest comp without explaining why Borealis deserves the floor of the range. A proper valuation analysis with 8-10 adjusted comps is needed.

### 4. The IRR Estimate of 28-34% Is Unsubstantiated

The pack states a "risk-adjusted IRR estimate" of 28-34% over four years but provides no model, no assumptions, and no sensitivity analysis. The $3.2M synergy figure is stated without derivation. There is no discussion of integration costs (relocation, dual-platform operations, migration engineering) or of the revenue impact of the Aurora sunset. An IRR claim without a visible model is not diligence — it's a headline.

### 5. Team Retention Is Based on a Single Data Point

The pack claims "~85% retention expected based on conversations with their VP Eng." This is one person's assessment of 14 engineers. The CTO's personal stance on the deal is unknown. No retention packages or earn-out structures are discussed. In a tuck-in acquisition, losing the CTO or a third of the engineering team would be deal-breaking.

### 6. Material Omissions

The pack is silent on several areas that should be covered before an LOI:
- **Legal/IP:** No mention of IP ownership, litigation, open-source compliance, or customer contract terms.
- **Data privacy:** No mention of GDPR, CCPA, or SOC 2 compliance.
- **Competitive landscape:** No discussion of Borealis's competitors or market share trajectory.
- **Financial audit:** No mention of whether financials have been audited or of revenue quality (recurring vs. one-time).

---

## Next Steps

The accompanying `asks.md` document lists 18 specific diligence items with owners and deadlines for the next two weeks. The committee should not issue an LOI until at minimum the Priority 1 and Priority 2 items are satisfactorily resolved. If the Corp Dev team can demonstrate that the top customers will stay post-sunset, that the valuation is supported by a rigorous model, and that the integration plan is realistic — I will reconsider my position.
