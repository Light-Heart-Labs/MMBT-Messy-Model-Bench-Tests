# Borealis Analytics Acquisition — Independent Review

## How to Read This Output

This directory contains an independent executive committee review of the Corp Dev diligence pack for the proposed acquisition of Borealis Analytics at $84M.

### Files

| File | Purpose |
|------|---------|
| [`memo.md`](memo.md) | **Primary deliverable.** 1-page memo with recommendation, key concerns, and next steps. Read this first. |
| [`concerns.md`](concerns.md) | Full enumeration of every concern identified, ranked by impact. Includes high, medium, and low-impact items. |
| [`asks.md`](asks.md) | 18 specific diligence asks with owners and deadlines for the next 2 weeks. Organized by priority. |
| [`decisions/`](decisions/) | Architecture Decision Records (ADRs) documenting judgment calls made during the review. |

### Recommendation Summary

**HOLD** — Do not issue the LOI until key diligence gaps are addressed. The Corp Dev pack is an advocacy document that overclaims on valuation, underexplains integration risk, and omits material areas (legal, IP, customer concentration, competitive landscape).

### Key Findings

1. **Aurora sunset plan** is the single biggest risk — no customer validation exists.
2. **Customer concentration** is not analyzed despite skewed ARR distribution.
3. **Valuation comps** are cherry-picked (3 deals, no adjustments).
4. **IRR estimate** (28-34%) has no supporting model.
5. **Team retention** claim is based on one conversation with the VP Eng.
6. **Legal, IP, and compliance** diligence is entirely absent from the pack.

### Source

All analysis is based solely on the diligence pack at `/input/repo/deal_pack.md`. No external data was introduced.
