# ADR-0002: Public API Shape

## Status
Accepted

## Context
The `logalyzer/output` module is imported by `cli.py` with:
```python
from .output import render_aggregate, to_csv, to_json, to_text
```

The verification requirement also demands:
```python
from logalyzer.output import format_legacy
```

## Decision
The `logalyzer/output/__init__.py` re-exports the following symbols:

| Symbol | Source Module | Notes |
|--------|--------------|-------|
| `to_json` | `json_renderer.py` | JSON array serialization |
| `to_csv` | `csv_renderer.py` | CSV with header row |
| `to_text` | `plain_renderer.py` | Plain-text formatting |
| `render_aggregate` | `__init__.py` (defined inline) | Dispatcher for aggregate output |
| `format_legacy` | `legacy.py` | Backward-compat formatter |

`render_aggregate` is defined directly in `__init__.py` rather than in a separate module because it's a thin dispatcher that references multiple format types. Placing it in `__init__.py` avoids circular imports and keeps the dispatcher close to the re-export surface.

## Consequences
- All existing call sites in `cli.py` work without modification.
- `format_legacy` is now importable from `logalyzer.output` as required.
- The `__all__` list in `__init__.py` documents the public API explicitly.
