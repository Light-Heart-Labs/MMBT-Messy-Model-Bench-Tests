# ADR-0001: Why Split output.py

## Status
Accepted

## Context
The `logalyzer/output.py` module mixes four distinct concerns:
1. JSON serialization (`to_json`)
2. CSV serialization (`to_csv`)
3. Plain-text formatting (`to_text`)
4. Aggregate rendering (`render_aggregate`)

Additionally, the task requires `format_legacy` to be importable from `logalyzer.output`, though it currently lives in `utils.py`.

This violates the Single Responsibility Principle and makes the module harder to navigate, test, and maintain.

## Decision
Split `logalyzer/output.py` into a `logalyzer/output/` package with one module per concern:

- `json_renderer.py` — `to_json()`
- `csv_renderer.py` — `to_csv()`
- `plain_renderer.py` — `to_text()`
- `legacy.py` — `format_legacy()` (moved from utils.py, re-exported for backward compat)
- `__init__.py` — re-exports the full public API so existing imports work unchanged

`render_aggregate()` is kept in `__init__.py` since it's a dispatcher that references multiple formats and doesn't belong to a single renderer.

## Consequences
- All existing imports (`from logalyzer.output import to_json, to_csv, to_text, render_aggregate`) continue to work.
- `from logalyzer.output import format_legacy` now works (it was previously only in `utils.py`).
- The `output/` package is self-contained and each renderer module has a single responsibility.
- No behavioral changes; all output is byte-identical.
