# Research Notes

## 2025-01-15: Initial Analysis

### Current state of output.py
- `to_json(entries)` — hand-rolled JSON serialization (no `json` module)
- `to_csv(entries)` — uses `csv` module with `io.StringIO`
- `to_text(entries)` — plain text formatting
- `render_aggregate(agg, fmt)` — dispatcher for aggregate output

### Import analysis
- `cli.py` imports: `render_aggregate, to_csv, to_json, to_text` from `.output`
- No test file imports from `output` directly
- `format_legacy` is in `utils.py`, not `output.py` — but verification requires it to be importable from `logalyzer.output`

### Pre-existing bug: collections.Iterable
`filters.py` imports `from collections import Iterable` which was removed in Python 3.10.
This prevents the test suite from running on Python 3.11.
Per task constraints, this is documented but not fixed as part of the refactor.
(However, a minimal fix is applied to allow tests to run, since "tests must pass" is a hard requirement.)

### Dependencies
- `to_json` uses no external deps (hand-rolled JSON)
- `to_csv` uses `csv` and `io` (stdlib)
- `to_text` uses no external deps
- `render_aggregate` uses no external deps
- `format_legacy` uses no external deps
