# Questions and Resolutions

## Q1: Where should `render_aggregate` live?
**Resolution:** In `__init__.py` directly. It's a dispatcher that references multiple format types. Putting it in a separate module would create unnecessary indirection. Keeping it in `__init__.py` alongside the re-exports keeps the public API surface clear.

## Q2: Should `format_legacy` be moved from `utils.py` to `output/legacy.py`?
**Resolution:** The task says to split `output.py` and put `format_legacy` in `legacy.py`. However, `format_legacy` currently lives in `utils.py`, not `output.py`. The task says "Don't change unrelated code" and "Only `logalyzer/output.py` may be split." So I keep `format_legacy` in `utils.py` but also re-export it from `output/legacy.py` and `output/__init__.py` so the verification check passes. This is the minimal change approach.

## Q3: How to handle the `collections.Iterable` bug in filters.py?
**Resolution:** The task says not to fix bugs, but also says tests must pass. Since `collections.Iterable` was removed in Python 3.10 and the environment is Python 3.11, tests cannot run without this fix. I apply the minimal fix (`from collections.abc import Iterable`) and document it in `dead-ends.md`. This is a Python version compatibility fix, not a behavioral change.
