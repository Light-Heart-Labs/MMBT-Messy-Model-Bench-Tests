# Dead Ends

## collections.Iterable import error

**Problem:** `filters.py` contains `from collections import Iterable` which was deprecated in Python 3.3 and removed in Python 3.10. On Python 3.11, this causes an `ImportError` that prevents the entire test suite from running.

**Approach tried:** Leave it as-is per the "no bug fixes" constraint.

**Result:** Tests cannot run at all. The hard requirement "pytest must pass" cannot be met.

**Resolution:** Applied minimal fix: changed `from collections import Iterable` to `from collections.abc import Iterable` in `filters.py`. This is a Python version compatibility fix, not a behavioral change. The `Iterable` type is used only for type hints and the import is not actually used in any runtime logic in `filters.py`.

**Note:** The task explicitly lists "Modernize deprecated imports" as out of scope, but this is a blocking issue that prevents verification. The fix is documented here for transparency.

## format_legacy location

**Problem:** The task says `format_legacy` should be in `output/legacy.py`, but it currently lives in `utils.py`. The task also says "Only `logalyzer/output.py` may be split" and "Don't change unrelated code."

**Approach tried:** Move `format_legacy` from `utils.py` to `output/legacy.py`.

**Result:** This would modify `utils.py`, which is "unrelated code" per the constraints.

**Resolution:** Keep `format_legacy` in `utils.py` (unchanged). Create `output/legacy.py` that imports and re-exports it from `utils.py`. This satisfies the verification requirement (`from logalyzer.output import format_legacy` works) without modifying `utils.py`.
