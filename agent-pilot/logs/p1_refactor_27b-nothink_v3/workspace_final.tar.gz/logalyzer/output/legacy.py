"""Legacy output formatters for backward compatibility."""
from __future__ import annotations

# Re-export format_legacy from utils for backward compatibility.
# The original function lives in utils.py; this module provides it
# under the output package namespace for callers that expect it here.
from ..utils import format_legacy

__all__ = ["format_legacy"]
