# ADR-006: Slide Structure

**Date:** 2025-06-18
**Status:** Accepted

## Context
Need to establish slide structure that is clear, professional, and easy to understand for a technical board.

## Alternatives Considered

### Alternative 1: Title-Body-Bullet Structure
- Title slide
- Body with bullet points
- **Pros:** Familiar, easy to create
- **Cons:** Text-heavy, not visual

### Alternative 2: Title-Visual-Insight Structure
- Title slide
- Visual (chart, diagram)
- Insight (one sentence)
- **Pros:** Visual, data-focused
- **Cons:** May be too minimal for some audiences

### Alternative 3: Problem-Solution-Result Structure
- Problem slide
- Solution slide
- Result slide
- **Pros:** Narrative, clear
- **Cons:** Too narrative for board presentation

### Alternative 4: Question-Answer Structure
- Question slide
- Answer slide
- **Pros:** Direct, clear
- **Cons:** Too fragmented

## Decision
**Selected: Title-Visual-Insight structure with optional supporting visual**

## Rationale
1. **Title slide:** Clear, concise title
2. **Visual (chart, diagram):** Data-focused, easy to understand
3. **Insight (one sentence):** Clear takeaway
4. **Optional supporting visual:** Additional context if needed

## Implementation
- Title: Clear, concise, one sentence
- Visual: Chart or diagram (no text-heavy tables)
- Insight: One sentence takeaway
- Supporting visual: Additional chart or diagram if needed

## Limitations
- May be too minimal for some audiences
- No text-heavy tables

## Alternatives Considered but Rejected
- **Alternative 1 (Title-Body-Bullet):** Text-heavy, not visual
- **Alternative 3 (Problem-Solution-Result):** Too narrative
- **Alternative 4 (Question-Answer):** Too fragmented

## Lessons
- Visuals are more effective than text
- One-sentence insight is clear and concise
- No text-heavy tables
- No bullet points (use visuals instead)
