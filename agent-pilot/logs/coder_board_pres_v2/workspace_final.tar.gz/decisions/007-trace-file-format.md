# ADR-007: Trace File Format

**Date:** 2025-06-18
**Status:** Accepted

## Context
Need to establish a trace file format that allows board members to verify any claim by tracing it back to the source data.

## Alternatives Considered

### Alternative 1: Simple URL Format
- File: `/audit/traces/GTLB_revenue_2026.txt`
- Content: `https://github.com/input/repo/blob/main/extracted/income_statement_annual.csv#L1`
- **Pros:** Simple, easy to create
- **Cons:** No context, no explanation

### Alternative 2: Markdown Format
- File: `/audit/traces/GTLB_revenue_2026.md`
- Content: `GitLab revenue FY2026: $955M. Source: /extracted/income_statement_annual.csv, line 1.`
- **Pros:** Simple, includes context
- **Cons:** No structured data

### Alternative 3: JSON Format
- File: `/audit/traces/GTLB_revenue_2026.json`
- Content: `{"claim": "GitLab revenue FY2026: $955M", "source": "/extracted/income_statement_annual.csv", "line": 1, "column": "2026-01-31"}`
- **Pros:** Structured, machine-readable
- **Cons:** Less human-readable

### Alternative 4: YAML Format
- File: `/audit/traces/GTLB_revenue_2026.yaml`
- Content: `claim: "GitLab revenue FY2026: $955M" source: /extracted/income_statement_annual.csv line: 1 column: 2026-01-31`
- **Pros:** Human-readable, structured
- **Cons:** Less common than JSON

## Decision
**Selected: Markdown format with structured metadata**

## Rationale
1. **Markdown format:** Human-readable, easy to edit
2. **Structured metadata:** YAML front matter for machine-readable data
3. **Clear claim:** One sentence claim
4. **Source path:** Full path to source file
5. **Line/column:** Specific location in source file
6. **Context:** Surrounding text if applicable

## Implementation
- File: `/audit/traces/GTLB_revenue_2026.md`
- Content:
  ```markdown
  ---
  claim: "GitLab revenue FY2026: $955M"
  source: "/extracted/income_statement_annual.csv"
  line: 1
  column: "2026-01-31"
  ---
  
  GitLab revenue FY2026: $955M. Source: /extracted/income_statement_annual.csv, line 1, column 2026-01-31.
  ```

## Limitations
- Manual creation required
- No automated verification

## Alternatives Considered but Rejected
- **Alternative 1 (Simple URL):** No context, no explanation
- **Alternative 2 (Markdown only):** No structured metadata
- **Alternative 3 (JSON):** Less human-readable
- **Alternative 4 (YAML):** Less common than Markdown

## Lessons
- Markdown format is human-readable
- Structured metadata is machine-readable
- Clear claim is one sentence
- Source path is full path to source file
- Line/column is specific location in source file
