# ADR-005: Chart Conventions

**Date:** 2025-06-18
**Status:** Accepted

## Context
Need to establish chart conventions that are data-focused, professional, and easy to understand for a technical board.

## Alternatives Considered

### Alternative 1: Excel Default Charts
- Use Excel's default chart styles
- **Pros:** Familiar, easy to create
- **Cons:** Outdated, chartjunk, not data-focused

### Alternative 2: Minimalist Charts
- No gridlines, no borders, no chartjunk
- Clean, data-focused
- **Pros:** Professional, data-focused
- **Cons:** May be too minimal for some audiences

### Alternative 3: Financial Times Style
- Clean lines, muted colors, data-focused
- **Pros:** Professional, data-focused
- **Cons:** May be too minimal for some audiences

### Alternative 4: McKinsey Style
- Bold colors, clear labels, data-focused
- **Pros:** Clear, easy to understand
- **Cons:** May appear too "consultant-y"

## Decision
**Selected: Minimalist charts with GitLab blue as primary color**

## Rationale
1. **No gridlines:** Clean, data-focused, no distraction
2. **No borders:** Clean, data-focused, no distraction
3. **No chartjunk:** Clean, data-focused, no distraction
4. **GitLab blue as primary:** Brand consistency, professional
5. **Red/green for scenarios:** Clear visual distinction
6. **Clear labels:** Easy to understand
7. **Data labels on key points:** No need to interpret values

## Implementation
- Line charts: Clean lines, no markers, GitLab blue
- Bar charts: Clean bars, GitLab blue, no borders
- Scatter plots: Clean dots, GitLab blue, no borders
- Area charts: Clean areas, GitLab blue, no borders
- Scenario charts: Red (bear), GitLab blue (base), green (bull)

## Limitations
- May be too minimal for some audiences
- No visual variety may be boring

## Alternatives Considered but Rejected
- **Alternative 1 (Excel default):** Chartjunk, outdated
- **Alternative 3 (Financial Times):** Too minimal, no GitLab branding
- **Alternative 4 (McKinsey):** Too "consultant-y"

## Lessons
- Minimalist charts are data-focused
- GitLab blue provides brand consistency
- Red/green provides clear visual distinction
- No gridlines/borders/chartjunk keeps focus on data
