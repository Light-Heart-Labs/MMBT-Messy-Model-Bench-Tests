# ADR-004: Color Scheme

**Date:** 2025-06-18
**Status:** Accepted

## Context
Need to choose a color scheme that reinforces data, not distracts. Board is technical and skeptical - colors should be professional and data-focused.

## Alternatives Considered

### Alternative 1: GitLab Brand Colors
- Primary: GitLab blue (#615192)
- Secondary: GitLab orange (#FCA121)
- Accent: GitLab purple (#5D54AA)
- **Pros:** Brand consistency, recognizable
- **Cons:** May appear biased, not data-focused

### Alternative 2: Neutral Grayscale
- Primary: Black (#000000)
- Secondary: Gray (#666666)
- Accent: White (#FFFFFF)
- **Pros:** Professional, data-focused
- **Cons:** Boring, no visual distinction

### Alternative 3: Red/Green for Up/Down
- Up: Green (#27AE60)
- Down: Red (#E74C3C)
- Neutral: Blue (#3498DB)
- **Pros:** Intuitive, clear distinction
- **Cons:** Red/green colorblind issue

### Alternative 4: Sequential Colormap
- Low: Light blue (#A0C4FF)
- Medium: Medium blue (#4B69D6)
- High: Dark blue (#2F3E58)
- **Pros:** Data-focused, no bias
- **Cons:** Less visually distinct

## Decision
**Selected: GitLab blue (#615192) as primary, with red/green for scenarios**

## Rationale
1. **GitLab blue as primary:** Brand consistency without appearing biased. Blue is professional and trustworthy.
2. **Red for downside scenarios:** Clear visual distinction for bear case. Red is universally recognized as "danger" or "downside."
3. **Green for upside scenarios:** Clear visual distinction for bull case. Green is universally recognized as "good" or "upside."
4. **Neutral gray for background:** Professional, data-focused, no distraction.
5. **White for text:** High contrast, readable.

## Implementation
- Slide backgrounds: Light gray (#F5F5F5)
- Primary text: Dark gray (#333333)
- GitLab references: GitLab blue (#615192)
- Upside scenarios: Green (#27AE60)
- Downside scenarios: Red (#E74C3C)
- Neutral elements: Blue (#3498DB)

## Limitations
- Red/green may be challenging for colorblind viewers
- GitLab blue may appear biased (though we use it sparingly)

## Alternatives Considered but Rejected
- **Alternative 1 (GitLab brand):** Too brand-focused, may appear biased
- **Alternative 2 (Neutral grayscale):** Too boring, no visual distinction
- **Alternative 3 (Red/green only):** No primary color for GitLab references
- **Alternative 4 (Sequential colormap):** Too subtle, no clear distinction

## Lessons
- Color should reinforce data, not distract
- Red/green for up/down is intuitive but has colorblind issues
- Primary brand color can be used sparingly for consistency
- Neutral backgrounds keep focus on data
