#!/usr/bin/env python3
"""Generate trace files for key numbers in the deck."""

import os

# Create traces directory if it doesn't exist
os.makedirs('/workspace/audit/traces', exist_ok=True)

# Define trace files
traces = [
    {
        'filename': 'GTLB_revenue_2026.md',
        'content': '''---
claim: "GitLab revenue FY2026: $955M"
source: "/input/repo/extracted/income_statement_annual.csv"
line: 1
column: "2026-01-31"
---
GitLab revenue FY2026: $955M. Source: /input/repo/extracted/income_statement_annual.csv, line 1, column 2026-01-31.
'''
    },
    {
        'filename': 'GTLB_operating_margin_2026.md',
        'content': '''---
claim: "GitLab operating margin FY2026: -7.4%"
source: "/input/repo/extracted/income_statement_annual.csv"
line: 1
column: "2026-01-31"
---
GitLab operating margin FY2026: -7.4%. Calculated from Operating Income (-$70M) / Total Revenue ($955M). Source: /input/repo/extracted/income_statement_annual.csv, line 1, column 2026-01-31.
'''
    },
    {
        'filename': 'GTLB_fcf_2026.md',
        'content': '''---
claim: "GitLab free cash flow FY2026: $222M"
source: "/input/repo/extracted/cash_flow_annual.csv"
line: 1
column: "2026-01-31"
---
GitLab free cash flow FY2026: $222M. Source: /input/repo/extracted/cash_flow_annual.csv, line 1, column 2026-01-31.
'''
    },
    {
        'filename': 'GTLB_arr_2026.md',
        'content': '''---
claim: "GitLab ARR FY2026: $860M"
source: "/input/repo/extracted/financial_summary.json"
field: "arr[4]"
---
GitLab ARR FY2026: $860M. Management metric from earnings call transcripts. Source: /input/repo/extracted/financial_summary.json, arr[4].
'''
    },
    {
        'filename': 'GTLB_cash_2026.md',
        'content': '''---
claim: "GitLab cash & investments FY2026: $1.26B"
source: "/input/repo/extracted/balance_sheet_annual.csv"
line: 1
column: "2026-01-31"
---
GitLab cash & investments FY2026: $1.26B. Sum of Cash and Cash Equivalents ($230M) + Other Short Term Investments ($1.03B). Source: /input/repo/extracted/balance_sheet_annual.csv, line 1, column 2026-01-31.
'''
    },
    {
        'filename': 'GTLB_nrr_2026.md',
        'content': '''---
claim: "GitLab NRR FY2026: 115%"
source: "/input/repo/extracted/financial_summary.json"
field: "nrr[4]"
---
GitLab NRR FY2026: 115%. Management metric from earnings call transcripts. Source: /input/repo/extracted/financial_summary.json, nrr[4].
'''
    },
    {
        'filename': 'GTLB_ev_revenue_2026.md',
        'content': '''---
claim: "GitLab EV/Revenue FY2026: 2.56x"
source: "/input/repo/extracted/competitor_data.json"
field: "ev_revenue"
---
GitLab EV/Revenue FY2026: 2.56x. Enterprise Value ($2.44B) / Total Revenue ($955M). Source: /input/repo/extracted/competitor_data.json, ev_revenue field.
'''
    },
    {
        'filename': 'DCF_assumptions.md',
        'content': '''---
claim: "DCF assumptions: WACC 10.5%, Terminal growth 3.0%"
source: "/input/repo/decisions/003-valuation-methodology.md"
---
DCF assumptions: WACC 10.5%, Terminal growth 3.0%. Risk-free rate 4.5% (10Y Treasury), Beta 1.2 (SaaS sector), Equity risk premium 5.5%. Source: /input/repo/decisions/003-valuation-methodology.md.
'''
    },
    {
        'filename': 'DCF_base_case.md',
        'content': '''---
claim: "DCF base case: $38.52/share"
source: "/input/repo/model/gitlab_three_statement_model.xlsx"
sheet: "Valuation"
---
DCF base case: $38.52/share. Based on FCF projections, WACC 10.5%, terminal growth 3.0%. Source: /input/repo/model/gitlab_three_statement_model.xlsx, Valuation sheet.
'''
    },
    {
        'filename': 'probability_weighted_target.md',
        'content': '''---
claim: "Probability-weighted target: $45.98/share"
source: "/input/repo/model/gitlab_three_statement_model.xlsx"
sheet: "Scenarios"
---
Probability-weighted target: $45.98/share. 25% bear ($18.58) + 50% base ($38.52) + 25% bull ($88.30). Source: /input/repo/model/gitlab_three_statement_model.xlsx, Scenarios sheet.
'''
    },
]

# Write trace files
for trace in traces:
    filepath = f"/workspace/audit/traces/{trace['filename']}"
    with open(filepath, 'w') as f:
        f.write(trace['content'])
    print(f"Created: {filepath}")

print(f"\nTotal trace files created: {len(traces)}")
