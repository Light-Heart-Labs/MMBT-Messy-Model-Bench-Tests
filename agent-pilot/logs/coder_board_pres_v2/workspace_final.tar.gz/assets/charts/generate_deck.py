#!/usr/bin/env python3
"""Generate the board presentation PowerPoint file."""

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend

# Create presentation
prs = Presentation()
prs.slide_width = Inches(10)
prs.slide_height = Inches(7.5)

# Color scheme
GITLAB_BLUE = RGBColor(97, 81, 146)  # #615192
RED = RGBColor(231, 76, 60)  # #E74C3C
GREEN = RGBColor(39, 174, 96)  # #27AE60
BLUE = RGBColor(52, 152, 219)  # #3498DB
GRAY = RGBColor(245, 245, 245)  # #F5F5F5
DARK_GRAY = RGBColor(51, 51, 51)  # #333333

def add_title_slide(prs, title, subtitle):
    """Add a title slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.add_textbox(Inches(1), Inches(2.5), Inches(8), Inches(1))
    title_frame = title_box.text_frame
    title_frame.text = title
    title_para = title_frame.paragraphs[0]
    title_para.font.size = Pt(48)
    title_para.font.bold = True
    title_para.font.color.rgb = GITLAB_BLUE
    title_para.alignment = PP_ALIGN.CENTER
    
    # Subtitle
    subtitle_box = slide.shapes.add_textbox(Inches(1), Inches(3.5), Inches(8), Inches(0.5))
    subtitle_frame = subtitle_box.text_frame
    subtitle_frame.text = subtitle
    subtitle_para = subtitle_frame.paragraphs[0]
    subtitle_para.font.size = Pt(24)
    subtitle_para.font.color.rgb = DARK_GRAY
    subtitle_para.alignment = PP_ALIGN.CENTER

def add_recommendation_slide(prs):
    """Add recommendation slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Recommendation"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Recommendation badge
    badge_box = slide.shapes.add_textbox(Inches(2), Inches(2), Inches(6), Inches(1.5))
    badge_frame = badge_box.text_frame
    badge_frame.text = "BUY"
    badge_para = badge_frame.paragraphs[0]
    badge_para.font.size = Pt(72)
    badge_para.font.bold = True
    badge_para.font.color.rgb = GREEN
    badge_para.alignment = PP_ALIGN.CENTER
    
    # Price target
    target_box = slide.shapes.add_textbox(Inches(2), Inches(3.5), Inches(6), Inches(0.5))
    target_frame = target_box.text_frame
    target_frame.text = "$42.00 Price Target (95% upside)"
    target_para = target_frame.paragraphs[0]
    target_para.font.size = Pt(28)
    target_para.font.color.rgb = DARK_GRAY
    target_para.alignment = PP_ALIGN.CENTER
    
    # Current price
    current_box = slide.shapes.add_textbox(Inches(2), Inches(4.2), Inches(6), Inches(0.5))
    current_frame = current_box.text_frame
    current_frame.text = "Current Price: $21.51"
    current_para = current_frame.paragraphs[0]
    current_para.font.size = Pt(24)
    current_para.font.color.rgb = DARK_GRAY
    current_para.alignment = PP_ALIGN.CENTER
    
    # Probability-weighted target
    pw_box = slide.shapes.add_textbox(Inches(2), Inches(4.9), Inches(6), Inches(0.5))
    pw_frame = pw_box.text_frame
    pw_frame.text = "Probability-Weighted Target: $45.98 (114% upside)"
    pw_para = pw_frame.paragraphs[0]
    pw_para.font.size = Pt(20)
    pw_para.font.color.rgb = DARK_GRAY
    pw_para.alignment = PP_ALIGN.CENTER

def add_executive_summary_slide(prs):
    """Add executive summary slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Executive Summary"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Summary points
    points = [
        "Strong growth: 30% CAGR revenue (FY2023-FY2026)",
        "Improving margins: -49.8% → -7.4% operating margin",
        "Strong SaaS metrics: 115% NRR, $860M ARR",
        "Healthy balance sheet: $1.26B cash, negligible debt",
        "Path to profitability: GAAP operating income by FY2028"
    ]
    
    y_pos = Inches(1.5)
    for point in points:
        point_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(8), Inches(0.5))
        point_frame = point_box.text_frame
        point_frame.text = point
        point_para = point_frame.paragraphs[0]
        point_para.font.size = Pt(20)
        point_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.2)

def add_investment_thesis_slide(prs):
    """Add investment thesis slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Investment Thesis"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Thesis points
    points = [
        "1. Large and growing TAM ($30B+ DevOps market)",
        "2. Proven growth engine (30% CAGR, 115% NRR)",
        "3. Clear path to profitability (margins improving 13pp annually)",
        "4. Strong balance sheet ($1.26B cash)",
        "5. What the market is missing (AI monetization, operating leverage, ARR quality)"
    ]
    
    y_pos = Inches(1.5)
    for point in points:
        point_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(8), Inches(0.5))
        point_frame = point_box.text_frame
        point_frame.text = point
        point_para = point_frame.paragraphs[0]
        point_para.font.size = Pt(20)
        point_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.2)

def add_financial_trajectory_slide(prs):
    """Add financial trajectory slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Financial Trajectory"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Historical data
    historical = [
        ("FY2023", "$424M", "-49.8%"),
        ("FY2024", "$580M", "-32.3%"),
        ("FY2025", "$759M", "-18.8%"),
        ("FY2026", "$955M", "-7.4%")
    ]
    
    y_pos = Inches(1.5)
    for year, revenue, margin in historical:
        row_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(8), Inches(0.5))
        row_frame = row_box.text_frame
        row_frame.text = f"{year} | Revenue: {revenue} | Operating Margin: {margin}"
        row_para = row_frame.paragraphs[0]
        row_para.font.size = Pt(18)
        row_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.0)

def add_competitive_landscape_slide(prs):
    """Add competitive landscape slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Competitive Landscape"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Competitor table
    competitors = [
        ("GitLab", "GTLB", "$3.66B", "2.56x", "Full-stack, open-core"),
        ("Atlassian", "TEAM", "$18.87B", "3.22x", "Collaboration focus"),
        ("Datadog", "DDOG", "$45.82B", "12.39x", "Observability leader"),
        ("MongoDB", "MDB", "$20.38B", "7.33x", "Database platform"),
        ("Confluent", "CFLT", "$11.13B", "8.69x", "Data streaming"),
        ("Snowflake", "SNOW", "$48.51B", "10.07x", "Data warehouse"),
        ("Zscaler", "ZS", "$21.79B", "6.71x", "Cloud security"),
        ("Okta", "OKTA", "$13.44B", "3.88x", "Identity management"),
        ("Bill.com", "BILL", "$3.68B", "2.14x", "Financial workflows")
    ]
    
    y_pos = Inches(1.5)
    for name, ticker, mkt_cap, ev_rev, diff in competitors:
        row_box = slide.shapes.add_textbox(Inches(0.5), y_pos, Inches(9), Inches(0.4))
        row_frame = row_box.text_frame
        row_frame.text = f"{name} ({ticker}) | Mkt Cap: {mkt_cap} | EV/Rev: {ev_rev} | {diff}"
        row_para = row_frame.paragraphs[0]
        row_para.font.size = Pt(14)
        row_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.0)

def add_mispricing_thesis_slide(prs):
    """Add mispricing thesis slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Mispricing Thesis"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Mispricing points
    points = [
        "1. AI Monetization: GitLab's AI features embedded in workflow, not standalone tools",
        "2. ARR Quality: $860M ARR with 115% NRR = $990M next-year revenue",
        "3. Operating Leverage: Margins expand as revenue scales (fixed R&D, platform costs)"
    ]
    
    y_pos = Inches(1.5)
    for point in points:
        point_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(8), Inches(0.5))
        point_frame = point_box.text_frame
        point_frame.text = point
        point_para = point_frame.paragraphs[0]
        point_para.font.size = Pt(20)
        point_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.2)

def add_risk_assessment_slide(prs):
    """Add risk assessment slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Risk Assessment"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Risk matrix
    risks = [
        ("High Probability / High Impact", ""),
        ("• NRR decline (120% → 115%)", "If NRR < 110%, growth slows significantly"),
        ("• GitHub competition", "Copilot and expanding DevOps features"),
        ("Medium Probability / High Impact", ""),
        ("• Macro downturn", "Enterprise software spending cuts"),
        ("• AI monetization failure", "AI features don't drive meaningful upsells"),
        ("Low Probability / High Impact", ""),
        ("• Open-source cannibalization", "Self-hosted users prefer free version"),
        ("• Key person risk", "CEO Sid Sijbrandij is co-founder and visionary")
    ]
    
    y_pos = Inches(1.5)
    for risk, mitigation in risks:
        row_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(8), Inches(0.4))
        row_frame = row_box.text_frame
        row_frame.text = risk
        row_para = row_frame.paragraphs[0]
        row_para.font.size = Pt(16)
        row_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(1.9)

def add_scenarios_slide(prs):
    """Add scenarios slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Bear/Base/Bull Scenarios"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Scenario table
    scenarios = [
        ("Bear", "25%", "$18.58", "-14%", "12% growth, 12% WACC, 2% terminal"),
        ("Base", "50%", "$38.52", "79%", "20% growth, 10.5% WACC, 3% terminal"),
        ("Bull", "25%", "$88.30", "310%", "28% growth, 9% WACC, 4% terminal"),
        ("Probability-Weighted", "100%", "$45.98", "114%", "Weighted average")
    ]
    
    y_pos = Inches(1.5)
    for scenario, prob, price, upside, assumptions in scenarios:
        row_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(8), Inches(0.5))
        row_frame = row_box.text_frame
        row_frame.text = f"{scenario} | Prob: {prob} | Price: {price} | Upside: {upside} | {assumptions}"
        row_para = row_frame.paragraphs[0]
        row_para.font.size = Pt(16)
        row_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.1)

def add_reasoning_trail_slide(prs):
    """Add reasoning trail slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Reasoning Trail"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Reasoning flow
    flow = [
        "1. Filings Read: 10-K, 10-Q, earnings transcripts (Q4 2023 - Q1 2025)",
        "2. Analysis Performed: DCF, EV/Revenue multiples, SaaS metrics",
        "3. Decisions Made: Company selection, competitor selection, valuation methodology",
        "4. Conclusions Drawn: Undervaluation, path to profitability, AI potential"
    ]
    
    y_pos = Inches(1.5)
    for step in flow:
        step_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(8), Inches(0.5))
        step_frame = step_box.text_frame
        step_frame.text = step
        step_para = step_frame.paragraphs[0]
        step_para.font.size = Pt(20)
        step_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.2)

def add_dead_ends_slide(prs):
    """Add dead ends slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Dead Ends"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Dead ends
    dead_ends = [
        "1. SEC filing downloads blocked (403 errors) → used yfinance instead",
        "2. GitLab IR website DNS failed → used third-party transcripts",
        "3. PRNewswire search 404 → used earnings call transcripts",
        "4. Initial CIK lookup wrong (Harper James P) → corrected to 0001653482",
        "5. Earnings call audio not accessible → relied on text transcripts"
    ]
    
    y_pos = Inches(1.5)
    for dead_end in dead_ends:
        dead_end_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(8), Inches(0.5))
        dead_end_frame = dead_end_box.text_frame
        dead_end_frame.text = dead_end
        dead_end_para = dead_end_frame.paragraphs[0]
        dead_end_para.font.size = Pt(20)
        dead_end_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.2)

def add_confidence_assessment_slide(prs):
    """Add confidence assessment slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Confidence Assessment"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Confidence columns
    confident = [
        "Revenue trajectory",
        "Gross margins",
        "Balance sheet",
        "SaaS model quality"
    ]
    
    estimating = [
        "ARR and NRR (management metrics)",
        "AI monetization (forward-looking)",
        "Competitive dynamics (unpredictable)"
    ]
    
    y_pos = Inches(1.5)
    confident_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(3.5), Inches(3))
    confident_frame = confident_box.text_frame
    confident_frame.text = "CONFIDENT ABOUT"
    confident_para = confident_frame.paragraphs[0]
    confident_para.font.size = Pt(20)
    confident_para.font.bold = True
    confident_para.font.color.rgb = GREEN
    
    y_pos = Inches(2.2)
    for item in confident:
        item_box = slide.shapes.add_textbox(Inches(1.2), y_pos, Inches(3.3), Inches(0.4))
        item_frame = item_box.text_frame
        item_frame.text = f"• {item}"
        item_para = item_frame.paragraphs[0]
        item_para.font.size = Pt(16)
        item_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.7)
    
    y_pos = Inches(1.5)
    estimating_box = slide.shapes.add_textbox(Inches(5.5), y_pos, Inches(3.5), Inches(3))
    estimating_frame = estimating_box.text_frame
    estimating_frame.text = "ESTIMATING"
    estimating_para = estimating_frame.paragraphs[0]
    estimating_para.font.size = Pt(20)
    estimating_para.font.bold = True
    estimating_para.font.color.rgb = BLUE
    
    y_pos = Inches(2.2)
    for item in estimating:
        item_box = slide.shapes.add_textbox(Inches(5.7), y_pos, Inches(3.3), Inches(0.4))
        item_frame = item_box.text_frame
        item_frame.text = f"• {item}"
        item_para = item_frame.paragraphs[0]
        item_para.font.size = Pt(16)
        item_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.7)

def add_audit_trail_slide(prs):
    """Add audit trail slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "How to Audit This Deck"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Audit steps
    steps = [
        "1. Clone this repository",
        "2. Pick any claim from the presentation",
        "3. Find the trace file in /audit/traces/",
        "4. Follow the source path in the trace file",
        "5. Verify the source in /input/repo/"
    ]
    
    y_pos = Inches(1.5)
    for step in steps:
        step_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(8), Inches(0.5))
        step_frame = step_box.text_frame
        step_frame.text = step
        step_para = step_frame.paragraphs[0]
        step_para.font.size = Pt(20)
        step_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.2)
    
    # Example
    example_box = slide.shapes.add_textbox(Inches(1), Inches(5), Inches(8), Inches(1))
    example_frame = example_box.text_frame
    example_frame.text = "Example: Claim: 'Revenue FY2026: $955M' → Trace: /audit/traces/GTLB_revenue_2026.md → Source: /input/repo/extracted/income_statement_annual.csv"
    example_para = example_frame.paragraphs[0]
    example_para.font.size = Pt(16)
    example_para.font.color.rgb = DARK_GRAY

def add_catalysts_slide(prs):
    """Add catalysts slide."""
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    
    # Background
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = GRAY
    
    # Title
    title_box = slide.shapes.title
    title_box.text = "Key Catalysts & Position Sizing"
    title_para = title_box.text_frame.paragraphs[0]
    title_para.font.size = Pt(36)
    title_para.font.color.rgb = GITLAB_BLUE
    
    # Catalysts
    catalysts = [
        "FY2027 Q1 earnings (June 2026): First quarter of new fiscal year with AI revenue contribution",
        "GAAP operating profitability announcement: Expected FY2028",
        "AI feature expansion: New AI capabilities driving upsell",
        "Potential M&A: Strong balance sheet enables strategic acquisitions"
    ]
    
    y_pos = Inches(1.5)
    for catalyst in catalysts:
        catalyst_box = slide.shapes.add_textbox(Inches(1), y_pos, Inches(8), Inches(0.5))
        catalyst_frame = catalyst_box.text_frame
        catalyst_frame.text = catalyst
        catalyst_para = catalyst_frame.paragraphs[0]
        catalyst_para.font.size = Pt(18)
        catalyst_para.font.color.rgb = DARK_GRAY
        y_pos = Inches(2.1)
    
    # Position sizing
    sizing_box = slide.shapes.add_textbox(Inches(1), Inches(5), Inches(8), Inches(0.5))
    sizing_frame = sizing_box.text_frame
    sizing_frame.text = "Position sizing: 2-3% of portfolio, 12-month holding period"
    sizing_para = sizing_frame.paragraphs[0]
    sizing_para.font.size = Pt(20)
    sizing_para.font.color.rgb = DARK_GRAY

# Add all slides
add_title_slide(prs, "GitLab Inc. (GTLB)", "Board of Advisors Presentation | June 18, 2025")
add_recommendation_slide(prs)
add_executive_summary_slide(prs)
add_investment_thesis_slide(prs)
add_financial_trajectory_slide(prs)
add_competitive_landscape_slide(prs)
add_mispricing_thesis_slide(prs)
add_risk_assessment_slide(prs)
add_scenarios_slide(prs)
add_reasoning_trail_slide(prs)
add_dead_ends_slide(prs)
add_confidence_assessment_slide(prs)
add_audit_trail_slide(prs)
add_catalysts_slide(prs)

# Save presentation
prs.save('/workspace/deck/presentation.pptx')
print("Presentation saved to /workspace/deck/presentation.pptx")
