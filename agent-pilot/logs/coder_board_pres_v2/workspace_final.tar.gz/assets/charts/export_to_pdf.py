#!/usr/bin/env python3
"""Export the board presentation to PDF."""

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.colors import Color

# Color scheme
GITLAB_BLUE = Color(97/255, 81/255, 146/255)
RED = Color(231/255, 76/60, 60/255)
GREEN = Color(39/255, 174/255, 96/255)
BLUE = Color(52/255, 152/255, 219/255)
GRAY = Color(245/255, 245/255, 245/255)
DARK_GRAY = Color(51/255, 51/255, 51/255)

# Create PDF
c = canvas.Canvas("/workspace/deck/presentation.pdf", pagesize=letter)
width, height = letter

# Slide 1: Title
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 48)
c.drawCentredString(width/2, height - 2*inch, "GitLab Inc. (GTLB)")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 24)
c.drawCentredString(width/2, height - 3*inch, "Board of Advisors Presentation")
c.drawCentredString(width/2, height - 3.5*inch, "June 18, 2025")

# Slide 2: Recommendation
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Recommendation")
c.setFillColor(GREEN)
c.setFont("Helvetica-Bold", 72)
c.drawCentredString(width/2, height - 3*inch, "BUY")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 28)
c.drawCentredString(width/2, height - 4.5*inch, "$42.00 Price Target (95% upside)")
c.setFont("Helvetica", 24)
c.drawCentredString(width/2, height - 5.2*inch, "Current Price: $21.51")
c.setFont("Helvetica", 20)
c.drawCentredString(width/2, height - 5.9*inch, "Probability-Weighted Target: $45.98 (114% upside)")

# Slide 3: Executive Summary
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Executive Summary")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 20)
y_pos = height - 2*inch
points = [
    "Strong growth: 30% CAGR revenue (FY2023-FY2026)",
    "Improving margins: -49.8% → -7.4% operating margin",
    "Strong SaaS metrics: 115% NRR, $860M ARR",
    "Healthy balance sheet: $1.26B cash, negligible debt",
    "Path to profitability: GAAP operating income by FY2028"
]
for point in points:
    c.drawString(1*inch, y_pos, point)
    y_pos -= 0.5*inch

# Slide 4: Investment Thesis
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Investment Thesis")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 20)
y_pos = height - 2*inch
points = [
    "1. Large and growing TAM ($30B+ DevOps market)",
    "2. Proven growth engine (30% CAGR, 115% NRR)",
    "3. Clear path to profitability (margins improving 13pp annually)",
    "4. Strong balance sheet ($1.26B cash)",
    "5. What the market is missing (AI monetization, operating leverage, ARR quality)"
]
for point in points:
    c.drawString(1*inch, y_pos, point)
    y_pos -= 0.5*inch

# Slide 5: Financial Trajectory
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Financial Trajectory")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 18)
y_pos = height - 2*inch
historical = [
    "FY2023 | Revenue: $424M | Operating Margin: -49.8%",
    "FY2024 | Revenue: $580M | Operating Margin: -32.3%",
    "FY2025 | Revenue: $759M | Operating Margin: -18.8%",
    "FY2026 | Revenue: $955M | Operating Margin: -7.4%"
]
for row in historical:
    c.drawString(1*inch, y_pos, row)
    y_pos -= 0.5*inch

# Slide 6: Competitive Landscape
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Competitive Landscape")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 14)
y_pos = height - 2*inch
competitors = [
    "GitLab (GTLB) | Mkt Cap: $3.66B | EV/Rev: 2.56x | Full-stack, open-core",
    "Atlassian (TEAM) | Mkt Cap: $18.87B | EV/Rev: 3.22x | Collaboration focus",
    "Datadog (DDOG) | Mkt Cap: $45.82B | EV/Rev: 12.39x | Observability leader",
    "MongoDB (MDB) | Mkt Cap: $20.38B | EV/Rev: 7.33x | Database platform",
    "Confluent (CFLT) | Mkt Cap: $11.13B | EV/Rev: 8.69x | Data streaming",
    "Snowflake (SNOW) | Mkt Cap: $48.51B | EV/Rev: 10.07x | Data warehouse",
    "Zscaler (ZS) | Mkt Cap: $21.79B | EV/Rev: 6.71x | Cloud security",
    "Okta (OKTA) | Mkt Cap: $13.44B | EV/Rev: 3.88x | Identity management",
    "Bill.com (BILL) | Mkt Cap: $3.68B | EV/Rev: 2.14x | Financial workflows"
]
for comp in competitors:
    c.drawString(0.5*inch, y_pos, comp)
    y_pos -= 0.4*inch

# Slide 7: Mispricing Thesis
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Mispricing Thesis")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 20)
y_pos = height - 2*inch
points = [
    "1. AI Monetization: GitLab's AI features embedded in workflow, not standalone tools",
    "2. ARR Quality: $860M ARR with 115% NRR = $990M next-year revenue",
    "3. Operating Leverage: Margins expand as revenue scales (fixed R&D, platform costs)"
]
for point in points:
    c.drawString(1*inch, y_pos, point)
    y_pos -= 0.5*inch

# Slide 8: Risk Assessment
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Risk Assessment")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 16)
y_pos = height - 2*inch
risks = [
    "High Probability / High Impact:",
    "• NRR decline (120% → 115%) - If NRR < 110%, growth slows significantly",
    "• GitHub competition - Copilot and expanding DevOps features",
    "Medium Probability / High Impact:",
    "• Macro downturn - Enterprise software spending cuts",
    "• AI monetization failure - AI features don't drive meaningful upsells",
    "Low Probability / High Impact:",
    "• Open-source cannibalization - Self-hosted users prefer free version",
    "• Key person risk - CEO Sid Sijbrandij is co-founder and visionary"
]
for risk in risks:
    c.drawString(1*inch, y_pos, risk)
    y_pos -= 0.4*inch

# Slide 9: Bear/Base/Bull Scenarios
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Bear/Base/Bull Scenarios")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 16)
y_pos = height - 2*inch
scenarios = [
    "Bear | Prob: 25% | Price: $18.58 | Upside: -14% | 12% growth, 12% WACC, 2% terminal",
    "Base | Prob: 50% | Price: $38.52 | Upside: 79% | 20% growth, 10.5% WACC, 3% terminal",
    "Bull | Prob: 25% | Price: $88.30 | Upside: 310% | 28% growth, 9% WACC, 4% terminal",
    "Probability-Weighted | Prob: 100% | Price: $45.98 | Upside: 114% | Weighted average"
]
for scenario in scenarios:
    c.drawString(1*inch, y_pos, scenario)
    y_pos -= 0.5*inch

# Slide 10: Reasoning Trail
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Reasoning Trail")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 20)
y_pos = height - 2*inch
flow = [
    "1. Filings Read: 10-K, 10-Q, earnings transcripts (Q4 2023 - Q1 2025)",
    "2. Analysis Performed: DCF, EV/Revenue multiples, SaaS metrics",
    "3. Decisions Made: Company selection, competitor selection, valuation methodology",
    "4. Conclusions Drawn: Undervaluation, path to profitability, AI potential"
]
for step in flow:
    c.drawString(1*inch, y_pos, step)
    y_pos -= 0.5*inch

# Slide 11: Dead Ends
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Dead Ends")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 20)
y_pos = height - 2*inch
dead_ends = [
    "1. SEC filing downloads blocked (403 errors) → used yfinance instead",
    "2. GitLab IR website DNS failed → used third-party transcripts",
    "3. PRNewswire search 404 → used earnings call transcripts",
    "4. Initial CIK lookup wrong (Harper James P) → corrected to 0001653482",
    "5. Earnings call audio not accessible → relied on text transcripts"
]
for dead_end in dead_ends:
    c.drawString(1*inch, y_pos, dead_end)
    y_pos -= 0.5*inch

# Slide 12: Confidence Assessment
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Confidence Assessment")
c.setFillColor(GREEN)
c.setFont("Helvetica-Bold", 20)
c.drawString(1*inch, height - 2*inch, "CONFIDENT ABOUT")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 16)
y_pos = height - 2.7*inch
confident = [
    "• Revenue trajectory",
    "• Gross margins",
    "• Balance sheet",
    "• SaaS model quality"
]
for item in confident:
    c.drawString(1.2*inch, y_pos, item)
    y_pos -= 0.4*inch

c.setFillColor(BLUE)
c.setFont("Helvetica-Bold", 20)
c.drawString(5.5*inch, height - 2*inch, "ESTIMATING")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 16)
y_pos = height - 2.7*inch
estimating = [
    "• ARR and NRR (management metrics)",
    "• AI monetization (forward-looking)",
    "• Competitive dynamics (unpredictable)"
]
for item in estimating:
    c.drawString(5.7*inch, y_pos, item)
    y_pos -= 0.4*inch

# Slide 13: How to Audit This Deck
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "How to Audit This Deck")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 20)
y_pos = height - 2*inch
steps = [
    "1. Clone this repository",
    "2. Pick any claim from the presentation",
    "3. Find the trace file in /audit/traces/",
    "4. Follow the source path in the trace file",
    "5. Verify the source in /input/repo/"
]
for step in steps:
    c.drawString(1*inch, y_pos, step)
    y_pos -= 0.5*inch

c.setFont("Helvetica", 16)
c.drawString(1*inch, height - 5*inch, "Example: Claim: 'Revenue FY2026: $955M' → Trace: /audit/traces/GTLB_revenue_2026.md → Source: /input/repo/extracted/income_statement_annual.csv")

# Slide 14: Key Catalysts & Position Sizing
c.showPage()
c.setFillColor(GRAY)
c.rect(0, 0, width, height, fill=True, stroke=False)
c.setFillColor(GITLAB_BLUE)
c.setFont("Helvetica-Bold", 36)
c.drawCentredString(width/2, height - 1*inch, "Key Catalysts & Position Sizing")
c.setFillColor(DARK_GRAY)
c.setFont("Helvetica", 18)
y_pos = height - 2*inch
catalysts = [
    "FY2027 Q1 earnings (June 2026): First quarter of new fiscal year with AI revenue contribution",
    "GAAP operating profitability announcement: Expected FY2028",
    "AI feature expansion: New AI capabilities driving upsell",
    "Potential M&A: Strong balance sheet enables strategic acquisitions"
]
for catalyst in catalysts:
    c.drawString(1*inch, y_pos, catalyst)
    y_pos -= 0.5*inch

c.setFont("Helvetica", 20)
c.drawString(1*inch, height - 5*inch, "Position sizing: 2-3% of portfolio, 12-month holding period")

# Save PDF
c.save()
print("PDF saved to /workspace/deck/presentation.pdf")
