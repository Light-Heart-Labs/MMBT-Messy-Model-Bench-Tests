---
claim: "GitLab NRR FY2026: 115%"
source: "/input/repo/extracted/financial_summary.json"
field: "nrr[4]"
---
GitLab NRR FY2026: 115%. Management metric from earnings call transcripts. Source: /input/repo/extracted/financial_summary.json, nrr[4].
