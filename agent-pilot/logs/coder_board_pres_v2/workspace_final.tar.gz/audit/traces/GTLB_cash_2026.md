---
claim: "GitLab cash & investments FY2026: $1.26B"
source: "/input/repo/extracted/balance_sheet_annual.csv"
line: 1
column: "2026-01-31"
---
GitLab cash & investments FY2026: $1.26B. Sum of Cash and Cash Equivalents ($230M) + Other Short Term Investments ($1.03B). Source: /input/repo/extracted/balance_sheet_annual.csv, line 1, column 2026-01-31.
