---
claim: "GitLab revenue FY2026: $955M"
source: "/input/repo/extracted/income_statement_annual.csv"
line: 1
column: "2026-01-31"
---
GitLab revenue FY2026: $955M. Source: /input/repo/extracted/income_statement_annual.csv, line 1, column 2026-01-31.
