---
claim: "DCF assumptions: WACC 10.5%, Terminal growth 3.0%"
source: "/input/repo/decisions/003-valuation-methodology.md"
---
DCF assumptions: WACC 10.5%, Terminal growth 3.0%. Risk-free rate 4.5% (10Y Treasury), Beta 1.2 (SaaS sector), Equity risk premium 5.5%. Source: /input/repo/decisions/003-valuation-methodology.md.
