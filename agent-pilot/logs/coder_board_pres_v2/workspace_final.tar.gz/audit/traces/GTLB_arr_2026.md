---
claim: "GitLab ARR FY2026: $860M"
source: "/input/repo/extracted/financial_summary.json"
field: "arr[4]"
---
GitLab ARR FY2026: $860M. Management metric from earnings call transcripts. Source: /input/repo/extracted/financial_summary.json, arr[4].
