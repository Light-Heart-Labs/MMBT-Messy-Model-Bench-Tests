---
claim: "GitLab EV/Revenue FY2026: 2.56x"
source: "/input/repo/extracted/competitor_data.json"
field: "ev_revenue"
---
GitLab EV/Revenue FY2026: 2.56x. Enterprise Value ($2.44B) / Total Revenue ($955M). Source: /input/repo/extracted/competitor_data.json, ev_revenue field.
