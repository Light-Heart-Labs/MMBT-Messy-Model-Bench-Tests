---
claim: "DCF base case: $38.52/share"
source: "/input/repo/model/gitlab_three_statement_model.xlsx"
sheet: "Valuation"
---
DCF base case: $38.52/share. Based on FCF projections, WACC 10.5%, terminal growth 3.0%. Source: /input/repo/model/gitlab_three_statement_model.xlsx, Valuation sheet.
