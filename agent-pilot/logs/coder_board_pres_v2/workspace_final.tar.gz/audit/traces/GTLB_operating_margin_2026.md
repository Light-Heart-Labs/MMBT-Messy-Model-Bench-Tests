---
claim: "GitLab operating margin FY2026: -7.4%"
source: "/input/repo/extracted/income_statement_annual.csv"
line: 1
column: "2026-01-31"
---
GitLab operating margin FY2026: -7.4%. Calculated from Operating Income (-$70M) / Total Revenue ($955M). Source: /input/repo/extracted/income_statement_annual.csv, line 1, column 2026-01-31.
