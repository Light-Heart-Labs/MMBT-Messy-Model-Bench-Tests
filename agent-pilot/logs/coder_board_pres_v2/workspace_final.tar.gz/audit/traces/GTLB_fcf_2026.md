---
claim: "GitLab free cash flow FY2026: $222M"
source: "/input/repo/extracted/cash_flow_annual.csv"
line: 1
column: "2026-01-31"
---
GitLab free cash flow FY2026: $222M. Source: /input/repo/extracted/cash_flow_annual.csv, line 1, column 2026-01-31.
