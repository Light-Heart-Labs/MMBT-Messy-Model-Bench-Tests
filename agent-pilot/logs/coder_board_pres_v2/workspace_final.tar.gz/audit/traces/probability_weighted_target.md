---
claim: "Probability-weighted target: $45.98/share"
source: "/input/repo/model/gitlab_three_statement_model.xlsx"
sheet: "Scenarios"
---
Probability-weighted target: $45.98/share. 25% bear ($18.58) + 50% base ($38.52) + 25% bull ($88.30). Source: /input/repo/model/gitlab_three_statement_model.xlsx, Scenarios sheet.
