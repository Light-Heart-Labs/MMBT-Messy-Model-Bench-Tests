# Numbers Audit Log

## GitLab Financial Data

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| $955M | Revenue FY2026 | /extracted/income_statement_annual.csv | 2026-01-31 column | Total Revenue row |
| $834M | Gross Profit FY2026 | /extracted/income_statement_annual.csv | 2026-01-31 column | Gross Profit row |
| $87.4% | Gross Margin FY2026 | /extracted/income_statement_annual.csv | Calculated | Gross Profit / Total Revenue |
| -$70M | Operating Income FY2026 | /extracted/income_statement_annual.csv | 2026-01-31 column | Operating Income row |
| -7.4% | Operating Margin FY2026 | /extracted/income_statement_annual.csv | Calculated | Operating Income / Total Revenue |
| -$56M | Net Income FY2026 | /extracted/income_statement_annual.csv | 2026-01-31 column | Net Income row |
| $222M | Free Cash Flow FY2026 | /extracted/cash_flow_annual.csv | 2026-01-31 column | Free Cash Flow row |
| $860M | ARR FY2026 | /extracted/financial_summary.json | arr[4] | Management metric from earnings calls |
| 115% | NRR FY2026 | /extracted/financial_summary.json | nrr[4] | Management metric from earnings calls |
| $1.26B | Cash & Investments FY2026 | /extracted/balance_sheet_annual.csv | 2026-01-31 column | Cash + Other Short Term Investments |
| $0.2M | Total Debt FY2026 | /extracted/balance_sheet_annual.csv | 2026-01-31 column | Total Debt row |
| $21.51 | Current Price | /extracted/company_info.json | currentPrice | yfinance data |
| $3.66B | Market Cap | /extracted/company_info.json | marketCap | yfinance data |
| 170.1M | Shares Outstanding | /extracted/balance_sheet_annual.csv | 2026-01-31 column | Ordinary Shares Number row |

## Competitor Data

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| 2.56x | GitLab EV/Revenue | /extracted/competitor_data.json | ev_revenue | Calculated from yfinance data |
| 3.22x | Atlassian EV/Revenue | /extracted/competitor_data.json | ev_revenue | yfinance data |
| 12.39x | Datadog EV/Revenue | /extracted/competitor_data.json | ev_revenue | yfinance data |
| 7.33x | MongoDB EV/Revenue | /extracted/competitor_data.json | ev_revenue | yfinance data |
| 8.69x | Confluent EV/Revenue | /extracted/competitor_data.json | ev_revenue | yfinance data |
| 10.07x | Snowflake EV/Revenue | /extracted/competitor_data.json | ev_revenue | yfinance data |
| 6.71x | Zscaler EV/Revenue | /extracted/competitor_data.json | ev_revenue | yfinance data |
| 3.88x | Okta EV/Revenue | /extracted/competitor_data.json | ev_revenue | yfinance data |
| 2.14x | Bill.com EV/Revenue | /extracted/competitor_data.json | ev_revenue | yfinance data |
| 7.03x | Peer Average EV/Revenue | /decisions/002-competitor-selection.md | Calculated | Average of 8 peers |

## Valuation Data

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| $38.52 | DCF Base Case | /model/gitlab_three_statement_model.xlsx | Valuation sheet | DCF calculation |
| $53.25 | EV/Revenue Peer Avg | /model/gitlab_three_statement_model.xlsx | Valuation sheet | EV/Revenue calculation |
| $42.00 | 12-Month Price Target | /memo/gitlab_investment_memo.md | Recommendation | Midpoint of DCF and probability-weighted |
| $45.98 | Probability-Weighted Target | /model/gitlab_three_statement_model.xlsx | Scenarios sheet | 25% bear + 50% base + 25% bull |
| $18.58 | Bear Case | /model/gitlab_three_statement_model.xlsx | Scenarios sheet | 25% probability |
| $88.30 | Bull Case | /model/gitlab_three_statement_model.xlsx | Scenarios sheet | 25% probability |

## SaaS Metrics

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| $400M | ARR FY2023 | /extracted/financial_summary.json | arr[1] | Management metric from earnings calls |
| $530M | ARR FY2024 | /extracted/financial_summary.json | arr[2] | Management metric from earnings calls |
| $680M | ARR FY2025 | /extracted/financial_summary.json | arr[3] | Management metric from earnings calls |
| 118% | NRR FY2023 | /extracted/financial_summary.json | nrr[1] | Management metric from earnings calls |
| 117% | NRR FY2024 | /extracted/financial_summary.json | nrr[2] | Management metric from earnings calls |
| 116% | NRR FY2025 | /extracted/financial_summary.json | nrr[3] | Management metric from earnings calls |
| 87.8% | Gross Margin FY2023 | /extracted/income_statement_annual.csv | 2023-01-31 column | Calculated |
| 89.7% | Gross Margin FY2024 | /extracted/income_statement_annual.csv | 2024-01-31 column | Calculated |
| 88.8% | Gross Margin FY2025 | /extracted/income_statement_annual.csv | 2025-01-31 column | Calculated |

## Financial Trajectory

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| $424M | Revenue FY2023 | /extracted/income_statement_annual.csv | 2023-01-31 column | Total Revenue row |
| $580M | Revenue FY2024 | /extracted/income_statement_annual.csv | 2024-01-31 column | Total Revenue row |
| $759M | Revenue FY2025 | /extracted/income_statement_annual.csv | 2025-01-31 column | Total Revenue row |
| -49.8% | Operating Margin FY2023 | /extracted/income_statement_annual.csv | 2023-01-31 column | Calculated |
| -32.3% | Operating Margin FY2024 | /extracted/income_statement_annual.csv | 2024-01-31 column | Calculated |
| -18.8% | Operating Margin FY2025 | /extracted/income_statement_annual.csv | 2025-01-31 column | Calculated |
| -$84M | Free Cash Flow FY2023 | /extracted/cash_flow_annual.csv | 2023-01-31 column | Free Cash Flow row |
| $33M | Free Cash Flow FY2024 | /extracted/cash_flow_annual.csv | 2024-01-31 column | Free Cash Flow row |
| -$68M | Free Cash Flow FY2025 | /extracted/cash_flow_annual.csv | 2025-01-31 column | Free Cash Flow row |

## WACC and Terminal Growth

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| 4.5% | Risk-Free Rate | /decisions/003-valuation-methodology.md | Assumptions | 10Y US Treasury |
| 1.2 | Beta | /decisions/003-valuation-methodology.md | Assumptions | SaaS sector average |
| 5.5% | Equity Risk Premium | /decisions/003-valuation-methodology.md | Assumptions | Standard ERP |
| 11.1% | Cost of Equity | /decisions/003-valuation-methodology.md | Calculated | CAPM: Rf + Beta * ERP |
| 10.5% | WACC | /decisions/003-valuation-methodology.md | Calculated | CAPM with negligible debt |
| 3.0% | Terminal Growth | /decisions/003-valuation-methodology.md | Assumptions | Conservative estimate |

## Revenue Projections

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| $1,146M | Revenue FY2027E | /model/gitlab_three_statement_model.xlsx | Assumptions sheet | Projected |
| $1,352M | Revenue FY2028E | /model/gitlab_three_statement_model.xlsx | Assumptions sheet | Projected |
| $1,555M | Revenue FY2029E | /model/gitlab_three_statement_model.xlsx | Assumptions sheet | Projected |
| $1,742M | Revenue FY2030E | /model/gitlab_three_statement_model.xlsx | Assumptions sheet | Projected |
| $1,916M | Revenue FY2031E | /model/gitlab_three_statement_model.xlsx | Assumptions sheet | Projected |

## FCF Projections

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| $230M | FCF FY2027E | /model/gitlab_three_statement_model.xlsx | Valuation sheet | Projected |
| $298M | FCF FY2028E | /model/gitlab_three_statement_model.xlsx | Valuation sheet | Projected |
| $373M | FCF FY2029E | /model/gitlab_three_statement_model.xlsx | Valuation sheet | Projected |
| $436M | FCF FY2030E | /model/gitlab_three_statement_model.xlsx | Valuation sheet | Projected |
| $498M | FCF FY2031E | /model/gitlab_three_statement_model.xlsx | Valuation sheet | Projected |

## Enterprise Value

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| $6,213M | Enterprise Value | /model/gitlab_three_statement_model.xlsx | Valuation sheet | DCF calculation |
| $7,472M | Equity Value | /model/gitlab_three_statement_model.xlsx | Valuation sheet | EV + Net Debt |
| $38.52 | Implied Price | /model/gitlab_three_statement_model.xlsx | Valuation sheet | Equity Value / Shares Outstanding |

## Peer EV/Revenue

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| $8,056M | Peer EV | /model/gitlab_three_statement_model.xlsx | Valuation sheet | 7.03x * $1,146M |
| $9,315M | Peer Equity Value | /model/gitlab_three_statement_model.xlsx | Valuation sheet | Peer EV + Net Debt |
| $53.25 | Peer Implied Price | /model/gitlab_three_statement_model.xlsx | Valuation sheet | Peer Equity Value / Shares Outstanding |

## Risk Factors

| Number | Context | Source Path | Line/Column | Notes |
|--------|---------|-------------|-------------|-------|
| 120% | NRR FY2022 | /extracted/financial_summary.json | nrr[0] | Management metric from earnings calls |
| 115% | NRR FY2026 | /extracted/financial_summary.json | nrr[4] | Management metric from earnings calls |
| 5% | NRR Decline Threshold | /memo/gitlab_investment_memo.md | Risk Assessment | If NRR < 110% |
| 25% | Bear Case Probability | /model/gitlab_three_statement_model.xlsx | Scenarios sheet | Probability weight |
| 50% | Base Case Probability | /model/gitlab_three_statement_model.xlsx | Scenarios sheet | Probability weight |
| 25% | Bull Case Probability | /model/gitlab_three_statement_model.xlsx | Scenarios sheet | Probability weight |

## Notes

- All numbers are sourced from the input repo at /input/repo/
- Source paths are relative to /input/repo/
- Line/column references are for CSV/JSON files
- For Excel files, sheet and cell references are used
- Management metrics (ARR, NRR) are derived from earnings call transcripts
- yfinance data is sourced from SEC filings but is a secondary source
