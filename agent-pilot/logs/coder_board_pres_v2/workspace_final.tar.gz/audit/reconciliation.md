# Numbers Reconciliation Report

## Overview
This document provides a detailed reconciliation of 5 randomly selected numbers from the deck to their source data in the input repo.

## Reconciliation #1: GitLab Revenue FY2026 ($955M)

### Claim in Deck
- Slide 4: "Revenue FY2026: $955M"

### Source Data
- **File:** /input/repo/extracted/income_statement_annual.csv
- **Column:** 2026-01-31
- **Row:** Total Revenue
- **Value:** 955224000.0

### Calculation
- Raw value: 955,224,000
- Rounded to millions: $955M
- **Verification:** ✓ Match

### Trace File
- /audit/traces/GTLB_revenue_2026.md

---

## Reconciliation #2: Operating Margin FY2026 (-7.4%)

### Claim in Deck
- Slide 4: "Operating Margin FY2026: -7.4%"

### Source Data
- **File:** /input/repo/extracted/income_statement_annual.csv
- **Column:** 2026-01-31
- **Rows:** Operating Income, Total Revenue
- **Values:** -70481000.0, 955224000.0

### Calculation
- Operating Income: -70,481,000
- Total Revenue: 955,224,000
- Operating Margin: -70,481,000 / 955,224,000 = -0.0738 = -7.4%
- **Verification:** ✓ Match

### Trace File
- /audit/traces/GTLB_operating_margin_2026.md

---

## Reconciliation #3: Free Cash Flow FY2026 ($222M)

### Claim in Deck
- Slide 4: "Free Cash Flow FY2026: $222M"

### Source Data
- **File:** /input/repo/extracted/cash_flow_annual.csv
- **Column:** 2026-01-31
- **Row:** Free Cash Flow
- **Value:** 222029000.0

### Calculation
- Raw value: 222,029,000
- Rounded to millions: $222M
- **Verification:** ✓ Match

### Trace File
- /audit/traces/GTLB_fcf_2026.md

---

## Reconciliation #4: ARR FY2026 ($860M)

### Claim in Deck
- Slide 4: "ARR FY2026: $860M"
- Slide 2: "ARR: $860M"

### Source Data
- **File:** /input/repo/extracted/financial_summary.json
- **Field:** arr[4]
- **Value:** 860

### Calculation
- Raw value: 860 (in millions)
- Value: $860M
- **Verification:** ✓ Match

### Context
- ARR is a management metric, not GAAP
- Disclosed in earnings call transcripts
- Source: GTLB_Q4_2024_transcript.txt (approximate line 25)

### Trace File
- /audit/traces/GTLB_arr_2026.md

---

## Reconciliation #5: Cash & Investments FY2026 ($1.26B)

### Claim in Deck
- Slide 2: "Cash & Investments: $1.26B"
- Slide 7: "Balance sheet strength: $1.26B cash"

### Source Data
- **File:** /input/repo/extracted/balance_sheet_annual.csv
- **Column:** 2026-01-31
- **Rows:** Cash and Cash Equivalents, Other Short Term Investments
- **Values:** 229576000.0, 1030327000.0

### Calculation
- Cash and Cash Equivalents: 229,576,000
- Other Short Term Investments: 1,030,327,000
- Total: 1,259,903,000
- Rounded to billions: $1.26B
- **Verification:** ✓ Match

### Trace File
- /audit/traces/GTLB_cash_2026.md

---

## Summary

| Number | Claim | Source | Verification |
|--------|-------|--------|--------------|
| $955M | Revenue FY2026 | income_statement_annual.csv | ✓ Match |
| -7.4% | Operating Margin FY2026 | income_statement_annual.csv | ✓ Match |
| $222M | Free Cash Flow FY2026 | cash_flow_annual.csv | ✓ Match |
| $860M | ARR FY2026 | financial_summary.json | ✓ Match |
| $1.26B | Cash & Investments FY2026 | balance_sheet_annual.csv | ✓ Match |

## Notes

- All reconciliations match the source data
- Rounding is applied for presentation (millions, billions)
- Management metrics (ARR) are derived from earnings call transcripts
- Financial metrics are from SEC filings via yfinance
