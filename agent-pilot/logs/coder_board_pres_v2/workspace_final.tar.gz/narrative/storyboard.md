# Board of Advisors Presentation - Storyboard
## GitLab Inc. (GTLB) Investment Recommendation

**Date:** June 18, 2025  
**Audience:** Technical, skeptical board members  
**Goal:** Demonstrate agent reasoning and enable verification of all claims

---

## Narrative Arc

### 1. Opening (2 minutes)
- **Slide 1: Recommendation** - Lead with the BUY recommendation and price target
- **Slide 2: Executive Summary** - One slide overview of the thesis

### 2. The Thesis (5 minutes)
- **Slide 3: Investment Thesis** - GitLab's 5-part thesis in the agent's own words
- **Slide 4: Financial Trajectory** - Historical + projected with inflection points

### 3. Competitive Position (4 minutes)
- **Slide 5: Competitive Landscape** - Why these comps, GitLab's unique position
- **Slide 6: Mispricing Thesis** - What the market is underpricing

### 4. Risk Assessment (4 minutes)
- **Slide 7: Risk Prioritization** - High/medium/low risks with what must be true
- **Slide 8: Bear/Base/Bull Scenarios** - Probability-weighted visualization

### 5. Reasoning & Verification (5 minutes)
- **Slide 9: Reasoning Trail** - How the agent moved from filings → analysis → conclusion
- **Slide 10: Dead Ends** - Hypotheses investigated and rejected (shows intellectual honesty)

### 6. Confidence & Limitations (3 minutes)
- **Slide 11: Confidence Assessment** - What we're confident about vs. what we're estimating
- **Slide 12: How to Audit This Deck** - Self-audit slide showing verification mechanism

### 7. Q&A Transition (1 minute)
- **Slide 13: Key Catalysts & Position Sizing** - What to watch for and portfolio impact

---

## Slide-by-Slide Breakdown

### Slide 1: Recommendation
**Headline:** BUY | $42.00 Price Target (95% upside from $21.51)

**Content:**
- Recommendation: BUY
- 12-month price target: $42.00
- Current price: $21.51
- Probability-weighted target: $45.98 (114% upside)
- Key message: Market is underpricing GitLab's AI monetization and operating leverage

**Visual:** Large recommendation badge, price target visualization

**Reasoning for placement:** Lead with conclusion - board members should know the recommendation immediately

---

### Slide 2: Executive Summary
**Headline:** GitLab is undervalued with a clear path to profitability

**Content:**
- Strong growth: 30% CAGR revenue (FY2023-FY2026)
- Improving margins: -49.8% → -7.4% operating margin
- Strong SaaS metrics: 115% NRR, $860M ARR
- Healthy balance sheet: $1.26B cash, negligible debt
- Path to profitability: GAAP operating income by FY2028

**Visual:** 4-column summary with icons

**Reasoning for placement:** After recommendation, provide quick overview before diving deep

---

### Slide 3: Investment Thesis
**Headline:** 5-part thesis driving the recommendation

**Content:**
1. Large and growing TAM ($30B+ DevOps market)
2. Proven growth engine (30% CAGR, 115% NRR)
3. Clear path to profitability (margins improving 13pp annually)
4. Strong balance sheet ($1.26B cash)
5. What the market is missing (AI monetization, operating leverage, ARR quality)

**Visual:** 5-point diagram with GitLab logo at center

**Reasoning for placement:** Core thesis slide - shows the agent's reasoning framework

---

### Slide 4: Financial Trajectory
**Headline:** Revenue growth moderating but path to profitability clear

**Content:**
- Historical: FY2023-FY2026 (424M → 955M revenue, -49.8% → -7.4% operating margin)
- Projected: FY2027-FY2031 (1,146M → 1,916M revenue, 20% → 26% FCF margin)
- Inflection points: FY2024 (FCF positive), FY2028 (GAAP profitability projected)

**Visual:** Dual-axis chart (revenue + FCF margin on left, operating margin on right)

**Reasoning for placement:** Shows the quantitative foundation of the thesis

---

### Slide 5: Competitive Landscape
**Headline:** Full-stack DevOps platform with unique positioning

**Content:**
- GitLab's position: Full-stack, open-core, single application
- Competitor comparison: 8 peers with EV/Revenue multiples
- Key differentiators: Workflow embedding, open-source distribution

**Visual:** Scatter plot (revenue growth vs. EV/Revenue) with GitLab labeled

**Reasoning for placement:** Shows competitive positioning and valuation context

---

### Slide 6: Mispricing Thesis
**Headline:** Market underpricing 3 key factors

**Content:**
1. AI monetization potential (Gitter, code review, security scanning)
2. ARR quality ($860M ARR with 115% NRR = $990M next-year revenue)
3. Operating leverage (margins expand as revenue scales)

**Visual:** 3-panel diagram showing each factor and its impact

**Reasoning for placement:** Explains why valuation doesn't match fundamentals

---

### Slide 7: Risk Assessment
**Headline:** Risks prioritized by probability and impact

**Content:**
- High probability/high impact: NRR decline, GitHub competition
- Medium probability/high impact: Macro downturn, AI monetization failure
- Low probability/high impact: Open-source cannibalization, key person risk

**Visual:** Risk matrix (probability vs. impact) with bubbles for each risk

**Reasoning for placement:** Shows agent considered risks, not just positives

---

### Slide 8: Bear/Base/Bull Scenarios
**Headline:** Probability-weighted valuation scenarios

**Content:**
- Bear (25%): $18.58/share (-14%)
- Base (50%): $38.52/share (79%)
- Bull (25%): $88.30/share (310%)
- Probability-weighted: $45.98/share (114%)

**Visual:** Distribution chart showing probability density across price targets

**Reasoning for placement:** Shows agent quantified uncertainty, not just point estimate

---

### Slide 9: Reasoning Trail
**Headline:** How the agent reached its conclusion

**Content:**
- Filings read: 10-K, 10-Q, earnings transcripts (Q4 2023 - Q1 2025)
- Analysis performed: DCF, EV/Revenue multiples, SaaS metrics
- Decisions made: Company selection, competitor selection, valuation methodology
- Conclusions drawn: Undervaluation, path to profitability, AI potential

**Visual:** Flowchart showing data → analysis → decisions → conclusion

**Reasoning for placement:** Critical for skeptical board - shows reasoning transparency

---

### Slide 10: Dead Ends
**Headline:** Hypotheses investigated and rejected

**Content:**
1. SEC filing downloads blocked (403 errors) → used yfinance instead
2. GitLab IR website DNS failed → used third-party transcripts
3. PRNewswire search 404 → used earnings call transcripts
4. Initial CIK lookup wrong (Harper James P) → corrected to 0001653482
5. Earnings call audio not accessible → relied on text transcripts

**Visual:** "What didn't work" diagram with lessons learned

**Reasoning for placement:** Shows intellectual honesty - builds trust with board

---

### Slide 11: Confidence Assessment
**Headline:** What we're confident about vs. what we're estimating

**Content:**
- Confident about: Revenue trajectory, gross margins, balance sheet, SaaS model
- Estimating: ARR/NRR (management metrics), AI monetization, competitive dynamics

**Visual:** Two-column table with confidence indicators (✓/⚠️)

**Reasoning for placement:** Sets expectations about certainty levels

---

### Slide 12: How to Audit This Deck
**Headline:** Every claim traces back to source data

**Content:**
- Audit trail mechanism: Click any number → trace file → source data
- Repository structure: /audit/traces/, /audit/numbers.md, /audit/quotes.md
- Verification steps: Clone repo, find claim, follow trace, verify source

**Visual:** Diagram showing audit path from slide → trace → source

**Reasoning for placement:** Most important slide for technical board - enables verification

---

### Slide 13: Key Catalysts & Position Sizing
**Headline:** What to watch for and portfolio impact

**Content:**
- Catalysts: FY2027 Q1 earnings, GAAP profitability announcement, AI feature expansion
- Position sizing: 2-3% of portfolio, 12-month holding period
- Next steps: Monitor NRR trends, AI adoption metrics, competitive response

**Visual:** Timeline showing key catalysts over next 12 months

**Reasoning for placement:** Final slide - sets up Q&A and next actions

---

## Design Principles

1. **Color scheme:** GitLab blue (#615192) as primary, with red for downside, green for upside
2. **Typography:** Sans-serif (Arial/Helvetica) for clarity, bold for emphasis
3. **Charts:** Minimalist, data-focused, no chartjunk
4. **Tracing:** Every number has trace file in /audit/traces/
5. **Transparency:** Dead ends and limitations shown, not hidden

---

## Timing

- Total presentation: 15 minutes
- Q&A: 15 minutes
- Per slide: 1-2 minutes average
