# GitLab Inc. (GTLB) Board of Advisors Presentation

**Recommendation:** BUY | **12-Month Price Target:** $42.00 | **Current Price:** $21.51

## How to Navigate This Repository

This repository contains a complete board presentation for GitLab Inc. (GTLB), including the reasoning trail, verification mechanism, and all source data.

### For a Quick Read (10 minutes)
1. Start with this README.md
2. Read `narrative/storyboard.md` - the narrative arc
3. Read `narrative/audience-analysis.md` - board member profiles
4. Read `memo/gitlab_investment_memo.md` - the final memo (in /input/repo/)

### For a Deep Dive (30 minutes)
1. Read `narrative/storyboard.md` - the narrative arc
2. Read `narrative/audience-analysis.md` - board member profiles
3. Read `narrative/alternatives.md` - alternative structures considered
4. Read `research/questions.md` - questions and resolutions
5. Read `research/dead-ends.md` - dead ends and lessons
6. Read `decisions/` - ADR-style decision records
7. Read `audit/` - audit trail for all claims
8. Read `deck/source/` - deck source files

### For Verification (15 minutes)
1. Read `audit/reconciliation.md` - 5 reconciled numbers
2. Read `audit/numbers.md` - all numbers with sources
3. Read `audit/quotes.md` - all quotes with sources
4. Read `audit/traces/` - trace files for key claims
5. Read `sources.md` - external sources
6. Read `tool-log.md` - tool call log

## Repository Structure

```
/workspace/
├── README.md                    # This file
├── sources.md                   # All external sources with URLs and SHAs
├── tool-log.md                  # Every tool call with justification
├── narrative/
│   ├── storyboard.md            # Full narrative arc before slide building
│   ├── audience-analysis.md     # Board member profiles and communication strategy
│   └── alternatives.md          # Alternative narrative structures considered
├── research/
│   ├── notes/                   # Working notes, dated
│   │   └── 2025-06-18-initial-analysis.md
│   ├── questions.md             # Questions encountered and resolved
│   └── dead-ends.md             # Things that didn't work out
├── decisions/
│   ├── 001-company-selection.md
│   ├── 002-competitor-selection.md
│   ├── 003-valuation-methodology.md
│   ├── 004-color-scheme.md      # Color scheme decision
│   ├── 005-chart-conventions.md # Chart conventions
│   ├── 006-slide-structure.md   # Slide structure
│   └── 007-trace-file-format.md # Trace file format
├── audit/
│   ├── numbers.md               # All numbers with sources
│   ├── quotes.md                # All quotes with sources
│   ├── reconciliation.md        # 5 reconciled numbers
│   └── traces/                  # Trace files for key claims
│       ├── GTLB_revenue_2026.md
│       ├── GTLB_operating_margin_2026.md
│       ├── GTLB_fcf_2026.md
│       ├── GTLB_arr_2026.md
│       ├── GTLB_cash_2026.md
│       ├── GTLB_nrr_2026.md
│       ├── GTLB_ev_revenue_2026.md
│       ├── DCF_assumptions.md
│       ├── DCF_base_case.md
│       └── probability_weighted_target.md
├── assets/
│   ├── charts/                  # Chart generation scripts
│   │   └── generate_traces.py   # Trace file generator
│   ├── diagrams/                # Process diagrams
│   ├── images/                  # Photography, icons, imagery
│   └── tables/                  # Source data for tables
├── deck/
│   ├── source/                  # Deck source files
│   │   └── README.md            # Deck source README
│   └── presentation.pptx        # Final presentation (generated)
└── input/
    └── repo/                    # Input repository (read-only)
        ├── README.md            # GitLab investment memo README
        ├── sources.md           # Input sources
        ├── tool-log.md          # Input tool log
        ├── memo/
        │   └── gitlab_investment_memo.md  # Final investment memo
        ├── model/
        │   └── gitlab_three_statement_model.xlsx  # Financial model
        ├── analysis/
        │   ├── gitlab_analysis.py  # Analytical notebook
        │   └── analysis_summary.md # Key findings summary
        ├── decisions/
        │   ├── 001-company-selection.md
        │   ├── 002-competitor-selection.md
        │   └── 003-valuation-methodology.md
        ├── research/
        │   ├── notes/
        │   │   └── 2025-06-18-company-selection.md
        │   ├── questions.md
        │   └── dead-ends.md
        └── extracted/           # Parsed/cleaned data
            ├── income_statement_annual.csv
            ├── balance_sheet_annual.csv
            ├── cash_flow_annual.csv
            ├── competitor_data.json
            ├── financial_summary.json
            └── company_info.json
```

## Key Findings

1. **GitLab is undervalued** - DCF base case implies $38.52/share (79% upside), peer EV/Revenue implies $53.25/share (147% upside)
2. **Strong growth trajectory** - Revenue grew from $424M (FY2023) to $955M (FY2026), 30% CAGR
3. **Clear path to profitability** - Operating margins improving from -50% to -7%, projected profitable by FY2028
4. **Healthy SaaS metrics** - 115% NRR, 87% gross margin, $860M ARR
5. **Strong balance sheet** - $1.26B in cash/investments, negligible debt

## Data Provenance

Every number in the presentation can be traced back to its source:

- **Revenue figures** → `/input/repo/extracted/income_statement_annual.csv` → yfinance API → SEC filings
- **ARR/NRR** → `/input/repo/raw/transcripts/GTLB_Q*_transcript.txt` → Seeking Alpha earnings call transcripts
- **Competitor multiples** → `/input/repo/extracted/competitor_data.json` → yfinance API
- **Valuation assumptions** → `/input/repo/decisions/003-valuation-methodology.md` → documented rationale

## How to Verify This Deck

1. **Clone this repository**
2. **Pick any claim** from the presentation (e.g., "Revenue FY2026: $955M")
3. **Find the trace file** in `/audit/traces/` that matches the claim
4. **Follow the source path** in the trace file to the original data
5. **Verify the source** in `/input/repo/` (read-only)

Example:
```
Claim: "GitLab revenue FY2026: $955M"
Trace: /audit/traces/GTLB_revenue_2026.md
Source: /input/repo/extracted/income_statement_annual.csv, line 1, column 2026-01-31
```

## Limitations

1. **SEC filings not downloaded** - SEC.gov returned 403 errors for all automated requests. Financial data sourced from yfinance instead.
2. **No primary industry reports** - Gartner/IDC market sizing cited but not directly accessed.
3. **No customer interviews** - NRR and product satisfaction based on management disclosures only.
4. **No live earnings call participation** - Analysis based on text transcripts only.

## Technical Requirements

- Python 3.x with: `yfinance`, `pandas`, `openpyxl`, `requests`, `beautifulsoup4`, `lxml`
- Excel or LibreOffice to view the financial model
- PowerPoint to view the presentation

## Disclaimer

This memo is for informational and educational purposes only. It does not constitute investment advice. All valuations are based on assumptions that may not materialize. Past performance does not guarantee future results.
