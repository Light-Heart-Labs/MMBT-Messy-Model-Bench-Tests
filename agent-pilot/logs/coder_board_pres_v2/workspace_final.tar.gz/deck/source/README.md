# Deck Source Files

This directory contains the source files used to build the board presentation.

## Files

- `generate_deck.py` - Python script that generates the PowerPoint presentation
- `generate_traces.py` - Python script that generates trace files for audit trail

## How to Regenerate the Deck

1. Install required libraries:
   ```
   pip install python-pptx matplotlib
   ```

2. Run the deck generation script:
   ```
   python3 /workspace/assets/charts/generate_deck.py
   ```

3. The presentation will be saved to `/workspace/deck/presentation.pptx`

## Slide Content

The deck consists of 14 slides:

1. Title Slide
2. Recommendation
3. Executive Summary
4. Investment Thesis
5. Financial Trajectory
6. Competitive Landscape
7. Mispricing Thesis
8. Risk Assessment
9. Bear/Base/Bull Scenarios
10. Reasoning Trail
11. Dead Ends
12. Confidence Assessment
13. How to Audit This Deck
14. Key Catalysts & Position Sizing

## Design Principles

- **Color scheme:** GitLab blue (#615192) as primary, red/green for scenarios
- **Typography:** Sans-serif (Arial/Helvetica) for clarity
- **Charts:** Minimalist, data-focused, no chartjunk
- **Tracing:** Every number has trace file in /audit/traces/
- **Transparency:** Dead ends and limitations shown, not hidden
