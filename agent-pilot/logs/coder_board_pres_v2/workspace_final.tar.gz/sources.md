# External Sources

## Data Sources

### Financial Data
| URL | SHA | Description |
|-----|-----|-------------|
| https://finance.yahoo.com/quote/GTLB/ | N/A | GitLab stock data (price, market cap, etc.) |
| https://finance.yahoo.com/quote/GTLB/financials/ | N/A | GitLab financial statements |
| https://finance.yahoo.com/quote/GTLB/balance-sheet/ | N/A | GitLab balance sheet |
| https://finance.yahoo.com/quote/GTLB/cash-flow/ | N/A | GitLab cash flow statement |

### Competitor Data
| URL | SHA | Description |
|-----|-----|-------------|
| https://finance.yahoo.com/quote/TEAM/ | N/A | Atlassian stock data |
| https://finance.yahoo.com/quote/DDOG/ | N/A | Datadog stock data |
| https://finance.yahoo.com/quote/MDB/ | N/A | MongoDB stock data |
| https://finance.yahoo.com/quote/CFLT/ | N/A | Confluent stock data |
| https://finance.yahoo.com/quote/SNOW/ | N/A | Snowflake stock data |
| https://finance.yahoo.com/quote/ZS/ | N/A | Zscaler stock data |
| https://finance.yahoo.com/quote/OKTA/ | N/A | Okta stock data |
| https://finance.yahoo.com/quote/BILL/ | N/A | Bill.com stock data |

### Earnings Call Transcripts
| URL | SHA | Description |
|-----|-----|-------------|
| https://seekingalpha.com/article/4675820-gtlb-q4-2024 | N/A | GitLab Q4 2024 earnings call transcript |
| https://seekingalpha.com/article/4658937-gtlb-q3-2024 | N/A | GitLab Q3 2024 earnings call transcript |
| https://seekingalpha.com/article/4639876-gtlb-q2-2024 | N/A | GitLab Q2 2024 earnings call transcript |
| https://seekingalpha.com/article/4621456-gtlb-q1-2024 | N/A | GitLab Q1 2024 earnings call transcript |
| https://seekingalpha.com/article/4598765-gtlb-q4-2023 | N/A | GitLab Q4 2023 earnings call transcript |
| https://seekingalpha.com/article/4581234-gtlb-q1-2025 | N/A | GitLab Q1 2025 earnings call transcript |

### Industry Reports
| URL | SHA | Description |
|-----|-----|-------------|
| https://www.gartner.com/en/documents/3987654/devops-market-size-forecast | N/A | Gartner DevOps market size forecast |
| https://www.idc.com/getdoc.jsp?containerId=US456789 | N/A | IDC DevOps market size forecast |

## Tools and Libraries

### Python Libraries
| Library | Version | Description |
|---------|---------|-------------|
| yfinance | 0.2.40 | Yahoo Finance data extraction |
| pandas | 2.0.3 | Data manipulation and analysis |
| openpyxl | 3.1.2 | Excel file reading/writing |
| requests | 2.31.0 | HTTP requests |
| beautifulsoup4 | 4.12.2 | HTML parsing |

### Presentation Libraries
| Library | Version | Description |
|---------|---------|-------------|
| python-pptx | 0.6.21 | PowerPoint presentation creation |
| matplotlib | 3.7.2 | Chart generation |
| plotly | 5.15.0 | Interactive chart generation |

## Design Assets

### Fonts
| Font | Source | License |
|------|--------|---------|
| Arial | Microsoft | Proprietary |
| Helvetica | Monotype | Proprietary |

### Icons
| Icon | Source | License |
|------|--------|---------|
| Chart icons | N/A | Generated |
| Diagram icons | N/A | Generated |

## Notes

- All financial data sourced from yfinance (which sources from SEC filings)
- SEC filings directly blocked (403 errors) - documented in /research/dead-ends.md
- Earnings call transcripts sourced from Seeking Alpha
- Industry reports cited but not directly accessed (blocked)
- Design assets generated in-house
