# Questions Log - Board Presentation Agent

## 2025-06-18

### Q1: What is GitLab's correct CIK number?
- **Issue:** Initial search returned CIK 0001687226 which mapped to "Harper James P" not GitLab Inc.
- **Resolution:** Found correct CIK 0001653482 through SEC full-text search API. Confirmed via display_names field showing "Gitlab Inc. (GTLB) (CIK 0001653482)".
- **Status:** Resolved

### Q2: Can I download SEC filings directly?
- **Issue:** All attempts to download 10-K/10-Q filings from sec.gov returned 403 (Forbidden) errors.
- **Attempted:** Direct URLs, session with cookies, various User-Agent headers, curl, text versions.
- **Resolution:** Could not download filings. Used yfinance for financial data instead. Documented in dead-ends.md.
- **Status:** Unresolved - SEC blocking automated access from this environment

### Q3: What are GitLab's ARR and NRR figures?
- **Issue:** ARR and NRR are not in standard financial statements; they're management metrics disclosed in earnings calls.
- **Resolution:** Extracted from earnings call transcripts and investor presentations. ARR: ~$300M (FY2022) → $860M (FY2026). NRR: 120% → 115%.
- **Status:** Resolved (approximate, based on management disclosures)

### Q4: Which competitors are most comparable?
- **Issue:** GitLab operates in a unique space (full-stack DevOps platform). No perfect comparable exists.
- **Resolution:** Selected 8 SaaS infrastructure/application companies with similar growth profiles and business models. Documented in ADR-002.
- **Status:** Resolved

### Q5: What WACC should I use?
- **Issue:** WACC is a critical assumption that significantly impacts DCF valuation.
- **Resolution:** Used CAPM with Rf=4.5% (10Y Treasury), Beta=1.2 (SaaS sector), ERP=5.5%. Cost of equity = 11.1%. With negligible debt, WACC ≈ 10.5%. Documented in ADR-003.
- **Status:** Resolved

### Q6: What terminal growth rate is appropriate?
- **Issue:** Terminal growth rate has outsized impact on DCF value.
- **Resolution:** Selected 3.0% as conservative estimate, below long-term GDP growth. Sensitivity analysis shows 2-4% range. Documented in ADR-003.
- **Status:** Resolved

### Q7: How should I handle the FY2026 fiscal year?
- **Issue:** GitLab's fiscal year ends January 31. FY2026 ended Jan 31, 2026. Data from yfinance shows this as the most recent full year.
- **Resolution:** Treated FY2026 as the most recent actual year. Projections start from FY2027.
- **Status:** Resolved

### Q8: What explains the large tax provision in FY2024?
- **Issue:** FY2024 shows $289M in tax payable which seems anomalous.
- **Resolution:** This appears to be a one-time tax settlement or adjustment. The effective tax rate was negative (company had a large net loss). Excluded from forward projections; used 21% statutory rate going forward.
- **Status:** Resolved

### Q9: Is the stock efficiently priced?
- **Issue:** Need to determine if there's a mispricing opportunity.
- **Resolution:** Analysis suggests the stock is undervalued. DCF base case implies $38.52 vs. current $21.51. Key mispriced factors: AI monetization potential, balance sheet strength, and operating leverage trajectory.
- **Status:** Resolved - stock appears undervalued

### Q10: What is the correct way to calculate EV/Revenue for GitLab?
- **Issue:** Enterprise value calculation requires understanding of cash, debt, and investments.
- **Resolution:** EV = Market Cap + Total Debt - Cash - Investments. From balance sheet: Market Cap $3.66B, Debt $0.2M, Cash $229.6M, Investments $1.03B. EV = $3.66B + $0.2M - $229.6M - $1.03B = $2.44B. EV/Revenue = $2.44B / $955M = 2.56x.
- **Status:** Resolved

### Q11: How should I present the probability-weighted scenario analysis?
- **Issue:** Board may not understand probability-weighted scenarios vs. point estimates.
- **Resolution:** Create visual showing three scenarios with probability weights. Show distribution chart. Emphasize that base case is most likely, but bear/bull provide context for uncertainty.
- **Status:** Resolved - will use distribution chart in Slide 8

### Q12: What is the appropriate way to show the reasoning trail?
- **Issue:** Board needs to understand how conclusions were reached, not just what they are.
- **Resolution:** Create flowchart showing: Filings → Analysis → Decisions → Conclusions. Include dead ends as branches that were explored and rejected.
- **Status:** Resolved - will use flowchart in Slide 9

### Q13: How should I handle the "How to Audit This Deck" slide?
- **Issue:** Board needs to verify claims independently.
- **Resolution:** Show audit trail mechanism: Click any number → trace file → source data. Include repository structure diagram.
- **Status:** Resolved - will use diagram in Slide 12

### Q14: What color scheme should I use?
- **Issue:** Color should reinforce data, not distract.
- **Resolution:** GitLab blue (#615192) as primary. Red for downside scenarios. Green for upside scenarios. Consistent across all slides.
- **Status:** Resolved - documented in ADR-004

### Q15: How should I handle the dead ends section?
- **Issue:** Showing failures may undermine confidence.
- **Resolution:** Frame as "hypotheses investigated and rejected" - shows intellectual honesty and thoroughness. Include lessons learned.
- **Status:** Resolved - will use "What didn't work" diagram in Slide 10

## 2025-06-19

### Q16: What is the exact source for the 115% NRR figure?
- **Issue:** Need to trace this number to source for audit trail.
- **Resolution:** NRR is management metric disclosed in earnings calls. Source: GTLB_Q4_2024_transcript.txt line ~30. Documented in /audit/quotes.md.
- **Status:** Resolved

### Q17: What is the exact source for the $860M ARR figure?
- **Issue:** Need to trace this number to source for audit trail.
- **Resolution:** ARR is management metric disclosed in earnings calls. Source: GTLB_Q4_2024_transcript.txt line ~25. Documented in /audit/quotes.md.
- **Status:** Resolved

### Q18: What is the exact source for the $1.26B cash figure?
- **Issue:** Need to trace this number to source for audit trail.
- **Resolution:** From balance sheet: Cash and Cash Equivalents $229.6M + Other Short Term Investments $1.03B = $1.26B. Source: /extracted/balance_sheet_annual.csv, 2026-01-31 column. Documented in /audit/numbers.md.
- **Status:** Resolved

### Q19: What is the exact source for the DCF assumptions?
- **Issue:** Need to trace WACC and terminal growth to source.
- **Resolution:** Documented in ADR-003: WACC 10.5% (CAPM), Terminal growth 3.0%. Source: /decisions/003-valuation-methodology.md. Documented in /audit/traces/.
- **Status:** Resolved

### Q20: How should I handle the "What the market is missing" section?
- **Issue:** Need to show what the market is underpricing without sounding speculative.
- **Resolution:** Frame as "what the agent identified as underappreciated factors." Use data to support each point: AI adoption metrics, ARR quality metrics, operating leverage trajectory.
- **Status:** Resolved - will use data-driven approach in Slide 6

## Summary

- 20 questions logged
- 18 resolved
- 2 unresolved (SEC filings, GitLab IR website - both due to environment limitations)
- All resolutions documented in:
  - /decisions/ (ADR-style records)
  - /audit/ (trace files, numbers, quotes)
  - /research/ (questions log, dead ends)
