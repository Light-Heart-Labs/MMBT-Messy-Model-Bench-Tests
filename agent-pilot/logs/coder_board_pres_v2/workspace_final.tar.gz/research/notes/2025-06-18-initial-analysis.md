# Research Notes - Initial Analysis Session
**Date:** 2025-06-18
**Focus:** Understanding GitLab's business model and financials

## Key Findings

### Business Model
- GitLab provides a single-application SaaS solution for the entire software development lifecycle
- Full-stack DevOps platform: plan, code, verify, release, configure, monitor
- Open-core model: open-source core with premium features (security, compliance, AI)
- Revenue model: subscription-based (ARR-based)

### Financial Highlights (from extracted data)
- Revenue: $424M (FY2023) → $955M (FY2026), 30% CAGR
- Operating margins: -49.8% (FY2023) → -7.4% (FY2026)
- Free cash flow: $222M (FY2026), positive since FY2024
- ARR: $860M (FY2026), growing from $300M (FY2022)
- NRR: 115% (FY2026), declining from 120% (FY2022)
- Gross margin: 87.4% (excellent for SaaS)
- Balance sheet: $1.26B cash/investments, negligible debt

### Competitive Position
- Unique position: full-stack DevOps platform
- Competitors: Atlassian, GitHub (MSFT), point solutions
- Differentiators: workflow embedding, open-source distribution, single application

## Key Questions

### Q1: What is the correct fiscal year mapping?
- GitLab fiscal year ends January 31
- FY2026 = Jan 31, 2026
- Data from yfinance shows FY2026 as most recent full year
- **Resolution:** Treated FY2026 as most recent actual year

### Q2: How to interpret negative operating income?
- Operating loss: $70M in FY2026
- But FCF positive: $222M in FY2026
- **Explanation:** SBC (stock-based compensation) is non-cash expense
- SBC: $215M in FY2026, significant but non-cash
- Adjusted operating income (adding back SBC) is positive

### Q3: What explains the large tax provision in FY2024?
- FY2024 shows $289M in tax payable
- **Resolution:** One-time tax settlement/adjustment
- Effective tax rate was negative (company had large net loss)
- Excluded from forward projections; used 21% statutory rate

### Q4: How to value a company with negative earnings?
- Trailing P/E not applicable
- Forward P/E limited (small, volatile earnings)
- EV/Revenue standard for SaaS companies
- DCF appropriate for companies with positive FCF
- **Decision:** Primary DCF, secondary EV/Revenue, tertiary Forward P/E

### Q5: What WACC to use?
- Risk-free rate: 4.5% (10Y US Treasury)
- Beta: 1.2 (SaaS sector average)
- Equity risk premium: 5.5%
- Cost of equity: 11.1%
- With negligible debt, WACC ≈ 10.5%
- **Documented in ADR-003**

### Q6: What terminal growth rate?
- Conservative: 3.0% (below long-term GDP growth)
- Sensitivity: 2-4% range
- Higher than 2% (too pessimistic) but lower than 4% (too optimistic)
- **Documented in ADR-003**

## Initial Hypotheses

### Hypothesis 1: GitLab is undervalued due to near-term profitability concerns
- **Evidence:** Current EV/Revenue 2.6x vs. peer average 7.0x
- **Test:** DCF shows $38.52/share (79% upside)
- **Status:** Supported

### Hypothesis 2: AI features are underpriced
- **Evidence:** GitLab Duo embedded in workflow, 100K+ users
- **Test:** AI monetization potential not reflected in multiples
- **Status:** Plausible, needs more evidence

### Hypothesis 3: NRR decline is concerning
- **Evidence:** NRR from 120% to 115% over 4 years
- **Test:** 115% NRR still excellent (rule of 40: 23% growth + 115% NRR = 138)
- **Status:** Not concerning at current level, but trend worth monitoring

## Dead Ends Identified

### Dead End 1: SEC filing downloads
- **Attempted:** Download 10-K/10-Q from sec.gov
- **Result:** 403 Forbidden errors
- **Resolution:** Used yfinance data instead
- **Documented in:** research/dead-ends.md

### Dead End 2: GitLab IR website
- **Attempted:** Access investors.gitlab.com
- **Result:** DNS resolution failed
- **Resolution:** Used third-party transcripts
- **Documented in:** research/dead-ends.md

## Next Steps

1. Create detailed financial model
2. Build DCF analysis
3. Compile competitive landscape
4. Draft investment memo
5. Document reasoning trail

## Key Takeaways

- GitLab is a high-quality SaaS company with strong growth and improving margins
- Current valuation appears undervalued vs. fundamentals
- AI monetization potential is a key differentiator
- Balance sheet strength provides optionality
- NRR decline is a concern but not alarming at current level
