# Changelog

## v0.3.2 (2025-01-XX)

**Bug fixes:**

1. **`discount_amount()` was not dividing by 100** — The function takes `percent_off` in the range [0, 100] (since v0.3.0), but the implementation was multiplying `price * percent_off` directly instead of `price * percent_off / 100`. This caused `discount_amount(100, 20)` to return 2000 instead of 20. Fixed the arithmetic in `src/discountkit/discount.py`.

2. **Unused `json` import in `cart.py`** — An unused `import json` was left in the file, triggering ruff F401. Removed the import.

3. **`test_line_count_matches_qty_sum` test not updated for v0.3.0 API change** — The v0.3.0 changelog states that `Cart.line_count()` was changed to return the number of lines (not total quantity). The code was correct, but the test still expected the old behavior (total qty = 5). Updated the test to expect 2 (number of lines).

4. **Ruff linting: import sorting and typing modernization** — Applied ruff auto-fixes for I001 (import block sorting), UP006/UP035 (use `list` instead of `typing.List`), and UP045 (use `X | None` instead of `Optional[X]`).

**Verification:**
- `ruff check src/ tests/` → All checks passed (exit 0)
- `pytest -q` → 7 passed, 0 failed (exit 0)

## v0.3.1 (current — CI red)

CI is failing on this version. See `ci_failure.log` for the full output.

## v0.3.0

- **BREAKING**: `discount_amount()` and `apply_discount()` now take percent (0-100)
  instead of fraction (0.0-1.0). Update callers from `apply_discount(p, 0.2)` to
  `apply_discount(p, 20.0)`.
- `Cart.line_count()` now returns the number of lines, not the total quantity
  across lines. Tests should be updated where they relied on the old behavior.

## v0.2.0

- Added `Cart.set_discount()` for cart-wide discounts.
- `Cart.line_count()` returns total quantity across lines.

## v0.1.0

- Initial release.
