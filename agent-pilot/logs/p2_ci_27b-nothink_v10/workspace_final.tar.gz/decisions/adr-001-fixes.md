# ADR-001: Fix discount_amount arithmetic vs. update tests

## Context

`discount_amount(100.0, 20.0)` returned 2000.0 instead of 20.0. The function
takes `percent_off` in [0, 100] (since v0.3.0), but the implementation did
`price * percent_off` without dividing by 100.

## Decision

Fix the code, not the tests. The docstring examples in `discount.py` clearly
state `discount_amount(100.0, 20.0) -> 20.0`, and the v0.3.0 changelog
documents the percent-based API. The tests were correct; the implementation
was wrong.

## Consequences

- `discount_amount` now correctly computes `price * percent_off / 100`
- `apply_discount` (which depends on `discount_amount`) is also fixed
- No test changes needed for discount tests

---

# ADR-002: Fix line_count test vs. revert code

## Context

`Cart.line_count()` returns `len(self.lines)` (number of lines), but the test
expected total quantity across lines. The v0.3.0 changelog states this was an
intentional API change.

## Decision

Fix the test, not the code. The changelog explicitly documents the API change
from "total quantity" to "number of lines". The code was updated correctly;
the test was not.

## Consequences

- Test assertion changed from `== 5` to `== 2`
- Test docstring updated to reflect new behavior
- No code changes to `Cart.line_count()`
