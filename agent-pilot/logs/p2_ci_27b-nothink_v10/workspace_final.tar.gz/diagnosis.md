# Diagnosis

## CI Failure Analysis

The CI log showed 1 ruff error and 3 test failures. Here's the breakdown:

### 1. Ruff F401: Unused `json` import in `cart.py`

**What was wrong:** `import json` was present but never used in `src/discountkit/cart.py`.

**Fix:** Removed the import line.

**Decision:** Code fix — straightforward lint issue.

### 2. `test_discount_amount` — `assert 2000.0 == 20.0`

**What was wrong:** `discount_amount(100.0, 20.0)` returned 2000.0 instead of 20.0. The function multiplies `price * percent_off` but since v0.3.0 the parameter is a percentage (0-100), not a fraction (0-1). It needs to divide by 100.

**Fix:** Changed `return round(price * percent_off, 2)` to `return round(price * percent_off / 100, 2)`.

**Decision:** Code fix — the docstring examples and the v0.3.0 changelog both confirm the function should take percent (0-100). The implementation was wrong.

### 3. `test_apply_discount` — `assert -1900.0 == 80.0`

**What was wrong:** This was a cascading failure from bug #2. `apply_discount` calls `discount_amount`, so the wrong discount amount caused the wrong final price.

**Fix:** Resolved by fixing `discount_amount` (bug #2). No separate change needed.

### 4. `test_line_count_matches_qty_sum` — `assert 2 == 5`

**What was wrong:** The test expected `line_count()` to return total quantity (5), but the code returns number of lines (2). The v0.3.0 changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines."

**Fix:** Updated the test assertion from `== 5` to `== 2`, and updated the docstring to reflect the new behavior.

**Decision:** Test fix — the code was correct per the v0.3.0 API change documented in the changelog. The test was not updated when the API changed.

### 5. Additional ruff issues (I001, UP006, UP035, UP045)

**What was wrong:** Import blocks were unsorted, and deprecated `typing.List`/`typing.Optional` were used instead of modern `list`/`X | None`.

**Fix:** Applied `ruff --fix` to auto-correct all of these.

**Decision:** Code fix — these are style/modernization issues that ruff enforces.
