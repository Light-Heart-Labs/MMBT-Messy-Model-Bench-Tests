# Borealis Analytics Acquisition Review

This repository contains the executive committee review of the Borealis Analytics acquisition diligence pack.

## Files

- **`memo.md`** — The 1-page executive memo with the recommendation, concerns, and next steps.
- **`concerns.md`** — A detailed enumeration of concerns with the deal pack, including overclaims, underexplanations, and omissions.
- **`asks.md`** — A 2-week diligence plan with specific questions, owners, and deadlines.
- **`decisions/adr001.md`** — The decision record for the recommendation stance.

## Summary

The deal pack recommends PROCEEDING to LOI at $84M. This review finds the pack compelling but incomplete. Key concerns include:

- Overreliance on GAAP revenue without cash flow validation.
- Limited customer validation (only 5 customers, no churned customers).
- Integration timeline and retention estimates lack evidence.
- Valuation comps lack growth-rate normalization.

**Recommendation:** HOLD — pending completion of the 2-week diligence plan. If key conditions are met (e.g., cash collections validate revenue, retention plan is robust, DCF shows resilience), the recommendation can be upgraded to PROCEED.

## How to Use

1. Read `memo.md` for the high-level view.
2. Review `concerns.md` for a deeper understanding of the pack's weaknesses.
3. Use `asks.md` to assign diligence tasks.
4. Refer to `decisions/adr001.md` for the decision rationale.
