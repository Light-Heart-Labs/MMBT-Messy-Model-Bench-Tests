# Diligence Asks for the Next 2 Weeks

## 1. Financial Deep Dive (Owner: FP&A Lead, Deadline: 2026-04-25)

- [ ] Provide cash collections vs. GAAP revenue for FY2024 and FY2025. Explain any material differences.
- [ ] Provide deferred revenue balance and changes over the last 2 quarters.
- [ ] Break down churn by ARR band (e.g., < $20K, $20–$50K, > $50K) to validate the logo vs. net retention narrative.
- [ ] Provide a 12-month cash flow forecast, including assumptions for growth, burn, and path to profitability.
- [ ] Provide a detailed synergy model: which infra costs are being eliminated, and how was the $3.2M figure derived?

## 2. Customer Validation (Owner: VP Product, Deadline: 2026-04-25)

- [ ] Conduct reference calls with at least 3 churned customers and 3 customers who declined to renew in the last 12 months.
- [ ] Verify the NPS figure: request Borealis's raw survey data and methodology.
- [ ] Request a list of all customers who declined to renew or reduced spend in the last 12 months, with reasons (if available).
- [ ] Confirm customer concentration: what % of ARR comes from the top 5 and top 10 customers?

## 3. Technical Due Diligence (Owner: VP Eng, Deadline: 2026-04-25)

- [ ] Obtain a codebase health report: test coverage %, CI/CD maturity, deployment frequency, mean time to recovery (MTTR).
- [ ] Conduct a 90-minute deep-dive with Borealis's engineering leadership on tech debt, scalability, and integration plan.
- [ ] Review their data pipeline architecture and data governance practices (especially for GDPR/CCPA compliance).
- [ ] Assess intellectual property ownership: who owns the core code, and are there any third-party dependencies with restrictive licenses?

## 4. Product and Market (Owner: Head of Strategy, Deadline: 2026-04-25)

- [ ] Provide a competitive matrix: top 3 competitors, market share estimates, pricing comparisons, and win/loss rates.
- [ ] Validate the "12% feature overlap" claim with a side-by-side feature comparison.
- [ ] Review Borealis's product roadmap for the next 12 months and assess alignment with our platform strategy.
- [ ] Assess the mid-market e-commerce opportunity size and our current revenue from that segment (via partners or otherwise).

## 5. Legal and Contract Review (Owner: General Counsel, Deadline: 2026-04-25)

- [ ] Review all customer contracts for renewal terms, early termination clauses, and change-of-control provisions.
- [ ] Confirm no pending litigation, regulatory investigations, or data breaches in the last 24 months.
- [ ] Review employee contracts for non-solicitation and IP assignment clauses.
- [ ] Assess data privacy compliance: GDPR, CCPA, and other relevant regulations.

## 6. Retention Plan (Owner: HR Lead, Deadline: 2026-04-25)

- [ ] Obtain a full employee list with roles, tenures, and compensation.
- [ ] Conduct anonymous engagement surveys with Borealis employees (especially engineering and product).
- [ ] Draft a retention bonus plan for key employees (engineering, product, sales) with clear eligibility and payout criteria.
- [ ] Present a detailed integration plan with milestones, roles, and responsibilities (not just a timeline).

## 7. Valuation and Deal Structuring (Owner: CFO, Deadline: 2026-04-28)

- [ ] Provide a DCF model with base, upside, and downside scenarios (e.g., growth rates: 92%, 60%, 30%; margins: 71%, 60%, 50%).
- [ ] Provide sensitivity analysis for key variables: ARR growth, gross margin, integration costs, retention rate.
- [ ] Recommend a cash vs. stock split that balances Borealis's preferences with our balance sheet flexibility.
- [ ] Compare Borealis's growth rate and margins to the comps to justify the 7.4x multiple.

## 8. Final Recommendation Memo (Owner: Corp Dev, Deadline: 2026-04-30)

- [ ] Incorporate findings from all above asks.
- [ ] Update the recommendation (proceed, hold, or pass) with revised rationale.
- [ ] List any material risks that were not previously disclosed.
- [ ] Provide a revised integration plan with more granular milestones.
