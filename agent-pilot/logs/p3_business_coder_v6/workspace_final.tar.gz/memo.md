# Executive Committee Memo: Borealis Analytics Acquisition

**Date:** 2026-04-17  
**From:** Executive Committee Member  
**Subject:** Independent Review of Deal Pack — Recommendation: **HOLD**

## Recommendation

I recommend **HOLD** on issuing the LOI at $84M. The deal has clear strengths — strong growth (92% ARR YoY), high net retention (118%), and a valuation (~7.4x ARR) that appears reasonable relative to comps — but the pack is incomplete and lacks sufficient evidence to support a final decision. Proceeding to LOI now would be premature.

I would upgrade to **PROCEED** if the following conditions are met within 2 weeks:
1. Cash collections validate GAAP revenue (no material lag or concentration risk).
2. Churned customers provide neutral or positive feedback, and top-10 customer concentration is <25% of ARR.
3. Codebase health report shows ≥80% test coverage and no critical IP or compliance risks.
4. Anonymous employee survey shows ≥70% engagement, and a retention plan is in place for key engineering talent.
5. DCF model shows positive NPV across base and downside scenarios.

If any of these conditions are not met, or if material risks are uncovered, I would recommend **PASS**.

## Strongest Concerns

1. **Financials are incomplete.** The pack reports GAAP revenue ($9.2M) but omits cash collections and deferred revenue. A company burning $750K/month with only $4.1M cash ($5.5M runway) could be burning cash despite strong GAAP revenue if collections lag. Without cash flow data, we cannot assess true liquidity.

2. **Customer validation is thin and biased.** Only 5 customers were contacted (4 quoted), and none were churned. This tiny sample (280 customers) and selection bias (likely happy customers) make the "NPS in the high 40s" claim unreliable. We need to hear from churned customers to validate satisfaction.

3. **Integration risks are understated.** The 4-6 month timeline and 85% retention rate are stated but not substantiated. Integration of data platforms is notoriously complex, and employee retention during uncertainty is never guaranteed. The pack provides no evidence (e.g., retention bonuses, engagement surveys) to support these figures.

4. **Valuation comps lack context.** The comps (Hexa, Aspen, Trellis) are not described in detail. A 7.4x multiple for a 92% growth company is very different from 7.4x for a 20% growth company. The pack does not normalize for growth rate, making the "in line with comps" claim misleading.

5. **Synergy estimate is unvalidated.** The $3.2M annual savings claim is stated but not broken down. What infra costs are being eliminated? Is this based on actual usage forecasts or assumptions? A 30% reduction in infra costs is significant and should be backed by a model.

## Next Steps

I propose a 2-week diligence sprint to address the above concerns. Key asks include:

- **Financials:** Validate cash collections vs. GAAP revenue, deferred revenue, and path to profitability.
- **Customers:** Interview churned customers, verify NPS methodology, and confirm customer concentration.
- **Technical:** Obtain codebase health report (test coverage, CI/CD maturity) and conduct engineering deep-dive.
- **Retention:** Conduct anonymous employee survey and draft retention plan for key talent.
- **Valuation:** Build DCF model with base, upside, and downside scenarios.

If these asks are completed satisfactorily, I will recommend PROCEED. If not, I will recommend PASS.

**Deadline for re-evaluation:** 2026-04-30
