# Concerns with the Borealis Acquisition Deal Pack

## 1. Overstated Strategic Rationale

- **Claim**: "Borealis would extend our analytics surface area into mid-market e-commerce, a segment we currently service only via partner integrations."
- **Concern**: This is presented as a clear strategic gap, but the pack provides no data on the size of that segment, our current revenue from partner-served mid-market e-commerce, or whether our existing partners are failing to serve it. Without this context, it's unclear if this is a $10M opportunity or a $100M one — or whether we're better off investing in our own analytics rather than acquiring.

## 2. Revenue Recognition vs. Cash Collection

- **Claim**: Revenue (GAAP) $9.2M in FY2025, up 80% YoY.
- **Concern**: GAAP revenue recognition can be misleading for SaaS startups. The pack does not provide cash collections or deferred revenue metrics. A company with $750K/month burn and only $4.1M cash on hand ($5.5M runway) could be burning cash despite "strong" GAAP revenue growth if customers are negotiating long payment terms or large discounts. We need to know if the revenue is "real" in a cash-flow sense.

## 3. Net Retention vs. Logo Retention Discrepancy

- **Claim**: Net retention 118%, Logo retention 91%.
- **Concern**: A 9% logo churn rate with 118% net retention implies that churned customers were very small (low ARR), while expansion from remaining customers is strong. This is plausible, but the pack does not break down the ARR of churned customers. If the 9% churn represents high-ARR customers (e.g., enterprise deals that failed), the risk is higher than implied. The pack should clarify the distribution.

## 4. Customer Testimonials: Small Sample, Selection Bias

- **Claim**: "Pre-LOI conversations with their five largest customers indicate strong satisfaction (NPS in the high 40s)."
- **Concern**: Only 5 customers were contacted, and only 4 were willing to be quoted. This is a tiny sample for a 280-customer base. More importantly, Corp Dev is likely to contact customers who are most likely to be happy (e.g., those who recently renewed or expanded). There is no mention of speaking to churned customers or those who declined to renew. The NPS figure is also not verified — it could be self-reported by Borealis.

## 5. Integration Plan: Overly Optimistic Timeline and Retention

- **Claim**: "4-6 month full integration timeline" and "~85% retention expected".
- **Concern**: The pack provides no detail on how this timeline was derived. Integration of data platforms is notoriously complex and often underestimated. The 85% retention figure is based on "conversations with their VP Eng" — not a formal retention plan or employee engagement survey. In acquisitions, especially in competitive markets, key talent often leaves during the uncertainty period. This number feels optimistic without evidence.

## 6. Tech Debt Assessment: "Clean, well-tested" — No Evidence Provided

- **Claim**: "Their codebase is 'modern Python + Postgres + dbt' — clean, well-tested. Engineering review found no concerning patterns."
- **Concern**: This is a qualitative assessment with no supporting data. What does "well-tested" mean? What % of code has unit tests? What's the average test coverage? What's the CI/CD maturity? Without this, it's impossible to assess the true cost of integration or the risk of technical surprises post-close.

## 7. Comparable Transactions: Apples-to-Oranges Comparison

- **Claim**: Borealis at ~7.4x ARR is "in line with the lower comps".
- **Concern**: The comps (Hexa, Aspen, Trellis) are not described in detail. Were they early-stage acquisitions (pre-revenue) or later-stage? What were their growth rates, margins, and profitability profiles? A 7x multiple for a company at 92% growth is very different from 7x for a company at 20% growth. The pack does not normalize for growth rate, which is a critical variable in SaaS valuations.

## 8. Runway and Burn Rate: No Path to Profitability

- **Claim**: 22 months runway at $750K/month burn.
- **Concern**: The pack does not explain how Borealis plans to become profitable. At $9.2M revenue and $750K/month burn, annual burn is $9M — roughly equal to revenue. Even with gross margin of 71%, that leaves little room for sales & marketing and G&A. If Borealis is not close to profitability, the acquirer will need to invest heavily to scale — which could erode the synergy estimates.

## 9. Synergy Estimate: $3.2M Annual Savings — No Breakdown

- **Claim**: "$3.2M annual cost savings from consolidated infra."
- **Concern**: This number is stated but not justified. What infrastructure costs are being consolidated? Is this based on actual usage forecasts or assumptions? A 30% reduction in infra costs is significant and should be backed by a detailed model.

## 10. Valuation: No Discounted Cash Flow (DCF) or Sensitivity Analysis

- **Concern**: The pack relies on comps and a high-level IRR estimate (28-34%) but provides no DCF model or sensitivity analysis. How does the valuation hold up if growth slows to 60% YoY? If margins compress to 60%? If integration costs exceed estimates? Without this, the financial case is incomplete.

## 11. Missing: Customer Concentration Risk

- **Concern**: The pack mentions the five largest customers but does not disclose their contribution to revenue. If the top 5 customers represent >30% of ARR, that is a material concentration risk that should be highlighted.

## 12. Missing: Contract Terms and Renewal Risk

- **Concern**: The pack does not disclose average contract length, renewal terms, or early-termination clauses. Long-term contracts with favorable terms reduce risk; short-term or easily terminable contracts increase it. This is critical for assessing the quality of ARR.

## 13. Missing: Competitive Landscape

- **Concern**: While the pack mentions "minimal overlap" with our offerings, it does not describe the competitive landscape for Borealis. Who are their main competitors? Are they gaining or losing share? What's their pricing power? Without this, it's hard to assess the sustainability of their growth.

## 14. Missing: Legal and Regulatory Risks

- **Concern**: No mention of pending litigation, data privacy compliance (e.g., GDPR, CCPA), or intellectual property risks. For a data analytics company, data rights and privacy compliance are critical.

## 15. Deal Structure: Cash vs. Stock Split "TBD"

- **Concern**: The pack notes Borealis prefers cash-heavy, but the split is not defined. A cash-heavy deal increases financial risk for the acquirer and could strain balance sheet flexibility. This should be addressed before LOI.
