# Key Facts Incorporated in the Brief

Each fact is attributed to its source. Sources:
- [Source 1] = Press Release (company-issued, 2026-01-14)
- [Source 2] = TechCrunch article (2026-01-15)
- [Source 3] = Former employee blog post (2026-02-22)
- [Source 4] = Leaked internal memo via The Information (2026-03-05)
- [Source 5] = SEC Form D filing (2026-01-22)

## Deal Terms
- $84M Series B raised [Source 1, Source 5]
- Led by Lightning Capital [Source 1, Source 5]
- Post-money valuation: $560M [Source 1]
- Previous valuation: $230M (Series A, 2023) [Source 1]
- Total funding to date: $128M [Source 1]
- 7 total investors [Source 5]
- Existing investors (Sequoia, Accel) participated pro-rata [Source 1, Source 5]
- FedEx Ventures invested as strategic [Source 1, Source 5]
- Originally priced at $720M, repriced down after Sundry non-renewal [Source 2]

## Revenue and Financials
- Reported ARR: $42M as of Q4 2025 [Source 1]
- Prior-year ARR: $11M [Source 1]
- Adjusted ARR after churn: $36–37M [Source 2]
- Monthly burn rate: ~$4M/month (mid-2025) [Source 3]
- Monthly revenue: ~$3.5M/month (mid-2025) [Source 3]
- Net burn: ~$500K/month [Source 3, derived]
- $50M credit facility from Silicon Valley Bridge [Source 4]

## Customer Metrics
- 1,400+ e-commerce brands on platform [Source 1]
- Top 5 customers = ~38% of ARR [Source 3]
- Sundry Brands: largest contract, $4.2M ARR, did not renew in November 2025 [Source 2]
- Klatch: second customer lost in December 2025, migrated to competitor [Source 2]
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 [Source 2]
- CEO claims net retention above 110% [Source 2]
- Nimbus Lite tier sunset: ~310 small customers ($5K–$20K ARR each) [Source 4]

## Organizational
- 187 employees (Oakland, Austin, Berlin) [Source 1]
- 22 layoffs in February 2025 (~11% of org), not publicly announced [Source 3]
- Berlin headcount: 41, planned reduction to 28–30 by end Q2 2026 (30% cut) [Source 4]
- International expansion deferred to 2027 [Source 4]
- Berlin reframed as "support hub" [Source 4]

## Strategic
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) [Source 1]
- Platform: warehouse management, carrier orchestration, demand forecasting [Source 1]
- Target: operating-cash-flow breakeven by Q4 2026 [Source 4]
- Runway: 24+ months at current burn, 36+ months with restructuring [Source 4]
- Series C conversations planned from "position of strength" [Source 4]
- Engineering quality praised by former employee; CTO Daniel Wong described as "the real deal" [Source 3]
- Customer love described as genuine by former employee [Source 3]
