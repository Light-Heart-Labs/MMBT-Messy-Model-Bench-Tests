# ADR-001: Recommendation Stance — "Conditional Follow-On"

## Context

The brief requires a clear stance: follow-on, pass, or more diligence needed. The sources present a company with genuine product-market fit but significant operational challenges.

## Decision

**Stance: Conditional follow-on — proceed only with specific diligence requirements.**

## Rationale

A hard "pass" ignores:
- Real product-market fit (1,400 customers, strong engineering)
- Strategic investor (FedEx Ventures) signaling industry validation
- Management's proactive restructuring plan (memo)
- $50M credit facility providing downside protection
- Existing investors (Sequoia, Accel) participating pro-rata

A hard "buy" ignores:
- $5-6M ARR gap between reported and adjusted figures
- Customer concentration (top 5 = 38% of ARR, lost 2 of 5)
- Valuation repricing from $720M to $560M
- Undisclosed layoffs (22 people, not announced publicly)
- Net negative cash flow ($4M burn vs. $3.5M revenue)
- International expansion deferred (contradicts press release narrative)

"More diligence needed" without specifics is hedging. The recommendation is to proceed conditionally, with named diligence requirements that address the specific gaps.

## Alternatives Considered

- **Full pass**: Too conservative given the company's strengths and management's proactive response.
- **Enthusiastic buy**: Irresponsible given the material discrepancies between public narrative and internal reality.
- **Generic "more diligence"**: Fails to provide actionable guidance to the partner.

## Consequences

This stance requires the brief to specify exactly what diligence would change the recommendation to a full pass, making it actionable.
