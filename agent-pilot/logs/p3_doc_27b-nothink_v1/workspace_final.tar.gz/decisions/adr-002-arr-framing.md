# ADR-002: Framing the ARR Discrepancy

## Context

The press release states $42M ARR. TechCrunch reports adjusted ARR of $36-37M after accounting for Sundry ($4.2M) and Klatch churn. The blog post doesn't directly address ARR but confirms the Sundry loss was expected internally.

## Decision

**Lead with the $42M figure as the company's stated number, immediately qualify it with the adjusted range, and attribute both to their sources.**

## Rationale

- The $42M is the company's official number and what appears in the press release and presumably in their financials.
- The $36-37M is from TechCrunch citing "two sources familiar with the company's finances" — credible but not independently verified.
- Presenting both with attribution is honest about source quality.
- The ~$5-6M gap is material and must be highlighted, not buried.

## Language Used

> "ARR is reported at $42M [Source 1], but adjusted for the December departures of Sundry Brands ($4.2M ARR) and Klatch, the run-rate is closer to $36–37M according to TechCrunch sources [Source 2]."

## Alternatives Considered

- **Use only the adjusted number**: Would be inaccurate — the company's official number is $42M.
- **Use only the press release number**: Would be misleading — the churn is material.
- **Average the two**: Would fabricate a number not in any source.
