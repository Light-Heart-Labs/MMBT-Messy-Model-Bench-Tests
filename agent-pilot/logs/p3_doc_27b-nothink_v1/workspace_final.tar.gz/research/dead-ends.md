# Dead Ends — Ideas Considered and Abandoned

## Considered but Rejected

1. **Recommending a full "pass"**: The company has real product-market fit (1,400 customers, strong engineering, strategic investor in FedEx Ventures). A hard pass would ignore the genuine strengths. The burn is manageable with the $50M credit facility and restructuring plan.

2. **Recommending an enthusiastic "buy"**: The churn, customer concentration, valuation repricing, and undisclosed layoffs make an enthusiastic recommendation irresponsible. The gap between the press release narrative and the internal reality is too wide.

3. **Trying to calculate exact runway**: We have burn ($4M/month) and revenue ($3.5M/month) from the blog post, and the memo says 24+ months runway. But we don't have exact cash on hand post-Series B. The memo's "36+ months" with restructuring is management's projection, not an independently verifiable number. Better to cite the memo's own framing.

4. **Speculating on the three new $1M+ contracts**: The CEO told TechCrunch about these, but we have no independent confirmation. Mentioned as a claim, not a fact.

5. **Trying to value the $50M credit facility as "free money"**: The memo explicitly calls it "insurance, not operating capital." It's a backstop, not growth capital. Important distinction.

6. **Focusing heavily on the Berlin office**: While the 30% headcount reduction is notable, the bigger story is the strategic pivot away from international expansion entirely. The Berlin detail supports the broader point.

7. **Calculating exact ARR from Nimbus Lite sunset**: 310 customers × $5K-$20K ARR = $1.55M-$6.2M ARR at risk. This is a real number but it's a range and relatively small compared to the $36-42M total. Worth noting qualitatively but not as a headline number.
