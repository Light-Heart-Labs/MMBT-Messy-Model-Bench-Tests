# Nimbus Logistics — Follow-On Investment Brief

## How to Read This Output

### Primary Deliverable
- **`brief.md`** — The 1-page executive brief (696 words). This is the main output. Read this first.

### Supporting Materials
- **`key-facts.md`** — Every material fact incorporated into the brief, with source attribution. Use this to verify that no numbers were fabricated and all claims trace to the five source documents.
- **`research/notes.md`** — Working notes from reading the five source documents. Includes source-by-source summaries, key tensions identified, and source quality assessments.
- **`research/dead-ends.md`** — Ideas considered and abandoned during analysis, with rationale for why they were rejected.
- **`decisions/adr-001-recommendation-stance.md`** — ADR explaining the choice of "conditional follow-on" as the recommendation stance.
- **`decisions/adr-002-arr-framing.md`** — ADR explaining how the ARR discrepancy between the press release and TechCrunch was framed.

### Source Documents
The five source documents are at `/input/repo/sources.md`:
1. **Source 1** — Company press release (2026-01-14)
2. **Source 2** — TechCrunch article (2026-01-15)
3. **Source 3** — Former employee blog post (2026-02-22)
4. **Source 4** — Leaked internal memo via The Information (2026-03-05)
5. **Source 5** — SEC Form D filing summary (2026-01-22)

### Methodology
The brief was produced by:
1. Reading all five sources independently
2. Identifying tensions and discrepancies between sources
3. Assessing source quality (press release = company spin; TechCrunch = journalistic with cited sources; blog = one person's view; memo = internal but aspirational; SEC filing = regulatory but limited)
4. Synthesizing into a clear recommendation with specific conditions
5. Verifying every number traces to a source document
