# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Recommendation

**Date:** 2026-03-10
**To:** Investment Committee
**Subject:** Series B follow-on evaluation — Nimbus Logistics

---

## Recommendation: Conditional Follow-On

We recommend a follow-on investment in Nimbus Logistics **only if** three specific diligence items are confirmed (detailed below). The company has genuine product-market fit, but the gap between its public narrative and internal reality requires verification before committing capital.

---

## The Good: Real Product-Market Fit

Nimbus is a cloud-native logistics platform serving 1,400+ mid-market e-commerce brands [Source 1]. The product is strong: a former senior engineer described the carrier-orchestration layer as "some of the cleanest distributed-systems code" he's worked on, and called CTO Daniel Wong "the real deal" [Source 3]. Customer relationships appear genuine — the same engineer noted real dependency from the brands using the platform [Source 3].

The investor base is credible. Lightning Capital led the $84M Series B at a $560M post-money valuation, with pro-rata participation from Sequoia and Accel, plus a strategic investment from FedEx Ventures [Source 1, Source 5]. FedEx's involvement signals industry validation beyond financial return.

---

## The Bad: Material Discrepancies

**Revenue is overstated in public materials.** The company reports $42M ARR [Source 1], but sources familiar with Nimbus's finances told TechCrunch that adjusted for the December departures of Sundry Brands ($4.2M ARR) and Klatch, the run-rate is closer to $36–37M [Source 2]. That's a 12–14% gap between the headline number and reality.

**Customer concentration is severe.** According to a former employee, the top five customers accounted for approximately 38% of ARR [Source 3]. Two of those five left in late 2025 — including Sundry, the largest contract [Source 2]. The Sundry loss was not a surprise internally; the timing relative to the fundraise was the problem [Source 3].

**The valuation was repriced down.** Insiders say the round was originally targeted at $720M but was repriced to $560M after the Sundry non-renewal became known to the lead investor in early December [Source 2].

**The company is net-negative on cash.** A former employee reported monthly burn of approximately $4M against roughly $3.5M in monthly revenue (mid-2025) [Source 3].

**Layoffs were not disclosed.** The company quietly cut 22 people (~11% of the org) in February 2025, primarily in customer success and business development, without public announcement [Source 3].

---

## The Ugly: Strategic Retreat

A leaked internal memo from CEO Mira Patel (dated February 28, 2026) reveals a significant pivot that contradicts the press release narrative [Source 4]:

- **International expansion is deferred to 2027**, despite the press release highlighting "expansion into international markets" as a key use of proceeds [Source 1, Source 4].
- **Berlin headcount will be cut by 30%** (from 41 to 28–30 by end of Q2 2026), and the office will be reframed as a "support hub" [Source 4].
- **The Nimbus Lite tier is being sunset**, affecting ~310 small customers ($5K–$20K ARR each) [Source 4].
- A **$50M credit facility from Silicon Valley Bridge** has been secured, described as "insurance, not operating capital" [Source 4].

The memo targets operating-cash-flow breakeven by Q4 2026, the trigger for Series C conversations [Source 4]. At current burn, the company has 24+ months of runway; with restructuring, management projects 36+ months [Source 4].

---

## Three Conditions for Proceeding

1. **Verify adjusted ARR and net retention.** Confirm the $36–37M adjusted run-rate [Source 2] and independently verify the CEO's claim of 110%+ net retention and three new $1M+ contracts in Q1 [Source 2].

2. **Confirm the restructuring plan is on track.** The Berlin reduction, Nimbus Lite sunset, and burn-rate reduction need verification against actuals, not just the memo's projections [Source 4].

3. **Understand the credit facility terms.** The $50M facility from Silicon Valley Bridge is a material part of the capital structure [Source 4]. We need the terms, covenants, and any equity kickers.

---

## Bottom Line

Nimbus is a real company with a real product, credible founders, and a strong investor base. But the public narrative is materially ahead of the operational reality. The follow-on makes sense **if** the restructuring plan is working and the revenue gap is closing. If adjusted ARR is below $35M or burn hasn't come down, pass.
