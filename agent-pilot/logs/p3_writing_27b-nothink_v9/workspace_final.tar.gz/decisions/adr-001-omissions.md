# ADR-001: Omission Decisions Per Audience

## Decision: What to omit from the CEO brief

**Context:** The source memo contains extensive technical detail about the rate-limiter mechanism, named individuals (Marcus, Priya, Sarah), and informal asides ("sorry Sarah, you were right").

**Decision:** The CEO brief omits:
- All named individuals (Marcus, Priya, Sarah) — the CEO needs outcomes, not personnel details.
- The technical explanation of the fraction-against-MAX mechanism — replaced with a plain-language description ("triggered an internal safeguard").
- The "sorry Sarah" aside — inappropriate for board-prep material.
- The runbook discussion — too granular for a 5-minute read.

**Rationale:** The audience brief explicitly prohibits engineering jargon and informal apologies. The CEO needs the signal (second outage in 90 days), the scope (11,400 accounts, 28 enterprise), and the remediation plan.

---

# ADR-002: Omission Decisions for Customer Email

**Context:** The source memo names Marcus as the deployer, references the "second outage in 90 days" board signal, and discusses internal process failures candidly.

**Decision:** The customer email omits:
- Marcus's name — the brief explicitly prohibits blaming a named individual.
- The "second outage in 90 days" framing — this is an internal board signal, not customer-facing.
- The internal candor about Sarah's unaddressed warning — this would undermine trust.
- Technical jargon (rate limiter, MAX, throttling internals) — replaced with "safeguard that blocked authentication requests."
- The runbook gap discussion — not relevant to customers.

**Rationale:** The customer email must build trust, not expose internal dysfunction. The brief requires warmth, accountability, and an explicit SLA-credit offer.

---

# ADR-003: Omission Decisions for Legal Summary

**Context:** The source memo contains informal language, speculation about future outages, and detailed engineering remediation plans.

**Decision:** The legal summary omits:
- All named individuals — counsel needs facts, not personnel.
- Speculation about a potential third outage — not relevant to SLA credit determination.
- Engineering remediation details (staged rollout, runbook updates) — irrelevant to counsel's review.
- Marketing language and apologies — the brief requires dispassionate, factual tone.
- The "sorry Sarah" and other informal asides.

**Rationale:** The legal summary must be a precise, dispassionate enumeration of facts relevant to SLA-credit determinations. Counsel uses this to advise finance on credit processing.

---

# ADR-004: Use of "support@[company].com" as Contact Path

**Context:** The source memo mentions CSMs and support tickets but does not provide a specific email address or contact path for customers.

**Decision:** Used "support@[company].com" as a placeholder contact path in the customer email, since the brief requires "a contact path (CSM, support, named exec)." The source memo references "support tickets" and "CSMs" as existing channels.

**Rationale:** The brief requires a contact path. The source memo confirms CSMs and support exist as channels. A placeholder email is appropriate since no specific address was provided in the source.
