# Outage Brief — Friday, 14:11–18:24 UTC

**Summary:** A configuration change to our authentication service caused our primary API to return errors for approximately 4 hours, impacting 11,400 customer accounts.

**Impact:** 28 enterprise accounts experienced revenue loss during business hours. Four customers had downstream automation failures requiring manual remediation. We received 217 support tickets and 31 refund requests.

**Root Cause:** A configuration update to our authentication service inadvertently triggered an internal safeguard that blocked all authentication requests. Without successful authentication, our API could not process requests. The change was reverted at 18:18 UTC; service fully recovered by 18:24 UTC.

**Board Signal:** This is the second outage of this duration in 2026, occurring within 90 days of the February database incident. A third would warrant a full reliability program review.

**Remediations Underway:**
1. Staged, per-region rollout for configuration changes (prevents simultaneous global exposure) — estimated 1 sprint.
2. Fix the internal safeguard to reference live configuration rather than a fixed value — estimated 2 weeks.
3. Status-page monitoring corrected to reflect actual customer-facing endpoints (already deployed).
4. New protocol: on-call lead must issue an acknowledgment within 15 minutes of confirmed impact, regardless of root-cause status.

**Financial Exposure:** SLA credits are owed to affected accounts per our 99.9% monthly uptime commitment. Legal and finance are processing 31 refund requests case by case.
