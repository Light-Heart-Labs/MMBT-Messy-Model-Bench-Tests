# Incident Rewrite Output

This directory contains three audience-tailored rewrites of the internal outage memo (`/input/repo/draft_memo.md`), produced according to the specifications in `/input/repo/audience_briefs.json`.

## Files

| File | Audience | Word Count | Limit |
|------|----------|------------|-------|
| `ceo_brief.md` | CEO / Board prep | 211 | ≤250 |
| `customer_email.md` | Affected customers | 298 | ≤350 |
| `legal_summary.md` | In-house counsel | 291 | ≤400 |

Each rewrite preserves all factual content from the source memo without inventing data. Numbers, times, and account counts are drawn exclusively from the original draft.

## Supporting Materials

- `decisions/adr-001-omissions.md` — ADR-style records documenting non-obvious omission choices per audience.
- `research/notes.md` — Working notes with extracted facts and audience-specific decision rationale.

## Constraints Enforced

- **CEO brief:** No engineering jargon, no named individuals, no informal asides. Includes the second-in-90-days board signal.
- **Customer email:** No named engineer, no "second outage in 90 days" framing, no internal candor. Includes explicit SLA-credit offer and contact path.
- **Legal summary:** No speculation, no named employees, no marketing language, no remediation details. Uses "incident" not "outage."
