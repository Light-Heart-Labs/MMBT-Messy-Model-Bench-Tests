# Incident Summary — SLA Credit Review

**Incident Window:** 14:11 UTC to 18:24 UTC, Friday (approximately 4 hours 13 minutes).

**Scope of Impact:**
- 11,400 customer accounts experienced service disruption.
- 28 enterprise accounts (those with named Customer Success Managers) experienced revenue impact during business hours.
- 4 accounts had confirmed downstream automation failures requiring manual data cleanup.
- 217 inbound support tickets were received.
- 31 refund requests have been submitted to date (a mix of SLA-credit-only requests and full-month credit requests).

**Contractual SLA:** The company's standard SLA provides 99.9% monthly uptime, with service credits for breach. Based on the incident duration and the number of affected accounts, the SLA threshold was nominally breached for the impacted accounts.

**Credit Obligation Assessment:**
- For the 28 enterprise accounts with confirmed revenue impact: SLA credits are owed per the Master Service Agreement. These should be processed as contractual obligations.
- For the 4 accounts with downstream automation harm: SLA credits are owed, and additional remediation support (data cleanup) is recommended as a separate customer-relationship matter.
- For the remaining approximately 11,368 accounts: SLA credits should be issued to any account that explicitly requests one, provided the breach can be demonstrated.
- For accounts requesting credits without a demonstrated SLA breach: these are relationship matters, not contractual obligations. Finance and Customer Success should handle these case by case.

**Recommendation:** Do not contest credit requests where the SLA was clearly breached. Process contractual credits through the standard credit-processing batch. Route relationship-driven requests to Finance and Customer Success for individual review.

**Legal Note:** The incident was caused by a configuration change to the authentication service that inadvertently triggered an internal safeguard. No third-party action or force majeure is implicated.
