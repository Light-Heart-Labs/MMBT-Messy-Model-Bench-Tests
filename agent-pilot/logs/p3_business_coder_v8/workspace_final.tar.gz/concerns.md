# Concerns with the Borealis Acquisition Deal Pack

## 1. Overstated Strategic Rationale

- **Claim**: "Borealis would extend our analytics surface area into mid-market e-commerce, a segment we currently service only via partner integrations."
- **Concern**: This is presented as a clear strategic gap, but the pack provides no data on the size of that segment, our current revenue from partner-served mid-market e-commerce, or whether our existing partners are actually failing to serve that segment. Is this a new market or just a channel we want to control? The pack doesn't distinguish.

## 2. Revenue Recognition vs. Cash Collection

- **Claim**: Revenue (recognized GAAP) $9.2M in FY2025.
- **Concern**: The pack does not disclose cash collections or deferred revenue. A SaaS company with 80% YoY revenue growth could be recognizing revenue on long-term contracts with extended payment terms, or it could be recognizing revenue on churned customers (e.g., if contracts are backfilled). Without cash collections data, we cannot assess true liquidity or near-term burn sustainability.

## 3. Net Retention vs. Logo Retention Discrepancy

- **Claim**: Net retention 118%, Logo retention 91%.
- **Concern**: A 27-point spread is unusually high for a Series-A company. This could indicate massive expansion from a few key customers (concentration risk) or aggressive revenue recognition on expansion. The pack does not explain this gap. If the 9% churned customers represent a disproportionate share of ARR, the underlying health is worse than the headline numbers suggest.

## 4. Customer Testimonials: Small Sample, High Variance

- **Claim**: 4 of 5 top customers willing to be quoted, NPS in high 40s.
- **Concerns**:
  - Sample size of 5 is extremely small for a 280-customer base. One or two outliers can skew perception.
  - The pack does not disclose how NPS was calculated (e.g., base size, timing, methodology).
  - Testimonials are curated and positive. No mention of churned customers or negative reference calls.

## 5. Tech Debt Assessment: "Clean, well-tested" — No Evidence Provided

- **Claim**: "Their codebase is 'modern Python + Postgres + dbt' — clean, well-tested. Engineering review found no concerning patterns."
- **Concern**: This is a qualitative statement with no supporting evidence. No metrics on test coverage, CI/CD uptime, incident frequency, or technical debt score. Engineering review is cited but not shown. A "modern stack" does not guarantee technical health.

## 6. Integration Plan: Overly Optimistic Timeline and Retention

- **Claim**: 4-6 month full integration timeline; ~85% retention expected.
- **Concerns**:
  - No breakdown of integration milestones or dependencies. What happens if the 12-month Aurora sunset is delayed? Customer churn risk increases.
  - 85% retention is assumed "based on conversations with their VP Eng" — not based on historical retention data from similar integrations.
  - Relocating the entire team to HQ is a major cultural disruption. The pack does not address how this will be managed or what happens if key engineers decline to relocate.

## 7. Comparable Transactions: Misleading Comparison

- **Claim**: Borealis at ~7.4x ARR is "in line with the lower comps."
- **Concerns**:
  - Comps include companies acquired by Salesforce, Snowflake, and HubSpot — all strategic acquirers with different valuation criteria than our company.
  - No disclosure of deal terms (e.g., earnouts, holdbacks, liabilities assumed).
  - Borealis is at an earlier stage (Series-A) than most comps. Stage discount is not applied.

## 8. Burn Rate and Runway: Misaligned with Growth Narrative

- **Claim**: Burn rate $750K/month, 22 months runway at last cap raise.
- **Concern**: If Borealis is growing revenue at 80% YoY and has strong net retention, why is it burning cash at such a high rate? The pack does not explain unit economics (e.g., CAC, payback period). High burn with high growth is acceptable only if CAC payback is short — this is not disclosed.

## 9. Valuation: No Discounted Cash Flow or Scenario Analysis

- **Concern**: The pack relies solely on comps and ARR multiples. No DCF, no scenario analysis (e.g., 20% slower growth, 10% higher churn), and no sensitivity to integration delays. The "28-34% IRR" claim is stated but not modeled.

## 10. Missing Key Risks Section

- **Concern**: The pack does not explicitly list top risks (e.g., regulatory, data privacy, key person risk beyond CTO, integration failure). Risk mitigation plans are not outlined.

## 11. Financials: No Breakdown of Revenue Quality

- **Concern**: No disclosure of:
  - Recurring vs. non-recurring revenue
  - Contract duration (e.g., 1-year vs. 3-year commitments)
  - Renewal timing (e.g., 30% up for renewal in Q3 FY26)
  - Customer concentration (top 10 customers % of ARR)

## 12. Product Roadmap: No Input from Our Product Team

- **Claim**: Our PM team validated Borealis features as differentiated.
- **Concern**: No evidence of this validation. No disclosure of how "differentiated" was measured (e.g., feature matrix, customer surveys). Also, no disclosure of whether our existing roadmap already has similar features in development.
