# Executive Committee Review: Borealis Analytics Acquisition

**Date:** 2026-04-16  
**Subject:** Recommendation on Project Lighthouse (Borealis Analytics)

## Recommendation

**HOLD** on issuing the LOI at $84M.

The Corp Dev team’s recommendation is well-structured and highlights compelling strategic and financial positives. However, the deal pack is an advocacy document, not a balanced risk assessment. Without additional transparency on three critical areas, approving the LOI would be premature and expose us to material, unquantified risk.

## Strengths Acknowledged

The pack rightly emphasizes Borealis’s strong product-market fit (80% YoY ARR growth, 118% net retention), clean engineering (modern stack, no critical attrition), and in-line valuation (~7.4x ARR vs. comps at 7-12x). The strategic rationale—extending our analytics surface into mid-market e-commerce—is valid and aligns with our growth goals.

## Top Concerns

1. **Financial Transparency Gap**  
   Per the financials table, Borealis reports $9.2M in recognized GAAP revenue and $750K/month burn. But the pack omits cash collections, deferred revenue, and CAC payback. A SaaS company growing at 80% could be recognizing revenue on churned customers or extending payment terms. Without this data, we cannot assess true liquidity or unit economics. *If cash collections are <90% of revenue or CAC payback exceeds 18 months, the deal becomes financially unattractive.*

2. **Customer Health: Small Sample, Unexplained Discrepancy**  
   The pack cites NPS in the high 40s from 5 top customers and logo retention of 91%. But a 27-point gap between net retention (118%) and logo retention is unusually high for a Series-A company. This could indicate massive expansion from a few customers (concentration risk) or aggressive revenue recognition. No churned customers were referenced. *If top 10 customers represent >40% of ARR, the base is fragile.*

3. **Integration Risk: Overly Optimistic Assumptions**  
   The pack assumes a 4-6 month integration and ~85% team retention “based on conversations with VP Eng.” No detailed roadmap, dependency map, or failure scenario is provided. Relocating the entire team to HQ is a major cultural disruption, yet no retention risk assessment is shared. *If the Aurora sunset is delayed by 3+ months, customer churn risk increases significantly.*

## Diligence Asks to Change Stance

I would change my recommendation to **PROCEED** if, within 2 weeks, we can confirm:

1. **Finance**: Cash collections ≥ 95% of recognized revenue and CAC payback < 12 months.
2. **Product**: No material churn concentration (top 10 customers < 40% of ARR) and stable NPS trend.
3. **Engineering**: Test coverage ≥ 80% and CI/CD uptime ≥ 99% (objective metrics, not qualitative statements).
4. **Integration**: A detailed risk mitigation plan with clear milestones and a “failure” scenario (e.g., delayed sunset).
5. **Valuation**: IRR ≥ 25% in a downside scenario (e.g., 20% slower growth, 10% higher churn).

## Conclusion

The Borealis acquisition has clear strategic merit, but the deal pack does not provide sufficient evidence to de-risk the decision. Approving the LOI at this stage would be a leap of faith, not a data-driven allocation of $84M. I recommend issuing a formal hold, approving the 2-week diligence sprint (see `asks.md`), and reconvening on 2026-04-28 with updated data.

If the diligence confirms the pack’s positives, I will support proceeding. If not, I recommend passing.

---

*Prepared by Executive Committee Member. Not a ratification of Corp Dev’s recommendation.*
