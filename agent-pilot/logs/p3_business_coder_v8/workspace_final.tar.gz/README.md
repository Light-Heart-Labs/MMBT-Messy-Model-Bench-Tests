# Borealis Analytics Acquisition Review

## Overview

This repository contains the executive committee review of the Borealis Analytics acquisition deal pack.

## Files

- `memo.md` — The 1-page review memo (primary deliverable).
- `concerns.md` — A longer enumeration of every concern considered.
- `asks.md` — The diligence-ask list for the next 2 weeks.
- `decisions/` — ADRs for judgment calls.

## Key Takeaways

- **Recommendation**: HOLD on issuing LOI at $84M.
- **Reason**: Deal pack is advocacy-focused, lacks transparency on financials, customer health, and technical risk.
- **Next Steps**: 2-week diligence sprint to address top concerns.

## Timeline

- Deal pack received: 2026-04-15
- Memo due: 2026-04-16
- LOI deadline: 2026-04-30
