# Diligence Asks for the Next 2 Weeks

## 1. Financial Deep Dive (Owner: Finance; Deadline: 2026-04-25)

- [ ] Provide cash collections for FY2025 and Q1 FY2026 vs. recognized revenue. Explain any material differences.
- [ ] Provide deferred revenue balance as of 2026-03-31 and breakdown of revenue recognition policy.
- [ ] Provide CAC, payback period, and cohort churn analysis (not just logo retention).
- [ ] Provide revenue breakdown: recurring vs. non-recurring, contract duration, top 10 customer concentration.

## 2. Customer Health & Churn Analysis (Owner: Product; Deadline: 2026-04-25)

- [ ] Provide full list of 280 customers with ARR tiers, renewal dates, and contract terms.
- [ ] Conduct reference calls with at least 5 churned customers (if any) and 5 mid-tier customers (not top 5).
- [ ] Provide NPS methodology, sample size, and trend data (not just a single snapshot).

## 3. Technical Debt Assessment (Owner: Engineering; Deadline: 2026-04-25)

- [ ] Provide test coverage metrics (unit, integration, e2e) and CI/CD pipeline metrics (uptime, build time, failure rate).
- [ ] Provide incident history (MTTR, MTBF) for the last 12 months.
- [ ] Conduct a technical debt scorecard (e.g., SonarQube or similar) and share results.

## 4. Integration Risk Assessment (Owner: Corp Dev + Integration Lead; Deadline: 2026-04-25)

- [ ] Provide a detailed integration roadmap with milestones, dependencies, and risk mitigation plans.
- [ ] Conduct a retention risk assessment for each Borealis team member (not just VP Eng).
- [ ] Provide a "integration failure" scenario plan (e.g., if Aurora sunset is delayed by 3+ months).

## 5. Valuation & Deal Structuring (Owner: Finance + Corp Dev; Deadline: 2026-04-25)

- [ ] Provide a DCF model with base, upside, and downside scenarios (e.g., 20% growth variance, 5% churn variance).
- [ ] Provide sensitivity analysis on integration synergy realization (e.g., what if only $2M of $3.2M savings materialize?).
- [ ] Provide deal structure options (e.g., earnouts, holdbacks, stock vs. cash split) and their impact on IRR.

## 6. Legal & Compliance (Owner: Legal; Deadline: 2026-04-25)

- [ ] Provide a summary of key customer contract terms (e.g., termination rights, data portability, IP assignments).
- [ ] Provide a data privacy compliance assessment (e.g., GDPR, CCPA, SOC 2).
- [ ] Provide key person risk assessment (e.g., CTO employment contract, non-compete status).

## 7. Product Integration Assessment (Owner: Product; Deadline: 2026-04-25)

- [ ] Provide a feature overlap analysis with our roadmap (not just "12% overlap").
- [ ] Provide a customer migration plan (e.g., data transfer, training, support handoff).
- [ ] Provide a sunset timeline with customer communication plan.

## 8. Management Review (Owner: CEO; Deadline: 2026-04-28)

- [ ] Present final recommendation with updated risk assessment.
- [ ] Present deal structure recommendations (e.g., earnouts, holdbacks).
- [ ] Present post-close integration organization chart and leadership plan.
