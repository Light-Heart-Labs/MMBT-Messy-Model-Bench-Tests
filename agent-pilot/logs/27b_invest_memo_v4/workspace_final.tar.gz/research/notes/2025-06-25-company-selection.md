# Company Selection Research Session - 2025-06-25

## Objective
Select a publicly traded US company with market cap between $1B and $10B for investment memo.

## Criteria
- Market cap: $1B - $10B
- US-listed (NYSE, NASDAQ)
- Sufficient public data availability (SEC filings, earnings calls)
- Interesting investment thesis potential
- Not too complex (avoid heavy financials, complex holding cos)

## Candidates Considered
1. **Hims & Hers Medical (HIMS)** - Telehealth, direct-to-consumer
2. **SoundHound AI (SOUN)** - AI voice recognition
3. **BigBear.ai (BBAI)** - AI analytics for government
4. **Rocket Lab (RKLB)** - Space launch services
5. **Upstart (UPST)** - AI lending platform
6. **Opendoor (OPEN)** - Real estate tech
7. **Instacart (CART)** - Grocery delivery

## Selection Process
Need to verify market caps and data availability. Will check via web scraping and SEC EDGAR.

## Next Steps
- Check market caps of candidates
- Verify SEC filing availability
- Pick the most interesting one with clean data
