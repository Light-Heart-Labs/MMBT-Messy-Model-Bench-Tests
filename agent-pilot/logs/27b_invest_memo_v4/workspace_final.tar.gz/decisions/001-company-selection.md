# ADR-001: Company Selection — Hims & Hers Medical (HIMS)

**Date:** 2025-06-25
**Status:** Accepted

## Context
Need to select a US publicly traded company with $1B-$10B market cap for investment memo.

## Alternatives Considered
| Ticker | Company | Market Cap | Notes |
|--------|---------|-----------|-------|
| HIMS | Hims & Hers Medical | $6.97B | DTC telehealth, weight loss, mental health |
| SOUN | SoundHound AI | $3.49B | AI voice, but very early stage |
| BBAI | BigBear.ai | $1.76B | Gov AI contracts, limited data |
| UPST | Upstart | $3.21B | AI lending, cyclical |
| OPEN | Opendoor | $5.29B | Real estate tech, highly cyclical |
| CART | Instacart | $9.98B | Grocery delivery, competitive |
| CELH | Celsius Holdings | $8.89B | Beverage, well-covered |
| S | SentinelOne | $4.85B | Cybersecurity, competitive |
| AI | C3.ai | $1.26B | AI software, unprofitable |
| BROS | Dutch Bros | $7.31B | Coffee chain, well-covered |

## Decision
**Selected: Hims & Hers Medical (HIMS)**

## Rationale
1. **Clear business model:** DTC telehealth platform with multiple product categories (hair loss, weight loss, sexual health, mental health, skincare)
2. **Growth trajectory:** Revenue growing rapidly, approaching profitability
3. **Weight loss angle:** GLP-1 weight loss drugs represent a massive TAM with HIMS positioned as a digital-first access point
4. **Data availability:** Regular SEC filings, earnings calls, clear financials
5. **Potential mispricing:** Market may be underestimating the weight loss business scalability or overestimating competitive threats
6. **Interesting competitive dynamics:** Competing with traditional pharmacies, other telehealth platforms, and direct GLP-1 manufacturers

## Rejected Alternatives
- **SOUN/BBAI:** Too early stage, limited financial history
- **UPST:** Highly cyclical with lending, hard to model
- **OPEN:** Real estate cycle dependency makes it less interesting
- **CART:** Well-covered by sell-side, hard to find edge
- **CELH/BROS:** Consumer staples, well-covered
- **S:** Cybersecurity is competitive, many players
- **AI:** No path to profitability visible
