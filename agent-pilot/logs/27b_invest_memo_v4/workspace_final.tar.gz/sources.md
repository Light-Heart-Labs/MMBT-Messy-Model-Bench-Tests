# Sources

All URLs fetched during research, with timestamps and content hashes.

