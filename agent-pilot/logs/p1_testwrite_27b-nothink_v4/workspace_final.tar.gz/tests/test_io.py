"""Tests for io.py — file loading helpers.

These tests exercise the 0%-coverage io module, covering:
- load: empty files, files without trailing newline, mixed valid/invalid lines
- load_iter: generator behavior, empty files
"""
import os
import tempfile

from logalyzer.io import load, load_iter
from logalyzer.parser import LogEntry


def _write_log(content):
    """Write content to a temp file and return its path."""
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False)
    f.write(content)
    f.close()
    return f.name


# ── load ────────────────────────────────────────────────────────────────────


def test_load_empty_file():
    """An empty file should return an empty list."""
    path = _write_log("")
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_single_valid_line():
    """A file with one valid log line should return one entry."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
    path = _write_log(line)
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_no_trailing_newline():
    """A file without a trailing newline should still parse the last line."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    path = _write_log(line)
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_mixed_valid_invalid_lines():
    """A file with mixed valid and invalid lines should only return valid entries."""
    content = (
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
        'this is garbage\n'
        '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512\n'
        '\n'
        'more garbage\n'
    )
    path = _write_log(content)
    try:
        result = load(path)
        assert len(result) == 2
        assert result[0].ip == "127.0.0.1"
        assert result[1].ip == "192.168.1.1"
    finally:
        os.unlink(path)


def test_load_multiple_valid_lines():
    """A file with multiple valid lines should return all entries."""
    lines = [
        '10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "GET /a HTTP/1.1" 200 100\n',
        '10.0.0.2 - - [01/Jan/2026:00:01:00 +0000] "GET /b HTTP/1.1" 200 200\n',
        '10.0.0.3 - - [01/Jan/2026:00:02:00 +0000] "GET /c HTTP/1.1" 200 300\n',
    ]
    path = _write_log("".join(lines))
    try:
        result = load(path)
        assert len(result) == 3
        ips = [e.ip for e in result]
        assert ips == ["10.0.0.1", "10.0.0.2", "10.0.0.3"]
    finally:
        os.unlink(path)


def test_load_all_invalid_lines():
    """A file with only invalid lines should return an empty list."""
    content = "garbage line 1\ngarbage line 2\ngarbage line 3\n"
    path = _write_log(content)
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_returns_log_entry_objects():
    """load should return LogEntry objects, not dicts or strings."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
    path = _write_log(line)
    try:
        result = load(path)
        assert all(isinstance(e, LogEntry) for e in result)
    finally:
        os.unlink(path)


# ── load_iter ───────────────────────────────────────────────────────────────


def test_load_iter_empty_file():
    """load_iter on an empty file should yield nothing."""
    path = _write_log("")
    try:
        result = list(load_iter(path))
        assert result == []
    finally:
        os.unlink(path)


def test_load_iter_single_line():
    """load_iter on a file with one valid line should yield one entry."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
    path = _write_log(line)
    try:
        result = list(load_iter(path))
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_iter_mixed_lines():
    """load_iter should skip invalid lines and yield only valid entries."""
    content = (
        '10.0.0.1 - - [01/Jan/2026:00:00:00 +0000] "GET / HTTP/1.1" 200 100\n'
        'invalid line\n'
        '10.0.0.2 - - [01/Jan/2026:00:01:00 +0000] "GET / HTTP/1.1" 200 200\n'
    )
    path = _write_log(content)
    try:
        result = list(load_iter(path))
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_is_generator():
    """load_iter should return a generator, not a list."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
    path = _write_log(line)
    try:
        result = load_iter(path)
        # Should be a generator
        assert hasattr(result, "__next__")
        assert hasattr(result, "__iter__")
    finally:
        os.unlink(path)


def test_load_iter_no_trailing_newline():
    """load_iter should handle files without trailing newlines."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    path = _write_log(line)
    try:
        result = list(load_iter(path))
        assert len(result) == 1
    finally:
        os.unlink(path)
