"""Edge case tests for filters.py — filter predicates.

These tests cover edge cases not tested by the original test_filters.py:
- expression_filter with invalid expressions
- combine_and with no predicates, single predicate
- Invalid regex patterns
- date_range with only since or only until
- ip_allowlist with set (not just list)
"""
from datetime import datetime, timezone

import pytest

from logalyzer.filters import (
    combine_and,
    date_range_filter,
    expression_filter,
    ip_allowlist_filter,
    status_filter,
    url_regex_filter,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── expression_filter ───────────────────────────────────────────────────────


def test_expression_filter_basic():
    """expression_filter should evaluate Python expressions against entry."""
    pred = expression_filter("entry.status >= 200")
    assert pred(_entry(status=200)) is True
    assert pred(_entry(status=199)) is False


def test_expression_filter_complex():
    """expression_filter should handle complex boolean expressions."""
    pred = expression_filter("entry.status >= 500 and entry.method == 'GET'")
    assert pred(_entry(status=500, method="GET")) is True
    assert pred(_entry(status=500, method="POST")) is False
    assert pred(_entry(status=200, method="GET")) is False


def test_expression_filter_attribute_access():
    """expression_filter should allow access to all LogEntry attributes."""
    pred = expression_filter("entry.ip == '10.0.0.1'")
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="10.0.0.2")) is False


def test_expression_filter_bytes_comparison():
    """expression_filter should work with bytes field."""
    pred = expression_filter("entry.bytes > 50")
    assert pred(_entry(bytes=100)) is True
    assert pred(_entry(bytes=50)) is False


def test_expression_filter_invalid_expression_raises():
    """expression_filter with invalid Python should raise when called."""
    pred = expression_filter("entry.nonexistent_field")
    with pytest.raises(AttributeError):
        pred(_entry())


def test_expression_filter_builtins_restricted():
    """expression_filter should restrict builtins (security)."""
    pred = expression_filter("__import__('os').system('echo pwned')")
    # Should raise because __builtins__ is empty
    with pytest.raises(NameError):
        pred(_entry())


# ── combine_and ─────────────────────────────────────────────────────────────


def test_combine_and_no_predicates():
    """combine_and with no predicates should return True for all entries."""
    pred = combine_and()
    assert pred(_entry()) is True


def test_combine_and_single_predicate():
    """combine_and with one predicate should behave like that predicate."""
    pred = combine_and(status_filter(200))
    assert pred(_entry(status=200)) is True
    assert pred(_entry(status=404)) is False


def test_combine_and_all_match():
    """combine_and should return True when all predicates match."""
    pred = combine_and(
        status_filter(200),
        expression_filter("entry.method == 'GET'"),
    )
    assert pred(_entry(status=200, method="GET")) is True


def test_combine_and_one_fails():
    """combine_and should return False when any predicate fails."""
    pred = combine_and(
        status_filter(200),
        expression_filter("entry.method == 'POST'"),
    )
    assert pred(_entry(status=200, method="GET")) is False


def test_combine_and_short_circuits():
    """combine_and should short-circuit on first failure."""
    call_count = [0]

    def counting_pred(entry):
        call_count[0] += 1
        return False

    def second_pred(entry):
        return True

    pred = combine_and(counting_pred, second_pred)
    pred(_entry())
    # second_pred should not be called due to short-circuit
    assert call_count[0] == 1


# ── date_range_filter edge cases ────────────────────────────────────────────


def test_date_range_only_since():
    """date_range_filter with only since should filter from that date forward."""
    since = datetime(2026, 1, 15, tzinfo=timezone.utc)
    pred = date_range_filter(since, None)
    assert pred(_entry(timestamp=datetime(2026, 1, 15, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2026, 1, 14, tzinfo=timezone.utc))) is False
    assert pred(_entry(timestamp=datetime(2026, 12, 31, tzinfo=timezone.utc))) is True


def test_date_range_only_until():
    """date_range_filter with only until should filter up to that date."""
    until = datetime(2026, 1, 15, tzinfo=timezone.utc)
    pred = date_range_filter(None, until)
    assert pred(_entry(timestamp=datetime(2026, 1, 15, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2026, 1, 16, tzinfo=timezone.utc))) is False
    assert pred(_entry(timestamp=datetime(2025, 1, 1, tzinfo=timezone.utc))) is True


def test_date_range_both_none():
    """date_range_filter with both None should match everything."""
    pred = date_range_filter(None, None)
    assert pred(_entry()) is True
    assert pred(_entry(timestamp=datetime(2020, 1, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2030, 12, 31, tzinfo=timezone.utc))) is True


# ── url_regex_filter edge cases ─────────────────────────────────────────────


def test_url_regex_invalid_pattern_raises():
    """url_regex_filter with invalid regex should raise."""
    with pytest.raises(Exception):  # re.error
        url_regex_filter("[invalid")


def test_url_regex_case_sensitive():
    """url_regex_filter should be case-sensitive by default."""
    pred = url_regex_filter(r"^/API")
    assert pred(_entry(url="/API/data")) is True
    assert pred(_entry(url="/api/data")) is False


def test_url_regex_special_chars():
    """url_regex_filter should handle URLs with special characters."""
    pred = url_regex_filter(r"^/api/\d+")
    assert pred(_entry(url="/api/123")) is True
    assert pred(_entry(url="/api/abc")) is False


# ── ip_allowlist_filter edge cases ──────────────────────────────────────────


def test_ip_allowlist_with_set():
    """ip_allowlist_filter should work with a set (not just list)."""
    pred = ip_allowlist_filter({"10.0.0.1", "10.0.0.2"})
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="10.0.0.3")) is False


def test_ip_allowlist_empty():
    """ip_allowlist_filter with empty allowlist should match nothing."""
    pred = ip_allowlist_filter([])
    assert pred(_entry()) is False


def test_ip_allowlist_with_tuple():
    """ip_allowlist_filter should work with a tuple."""
    pred = ip_allowlist_filter(("10.0.0.1",))
    assert pred(_entry(ip="10.0.0.1")) is True


# ── status_filter edge cases ────────────────────────────────────────────────


def test_status_filter_zero_status():
    """status_filter should work with status 0 (edge case)."""
    pred = status_filter(0)
    assert pred(_entry(status=0)) is True
    assert pred(_entry(status=200)) is False


def test_status_filter_large_status():
    """status_filter should work with large status codes."""
    pred = status_filter(999)
    assert pred(_entry(status=999)) is True
