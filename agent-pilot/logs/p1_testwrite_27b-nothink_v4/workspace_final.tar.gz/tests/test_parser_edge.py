"""Edge case tests for parser.py — timestamp parsing and line parsing.

These tests cover edge cases not tested by the original test_parser.py:
- Various timezone offsets (positive, negative, zero)
- Malformed timestamps
- parse_lines generator behavior
- Edge cases in byte parsing
"""
from datetime import datetime, timezone

import pytest

from logalyzer.parser import parse_line, parse_lines, parse_timestamp


def test_parse_timestamp_positive_offset():
    """A positive timezone offset should subtract from the time to get UTC."""
    # 10:00 +0500 → 05:00 UTC
    ts = parse_timestamp("01/Jan/2026:10:00:00 +0500")
    assert ts.hour == 5
    assert ts.tzinfo is timezone.utc


def test_parse_timestamp_negative_offset():
    """A negative timezone offset should add to the time to get UTC."""
    # 10:00 -0500 → 15:00 UTC
    ts = parse_timestamp("01/Jan/2026:10:00:00 -0500")
    assert ts.hour == 15
    assert ts.tzinfo is timezone.utc


def test_parse_timestamp_zero_offset():
    """A +0000 offset should preserve the time."""
    ts = parse_timestamp("01/Jan/2026:10:00:00 +0000")
    assert ts.hour == 10
    assert ts.tzinfo is timezone.utc


def test_parse_timestamp_malformed_raises():
    """A malformed timestamp should raise ValueError."""
    with pytest.raises(ValueError, match="unrecognized timestamp format"):
        parse_timestamp("not-a-timestamp")


def test_parse_timestamp_missing_timezone_raises():
    """A timestamp without timezone should raise ValueError."""
    with pytest.raises(ValueError):
        parse_timestamp("01/Jan/2026:10:00:00")


def test_parse_line_empty_string():
    """parse_line with empty string should return None."""
    assert parse_line("") is None


def test_parse_line_whitespace_only():
    """parse_line with only whitespace should return None."""
    assert parse_line("   ") is None


def test_parse_line_leading_trailing_whitespace():
    """parse_line should strip leading/trailing whitespace."""
    line = '  127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326  '
    e = parse_line(line)
    assert e is not None
    assert e.ip == "127.0.0.1"


def test_parse_line_bytes_dash():
    """A dash for bytes should be treated as 0."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 -'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 0


def test_parse_line_bytes_zero():
    """A zero for bytes should be treated as 0."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 0'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 0


def test_parse_line_large_bytes():
    """Large byte values should be parsed correctly."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 999999999'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 999999999


def test_parse_line_non_standard_method():
    """Non-standard HTTP methods (lowercase) should not match."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "get / HTTP/1.0" 200 2326'
    e = parse_line(line)
    # The regex requires [A-Z]+ for method, so lowercase won't match
    assert e is None


def test_parse_line_various_methods():
    """Various valid HTTP methods should parse."""
    for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "{method} / HTTP/1.0" 200 2326'
        e = parse_line(line)
        assert e is not None, f"Method {method} should parse"
        assert e.method == method


def test_parse_line_various_status_codes():
    """Various HTTP status codes should parse."""
    for status in [200, 201, 301, 302, 400, 401, 403, 404, 500, 502, 503]:
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" {status} 2326'
        e = parse_line(line)
        assert e is not None, f"Status {status} should parse"
        assert e.status == status


def test_parse_line_unicode_url():
    """URLs with percent-encoded unicode should parse."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /path/%C3%A9 HTTP/1.0" 200 2326'
    e = parse_line(line)
    assert e is not None
    assert e.url == "/path/%C3%A9"


def test_parse_line_user_field():
    """The user field should be parsed correctly."""
    line = '127.0.0.1 - admin [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    e = parse_line(line)
    assert e is not None
    assert e.user == "admin"


def test_parse_line_user_dash():
    """A dash user field should be preserved as '-'. """
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    e = parse_line(line)
    assert e is not None
    assert e.user == "-"


# ── parse_lines ─────────────────────────────────────────────────────────────


def test_parse_lines_empty_iterable():
    """parse_lines with empty iterable should yield nothing."""
    result = list(parse_lines([]))
    assert result == []


def test_parse_lines_mixed_valid_invalid():
    """parse_lines should skip invalid lines and yield valid entries."""
    lines = [
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326',
        'garbage',
        '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512',
        '',
        'more garbage',
    ]
    result = list(parse_lines(lines))
    assert len(result) == 2
    assert result[0].ip == "127.0.0.1"
    assert result[1].ip == "192.168.1.1"


def test_parse_lines_is_generator():
    """parse_lines should return a generator."""
    result = parse_lines([])
    assert hasattr(result, "__next__")
    assert hasattr(result, "__iter__")


def test_parse_lines_with_generator_input():
    """parse_lines should work with generator input."""
    def gen():
        yield '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
        yield 'garbage'
        yield '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512'
    result = list(parse_lines(gen()))
    assert len(result) == 2


def test_parse_line_malformed_timestamp_returns_none():
    """parse_line should return None for lines with unparseable timestamps."""
    line = '127.0.0.1 - - [bad-timestamp] "GET / HTTP/1.0" 200 2326'
    e = parse_line(line)
    assert e is None
