"""Edge case tests for aggregate.py — aggregation functions.

These tests cover edge cases not tested by the original test_aggregate.py:
- Empty input for all aggregation functions
- by_hour with entries at midnight and end of day
- by_url with top=0 and top=1
- total_bytes with zero-byte entries
"""
from datetime import datetime, timezone

from logalyzer.aggregate import by_hour, by_status, by_url, total_bytes
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── by_status edge cases ────────────────────────────────────────────────────


def test_by_status_empty():
    """by_status with empty input should return empty Counter."""
    result = by_status([])
    assert len(result) == 0


def test_by_status_single_entry():
    """by_status with one entry should have one count."""
    result = by_status([_entry(status=200)])
    assert result[200] == 1


def test_by_status_all_same_status():
    """by_status with all same status should have one entry."""
    entries = [_entry(status=200) for _ in range(10)]
    result = by_status(entries)
    assert len(result) == 1
    assert result[200] == 10


# ── by_url edge cases ───────────────────────────────────────────────────────


def test_by_url_empty():
    """by_url with empty input should return empty list."""
    result = by_url([])
    assert result == []


def test_by_url_top_zero():
    """by_url with top=0 should return empty list."""
    entries = [_entry(url="/a"), _entry(url="/b")]
    result = by_url(entries, top=0)
    assert result == []


def test_by_url_top_one():
    """by_url with top=1 should return only the most common URL."""
    entries = [_entry(url="/a"), _entry(url="/a"), _entry(url="/b")]
    result = by_url(entries, top=1)
    assert len(result) == 1
    assert result[0] == ("/a", 2)


def test_by_url_top_larger_than_unique():
    """by_url with top > number of unique URLs should return all."""
    entries = [_entry(url="/a"), _entry(url="/b")]
    result = by_url(entries, top=100)
    assert len(result) == 2


def test_by_url_none_top():
    """by_url with top=None should return all URLs."""
    entries = [_entry(url="/a"), _entry(url="/b"), _entry(url="/c")]
    result = by_url(entries, top=None)
    assert len(result) == 3


# ── by_hour edge cases ──────────────────────────────────────────────────────


def test_by_hour_empty():
    """by_hour with empty input should return all 24 hours with 0 counts."""
    result = by_hour([])
    assert len(result) == 24
    assert all(v == 0 for v in result.values())


def test_by_hour_midnight():
    """by_hour should correctly bucket entries at midnight (hour 0)."""
    entries = [_entry(timestamp=datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc))]
    result = by_hour(entries)
    assert result[0] == 1


def test_by_hour_end_of_day():
    """by_hour should correctly bucket entries at 23:59 (hour 23)."""
    entries = [_entry(timestamp=datetime(2026, 1, 1, 23, 59, 59, tzinfo=timezone.utc))]
    result = by_hour(entries)
    assert result[23] == 1


def test_by_hour_all_hours():
    """by_hour should have exactly 24 keys (0-23)."""
    entries = [_entry(timestamp=datetime(2026, 1, 1, h, 0, 0, tzinfo=timezone.utc)) for h in range(24)]
    result = by_hour(entries)
    assert set(result.keys()) == set(range(24))


# ── total_bytes edge cases ──────────────────────────────────────────────────


def test_total_bytes_empty():
    """total_bytes with empty input should return 0."""
    assert total_bytes([]) == 0


def test_total_bytes_all_zero():
    """total_bytes with all zero-byte entries should return 0."""
    entries = [_entry(bytes=0) for _ in range(5)]
    assert total_bytes(entries) == 0


def test_total_bytes_single_entry():
    """total_bytes with one entry should return that entry's bytes."""
    assert total_bytes([_entry(bytes=42)]) == 42
