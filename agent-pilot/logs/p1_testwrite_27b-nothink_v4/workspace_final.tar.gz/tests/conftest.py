"""Shared pytest fixtures."""
import sys
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Patch: collections.Iterable was removed in Python 3.10+.
# The source code imports it from collections (not collections.abc).
# We monkey-patch it so the module can import without modifying source.
import collections
if not hasattr(collections, "Iterable"):
    from collections.abc import Iterable as _Iterable
    collections.Iterable = _Iterable
