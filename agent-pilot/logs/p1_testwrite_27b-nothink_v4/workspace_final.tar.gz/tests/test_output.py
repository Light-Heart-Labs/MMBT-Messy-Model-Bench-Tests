"""Tests for output.py — JSON, CSV, text formatters and render_aggregate.

These tests exercise the 0%-coverage output module, covering:
- to_json: empty entries, special characters, multiple entries
- to_csv: empty entries, entries with commas in data
- to_text: empty entries, formatting
- render_aggregate: Counter, dict, list, unknown format
"""
from collections import Counter
from datetime import datetime, timezone

from logalyzer.output import render_aggregate, to_csv, to_json, to_text
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── to_json ─────────────────────────────────────────────────────────────────


def test_to_json_empty():
    """Empty entries should produce an empty JSON array."""
    assert to_json([]) == "[]"


def test_to_json_single_entry():
    """A single entry should produce a valid JSON array with one object."""
    entries = [_entry()]
    result = to_json(entries)
    assert result.startswith("[")
    assert result.endswith("]")
    assert '"ip":"10.0.0.1"' in result
    assert '"status":200' in result
    assert '"bytes":100' in result


def test_to_json_multiple_entries():
    """Multiple entries should produce a JSON array with comma-separated objects."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_json(entries)
    # Should have two objects
    assert result.count('"ip"') == 2
    assert '"status":200' in result
    assert '"status":404' in result


def test_to_json_preserves_all_fields():
    """All LogEntry fields should appear in the JSON output."""
    entry = _entry(
        ip="192.168.1.1",
        user="admin",
        method="POST",
        url="/api/data",
        protocol="HTTP/2.0",
        status=500,
        bytes=2048,
    )
    result = to_json([entry])
    assert '"ip":"192.168.1.1"' in result
    assert '"user":"admin"' in result
    assert '"method":"POST"' in result
    assert '"url":"/api/data"' in result
    assert '"protocol":"HTTP/2.0"' in result
    assert '"status":500' in result
    assert '"bytes":2048' in result


def test_to_json_timestamp_isoformat():
    """Timestamp should be rendered in ISO format."""
    entry = _entry()
    result = to_json([entry])
    assert "2026-01-01T12:00:00" in result


# ── to_csv ──────────────────────────────────────────────────────────────────


def test_to_csv_empty():
    """Empty entries should produce CSV with only the header row."""
    result = to_csv([])
    lines = result.strip().split("\n")
    assert len(lines) == 1
    assert "ip" in lines[0]
    assert "status" in lines[0]


def test_to_csv_single_entry():
    """A single entry should produce header + one data row."""
    entries = [_entry()]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 2
    # Data row should contain the IP
    assert "10.0.0.1" in lines[1]


def test_to_csv_header_fields():
    """CSV header should contain all expected column names."""
    result = to_csv([])
    header = result.strip().split("\n")[0]
    expected = ["ip", "user", "timestamp", "method", "url", "protocol", "status", "bytes"]
    for field in expected:
        assert field in header


def test_to_csv_multiple_entries():
    """Multiple entries should produce header + N data rows."""
    entries = [_entry(status=200), _entry(status=404), _entry(status=500)]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 4  # header + 3 data rows


# ── to_text ─────────────────────────────────────────────────────────────────


def test_to_text_empty():
    """Empty entries should produce an empty string."""
    assert to_text([]) == ""


def test_to_text_single_entry():
    """A single entry should produce one line of text."""
    entries = [_entry()]
    result = to_text(entries)
    assert "10.0.0.1" in result
    assert "GET" in result
    assert "200" in result
    assert "/" in result


def test_to_text_multiple_entries():
    """Multiple entries should produce multiple lines separated by newlines."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_text(entries)
    lines = result.split("\n")
    assert len(lines) == 2


def test_to_text_ip_right_aligned():
    """IP addresses should be right-aligned in a 15-char field.

    The format string uses {e.ip:>15}, so the end of the IP string
    should be at the same column regardless of IP length.
    """
    entries = [_entry(ip="1.1.1.1"), _entry(ip="192.168.1.1")]
    result = to_text(entries)
    lines = result.split("\n")
    # The end position of the IP should be the same (right-aligned)
    ip1_end = lines[0].find("1.1.1.1") + len("1.1.1.1")
    ip2_end = lines[1].find("192.168.1.1") + len("192.168.1.1")
    assert ip1_end == ip2_end


# ── render_aggregate ────────────────────────────────────────────────────────


def test_render_aggregate_text_with_counter():
    """render_aggregate with a Counter should produce tab-separated key-value pairs."""
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_text_with_dict():
    """render_aggregate with a dict should produce tab-separated key-value pairs."""
    agg = {"200": 10, "404": 3}
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_text_with_list():
    """render_aggregate with a list of tuples should produce tab-separated pairs."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_json_with_counter():
    """render_aggregate with format=json should produce JSON-like output."""
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="json")
    assert result.startswith("{")
    assert result.endswith("}")
    assert '"200":10' in result
    assert '"404":3' in result


def test_render_aggregate_json_with_list():
    """render_aggregate with a list and format=json should produce JSON-like output."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="json")
    assert '"200":10' in result
    assert '"404":3' in result


def test_render_aggregate_unknown_format_raises():
    """render_aggregate with an unknown format should raise ValueError."""
    agg = Counter({"200": 10})
    try:
        render_aggregate(agg, fmt="xml")
        assert False, "Expected ValueError"
    except ValueError as e:
        assert "unknown format" in str(e)


def test_render_aggregate_empty_counter():
    """render_aggregate with an empty Counter should produce empty output."""
    agg = Counter()
    result = render_aggregate(agg, fmt="text")
    assert result == ""
