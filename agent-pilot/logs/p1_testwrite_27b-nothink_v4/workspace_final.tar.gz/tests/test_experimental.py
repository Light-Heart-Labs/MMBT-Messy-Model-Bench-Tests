"""Tests for experimental.py — anomaly detection and session windowing.

These tests exercise the 0%-coverage experimental module, covering:
- detect_anomalies: empty input, single entry, spike patterns, uniform traffic
- session_window: single IP, multiple IPs, session gaps, edge cases
"""
from datetime import datetime, timedelta, timezone

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1", **kw):
    """Helper to create a LogEntry with a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
        **kw,
    )


# ── detect_anomalies ────────────────────────────────────────────────────────


def test_detect_anomalies_empty_input():
    """Empty entries list should return empty list (no anomalies possible)."""
    assert detect_anomalies([]) == []


def test_detect_anomalies_single_entry_no_anomaly():
    """A single entry cannot be anomalous (std=0, threshold=mean)."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts)]
    assert detect_anomalies(entries) == []


def test_detect_anomalies_uniform_traffic_no_anomaly():
    """Uniform traffic across minutes should produce no anomalies."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    # Each minute has exactly 1 request — perfectly uniform
    assert detect_anomalies(entries) == []


def test_detect_anomalies_spike_detected():
    """A clear spike in one minute should be flagged as anomalous."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 10 minutes with 1 request each
    for i in range(10):
        entries.append(_entry(base + timedelta(minutes=i)))
    # 1 minute with 100 requests (clear spike)
    spike_time = base + timedelta(minutes=10)
    for _ in range(100):
        entries.append(_entry(spike_time))

    anomalies = detect_anomalies(entries)
    assert spike_time.replace(second=0, microsecond=0) in anomalies


def test_detect_anomalies_multiple_spikes():
    """Multiple anomalous minutes should all be detected."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 20 minutes with 1 request each
    for i in range(20):
        entries.append(_entry(base + timedelta(minutes=i)))
    # Two spike minutes
    for spike_min in (20, 21):
        spike_time = base + timedelta(minutes=spike_min)
        for _ in range(50):
            entries.append(_entry(spike_time))

    anomalies = detect_anomalies(entries)
    assert len(anomalies) == 2


def test_detect_anomalies_buckets_by_minute_not_second():
    """Entries within the same minute should be bucketed together."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    # 5 entries in the same minute but different seconds
    entries = [_entry(base + timedelta(seconds=s)) for s in range(0, 300, 60)]
    anomalies = detect_anomalies(entries)
    # All in one bucket, no anomaly
    assert anomalies == []


def test_detect_anomalies_returns_datetime_objects():
    """Anomaly buckets should be datetime objects, not strings."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base)]
    for _ in range(100):
        entries.append(_entry(base + timedelta(minutes=1)))
    anomalies = detect_anomalies(entries)
    if anomalies:
        for a in anomalies:
            assert isinstance(a, datetime)


# ── session_window ──────────────────────────────────────────────────────────


def test_session_window_empty_input():
    """Empty entries should return empty sessions list."""
    assert session_window([]) == []


def test_session_window_single_entry():
    """A single entry should produce one session."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts)]
    sessions = session_window(entries)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    assert ip == "10.0.0.1"
    assert len(session_entries) == 1


def test_session_window_single_ip_no_gap():
    """Multiple entries from same IP with no gap should be one session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(5)]
    sessions = session_window(entries)
    assert len(sessions) == 1
    _, session_entries = sessions[0]
    assert len(session_entries) == 5


def test_session_window_single_ip_with_gap():
    """Entries from same IP with a gap > window should split into sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        # 40-minute gap (default window is 1800s = 30min)
        _entry(base + timedelta(minutes=50)),
        _entry(base + timedelta(minutes=60)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    _, first = sessions[0]
    _, second = sessions[1]
    assert len(first) == 2
    assert len(second) == 2


def test_session_window_custom_window():
    """Custom window_seconds should control session splitting."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=60)),
        _entry(base + timedelta(seconds=120)),
    ]
    # Window of 90 seconds: gap between 1st and 2nd is 60s (ok),
    # gap between 2nd and 3rd is 60s (ok) — all one session
    sessions = session_window(entries, window_seconds=90)
    assert len(sessions) == 1

    # Window of 50 seconds: gap between 1st and 2nd is 60s (split)
    sessions = session_window(entries, window_seconds=50)
    assert len(sessions) == 3


def test_session_window_multiple_ips():
    """Entries from different IPs should be in separate sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base, ip="10.0.0.1"),
        _entry(base + timedelta(minutes=1), ip="10.0.0.2"),
        _entry(base + timedelta(minutes=2), ip="10.0.0.1"),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 2
    ips = {ip for ip, _ in sessions}
    assert ips == {"10.0.0.1", "10.0.0.2"}


def test_session_window_sessions_sorted_by_time():
    """Entries within a session should be sorted by timestamp."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base + timedelta(minutes=5)),
        _entry(base),
        _entry(base + timedelta(minutes=3)),
    ]
    sessions = session_window(entries)
    _, session_entries = sessions[0]
    timestamps = [e.timestamp for e in session_entries]
    assert timestamps == sorted(timestamps)


def test_session_window_gap_exactly_at_window_boundary():
    """A gap exactly equal to window_seconds should NOT split (only > splits)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1800)),  # exactly 30 min
    ]
    sessions = session_window(entries, window_seconds=1800)
    # gap == 1800, not > 1800, so still one session
    assert len(sessions) == 1
