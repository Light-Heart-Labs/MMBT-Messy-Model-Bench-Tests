"""Tests for utils.py — utility functions.

These tests exercise the 0%-coverage utils module, covering:
- parse_iso_date: valid dates, invalid formats, edge dates
- format_bytes: zero, small, large, boundary values
- format_legacy: basic formatting
- chunked: empty, exact fit, remainder, size=1
"""
from datetime import datetime, timezone
import pytest

from logalyzer.utils import chunked, format_bytes, format_legacy, parse_iso_date
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── parse_iso_date ──────────────────────────────────────────────────────────


def test_parse_iso_date_valid():
    """A valid YYYY-MM-DD string should parse to a UTC datetime at midnight."""
    dt = parse_iso_date("2026-01-15")
    assert dt == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_leap_year():
    """Feb 29 on a leap year should parse correctly."""
    dt = parse_iso_date("2024-02-29")
    assert dt.month == 2
    assert dt.day == 29


def test_parse_iso_date_last_day_of_year():
    """Dec 31 should parse correctly."""
    dt = parse_iso_date("2026-12-31")
    assert dt.month == 12
    assert dt.day == 31


def test_parse_iso_date_invalid_format_raises():
    """An invalid date format should raise ValueError."""
    with pytest.raises(ValueError):
        parse_iso_date("01-15-2026")


def test_parse_iso_date_non_date_string_raises():
    """A non-date string should raise ValueError."""
    with pytest.raises(ValueError):
        parse_iso_date("not a date")


def test_parse_iso_date_empty_string_raises():
    """An empty string should raise ValueError."""
    with pytest.raises(ValueError):
        parse_iso_date("")


def test_parse_iso_date_partial_date_raises():
    """A partial date like '2026-01' should raise ValueError."""
    with pytest.raises(ValueError):
        parse_iso_date("2026-01")


def test_parse_iso_date_returns_utc():
    """The returned datetime should have UTC timezone."""
    dt = parse_iso_date("2026-06-15")
    assert dt.tzinfo is timezone.utc


# ── format_bytes ────────────────────────────────────────────────────────────


def test_format_bytes_zero():
    """Zero bytes should format as '0.0 B'."""
    assert format_bytes(0) == "0.0 B"


def test_format_bytes_small():
    """Small byte counts should use 'B' unit."""
    assert format_bytes(1) == "1.0 B"
    assert format_bytes(500) == "500.0 B"


def test_format_bytes_exactly_1024():
    """Exactly 1024 bytes should format as '1.0 KB'."""
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_just_under_1024():
    """1023 bytes should still use 'B' unit."""
    assert format_bytes(1023) == "1023.0 B"


def test_format_bytes_megabyte():
    """1 MB (1048576 bytes) should format as '1.0 MB'."""
    assert format_bytes(1048576) == "1.0 MB"


def test_format_bytes_gigabyte():
    """1 GB should format as '1.0 GB'."""
    assert format_bytes(1073741824) == "1.0 GB"


def test_format_bytes_terabyte():
    """1 TB should format as '1.0 TB'."""
    assert format_bytes(1099511627776) == "1.0 TB"


def test_format_bytes_very_large():
    """Values larger than 1 PB should still produce output (PB unit)."""
    # 2 PB
    result = format_bytes(1024**5)
    assert "PB" in result


def test_format_bytes_fractional_kb():
    """1536 bytes (1.5 KB) should format as '1.5 KB'."""
    assert format_bytes(1536) == "1.5 KB"


def test_format_bytes_negative():
    """Negative byte counts should still produce output (edge case)."""
    result = format_bytes(-100)
    assert "B" in result


# ── format_legacy ───────────────────────────────────────────────────────────


def test_format_legacy_basic():
    """format_legacy should produce pipe-separated fields: ip | timestamp | status | url."""
    entry = _entry()
    result = format_legacy(entry)
    assert "10.0.0.1" in result
    assert "200" in result
    assert "/" in result
    assert "|" in result


def test_format_legacy_field_order():
    """Fields should appear in order: ip, timestamp, status, url."""
    entry = _entry()
    result = format_legacy(entry)
    parts = [p.strip() for p in result.split("|")]
    assert len(parts) == 4
    assert parts[0] == "10.0.0.1"
    assert parts[2] == "200"
    assert parts[3] == "/"


def test_format_legacy_with_custom_values():
    """format_legacy should reflect custom entry values."""
    entry = _entry(ip="1.2.3.4", status=404, url="/missing")
    result = format_legacy(entry)
    assert "1.2.3.4" in result
    assert "404" in result
    assert "/missing" in result


# ── chunked ─────────────────────────────────────────────────────────────────


def test_chunked_empty():
    """chunked with an empty sequence should yield nothing."""
    result = list(chunked([], 3))
    assert result == []


def test_chunked_exact_fit():
    """chunked with a sequence that divides evenly should produce exact chunks."""
    result = list(chunked([1, 2, 3, 4, 5, 6], 3))
    assert result == [[1, 2, 3], [4, 5, 6]]


def test_chunked_with_remainder():
    """chunked with a remainder should include the partial final chunk."""
    result = list(chunked([1, 2, 3, 4, 5], 2))
    assert result == [[1, 2], [3, 4], [5]]


def test_chunked_size_one():
    """chunked with size=1 should produce one-item chunks."""
    result = list(chunked([1, 2, 3], 1))
    assert result == [[1], [2], [3]]


def test_chunked_size_larger_than_sequence():
    """chunked with size > len(seq) should return the whole sequence as one chunk."""
    result = list(chunked([1, 2], 10))
    assert result == [[1, 2]]


def test_chunked_preserves_order():
    """chunked should preserve the order of elements."""
    result = list(chunked([3, 1, 4, 1, 5], 2))
    assert result == [[3, 1], [4, 1], [5]]


def test_chunked_with_generator():
    """chunked should work with generator inputs."""
    def gen():
        yield 1
        yield 2
        yield 3
    result = list(chunked(gen(), 2))
    assert result == [[1, 2], [3]]
