# Dead Ends

## Tests Written and Removed

### test_to_text_ip_right_aligned (first version)
**Problem:** Used `rfind()` to find IP position, but right-alignment means the *end* of the IP is at the same column, not the start. `rfind("1.1.1.1")` returns the start position, which differs between short and long IPs.
**Fix:** Changed to check `find(ip) + len(ip)` (end position) instead of `rfind(ip)` (start position).

### test_format_bytes_very_large (first version)
**Problem:** Used `2 * 1099511627776` thinking it was 2 PB, but it's actually 2 TB. The `format_bytes` function only goes up to TB in its loop, then returns PB for the remainder.
**Fix:** Changed to `1024**5` (1 PB) which correctly exercises the PB return path.

### test_expression_filter_builtins_restricted (first version)
**Problem:** Expected `AttributeError` or `TypeError`, but `eval()` with empty `__builtins__` raises `NameError` when `__import__` is not found.
**Fix:** Changed to `pytest.raises(NameError)`.

### test_main_* with patch("sys.stdout") (first version)
**Problem:** `patch("sys.stdout")` creates a MagicMock, and `mock_stdout.getvalue()` returns another MagicMock, not a string. This caused all assertions to fail.
**Fix:** Used `io.StringIO` with `patch("sys.stdout", buf)` and `buf.getvalue()` to properly capture output.

## Tests Not Written

### test_cli_version_flag
**Reason:** `argparse` handles `--version` by printing and exiting. Testing it would require catching `SystemExit`, which is more about testing argparse than logalyzer.

### test_io_file_not_found
**Reason:** `load()` and `load_iter()` would raise `FileNotFoundError` for missing files. This is standard Python behavior — testing it adds no signal about logalyzer-specific code.

### test_parser_invalid_month_name
**Reason:** The `MONTH_NAMES` list is missing "Jul" (a bug). Testing this would just re-confirm the bug. The existing `test_timestamp_july_parses_correctly` already documents this.
