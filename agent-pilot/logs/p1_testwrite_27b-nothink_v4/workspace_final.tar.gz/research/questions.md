# Questions

## Resolved
- **Q:** Can I modify conftest.py? **A:** Yes — it's in `/tests/`, not in `/logalyzer/`.
- **Q:** Should I fix the `collections.Iterable` import? **A:** No — can't modify source. Patched in conftest instead.
- **Q:** Should I fix the 3 failing tests? **A:** No — they document bugs in source code. Tests must pass against current behavior.

## Open
- **Q:** Should `experimental.py` be kept or removed? **A:** Documented in ADR-003. It's marked "experimental" and "in-progress" — testing it is valid for coverage purposes, but the code should be reviewed for production readiness.
- **Q:** The `io.load()` function reads files character-by-character — is this intentional? **A:** It's an implementation choice, not a bug. The `load_iter()` function provides a more efficient alternative.
