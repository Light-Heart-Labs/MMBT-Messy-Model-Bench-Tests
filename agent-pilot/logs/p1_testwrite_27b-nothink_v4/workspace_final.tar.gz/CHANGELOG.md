# CHANGELOG

## v0.3.2-test-additions (2025-01-01)

### Coverage Delta
- **Before:** 34% (97/287 statements covered)
- **After:** 99% (286/287 statements covered)
- **Delta:** +65 percentage points

### Test Files Added
| File | Tests | Module(s) Covered |
|------|-------|-------------------|
| `tests/test_experimental.py` | 15 | `experimental.py` (detect_anomalies, session_window) |
| `tests/test_output.py` | 20 | `output.py` (to_json, to_csv, to_text, render_aggregate) |
| `tests/test_utils.py` | 28 | `utils.py` (parse_iso_date, format_bytes, format_legacy, chunked) |
| `tests/test_io.py` | 12 | `io.py` (load, load_iter) |
| `tests/test_cli.py` | 24 | `cli.py` (build_parser, main) |
| `tests/test_parser_edge.py` | 22 | `parser.py` (edge cases: timestamps, parse_lines) |
| `tests/test_filters_edge.py` | 22 | `filters.py` (expression_filter, combine_and, edge cases) |
| `tests/test_aggregate_edge.py` | 15 | `aggregate.py` (empty inputs, boundary conditions) |

### Per-Module Coverage
| Module | Before | After |
|--------|--------|-------|
| `__init__.py` | 100% | 100% |
| `aggregate.py` | 100% | 100% |
| `cli.py` | 0% | 98% |
| `experimental.py` | 0% | 100% |
| `filters.py` | 74% | 100% |
| `io.py` | 0% | 100% |
| `output.py` | 0% | 100% |
| `parser.py` | 86% | 100% |
| `utils.py` | 0% | 100% |

### Pre-existing Test Failures (3)
These are bugs in the source code, not test issues:
1. `test_status_filter_works_with_cli_string_input` — `status_filter` doesn't convert string to int
2. `test_url_regex_finds_substring_match` — `url_regex_filter` uses `match()` instead of `search()`
3. `test_timestamp_july_parses_correctly` — `MONTH_NAMES` list is missing "Jul"

### Conftest Change
Added monkey-patch for `collections.Iterable` (removed in Python 3.10+) to allow the source code to import without modification.
