# ADR-003: experimental.py — keep or remove?

## Date
2025-01-01

## Context
`experimental.py` contains two functions:
1. `detect_anomalies()` — z-score-based anomaly detection on per-minute request counts
2. `session_window()` — session grouping by IP with configurable inactivity timeout

The module is marked "experimental" and "Not yet wired into the CLI."

## Decision
**Keep the code.** The functions are:
- Well-documented with clear docstrings
- Self-contained with no external dependencies
- Useful for log analysis (anomaly detection, session tracking)
- Currently at 0% coverage, which is a risk if someone tries to use them

Testing these functions increases coverage and provides a safety net for future integration.

## Recommendation (out of scope)
When ready for production:
1. Wire into CLI with `--anomalies` and `--sessions` flags
2. Add configuration for z-score threshold and window size
3. Consider more sophisticated anomaly detection (e.g., moving averages)
4. Add performance benchmarks for large datasets

## Consequences
- 15 new tests provide full coverage of experimental.py
- Tests document expected behavior for future developers
- No production code changes required
