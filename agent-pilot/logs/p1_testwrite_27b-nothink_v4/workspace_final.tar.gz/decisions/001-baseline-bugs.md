# ADR-001: Baseline test failures and source code bugs

## Date
2025-01-01

## Context
The original codebase has 3 failing tests due to bugs in the source code:

1. **`test_status_filter_works_with_cli_string_input`** — `status_filter()` compares `entry.status == status` directly. When `status` is a string "404" and `entry.status` is int 404, they don't match. The filter doesn't convert the string to int.

2. **`test_url_regex_finds_substring_match`** — `url_regex_filter()` uses `rx.match()` which only matches at the start of the string. The test expects "admin" to match "/admin/login", but `match()` fails because the URL starts with "/".

3. **`test_timestamp_july_parses_correctly`** — `MONTH_NAMES` list in `parser.py` is missing "Jul" (it has "Jun" then "Aug"). This causes `ValueError: 'Jul' is not in list`.

## Decision
Per the rules, I must NOT fix these bugs. The conftest.py was patched to work around the `collections.Iterable` import error (Python 3.10+ compatibility issue in source). The 3 failing tests remain as-is — they document known bugs. My new tests will pass against current behavior.

## Consequences
- Baseline coverage: ~34% (14 passing tests)
- 3 tests remain failing (documented bugs)
- My new tests will add coverage for: experimental.py, output.py, utils.py, io.py, cli.py, and edge cases in existing modules
