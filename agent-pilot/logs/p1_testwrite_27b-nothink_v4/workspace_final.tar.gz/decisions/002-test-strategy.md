# ADR-002: Test strategy for under-covered modules

## Date
2025-01-01

## Context
The following modules have 0% or very low coverage:
- `experimental.py` — 0% (32 statements, all uncovered)
- `output.py` — 0% (35 statements, all uncovered)
- `utils.py` — 0% (21 statements, all uncovered)
- `io.py` — 0% (26 statements, all uncovered)
- `cli.py` — 0% (59 statements, all uncovered)
- `filters.py` — 74% (some edge cases missing)
- `parser.py` — 86% (some edge cases missing)

## Decision
I will add tests for:

1. **`test_experimental.py`** — Full coverage of `detect_anomalies()` and `session_window()`
   - Empty entries list
   - Single entry (no anomalies possible)
   - Entries with clear spike patterns
   - Session window with single IP, multiple IPs, gaps

2. **`test_output.py`** — Full coverage of `to_json()`, `to_csv()`, `to_text()`, `render_aggregate()`
   - Empty entries
   - Entries with special characters in URLs
   - render_aggregate with Counter, dict, list, and unknown format

3. **`test_utils.py`** — Full coverage of `parse_iso_date()`, `format_bytes()`, `format_legacy()`, `chunked()`
   - Invalid date strings
   - Zero bytes, very large byte counts
   - Empty sequences for chunked
   - Chunk size of 1

4. **`test_io.py`** — Coverage of `load()` and `load_iter()`
   - Empty files
   - Files with no trailing newline
   - Files with mixed valid/invalid lines

5. **`test_cli.py`** — Coverage of `build_parser()` and `main()`
   - Version flag
   - Various filter combinations
   - Aggregate modes

6. **`test_parser_edge.py`** — Edge cases for parser
   - Various timezone offsets
   - Malformed timestamps
   - parse_lines generator behavior

7. **`test_filters_edge.py`** — Edge cases for filters
   - expression_filter with invalid expressions
   - combine_and with no predicates
   - Invalid regex patterns

## Consequences
Expected coverage increase from ~34% to ~80%+
