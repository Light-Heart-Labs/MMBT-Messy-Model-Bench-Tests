# Extraction Notes

## Summary
All 20 fields from the schema were successfully extracted from the press release. No fields required null/uncertain treatment.

## Field-by-Field Decisions

### company_name
- **Value:** `Veridyne Networks, Inc.`
- **Source:** Dateline and body text use the formal legal name "Veridyne Networks, Inc."
- **Rationale:** The schema accepts variants; used the most formal version as it appears in the dateline.

### ticker_symbol
- **Value:** `VRDN`
- **Source:** `(NASDAQ: VRDN)` in the first paragraph.
- **Rationale:** Extracted just the symbol, not the exchange prefix.

### fiscal_period
- **Value:** `Q3 FY2026`
- **Source:** Headline "Veridyne Networks Reports Fiscal Q3 2026 Results" and body "third fiscal quarter ended February 28, 2026."
- **Rationale:** Used the compact form matching the press release's own shorthand.

### fiscal_period_end_date
- **Value:** `2026-02-28`
- **Source:** "third fiscal quarter ended February 28, 2026"
- **Rationale:** Converted to ISO 8601 as required.

### total_revenue_usd_millions
- **Value:** `187.4`
- **Source:** "Total revenue of $187.4 million"
- **Rationale:** Direct extraction, already in millions.

### revenue_yoy_growth_pct
- **Value:** `38`
- **Source:** "up 38% year-over-year"
- **Rationale:** Integer percent value as stated.

### subscription_revenue_usd_millions
- **Value:** `171.2`
- **Source:** "Subscription revenue of $171.2 million"
- **Rationale:** Direct extraction.

### gaap_gross_margin_pct
- **Value:** `76.3`
- **Source:** "GAAP gross margin of 76.3%"
- **Rationale:** Direct extraction.

### non_gaap_operating_income_usd_millions
- **Value:** `9.8`
- **Source:** "Non-GAAP operating income of $9.8 million"
- **Rationale:** Positive income (not loss). The field name explicitly asks for income, and the press release states it as income.

### total_customers
- **Value:** `4117`
- **Source:** "Total customers grew to 4,117"
- **Rationale:** Integer as required.

### customers_above_100k_arr
- **Value:** `1082`
- **Source:** "Customers contributing more than $100,000 in annual recurring revenue (ARR) grew to 1,082"
- **Rationale:** Integer as required.

### customers_above_1m_arr
- **Value:** `71`
- **Source:** "Customers contributing more than $1 million in ARR grew to 71"
- **Rationale:** Integer as required.

### net_dollar_retention_pct
- **Value:** `124`
- **Source:** "Net dollar retention rate of 124%"
- **Rationale:** Direct percent value.

### total_arr_usd_millions
- **Value:** `710`
- **Source:** "Total ARR exceeded $710 million as of quarter-end"
- **Rationale:** The press release says "exceeded $710 million." Per instructions, defer to the document's stated figure (710), not a back-calculation.

### fte_count_end_of_q3
- **Value:** `1847`
- **Source:** "The Company ended the quarter with 1,847 full-time employees"
- **Rationale:** Integer as required. This is the end-of-quarter count.

### stitchwise_acquisition_total_consideration_usd_millions
- **Value:** `115`
- **Source:** "Total consideration was approximately $115 million"
- **Rationale:** Used the stated approximate total of $115 million, not a sum of components.

### stitchwise_close_date
- **Value:** `2026-01-22`
- **Source:** "closed its acquisition of Stitchwise Labs, Inc. ... on January 22, 2026"
- **Rationale:** Converted to ISO 8601.

### fy2026_revenue_guidance_low_usd_millions
- **Value:** `722`
- **Source:** "Total revenue: $722-$726 million (previously $702-$710 million)"
- **Rationale:** Used the raised (current) guidance range, not the previous.

### fy2026_revenue_guidance_high_usd_millions
- **Value:** `726`
- **Source:** Same as above.
- **Rationale:** Used the raised (current) guidance range.

### share_repurchase_authorization_usd_millions
- **Value:** `200`
- **Source:** "share repurchase program of up to $200 million"
- **Rationale:** Direct extraction.
