# Decision: Ticket 026 — Account Management (Seat Changes)

**Ticket:** 026  
**Category:** `account-management`  
**Urgency:** `normal`

**Rationale:**
- Account admin requesting seat changes: add 12 new analysts, remove 3 departed employees
- Bulk-update request with CSV attachment mentioned
- Account ID provided: NCO-3389
- Standard operational request, no indication of urgency

**Decision:**
- Category: `account-management` (seat add/remove)
- Urgency: `normal` (needs response within ~1 business day)
- Note: Similar to ticket 006 (cancellation) — both are account management but not urgent
