# Decision: Ticket 025 — General Question (Nonprofit Pricing)

**Ticket:** 025  
**Category:** `general-question`  
**Urgency:** `normal`

**Rationale:**
- Pricing inquiry: "How does your pricing work for non-profits?"
- Customer is a small environmental non-profit (501c3)
- No indication of business-critical impact
- Account ID: curious-user.example (likely individual user)

**Decision:**
- Category: `general-question` (pricing inquiry)
- Urgency: `normal` (needs response within ~1 business day)
- Note: Nonprofit pricing questions are important for outreach but not urgent
