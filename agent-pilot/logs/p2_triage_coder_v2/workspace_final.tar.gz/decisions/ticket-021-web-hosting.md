# Decision: Ticket 021 — Spam/Noise (Affiliate Marketing)

**Ticket:** 021  
**Category:** `spam-or-noise`  
**Urgency:** `n/a`

**Rationale:**
- Affiliate marketing pitch: "save 80% on web hosting"
- Contains affiliate links (8 paragraphs of promotional content)
- No legitimate customer support request
- Account ID: blog-hosting.example (likely throwaway)

**Decision:**
- Category: `spam-or-noise` (marketing pitches with no substance)
- Urgency: `n/a` (no action required)
- Note: Similar to ticket 010 (podcast sponsorship) — both are external business development pitches masquerading as support tickets
