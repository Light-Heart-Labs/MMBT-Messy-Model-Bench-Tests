# Decision: Ticket 005 — Bug Report (CSV Export)

**Ticket:** 005  
**Category:** `bug-report`  
**Urgency:** `normal`

**Rationale:**
- Concrete reproducible bug: CSV export drops last row when filename has spaces
- Reproducer: "any saved view, click Export → CSV, give it a filename with a space"
- Browser/platform specified: Firefox 134 on macOS
- Account ID: ben-and-co.dev

**Decision:**
- Category: `bug-report` (concrete reproducible product bug)
- Urgency: `normal` (needs response within ~1 business day)
- Note: Similar to tickets 020 and 027 — all are reproducible bugs but not urgent
