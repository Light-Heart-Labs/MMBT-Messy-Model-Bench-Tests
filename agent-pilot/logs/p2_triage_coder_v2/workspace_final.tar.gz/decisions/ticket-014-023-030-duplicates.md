# Decision: Duplicate Cluster — API Rate Limits

**Tickets:** 014, 023, 030  
**Category:** `incident-active`  
**Urgency:** `urgent`

**Rationale:**
- All three tickets from same sender (`ops@major-customer.com`)
- Same account ID (`MC-4221`)
- Same underlying issue: API rate limits blocking nightly ingestion
- Ticket 023 explicitly references ticket #14 as follow-up
- Ticket 030 explicitly references ticket #23 as third message
- Impact is ongoing (recurring nightly failures, growing data backlog)
- Customer explicitly states business impact: "blocking $48k of contracted business"
- Customer mentions escalation to account exec if unresolved by Thursday

**Decision:** 
- Cluster: ["014", "023", "030"]
- Original: 014 (first report)
- Duplicate assignments: 023 → 014, 030 → 014
- Category: `incident-active` (ongoing production impact)
- Urgency: `urgent` (recurring, time-sensitive, business-impacting)
