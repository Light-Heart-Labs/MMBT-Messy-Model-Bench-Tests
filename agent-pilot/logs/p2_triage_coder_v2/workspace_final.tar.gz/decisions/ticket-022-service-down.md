# Decision: Ticket 022 — Billing-Refund (Service Down)

**Ticket:** 022  
**Category:** `billing-refund`  
**Urgency:** `normal`

**Rationale:**
- Refund request due to service downtime: "service was down all weekend during our launch"
- Platform was down 11 hours over weekend (per status page)
- Business impact: "small business; this hurt us materially"
- Account ID: SB-2204

**Decision:**
- Category: `billing-refund` (explicit refund request)
- Urgency: `normal` (needs response within ~1 business day)
- Note: While service downtime occurred, the ticket itself is a refund request, not an active incident report. The customer references the status page, suggesting the issue is resolved.
