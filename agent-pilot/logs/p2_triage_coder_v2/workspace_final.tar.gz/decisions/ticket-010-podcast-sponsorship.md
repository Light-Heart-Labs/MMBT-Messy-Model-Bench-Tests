# Decision: Ticket 010 — External Business (Podcast Sponsorship)

**Ticket:** 010  
**Category:** `external-business`  
**Urgency:** `low`

**Rationale:**
- Podcast sponsorship pitch: "We have a podcast with 18,000 downloads/month"
- Rates: $1,500/episode
- Account ID: agency-xyz.com (marketing agency)

**Decision:**
- Category: `external-business` (partnerships, sales, marketing pitches)
- Urgency: `low` (can be batched, not blocking)
- Note: This is a business development inquiry, not a customer support ticket
