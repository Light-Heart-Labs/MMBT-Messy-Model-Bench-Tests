# Decision: Ticket 027 — Bug Report (PDF Export Quality)

**Ticket:** 027  
**Category:** `bug-report`  
**Urgency:** `normal`

**Rationale:**
- Clear bug description: Report PDFs render charts at low resolution (72 DPI, pixelated)
- Reproducible across three dashboards
- Browser/platform specified: Chrome 130 on Windows
- Account ID provided: ED-7745
- No indication of business-critical impact (aesthetic issue, not functional)

**Decision:**
- Category: `bug-report` (concrete reproducible product bug)
- Urgency: `normal` (needs response within ~1 business day)
- Note: Similar to tickets 005 and 020 — all are reproducible bugs but not urgent
