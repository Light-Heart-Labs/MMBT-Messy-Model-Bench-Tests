# Decision: Ticket 002 — Feature Request (SAML SSO)

**Ticket:** 002  
**Category:** `feature-request`  
**Urgency:** `normal`

**Rationale:**
- Explicit feature request: "Add support for SAML SSO"
- Business context: evaluating moving 60 seats from Trial to Business
- Security team requirement (not just preference)
- Currently stuck with Google OAuth only
- Account ID provided: startup.io

**Decision:**
- Category: `feature-request` (wants something the product doesn't currently do)
- Urgency: `normal` (business decision blocker, needs response within ~1 business day)
- Note: Higher urgency than ticket 012 because it's blocking a business deal (60 seats)
