# Decision: Ticket 028 — Security Incident

**Ticket:** 028  
**Category:** `security-incident`  
**Urgency:** `urgent`

**Rationale:**
- Subject: "SECURITY — possible account compromise, freeze account immediately"
- Claims unauthorized API key usage from foreign IPs within last 90 minutes
- Requests immediate account freeze and API key revocation
- Compliance team will need full access logs (indicates serious incident)
- Account ID provided: MB-8821
- Customer is a "major bank" — high-stakes security scenario

**Decision:**
- Category: `security-incident` (customer-reported account compromise)
- Urgency: `urgent` (active compromise, immediate action required)
- This is distinct from spam/phishing — it's a legitimate security report from a customer
