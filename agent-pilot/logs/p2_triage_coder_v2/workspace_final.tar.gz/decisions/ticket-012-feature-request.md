# Decision: Ticket 012 — Feature Request (Scheduled Reports)

**Ticket:** 012  
**Category:** `feature-request`  
**Urgency:** `low`

**Rationale:**
- Explicit feature request: "schedule reports to be emailed weekly"
- Customer describes current workaround (cron + headless browser)
- Account ID provided: DT-1198
- No indication of business-critical impact (improvement to workflow)

**Decision:**
- Category: `feature-request` (wants something the product doesn't currently do)
- Urgency: `low` (can be batched, not blocking)
- Note: Similar to ticket 002 (SAML SSO) — both are feature requests without urgent deadlines
