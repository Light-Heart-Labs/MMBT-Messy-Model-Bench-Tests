# Decision: Incident-Active Tickets — Urgency Assessment

**Tickets:** 003, 016  
**Category:** `incident-active`  
**Urgency:** `urgent`

**Rationale:**

**Ticket 003:**
- Subject: "URGENT — production down, cannot login"
- Impact: entire org cannot login since 9:42 EST
- Business impact: board meeting at 11 (within ~1.5 hours of report)
- Account ID provided: BC-44218
- Clear production-down scenario with time-sensitive business impact

**Ticket 016:**
- Subject: "500 errors on /api/v2/exports endpoint started at 14:00 UTC"
- Impact: 30% of requests failing, SOC1 review tomorrow morning
- SOC1 is a compliance audit with strict deadline → time-sensitive
- Account ID provided: PE-5510
- Customer explicitly states "Need urgent eyes"

**Decision:**
- Both tickets are `incident-active` with `urgent` urgency
- Ticket 003: immediate production outage affecting login
- Ticket 016: API failure impacting compliance audit deadline
