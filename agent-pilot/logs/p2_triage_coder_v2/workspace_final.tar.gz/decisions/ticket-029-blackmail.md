# Decision: Ticket 029 — Extortion/Blackmail

**Ticket:** 029  
**Category:** `spam-or-noise`  
**Urgency:** `n/a`

**Rationale:**
- Explicit extortion threat: "pay $50,000 in BTC or I post them on twitter"
- Includes Bitcoin address (classic ransom/extortion pattern)
- No actual vulnerability disclosure (no CVE request, no reproducible steps)
- Clearly fictitious and malicious

**Decision:** Classify as `spam-or-noise` with `n/a` urgency. This is not a legitimate security report; it's blackmail. No action required.
