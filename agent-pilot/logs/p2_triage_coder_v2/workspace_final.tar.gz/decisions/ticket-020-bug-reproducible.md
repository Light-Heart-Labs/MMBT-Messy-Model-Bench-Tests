# Decision: Ticket 020 — Bug Report with Reproducible Steps

**Ticket:** 020  
**Category:** `bug-report`  
**Urgency:** `normal`

**Rationale:**
- Clear bug description: date filtering excludes today's data even with "include today" checked
- Reproducible steps provided: "open any saved view with a date filter set to 'Last 7 days'. Click 'include today's data' checkbox"
- Reproducible across multiple users in the org (confirms it's not user error)
- Account ID provided: RT-9912
- No indication of business-critical impact (no deadline mentioned)

**Decision:**
- Category: `bug-report` (concrete reproducible product bug)
- Urgency: `normal` (needs response within ~1 business day)
- Note: Similar to ticket 005 (CSV export bug) — both are reproducible bugs but not urgent
