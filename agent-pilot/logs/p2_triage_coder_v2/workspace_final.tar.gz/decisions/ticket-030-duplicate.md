# Decision: Ticket 030 — Duplicate of Ticket 014

**Ticket:** 030  
**Category:** `incident-active`  
**Urgency:** `urgent`  
**Duplicate of:** 014

**Rationale:**
- Explicit follow-up: "Re: Re: API rate limits are blocking our nightly ingestion (THIRD MESSAGE)"
- Same account ID: MC-4221 (same org as 014/023)
- Same issue: recurring API rate limit failures
- Business impact: "Still no response. This is now blocking $48k of contracted business"
- Escalation threat: "we'll have to escalate to our account exec"

**Decision:**
- Category: `incident-active` (same as 014)
- Urgency: `urgent` (same as 014)
- Duplicate of: 014 (first report in cluster)
- Note: This is part of the larger cluster [014, 023, 030] — all should be treated as one issue
