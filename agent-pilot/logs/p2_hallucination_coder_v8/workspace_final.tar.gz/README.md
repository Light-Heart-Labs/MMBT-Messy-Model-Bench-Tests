# Triage Results

This directory contains the verification results for the 15 issues in the code-review report.

## Files

- **triage.json** - Required output with verdicts for all 15 issues
- **notes.md** - Detailed reasoning for each verdict
- **decisions/adr-*.md** - ADRs for borderline or notable decisions

## Summary

- **Real issues:** 8
- **Fabricated issues:** 7

## Verdicts

| Issue | Verdict | Key Finding |
|-------|---------|-------------|
| 001 | real | `from collections import Iterable` fails on Python 3.10+ |
| 002 | real | `eval()` with restricted builtins is still exploitable |
| 003 | fabricated | No SQL code exists in the codebase |
| 004 | real | README claims "tail mode" but no such feature exists |
| 005 | fabricated | `--top` flag works correctly |
| 006 | real | experimental.py is unused |
| 007 | fabricated | No web.py file exists |
| 008 | fabricated | No 8192 character limit in parser |
| 009 | fabricated | format_legacy() is in utils.py, not output.py |
| 010 | fabricated | No race condition in load_iter() |
| 011 | fabricated | by_status() doesn't double-count 3xx entries |
| 012 | fabricated | No cache.py file exists |
| 013 | real | O(n²) patterns in io.py |
| 014 | real | ip_allowlist_filter uses O(n) list membership |
| 015 | real | LogEntry not exported from __init__.py |
