# Verification Notes

## Issue 001 - Real
Confirmed: `from collections import Iterable` at filters.py:5 fails on Python 3.11.
The fix would be `from collections.abc import Iterable`.

## Issue 002 - Real
Confirmed: `eval(expr, {"__builtins__": {}}, {"entry": entry})` at filters.py:59.
While `__builtins__` is empty, the `entry` object (a LogEntry dataclass) exposes
`__class__`, `__mro__`, and `__subclasses__` which can be abused to access
dangerous modules like `os`. This is a well-known Python security issue.

## Issue 003 - Fabricated
No SQL code exists in the codebase. The parser.py file only parses log lines
into LogEntry dataclasses. There is no database export pipeline.

## Issue 004 - Real
README.md line 8 claims "Real-time tail mode for live log streams" but:
- No `--tail` flag exists in cli.py
- No streaming/tail logic exists in io.py (load_iter reads line-by-line but
  doesn't implement tail -F behavior)
- The CLI only processes files that already exist

## Issue 005 - Fabricated
The `--top` flag is correctly defined at cli.py:36 with `type=int, default=None`.
It's used correctly at cli.py:64 as `top=args.top`. No AttributeError occurs.

## Issue 006 - Real
experimental.py exists but is not imported anywhere:
- No `from .experimental import` or `import .experimental` in any module
- No `import logalyzer.experimental` in tests or cli
- The module is explicitly described as "Experimental features. Not yet wired
  into the CLI."

## Issue 007 - Fabricated
No web.py file exists. The entire web interface with CSRF protection is not
part of this codebase. The tool is purely CLI-based.

## Issue 008 - Fabricated
parse_line() in parser.py processes the entire line passed to it:
```python
def parse_line(line: str) -> Optional[LogEntry]:
    line = line.strip()
    if not line:
        return None
    m = LOG_LINE_RE.match(line)
    ...
```
No 8192 character limit exists.

## Issue 009 - Fabricated
The issue claims format_legacy() is in output.py, but it's actually in
utils.py:21. The function exists but is in a different file than claimed.

## Issue 010 - Fabricated
The race condition described doesn't exist:
- load_iter() opens the file and iterates line-by-line
- File iteration in Python is atomic at the line level
- Multiple threads reading the same file would just interleave lines, not
  corrupt data

## Issue 011 - Fabricated
by_status() simply does `c[e.status] += 1` for each entry. It doesn't have
special logic for 3xx redirects, and there's no deduplication that would
cause double-counting. The Counter correctly counts each entry once.

## Issue 012 - Fabricated
No cache.py file exists in the codebase. There is no caching mechanism at all.

## Issue 013 - Real
Confirmed in io.py:
- Line 24: `result = result + [entry]` creates a new list each time (O(n) per op)
- Line 27: `accumulated = accumulated + ch` creates a new string each char (O(n) per char)
Both patterns cause O(n²) behavior on large inputs.

## Issue 014 - Real
Confirmed in filters.py:36:
```python
return entry.ip in allowlist
```
When allowlist is a list (from argparse's `action="append"`), membership
testing is O(n). For >10 entries, converting to a set would be O(1).

## Issue 015 - Real
logalyzer/__init__.py is essentially empty (only has __version__).
LogEntry is defined in parser.py but not re-exported from __init__.py.
`from logalyzer import LogEntry` raises ImportError.
