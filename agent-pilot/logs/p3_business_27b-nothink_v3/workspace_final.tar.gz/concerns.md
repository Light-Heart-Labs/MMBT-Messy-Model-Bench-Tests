# Concerns with the Borealis Analytics Deal Pack

## HIGH-SEVERITY CONCERNS

### 1. Valuation Comps Are Not Apples-to-Apples
The pack cites three comparable transactions (Hexa Insights at ~9x ARR, Aspen Data at ~12x ARR, Trellis Analytics at ~7x ARR) to justify the 7.4x ARR multiple. However:
- No detail is given on the growth rates, profitability, or strategic value of those targets at time of acquisition. A company growing 200% YoY commands a higher multiple than one growing 80%.
- The pack does not disclose whether those deals were all-cash, stock-heavy, or included earn-outs. The effective multiples could differ materially.
- The pack cherry-picks only three comps. A broader set might show a different median.
- Borealis's 80% YoY revenue growth is strong but not exceptional for a Series-A SaaS company. The pack does not benchmark this against category norms.

### 2. Customer Concentration and Reference Call Bias
- The pack reports ~280 paid customers but only conducted reference calls with the top 5. With a median ARR of $32K per customer, the top 5 could represent a disproportionate share of revenue. The pack does not disclose the revenue concentration of the top 5 or top 10 customers.
- Only 4 of 5 reference customers were "willing to be quoted" — the pack does not explain why one declined, nor does it include any negative feedback.
- NPS "in the high 40s" is good but not outstanding. The pack frames this as "strong satisfaction" without context (category median? Borealis's own historical trend?).
- The testimonials are all uniformly positive with no nuance. This is expected in an advocacy document but means we have no unvarnished customer feedback.

### 3. Integration Plan Is Aggressive and Risky
- The plan calls for sunsetting the Aurora platform within 12 months post-close and migrating all customers to our platform. This is a high-risk move:
  - Customers who love Aurora (as the testimonials suggest) may resist migration.
  - The 4-6 month integration timeline assumes no technical surprises, but the pack's engineering review was high-level ("no concerning patterns").
  - The pack does not address data migration complexity, customer communication strategy, or rollback plans.
- "~85% retention expected" is based on "conversations with their VP Eng" — a single data point from one person. The pack does not describe retention incentives, retention guarantees, or what happens if key people leave.

### 4. Financials Lack Depth
- The pack provides only one year of financials (FY2025) with FY2024 revenue for comparison. No quarterly breakdown, no seasonality analysis, no cohort-level data.
- Gross margin of 71% is described as "acceptable" but the pack does not explain what drives it or whether it is sustainable at scale.
- Burn rate of $750K/month with $4.1M cash on hand gives ~5.5 months of runway, not the "22 months runway at last cap raise" mentioned. The pack does not explain the gap — presumably they have raised since, but the timing and terms of the last raise are not disclosed.
- No information on deferred revenue, contract terms, or revenue recognition policy.

### 5. No Discussion of Competitive Threats or Market Dynamics
- The pack does not address who Borealis's competitors are, how defensible their position is, or what market trends could threaten their growth trajectory.
- No mention of whether Borealis has any pending litigation, IP disputes, or regulatory concerns.
- No discussion of whether Borealis's customers overlap with ours (potential cannibalization risk).

## MEDIUM-SEVERITY CONCERNS

### 6. "Minimal Overlap" Claim Needs Verification
- The pack claims ~12% feature overlap with our existing offerings. This is a low number that suggests the integration may be more complex than implied, or that the products serve genuinely different use cases. If they serve different use cases, the synergy estimate of $3.2M may be overstated.

### 7. Synergy Estimate Lacks Detail
- $3.2M in annual cost savings from "consolidated infra" is stated without breakdown. How much is from eliminating redundant cloud costs? Headcount? Software licenses? The pack does not provide a synergy model.

### 8. No Information on Borealis's Cap Table or Investor Rights
- The pack does not disclose Borealis's cap table, existing investor rights, liquidation preferences, or any anti-dilution provisions that could affect the effective purchase price.

### 9. No Discussion of Cultural Fit
- The pack mentions the team relocating to our HQ but does not address cultural integration, management style differences, or potential friction points.

### 10. Risk-Adjusted IRR Estimate Is Unsubstantiated
- The pack cites a 28-34% IRR over 4 years but provides no model, assumptions, or sensitivity analysis. This number appears to be a single-point estimate without range or downside scenario.

## LOW-SEVERITY CONCERNS

### 11. Testimonials Lack Specificity
- The four quoted testimonials are generic and could apply to almost any analytics tool. They do not mention specific features, ROI metrics, or competitive advantages.

### 12. "Clean Codebase" Assessment Is Superficial
- The engineering review found "no concerning patterns" but this is a binary assessment. The pack does not provide test coverage metrics, deployment frequency, or other engineering health indicators.

### 13. No Mention of Borealis's Go-to-Market Strategy
- The pack does not describe Borealis's sales motion, CAC, payback period, or channel strategy. This is critical for understanding whether their growth is repeatable.

### 14. No Discussion of Post-Acquisition Governance
- The pack does not address how Borealis will be managed post-close, reporting structure, or decision-making authority.
