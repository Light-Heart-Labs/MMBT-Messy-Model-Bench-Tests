# ADR-001: Recommendation Stance — HOLD with Conditions

**Date:** 2026-04-15
**Status:** Accepted

## Context

The Corp Dev team recommends proceeding to LOI at $84M for Borealis Analytics. The diligence pack presents a favorable view of the target but contains several gaps and assertions that lack supporting evidence.

## Decision

The recommendation is **HOLD** — do not proceed to LOI until the diligence asks in `asks.md` are completed and the following conditions are met:

1. Customer concentration risk is quantified (top-5 and top-10 revenue share).
2. A broader comp set (8–10 deals) validates the 7.4x ARR multiple.
3. A downside IRR scenario is modeled and presented alongside the 28–34% base case.
4. Retention conversations are completed with all key Borealis employees, not just the VP Eng.
5. A detailed synergy model is produced with line-item support for the $3.2M estimate.

## Rationale

The pack is an advocacy document, not a balanced analysis. While the headline metrics (80% YoY growth, 118% NRR, 71% gross margin) are attractive, the pack omits critical context: customer concentration, competitive dynamics, deal structure details of comps, and downside scenarios. Proceeding to LOI without this information would commit the company to a price without full understanding of the risks.

The deal is not being rejected — the target appears genuinely interesting. But the diligence to date is insufficient for an $84M commitment.

## Consequences

- If the additional diligence confirms the pack's assertions and the downside scenarios are acceptable, the recommendation would shift to PROCEED.
- If the diligence reveals material issues (e.g., high customer concentration, weak competitive moat, unrealistic synergy estimates), the recommendation would shift to PASS.
- The 2-week diligence window aligns with the committee's decision deadline of 2026-04-30.
