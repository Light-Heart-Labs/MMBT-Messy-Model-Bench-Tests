# Diligence Asks — Next 2 Weeks

**Target completion:** 2026-04-30 (aligned with decision deadline)

## Financial Due Diligence

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| F1 | Obtain full FY2025 quarterly revenue breakdown and FY2023–FY2025 trend. Identify seasonality and any one-time revenue events. | Corp Dev / Finance | 2026-04-22 |
| F2 | Obtain Borealis's cap table, last round terms (valuation, liquidation preferences, investor rights), and any anti-dilution provisions. | Corp Dev / Legal | 2026-04-22 |
| F3 | Obtain deferred revenue schedule, average contract length, and renewal terms. Calculate true net retention by cohort. | Corp Dev / Finance | 2026-04-25 |
| F4 | Obtain detailed burn rate breakdown (headcount vs infra vs other). Reconcile the "22 months runway at last cap raise" claim with current $4.1M cash position. | Corp Dev / Finance | 2026-04-22 |
| F5 | Obtain gross margin bridge: what drives the 71% margin and how has it trended quarter-over-quarter? | Corp Dev / Finance | 2026-04-25 |
| F6 | Obtain Borealis's CAC, payback period, and LTV:CAC ratio. Assess whether growth is capital-efficient. | Corp Dev / Finance | 2026-04-25 |

## Customer Due Diligence

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| C1 | Conduct reference calls with at least 10 additional customers (beyond the top 5), including 2–3 who have churned or are at risk of churning. | Corp Dev / Sales | 2026-04-25 |
| C2 | Obtain revenue concentration analysis: what % of ARR is in the top 5, top 10, and top 20 customers? | Corp Dev / Finance | 2026-04-22 |
| C3 | Identify any Borealis customers that are also our customers (overlap analysis). Assess cannibalization risk. | Corp Dev / Sales | 2026-04-22 |
| C4 | Obtain Borealis's NPS trend over the last 4 quarters and benchmark against category median. | Corp Dev | 2026-04-25 |

## Technical Due Diligence

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| T1 | Conduct deep-dive code review: test coverage %, deployment frequency, CI/CD maturity, and technical debt quantification. | Engineering | 2026-04-25 |
| T2 | Assess data migration complexity: volume of customer data, schema differences, and estimated migration effort. | Engineering | 2026-04-25 |
| T3 | Validate the 12% feature overlap claim with a detailed feature-by-feature comparison matrix. | Product / Engineering | 2026-04-22 |
| T4 | Review Borealis's security posture: SOC 2 status, penetration test results, data residency compliance. | Security / Engineering | 2026-04-25 |

## Integration & People Due Diligence

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| I1 | Develop a detailed synergy model with line-item breakdown of the $3.2M cost savings estimate. | Finance / Corp Dev | 2026-04-25 |
| I2 | Conduct retention conversations with all 14 engineers and key non-engineering staff. Document retention incentives and concerns. | Corp Dev / HR | 2026-04-25 |
| I3 | Develop a customer migration plan with timeline, communication strategy, and rollback procedures. | Product / Engineering | 2026-04-28 |
| I4 | Build a downside IRR scenario (e.g., 50% retention, 18-month integration, no synergies realized). | Finance | 2026-04-28 |

## Competitive & Market Due Diligence

| # | Ask | Owner | Deadline |
|---|-----|-------|----------|
| M1 | Obtain a competitive landscape analysis: who are Borealis's top 5 competitors, what is their market share, and what is Borealis's differentiation? | Corp Dev / Strategy | 2026-04-25 |
| M2 | Obtain a broader set of M&A comps (at least 8–10 deals) with normalized multiples (growth-adjusted, deal-structure-adjusted). | Corp Dev / Finance | 2026-04-25 |
| M3 | Assess whether Borealis has any pending litigation, IP disputes, or regulatory exposures. | Legal | 2026-04-22 |
