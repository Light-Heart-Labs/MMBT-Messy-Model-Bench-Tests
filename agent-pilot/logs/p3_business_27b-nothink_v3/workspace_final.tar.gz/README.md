# How to Read This Output

## Files

| File | Purpose |
|------|---------|
| `memo.md` | **Primary deliverable.** A 1-page memo (≤700 words) for the executive committee with the recommendation, key concerns, and diligence asks. |
| `concerns.md` | Full enumeration of every concern identified in the deal pack, ranked by severity (high, medium, low). Supports the memo. |
| `asks.md` | Detailed diligence-ask list for the next 2 weeks, with specific questions, owners, and deadlines. Supports the memo. |
| `decisions/adr-001-recommendation-stance.md` | Architecture Decision Record documenting the judgment call on recommendation stance (HOLD vs PROCEED vs PASS). |

## Reading Order

1. Start with `memo.md` — this is the executive-facing document.
2. Review `concerns.md` for the full list of issues, including lower-severity items not included in the memo.
3. Review `asks.md` for the specific diligence actions needed over the next 2 weeks.
4. Review `decisions/` for the reasoning behind key judgment calls.

## Methodology

The diligence pack at `/input/repo/deal_pack.md` was treated as an advocacy document (as intended by the Corp Dev team). The review focused on:

- **Overclaims:** Assertions presented as fact without supporting evidence (e.g., IRR estimate, synergy numbers).
- **Underexplanations:** Claims that lack necessary context (e.g., comp deals without growth-rate normalization).
- **Omissions:** Material information absent from the pack (e.g., customer concentration, cap table, competitive landscape).

No external data was used. All citations reference the deal pack directly.
