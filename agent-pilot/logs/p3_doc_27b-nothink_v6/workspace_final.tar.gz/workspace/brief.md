# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Evaluation

**Date:** 2026-03-10
**Recommendation:** **More diligence needed** — conditional lean toward invest if three risks are resolved.

---

## Stance

Do not commit capital yet. Nimbus presents a credible business with strong engineering and top-tier investor backing, but material discrepancies between the company's public narrative and internal reality require targeted diligence. If the items below are satisfactorily addressed, the recommendation shifts to **invest**. If not, it shifts to **pass**.

---

## The Numbers

Nimbus closed an $84M Series B at a $560M post-money valuation, more than doubling its 2023 Series A valuation of $230M [Source 1]. The company reports $42M in ARR, up from $11M a year prior [Source 1]. However, two of its top-five customers departed in late 2025 — including its largest contract, Sundry Brands ($4.2M ARR, non-renewed in November) and fast-fashion brand Klatch (exited December) [Source 2]. Adjusted for this churn, the current run-rate ARR is closer to $36–37M [Source 2]. The round was originally priced at $720M but was repriced down ~22% after the Sundry non-renewal became known to the lead investor [Source 2].

Burn is approximately $4M/month against ~$3.5M/month in revenue, per a former senior engineer [Source 3]. Management's internal memo projects 24+ months of runway from the Series B alone, extended to 36+ months after planned restructuring [Source 4]. A separate $50M credit facility from Silicon Valley Bridge has been secured, described internally as "insurance, not operating capital" [Source 4].

---

## The Tensions

**Customer concentration is the biggest risk.** The top five customers represent ~38% of ARR [Source 3]. Two of those five left in a single quarter. The company claims three new $1M+ ARR contracts in Q1 2026 and net revenue retention above 110% [Source 2], but these claims have not been independently verified.

**Management has not been fully transparent.** Twenty-two employees (~11% of the org) were laid off in February 2025, primarily in customer success and business development, with no public announcement [Source 3]. The ARR figure in the press release includes contracts that had already been lost by the time of publication [Source 2]. These are not fatal flaws, but they signal a pattern of selective disclosure.

**The international strategy is being wound back.** Berlin headcount (41 employees) will be cut by 30% to 28–30 by end of Q2 2026, and international expansion is deferred to 2027 at earliest [Source 4]. The "Nimbus Lite" tier — serving ~310 small customers — is being sunset entirely [Source 4]. This is a rational pivot toward profitability, but the growth story is narrower than the press release suggests.

---

## What's Working

The engineering is strong. A former senior engineer described the carrier-orchestration layer as "some of the cleanest distributed-systems code" he's worked on, and CTO Daniel Wong is widely regarded as credible [Source 3]. Customer relationships at the mid-market level are deep — the platform is mission-critical for its users [Source 3]. The investor roster is elite: Lightning Capital (lead), Sequoia, Accel, and FedEx Ventures as a strategic [Source 1, Source 5].

Management's restructuring plan is explicit. The internal memo outlines specific actions — headcount reductions, product tier sunsetting, deferred international expansion — with a clear target of operating-cash-flow breakeven by Q4 2026 [Source 4]. This is not a company in freefall; it is a company recalibrating.

---

## Diligence Requirements

Before committing follow-on capital, the following must be verified:

1. **Customer concentration.** Has the top-5 concentration ratio declined below 30% since the Sundry and Klatch departures? What is the pipeline for replacing that $4.2M+ in lost ARR?
2. **Net revenue retention.** Can the >110% NRR claim be independently verified?
3. **Credit facility terms.** What are the covenants, interest rate, and maturity of the $50M Silicon Valley Bridge facility? Are there provisions that would complicate a future Series C or exit?
4. **Governance.** Why were 22 layoffs not disclosed? What other material events may have been withheld from investors?

---

## Bottom Line

Nimbus is a real company with real technology and real customers, but the gap between its public narrative and its operational reality is wider than is comfortable for a blind follow-on. The restructuring plan is a positive sign — management is acting, not spinning. But the customer concentration risk and transparency concerns need answers before capital is committed.

**Recommendation: More diligence needed.** If the four items above are satisfactorily resolved, invest. If they reveal deeper problems, pass.
