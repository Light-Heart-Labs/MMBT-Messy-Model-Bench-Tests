# Key Facts — Nimbus Logistics Executive Brief

Every material fact incorporated into the brief, with source attribution.

## Financials
| Fact | Value | Source |
|------|-------|--------|
| Series B amount | $84M | [Source 1], [Source 5] |
| Post-money valuation | $560M | [Source 1] |
| Previous valuation (Series A, 2023) | $230M | [Source 1] |
| Total funding raised | $128M | [Source 1] |
| Reported ARR (Q4 2025) | $42M | [Source 1] |
| ARR one year prior | $11M | [Source 1] |
| Adjusted ARR (post-December churn) | $36-37M | [Source 2] |
| Monthly burn rate (mid-2025) | ~$4M/month | [Source 3] |
| Monthly revenue (mid-2025) | ~$3.5M/month | [Source 3] |
| Credit facility | $50M from Silicon Valley Bridge | [Source 4] |
| Target valuation before repricing | $720M | [Source 2] |

## Customers
| Fact | Value | Source |
|------|-------|--------|
| Total customers | 1,400+ e-commerce brands | [Source 1] |
| Named customers | Maevia, Truant Coffee, Brick & Cobble | [Source 1] |
| Top 5 customer concentration | ~38% of ARR | [Source 3] |
| Sundry Brands (largest contract) | $4.2M ARR, non-renewed November 2025 | [Source 2] |
| Klatch (fast-fashion) | Exited December 2025 | [Source 2] |
| New contracts signed Q1 2026 | 3 contracts at $1M+ ARR each | [Source 2] |
| Net revenue retention (claimed) | >110% | [Source 2] |
| Nimbus Lite customers being sunset | ~310 customers ($5K-$20K ARR each) | [Source 4] |

## Organization
| Fact | Value | Source |
|------|-------|--------|
| Employees | 187 (as of Jan 2026) | [Source 1] |
| Offices | Oakland, Austin, Berlin | [Source 1] |
| Berlin headcount | 41 (as of Feb 2026) | [Source 4] |
| Berlin target headcount | 28-30 by end Q2 2026 | [Source 4] |
| Layoffs (Feb 2025) | 22 people (~11% of org) | [Source 3] |
| Layoffs public announcement | None | [Source 3] |
| Founders | Mira Patel (CEO), Daniel Wong (CTO) | [Source 1] |
| Founded | 2021 | [Source 1] |

## Investors
| Fact | Value | Source |
|------|-------|--------|
| Lead investor | Lightning Capital | [Source 1], [Source 5] |
| Participating investors | Sequoia Capital, Accel, FedEx Ventures (strategic) | [Source 1], [Source 5] |
| Total investors | 7 | [Source 5] |
| Security type | Series B Preferred Equity | [Source 5] |

## Strategic Plans
| Fact | Value | Source |
|------|-------|--------|
| International expansion | Deferred to 2027 | [Source 4] |
| Berlin office role | Reframed as "support hub" | [Source 4] |
| Target breakeven | Q4 2026 | [Source 4] |
| Runway (current burn) | 24+ months | [Source 4] |
| Runway (post-restructuring) | 36+ months | [Source 4] |
| Use of proceeds | "Expansion, working capital, general corporate purposes" | [Source 5] |

## Product
| Fact | Value | Source |
|------|-------|--------|
| Platform components | Warehouse management, carrier orchestration, demand forecasting | [Source 1] |
| Engineering quality | Praised by former employee as "genuinely good" | [Source 3] |
| Nimbus Lite tier | Being sunset | [Source 4] |
