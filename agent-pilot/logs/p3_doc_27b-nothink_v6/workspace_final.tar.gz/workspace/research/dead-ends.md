# Dead Ends — Ideas Considered and Abandoned

## Considered but Rejected Approaches

### 1. "Pass" recommendation
- Initially considered a hard "pass" due to churn, hidden layoffs, and valuation repricing.
- Rejected because: the restructuring memo shows management is actively addressing problems; the $50M credit facility provides real cushion; the engineering team is strong; and the company is still growing (even if slower than claimed). A "pass" would ignore the positive signals.

### 2. "Invest" recommendation
- Considered a straightforward "invest" because the company raised $84M from top-tier VCs, has a credible founding team, and the restructuring plan is explicit.
- Rejected because: the customer concentration risk (38% of ARR in top 5, lost 2 of 5) is material and not fully addressed; the ARR discrepancy ($42M vs. $36-37M adjusted) suggests the company is not fully transparent; and the hidden layoffs raise governance concerns.

### 3. Including the $50M credit facility in runway calculations
- Initially wanted to add the $50M to the $84M for total capitalization.
- Rejected because: the memo explicitly calls it "insurance, not operating capital." It's a credit facility, not equity, and may have covenants or conditions. Better to treat it as a separate safety net.

### 4. Speculating on the identity of the 3 additional undisclosed investors
- The Form D lists 7 investors but only names 4.
- Rejected because: no source provides information about the other 3. Speculating would violate the "no invented facts" rule.

### 5. Calculating precise runway months
- Wanted to compute exact runway from burn rate and cash on hand.
- Rejected because: we don't know the exact cash position post-Series B (some of the $84M may have gone to paying down debt or other uses). The memo's "24+ months" is the best available figure.

### 6. Treating the ex-employee's burn rate as definitive
- The $4M/month burn figure is useful but comes from a single former employee's memory.
- Decided to use it with appropriate hedging ("according to a former employee") rather than as a hard fact.
