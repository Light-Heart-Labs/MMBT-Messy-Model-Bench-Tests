# Working Notes — Nimbus Logistics Source Analysis

## Source-by-Source Summary

### Source 1: Press Release (2026-01-14)
- $84M Series B, led by Lightning Capital
- Post-money valuation: $560M (up from $230M Series A in 2023)
- Total funding: $128M across all rounds
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400+ e-commerce brands on platform
- 187 employees across Oakland, Austin, Berlin
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (strategic)
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO)
- Named customers: Maevia, Truant Coffee, Brick & Cobble

### Source 2: TechCrunch (2026-01-15)
- Lost two top-5 customers in late 2025
- Sundry Brands: $4.2M ARR, did not renew in November
- Klatch (fast-fashion): exited in December, migrated to competitor
- Adjusted ARR after churn: $36-37M (vs. $42M in press release)
- CEO claims 3 new $1M+ ARR contracts signed in Q1
- CEO claims net retention >110%
- Round was meant to close at $720M but repriced down to $560M after Sundry news
- Nimbus confirmed Sundry non-renewal as "strategic mutual decision"

### Source 3: Former Employee Blog (2026-02-22)
- Author: "Daniel R", former senior engineer, 14 months tenure
- Burn rate: ~$4M/month (mid-2025)
- Revenue: ~$3.5M/month
- Net burn: ~$500K/month
- Layoffs: 22 people (~11% of org) in February 2025, mostly customer success and BD
- Layoffs were NOT announced publicly
- Top 5 customers = ~38% of ARR (customer concentration)
- Sundry loss was not a shock internally
- Engineering quality praised; CTO Daniel Wong is strong
- Compensation: $215K base + $50K equity/year for senior engineers

### Source 4: Leaked Internal Memo (2026-03-05)
- Dated February 28, 2026
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
- International expansion deferred to 2027
- Berlin reframed as "support hub" not sales/expansion
- Nimbus Lite tier being sunset (~310 customers, $5K-$20K ARR each)
- 90-day notice for affected customers
- New $50M credit facility from Silicon Valley Bridge
- Memo claims 24+ months runway at current burn; actions extend to 36+ months
- Target: operating-cash-flow breakeven by Q4 2026
- Breakeven is trigger for Series C conversations

### Source 5: SEC Form D (2026-01-22)
- Confirms $84M total offering, all sold
- 7 investors total
- Securities: Series B Preferred Equity
- No executive compensation disclosed in connection with offering
- Use of proceeds: "expansion, working capital, general corporate purposes"

## Key Tensions Identified

1. **ARR discrepancy**: $42M (press release) vs. $36-37M adjusted for churn (TechCrunch sources)
2. **Valuation repricing**: $720M target → $560M actual (down ~22%)
3. **Customer concentration**: Top 5 = 38% of ARR; lost 2 of top 5 in late 2025
4. **Burn vs. revenue**: $4M/month burn vs. $3.5M/month revenue = net negative
5. **Layoffs hidden**: 22 people cut in Feb 2025, not publicly announced
6. **International pivot**: Berlin expansion being wound back; Lite tier sunset
7. **Credit facility**: $50M from Silicon Valley Bridge — "insurance, not operating capital"

## Numbers Cross-Check

- Employee count: 187 (press release) — but 22 were laid off in Feb 2025, so headcount at time of press release (Jan 2026) should be ~187. The 22 layoffs happened before the press release date.
- Berlin headcount: 41 (memo) — this is as of Feb 2026
- Monthly revenue: $42M ARR / 12 = $3.5M/month — matches ex-employee's figure
- Monthly burn: $4M/month (ex-employee)
- Net monthly burn: ~$500K/month
- Runway at $84M raise: $84M / $0.5M per month = 168 months? That seems too high. The memo says 24+ months, which suggests either higher burn or that not all $84M is cash. Let me trust the memo's 24-month figure.
- Actually, the $50M credit facility is separate. The memo says "24+ months of runway at current burn" from the Series B alone.

## Recommendation Reasoning

The company is raising at a significant discount from its target valuation, has hidden layoffs, is cutting international expansion, sunsetting a product tier, and has high customer concentration. However, the engineering is solid, the founders are credible, and the restructuring plan is explicit and measured. The $50M credit facility provides additional cushion.

Stance: **More diligence needed** — but with a specific direction. The restructuring is a positive signal (management is acting), but the customer concentration and churn risk need deeper investigation before committing capital.
