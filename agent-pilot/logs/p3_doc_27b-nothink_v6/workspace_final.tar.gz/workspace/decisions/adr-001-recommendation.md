# ADR-001: Recommendation Stance — "More Diligence Needed"

## Context
The brief requires a clear stance: invest, pass, or more diligence needed. The sources present both positive and negative signals.

## Decision
**"More diligence needed"** — with specific diligence items that would flip the recommendation to "invest" or "pass."

## Rationale
- A hard "invest" would ignore material red flags: hidden layoffs, ARR inflation, customer concentration, and valuation repricing.
- A hard "pass" would ignore positive signals: credible founders, strong engineering, explicit restructuring plan, and top-tier investor participation.
- The right call is conditional: if the diligence items below are satisfactorily addressed, the recommendation shifts to "invest." If not, it shifts to "pass."

## Conditions for "Invest"
1. Customer concentration drops below 25% in top 5 (from current ~38%)
2. Net revenue retention verified independently at >100%
3. No additional undisclosed layoffs or restructuring
4. International pivot is a strategic choice, not a retreat from failed expansion

## Conditions for "Pass"
1. Further customer losses in top 10
2. Burn rate exceeds $4.5M/month
3. Credit facility from Silicon Valley Bridge has onerous covenants
4. Management is not transparent about financials

---

# ADR-002: ARR Figure to Use in Brief

## Context
The press release claims $42M ARR. TechCrunch sources say adjusted ARR is $36-37M after accounting for December churn.

## Decision
Report both figures, with the adjusted figure as the more reliable number, but attribute each to its source.

## Rationale
- The $42M figure is the company's official number and may be technically correct for Q4 2025 (the contracts were still active during the quarter).
- The $36-37M figure reflects the current run-rate and is more useful for investment evaluation.
- Reporting both with attribution is honest and informative.

---

# ADR-003: Treatment of Leaked Memo

## Context
The internal memo was leaked to The Information. It contains specific operational plans and financial targets.

## Decision
Treat the memo as credible but not perfectly authoritative. Use "according to" language and note it was leaked.

## Rationale
- The memo is attributed to CEO Mira Patel and contains specific, verifiable details (headcount numbers, customer counts).
- It was leaked, not officially released, so it may not represent the final plan.
- The company declined to confirm specifics, which is neither confirmation nor denial.
