# Password Manager Recommendation: 1Password Business

**To:** CTO and Engineering Leadership
**From:** Engineering Security Advisory
**Date:** 2025-01-XX
**Subject:** Standardize on 1Password Business for the 50-person engineering team

---

## Executive Summary

After evaluating five password managers — **1Password, Bitwarden, LastPass, Dashlane, and Keeper Security** — we recommend **1Password Business** as the standard password manager for our engineering team.

**Recommended product:** 1Password Business
**Per-seat cost:** $7.99/user/month ($95.88/user/year) billed annually
**50-seat annual cost:** **$4,794/year**
**Runner-up:** Bitwarden Enterprise ($6/user/month = $3,600/year for 50 seats)

1Password wins on the combination of developer tooling, security track record, admin UX, and SOC 2 readiness — the factors that matter most for a Series-B SaaS engineering team.

---

## Decision Criteria

We defined our evaluation criteria before selecting products, in three tiers:

### Tier 1: Must-Have (disqualifying if absent)

1. **SSO with Google Workspace** — SAML 2.0 SSO and SCIM provisioning for automated user lifecycle management.
2. **Audit logging** — Detailed logs of who accessed what, when, and from where, required for SOC 2 compliance.
3. **Zero-knowledge architecture** — End-to-end encryption; the vendor cannot access plaintext vault data.
4. **Cross-platform coverage** — macOS, Windows, Linux, iOS, Android, and major browsers.
5. **Developer tooling** — CLI access and CI/CD integrations for our engineering workflow.

### Tier 2: Important

6. **Transparent pricing** — Publicly listed per-seat pricing.
7. **Admin console** — Web-based admin for user management, policies, and reporting.
8. **Security certifications** — SOC 2 Type II baseline; ISO 27001 and FedRAMP are bonuses.
9. **Clean security history** — No known breaches of customer vault data.

### Tier 3: Nice-to-Have

10. Self-hosting option, open source, free personal plan for employees, passkey support.

---

## The Recommendation: 1Password Business

### Why 1Password

**1. Best-in-class developer tooling.** 1Password offers the most comprehensive developer integrations of any password manager evaluated:

- **`op` CLI** with native SSH agent support and Git commit signing — engineers can authenticate SSH connections and sign commits using biometrics, without plaintext secrets in code.
- **CI/CD integrations** for GitHub Actions, GitLab CI, Jenkins, Terraform, Ansible, Pulumi, and Kubernetes.
- **SDKs** for Python, JavaScript, and Go to embed secret resolution in applications.
- **IDE extensions** for VS Code, JetBrains, and others.

This matters because our engineering team needs to eliminate secrets from code repositories and CI/CD pipelines — a core requirement for SOC 2 compliance.

**2. Clean security track record.** 1Password has never had a publicly disclosed breach of customer vault data. Their dual-key encryption model (password + 128-bit Secret Key) and SRP protocol for authentication provide strong protection. They are SOC 2 Type II certified [1].

**3. SOC 2-ready admin console.** The 1Password admin console provides:

- Role-based vault permissions and group management
- Custom security policies (password strength, 2FA enforcement, etc.)
- Detailed audit logs exportable to SIEM tools (Splunk, Elastic, Sumo Logic, Panther)
- Watchtower alerts for breached, weak, or reused passwords
- SCIM provisioning with Google Workspace, Okta, Azure AD, OneLogin, Rippling, and JumpCloud

**4. Free Families plan for every employee.** Each Business user gets a free 1Password Families plan for personal use, reducing the risk of personal credential reuse affecting work accounts.

**5. Cross-platform coverage.** Native apps for macOS, Windows, Linux, iOS, Android, watchOS, plus browser extensions for Chrome, Safari, Edge, Firefox, and Brave.

### Pricing

| Item | Value |
|------|-------|
| Tier | 1Password Business |
| Per-seat price | $7.99/user/month (billed annually) |
| Per-seat annual | $95.88/user/year |
| 50 seats annual | **$4,794/year** |
| Source | [1Password Pricing][1] |

### 90-Day Rollout Plan

| Week | Activity |
|------|----------|
| 1–2 | Procure 50 seats; configure SSO with Google Workspace; set up SCIM provisioning |
| 3–4 | Configure admin policies (password requirements, 2FA enforcement, vault structure); create onboarding documentation |
| 5–8 | Phased rollout: leadership and security team first, then full team; migrate credentials from shadow IT (browser, Slack, sticky notes) |
| 9–10 | Developer onboarding: configure CLI, CI/CD integrations, SSH agent; audit code repos for hardcoded secrets |
| 11–12 | Final audit: verify all users are active; confirm audit logging is flowing to SIEM; document SOC 2 evidence |

---

## Runner-Up: Bitwarden Enterprise

**Bitwarden Enterprise** at $6/user/month ($3,600/year for 50 seats) is the clear runner-up. It would beat 1Password under these conditions:

1. **Budget is the primary constraint.** Bitwarden Enterprise is $1,194/year cheaper for 50 seats (25% less).
2. **Self-hosting is required.** Bitwarden is the only product in this evaluation that can be fully self-hosted, which matters if data residency or air-gapping requirements emerge.
3. **Open source is a hard requirement.** Bitwarden's codebase is fully open source (AGPLv3), allowing independent security audits and community scrutiny.
4. **The team is comfortable with a less polished developer experience.** Bitwarden's CLI (`bw`) is functional but lacks 1Password's SSH agent, Git commit signing, and breadth of CI/CD integrations.

**Key trade-offs vs. 1Password:**
- Bitwarden Teams ($4/user/month) lacks SSO and SCIM — you'd need to upgrade to Enterprise ($6/user/month) for those features.
- Bitwarden's developer tooling is good but not as comprehensive (no native SSH agent, no Git commit signing, fewer CI/CD integrations).
- Bitwarden's admin console is functional but less polished than 1Password's.

---

## Why Not the Others

### LastPass Business ($7/user/month = $4,200/year)

**Disqualified due to security incident history.** LastPass suffered a major breach in May 2022 where attackers accessed encrypted vault data, SSH keys, and customer metadata [2]. While the vault data was encrypted, the breach exposed encrypted blobs and some unencrypted data, and it significantly eroded trust in the product. For a SaaS company preparing for SOC 2, choosing a vendor with a known breach of customer data is an unnecessary risk.

### Dashlane Password Management ($8/user/month = $4,800/year)

**Disqualified due to lack of developer tooling.** Dashlane has no CLI, no CI/CD integrations, and no SDKs. For an engineering team that needs to manage secrets in code and CI/CD pipelines, this is a disqualifying gap. Dashlane also lacks publicly listed pricing on their website (we found $96/user/year via AWS Marketplace [3]), which is a transparency concern.

### Keeper Business ($4/user/month = $2,400/year)

**Disqualified at the Business tier due to missing SSO/SCIM.** Keeper's Business tier lacks SSO and SCIM provisioning — these are only available in the Enterprise tier ($6/user/month = $3,600/year). While Keeper has strong compliance credentials (FedRAMP, ISO 27017/27018), the Business tier doesn't meet our Tier 1 must-have criteria. The Enterprise tier is competitive on price but still trails 1Password in developer tooling breadth.

---

## Concerns and Risks with 1Password

### 1. Vendor Lock-In

1Password is proprietary and closed-source. Unlike Bitwarden, you cannot self-host or audit the codebase. If 1Password were to discontinue service or dramatically increase pricing, migration would require manual re-entry of all credentials.

**Mitigation:** 1Password supports standard export formats (CSV, KDBX). We should establish a quarterly export cadence as a migration safety net.

### 2. Pricing Increases

At $7.99/user/month, 1Password is the second-most expensive option evaluated (behind Dashlane). If the team grows beyond 50, costs scale linearly.

**Mitigation:** Lock in annual billing. Monitor pricing changes at renewal. Bitwarden Enterprise remains a viable migration target if costs become prohibitive.

### 3. No FedRAMP Certification

1Password is not FedRAMP certified. If the company later needs to serve government customers with FedRAMP requirements, 1Password may not qualify.

**Mitigation:** For a Series-B SaaS company, this is unlikely to be an immediate concern. If it becomes relevant, Keeper Security (FedRAMP certified) would be the alternative.

### 4. No Self-Hosting Option

Unlike Bitwarden, 1Password cannot be self-hosted. All vault data resides on 1Password's infrastructure.

**Mitigation:** 1Password's zero-knowledge architecture means they cannot access vault data even if their infrastructure is compromised. SOC 2 Type II certification provides independent verification of their security controls.

### 5. Secret Key Recovery Complexity

1Password's dual-key model (password + Secret Key) means that if a user loses both their password and Secret Key, their vault is irrecoverable. Recovery codes mitigate this, but the process is more complex than single-password systems.

**Mitigation:** Enforce a policy requiring all users to store their Secret Key and recovery codes in a secure, offline location. 1Password's admin console can help enforce this.

---

## Conclusion

**1Password Business** is the recommended password manager for our 50-person engineering team. It provides the best combination of developer tooling, security track record, admin UX, and SOC 2 readiness. The $4,794/year cost for 50 seats is justified by the reduction in security risk and the productivity gains from eliminating shadow IT password storage.

**Bitwarden Enterprise** is the runner-up and would be the preferred choice if budget were the primary constraint or if self-hosting/open source were hard requirements.

We recommend proceeding with procurement and beginning the 90-day rollout plan outlined above.

---

## Sources

[1] https://1password.com/pricing/ — 1Password Business pricing: $7.99/user/month billed annually; SOC 2 Type II certification
[2] LastPass May 2022 breach — widely reported across tech media; attackers accessed encrypted vault data, SSH keys, and metadata
[3] https://aws.amazon.com/marketplace/pp/prodview-glvhugk2njxxa — Dashlane Password Management: $96/user/year via AWS Marketplace
