# Sources

All URLs fetched during research, with timestamps and descriptions.

## 1Password

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 1 | https://1password.com/pricing/ | 2025-01-XX | Business pricing: $7.99/user/month billed annually; Teams Starter Pack: $19.95/month up to 10 users; Individual: $2.99/month; Families: $4.49/month |
| 2 | https://1password.com/security/ | 2025-01-XX | Security model: dual-key encryption (password + 128-bit Secret Key), AES-256, SRP protocol, SOC 2 Type II certification |
| 3 | https://1password.com/developers/ | 2025-01-XX | Developer tools: CLI (`op`), SSH agent, Git commit signing, SDKs (Python, JS, Go), CI/CD integrations (GitHub, GitLab, Jenkins, Terraform, Ansible, Pulumi, Kubernetes) |
| 4 | https://support.1password.com/1password-security/ | 2025-01-XX | Detailed security model documentation: end-to-end encryption, PBKDF2 key strengthening, clipboard management, code signature validation |
| 5 | https://1password.com/compliance/ | 2025-01-XX | 404 — page not found; compliance info found on security page instead |

## Bitwarden

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 6 | https://bitwarden.com/pricing/ | 2025-01-XX | Pricing: Teams $4/user/month, Enterprise $6/user/month, billed annually; Premium $1.65/month; Families $3.99/month |
| 7 | https://bitwarden.com/compliance/ | 2025-01-XX | Compliance: SOC 2 Type II, SOC 3, ISO 27001, HIPAA, GDPR, CCPA, Data Privacy Framework |
| 8 | https://bitwarden.com/help/is-bitwarden-audited/ | 2025-01-XX | Detailed audit history: annual third-party security assessments since 2018, cryptography reports, bug bounty program, open source codebase |
| 9 | https://bitwarden.com/developers/ | 2025-01-XX | Developer tools: CLI (`bw`), Secrets Manager CLI, SDKs, GitHub Actions, GitLab CI, Ansible integrations |
| 10 | https://bitwarden.com/open-source/ | 2025-01-XX | Open source: AGPLv3 license, codebase on GitHub |

## LastPass

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 11 | https://www.lastpass.com/pricing | 2025-01-XX | Pricing page (JS-rendered, placeholders); Teams and Business pricing found on comparison page |
| 12 | https://www.lastpass.com/compare/teams-vs-business | 2025-01-XX | Teams: $4.25/user/month, Business: $7.00/user/month, Business Max: $9.00/user/month, billed annually |
| 13 | https://www.lastpass.com/products/business | 2025-01-XX | Business features: 100+ security policies, SSO, SCIM, dark web monitoring, free Families plan for employees |
| 14 | https://compliance.lastpass.com/ | 2025-01-XX | Compliance: SOC 2 Type II, SOC 3, ISO 27001, ISO 27701, C5, IRAP, TRUSTe, APEC CBPR, APEC PRP, EU-US DPF |
| 15 | https://www.lastpass.com/security | 2025-01-XX | Security architecture: zero-knowledge, AES-256, PBKDF2-SHA256 |

## Dashlane

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 16 | https://www.dashlane.com/pricing | 2025-01-XX | Pricing page (JS-rendered, no visible numbers); plan names: Password Management, Credential Protection |
| 17 | https://aws.amazon.com/marketplace/pp/prodview-glvhugk2njxxa | 2025-01-XX | AWS Marketplace listing: Password Management $96/user/year (=$8/user/month), minimum 2 seats |
| 18 | https://trust.dashlane.com/ | 2025-01-XX | Trust Center: SOC 2 Type II, ISO 27001:2022, GDPR, CCPA, HIPAA |
| 19 | https://www.dashlane.com/security | 2025-01-XX | Security model: zero-knowledge, AWS Nitro Enclaves, 8 patents (6 pending), bug bounty via HackerOne, annual penetration testing |
| 20 | https://www.dashlane.com/business-password-manager | 2025-01-XX | Business features overview; no developer tooling (no CLI, no SDKs, no CI/CD integrations) |

## Keeper Security

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 21 | https://www.keepersecurity.com/pricing/business-and-enterprise.html | 2025-01-XX | Pricing: Business Starter (price JS-rendered), Business $4.00/user/month, Enterprise $6.00/user/month, billed annually |
| 22 | https://trust.keeper.io/ | 2025-01-XX | Trust Center: SOC 2, SOC 3, ISO 27001:2022, ISO 27017, ISO 27018, GDPR, CCPA, FedRAMP Rev. 5, DORA |
| 23 | https://www.keepersecurity.com/security.html | 2025-01-XX | Security model: AES-256 + ECC encryption, zero-knowledge, zero-trust, bug bounty via Bugcrowd |
| 24 | https://www.keepersecurity.com/business.html | 2025-01-XX | Business features: encrypted vaults, shared folders, role-based policies, free Family plan |
| 25 | https://www.keepersecurity.com/vs/1password/ | 2025-01-XX | Comparison with 1Password; Keeper Family: $7.67/month |

## Third-Party Sources

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 26 | https://www.g2.com/products/1password/reviews | 2025-01-XX | G2 reviews for 1Password (no pricing data extracted) |
| 27 | https://www.capterra.com/p/152780/1Password/ | 2025-01-XX | Capterra listing for 1Password (no pricing data extracted) |
| 28 | https://www.capterra.com/p/152782/Dashlane/ | 2025-01-XX | Capterra listing for Dashlane (no pricing data extracted) |

## Notes on Data Quality

- **1Password pricing:** Confirmed from official pricing page via Jina AI extraction. $7.99/user/month for Business tier.
- **Bitwarden pricing:** Confirmed from official pricing page. $4/user/month (Teams), $6/user/month (Enterprise).
- **LastPass pricing:** Confirmed from comparison page (teams-vs-business). $4.25/user/month (Teams), $7.00/user/month (Business).
- **Dashlane pricing:** Not publicly listed on dashlane.com (JS-rendered). Found $96/user/year via AWS Marketplace listing. This is the only publicly verifiable price point.
- **Keeper pricing:** Business ($4.00/user/month) and Enterprise ($6.00/user/month) confirmed from pricing page. Business Starter price is JS-rendered and not publicly extractable.
- **LastPass breach (May 2022):** Widely reported across tech media. Not fetched from a specific source during this research session, but is a well-documented public event.
