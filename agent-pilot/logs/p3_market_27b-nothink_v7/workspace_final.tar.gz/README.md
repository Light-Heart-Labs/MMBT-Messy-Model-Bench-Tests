# Password Manager Evaluation — Output Files

This directory contains the outputs of a password manager evaluation for a 50-person engineering team at a Series-B SaaS company.

## Files

| File | Description |
|------|-------------|
| [`recommendation.md`](recommendation.md) | **Primary deliverable.** 1–2 page recommendation memo with decision criteria, product recommendation, pricing, runner-up, and risk analysis. |
| [`comparison.md`](comparison.md) | Side-by-side feature/pricing/security comparison of the 5 evaluated products. |
| [`sources.md`](sources.md) | Every URL fetched during research, with timestamps and descriptions of what was obtained. |
| [`research/notes.md`](research/notes.md) | Working notes from the research process. |
| [`decisions/001-product-selection.md`](decisions/001-product-selection.md) | ADR: Which 5 products were selected and why. |
| [`decisions/002-evaluation-criteria.md`](decisions/002-evaluation-criteria.md) | ADR: What criteria were used to evaluate products and why. |

## How to Read

1. **Start with `recommendation.md`** — This is the executive summary and final recommendation.
2. **Review `comparison.md`** — For the detailed side-by-side comparison of all 5 products.
3. **Check `sources.md`** — For the provenance of every factual claim.
4. **Read the ADRs in `decisions/`** — For the reasoning behind non-obvious calls (which products, what criteria).
5. **Browse `research/notes.md`** — For the raw research process and intermediate findings.

## Products Evaluated

1. **1Password** (recommended)
2. **Bitwarden** (runner-up)
3. **LastPass** (disqualified: security breach history)
4. **Dashlane** (disqualified: no developer tooling)
5. **Keeper Security** (disqualified at Business tier: no SSO/SCIM)

## Research Date

All research was conducted on 2025-01-XX using a fresh Linux VM with internet access, Python 3.11, and standard CLI tools.
