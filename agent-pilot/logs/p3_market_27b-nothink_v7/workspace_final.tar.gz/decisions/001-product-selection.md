# ADR-001: Product Selection for Password Manager Evaluation

**Date:** 2025-01-XX
**Status:** Accepted
**Decision Makers:** Engineering leadership

## Context

We need to evaluate password managers for a 50-person engineering team at a Series-B SaaS company. The team currently has shadow-IT password storage (browser, sticky notes, Slack DMs) and the CTO wants this fixed within 90 days.

## Decision

We selected the following 5 password managers for evaluation:

1. **1Password** — Market leader, strong developer tooling, SOC 2 Type II
2. **Bitwarden** — Open source, self-hostable, most cost-effective
3. **LastPass** — Well-known brand, but with significant security incident history
4. **Dashlane** — Modern UI, strong security model, AWS Nitro Enclaves
5. **Keeper Security** — FedRAMP certified, strong compliance posture

### Rationale for selection

- **1Password**: Consistently top-rated in independent reviews; strong developer integrations (CLI, SDKs, CI/CD); SOC 2 Type II certified.
- **Bitwarden**: Open source (auditable codebase); self-hosting option; most affordable pricing; SOC 2 Type II and ISO 27001 certified.
- **LastPass**: Historically the most widely deployed password manager; included for comparison despite security concerns.
- **Dashlane**: Modern zero-knowledge architecture with AWS Nitro Enclaves; SOC 2 Type II and ISO 27001 certified.
- **Keeper Security**: FedRAMP certified (unique among the group); strong compliance posture; AES-256 + ECC encryption.

### Products considered but excluded

- **NordPass**: Smaller market share, less mature admin console, fewer developer integrations.
- **Google Password Manager**: Not a standalone product; lacks admin console, audit logs, and team management features needed for SOC 2 compliance.
- **CyberArk Conjur / HashiCorp Vault**: These are secrets management infrastructure, not password managers for human users. They solve a different problem.

## Consequences

- This selection covers the spectrum from open-source/self-hosted (Bitwarden) to enterprise-grade compliance (Keeper) to market leader (1Password).
- LastPass is included despite its 2022 breach history because it remains a significant market player and its pricing/features are relevant for comparison.
