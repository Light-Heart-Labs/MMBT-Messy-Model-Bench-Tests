# ADR-002: Evaluation Criteria

**Date:** 2025-01-XX
**Status:** Accepted
**Decision Makers:** Engineering leadership

## Context

We need to define the criteria by which we evaluate password managers for our 50-person engineering team. The criteria must reflect our specific needs as a Series-B SaaS company.

## Decision

The following criteria were established, in order of importance:

### Tier 1: Must-Have Criteria

1. **SSO Integration** — Must support SAML 2.0 SSO with Google Workspace (our IdP). SCIM provisioning is a strong plus.
2. **Audit Logging** — Must provide detailed audit logs for SOC 2 compliance (who accessed what, when, from where).
3. **Zero-Knowledge Architecture** — Vendor must not be able to access plaintext vault data. End-to-end encryption is non-negotiable.
4. **Cross-Platform Coverage** — Must support macOS, Windows, Linux, iOS, Android, and major browsers (Chrome, Firefox, Safari, Edge).
5. **Developer Tooling** — Must provide CLI access and CI/CD integrations (GitHub Actions, GitLab CI, etc.) for our engineering workflow.

### Tier 2: Important Criteria

6. **Pricing Transparency** — Publicly listed per-seat pricing preferred. "Contact sales" only is a negative signal.
7. **Admin Console** — Must have a web-based admin console for user management, policy enforcement, and reporting.
8. **Security Certifications** — SOC 2 Type II is the baseline. ISO 27001 and FedRAMP are bonuses.
9. **Security Incident History** — Past breaches or security incidents are weighed heavily against a product.

### Tier 3: Nice-to-Have Criteria

10. **Self-Hosting Option** — Ability to self-host is valued but not required.
11. **Open Source** — Auditable codebase is valued but not required.
12. **Mobile Biometrics** — Touch ID / Face ID / fingerprint unlock on mobile.
13. **Passkey Support** — Native passkey management and usage.
14. **Free Personal Plan for Employees** — Reduces risk of personal credential reuse affecting work accounts.

## Consequences

- Products that fail Tier 1 criteria are disqualified regardless of other strengths.
- Pricing is evaluated at the 50-seat annual commitment level.
- Security incident history is a significant differentiator, particularly for products with known breaches.
