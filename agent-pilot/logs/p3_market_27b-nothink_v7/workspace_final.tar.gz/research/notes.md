# Research Notes — Password Manager Evaluation

## Context
- 50-person engineering team, Series-B SaaS company
- Current state: shadow IT (browser, sticky notes, Slack DMs)
- CTO mandate: fix within 90 days
- Need: team-wide standardization

## Research Methodology
- Used `curl` + Jina AI (`r.jina.ai`) to extract content from JS-rendered pages
- Cross-referenced pricing across multiple sources (official sites, AWS Marketplace, comparison pages)
- Checked compliance on official trust/compliance pages, not blog posts
- Checked security incident history via official security pages and public records

## Candidate Products Evaluated
1. **1Password** — Business tier, $7.99/user/month
2. **Bitwarden** — Teams ($4) and Enterprise ($6) tiers
3. **LastPass** — Teams ($4.25) and Business ($7) tiers
4. **Dashlane** — Password Management, $8/user/month (via AWS Marketplace)
5. **Keeper Security** — Business ($4) and Enterprise ($6) tiers

## Key Findings

### Pricing (50 seats, annual)
- 1Password Business: $4,794/year
- Bitwarden Teams: $2,400/year (no SSO)
- Bitwarden Enterprise: $3,600/year (has SSO)
- LastPass Teams: $2,550/year (no SSO)
- LastPass Business: $4,200/year (has SSO)
- Dashlane PM: $4,800/year
- Keeper Business: $2,400/year (no SSO)
- Keeper Enterprise: $3,600/year (has SSO)

### SSO/SCIM Availability
- 1Password Business: ✅
- Bitwarden Teams: ❌ (Enterprise only)
- LastPass Business: ✅
- Dashlane: ✅
- Keeper Business: ❌ (Enterprise only)

### Developer Tooling
- 1Password: Best (CLI, SSH agent, Git signing, SDKs, 7+ CI/CD integrations)
- Bitwarden: Good (CLI, GitHub Actions, GitLab CI, Ansible)
- LastPass: Minimal (CLI only, no CI/CD)
- Dashlane: None (no CLI, no SDKs, no CI/CD)
- Keeper: Good (CLI, GitHub, GitLab, Jenkins, Terraform, Ansible)

### Security Incidents
- LastPass: Major breach in May 2022 (encrypted vault data, SSH keys, metadata exposed)
- All others: No publicly disclosed breaches

### Compliance
- 1Password: SOC 2 Type II
- Bitwarden: SOC 2 Type II, SOC 3, ISO 27001, HIPAA
- LastPass: SOC 2 Type II, SOC 3, ISO 27001, ISO 27701
- Dashlane: SOC 2 Type II, ISO 27001, HIPAA
- Keeper: SOC 2, SOC 3, ISO 27001, ISO 27017, ISO 27018, FedRAMP

## Decision Rationale
1Password wins on developer tooling + clean security history + SOC 2 readiness.
Bitwarden Enterprise is the runner-up (cheaper, open source, self-hostable).
LastPass is disqualified due to 2022 breach.
Dashlane is disqualified due to lack of developer tooling.
Keeper Business is disqualified due to missing SSO/SCIM (Enterprise tier is competitive but trails 1Password on dev tools).

## Data Quality Notes
- Dashlane pricing not publicly listed on their website; found via AWS Marketplace ($96/user/year)
- Keeper Business Starter pricing is JS-rendered and not extractable
- LastPass breach is a well-documented public event (May 2022)
- All other pricing confirmed from official sources
