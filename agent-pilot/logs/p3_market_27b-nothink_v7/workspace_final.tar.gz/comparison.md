# Password Manager Comparison: 5-Product Evaluation

**Date:** 2025-01-XX
**Scope:** 50-person engineering team, Series-B SaaS company

## Pricing Comparison (Annual, Per User)

| Product | Tier | Per-Seat Price (Annual) | 50-Seat Annual Cost | Source |
|---------|------|------------------------|---------------------|--------|
| 1Password | Business | $7.99/user/month ($95.88/user/year) | $4,794/year | [1Password Pricing][1] |
| Bitwarden | Teams | $4.00/user/month ($48.00/user/year) | $2,400/year | [Bitwarden Pricing][2] |
| Bitwarden | Enterprise | $6.00/user/month ($72.00/user/year) | $3,600/year | [Bitwarden Pricing][2] |
| LastPass | Teams | $4.25/user/month ($51.00/user/year) | $2,550/year | [LastPass Teams vs Business][3] |
| LastPass | Business | $7.00/user/month ($84.00/user/year) | $4,200/year | [LastPass Teams vs Business][3] |
| Dashlane | Password Management | $8.00/user/month ($96.00/user/year) | $4,800/year | [AWS Marketplace][4] |
| Keeper | Business | $4.00/user/month ($48.00/user/year) | $2,400/year | [Keeper Pricing][5] |
| Keeper | Enterprise | $6.00/user/month ($72.00/user/year) | $3,600/year | [Keeper Pricing][5] |

> **Note:** Keeper Business Starter pricing is not publicly listed (JS-rendered on their site). The Business tier starts at $4.00/user/month.

## Feature Comparison

| Feature | 1Password Business | Bitwarden Teams | Bitwarden Enterprise | LastPass Business | Dashlane PM | Keeper Business |
|---------|-------------------|-----------------|---------------------|-------------------|-------------|-----------------|
| **SSO (SAML 2.0)** | ✅ | ❌ (Teams) | ✅ | ✅ | ✅ | ❌ (Enterprise only) |
| **SCIM Provisioning** | ✅ | ❌ (Teams) | ✅ | ✅ | ✅ | ❌ (Enterprise only) |
| **Audit Logs** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Zero-Knowledge** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **macOS / Windows** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Linux Desktop** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **iOS / Android** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Browser Extensions** | ✅ (Chrome, Safari, Edge, Firefox, Brave) | ✅ (Chrome, Firefox, Edge, Safari, Opera) | ✅ | ✅ | ✅ | ✅ |
| **CLI** | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ |
| **CI/CD Integrations** | ✅ (GitHub, GitLab, Jenkins, Terraform, Ansible, Pulumi, Kubernetes) | ✅ (GitHub Actions, GitLab CI, Ansible) | ✅ | ❌ | ❌ | ✅ |
| **SDKs** | ✅ (Python, JS, Go) | ✅ (via Secrets Manager) | ✅ | ❌ | ❌ | ✅ |
| **Self-Hosting** | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ |
| **Open Source** | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ |
| **Free Personal Plan** | ✅ (Families plan) | ❌ | ✅ (Families plan) | ✅ (Families plan) | ❌ | ✅ (Family plan) |
| **Passkey Support** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Mobile Biometrics** | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |

## Security & Compliance Comparison

| Certification | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|--------------|-----------|-----------|----------|----------|--------|
| **SOC 2 Type II** | ✅ [6] | ✅ [7] | ✅ [8] | ✅ [9] | ✅ [10] |
| **SOC 3** | ✅ [6] | ✅ [7] | ✅ [8] | — | ✅ [10] |
| **ISO 27001** | — | ✅ [7] | ✅ [8] | ✅ [9] | ✅ [10] |
| **ISO 27017** | — | — | — | — | ✅ [10] |
| **ISO 27018** | — | — | — | — | ✅ [10] |
| **FedRAMP** | — | — | — | — | ✅ [10] |
| **HIPAA** | — | ✅ [7] | — | ✅ [9] | — |
| **GDPR** | ✅ [6] | ✅ [7] | ✅ [8] | ✅ [9] | ✅ [10] |
| **CCPA** | ✅ [6] | ✅ [7] | ✅ [8] | ✅ [9] | ✅ [10] |
| **Bug Bounty** | ✅ | ✅ | ✅ | ✅ | ✅ |

## Security Incident History

| Product | Known Incidents | Details |
|---------|----------------|---------|
| **1Password** | None publicly disclosed | No known breaches of customer vault data. |
| **Bitwarden** | None publicly disclosed | No known breaches of customer vault data. |
| **LastPass** | **Major breach (May 2022)** | Attackers accessed encrypted vault data, SSH keys, and other customer data. While vault data was encrypted, the breach exposed encrypted blobs, metadata, and some unencrypted data. [11] |
| **Dashlane** | None publicly disclosed | No known breaches of customer vault data. |
| **Keeper** | None publicly disclosed | No known breaches of customer vault data. |

## Developer Tooling Deep Dive

| Tool | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|------|-----------|-----------|----------|----------|--------|
| **CLI** | `op` CLI with SSH agent, Git commit signing | `bw` CLI | `lpass` CLI | ❌ | `keepercommander` CLI |
| **SSH Agent** | ✅ Native | ❌ | ❌ | ❌ | ❌ |
| **Git Commit Signing** | ✅ | ❌ | ❌ | ❌ | ❌ |
| **GitHub Actions** | ✅ | ✅ | ❌ | ❌ | ✅ |
| **GitLab CI** | ✅ | ✅ | ❌ | ❌ | ✅ |
| **Jenkins** | ✅ | ❌ | ❌ | ❌ | ✅ |
| **Terraform** | ✅ | ❌ | ❌ | ❌ | ✅ |
| **Ansible** | ✅ | ✅ | ❌ | ❌ | ✅ |
| **Kubernetes** | ✅ | ❌ | ❌ | ❌ | ✅ |
| **Pulumi** | ✅ | ❌ | ❌ | ❌ | ❌ |
| **SDKs** | Python, JS, Go | Via Secrets Manager | ❌ | ❌ | Python, JS, Go, Java, .NET |

## Summary Scoring

| Criterion | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|-----------|-----------|-----------|----------|----------|--------|
| **Pricing (50 seats)** | $4,794/yr | $2,400–$3,600/yr | $2,550–$4,200/yr | $4,800/yr | $2,400–$3,600/yr |
| **SSO + SCIM** | ✅✅ | ❌ (Teams) / ✅ (Ent) | ✅✅ | ✅✅ | ❌ (Bus) / ✅ (Ent) |
| **Audit Logs** | ✅✅ | ✅✅ | ✅✅ | ✅✅ | ✅✅ |
| **Developer Tools** | ✅✅✅ | ✅✅ | ✅ | ❌ | ✅✅ |
| **Security Incidents** | ✅✅✅ | ✅✅✅ | ❌❌ | ✅✅✅ | ✅✅✅ |
| **Compliance** | ✅✅ | ✅✅ | ✅✅ | ✅✅ | ✅✅✅ |
| **Open Source** | ❌ | ✅✅✅ | ❌ | ❌ | ❌ |
| **Self-Hosting** | ❌ | ✅✅✅ | ❌ | ❌ | ❌ |

---

## Sources

[1] https://1password.com/pricing/ — 1Password Business pricing: $7.99/user/month billed annually
[2] https://bitwarden.com/pricing/ — Bitwarden Teams: $4/user/month, Enterprise: $6/user/month billed annually
[3] https://www.lastpass.com/compare/teams-vs-business — LastPass Teams: $4.25/user/month, Business: $7/user/month billed annually
[4] https://aws.amazon.com/marketplace/pp/prodview-glvhugk2njxxa — Dashlane Password Management: $96/user/year via AWS Marketplace
[5] https://www.keepersecurity.com/pricing/business-and-enterprise.html — Keeper Business: $4/user/month, Enterprise: $6/user/month billed annually
[6] https://1password.com/security/ — 1Password SOC 2 Type II certification
[7] https://bitwarden.com/compliance/ — Bitwarden SOC 2 Type II, SOC 3, ISO 27001, HIPAA
[8] https://compliance.lastpass.com/ — LastPass SOC 2 Type II, SOC 3, ISO 27001, ISO 27701
[9] https://trust.dashlane.com/ — Dashlane SOC 2 Type II, ISO 27001, HIPAA
[10] https://trust.keeper.io/ — Keeper SOC 2, SOC 3, ISO 27001, ISO 27017, ISO 27018, FedRAMP
[11] LastPass May 2022 breach — widely reported; attackers accessed encrypted vault data and metadata
