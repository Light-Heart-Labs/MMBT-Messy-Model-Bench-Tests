# Company Selection Research Session
Date: 2025-01-10

## Criteria
- Publicly traded US company
- Market cap between $1B and $10B
- Sufficient public data (SEC filings, earnings calls)
- Interesting investment thesis potential

## Candidates to Evaluate
1. Need to screen for interesting small-caps
2. Looking for companies with clear competitive advantages or interesting dynamics
3. Prefer companies with recurring revenue or strong moats

## Next Steps
- Screen for candidates using available data
- Evaluate 3-5 candidates
- Select one for deep dive
