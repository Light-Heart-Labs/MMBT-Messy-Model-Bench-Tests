# Sources

Generated: 2026-04-26T18:43:29.653472

## SEC Filings

- **s-20260131.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000020/s-20260131.htm
  - SHA-256: 9b4f5f95ac8c13590e4d709bc2887c802569b47d98665cc67f56be655293fac0
  - Size: 2255174 bytes

- **s-20250131.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000051/s-20250131.htm
  - SHA-256: ea7301d8290cb32fcb38ab8315dfbf7da6e6e8e1d25a58780d7df1c9d31fb43b
  - Size: 2150787 bytes

- **s-20240131.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370824000016/s-20240131.htm
  - SHA-256: 2cd2ba45b5981eba92ff68e90b3cdf71de99e58e2c93dcb9d9eec2ee7c2b5816
  - Size: 2172140 bytes

- **s-20251031.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000159/s-20251031.htm
  - SHA-256: 9e9e8087d6950dc88dc499ad1fa6ccd521c15364a30b7921c01f3d1bca4e9982
  - Size: 1642638 bytes

- **s-20250731.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000148/s-20250731.htm
  - SHA-256: f05b2470a2b2ecf15ab2be327d9b25c6c8b36daa89337d1b2ced19213a9b27ff
  - Size: 1578905 bytes

- **s-20250430.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000106/s-20250430.htm
  - SHA-256: 5ab9d9c5eb58d9b9f6a65868f5dad9f3fb50048d6f60492ebceb4fc8cc289e08
  - Size: 1309779 bytes

- **s-20241031.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370824000125/s-20241031.htm
  - SHA-256: 4b5b5070c7018fe4a90c432800c1046273514c0ef05f9d7d37e06fbadccdae43
  - Size: 1586972 bytes

- **s-20260319.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000025/s-20260319.htm
  - SHA-256: bdd4c361813e4a099f092509cfce3e335e649fa545f2de00420f9b29b2365110
  - Size: 41302 bytes

- **s-20260312.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000014/s-20260312.htm
  - SHA-256: e61fdaae7fe33f4e099ef607b5ee0d99937e66da0e03898a648aab90b7164aae
  - Size: 44939 bytes

- **s-20260228.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000009/s-20260228.htm
  - SHA-256: 6c9451ce7d98cfe0bddc2e11378f1e2c724991518322570ab411aff3e2413157
  - Size: 46916 bytes

- **s-20260108.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000003/s-20260108.htm
  - SHA-256: 83b27668dad2364f2c301552846f50b68576b4ab29364bb1f7ee16d2def282d1
  - Size: 36377 bytes

- **s-20251204.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000157/s-20251204.htm
  - SHA-256: 1603a16a288e970eb8560d648f81367a8af02a7b44a292b035d9e6cdff8cd16c
  - Size: 55713 bytes


## Earnings 8-K Filings

- **8k_20260325.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000025/s-20260319.htm
  - SHA-256: bdd4c361813e4a099f092509cfce3e335e649fa545f2de00420f9b29b2365110
  - Date: 2026-03-25

- **8k_20260312.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000014/s-20260312.htm
  - SHA-256: e61fdaae7fe33f4e099ef607b5ee0d99937e66da0e03898a648aab90b7164aae
  - Date: 2026-03-12

- **8k_20260305.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000009/s-20260228.htm
  - SHA-256: 6c9451ce7d98cfe0bddc2e11378f1e2c724991518322570ab411aff3e2413157
  - Date: 2026-03-05

- **8k_20251204.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000157/s-20251204.htm
  - SHA-256: 1603a16a288e970eb8560d648f81367a8af02a7b44a292b035d9e6cdff8cd16c
  - Date: 2025-12-04

- **8k_20250828.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000146/s-20250828.htm
  - SHA-256: 759266d15590f8e974de5d81b551a0c1c2ec4689852dc8d5a364f176133423f6
  - Date: 2025-08-28

- **8k_20250528.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000104/s-20250528.htm
  - SHA-256: 2899aad47f9c81c2e11caec67dd7f03014d6d65700ff101b1df1225e4dd54470
  - Date: 2025-05-28


## Earnings Press Release Exhibits

- **sentineloneq426exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000014/sentineloneq426exhibit991.htm
  - SHA-256: 2d91e9951514773ffc0c19b11a526fad71f89c67d0bd865eae80ef5bd25981c3
  - Date: 2026-03-12

- **sentineloneq426exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000014/sentineloneq426exhibit991.htm
  - SHA-256: 2d91e9951514773ffc0c19b11a526fad71f89c67d0bd865eae80ef5bd25981c3
  - Date: 2026-03-12

- **sentineloneq426exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000014/sentineloneq426exhibit991.htm
  - SHA-256: 2d91e9951514773ffc0c19b11a526fad71f89c67d0bd865eae80ef5bd25981c3
  - Date: 2026-03-12

- **sentineloneq426exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000014/sentineloneq426exhibit991.htm
  - SHA-256: 2d91e9951514773ffc0c19b11a526fad71f89c67d0bd865eae80ef5bd25981c3
  - Date: 2026-03-12

- **sentineloneq426exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000014/sentineloneq426exhibit991.htm
  - SHA-256: 2d91e9951514773ffc0c19b11a526fad71f89c67d0bd865eae80ef5bd25981c3
  - Date: 2026-03-12

- **sentineloneq426exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370826000014/sentineloneq426exhibit991.htm
  - SHA-256: 2d91e9951514773ffc0c19b11a526fad71f89c67d0bd865eae80ef5bd25981c3
  - Date: 2026-03-12

- **sentineloneq326exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000157/sentineloneq326exhibit991.htm
  - SHA-256: 35e779df53bca253cb6d04dd627ad99990bf5b453da463645ad48029c7168e06
  - Date: 2025-12-04

- **sentineloneq326exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000157/sentineloneq326exhibit991.htm
  - SHA-256: 35e779df53bca253cb6d04dd627ad99990bf5b453da463645ad48029c7168e06
  - Date: 2025-12-04

- **sentineloneq326exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000157/sentineloneq326exhibit991.htm
  - SHA-256: 35e779df53bca253cb6d04dd627ad99990bf5b453da463645ad48029c7168e06
  - Date: 2025-12-04

- **sentineloneq326exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000157/sentineloneq326exhibit991.htm
  - SHA-256: 35e779df53bca253cb6d04dd627ad99990bf5b453da463645ad48029c7168e06
  - Date: 2025-12-04

- **sentineloneq226exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000146/sentineloneq226exhibit991.htm
  - SHA-256: 8328c9c8f5aae779eb97b54020da1af6aa3d1d11b0bd5d68658c3b2c0a831278
  - Date: 2025-08-28

- **sentineloneq226exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000146/sentineloneq226exhibit991.htm
  - SHA-256: 8328c9c8f5aae779eb97b54020da1af6aa3d1d11b0bd5d68658c3b2c0a831278
  - Date: 2025-08-28

- **sentineloneq226exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000146/sentineloneq226exhibit991.htm
  - SHA-256: 8328c9c8f5aae779eb97b54020da1af6aa3d1d11b0bd5d68658c3b2c0a831278
  - Date: 2025-08-28

- **sentineloneq226exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000146/sentineloneq226exhibit991.htm
  - SHA-256: 8328c9c8f5aae779eb97b54020da1af6aa3d1d11b0bd5d68658c3b2c0a831278
  - Date: 2025-08-28

- **sentineloneq126exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000104/sentineloneq126exhibit991.htm
  - SHA-256: 22f435aec6957b8feef5b3399766df2eb08435fffb5711d15cb6eb4783dbe858
  - Date: 2025-05-28

- **sentineloneq126exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000104/sentineloneq126exhibit991.htm
  - SHA-256: 22f435aec6957b8feef5b3399766df2eb08435fffb5711d15cb6eb4783dbe858
  - Date: 2025-05-28

- **sentineloneq126exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000104/sentineloneq126exhibit991.htm
  - SHA-256: 22f435aec6957b8feef5b3399766df2eb08435fffb5711d15cb6eb4783dbe858
  - Date: 2025-05-28

- **sentineloneq126exhibit991.htm**
  - URL: https://www.sec.gov/Archives/edgar/data/0001583708/000158370825000104/sentineloneq126exhibit991.htm
  - SHA-256: 22f435aec6957b8feef5b3399766df2eb08435fffb5711d15cb6eb4783dbe858
  - Date: 2025-05-28

