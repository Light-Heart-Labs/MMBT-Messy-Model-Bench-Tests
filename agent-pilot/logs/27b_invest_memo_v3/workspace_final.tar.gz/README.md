# Investment Memo Repository

## Overview
This repository contains a complete investment analysis of a publicly traded US company with a market cap between $1B and $10B.

## How to Navigate

1. **Start with `/memo/`** - The final investment memo (PDF + source markdown)
2. **Review `/decisions/`** - ADR-style records explaining key analytical choices
3. **Check `/research/questions.md`** - Questions encountered and how they were resolved
4. **Check `/research/dead-ends.md`** - Investigated paths that didn't pan out
5. **Review `/model/`** - Three-statement financial model (Excel)
6. **Trace numbers** - Every number in the memo traces back through:
   - `/raw/` (original SEC filings, transcripts, press releases)
   - `/extracted/` (parsed/cleaned data with extraction scripts)
   - `/model/` (financial model cells)
   - `/memo/` (final memo)
7. **Verify sources** - `/sources.md` contains every URL with timestamps and content SHAs
8. **Audit tools** - `/tool-log.md` documents every tool call with justification

## Company
[To be determined after initial screening]

## Recommendation
[To be determined after analysis]

## Timeline
- Research started: [Date]
- Research completed: [Date]
