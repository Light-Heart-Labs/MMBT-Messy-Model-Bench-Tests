"""
Fetch earnings call transcripts from accessible sources
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}

# Try to get transcripts from various accessible sources
transcript_sources = [
    # Try to find transcripts on the web
    ("Yahoo Finance - S", "https://finance.yahoo.com/quote/S/"),
    ("MarketWatch", "https://www.marketwatch.com/investing/stock/s"),
]

# Try to get the 10-K text for management discussion
print("Extracting MD&A from 10-K filings...")
for fpath in [
    '/workspace/raw/filings/10-K/s-20260131.htm',
    '/workspace/raw/filings/10-K/s-20250131.htm',
]:
    with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    soup = BeautifulSoup(content, 'lxml')
    text = soup.get_text(separator='\n', strip=True)
    
    # Find MD&A section
    lines = text.split('\n')
    mda = []
    in_mda = False
    for line in lines:
        if 'Management\'s Discussion' in line or 'MANAGEMENT\'S DISCUSSION' in line:
            in_mda = True
        if in_mda:
            mda.append(line)
        if 'Risk Factors' in line and in_mda:
            break
    
    mda_text = '\n'.join(mda[:200])
    print(f"\nMD&A from {fpath.split('/')[-1]}:")
    for line in mda_text.split('\n')[:30]:
        print(f"  {line[:120]}")

# Try to get transcripts from a known source
print("\n\nTrying to get earnings call transcripts...")

# Try to get from the SEC's EDGAR full-text search
# Or try to find transcripts on accessible financial sites
try:
    # Try to get from a transcript aggregator
    resp = requests.get(
        "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0001583708&type=&dateb=&owner=include&count=100&search_text=&x=0&y=0",
        headers=headers, timeout=30
    )
    print(f"SEC browse: {resp.status_code}")
except Exception as e:
    print(f"Error: {e}")

# Try to get from the 10-K the management quotes
print("\n\nExtracting key management quotes from 10-K...")
for fpath in ['/workspace/raw/filings/10-K/s-20260131.htm']:
    with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    soup = BeautifulSoup(content, 'lxml')
    text = soup.get_text(separator='\n', strip=True)
    
    # Find quotes from management
    lines = text.split('\n')
    for i, line in enumerate(lines):
        if any(kw in line.lower() for kw in ['we believe', 'we are confident', 'our strategy', 'our vision', 'we expect']):
            if len(line) > 50:
                print(f"  Line {i}: {line[:150]}")

