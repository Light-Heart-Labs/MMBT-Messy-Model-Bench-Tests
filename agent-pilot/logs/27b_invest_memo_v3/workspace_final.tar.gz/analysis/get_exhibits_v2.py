"""
Get press release exhibits from 8-K filings by trying common naming patterns
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

CIK = "0001583708"
BASE_URL = "https://www.sec.gov/Archives/edgar/data"

headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}

# Get all filings
url = f"https://data.sec.gov/submissions/CIK{CIK}.json"
resp = requests.get(url, headers=headers, timeout=30)
data = resp.json()
recent = data.get('filings', {}).get('recent', {})
n = len(recent.get('accessionNumber', []))

# Find earnings-related 8-Ks
earnings_dates = []
for i in range(n):
    if recent['form'][i] == '8-K':
        filing_date = recent['filingDate'][i]
        month = int(filing_date.split('-')[1])
        if month in [2, 3, 5, 8, 11, 12]:
            earnings_dates.append({
                'accession': recent['accessionNumber'][i],
                'date': filing_date,
                'report_date': recent['reportDate'][i],
                'primary_doc': recent['primaryDocument'][i],
            })

# For each earnings 8-K, try to find and download the press release exhibit
os.makedirs('/workspace/raw/transcripts', exist_ok=True)
sources = []

for ek in earnings_dates[:6]:
    accession = ek['accession'].replace('-', '')
    date_str = ek['date'].replace('-', '')
    
    # Try common exhibit naming patterns
    possible_names = [
        f"s-{date_str}x991.htm",
        f"s-{date_str}x991pressrelease.htm",
        f"ex-99.1.htm",
        f"ex991.htm",
        f"ex991pressrelease.htm",
        f"ex991pr.htm",
        f"ex-991.htm",
        f"ex991.htm",
    ]
    
    for name in possible_names:
        file_url = f"{BASE_URL}/{CIK}/{accession}/{name}"
        resp = requests.get(file_url, headers=headers, timeout=30)
        if resp.status_code == 200:
            sha = hashlib.sha256(resp.content).hexdigest()
            filepath = f"/workspace/raw/transcripts/{name}"
            with open(filepath, 'wb') as f:
                f.write(resp.content)
            print(f"Downloaded: {name} ({len(resp.content)} bytes)")
            sources.append({
                'url': file_url,
                'sha': sha,
                'filename': name,
                'date': ek['date']
            })
            break

print(f"\nTotal downloaded: {len(sources)}")

# If still no luck, let's try to get the full 8-K HTML and look for embedded exhibits
if not sources:
    print("\nTrying to parse 8-K HTML for embedded exhibits...")
    
    # Check the 8-K HTML for exhibit references
    for fpath in [
        '/workspace/raw/transcripts/8k_20260312.htm',
        '/workspace/raw/transcripts/8k_20251204.htm',
    ]:
        if not os.path.exists(fpath):
            continue
        
        with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
        
        soup = BeautifulSoup(content, 'lxml')
        
        # Look for exhibit references
        for tag in soup.find_all(['a', 'div', 'p']):
            text = tag.get_text().strip()
            if 'exhibit' in text.lower() or 'press release' in text.lower():
                print(f"  Found: {text[:100]}")
                if tag.name == 'a' and tag.get('href'):
                    print(f"    Link: {tag.get('href')}")

