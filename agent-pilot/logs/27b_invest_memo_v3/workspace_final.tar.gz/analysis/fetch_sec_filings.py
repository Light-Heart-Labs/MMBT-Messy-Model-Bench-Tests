"""
Fetch SEC filings for SentinelOne (CIK: 0001583708)
"""
import requests
import json
import os
import hashlib
from datetime import datetime

CIK = "0001583708"
BASE_URL = "https://www.sec.gov/Archives/edgar/data"

def get_filings(cik):
    """Get list of filings from SEC EDGAR"""
    url = f"https://data.sec.gov/submissions/CIK{cik}.json"
    headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}
    resp = requests.get(url, headers=headers, timeout=30)
    resp.raise_for_status()
    data = resp.json()
    
    print(f"Company: {data.get('name')}")
    print(f"Tickers: {data.get('tickers')}")
    
    recent = data.get('filings', {}).get('recent', {})
    n = len(recent.get('accessionNumber', []))
    
    filings = []
    for i in range(n):
        filing = {
            'accessionNumber': recent['accessionNumber'][i],
            'filingDate': recent['filingDate'][i],
            'reportDate': recent['reportDate'][i],
            'act': recent['act'][i],
            'form': recent['form'][i],
            'fileNumber': recent['fileNumber'][i],
            'filmNumber': recent['filmNumber'][i],
            'items': recent.get('items', [''])[i] if i < len(recent.get('items', [])) else '',
            'size': recent['size'][i],
            'isXBRL': recent['isXBRL'][i],
            'isInlineXBRL': recent['isInlineXBRL'][i],
            'primaryDocument': recent['primaryDocument'][i],
            'primaryDocDescription': recent['primaryDocDescription'][i],
        }
        filings.append(filing)
    
    return filings

# Get all filings
print("Fetching all filings...")
all_filings = get_filings(CIK)

# Categorize
filings_10k = [f for f in all_filings if f['form'] == '10-K']
filings_10q = [f for f in all_filings if f['form'] == '10-Q']
filings_8k = [f for f in all_filings if f['form'] == '8-K']
filings_s8 = [f for f in all_filings if f['form'] == 'S-8']
filings_4 = [f for f in all_filings if f['form'] == '4']

print(f"\n10-K filings: {len(filings_10k)}")
for f in filings_10k:
    print(f"  {f['reportDate']}: {f['primaryDocument']}")

print(f"\n10-Q filings: {len(filings_10q)}")
for f in filings_10q:
    print(f"  {f['reportDate']}: {f['primaryDocument']}")

print(f"\n8-K filings: {len(filings_8k)}")
for f in filings_8k[:10]:
    print(f"  {f['reportDate']}: {f['primaryDocument']}")

# Save filing list
os.makedirs('/workspace/raw/filings', exist_ok=True)
with open('/workspace/raw/filings/filing_list.json', 'w') as fp:
    json.dump({
        'cik': CIK,
        'company': 'SentinelOne Inc',
        '10-K': filings_10k,
        '10-Q': filings_10q,
        '8-K': filings_8k[:10],
        'fetched_at': datetime.now().isoformat()
    }, fp, indent=2)

print("\nFiling list saved to raw/filings/filing_list.json")
