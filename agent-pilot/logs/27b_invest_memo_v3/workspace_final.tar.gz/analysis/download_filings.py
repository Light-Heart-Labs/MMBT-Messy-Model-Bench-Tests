"""
Download SEC filings for SentinelOne
"""
import requests
import json
import os
import hashlib
from datetime import datetime

CIK = "0001583708"
BASE_URL = "https://www.sec.gov/Archives/edgar/data"

# Load filing list
with open('/workspace/raw/filings/filing_list.json') as f:
    filing_data = json.load(f)

headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}

def download_filing(filing, category):
    """Download a single filing"""
    accession = filing['accessionNumber'].replace('-', '')
    filename = filing['primaryDocument']
    
    # Construct URL
    url = f"{BASE_URL}/{CIK}/{accession}/{filename}"
    
    filepath = f"/workspace/raw/filings/{category}/{filename}"
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    try:
        resp = requests.get(url, headers=headers, timeout=60)
        resp.raise_for_status()
        
        # Calculate SHA
        sha = hashlib.sha256(resp.content).hexdigest()
        
        with open(filepath, 'wb') as f:
            f.write(resp.content)
        
        print(f"  Downloaded: {filename} ({len(resp.content)} bytes, SHA: {sha[:16]}...)")
        return {'url': url, 'sha': sha, 'size': len(resp.content), 'filename': filename}
    except Exception as e:
        print(f"  Failed: {filename} - {e}")
        return None

# Download 10-K filings (last 3 years)
print("Downloading 10-K filings...")
sources = []
for filing in filing_data['10-K'][:3]:
    result = download_filing(filing, '10-K')
    if result:
        sources.append(result)

# Download 10-Q filings (last 4 quarters)
print("\nDownloading 10-Q filings...")
for filing in filing_data['10-Q'][:4]:
    result = download_filing(filing, '10-Q')
    if result:
        sources.append(result)

# Download key 8-K filings
print("\nDownloading key 8-K filings...")
for filing in filing_data['8-K'][:5]:
    result = download_filing(filing, '8-K')
    if result:
        sources.append(result)

# Save sources
with open('/workspace/sources.md', 'w') as f:
    f.write("# Sources\n\n")
    f.write(f"Generated: {datetime.now().isoformat()}\n\n")
    f.write("## SEC Filings\n\n")
    for s in sources:
        f.write(f"- **{s['filename']}**\n")
        f.write(f"  - URL: {s['url']}\n")
        f.write(f"  - SHA-256: {s['sha']}\n")
        f.write(f"  - Size: {s['size']} bytes\n\n")

print("\nSources saved to sources.md")
