"""
Fetch earnings call transcripts for SentinelOne from multiple sources
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}

# Try earningswhispers.com
print("Trying earningswhispers.com...")
try:
    resp = requests.get("https://www.earningswhispers.com/sentinelone-inc-s/", headers=headers, timeout=30)
    print(f"  Status: {resp.status_code}")
    if resp.status_code == 200:
        soup = BeautifulSoup(resp.text, 'lxml')
        links = soup.find_all('a', href=True)
        for link in links:
            if 'transcript' in link.get('href', '').lower() or 'earnings' in link.get('href', '').lower():
                print(f"  {link.get('text', '')}: {link.get('href')}")
except Exception as e:
    print(f"  Error: {e}")

# Try the edge
print("\nTrying edge...")
try:
    resp = requests.get("https://edge.media-server.com/p/c/p/edge/sentinelone/", headers=headers, timeout=30)
    print(f"  Status: {resp.status_code}")
except Exception as e:
    print(f"  Error: {e}")

# Try businesswire for press releases
print("\nTrying BusinessWire for press releases...")
try:
    resp = requests.get("https://www.businesswire.com/news/company/SentinelOne/", headers=headers, timeout=30)
    print(f"  Status: {resp.status_code}")
    if resp.status_code == 200:
        soup = BeautifulSoup(resp.text, 'lxml')
        for link in soup.find_all('a', href=True)[:20]:
            text = link.get('text', '').strip()
            if text and len(text) > 10:
                print(f"  {text[:80]}")
except Exception as e:
    print(f"  Error: {e}")

# Try PR Newswire
print("\nTrying PR Newswire...")
try:
    resp = requests.get("https://www.prnewswire.com/news-releases/sentinelone-inc-549087.html", headers=headers, timeout=30)
    print(f"  Status: {resp.status_code}")
except Exception as e:
    print(f"  Error: {e}")

# Try to get transcripts from a known transcript site
print("\nTrying to find transcripts via Google search...")
try:
    # Try a direct transcript URL pattern
    urls = [
        "https://ir.sentinelone.com/news-events/press-releases/",
        "https://ir.sentinelone.com/news-events/press-releases/detail/100/",
    ]
    for url in urls:
        resp = requests.get(url, headers=headers, timeout=30)
        print(f"  {url}: {resp.status_code}")
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.text, 'lxml')
            for link in soup.find_all('a', href=True):
                text = link.get('text', '').strip()
                if text and len(text) > 10:
                    print(f"    {text[:80]} -> {link.get('href')}")
except Exception as e:
    print(f"  Error: {e}")

