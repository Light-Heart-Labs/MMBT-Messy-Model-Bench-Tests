import requests
import json
import re

headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}

# Search SEC for SentinelOne
url = "https://www.sec.gov/cgi-bin/browse-edgar?company=SentinelOne&action=getcompany&type=&dateb=&owner=include&count=5&search_text=&x=0&y=0"
resp = requests.get(url, headers=headers, timeout=30)
print("Status:", resp.status_code)
print("Content (first 2000 chars):")
print(resp.text[:2000])
