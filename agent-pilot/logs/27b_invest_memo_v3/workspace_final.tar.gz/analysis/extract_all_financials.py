"""
Comprehensive financial data extraction from SentinelOne filings
"""
import json
import os
import re
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

def parse_number(s):
    """Parse a number string, handling commas and dollar signs"""
    if not s:
        return None
    s = s.replace('$', '').replace(',', '').replace('%', '').strip()
    if s in ('—', '-', ''):
        return 0
    try:
        return float(s)
    except:
        return None

def extract_from_filing(filepath):
    """Extract all financial tables from a filing"""
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    
    soup = BeautifulSoup(content, 'lxml')
    tables = soup.find_all('table')
    
    results = {}
    
    for table in tables:
        rows = table.find_all('tr')
        if len(rows) < 3:
            continue
        
        text = table.get_text().lower()
        table_data = []
        for row in rows:
            cells = [td.get_text().strip() for td in row.find_all(['th', 'td'])]
            if any(cells):
                table_data.append(cells)
        
        if not table_data:
            continue
        
        # Identify table type
        full_text = ' '.join([' '.join(row) for row in table_data]).lower()
        
        if 'revenue' in full_text and 'cost of revenue' in full_text and 'gross profit' in full_text:
            if 'operating expenses' in full_text or 'research and development' in full_text:
                results['income_statement'] = table_data
        elif 'balance sheet' in full_text or 'assets' in full_text and 'liabilities' in full_text:
            if 'cash and cash equivalents' in full_text:
                results['balance_sheet'] = table_data
        elif 'cash flow' in full_text and 'operating activities' in full_text:
            results['cash_flow'] = table_data
        elif 'recurring revenue' in full_text or 'arr' in full_text:
            results['arr'] = table_data
        elif 'non-gaap operating' in full_text:
            results['non_gaap_reconciliation'] = table_data
        elif 'stock-based compensation' in full_text and 'total stock-based' in full_text:
            results['sbc_breakdown'] = table_data
        elif 'geographic' in full_text or ('u.s.' in full_text and 'international' in full_text and 'revenue' in full_text):
            results['geographic_revenue'] = table_data
        elif 'contract liability' in full_text or 'deferred revenue' in full_text:
            results['deferred_revenue'] = table_data
    
    return results

# Process all filings
filings = {
    'FY2026_10K': '/workspace/raw/filings/10-K/s-20260131.htm',
    'FY2025_10K': '/workspace/raw/filings/10-K/s-20250131.htm',
    'FY2024_10K': '/workspace/raw/filings/10-K/s-20240131.htm',
    'Q3_2026_10Q': '/workspace/raw/filings/10-Q/s-20251031.htm',
    'Q2_2026_10Q': '/workspace/raw/filings/10-Q/s-20250731.htm',
    'Q1_2026_10Q': '/workspace/raw/filings/10-Q/s-20250430.htm',
    'Q4_2025_10Q': '/workspace/raw/filings/10-Q/s-20241031.htm',
}

all_data = {}
for name, filepath in filings.items():
    print(f"Processing {name}...")
    data = extract_from_filing(filepath)
    all_data[name] = data
    for key, val in data.items():
        print(f"  {key}: {len(val)} rows")

# Save extracted data
os.makedirs('/workspace/extracted', exist_ok=True)
with open('/workspace/extracted/financial_data.json', 'w') as f:
    json.dump(all_data, f, indent=2)

print("\nSaved to extracted/financial_data.json")

# Print key metrics
print("\n" + "="*60)
print("KEY METRICS SUMMARY")
print("="*60)

# From FY2026 10-K
fy26 = all_data.get('FY2026_10K', {})
if 'income_statement' in fy26:
    print("\nIncome Statement (from FY2026 10-K):")
    for row in fy26['income_statement'][:15]:
        print(f"  {' | '.join(row)}")

if 'arr' in fy26:
    print("\nARR (from FY2026 10-K):")
    for row in fy26['arr']:
        print(f"  {' | '.join(row)}")

if 'balance_sheet' in fy26:
    print("\nBalance Sheet (from FY2026 10-K):")
    for row in fy26['balance_sheet'][:20]:
        print(f"  {' | '.join(row)}")

