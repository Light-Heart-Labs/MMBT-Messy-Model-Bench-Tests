"""
Extract complete balance sheet and cash flow from FY2026 10-K
"""
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

filepath = '/workspace/raw/filings/10-K/s-20260131.htm'
with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
    content = f.read()

soup = BeautifulSoup(content, 'lxml')
tables = soup.find_all('table')

# Table 29 is the balance sheet - print all rows
print("=== BALANCE SHEET (Table 29) ===")
table = tables[29]
for row in table.find_all('tr'):
    cells = [td.get_text().strip() for td in row.find_all(['th', 'td'])]
    if any(cells):
        print(f"  {' | '.join(cells)}")

# Table 37 is the cash flow - print all rows
print("\n\n=== CASH FLOW STATEMENT (Table 37) ===")
table = tables[37]
for row in table.find_all('tr'):
    cells = [td.get_text().strip() for td in row.find_all(['th', 'td'])]
    if any(cells):
        print(f"  {' | '.join(cells)}")

