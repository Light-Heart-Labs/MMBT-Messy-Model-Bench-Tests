"""
Extract financial data from SentinelOne 10-K filings - v2
Search for specific financial statement tables
"""
import os
import re
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

def find_financial_tables(filepath):
    """Find tables containing financial statement data"""
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    
    soup = BeautifulSoup(content, 'lxml')
    tables = soup.find_all('table')
    
    financial_keywords = [
        'revenue', 'total revenue', 'cost of revenue', 'gross profit',
        'operating expenses', 'operating income', 'net income',
        'total assets', 'total liabilities', 'stockholders',
        'cash flow', 'operating activities', 'investing activities',
        'financing activities', 'balance sheet', 'income statement',
        'consolidated', 'statement of', 'earnings'
    ]
    
    financial_tables = []
    for i, table in enumerate(tables):
        text = table.get_text().lower()
        if any(kw in text for kw in financial_keywords):
            rows = table.find_all('tr')
            if len(rows) > 3:  # Must have at least a few rows
                table_data = []
                for row in rows:
                    cells = [td.get_text().strip() for td in row.find_all(['th', 'td'])]
                    if any(cells):
                        table_data.append(cells)
                if table_data:
                    financial_tables.append({
                        'index': i,
                        'num_rows': len(table_data),
                        'data': table_data
                    })
    
    return financial_tables

# Process FY2026 10-K
filepath = '/workspace/raw/filings/10-K/s-20260131.htm'
print(f"Processing: {filepath}")
tables = find_financial_tables(filepath)
print(f"Found {len(tables)} financial tables\n")

for t in tables:
    print(f"--- Table {t['index']} ({t['num_rows']} rows) ---")
    for row in t['data'][:15]:
        print(f"  {' | '.join(row)}")
    print()

