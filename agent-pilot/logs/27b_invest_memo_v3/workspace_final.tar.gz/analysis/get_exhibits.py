"""
Get press release exhibits from 8-K filings
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

CIK = "0001583708"
BASE_URL = "https://www.sec.gov/Archives/edgar/data"

headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}

# Load filing list
with open('/workspace/raw/filings/filing_list.json') as f:
    filing_data = json.load(f)

# Get all filings
url = f"https://data.sec.gov/submissions/CIK{CIK}.json"
resp = requests.get(url, headers=headers, timeout=30)
data = resp.json()
recent = data.get('filings', {}).get('recent', {})
n = len(recent.get('accessionNumber', []))

# Find earnings-related 8-Ks and download their exhibits
os.makedirs('/workspace/raw/transcripts', exist_ok=True)
sources = []

for i in range(n):
    if recent['form'][i] != '8-K':
        continue
    
    filing_date = recent['filingDate'][i]
    month = int(filing_date.split('-')[1])
    if month not in [2, 3, 5, 8, 11, 12]:
        continue
    
    accession = recent['accessionNumber'][i].replace('-', '')
    
    # Try to get the index
    index_url = f"{BASE_URL}/{CIK}/{accession}/index.json"
    try:
        resp = requests.get(index_url, headers=headers, timeout=30)
        if resp.status_code != 200:
            continue
        
        index_data = resp.json()
        files = index_data.get('information', [{}])[0].get('forms', [{}])[0].get('files', [])
        
        for item in files:
            name = item.get('name', '')
            if '99' in name or 'press' in name.lower():
                file_url = f"{BASE_URL}/{CIK}/{accession}/{name}"
                resp2 = requests.get(file_url, headers=headers, timeout=60)
                if resp2.status_code == 200:
                    sha = hashlib.sha256(resp2.content).hexdigest()
                    filepath = f"/workspace/raw/transcripts/{name}"
                    with open(filepath, 'wb') as f:
                        f.write(resp2.content)
                    print(f"Downloaded: {name} ({len(resp2.content)} bytes)")
                    sources.append({
                        'url': file_url,
                        'sha': sha,
                        'filename': name,
                        'date': filing_date
                    })
    except Exception as e:
        pass

print(f"\nTotal downloaded: {len(sources)}")

# If no exhibits found, try to extract press release text from the 8-K itself
if not sources:
    print("\nNo exhibits found. Extracting press release text from 8-K filings...")
    
    # Check the 8-K HTML for embedded press release text
    for fpath in [
        '/workspace/raw/filings/8-K/s-20260312.htm',  # Q4/FY2026 earnings
        '/workspace/raw/filings/8-K/s-20251204.htm',  # Q3 FY2026 earnings
    ]:
        with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()
        soup = BeautifulSoup(content, 'lxml')
        
        # Look for divs or sections with press release content
        for div in soup.find_all(['div', 'p', 'span']):
            text = div.get_text().strip()
            if 'revenue' in text.lower() and len(text) > 100:
                print(f"\nFound in {fpath.split('/')[-1]}:")
                print(f"  {text[:500]}")
                break

