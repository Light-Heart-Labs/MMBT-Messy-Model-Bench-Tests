"""
Download press release exhibits from 8-K filings
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

CIK = "0001583708"
BASE_URL = "https://www.sec.gov/Archives/edgar/data"

headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}

# Get all filings
url = f"https://data.sec.gov/submissions/CIK{CIK}.json"
resp = requests.get(url, headers=headers, timeout=30)
data = resp.json()
recent = data.get('filings', {}).get('recent', {})
n = len(recent.get('accessionNumber', []))

# Find earnings-related 8-Ks
earnings_dates = []
for i in range(n):
    if recent['form'][i] == '8-K':
        filing_date = recent['filingDate'][i]
        month = int(filing_date.split('-')[1])
        if month in [2, 3, 5, 8, 11, 12]:
            earnings_dates.append({
                'accession': recent['accessionNumber'][i],
                'date': filing_date,
                'report_date': recent['reportDate'][i],
                'primary_doc': recent['primaryDocument'][i],
            })

# For each earnings 8-K, parse the HTML to find exhibit links
os.makedirs('/workspace/raw/transcripts', exist_ok=True)
sources = []

for ek in earnings_dates[:6]:
    accession = ek['accession'].replace('-', '')
    date_str = ek['date'].replace('-', '')
    
    # Download the 8-K HTML
    fpath = f"/workspace/raw/transcripts/8k_{date_str}.htm"
    if not os.path.exists(fpath):
        print(f"  {ek['date']}: 8-K not found, skipping")
        continue
    
    with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    
    soup = BeautifulSoup(content, 'lxml')
    
    # Find exhibit links
    for tag in soup.find_all('a', href=True):
        href = tag.get('href', '')
        if 'exhibit991' in href.lower() or 'ex991' in href.lower():
            file_url = f"{BASE_URL}/{CIK}/{accession}/{href}"
            print(f"  {ek['date']}: Found exhibit link: {href}")
            
            resp = requests.get(file_url, headers=headers, timeout=60)
            if resp.status_code == 200:
                sha = hashlib.sha256(resp.content).hexdigest()
                filepath = f"/workspace/raw/transcripts/{href}"
                with open(filepath, 'wb') as f:
                    f.write(resp.content)
                print(f"    Downloaded: {filepath} ({len(resp.content)} bytes)")
                sources.append({
                    'url': file_url,
                    'sha': sha,
                    'filename': href,
                    'date': ek['date']
                })
            else:
                print(f"    Failed: {resp.status_code}")

print(f"\nTotal downloaded: {len(sources)}")

# Save sources
if sources:
    with open('/workspace/sources.md', 'a') as f:
        f.write("\n## Earnings Press Release Exhibits\n\n")
        for s in sources:
            f.write(f"- **{s['filename']}**\n")
            f.write(f"  - URL: {s['url']}\n")
            f.write(f"  - SHA-256: {s['sha']}\n")
            f.write(f"  - Date: {s['date']}\n\n")
