"""
Extract ARR and other key metrics more precisely
"""
import json
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

filepath = '/workspace/raw/filings/10-K/s-20260131.htm'
with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
    content = f.read()

soup = BeautifulSoup(content, 'lxml')
tables = soup.find_all('table')

# Find ARR table specifically
for i, table in enumerate(tables):
    text = table.get_text().lower()
    if 'annualized recurring revenue' in text or 'arr' in text:
        rows = table.find_all('tr')
        if len(rows) >= 3:
            print(f"\n=== Table {i} (ARR-related, {len(rows)} rows) ===")
            for row in rows:
                cells = [td.get_text().strip() for td in row.find_all(['th', 'td'])]
                if any(cells):
                    print(f"  {' | '.join(cells)}")

# Also find the correct balance sheet
print("\n\n=== Looking for balance sheet ===")
for i, table in enumerate(tables):
    text = table.get_text().lower()
    if 'cash and cash equivalents' in text and 'total current assets' in text:
        rows = table.find_all('tr')
        if len(rows) >= 10:
            print(f"\n=== Table {i} (Balance Sheet, {len(rows)} rows) ===")
            for row in rows:
                cells = [td.get_text().strip() for td in row.find_all(['th', 'td'])]
                if any(cells):
                    print(f"  {' | '.join(cells)}")
            break

# Find cash flow statement
print("\n\n=== Looking for cash flow ===")
for i, table in enumerate(tables):
    text = table.get_text().lower()
    if 'net loss' in text and 'stock-based compensation' in text and 'operating activities' in text:
        rows = table.find_all('tr')
        if len(rows) >= 10:
            print(f"\n=== Table {i} (Cash Flow, {len(rows)} rows) ===")
            for row in rows:
                cells = [td.get_text().strip() for td in row.find_all(['th', 'td'])]
                if any(cells):
                    print(f"  {' | '.join(cells)}")
            break

