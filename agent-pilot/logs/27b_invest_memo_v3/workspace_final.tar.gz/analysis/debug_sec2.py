import requests
import json

CIK = "0001819772"
url = f"https://data.sec.gov/submissions/CIK{CIK}.json"
headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}
resp = requests.get(url, headers=headers, timeout=30)
data = resp.json()

recent = data.get('filings', {}).get('recent', {})
print("Recent keys:", list(recent.keys())[:5])
print("\nFirst key:", list(recent.keys())[0])
first_key = list(recent.keys())[0]
print(f"\nValue for '{first_key}':")
print(json.dumps(recent[first_key], indent=2)[:1000])
