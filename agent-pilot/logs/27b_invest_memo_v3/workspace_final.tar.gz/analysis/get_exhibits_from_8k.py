"""
Get press release exhibits from 8-K filings by parsing the HTML
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

CIK = "0001583708"
BASE_URL = "https://www.sec.gov/Archives/edgar/data"

headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}

# Get all filings
url = f"https://data.sec.gov/submissions/CIK{CIK}.json"
resp = requests.get(url, headers=headers, timeout=30)
data = resp.json()
recent = data.get('filings', {}).get('recent', {})
n = len(recent.get('accessionNumber', []))

# Find earnings-related 8-Ks
earnings_dates = []
for i in range(n):
    if recent['form'][i] == '8-K':
        filing_date = recent['filingDate'][i]
        month = int(filing_date.split('-')[1])
        if month in [2, 3, 5, 8, 11, 12]:
            earnings_dates.append({
                'accession': recent['accessionNumber'][i],
                'date': filing_date,
                'report_date': recent['reportDate'][i],
                'primary_doc': recent['primaryDocument'][i],
            })

# For each earnings 8-K, try to find and download the press release exhibit
os.makedirs('/workspace/raw/transcripts', exist_ok=True)
sources = []

for ek in earnings_dates[:6]:
    accession = ek['accession'].replace('-', '')
    
    # Try to get the index file
    index_url = f"{BASE_URL}/{CIK}/{accession}/index.json"
    try:
        resp = requests.get(index_url, headers=headers, timeout=30)
        if resp.status_code != 200:
            print(f"  {ek['date']}: index not found")
            continue
        
        index_data = resp.json()
        files = index_data.get('information', [{}])[0].get('forms', [{}])[0].get('files', [])
        
        print(f"\n{ek['date']}: Found {len(files)} files")
        for item in files:
            name = item.get('name', '')
            print(f"  {name}")
            
            # Try to download press release exhibits
            if '99' in name or 'press' in name.lower() or 'ex99' in name.lower():
                file_url = f"{BASE_URL}/{CIK}/{accession}/{name}"
                resp2 = requests.get(file_url, headers=headers, timeout=60)
                if resp2.status_code == 200:
                    sha = hashlib.sha256(resp2.content).hexdigest()
                    filepath = f"/workspace/raw/transcripts/{name}"
                    with open(filepath, 'wb') as f:
                        f.write(resp2.content)
                    print(f"    Downloaded: {filepath} ({len(resp2.content)} bytes)")
                    sources.append({
                        'url': file_url,
                        'sha': sha,
                        'filename': name,
                        'date': ek['date']
                    })
    except Exception as e:
        print(f"  {ek['date']}: Error - {e}")

print(f"\nTotal downloaded: {len(sources)}")

# Save sources
if sources:
    with open('/workspace/sources.md', 'a') as f:
        f.write("\n## Earnings Press Release Exhibits\n\n")
        for s in sources:
            f.write(f"- **{s['filename']}**\n")
            f.write(f"  - URL: {s['url']}\n")
            f.write(f"  - SHA-256: {s['sha']}\n")
            f.write(f"  - Date: {s['date']}\n\n")
