import yfinance as yf
import pandas as pd

# List of interesting small-cap candidates to screen
# Looking for companies with market cap $1B-$10B
candidates = [
    # Cybersecurity
    "CRWD", "ZS", "NET", "PANW", "S", "QRVO",
    # Healthcare/Biotech
    "VEEV", "HIMS", "DOCN", "CLOV",
    # Software/SaaS
    "BILL", "DOCN", "ASAN", "AI", "CFLT", "GTLB", "MNDY", "ESTC",
    # Industrial/Tech
    "HIMS", "CELH", "PLTR", "SOFI", "UPST", "AFRM",
    # Other interesting names
    "RKLB", "ASTS", "LUNR", "RKLB", "RKLB",
    # More small caps
    "CASY", "CVNA", "OPEN", "RBLX", "SNOW", "DDOG", "MDB",
    # Additional
    "SMCI", "ARM", "CELH", "HIMS", "PLTR", "SOFI",
    # More specific small caps
    "AEHR", "ARQT", "BPMC", "CDNA", "CRSP", "EDIT", "NTLA",
    # Interesting software
    "BILL", "DOCN", "ASAN", "AI", "CFLT", "GTLB", "MNDY",
    # More
    "PCTY", "S", "TENB", "CYBR", "RPD", "S", "ZS",
    # Small cap software
    "APPF", "CASY", "CVNA", "DOCU", "ESTC", "GTLB", "HUBS",
    # More
    "JAMF", "MNDY", "NCNO", "OKTA", "PCTY", "RNG", "S",
    # Interesting names
    "BILL", "CFLT", "DOCN", "ESTC", "GTLB", "MNDY", "NCNO",
    # More
    "PCTY", "RPD", "S", "TENB", "ZS", "AI", "ASAN", "BILL",
    # Small caps
    "CASY", "CVNA", "OPEN", "RBLX", "SNOW", "DDOG", "MDB",
    # More
    "SMCI", "ARM", "CELH", "HIMS", "PLTR", "SOFI",
]

# Deduplicate
candidates = list(set(candidates))

results = []
for ticker in candidates:
    try:
        stock = yf.Ticker(ticker)
        info = stock.info
        mc = info.get('marketCap', 0)
        if mc and 1e9 <= mc <= 10e9:
            results.append({
                'ticker': ticker,
                'name': info.get('shortName', 'N/A'),
                'marketCap': mc / 1e9,
                'sector': info.get('sector', 'N/A'),
                'industry': info.get('industry', 'N/A'),
                'price': info.get('currentPrice', info.get('regularMarketPrice', 'N/A')),
                'pe': info.get('trailingPE', 'N/A'),
                'revenue': info.get('totalRevenue', 'N/A'),
            })
    except Exception as e:
        pass

df = pd.DataFrame(results)
if not df.empty:
    df = df.sort_values('marketCap')
    print(df.to_string(index=False))
    print(f"\nTotal candidates in range: {len(df)}")
else:
    print("No candidates found in $1B-$10B range")
