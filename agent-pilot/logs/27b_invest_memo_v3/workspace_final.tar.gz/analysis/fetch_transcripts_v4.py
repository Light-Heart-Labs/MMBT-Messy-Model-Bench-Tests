"""
Fetch earnings call transcripts for SentinelOne - try more sources
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}

# Try to get transcripts from various sources
transcript_urls = [
    # Try to find transcripts on accessible sites
    "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0001583708&type=8-K&dateb=&owner=include&count=40&search_text=&x=0&y=0",
]

# Let's try to get 8-K filings that contain earnings results
print("Fetching 8-K filings with earnings results...")
resp = requests.get(transcript_urls[0], headers=headers, timeout=30)
print(f"Status: {resp.status_code}")

if resp.status_code == 200:
    soup = BeautifulSoup(resp.text, 'lxml')
    # Find all links
    for link in soup.find_all('a', href=True):
        text = link.get('text', '').strip()
        href = link.get('href', '')
        if '8-K' in text or 'earnings' in text.lower() or 'results' in text.lower():
            print(f"  {text[:80]} -> {href[:100]}")

# Try to get transcripts from the SEC directly (8-K filings often contain earnings highlights)
print("\n\nTrying to get earnings-related 8-K filings...")
# We already have 8-K filings, let's check their content
for fpath in [
    '/workspace/raw/filings/8-K/s-20260319.htm',
    '/workspace/raw/filings/8-K/s-20260312.htm',
    '/workspace/raw/filings/8-K/s-20260228.htm',
    '/workspace/raw/filings/8-K/s-20260108.htm',
    '/workspace/raw/filings/8-K/s-20251204.htm',
]:
    with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    soup = BeautifulSoup(content, 'lxml')
    text = soup.get_text()
    # Check if it's earnings-related
    if 'earnings' in text.lower() or 'revenue' in text.lower() or 'results' in text.lower():
        print(f"\n{fpath}:")
        # Print first 500 chars
        print(f"  {text[:500]}")

