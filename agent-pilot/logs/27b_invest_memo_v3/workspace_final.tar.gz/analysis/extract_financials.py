"""
Extract financial data from SentinelOne 10-K filings
"""
import requests
import json
import os
import re
from bs4 import BeautifulSoup
from datetime import datetime

def extract_from_10k(filepath):
    """Extract key financial metrics from a 10-K HTML filing"""
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    
    soup = BeautifulSoup(content, 'lxml')
    
    # Get all text
    text = soup.get_text()
    
    # Look for revenue/total revenue
    revenue_patterns = [
        r'Total\s+revenue.*?(\$[\d,]+\.?\d*)',
        r'Total\s+revenues.*?(\$[\d,]+\.?\d*)',
        r'revenue.*?(\$[\d,]+\.?\d*)',
    ]
    
    # Look for income statement items
    results = {
        'filepath': filepath,
        'extracted_at': datetime.now().isoformat(),
    }
    
    # Try to find tables
    tables = soup.find_all('table')
    print(f"Found {len(tables)} tables in {filepath}")
    
    # Print first few table headers
    for i, table in enumerate(tables[:5]):
        rows = table.find_all('tr')
        if rows:
            headers = [th.get_text().strip() for th in rows[0].find_all(['th', 'td'])]
            print(f"  Table {i}: {headers[:5]}")
    
    # Extract all table data
    all_table_data = []
    for i, table in enumerate(tables):
        rows = table.find_all('tr')
        table_data = []
        for row in rows:
            cells = [td.get_text().strip() for td in row.find_all(['th', 'td'])]
            if any(cells):
                table_data.append(cells)
        if table_data:
            all_table_data.append(table_data)
    
    return {
        'filepath': filepath,
        'num_tables': len(tables),
        'num_rows_total': sum(len(td) for td in all_table_data),
        'sample_tables': all_table_data[:10],
    }

# Process each 10-K
filings = [
    '/workspace/raw/filings/10-K/s-20260131.htm',  # FY2026
    '/workspace/raw/filings/10-K/s-20250131.htm',  # FY2025
    '/workspace/raw/filings/10-K/s-20240131.htm',  # FY2024
]

for filepath in filings:
    print(f"\n{'='*60}")
    print(f"Processing: {filepath}")
    print('='*60)
    result = extract_from_10k(filepath)
    print(f"Tables: {result['num_tables']}, Total rows: {result['num_rows_total']}")
    
    # Print sample table data
    for i, table in enumerate(result['sample_tables'][:3]):
        print(f"\n--- Table {i} (first 5 rows) ---")
        for row in table[:5]:
            print(f"  {row}")

