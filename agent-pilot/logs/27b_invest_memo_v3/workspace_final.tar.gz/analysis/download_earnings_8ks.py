"""
Download earnings-related 8-K filings and extract press release content
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

CIK = "0001583708"
BASE_URL = "https://www.sec.gov/Archives/edgar/data"

headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}

# Get all filings
url = f"https://data.sec.gov/submissions/CIK{CIK}.json"
resp = requests.get(url, headers=headers, timeout=30)
data = resp.json()
recent = data.get('filings', {}).get('recent', {})
n = len(recent.get('accessionNumber', []))

# Find earnings-related 8-Ks
earnings_dates = []
for i in range(n):
    if recent['form'][i] == '8-K':
        filing_date = recent['filingDate'][i]
        month = int(filing_date.split('-')[1])
        if month in [2, 3, 5, 8, 11, 12]:
            earnings_dates.append({
                'accession': recent['accessionNumber'][i],
                'date': filing_date,
                'report_date': recent['reportDate'][i],
                'primary_doc': recent['primaryDocument'][i],
            })

print(f"Found {len(earnings_dates)} earnings-related 8-Ks")

# Download each one and extract the press release
os.makedirs('/workspace/raw/transcripts', exist_ok=True)
sources = []

for ek in earnings_dates[:6]:
    accession = ek['accession'].replace('-', '')
    filename = ek['primary_doc']
    url = f"{BASE_URL}/{CIK}/{accession}/{filename}"
    
    print(f"\nDownloading: {ek['date']} - {filename}")
    resp = requests.get(url, headers=headers, timeout=60)
    if resp.status_code != 200:
        print(f"  Failed: {resp.status_code}")
        continue
    
    sha = hashlib.sha256(resp.content).hexdigest()
    filepath = f"/workspace/raw/transcripts/8k_{ek['date'].replace('-', '')}.htm"
    with open(filepath, 'wb') as f:
        f.write(resp.content)
    
    # Parse and extract press release text
    soup = BeautifulSoup(resp.content, 'lxml')
    text = soup.get_text(separator='\n', strip=True)
    
    # Find the press release section (usually after Item 2.02)
    lines = text.split('\n')
    press_release = []
    in_press_release = False
    for line in lines:
        if 'Item 2.02' in line or 'Results of Operations' in line:
            in_press_release = True
        if in_press_release:
            press_release.append(line)
        if 'Item 7.01' in line or 'Item 9.01' in line:
            in_press_release = False
    
    pr_text = '\n'.join(press_release[:100])
    print(f"  Press release excerpt:")
    for line in pr_text.split('\n')[:10]:
        print(f"    {line[:120]}")
    
    sources.append({
        'url': url,
        'sha': sha,
        'filename': f"8k_{ek['date'].replace('-', '')}.htm",
        'date': ek['date']
    })

# Save sources
with open('/workspace/sources.md', 'a') as f:
    f.write("\n## Earnings 8-K Filings\n\n")
    for s in sources:
        f.write(f"- **{s['filename']}**\n")
        f.write(f"  - URL: {s['url']}\n")
        f.write(f"  - SHA-256: {s['sha']}\n")
        f.write(f"  - Date: {s['date']}\n\n")

print(f"\nDownloaded {len(sources)} earnings 8-Ks")
