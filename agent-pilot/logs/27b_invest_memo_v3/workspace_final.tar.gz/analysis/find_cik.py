import requests
import json

# Search for SentinelOne on SEC
url = "https://www.sec.gov/cgi-bin/browse-edgar"
params = {
    'company': 'SentinelOne',
    'action': 'search',
    'owner': 'include',
    'count': '5'
}
headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}

# Try the company lookup API
url2 = "https://www.sec.gov/Archives/edgar/full-index/company/"
# Let's try a different approach - use the search API
url3 = "https://efts.sec.gov/LATEST/search?searchText=SentinelOne"

# Actually, let's use the company info endpoint
url4 = "https://data.sec.gov/submissions/CIK0001819772.json"
resp = requests.get(url4, headers=headers, timeout=30)
data = resp.json()
print("CIK 0001819772 info:")
print(f"  Name: {data.get('name')}")
print(f"  Tickers: {data.get('tickers')}")
print(f"  Filings recent keys: {list(data.get('filings', {}).get('recent', {}).keys())}")

# Check if recent is empty
recent = data.get('filings', {}).get('recent', {})
if recent:
    print(f"  Number of accession numbers: {len(recent.get('accessionNumber', []))}")
    if recent.get('accessionNumber'):
        print(f"  First accession: {recent['accessionNumber'][0]}")
        print(f"  First form: {recent.get('form', [''])[0] if recent.get('form') else 'N/A'}")
