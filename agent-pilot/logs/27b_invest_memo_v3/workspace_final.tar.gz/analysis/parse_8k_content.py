"""
Parse 8-K filings to find the actual content items
"""
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

for fpath in [
    '/workspace/raw/filings/8-K/s-20260319.htm',
    '/workspace/raw/filings/8-K/s-20260312.htm',
    '/workspace/raw/filings/8-K/s-20260228.htm',
    '/workspace/raw/filings/8-K/s-20260108.htm',
    '/workspace/raw/filings/8-K/s-20251204.htm',
]:
    with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    soup = BeautifulSoup(content, 'lxml')
    text = soup.get_text(separator='\n', strip=True)
    
    lines = text.split('\n')
    print(f"\n{'='*60}")
    print(f"FILE: {fpath.split('/')[-1]}")
    print('='*60)
    
    # Find "Item" sections
    in_item = False
    item_text = []
    for line in lines:
        if line.startswith('Item') or 'ITEM' in line:
            if item_text:
                print(f"\n  {item_text[0]}")
                for t in item_text[1:5]:
                    print(f"  {t[:120]}")
            in_item = True
            item_text = [line]
        elif in_item:
            item_text.append(line)
            if len(item_text) > 20:
                break

