"""
Get earnings press releases from 8-K exhibits
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

CIK = "0001583708"
BASE_URL = "https://www.sec.gov/Archives/edgar/data"

# Load filing list
with open('/workspace/raw/filings/filing_list.json') as f:
    filing_data = json.load(f)

headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}

# Get all 8-K filings
url = f"https://data.sec.gov/submissions/CIK{CIK}.json"
resp = requests.get(url, headers=headers, timeout=30)
data = resp.json()
recent = data.get('filings', {}).get('recent', {})
n = len(recent.get('accessionNumber', []))

# Find earnings-related 8-Ks
earnings_8ks = []
for i in range(n):
    if recent['form'][i] == '8-K':
        accession = recent['accessionNumber'][i].replace('-', '')
        # Check if it's earnings-related by looking at the filing date
        # Earnings are typically reported in Feb (Q3), May (Q4/FY), Aug (Q1), Nov (Q2)
        filing_date = recent['filingDate'][i]
        month = int(filing_date.split('-')[1])
        if month in [2, 3, 5, 8, 11, 12]:  # Months when earnings are typically reported
            earnings_8ks.append({
                'accession': accession,
                'date': filing_date,
                'report_date': recent['reportDate'][i],
                'primary_doc': recent['primaryDocument'][i],
            })

print(f"Found {len(earnings_8ks)} potential earnings 8-Ks:")
for ek in earnings_8ks[:10]:
    print(f"  {ek['date']}: {ek['primary_doc']}")

# Now try to download the press release exhibits from these 8-Ks
# The press release is usually exhibit 99.1
print("\n\nDownloading press release exhibits...")
os.makedirs('/workspace/raw/transcripts', exist_ok=True)

sources = []
for ek in earnings_8ks[:6]:
    accession = ek['accession']
    # Try to find the press release exhibit
    # Usually it's named something like s-20260312x991pressrelease.htm
    possible_names = [
        f"s-20260312x991pressrelease.htm",
        f"s-20260312x991.htm",
        f"ex991.htm",
        f"ex-99.1.htm",
    ]
    
    # Try to get the index file first
    index_url = f"{BASE_URL}/{CIK}/{accession}/index.json"
    try:
        resp = requests.get(index_url, headers=headers, timeout=30)
        if resp.status_code == 200:
            index_data = resp.json()
            # List all files
            for item in index_data.get('information', [{}])[0].get('forms', [{}])[0].get('files', []):
                if '99' in item.get('name', '') or 'press' in item.get('name', '').lower():
                    filename = item['name']
                    file_url = f"{BASE_URL}/{CIK}/{accession}/{filename}"
                    print(f"  Found exhibit: {filename}")
                    
                    # Download it
                    resp2 = requests.get(file_url, headers=headers, timeout=60)
                    if resp2.status_code == 200:
                        sha = hashlib.sha256(resp2.content).hexdigest()
                        filepath = f"/workspace/raw/transcripts/{filename}"
                        with open(filepath, 'wb') as f:
                            f.write(resp2.content)
                        print(f"    Downloaded: {filepath} ({len(resp2.content)} bytes)")
                        sources.append({
                            'url': file_url,
                            'sha': sha,
                            'filename': filename,
                            'date': ek['date']
                        })
    except Exception as e:
        print(f"  Error for {ek['date']}: {e}")

# Save sources
if sources:
    with open('/workspace/sources.md', 'a') as f:
        f.write("\n## Earnings Press Releases\n\n")
        for s in sources:
            f.write(f"- **{s['filename']}**\n")
            f.write(f"  - URL: {s['url']}\n")
            f.write(f"  - SHA-256: {s['sha']}\n")
            f.write(f"  - Date: {s['date']}\n\n")

print(f"\nDownloaded {len(sources)} press releases")
