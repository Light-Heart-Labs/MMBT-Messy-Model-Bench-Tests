"""
Fetch earnings call transcripts for SentinelOne
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup

headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}

# Try multiple sources for earnings transcripts
sources = [
    # Seeking Alpha
    "https://seekingalpha.com/symbol/S/earnings",
    # Yahoo Finance
    "https://finance.yahoo.com/quote/S/earnings/",
    # The Motley Fool
    "https://www.fool.com/earnings/call-transcripts/S/",
]

# First, let's try to get transcript URLs from Seeking Alpha
print("Searching for SentinelOne earnings transcripts...")

# Try Seeking Alpha
try:
    resp = requests.get("https://seekingalpha.com/symbol/S/earnings", headers=headers, timeout=30)
    print(f"Seeking Alpha status: {resp.status_code}")
    if resp.status_code == 200:
        soup = BeautifulSoup(resp.text, 'lxml')
        # Look for transcript links
        links = soup.find_all('a', href=True)
        transcript_links = [l for l in links if 'transcript' in l.get('href', '').lower()]
        print(f"Found {len(transcript_links)} transcript links on Seeking Alpha")
        for link in transcript_links[:5]:
            print(f"  {link.get('href')}")
except Exception as e:
    print(f"Seeking Alpha error: {e}")

# Try Yahoo Finance
try:
    resp = requests.get("https://finance.yahoo.com/quote/S/earnings/", headers=headers, timeout=30)
    print(f"\nYahoo Finance status: {resp.status_code}")
    if resp.status_code == 200:
        soup = BeautifulSoup(resp.text, 'lxml')
        # Look for earnings dates
        print(f"Page length: {len(resp.text)}")
        # Print relevant sections
        text = soup.get_text()
        # Find earnings-related text
        for line in text.split('\n'):
            if 'earn' in line.lower() or 'transcript' in line.lower() or '2024' in line or '2025' in line:
                if len(line.strip()) > 10:
                    print(f"  {line.strip()[:100]}")
except Exception as e:
    print(f"Yahoo Finance error: {e}")

# Try earnings data from yfinance
import yfinance as yf
stock = yf.Ticker('S')
cal = stock.calendar
print(f"\nEarnings calendar: {cal}")

# Get earnings history
earnings = stock.earnings_history
print(f"\nEarnings history:\n{earnings}")

