"""
Try to get earnings call transcripts from web sources
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

# Try to get transcripts from various sources
sources_to_try = [
    # Try to get from the SEC's full-text search
    "https://efts.sec.gov/LATEST/search?searchText=SentinelOne+earnings+call",
    # Try to get from a transcript site
    "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0001583708&type=8-K&dateb=&owner=include&count=5&search_text=earnings&x=0&y=0",
]

for url in sources_to_try:
    try:
        resp = requests.get(url, headers=headers, timeout=30)
        print(f"{url[:80]}: {resp.status_code}")
        if resp.status_code == 200:
            print(f"  Content length: {len(resp.text)}")
    except Exception as e:
        print(f"{url[:80]}: Error - {e}")

# Let's try to get the actual press release text from the 8-K filings
# The 8-K usually references a press release that was filed as an exhibit
print("\n\nExtracting press release content from 8-K filings...")

for fpath in [
    '/workspace/raw/transcripts/8k_20260312.htm',  # Q4/FY2026
    '/workspace/raw/transcripts/8k_20251204.htm',  # Q3 FY2026
    '/workspace/raw/transcripts/8k_20250828.htm',  # Q2 FY2026
    '/workspace/raw/transcripts/8k_20250528.htm',  # Q1 FY2026
]:
    if not os.path.exists(fpath):
        print(f"  {fpath} not found, skipping")
        continue
    
    with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    
    soup = BeautifulSoup(content, 'lxml')
    text = soup.get_text(separator='\n', strip=True)
    
    # Find the press release section
    lines = text.split('\n')
    pr_lines = []
    in_pr = False
    for line in lines:
        if 'Item 2.02' in line:
            in_pr = True
        if in_pr:
            pr_lines.append(line)
        if 'Item 7.01' in line or 'Item 5.02' in line or 'Item 9.01' in line:
            break
    
    pr_text = '\n'.join(pr_lines)
    print(f"\n{fpath.split('/')[-1]}:")
    for line in pr_text.split('\n')[:15]:
        if line.strip():
            print(f"  {line[:150]}")

