import requests
import json

CIK = "0001819772"
url = f"https://data.sec.gov/submissions/CIK{CIK}.json"
headers = {"User-Agent": "InvestmentAnalyst (analyst@investmentmemo.com)"}
resp = requests.get(url, headers=headers, timeout=30)
data = resp.json()

# Print structure
print("Top-level keys:", list(data.keys()))
print("\nFilings keys:", list(data.get('filings', {}).keys()))
print("\nFirst few items in 'recent':")
recent = data.get('filings', {}).get('recent', [])
print(f"Type of recent: {type(recent)}")
print(f"Length: {len(recent)}")
if isinstance(recent, list) and len(recent) > 0:
    print(f"First item type: {type(recent[0])}")
    print(f"First item: {json.dumps(recent[0], indent=2)[:500]}")
