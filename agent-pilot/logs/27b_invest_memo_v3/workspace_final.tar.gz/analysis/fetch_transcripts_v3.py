"""
Fetch earnings call transcripts for SentinelOne from multiple sources
"""
import requests
import json
import os
import hashlib
from datetime import datetime
from bs4 import BeautifulSoup

headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}

# Try multiple transcript sources
sources = [
    ("Nasdaq", "https://www.nasdaq.com/markets/earnings/transcripts/S"),
    ("Yahoo Finance", "https://finance.yahoo.com/quote/S/earnings/"),
    ("Motley Fool", "https://www.fool.com/earnings/call-transcripts/S/"),
    ("Earnings Network", "https://www.earnings.net/transcripts/S"),
]

for name, url in sources:
    print(f"\nTrying {name}...")
    try:
        resp = requests.get(url, headers=headers, timeout=30)
        print(f"  Status: {resp.status_code}")
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.text, 'lxml')
            text = soup.get_text()
            # Look for transcript-related content
            lines = [l.strip() for l in text.split('\n') if l.strip() and len(l.strip()) > 10]
            for line in lines[:30]:
                if any(kw in line.lower() for kw in ['transcript', 'earnings', 'q1', 'q2', 'q3', 'q4', '2024', '2025', '2026']):
                    print(f"  {line[:120]}")
    except Exception as e:
        print(f"  Error: {e}")

# Try to get earnings data from yfinance
import yfinance as yf
stock = yf.Ticker('S')

# Get earnings dates
print("\n\nEarnings info from yfinance:")
info = stock.info
for key in ['earningsDate', 'financialCurrency', 'currentPrice', 'targetMeanPrice', 'targetHighPrice', 'targetLowPrice']:
    if key in info:
        print(f"  {key}: {info[key]}")

# Get analyst recommendations
recs = stock.recommendations_summary
print(f"\nRecommendations:\n{recs}")

# Get institutional holders
holders = stock.institutional_holders
print(f"\nInstitutional holders:\n{holders}")

