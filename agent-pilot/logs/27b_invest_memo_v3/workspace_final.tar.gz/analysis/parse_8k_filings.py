"""
Parse 8-K filings to find earnings-related ones
"""
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

for fpath in [
    '/workspace/raw/filings/8-K/s-20260319.htm',
    '/workspace/raw/filings/8-K/s-20260312.htm',
    '/workspace/raw/filings/8-K/s-20260228.htm',
    '/workspace/raw/filings/8-K/s-20260108.htm',
    '/workspace/raw/filings/8-K/s-20251204.htm',
]:
    with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()
    soup = BeautifulSoup(content, 'lxml')
    text = soup.get_text(separator='\n', strip=True)
    
    # Find the item description
    lines = text.split('\n')
    print(f"\n{'='*60}")
    print(f"FILE: {fpath.split('/')[-1]}")
    print('='*60)
    
    # Print first 30 non-empty lines
    count = 0
    for line in lines:
        if line.strip():
            print(f"  {line[:120]}")
            count += 1
            if count >= 30:
                break

