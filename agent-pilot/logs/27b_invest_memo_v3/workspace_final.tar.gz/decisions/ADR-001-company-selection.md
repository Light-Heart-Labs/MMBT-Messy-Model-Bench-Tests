# ADR-001: Company Selection

## Decision
Selected **SentinelOne, Inc. (NYSE: S)** for investment analysis.

## Context
Need a publicly traded US company with market cap between $1B and $10B that offers:
- Sufficient public data (SEC filings, earnings calls)
- Clear competitive dynamics
- Interesting investment thesis potential

## Alternatives Considered
1. **BILL Holdings (BILL)** - $3.7B, financial software for SMBs. Good but less differentiated competitive landscape.
2. **GitLab Inc. (GTLB)** - $3.7B, DevOps platform. Interesting but complex business model with mixed profitability.
3. **Elastic N.V. (ESTC)** - $4.8B, search/analytics. Strong but less clear competitive moat.
4. **nCino (NCNO)** - $2.0B, banking software. Niche market, limited data on competitive dynamics.
5. **SentinelOne (S)** - $4.8B, AI-driven cybersecurity endpoint protection.

## Rationale for SentinelOne
1. **Clear competitive landscape**: Direct competition with CrowdStrike (CRWD), Palo Alto Networks (PANW), Microsoft Defender — well-defined rivals
2. **Growing TAM**: Cybersecurity spending is structurally increasing due to rising threats
3. **AI narrative**: SentinelOne's AI-native approach is a key differentiator
4. **Profitability inflection**: Company recently achieved profitability, creating an interesting inflection point
5. **Data availability**: Regular SEC filings, quarterly earnings calls, clear financials
6. **Market cap**: ~$4.8B, squarely in the $1B-$10B range

## Risks of This Choice
- Cybersecurity is a crowded market
- Competition from Microsoft (free/bundled Defender) is a structural threat
- Recent CrowdStrike outage may have created temporary tailwinds

## Next Steps
- Download all SEC filings (10-K, 10-Q, 8-K)
- Download earnings call transcripts
- Build financial model
- Conduct competitive analysis
