# ADR-001: Recommendation Stance — HOLD

**Status:** Accepted
**Date:** 2026-04-16
**Decision Maker:** Executive Committee Reviewer

## Context

The Corp Dev team recommends PROCEED to LOI at $84M for Borealis Analytics. The diligence pack presents a positive case with strong growth metrics, good retention, and a clean engineering review. However, the pack is an advocacy document with material gaps in analysis.

## Decision

Recommend **HOLD** — do not issue LOI until critical diligence gaps are closed within the next two weeks.

## Rationale

- The deal has genuine strategic and financial merit (growth trajectory, net retention, engineering quality).
- However, five material concerns (valuation anchor, customer concentration, integration assumptions, synergy derivation, runway calculation) are insufficiently addressed.
- A PASS recommendation would be premature given the deal's underlying strengths.
- A PROCEED recommendation would be irresponsible given the gaps.
- HOLD allows the committee to keep the deal alive while closing the most critical information gaps.

## Consequences

- If diligence asks are satisfactorily addressed by 2026-04-30, recommendation reverses to PROCEED.
- If any material concern proves true (e.g., extreme customer concentration, hidden earnouts in comps, runway <3 months), recommendation shifts to PASS.
- Two-week delay carries opportunity cost if another buyer is in the market.

---

# ADR-002: Concern Severity Classification

**Status:** Accepted
**Date:** 2026-04-16
**Decision Maker:** Executive Committee Reviewer

## Context

The review identified 15 distinct concerns. Not all concerns are equal in their potential to change the recommendation.

## Decision

Classify concerns into two tiers:
- **Material (★):** 5 concerns that could individually change the recommendation from PROCEED to PASS.
- **Notable:** 10 concerns that are important but less likely to change the recommendation on their own.

## Rationale

- Material concerns are those where the pack either omits critical data (customer concentration), asserts without derivation (synergies), or uses misleading framing (runway).
- Notable concerns are important for a complete picture but are either partially addressed in the pack or are secondary risks.
- This classification guides the diligence ask prioritization — material concerns get earlier deadlines.

## Consequences

- Diligence asks are sequenced by concern severity.
- Material concerns are the primary gating criteria for the HOLD→PROCEED reversal.

---

# ADR-003: Diligence Ask Scope

**Status:** Accepted
**Date:** 2026-04-16
**Decision Maker:** Executive Committee Reviewer

## Context

Many diligence questions could be asked. The committee has a two-week window before the decision deadline.

## Decision

Limit diligence asks to 10 specific items, prioritized by the material concerns they address.

## Rationale

- The 10 asks directly address the 5 material concerns and the most impactful notable concerns.
- Additional asks (e.g., full cultural assessment, deep engineering audit) would extend beyond the two-week window.
- The asks are designed to be answerable within the timeframe with existing resources.
- If the committee wants deeper analysis on any item, it can be scoped as a follow-on ask.

## Consequences

- Some concerns (e.g., cultural fit, full security audit) are not fully addressed in the initial ask list.
- These can be addressed in a second diligence round if the deal proceeds past LOI.
