# Borealis Analytics — Acquisition Diligence Review

## How to Read This Output

This repository contains an independent executive committee review of the Corp Dev diligence pack for the proposed acquisition of Borealis Analytics (Project Lighthouse).

### Files

| File | Purpose |
|------|---------|
| [`memo.md`](memo.md) | **Primary deliverable.** 1-page review memo with recommendation, key concerns, and diligence asks. Read this first. |
| [`concerns.md`](concerns.md) | Full enumeration of all 15 concerns identified, ranked by severity. Supports the memo. |
| [`asks.md`](asks.md) | Detailed diligence-ask list with owners, deadlines, and deliverables for the next 2 weeks. |
| [`decisions/`](decisions/) | Architecture Decision Records (ADRs) documenting judgment calls made during the review. |

### Reading Order

1. **`memo.md`** — Start here for the executive summary and recommendation.
2. **`concerns.md`** — For the full list of concerns, including lower-severity items not in the memo.
3. **`asks.md`** — For the specific diligence questions to be answered in the next 2 weeks.
4. **`decisions/`** — For context on how the recommendation and scope were determined.

### Source Material

The sole source for this review is the Corp Dev diligence pack at `/input/repo/deal_pack.md`. No external data, customer names, or financial figures were introduced.

### Recommendation Summary

**HOLD** — Do not issue LOI until critical diligence gaps are closed. The deal has merit but the pack is advocacy-heavy and analysis-light. See `memo.md` for details.
