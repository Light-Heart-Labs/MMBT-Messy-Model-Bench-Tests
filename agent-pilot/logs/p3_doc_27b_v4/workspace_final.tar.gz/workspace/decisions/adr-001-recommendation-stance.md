# ADR-001: Recommendation Stance — PASS vs. MORE DILIGENCE

**Status:** Accepted
**Date:** 2026-03-10

## Context

The brief requires a clear stance: invest, pass, or more diligence needed. The evidence presents both positive signals (strong technology, credible founders, top-tier investors) and negative signals (churn, valuation repricing, cash burn, restructuring).

## Decision

**PASS** — not "more diligence needed."

## Rationale

1. **The company's own timeline supports waiting.** The leaked memo states the company targets Q4 2026 breakeven as the trigger for Series C. A follow-on before that would be premature by the company's own plan.
2. **The negative signals are structural, not informational.** The churn, concentration, and burn rate are not unknowns that diligence would resolve — they are known problems that time would resolve (or not). More diligence wouldn't change the recommendation.
3. **A "more diligence needed" stance is a cop-out when the evidence is clear.** The gap between public narrative and internal reality is wide enough to justify a clear PASS.

## Consequences

- The brief takes a definitive stance, which is what the task requires.
- The "What Would Change Our View" section provides the conditions under which the recommendation would flip, giving the reader a clear framework for future evaluation.

---

# ADR-002: Treatment of the Leaked Memo

**Status:** Accepted
**Date:** 2026-03-10

## Context

Source 4 is a leaked internal memo obtained by The Information. It contains specific, actionable information about restructuring plans. The question is how much weight to give it.

## Decision

Treat the memo as **highly credible but not independently verified**. Use its specific claims (Berlin headcount reduction, Nimbus Lite sunset, credit facility) as facts attributed to the memo, but frame them as "according to the memo" rather than ground truth.

## Rationale

1. **Specificity suggests authenticity.** The memo contains precise numbers (41 → 28-30 headcount, ~310 Nimbus Lite customers, $50M credit facility) that are hard to fabricate.
2. **Alignment with other sources.** The memo's claims about restructuring align with the former employee's account of layoffs and the TechCrunch report of churn, suggesting a consistent picture.
3. **It's management's own assessment.** The memo is attributed to CEO Mira Patel, making it a primary source for management's view of the company's challenges.

## Consequences

- The brief cites the memo for specific restructuring details but doesn't treat it as the sole basis for the recommendation.
- The source quality section explicitly notes the memo's status as "likely authentic given specificity and alignment with other sources."

---

# ADR-003: Structure — Red Flags vs. Balanced Pros/Cons

**Status:** Accepted
**Date:** 2026-03-10

## Context

The brief could be structured as a balanced pros/cons list or as a narrative leading to a recommendation.

## Decision

Use a **"The Good" section followed by "Five Red Flags"** structure, with the recommendation stated upfront.

## Rationale

1. **The task asks for tensions, not just facts.** A balanced pros/cons list would be too even-handed. The evidence clearly tilts toward caution.
2. **Leading with the recommendation** respects the reader's time — they know the stance before reading the details.
3. **The "Five Red Flags" structure** makes the negative signals explicit and countable, which is more persuasive than burying them in a balanced narrative.

## Consequences

- The brief is clearly structured for a busy reader who may only read the recommendation and the red flags.
- The "The Good" section is brief but fair, acknowledging the company's strengths without over-weighting them.
