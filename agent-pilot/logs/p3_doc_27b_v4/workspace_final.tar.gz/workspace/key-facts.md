# Key Facts Incorporated into the Brief

Each fact below traces to one or more of the five source documents.

## Deal Structure and Valuation
| Fact | Source(s) |
|------|-----------|
| $84M Series B led by Lightning Capital | [Source 1], [Source 5] |
| Post-money valuation: $560M | [Source 1] |
| Previous Series A valuation: $230M (2023) | [Source 1] |
| Total funding across all rounds: $128M | [Source 1] |
| 7 total investors in Series B | [Source 5] |
| Named investors: Lightning Capital, Sequoia, Accel, FedEx Ventures | [Source 1], [Source 5] |
| Three additional undisclosed investors | [Source 5] |
| Securities: Series B Preferred Equity | [Source 5] |
| Series B was intended to close at $720M valuation but was repriced down to $560M | [Source 2] |
| Repricing occurred after Sundry non-renewal became known in early December | [Source 2] |

## Revenue and Customer Metrics
| Fact | Source(s) |
|------|-----------|
| Company-reported ARR: $42M as of Q4 2025 | [Source 1] |
| ARR a year prior: $11M | [Source 1] |
| Adjusted run-rate ARR after churn: $36–37M | [Source 2] |
| Sundry Brands (largest customer, $4.2M ARR) did not renew in November 2025 | [Source 2] |
| Klatch (fast-fashion brand) exited in December 2025 | [Source 2] |
| Both Sundry and Klatch were top-five customers | [Source 2] |
| Top 5 customers accounted for ~38% of ARR | [Source 3] |
| Company serves over 1,400 e-commerce brands | [Source 1] |
| CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 | [Source 2] |
| CEO claims net retention above 110% | [Source 2] |
| Named customers: Maevia, Truant Coffee, Brick & Cobble | [Source 1] |

## Financials and Burn
| Fact | Source(s) |
|------|-----------|
| Monthly burn: ~$4M/month (mid-2025) | [Source 3] |
| Monthly revenue: ~$3.5M/month (mid-2025) | [Source 3] |
| Net burn: ~$500K/month | [Source 3] (calculated from above) |
| $50M credit facility from Silicon Valley Bridge | [Source 4] |
| Credit facility described as "insurance, not operating capital" | [Source 4] |
| Runway: 24+ months at current burn | [Source 4] |
| Runway extended to 36+ months with restructuring actions | [Source 4] |
| Target: operating-cash-flow breakeven by Q4 2026 | [Source 4] |

## Personnel and Organization
| Fact | Source(s) |
|------|-----------|
| 187 employees across Oakland, Austin, Berlin | [Source 1] |
| Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) | [Source 1] |
| 22 layoffs (~11% of org) in February 2025, mostly customer success and BD | [Source 3] |
| Layoffs were not publicly announced | [Source 3] |
| Berlin office headcount: 41, planned reduction to 28–30 by end Q2 2026 | [Source 4] |
| 30% reduction in international headcount | [Source 4] |
| International expansion deferred to 2027 | [Source 4] |
| Berlin reframed as "support hub" | [Source 4] |
| Senior engineer compensation: $215K base + $50K equity/year | [Source 3] |

## Product and Platform
| Fact | Source(s) |
|------|-----------|
| Platform combines warehouse management, carrier orchestration, and demand forecasting | [Source 1] |
| "Nimbus Lite" tier being sunset | [Source 4] |
| ~310 customers on Nimbus Lite, mostly $5K–$20K ARR each | [Source 4] |
| 90-day notice given to Nimbus Lite customers | [Source 4] |
| Use of proceeds: "expansion, working capital, general corporate purposes" | [Source 5] |
