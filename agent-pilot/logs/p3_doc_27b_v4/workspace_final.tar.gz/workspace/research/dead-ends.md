# Dead Ends — Ideas Considered and Abandoned

## 1. Including the CEO's Q1 new-contract claims as a positive signal
**Considered:** The CEO told TechCrunch that three new $1M+ ARR contracts were signed in Q1 2026, and that net retention is above 110%.
**Abandoned because:** These are unverified management claims made in the same interview where the company was trying to counter negative press. Without independent confirmation, they read as spin. The brief mentions them only implicitly by noting the CEO's claims in the source quality section. Including them as a positive would dilute the PASS recommendation.

## 2. Calculating an implied valuation multiple
**Considered:** Computing ARR multiples (e.g., $560M / $42M = ~13x ARR) to compare with industry benchmarks.
**Abandoned because:** No industry benchmark data is available in the source pack. Any comparison would require external research, which is outside scope. The valuation repricing from $720M to $560M is a more useful signal than the absolute multiple.

## 3. Including the former employee's compensation details
**Considered:** The blog post mentions $215K base + $50K equity/year for senior engineers.
**Abandoned because:** While interesting for talent assessment, compensation data is not material to an investment decision. The brief focuses on financial and operational signals.

## 4. Speculating on why Sundry Brands left
**Considered:** Trying to determine whether Sundry's departure was due to product issues, pricing, or strategic reasons.
**Abandoned because:** The sources don't provide a clear reason. The company called it a "strategic mutual decision" [Source 2], but the former employee noted it "was not a shock to the team" [Source 3], suggesting underlying issues. Without more data, speculation would be unfounded.

## 5. Including the FedEx Ventures strategic investment as a strong positive
**Considered:** Highlighting FedEx Ventures' participation as validation of the platform's strategic value.
**Abandoned because:** While it is a positive signal, the brief already notes the strong investor syndicate. Over-weighting this one investor would distract from the more material red flags. The brief mentions it as part of the syndicate but doesn't over-index on it.

## 6. Recommending "more diligence needed" instead of "PASS"
**Considered:** A hedged recommendation acknowledging both strengths and weaknesses.
**Abandoned because:** The task explicitly asks for a clear stance. The evidence tilts decisively toward waiting — the company itself is planning to raise Series C in late 2026 from a position of strength. A "more diligence needed" recommendation would be a cop-out when the company's own timeline suggests waiting is the rational choice.

## 7. Including the 22% valuation repricing as a calculation
**Considered:** Showing the math: ($720M - $560M) / $720M = 22%.
**Abandoned because:** The exact percentage isn't material; the direction and magnitude of the repricing is. The brief states "22% haircut" as a rough characterization rather than a precise calculation, since the $720M figure comes from insider reports, not a filing.

## 8. Discussing the three undisclosed investors
**Considered:** Speculating on who the three additional investors might be.
**Abandoned because:** The SEC Form D doesn't name them, and there's no basis for speculation. The brief notes their existence but doesn't dwell on it.
