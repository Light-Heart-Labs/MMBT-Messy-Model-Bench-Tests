# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Assessment

**Date:** 2026-03-10 | **For:** Investment Committee

---

## Recommendation: PASS — Wait for Restructuring to Play Out

Nimbus Logistics has credible technology and strong investor backing, but the company is executing a significant mid-round restructuring that signals deeper challenges than its public narrative suggests. **We recommend passing on a follow-on investment now** and keeping Nimbus on a watchlist for a potential Series C entry in late 2026.

The company itself targets operating-cash-flow breakeven by Q4 2026 as the trigger for Series C "from a position of strength rather than necessity" [Source 4]. A follow-on now would likely be at unfavorable terms before key risks resolve.

---

## The Good: Real Technology, Strong Backing

Nimbus's platform — warehouse management, carrier orchestration, and demand forecasting — is well-regarded. A former senior engineer called the carrier-orchestration layer "some of the cleanest distributed-systems code" he has worked on, noting genuine customer dependence [Source 3]. The company serves over 1,400 e-commerce brands [Source 1].

The investor syndicate is strong: Lightning Capital led the $84M Series B with Sequoia, Accel, FedEx Ventures (strategic), and three additional undisclosed investors [Source 1][Source 5]. Total funding is $128M [Source 1].

---

## Five Red Flags

### 1. ARR Is Inflated by Churn

The company reports $42M ARR as of Q4 2025 [Source 1], but this includes two major contracts that expired that quarter. Sundry Brands, the largest customer at $4.2M ARR, did not renew in November [Source 2]. Fast-fashion brand Klatch exited in December [Source 2]. Adjusted for churn, the current run-rate is closer to $36–37M [Source 2].

### 2. Valuation Was Repriced Down

Insiders report the Series B was intended to close in late 2025 at a $720M valuation but was repriced to $560M after the Sundry non-renewal became known to the lead investor in early December [Source 2]. A 22% haircut mid-process signals that informed capital saw more risk than the public narrative conveys.

### 3. Customer Concentration Is Material

The top five customers accounted for approximately 38% of ARR, according to a former employee [Source 3]. The loss of Sundry alone removed roughly 10% of reported ARR. This concentration risk is not disclosed publicly and represents a structural vulnerability for a platform claiming 1,400 brands.

### 4. The Company Is Burning Cash and Cutting Staff

As of mid-2025, Nimbus spent approximately $4M/month against roughly $3.5M/month in revenue — a net burn of ~$500K/month [Source 3]. The company quietly laid off 22 employees (~11% of the org) in February 2025, mostly in customer success and BD, without public announcement [Source 3].

A leaked internal memo from CEO Mira Patel (dated February 28, 2026) outlines further cuts: a 30% reduction in international headcount (Berlin from 41 to 28–30), deferral of international expansion to 2027, and elimination of the "Nimbus Lite" tier affecting ~310 small customers [Source 4].

### 5. A $50M Credit Facility Has Been Secured

The memo reveals a new $50M credit facility from Silicon Valley Bridge, described as "insurance, not operating capital" [Source 4]. While this extends runway to 36+ months, the need for debt so soon after an $84M equity raise suggests management recognizes the path to profitability is more challenging than the fundraise implied.

---

## Source Quality

- **Press release [Source 1]:** Company narrative. Accurate on deal terms but omits churn, layoffs, and restructuring.
- **TechCrunch [Source 2]:** Journalistic, citing unnamed sources. Most reliable on churn and valuation repricing; figures not independently audited.
- **Former-employee blog [Source 3]:** One person's account. Useful for burn rate and layoffs but not independently verified.
- **Leaked memo [Source 4]:** Likely authentic given specificity and alignment with other sources. Represents management's own assessment.
- **SEC Form D [Source 5]:** Regulatory filing. Most authoritative on deal structure; confirms 7 investors and $84M total.

---

## What Would Change Our View

We would reconsider if we saw: (1) demonstrated quarter-over-quarter improvement in unit economics; (2) top-five customer share dropping below 25% of ARR; (3) successful restructuring execution — Berlin stabilization, Nimbus Lite migration without disproportionate churn, and net-new ARR growth exceeding $1M/month; (4) a Series C at a reasonable valuation, which is the company's own planned entry point in late 2026.

---

## Bottom Line

Nimbus has a real product and credible founders, but the company is in a difficult mid-round correction. The gap between the public narrative ($42M ARR, $560M valuation, international expansion) and the internal reality ($36–37M adjusted ARR, repriced valuation, staff cuts, deferred expansion) is too wide to justify a follow-on today. Wait for the restructuring to play out and evaluate the Series C opportunity in late 2026.
