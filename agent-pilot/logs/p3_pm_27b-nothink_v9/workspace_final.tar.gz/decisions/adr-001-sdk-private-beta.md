# ADR-001: Scope of "V1" — Dashboard GA vs SDK Private Beta

**Date:** 2026-04-08 (week 6)
**Status:** Accepted
**Decider:** Brendan (CEO)

## Context

The SDK access-control gap (discovered week 4, assessed week 5) requires a 4-week IAM project. Three options were presented to Brendan in week 5:
- (a) Ship V1 without the embedded SDK; SDK becomes V1.5 in August
- (b) Ship V1 with SDK in private beta (3-5 customers) with extra contracts
- (c) Push V1 to August with everything

## Decision

Brendan chose **Option B** via Slack (week 6): private beta with 3-5 customers. He stated: "We have access-control commitments to make right but we cannot delay V1 entirely."

## Consequences

- Dashboard refresh ships GA in mid-July as planned
- SDK ships in private beta only; not general availability
- Legal must produce private-beta contracts for access-control commitments
- Full IAM implementation remains a post-V1 commitment
- At least one customer (Maevia) was promised GA SDK and will need expectation management
