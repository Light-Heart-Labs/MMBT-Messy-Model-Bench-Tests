# Working Notes — Synthesis Process

## Reading Pass: Key Facts Extracted

### Team & Roles
- Sara — PM
- Marcus — Tech Lead (backend / query layer)
- Jen — UX
- Roman — Data / architecture
- Brendan — CEO (sporadic attendance)
- Priya — Security (joined week 5)
- Aanya — substitute code reviewer (week 4)
- Lin — original reviewer, on PTO until 3/24 (week 3)

### Workstreams Identified

1. **Query Layer** (owner: Marcus)
   - W1: 4-6 week estimate
   - W2: revised to 8 weeks (parser needed, filter combos non-trivial)
   - W3: blocked on Lin's PTO; needs sub reviewer
   - W4: got sub reviewer (Aanya); on track for mid-May
   - W5: proceeding
   - W6: 60% done, tracking to mid-May
   - **Current status:** On track, mid-May completion. Blocking V1.

2. **Dashboard Design / UX** (owner: Jen)
   - W1: design in progress; open questions on custom branding & mobile
   - W2: custom branding confirmed wanted; ~3 weeks extra design work
   - W3: custom branding CUT from V1 (Brendan decision); Jen pivots to mobile
   - W4: mobile scope: native = 12+ weeks; web-responsive = 4 weeks. Decision: responsive in V1, native in V2.
   - W5: mobile-responsive on track for mid-May
   - W6: on track; custom branding still parked
   - **Current status:** On track, mid-May. Blocking V1.

3. **Data Pipeline / Panel Density** (owner: Roman)
   - W1: pipeline fine for dashboard; latency concern for SDK at 100+ panels
   - W2: confirmed: current arch hits ~40 panels/page before lag
   - W3: 40-panel limit accepted as known limitation in V1; architectural fix planned as V1.1 fast-follow
   - W4: started architectural fix in parallel; 6-week estimate
   - W5: on track
   - W6: 30% done; on track for V1.1 in August
   - **Current status:** V1 ships with 40-panel limit (documented). Arch fix on track for V1.1. Not blocking V1.

4. **SDK Access-Control / IAM** (owner: Priya / Roman)
   - W4: discovered gap — no access-control layer for multi-tenant embedding scenario
   - W5: Priya says 4-week minimum; needs IAM design + customer API + audit logging. Blows V1 timeline.
   - W6: IAM design started; ready for API discussion next week
   - **Current status:** In progress. Resolved via Option B (private beta). Blocking V1 SDK GA.

5. **Custom Branding** (owner: Jen)
   - W2: confirmed wanted, ~3 weeks extra
   - W3: CUT from V1 (Brendan decision)
   - W6: still parked
   - **Current status:** Deferred to post-V1. Not blocking V1.

6. **Mobile** (owner: Jen)
   - W1: open question
   - W3: Jen pivots to mobile after branding cut
   - W4: decision: web-responsive in V1, native in V2
   - W5: on track for mid-May
   - W6: on track
   - **Current status:** On track, mid-May. Blocking V1.

### Timeline
- W1: Brendan wants end-of-June
- W2: end-of-June not realistic
- W3: Brendan accepts mid-July GA; August is a problem (conference commit)
- W5: access-control gap threatens timeline; options presented
- W6: Brendan chooses Option B (private beta with 3-5 customers)
- **Current target:** mid-July GA for dashboard; SDK in private beta

### Decisions Made
1. W3: Custom branding cut from V1 — Brendan
2. W3: 40-panel limit accepted as documented limitation in V1 — Brendan
3. W4: Mobile = web-responsive in V1, native in V2 — Sara + Jen
4. W6: SDK ships in private beta (Option B) with 3-5 customers — Brendan

### Risks
1. Legal hasn't responded to private-beta contract draft (W6) — HIGH
2. Maevia promised GA SDK at conference; will push back on private-beta (W6) — HIGH
3. Access-control / IAM is 4-week project; private beta is workaround but not full fix (W5-W6) — MEDIUM
4. Query layer was underestimated (4-6 → 8 weeks); timeline is tight (W2) — MEDIUM
5. Panel-density architectural fix is a fast-follow, not in V1 (W3) — LOW

### Milestones
- Mid-May: query layer complete (Marcus)
- Mid-May: mobile-responsive design complete (Jen)
- Mid-July: V1 GA (dashboard) — target per W3
- August: V1.1 with architectural fix (Roman)
- TBD: SDK access-control full implementation (Priya/Roman)

### Open Questions / Asks for CEO
- Legal delay on private-beta contracts — may need CEO escalation
- Maevia expectation management — CEO may need to weigh in on customer communication
- Final V1 date confirmation — mid-July is the target but access-control risk could push
