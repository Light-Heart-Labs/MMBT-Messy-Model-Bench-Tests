# Project Aurora — Status Report

**Prepared for:** Brendan (CEO)
**As of:** 2026-04-08 (week 6)

---

## Headline

Project Aurora is tracking to a **mid-July V1 GA for the dashboard refresh**, with the **embedded SDK shipping in private beta** (3–5 customers) due to an access-control gap discovered in week 4. Two customer-facing risks require your attention: a legal delay on private-beta contracts and a GA promise made to customer Maevia at the conference.

---

## Workstreams

| Workstream | Owner | Status | Blocking V1? |
|---|---|---|---|
| Query layer (SDK filter expressions) | Marcus | 60% done; on track for mid-May (W6) | Yes |
| Mobile-responsive UX | Jen | On track for mid-May (W6) | Yes |
| SDK access-control / IAM | Priya, Roman | IAM design started; API discussion next week (W6) | Yes (resolved via private beta) |
| Data pipeline / panel-density fix | Roman | 30% done; targeting V1.1 in August (W6) | No (40-panel limit accepted for V1) |
| Custom branding | Jen | Parked; deferred to post-V1 (W3) | No |

---

## Risks

| Severity | Risk |
|---|---|
| **HIGH** | Legal has not responded to the private-beta contract draft; delay could block SDK beta launch (W6) |
| **HIGH** | Customer Maevia was promised GA SDK at the conference; they will push back on private-beta-only (W6) |
| **MEDIUM** | Access-control / IAM is a 4-week project; private beta is a workaround, not a full fix (W5–W6) |
| **MEDIUM** | Query-layer estimate grew from 4–6 to 8 weeks; timeline has no slack (W2) |
| **LOW** | Panel-density architectural fix deferred to V1.1; 40-panel limit must be clearly documented (W3) |

---

## Decisions Made

| Date | Decision | Decider |
|---|---|---|
| Week 3 (3/18) | Custom branding cut from V1 | Brendan |
| Week 3 (3/18) | 40-panel limit accepted as documented V1 limitation | Brendan |
| Week 4 (3/25) | Mobile strategy: web-responsive in V1, native in V2 | Sara, Jen |
| Week 6 (4/8) | SDK ships in private beta (Option B) with 3–5 customers | Brendan |

---

## Milestones

| Target | Milestone | Owner |
|---|---|---|
| Mid-May | Query layer complete | Marcus |
| Mid-May | Mobile-responsive UX complete | Jen |
| Mid-July | V1 GA (dashboard refresh) | Sara |
| August | V1.1 — panel-density architectural fix | Roman |
| TBD | Full IAM / access-control implementation | Priya, Roman |

---

## Open Questions / Asks

1. **Legal escalation:** The private-beta contract draft has no response from Legal. Do you want to escalate?
2. **Maevia communication:** Maevia was promised GA SDK at the conference. Sara has a call with their CSM tomorrow — do you want to be involved in the customer conversation?
3. **V1 date confirmation:** Mid-July is the current target. If Legal or Maevia issues escalate, should we pre-emptively communicate a potential slip to August?
