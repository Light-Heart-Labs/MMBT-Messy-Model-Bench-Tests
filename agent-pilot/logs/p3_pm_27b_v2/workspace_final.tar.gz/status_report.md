# Project Aurora — Status Report for CEO Brendan

## Headline

Project Aurora (dashboard refresh + embedded analytics SDK) is tracking toward **mid-July V1 GA** for the dashboard, with the SDK launching in **private beta** to 3–5 customers. The access-control gap (discovered week 4) is the primary risk, mitigated by the private-beta approach approved week 6.

---

## Workstreams

| Workstream | Owner | Status | Blocking V1? |
|---|---|---|---|
| Dashboard Refresh | Jen | On track; mobile-responsive added (week 4) | No |
| Embedded SDK | Marcus / Roman | Private beta only (week 6); access-control incomplete | Partially |
| Query Layer | Marcus | 60% done, tracking to mid-May (week 6) | No |
| Mobile | Jen | Web-responsive chosen over native (week 4); on track for mid-May | No |
| Panel Density | Roman | 40-panel limit accepted (week 3); fix targeting V1.1 in August | No |
| Access Control (IAM) | Priya + Marcus | Design started (week 6); 4-week minimum (week 5) | Yes — for SDK GA |

---

## Risks

| Severity | Risk |
|---|---|
| **HIGH** | Access-control gap in SDK — 4-week IAM build needed (week 5). Mitigated by private-beta (week 6). |
| **HIGH** | Legal delay — no response to private-beta contract draft (week 6). Blocks beta launch. |
| **MEDIUM** | Maevia expectation mismatch — promised GA SDK at conference (week 3); now private-beta. |
| **MEDIUM** | Timeline pressure — mid-July defensible to board, but August is problematic (week 3). |
| **LOW** | Panel-density limit — 40 panels/page is V1 ceiling, documented (week 3). Fix targeting V1.1. |

---

## Decisions Made

| Date | Decision | Decider |
|---|---|---|
| 2026-03-04 (week 1) | Aurora = dashboard refresh + embedded SDK as one shipped product | Sara |
| 2026-03-18 (week 3) | Cut custom branding from V1; defer to V2 | Brendan |
| 2026-03-18 (week 3) | Accept 40-panel limit as V1 limitation; fix as V1.1 | Brendan |
| 2026-03-25 (week 4) | Mobile = web-responsive in V1, native in V2 | Sara + Jen |
| 2026-04-08 (week 6) | SDK ships in private beta (option B) with 3–5 customers | Brendan |

---

## Milestones

| Target | Milestone | Owner |
|---|---|---|
| Mid-May 2026 | Query layer completion | Marcus |
| Mid-May 2026 | Mobile-responsive completion | Jen |
| Mid-July 2026 | V1 GA (dashboard) + private-beta SDK | Sara |
| August 2026 | V1.1 panel-density fix | Roman |
| TBD | Full access-control layer | Priya + Marcus |

---

## Open Questions / Asks

1. **Legal:** Unblocked — no response to private-beta contract draft (week 6).
2. **Maevia:** May need escalation — they expect GA SDK per conference commitment (week 3).
3. **V1 date:** Confirm mid-July is still defensible given access-control and legal risks.
