# ADR-001: Definition of "Blocking V1"

**Status:** Accepted
**Date:** 2026-04-08

## Context

The status report needs to flag which workstreams are blocking the V1 release. The source notes don't use this terminology explicitly.

## Decision

"Blocking V1" means: the workstream must be complete (or have an accepted mitigation) before V1 can ship. If a workstream is incomplete but has an accepted workaround (e.g., private beta, documented limitation), it is marked as "Partially" blocking.

## Rationale

- The access-control layer is incomplete but has a private-beta workaround (week 6). Marked as "Partially" blocking.
- The 40-panel limit is accepted as a V1 known limitation (week 3). Not blocking.
- Custom branding was cut from V1 (week 3). Not blocking.
- Query layer and mobile-responsive are on track. Not blocking.
