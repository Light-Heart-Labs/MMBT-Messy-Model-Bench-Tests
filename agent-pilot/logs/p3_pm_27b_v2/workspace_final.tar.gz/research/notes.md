# Working Notes — Synthesis Process

## Workstreams Identified

1. **Dashboard Refresh** — Core dashboard UI overhaul. Owner: Jen (UX). Status: On track. Mobile-responsive added to V1 scope (week 4). Custom branding deferred to V2 (week 3 decision by Brendan).

2. **Embedded Analytics SDK** — SDK that uses dashboard primitives. Owner: Marcus (TL) / Roman (data). Status: Conditional — shipping in private beta only (week 6 decision by Brendan). Blocked on access-control layer (discovered week 4, scoped week 5).

3. **Query Layer** — Backend work to support SDK filter expressions. Owner: Marcus. Status: 60% done, tracking to mid-May (week 6). Estimate: 8 weeks (revised week 2).

4. **Mobile Strategy** — Owner: Jen. Status: Web-mobile-responsive chosen over native (week 4 decision by Sara/Jen). On track for mid-May (week 6).

5. **Data Pipeline / Panel Density** — Owner: Roman. Status: 40-panel limit accepted as V1 known limitation (week 3). Architectural fix in progress, 30% done, targeting V1.1 in August (week 6).

6. **Security / Access Control (IAM)** — Owner: Priya (security) + Marcus. Status: IAM design started (week 6). 4-week minimum project (week 5). Required for SDK but deferred to private-beta workaround.

## Risks Identified

1. **HIGH** — Access-control gap in SDK. Discovered week 4. 4-week minimum fix (week 5). Mitigated by private-beta approach (week 6), but still a risk if beta customers encounter issues.

2. **HIGH** — Legal delay on private-beta contracts. Week 6: legal hasn't responded to draft.

3. **MEDIUM** — Maevia customer expectation mismatch. Promised GA SDK at conference; now private-beta only. Week 6: Sara has call with CSM.

4. **MEDIUM** — Timeline pressure. Brendan can defend mid-July but August is a problem (week 3). Access-control discovery (week 4-5) threatened timeline; option B chosen to preserve date.

5. **LOW** — Panel-density limit (40 panels/page). Accepted as V1 limitation, documented. Architectural fix targeting V1.1.

## Decisions Log

1. Week 1 (2026-03-04): Aurora = dashboard refresh + embedded SDK as one shipped thing. Decider: Sara (team consensus).
2. Week 3 (2026-03-18): Cut custom branding from V1; defer to V2. Decider: Brendan.
3. Week 3 (2026-03-18): Accept 40-panel limit as V1 known limitation; architectural fix as V1.1. Decider: Brendan.
4. Week 4 (2026-03-25): Mobile = web-responsive in V1, native in V2. Decider: Sara + Jen.
5. Week 6 (2026-04-08): SDK ships in private beta (option B) with 3-5 customers signing extra contracts. Decider: Brendan (via Slack).

## Milestones

- Mid-May 2026: Query layer completion (Marcus)
- Mid-May 2026: Mobile-responsive completion (Jen)
- Mid-July 2026: V1 GA (dashboard refresh) / private-beta SDK launch (Sara)
- August 2026: V1.1 with architectural fix for panel density (Roman)
- TBD: Full access-control layer (Priya + Marcus)

## Open Questions / Asks for CEO

- Legal engagement for private-beta contracts is stalled.
- Maevia customer expectation management.
- Final V1 date confirmation (mid-July still target but under pressure).
