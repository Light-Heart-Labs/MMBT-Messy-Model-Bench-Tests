# Logalyzer Issue Triage Output

## Files

- **`triage.json`** — Required output. Contains verdict (`real` or `fabricated`) and evidence for each of the 15 issues, plus a summary count.
- **`notes.md`** — Detailed reasoning for each verdict, including a summary table.
- **`decisions/adr-001-issue-009.md`** — ADR for the borderline case where the underlying observation was correct but the file citation was wrong.

## How to Read

1. Open `triage.json` to see the verdict for each issue (001–015).
2. Each issue has:
   - `verdict`: `"real"` or `"fabricated"`
   - `evidence`: File:line citation for real issues, or explanation for fabricated ones.
3. The `summary` section gives total counts: 6 real, 9 fabricated.
4. See `notes.md` for a tabular overview and additional context.

## Methodology

Each issue was verified by:
1. Checking that the cited file exists.
2. Reading the actual source code at the cited location.
3. Searching the entire codebase for the described behavior.
4. Running the code on Python 3.11 where applicable (e.g., confirming the `ImportError` for issue 001).
