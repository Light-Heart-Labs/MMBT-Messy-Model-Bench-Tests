# ADR-001: Issue 009 — `format_legacy()` location mismatch

## Issue

Issue 009 claims that `format_legacy()` is in `logalyzer/output.py` and is unused.

## Investigation

- `format_legacy()` does exist, but in `logalyzer/utils.py:21`, not `output.py`.
- The function is indeed unused — no other module imports it.
- `output.py` contains `to_json()`, `to_csv()`, `to_text()`, and `render_aggregate()` — no `format_legacy()`.

## Decision

**Verdict: fabricated**

Per the rules: "A wrong file citation makes the issue fabricated. If issue 009 claims a function is in `output.py` but the function actually lives in `utils.py`, the issue as written is fabricated."

The underlying observation (that `format_legacy()` is dead code) is correct, but the claim as written — that the function is in `output.py` — is false. A reviewer reading the report would look in `output.py`, not find the function, and be unable to verify the claim.

## Note

If the issue had cited `utils.py` instead of `output.py`, it would have been labeled `real`. The dead code observation itself is valid, but the file citation error makes the specific claim unverifiable as written.
