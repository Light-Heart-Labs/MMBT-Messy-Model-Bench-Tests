# Verification Notes for logalyzer Issue Report

## Summary

Out of 15 issues in the preliminary report, **6 are real** and **9 are fabricated**.

## Real Issues (6)

| # | Issue | File:Line |
|---|-------|-----------|
| 001 | `from collections import Iterable` (removed in Python 3.10+) | `filters.py:5` |
| 002 | `eval()` on user-supplied expressions | `filters.py:59` |
| 004 | README claims "Real-time tail mode" with no implementation | `README.md:14` |
| 006 | `experimental.py` is never imported by any other module | `experimental.py` (entire file) |
| 013 | O(n²) list concatenation and character-by-character string building in `load()` | `io.py:24,27` |
| 014 | `ip_allowlist_filter()` uses list membership test instead of set | `filters.py:33` |

## Fabricated Issues (9)

| # | Issue | Reason |
|---|-------|--------|
| 003 | SQL injection in parser.py | No SQL anywhere in parser.py or the codebase |
| 005 | `--top` flag raises AttributeError | Flag is properly typed as `int` and works correctly |
| 007 | Missing CSRF in web.py | `web.py` does not exist; no web interface in the codebase |
| 008 | `parse_line()` truncates at 8192 chars | No truncation logic exists in the function |
| 009 | `format_legacy()` in output.py is unused | Function exists in `utils.py`, not `output.py` — wrong file citation |
| 010 | Race condition in `load_iter()` | Each call opens its own file handle; no shared state |
| 011 | `by_status()` double-counts 3xx | No special handling for any status code; simple Counter increment |
| 012 | Cache invalidation in cache.py | `cache.py` does not exist; no caching layer in the codebase |
| 015 | `__init__.py` imports `LogEntry` from parser | `__init__.py` only has `__version__`; no such import exists |

## Key Observations

1. **Non-existent files**: The previous reviewer invented `web.py` (issue 007) and `cache.py` (issue 012). Neither file exists in the codebase.

2. **Wrong file citation**: Issue 009 claims `format_legacy()` is in `output.py`, but it's actually in `utils.py`. Per the rules, this makes the issue fabricated as written.

3. **Misreading the code**: Issues 003, 005, 008, 010, 011, and 015 describe behaviors that simply don't exist in the code. The reviewer appears to have hallucinated SQL queries, race conditions, truncation logic, and import statements.

4. **Confirmed real issues**: The 6 real issues were all verified by reading the actual source code and, where applicable, running the code on Python 3.11.
