# ADR-0002: Public API shape

## Status

Accepted.

## Context

The `logalyzer.output` module is imported by `cli.py` with:

```python
from .output import render_aggregate, to_csv, to_json, to_text
```

Additionally, the task requires that `format_legacy` remain importable from `logalyzer.output` for backward compatibility, even though it's defined in `utils.py`.

## Decision

The `logalyzer/output/__init__.py` re-exports the following public API:

| Name | Source module | Notes |
|---|---|---|
| `to_json` | `json_renderer.py` | Moved directly from original `output.py` |
| `to_csv` | `csv_renderer.py` | Moved directly from original `output.py` |
| `to_text` | `plain_renderer.py` | Moved directly from original `output.py` |
| `render_aggregate` | `__init__.py` | Kept in `__init__.py` as it doesn't fit a single renderer |
| `format_legacy` | `legacy.py` (→ `utils.py`) | Re-exported for backward compatibility |

### Why `render_aggregate` stays in `__init__.py`

`render_aggregate` operates on arbitrary aggregate data (Counters, dicts, lists), not specifically on `LogEntry` objects. It doesn't belong in any of the three `LogEntry`-specific renderers. Placing it in `__init__.py` keeps it accessible while acknowledging it's a general-purpose utility.

### Why `format_legacy` is in `legacy.py`

`format_legacy` is defined in `utils.py` but the task requires it to be importable from `logalyzer.output`. The `legacy.py` module acts as a shim, re-exporting the function from `utils.py`. This keeps the legacy concern isolated in its own module while maintaining the import path.

## Consequences

- All existing `from logalyzer.output import X` calls continue to work.
- The `__all__` list in `__init__.py` documents the complete public API.
- Future callers can import from submodules directly (e.g., `from logalyzer.output.json_renderer import to_json`) if they prefer explicit imports.
