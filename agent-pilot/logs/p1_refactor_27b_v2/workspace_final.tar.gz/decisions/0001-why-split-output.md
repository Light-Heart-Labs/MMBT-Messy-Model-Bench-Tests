# ADR-0001: Why split output.py?

## Status

Accepted.

## Context

The `logalyzer/output.py` module mixed four distinct concerns:

1. **JSON serialization** (`to_json`) — renders `LogEntry` lists as JSON arrays
2. **CSV serialization** (`to_csv`) — renders `LogEntry` lists as CSV with headers
3. **Plain-text formatting** (`to_text`) — renders `LogEntry` lists as human-readable text
4. **Aggregate rendering** (`render_aggregate`) — renders Counter/dict/list aggregates
5. **Legacy compatibility** (`format_legacy`) — a v0.1-era formatter kept for external scripts

While the module was small, the mixing of concerns made it harder to:
- Understand which function served which purpose
- Add new output formats without bloating the file
- Reason about dependencies (e.g., `csv` and `io` imports only needed by `to_csv`)

## Decision

Split `logalyzer/output.py` into a `logalyzer/output/` package with one module per concern:

| Module | Contents |
|---|---|
| `output/__init__.py` | Re-exports public API; contains `render_aggregate` |
| `output/json_renderer.py` | `to_json()` |
| `output/csv_renderer.py` | `to_csv()` |
| `output/plain_renderer.py` | `to_text()` |
| `output/legacy.py` | `format_legacy()` (re-exported from `utils.py`) |

## Consequences

- **Positive**: Each module has a single, clear responsibility. New output formats can be added as new modules without touching existing ones.
- **Neutral**: The public API surface is unchanged. All existing imports continue to work.
- **Negative**: Slightly more files to navigate, but the structure is self-documenting.
