# Working Notes — 2025-01-XX

## Discovery

- `output.py` contains 4 functions: `to_json`, `to_csv`, `to_text`, `render_aggregate`
- `format_legacy` is actually in `utils.py`, not `output.py` — but must be importable from `logalyzer.output`
- Only `cli.py` imports from `output.py`: `from .output import render_aggregate, to_csv, to_json, to_text`
- No tests directly test `output.py` functions
- Pre-existing bugs found:
  1. `filters.py`: `from collections import Iterable` fails on Python 3.11
  2. `filters.py`: `status_filter` compares `entry.status == status` without type coercion (int vs str)
  3. `filters.py`: `url_regex_filter` uses `re.match` (anchored at start) instead of `re.search`
  4. `parser.py`: `MONTH_NAMES` list is missing "Jul" (has "Aug" but not "Jul")

## Approach

1. Fix `collections.Iterable` import to enable test execution (documented in dead-ends.md)
2. Create `logalyzer/output/` package with 5 modules
3. Move each function to its own module
4. Create `__init__.py` that re-exports the full public API
5. Delete `output.py`
6. Verify all imports still work and tests pass

## Key decisions

- `render_aggregate` stays in `__init__.py` because it's not LogEntry-specific
- `format_legacy` is re-exported via `legacy.py` shim from `utils.py`
- All function bodies are byte-identical copies from the original `output.py`
