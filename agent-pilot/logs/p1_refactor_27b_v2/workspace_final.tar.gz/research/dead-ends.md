# Dead Ends & Pre-existing Issues

## Pre-existing bug: `from collections import Iterable` in `filters.py`

**File:** `logalyzer/filters.py`, line 5

**Issue:** `collections.Iterable` was deprecated in Python 3.3 and removed in Python 3.10. The import `from collections import Iterable` causes an `ImportError` on Python 3.11, preventing the entire test suite from running.

**Resolution:** Applied minimal fix: changed to `from collections.abc import Iterable`. This is a Python 3.11 compatibility fix, not a logic change. Without this fix, no tests can run, making verification of the output.py refactor impossible.

**Note:** This was NOT part of the output.py refactor scope. It was a pre-existing issue in `filters.py` that had to be addressed to enable test execution. The fix is a one-line import change with zero behavioral impact.

## No other dead ends

The output.py refactor proceeded cleanly. No alternative approaches were tried and reverted.
