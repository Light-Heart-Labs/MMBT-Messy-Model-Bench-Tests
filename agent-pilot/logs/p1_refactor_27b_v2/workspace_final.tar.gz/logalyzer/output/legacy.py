"""Legacy output formatters retained for backwards compatibility.

Re-exports format_legacy from utils for callers that import it from
logalyzer.output.
"""
from __future__ import annotations

from ..utils import format_legacy

__all__ = ["format_legacy"]
