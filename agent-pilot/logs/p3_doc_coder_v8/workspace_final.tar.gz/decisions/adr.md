# ADR — Executive Brief Framing for Nimbus Logistics

## Decision: Recommend **PASS** on follow-on investment

### Rationale
The company is in a "survival phase" rather than a "growth phase." The Series B was a down round (valued at $560M vs $720M target), and the internal memo confirms the company needs to achieve cash-flow breakeven by Q4 2026 to avoid a fire sale in Series C. The investor is being asked to make a *follow-on* investment, which implies continuing to support the company through this precarious phase.

### Key factors driving the stance

1. **Adjusted ARR is materially lower than headline figure**
   - Press release: $42M ARR
   - TechCrunch (with two financial sources): $36-37M run-rate after December churn
   - This 12-14% reduction is material and indicates underlying weakness masked by the press release

2. **Customer concentration and churn**
   - Top 5 customers = ~38% of ARR (per blog post)
   - Two top-5 customers lost in late 2025 (Sundry $4.2M, Klatch unnamed but "fast-fashion")
   - This is not a one-off; it's a pattern of losing large customers

3. **High burn relative to revenue**
   - Blog post: $4M/month burn vs ~$3.5M/month revenue → $0.5M monthly loss
   - Even with $84M raised + $50M credit facility = $134M total, runway is only ~24 months at current burn
   - Restructuring aims to extend runway to 36+ months but requires significant cuts

4. **Valuation repricing**
   - Series B intended to close at $720M but repriced to $560M (22% down)
   - This signals to the market that the company's trajectory was weaker than expected

5. **International expansion scaled back**
   - Press release says "accelerate international expansion"
   - Internal memo says "pause new hires in EMEA" and "defer international expansion to 2027"
   - This is a major strategic pivot that contradicts the public narrative

6. **Layoffs and Lite tier sunset**
   - 22 layoffs in Feb 2025 (~11% of org)
   - Sunset of Nimbus Lite tier (310 customers)
   - These are signs of operational missteps, not just strategic optimization

### Counterarguments considered (and rejected)

1. **"Net retention >110%" (CEO claim)**
   - This could mask churn if new logos are adding more ARR than lost customers
   - But losing two top-5 customers in the same quarter suggests systemic issues
   - Need to see if new logos are as sticky as lost ones

2. **"3 new $1M+ ARR contracts signed in Q1" (CEO claim)**
   - Positive, but 3 x $1M = $3M ARR vs $8.2M lost (Sundry $4.2M + Klatch ~$4M)
   - Not a full offset
   - Need more data on retention of these new customers

3. **"36+ months runway" (internal memo)**
   - This is a positive, but it assumes the restructuring works
   - The memo is a plan, not a guarantee
   - The company is still burning cash and needs to achieve breakeven

4. **"Strong engineering culture" (blog post)**
   - This is a positive, but engineering quality doesn't guarantee business success
   - Many startups have great engineering but fail due to business model issues

5. **"Real product-market fit" (blog post)**
   - Customer love is real, but that doesn't prevent churn of large customers
   - Mid-market brands may be loyal but also may have limited budgets and switch for better deals

### Recommendation: PASS

**Stated stance:** The investor should pass on a follow-on investment at the current $560M valuation. The company is in a precarious position with high burn, customer churn, and a down round. The internal memo confirms the company needs to achieve cash-flow breakeven by Q4 2026 to avoid a fire sale in Series C. The investor would be better off waiting for a clearer signal of stability before investing more capital.

### Triggers that would change the recommendation

1. **ARR growth to $45M+ by end of Q2 2026**
   - This would indicate the new sales are offsetting churn
   - Would suggest the company is on track to breakeven

2. **Net retention >120% for two consecutive quarters**
   - This would indicate the company is growing organically despite churn
   - Would suggest the business model is sustainable

3. **Announcement of a strategic acquisition or partnership**
   - This would validate the business and provide a path to scale
   - Would reduce the risk of a fire sale

4. **Confirmation of $50M credit facility**
   - The SEC filing doesn't mention it, so it may not be real
   - If confirmed, it would extend runway and reduce near-term pressure

5. **Public confirmation of the $720M valuation target**
   - If the company confirms it raised at $720M and TechCrunch was wrong, it would change the narrative
   - But TechCrunch has two sources, so this is unlikely

### Final note

The brief should be honest about source quality:
- Press release: company narrative only (use for basic facts)
- TechCrunch: journalistic reporting (best for churn, valuation repricing)
- Blog post: first-hand internal view (best for burn, layoffs, concentration)
- Leaked memo: internal strategy (best for restructuring, credit facility)
- SEC Form D: legal filing (best for confirming funding amount)

The brief should not repeat the press release but should synthesize all five sources to give the investor a realistic picture of the company's position.
