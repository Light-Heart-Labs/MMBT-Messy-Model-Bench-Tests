# Nimbus Logistics, Inc. — Deal Evaluation Package

## Overview

This package contains an executive brief and supporting analysis for evaluating a follow-on investment in Nimbus Logistics, Inc., a Series-B logistics-tech startup.

## Files

- **`brief.md`** — The 1-page executive brief (primary deliverable). Contains the recommendation (PASS), key facts, tensions, and triggers that would change the stance.
- **`key-facts.md`** — A list of every material fact incorporated into the brief, with source attribution.
- **`research/notes.md`** — Working notes from reading the five sources, including source-by-source summaries, key tensions, and source reliability assessment.
- **`decisions/adr.md`** — ADR-style records for framing choices, including why the recommendation is PASS and what would change it.

## How to Read This Output

1. **Start with `brief.md`** — This is the deliverable for the investor. It’s at most 700 words, leads with a clear stance (PASS), and cites sources inline.
2. **Check `key-facts.md`** — Verify that every metric in the brief is traceable to one of the five sources.
3. **Review `research/notes.md`** — See how the synthesis was built from the five sources.
4. **Read `decisions/adr.md`** — Understand the framing choices and counterarguments considered.

## Rules of the Road (Applied)

- **Don’t repeat the press release** — The brief doesn’t just say "they raised $84M, doubled valuation, growth from $11M to $42M ARR." It highlights tensions (e.g., $42M vs $36-37M ARR, $720M vs $560M valuation).
- **Highlight tensions, not just facts** — The brief shows how the press release narrative is contradicted by the TechCrunch article, blog post, and leaked memo.
- **Stay calibrated** — The leaked memo and blog post are used with language like "according to" rather than treating them as ground truth.
- **One clear recommendation** — The brief states PASS with specific triggers that would change it.

## Source Quality

- **Press release (Source 1)**: Company narrative only. Best for basic facts but omits risks.
- **TechCrunch (Source 2)**: Journalistic reporting with anonymous sources. Best for customer churn, valuation repricing.
- **Blog post (Source 3)**: First-hand internal view. Best for burn rate, layoffs, customer concentration.
- **Leaked memo (Source 4)**: Internal strategy document. Best for restructuring plans, credit facility.
- **SEC Form D (Source 5)**: Legal filing. Best for confirming funding amount, investors.

## Recommendation

**PASS** on follow-on investment at current $560M valuation. The company is in a "survival phase" rather than a "growth phase," and the internal memo confirms it needs to achieve cash-flow breakeven by Q4 2026 to avoid a fire sale in Series C.

### Triggers that would change the recommendation

1. ARR growth to $45M+ by end of Q2 2026
2. Net retention >120% for two consecutive quarters
3. Announcement of a strategic acquisition or partnership
4. Confirmation of $50M credit facility
5. Public confirmation of $720M valuation target

---

**Final commit tags a release.**
