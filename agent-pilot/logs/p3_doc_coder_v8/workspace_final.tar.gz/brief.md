# Executive Brief: Nimbus Logistics, Inc. — Follow-on Investment Recommendation

**Date:** 2026-03-10  
**Prepared for:** Investment Committee  
**Recommendation:** **PASS** on follow-on investment at current $560M valuation

---

## Executive Summary

Nimbus Logistics closed a $84M Series B at a $560M post-money valuation, but the company is in a precarious position that warrants a *pass* on a follow-on investment at this valuation. The press release paints a rosy picture of $42M ARR and international expansion, but the internal memo and TechCrunch reporting reveal a company that has lost two top-5 customers, repriced its down round from $720M to $560M, and is burning cash at a rate that requires significant restructuring to survive. The company’s path to viability hinges on achieving cash-flow breakeven by Q4 2026 — a high bar that is not yet proven.

---

## Key Facts and Tensions

### ARR: Headline vs. Adjusted
- Press release reports $42M ARR as of Q4 2025 [Source 1]
- TechCrunch, citing two financial sources, adjusts this to $36-37M run-rate after December 2025 churn [Source 2]
- This 12-14% reduction is material and indicates underlying weakness masked by the press release

### Customer Churn and Concentration
- Lost two top-5 customers in late 2025:
  - Sundry Brands ($4.2M ARR) — non-renewed November [Source 2]
  - Klatch (fast-fashion) — exited December, migrated to competitor [Source 2]
- Top 5 customers = ~38% of ARR (widely understood internally) [Source 3]
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 and net retention >110% [Source 2]
- But 3 x $1M = $3M ARR vs $8.2M lost (Sundry $4.2M + Klatch ~$4M) — not a full offset

### Burn and Runway
- Monthly burn: ~$4M all-in vs ~$3.5M revenue → $0.5M monthly loss [Source 3]
- Series B ($84M) + $50M credit facility = $134M total capital [Source 1, Source 4]
- Runway: 24+ months at current burn, extended to 36+ months after restructuring [Source 4]
- Goal: cash-flow breakeven by Q4 2026 to avoid Series C from a position of weakness [Source 4]

### Valuation and Down Round
- Series B valued at $560M post-money [Source 1]
- Originally intended to close at $720M but repriced down after Sundry non-renewal in early December [Source 2]
- This 22% repricing signals to the market that the company’s trajectory was weaker than expected

### Strategic Pivot
- Press release says "accelerate international expansion" [Source 1]
- Internal memo says "pause new hires in EMEA" and "defer international expansion to 2027" [Source 4]
- Berlin office: 41 → 28-30 by end of Q2 2026 (30% reduction) [Source 4]
- Nimbus Lite tier (~310 customers) to be sunset with 90-day notice [Source 4]

### Operational Red Flags
- Layoffs in February 2025: 22 people (~11% of 187 employees), mostly customer success and BD [Source 3]
- High burn relative to revenue suggests operational missteps
- Customer concentration risk (top 5 = 38% of ARR) amplified by recent churn

---

## Strengths

- Strong technical foundation: Engineering quality described as "genuinely good" with "cleanest distributed-systems code" [Source 3]
- Real product-market fit: Mid-market brands "truly depend on the platform" [Source 3]
- Competitive compensation: Senior engineers at $215K base + $50K equity (top quartile) [Source 3]
- Founders credible: Mira Patel and Daniel Wong are experienced operators [Source 1]
- 1,400 customers (diversified base beyond top 5) [Source 1]

---

## Recommendation: PASS

The investor should pass on a follow-on investment at the current $560M valuation. The company is in a "survival phase" rather than a "growth phase," and the internal memo confirms it needs to achieve cash-flow breakeven by Q4 2026 to avoid a fire sale in Series C. The investor would be better off waiting for clearer signals of stability before investing more capital.

### Triggers that would change the recommendation

1. **ARR growth to $45M+ by end of Q2 2026** — would indicate new sales are offsetting churn
2. **Net retention >120% for two consecutive quarters** — would suggest sustainable organic growth
3. **Announcement of a strategic acquisition or partnership** — would validate the business
4. **Confirmation of $50M credit facility** — if not already secured, this would extend runway
5. **Public confirmation of $720M valuation target** — if TechCrunch was wrong, it would change the narrative

---

## Source Quality Assessment

- **Press release (Source 1)**: Company narrative only. Use for basic facts (funding, valuation, ARR, employee count) but ignore risk mitigation language.
- **TechCrunch (Source 2)**: Journalistic reporting with anonymous sources. Best for customer churn, valuation repricing, and adjusted ARR.
- **Blog post (Source 3)**: First-hand internal view. Best for burn rate, layoffs, customer concentration, and compensation.
- **Leaked memo (Source 4)**: Internal strategy document. Best for restructuring plans, credit facility, and path to breakeven.
- **SEC Form D (Source 5)**: Legal filing. Best for confirming funding amount and investors.

The brief synthesizes all five sources to provide a realistic picture of the company’s position, not just the press release narrative.

---

## Appendix: Key Metrics Summary

| Metric | Value | Source |
|--------|-------|--------|
| ARR (reported) | $42M | [Source 1] |
| ARR (adjusted) | $36-37M | [Source 2] |
| Monthly burn | ~$4M | [Source 3] |
| Monthly revenue | ~$3.5M | [Source 3] |
| Monthly loss | ~$0.5M | [Source 3] |
| Top 5 customers | ~38% of ARR | [Source 3] |
| Layoffs (Feb 2025) | 22 people (11%) | [Source 3] |
| Runway (post-restructuring) | 36+ months | [Source 4] |
| Goal: Cash-flow breakeven | Q4 2026 | [Source 4] |
