# Key Facts — Nimbus Logistics, Inc.

## Funding and Valuation
- Raised $84M Series B led by Lightning Capital, with Sequoia Capital, Accel, and FedEx Ventures participating [Source 1, Source 5]
- Post-money valuation: $560M [Source 1]
- Series B originally intended to close at $720M but repriced down after Sundry non-renewal in early December [Source 2]
- Total funding raised: $128M across all rounds [Source 1]
- Secured $50M credit facility from Silicon Valley Bridge [Source 4]

## Financial Metrics
- ARR reported as $42M as of Q4 2025 [Source 1]
- Adjusted ARR after December 2025 churn: $36-37M run-rate [Source 2]
- Monthly burn rate: ~$4M all-in [Source 3]
- Monthly revenue: ~$3.5M [Source 3]
- Monthly loss: ~$0.5M [Source 3]
- Top 5 customers = ~38% of ARR [Source 3]

## Customer Metrics
- 1,400 customers [Source 1]
- Lost two top-5 customers in late 2025:
  - Sundry Brands ($4.2M ARR) — non-renewed November [Source 2]
  - Klatch (fast-fashion) — exited December, migrated to competitor [Source 2]
- 3 new $1M+ ARR contracts signed in Q1 2026 [Source 2]
- CEO claims net retention >110% [Source 2]
- Nimbus Lite tier (~310 customers, $5K-$20K ARR each) to be sunset with 90-day notice [Source 4]

## Operational Metrics
- 187 employees across offices in Oakland, Austin, and Berlin [Source 1]
- Layoffs in February 2025: 22 people (~11% of org), mostly customer success and BD [Source 3]
- Berlin office: 41 → 28-30 by end of Q2 2026 (30% reduction) [Source 4]
- Pause new hires in EMEA; Berlin reframed as "support hub" not sales/expansion [Source 4]
- International expansion deferred to 2027 at earliest [Source 4]

## Product and Technology
- Founded 2021 by Mira Patel and CTO Daniel Wong [Source 1]
- Platform: warehouse management, carrier orchestration, demand forecasting [Source 1]
- Engineering quality described as "genuinely good" with "cleanest distributed-systems code" [Source 3]
- CTO Daniel Wong described as "the real deal" [Source 3]

## Compensation
- Senior engineer compensation: $215K base + $50K equity vest annually [Source 3]
- Compensation described as "competitive" and "top quartile for senior engineers in the Bay" [Source 3]

## Runway and Path to Profitability
- Series B gives 24+ months runway at current burn [Source 4]
- Restructuring extends runway to 36+ months [Source 4]
- Goal: cash-flow breakeven by Q4 2026 [Source 4]
- Breakeven is trigger to begin Series C conversations from strength rather than necessity [Source 4]

## Use of Proceeds
- "expansion, working capital, general corporate purposes" [Source 5]

## Source Quality Assessment
- Press release (Source 1): Company narrative only. Best for basic facts but omits risks.
- TechCrunch (Source 2): Journalistic reporting with anonymous sources. Best for customer churn, valuation repricing.
- Blog post (Source 3): First-hand internal view. Best for burn rate, layoffs, customer concentration.
- Leaked memo (Source 4): Internal strategy document. Best for restructuring plans, credit facility.
- SEC Form D (Source 5): Legal filing. Best for confirming funding amount, investors.
