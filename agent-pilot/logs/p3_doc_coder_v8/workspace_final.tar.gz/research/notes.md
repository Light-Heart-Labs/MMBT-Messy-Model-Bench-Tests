# Research Notes — Nimbus Logistics, Inc.

## Source-by-source summary

### Source 1 — Press Release (company-issued)
- Raised $84M Series B led by Lightning Capital, with Sequoia, Accel, FedEx Ventures participating
- Post-money valuation: $560M (up from $230M in Series A)
- Total funding: $128M
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400 customers, 187 employees (Oakland, Austin, Berlin)
- Founded 2021 by Mira Patel and Daniel Wong
- Platform: warehouse management, carrier orchestration, demand forecasting

### Source 2 — TechCrunch News Article
- Lost two top-5 customers in late 2025:
  - Sundry Brands ($4.2M ARR) — non-renewed November (called "strategic mutual decision")
  - Klatch (fast-fashion) — exited December, migrated to competitor
- Adjusted ARR after December churn: $36-37M run-rate
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026
- Claims net retention >110%
- Series B originally intended to close at $720M valuation but repriced down after Sundry non-renewal in early December

### Source 3 — Former Employee Blog Post
- Engineering quality is high; CTO Daniel Wong is "the real deal"
- Customer love is real; mid-market brands depend on platform
- Compensation competitive: $215K base + $50K equity for senior engineers
- Burn rate: ~$4M/month all-in vs ~$3.5M/month revenue (mid-2025)
- Layoffs in February 2025: 22 people (~11% of org), mostly customer success and BD
- Top 5 customers = ~38% of ARR (customer concentration risk)
- Path to survival requires faster growth or significant cuts

### Source 4 — Leaked Internal Memo
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end of Q2)
- Pause new hires in EMEA; Berlin reframed as "support hub" not sales/expansion
- Sunset "Nimbus Lite" tier (~310 customers, $5K-$20K ARR each); 90-day migration notice
- Secured $50M credit facility from Silicon Valley Bridge
- Goal: cash-flow breakeven by Q4 2026; trigger for Series C from strength, not necessity
- Extend runway from 24+ months to 36+ months

### Source 5 — SEC Form D
- Filed 2026-01-22
- $84M raised, 7 investors
- Use of proceeds: "expansion, working capital, general corporate purposes"

---

## Key tensions and contradictions

1. **ARR figure**: Press release says $42M; TechCrunch says adjusted for churn it's $36-37M; blog post implies revenue ~$3.5M/month ($42M ARR) which matches press release but contradicts TechCrunch's adjusted figure.

2. **Valuation**: Press release says $560M; TechCrunch says Series B was meant to close at $720M but repriced down.

3. **Burn and runway**: Blog says $4M/month burn vs $3.5M revenue → negative cash flow; memo says Series B gives 24+ months runway at current burn, then extends to 36+ months with restructuring.

4. **Customer concentration**: Blog says top 5 = ~38% of ARR; TechCrunch confirms loss of two top-5 customers; press release doesn't acknowledge concentration risk.

5. **International expansion**: Press release says "accelerate our expansion into international markets"; memo says "pause new hires in EMEA" and "defer international expansion to 2027".

6. **Layoffs**: Blog says 22 layoffs in Feb 2025 (~11% of 187); press release and memo don't mention.

7. **Pricing tier**: Blog and memo mention "Nimbus Lite" tier being sunset; press release doesn't mention.

8. **Credit facility**: Memo says $50M credit facility secured; SEC filing doesn't mention.

---

## Source reliability assessment

- **Press release (Source 1)**: Company narrative only. Best for basic facts (funding amount, valuation, ARR, employee count, customer count) but omits risks.
- **TechCrunch (Source 2)**: Journalistic reporting with anonymous sources. Best for customer churn, valuation repricing, and adjusted ARR. May understate or overstate but likely calibrated.
- **Former employee blog (Source 3)**: First-hand internal view. Good for burn rate, layoffs, customer concentration, compensation. May be biased but seems balanced.
- **Leaked memo (Source 4)**: Internal strategy document. Best for restructuring plans, credit facility, path to breakeven. May be optimistic but reflects real plans.
- **SEC Form D (Source 5)**: Legal filing. Best for confirming $84M raised, 7 investors, use of proceeds. Minimal narrative.

---

## Synthesis

**Positive signals:**
- Strong technical foundation (CTO quality, clean architecture)
- Real customer love and dependency (mid-market brands)
- Competitive compensation (suggests talent quality)
- $84M raised, $50M credit facility → 36+ months runway
- 3 new $1M+ ARR contracts signed in Q1 2026 (per CEO)
- Goal of cash-flow breakeven by Q4 2026

**Negative signals:**
- Two top-5 customers lost in late 2025 ($4.2M+ ARR)
- Adjusted ARR $36-37M (not $42M)
- Customer concentration (top 5 = ~38% of ARR)
- Layoffs in Feb 2025 (~11% of org)
- High burn ($4M/month) vs revenue (~$3.5M/month)
- International expansion deferred; Lite tier sunset
- Valuation repriced down from $720M to $560M

**Key metrics:**
- ARR: $36-37M run-rate (adjusted for churn)
- Burn: ~$4M/month
- Revenue: ~$3.5M/month
- Monthly loss: ~$0.5M
- Runway: 36+ months after restructuring
- Top 5 customers: ~38% of ARR

**Critical path to success:**
- Achieve cash-flow breakeven by Q4 2026
- Grow ARR from $36-37M to $50M+ by end of 2026
- Reduce customer concentration
- Execute on new sales (3 $1M+ contracts Q1; need more)

**Red flags:**
- Customer churn of two top-5 customers in same quarter
- Layoffs indicate operational missteps
- High burn relative to revenue
- International expansion scaled back significantly

**Green flags:**
- Strong engineering culture
- Real product-market fit with mid-market brands
- Secured $50M credit facility
- Founders credible (Patel and Wong)
- 1,400 customers (diversified base beyond top 5)
