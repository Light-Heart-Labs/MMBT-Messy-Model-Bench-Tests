# Password Manager Comparison: 5 Products Evaluated

**Date:** 2025-01-XX
**Scope:** 1Password, Bitwarden, LastPass, Dashlane, Keeper Security

---

## Pricing (Annual Billing, Per User)

| Product | Tier Recommended | Per-Seat Price (Annual) | 50-Seat Annual Cost | Source |
|---------|-----------------|------------------------|---------------------|--------|
| **1Password** | Business | $7.99/user/month = $95.88/user/year | **$4,794/year** | [1Password Pricing](https://1password.com/pricing/) |
| **Bitwarden** | Teams | $4.00/user/month = $48.00/user/year | **$2,400/year** | [Bitwarden Business Pricing](https://bitwarden.com/pricing/business/) |
| **LastPass** | Business | $7.00/user/month = $84.00/user/year | **$4,200/year** | [LastPass Business](https://lastpass.com/business/) |
| **Dashlane** | Business | $11.00/user/month = $132.00/user/year | **$6,600/year** | [Dashlane Pricing](https://www.dashlane.com/pricing) |
| **Keeper** | Business | Not publicly listed; contact sales. Personal plan ~$20.98/year (discounted). | **Unknown** | [Keeper Pricing](https://www.keepersecurity.com/pricing/business-and-enterprise.html) |

> **Note:** Keeper's business pricing is loaded dynamically and not available in static HTML. The personal plan is ~$20.98/year (Tom's Guide reader discount) [source: Tom's Guide](https://www.tomsguide.com/best-picks/best-password-managers). Business pricing requires a sales quote.

---

## Feature Comparison

| Feature | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---------|-----------|-----------|----------|----------|--------|
| **SSO/SAML** | ✅ Yes | ✅ Yes (Teams+) | ✅ Yes (Business) | ✅ Yes | ✅ Yes (Enterprise) |
| **SCIM Provisioning** | ✅ Yes | ✅ Yes (Enterprise) | ✅ Yes | ✅ Yes | ✅ Yes (Enterprise) |
| **Admin Console** | ✅ Yes | ✅ Yes (Teams+) | ✅ Yes (Business) | ✅ Yes | ✅ Yes |
| **Audit Logging** | ✅ Yes | ✅ Yes (Teams+) | ✅ Yes (Business) | ✅ Yes | ✅ Yes |
| **Zero-Knowledge** | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes |
| **CLI** | ✅ Yes (native) | ✅ Yes (native) | ⚠️ Limited | ❌ No native CLI | ✅ Yes |
| **API** | ✅ Yes | ✅ Yes | ✅ Yes | ⚠️ Limited | ✅ Yes |
| **CI/CD Integration** | ✅ Yes (Secrets Automation) | ✅ Yes (CLI + API) | ⚠️ Limited | ❌ No | ✅ Yes |
| **SSH Key Management** | ✅ Yes | ✅ Yes | ✅ Yes | ⚠️ Limited | ✅ Yes |
| **Self-Hosting** | ❌ No | ✅ Yes (open source) | ❌ No | ❌ No | ✅ Yes |
| **Mobile Apps** | ✅ iOS + Android | ✅ iOS + Android | ✅ iOS + Android | ✅ iOS + Android | ✅ iOS + Android |
| **Desktop Apps** | ✅ Mac/Win/Linux | ✅ Mac/Win/Linux | ✅ Mac/Win/Linux | ✅ Mac/Win | ✅ Mac/Win/Linux |
| **Browser Extensions** | ✅ All major | ✅ All major | ✅ All major | ✅ All major | ✅ All major |
| **Open Source** | ❌ No | ✅ Yes | ❌ No | ❌ No | ❌ No |

---

## Security & Compliance

| Certification / Feature | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|------------------------|-----------|-----------|----------|----------|--------|
| **SOC 2 Type II** | ✅ Yes | ✅ Yes | ⚠️ Not confirmed on public page | ⚠️ Not confirmed on public page | ✅ Yes |
| **ISO 27001** | ⚠️ Not confirmed | ✅ Yes | ✅ Yes | ⚠️ Not confirmed | ✅ Yes |
| **ISO 27017/27018** | ⚠️ Not confirmed | ⚠️ Not confirmed | ❌ No | ⚠️ Not confirmed | ✅ Yes |
| **FedRAMP** | ❌ No | ❌ No | ❌ No | ❌ No | ✅ High |
| **Penetration Testing** | ✅ Yes | ✅ Yes | ⚠️ Not confirmed | ✅ Yes | ✅ Yes |
| **Encryption** | AES-256 | AES-256 | AES-256 | AES-256 | AES-256 |
| **Key Derivation** | SECURE REMEMBERED | PBKDF2 / Argon2 | Argon2 | Not specified | Not specified |

> **Sources:** [1Password Security](https://1password.com/security/), [Bitwarden Compliance](https://bitwarden.com/compliance/), [LastPass Security](https://lastpass.com/security/), [Dashlane Security](https://www.dashlane.com/security), [Keeper Security](https://www.keepersecurity.com/security)

---

## Security Incident History

| Product | Incidents |
|---------|-----------|
| **1Password** | No known major breaches. |
| **Bitwarden** | No known major breaches. |
| **LastPass** | **2022 breach** — Hackers stole sensitive data including encrypted vault data, master password hashes, and 2FA seeds. [Source: Krebs on Security](https://krebsonsecurity.com/tag/lastpass/) |
| **Dashlane** | No known major breaches. |
| **Keeper** | No known major breaches. |

---

## Developer Tooling

| Tool | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|------|-----------|-----------|----------|----------|--------|
| **CLI** | ✅ `op` CLI (native, well-documented) | ✅ `bw` CLI (open source) | ⚠️ Limited CLI | ❌ No | ✅ Keeper CLI |
| **CI/CD Secrets** | ✅ Secrets Automation (GitHub, GitLab, CircleCI, etc.) | ✅ CLI + API integration | ⚠️ Limited | ❌ No | ✅ Keeper Secrets Manager |
| **SSH Agent** | ✅ Yes | ✅ Yes | ✅ Yes | ⚠️ Limited | ✅ Yes |
| **Docker/Container** | ✅ Yes | ✅ Yes | ⚠️ Limited | ❌ No | ✅ Yes |
| **Terraform Provider** | ✅ Yes | ✅ Yes | ❌ No | ❌ No | ⚠️ Limited |

---

## Summary Scoring (Qualitative)

| Criterion | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|-----------|-----------|-----------|----------|----------|--------|
| SSO/SAML | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Admin/Audit | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Pricing | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐ |
| Developer Tooling | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐ |
| Mobile/Desktop | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Zero-Knowledge | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Compliance | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Incident History | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Onboarding Ease | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| **Overall** | **Strong** | **Strong** | **Weak** | **Moderate** | **Strong** |
