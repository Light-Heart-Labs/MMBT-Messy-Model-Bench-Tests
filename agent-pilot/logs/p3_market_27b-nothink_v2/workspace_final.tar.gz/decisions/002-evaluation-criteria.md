# ADR-002: Evaluation Criteria

**Date:** 2025-01-XX
**Status:** Accepted

## Decision

The following criteria define "best for this team":

| # | Criterion | Weight | Rationale |
|---|-----------|--------|-----------|
| 1 | **SSO/SAML integration** | High | Team uses Google Workspace; SSO eliminates separate password manager login. |
| 2 | **Admin console & audit logging** | High | SOC 2 compliance requires audit trails of who accessed what and when. |
| 3 | **Pricing transparency & per-seat cost** | High | Series-B company needs predictable, budgetable costs. |
| 4 | **Developer tooling (CLI, API, CI/CD)** | High | Engineering team needs CLI for automation, SSH key management, secrets in CI/CD. |
| 5 | **Mobile + desktop + browser coverage** | Medium | Team works across macOS, Windows, Linux, iOS, Android. |
| 6 | **Security model (zero-knowledge)** | High | Vendor must not be able to read stored passwords. |
| 7 | **Compliance certifications (SOC 2, ISO 27001)** | Medium | Required for our own SOC 2 audit. |
| 8 | **Vendor lock-in / export capability** | Medium | Must be able to export data if we switch vendors. |
| 9 | **Security incident history** | High | Past breaches are a strong negative signal. |
| 10 | **Onboarding ease (90-day mandate)** | Medium | Must be deployable within the CTO's 90-day timeline. |

## Rationale

The team is engineering-heavy (50 people), so developer tooling and CLI support are weighted higher than they would be for a general business. The SOC 2 requirement for the SaaS company makes audit logging and compliance certifications essential. The 90-day mandate means onboarding friction is a real constraint.

## Alternatives Considered

- Equal weighting across all criteria — rejected because the team's engineering focus and compliance needs make some criteria more important.
- Adding "brand recognition" as a criterion — rejected because it's a proxy for other factors already measured.
