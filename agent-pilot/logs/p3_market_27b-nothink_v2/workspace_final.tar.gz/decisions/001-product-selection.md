# ADR-001: Product Selection Criteria

**Date:** 2025-01-XX
**Status:** Accepted
**Context:** 50-person engineering team at a Series-B SaaS company needs to standardize on a password manager within 90 days.

## Decision

Evaluate 5 password managers: 1Password, Bitwarden, LastPass, Dashlane, and Keeper Security.

## Rationale

These 5 products represent the most widely-adopted enterprise password managers in the market:

1. **1Password** — Market leader in UX and developer tooling; strong brand recognition.
2. **Bitwarden** — Open-source, lowest pricing, self-hosting option.
3. **LastPass** — Long-standing market presence; notable for 2022 security breach.
4. **Dashlane** — Strong zero-knowledge architecture; premium positioning.
5. **Keeper Security** — Most comprehensive compliance certifications (FedRAMP High, SOC 2, ISO 27001/27017/27018).

Products excluded from evaluation:
- **KeePass** — No cloud sync, no admin console, not suitable for team deployment.
- **NordPass** — Primarily consumer-focused; limited enterprise features.
- **Google Password Manager / Apple Passwords** — Ecosystem-locked; no cross-platform admin.
- **HashiCorp Vault / AWS Secrets Manager** — Secrets management infrastructure, not password managers for human use.

## Alternatives Considered

- Evaluating only 3 products (narrower scope) — rejected because the market has clear top-5 contenders.
- Including SSO products (Okta, Azure AD) — rejected because SSO is adjacent but not a password manager.
