# Password Manager Recommendation: 1Password Business

**To:** CTO & Engineering Leadership
**From:** Security Advisory
**Date:** 2025-01-XX
**Subject:** Standardize on 1Password Business for the 50-person engineering team

---

## Executive Summary

After evaluating 5 enterprise password managers — **1Password, Bitwarden, LastPass, Dashlane, and Keeper Security** — we recommend **1Password Business** as the standard password manager for our engineering team.

**Recommended product:** 1Password Business
**Per-seat cost:** $7.99/user/month (billed annually) = $95.88/user/year
**50-seat annual cost:** **$4,794/year** ($95.88 × 50)
**Runner-up:** Bitwarden Teams at $48.00/user/year ($2,400/year for 50 seats)

---

## Decision Criteria

We defined "best for this team" using 10 criteria, weighted by relevance to our context (50-person engineering team, Series-B SaaS, SOC 2 compliance, 90-day deployment mandate):

| # | Criterion | Weight | Why It Matters |
|---|-----------|--------|----------------|
| 1 | SSO/SAML integration | High | Eliminates separate login; integrates with Google Workspace |
| 2 | Admin console & audit logging | High | Required for SOC 2 compliance; tracks who accessed what |
| 3 | Pricing transparency | High | Predictable budgeting for a Series-B company |
| 4 | Developer tooling (CLI, API, CI/CD) | High | Engineering team needs automation, SSH keys, secrets in CI/CD |
| 5 | Mobile + desktop + browser coverage | Medium | Team works across macOS, Windows, Linux, iOS, Android |
| 6 | Zero-knowledge architecture | High | Vendor must not be able to read stored passwords |
| 7 | Compliance certifications | Medium | SOC 2, ISO 27001 required for our own audit |
| 8 | Vendor lock-in / export | Medium | Must be able to leave if needed |
| 9 | Security incident history | High | Past breaches are a strong negative signal |
| 10 | Onboarding ease | Medium | Must deploy within 90 days |

---

## Recommendation: 1Password Business

### Why 1Password Wins

**1. Best-in-class developer tooling.** 1Password's `op` CLI is the most mature and well-documented in the industry. It has native integrations with GitHub, GitLab, CircleCI, Terraform, and Docker. For an engineering team, this is the single biggest differentiator — developers can manage SSH keys, inject secrets into CI/CD pipelines, and automate credential rotation without leaving their workflow. [Source: 1Password Business page](https://1password.com/business/)

**2. SOC 2 Type II certified.** 1Password is SOC 2 Type 2 certified, which directly supports our own SOC 2 compliance efforts. The admin console provides detailed audit logs of all user activity, which is required for our audit. [Source: 1Password Security page](https://1password.com/security/)

**3. Zero-knowledge architecture.** 1Password uses a zero-knowledge model — they cannot read our stored passwords. All data is encrypted client-side before being transmitted. [Source: 1Password Security page](https://1password.com/security/)

**4. SSO/SAML integration.** 1Password Business includes SSO/SAML support, enabling single sign-on with our Google Workspace. This eliminates the need for a separate password manager login. [Source: 1Password Business page](https://1password.com/business/)

**5. No known security breaches.** Unlike LastPass (which suffered a major breach in 2022), 1Password has no known major security incidents. [Source: Krebs on Security](https://krebsonsecurity.com/tag/1password/)

**6. Cross-platform coverage.** Native apps for macOS, Windows, Linux, iOS, Android, and all major browsers. The team's diverse OS usage is fully covered. [Source: 1Password Downloads](https://1password.com/downloads/)

### Pricing Breakdown

| Item | Cost |
|------|------|
| Per-seat price (annual billing) | $7.99/user/month |
| Per-seat annual cost | $95.88/user/year |
| 50 seats annual cost | **$4,794/year** |
| Monthly equivalent | $399.50/month |

**Source:** [1Password Pricing](https://1password.com/pricing/) — Business tier at $7.99/user/month when billed annually.

---

## Runner-Up: Bitwarden Teams

**Bitwarden Teams** at $4.00/user/month ($48.00/user/year, $2,400/year for 50 seats) is the clear runner-up and would beat 1Password under these conditions:

1. **Budget is the primary constraint.** Bitwarden is 50% cheaper than 1Password ($2,400 vs. $4,794/year for 50 seats).
2. **Open-source / self-hosting is required.** Bitwarden is fully open-source and can be self-hosted, which matters if data sovereignty or air-gapping is a concern. [Source: Bitwarden Compliance](https://bitwarden.com/compliance/)
3. **The team is comfortable with slightly less polished tooling.** Bitwarden's CLI (`bw`) is capable but less polished than 1Password's `op` CLI. The admin console is functional but less intuitive.

**Why Bitwarden didn't win:** While the price difference is significant ($2,394/year savings), 1Password's superior developer experience, more polished admin console, and more mature CI/CD integrations provide better value for an engineering team where developer productivity directly impacts revenue.

---

## Products Not Recommended

### LastPass Business ($84.00/user/year)
**Not recommended due to the 2022 security breach.** In September 2022, LastPass suffered a major breach where hackers stole encrypted vault data, master password hashes, and 2FA seeds. While the data was encrypted, the breach exposed sensitive infrastructure details and raised concerns about the company's security posture. [Source: Krebs on Security](https://krebsonsecurity.com/tag/lastpass/) For a SaaS company pursuing SOC 2 compliance, choosing a vendor with a recent major breach is an unnecessary risk.

### Dashlane Business ($132.00/user/year)
**Not recommended due to highest price and weakest developer tooling.** Dashlane is the most expensive option at $132/user/year and lacks a native CLI, making it a poor fit for an engineering team. Its zero-knowledge architecture is strong, but the price-to-value ratio is unfavorable. [Source: Dashlane Pricing](https://www.dashlane.com/pricing)

### Keeper Security Business (pricing not publicly listed)
**Not recommended due to pricing opacity.** Keeper has the strongest compliance certifications (SOC 2, ISO 27001/27017/27018, FedRAMP High), but its business pricing is not publicly listed and requires a sales quote. For a Series-B company that needs transparent, budgetable costs, this is a disqualifying factor. [Source: Keeper Pricing](https://www.keepersecurity.com/pricing/business-and-enterprise.html)

---

## Concerns & Risks with 1Password

### 1. Vendor Lock-In
1Password uses a proprietary vault format. While data can be exported (CSV, 1Password format), migrating to another vendor would require re-importing all data. **Mitigation:** 1Password supports standard export formats, and the cost of migration is manageable.

### 2. No Self-Hosting Option
Unlike Bitwarden, 1Password is cloud-only. If data sovereignty or air-gapping becomes a requirement, 1Password cannot be self-hosted. **Mitigation:** This is unlikely to be a concern for a Series-B SaaS company, but should be noted for future planning.

### 3. No FedRAMP Certification
1Password is not FedRAMP certified. If the company pursues government contracts requiring FedRAMP, Keeper Security would be a better choice. **Mitigation:** SOC 2 Type II certification covers most commercial compliance needs.

### 4. Price Increase Risk
As a private company, 1Password could raise prices with limited notice. **Mitigation:** Annual billing locks in the current rate for 12 months. The company should monitor pricing changes at renewal time.

### 5. No Open-Source Code
1Password's codebase is closed-source. Unlike Bitwarden, there is no community audit of the code. **Mitigation:** 1Password undergoes regular third-party penetration testing and is SOC 2 Type II certified, which provides independent verification of security controls. [Source: 1Password Security](https://1password.com/security/)

---

## Implementation Plan (90-Day Timeline)

| Week | Activity |
|------|----------|
| Weeks 1-2 | Procure 1Password Business licenses; configure SSO with Google Workspace |
| Weeks 3-4 | Set up admin console; define sharing policies; create team vaults |
| Weeks 5-6 | Roll out to engineering team; provide training session |
| Weeks 7-8 | Migrate credentials from shadow IT (browser, Slack, sticky notes) |
| Weeks 9-10 | Configure CI/CD integrations (GitHub, Terraform, etc.) |
| Weeks 11-12 | Audit migration completeness; decommission shadow IT stores |

---

## Sources

1. [1Password Pricing](https://1password.com/pricing/) — Business tier: $7.99/user/month (annual), $9.99/user/month (monthly)
2. [1Password Business](https://1password.com/business/) — SSO, CLI, API, GitHub integration features
3. [1Password Security](https://1password.com/security/) — SOC 2 Type II, zero-knowledge, encryption details
4. [Bitwarden Business Pricing](https://bitwarden.com/pricing/business/) — Teams: $4/user/month, Enterprise: $6/user/month
5. [Bitwarden Compliance](https://bitwarden.com/compliance/) — SOC 2, ISO 27001, penetration testing, open source
6. [LastPass Business](https://lastpass.com/business/) — Business: $7/user/month
7. [LastPass Security](https://lastpass.com/security/) — ISO 27001, zero-knowledge, AES-256
8. [Krebs on Security — LastPass](https://krebsonsecurity.com/tag/lastpass/) — 2022 breach coverage
9. [Dashlane Pricing](https://www.dashlane.com/pricing) — Business: $11/user/month
10. [Dashlane Security](https://www.dashlane.com/security) — Zero-knowledge, penetration testing
11. [Keeper Pricing](https://www.keepersecurity.com/pricing/business-and-enterprise.html) — Pricing loaded dynamically; not publicly listed
12. [Keeper Security](https://www.keepersecurity.com/security) — SOC 2, FedRAMP High, ISO 27001/27017/27018
13. [Tom's Guide — Best Password Managers](https://www.tomsguide.com/best-picks/best-password-managers) — Keeper personal: $20.98/year (discounted)
14. [CNET — Best Password Manager](https://www.cnet.com/tech/services-and-software/best-password-manager/) — Individual pricing: 1Password $36/yr, Bitwarden $10/yr, Dashlane $60/yr
