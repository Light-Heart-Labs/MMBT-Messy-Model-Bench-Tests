# Research Notes — Password Manager Evaluation

## Context
- 50-person engineering team, Series-B SaaS company
- Current state: shadow IT (browser, sticky notes, Slack DMs)
- CTO mandate: fix within 90 days
- Need: team-wide standardization on a single password manager

## Research Methodology
- Fetched vendor pricing pages, security pages, compliance pages
- Cross-referenced with third-party comparison articles (Tom's Guide, CNET)
- Checked Krebs on Security for breach history
- Extracted pricing from HTML/JSON where available; flagged dynamic pricing

## Key Findings

### Pricing Summary (Annual, Per User)
| Product | Tier | Price | 50-Seat Annual |
|---------|------|-------|----------------|
| 1Password | Business | $7.99/user/month | $4,794 |
| Bitwarden | Teams | $4.00/user/month | $2,400 |
| LastPass | Business | $7.00/user/month | $4,200 |
| Dashlane | Business | $11.00/user/month | $6,600 |
| Keeper | Business | Not publicly listed | Unknown |

### Security Incidents
- **LastPass:** 2022 breach — encrypted vault data, master password hashes, 2FA seeds stolen
- **1Password, Bitwarden, Dashlane, Keeper:** No known major breaches

### Compliance
- **1Password:** SOC 2 Type II
- **Bitwarden:** SOC 2, ISO 27001, penetration testing, open source
- **LastPass:** ISO 27001 (no SOC 2 confirmed)
- **Dashlane:** Zero-knowledge, penetration testing (no SOC 2 confirmed on public pages)
- **Keeper:** SOC 2, FedRAMP High, ISO 27001/27017/27018

### Developer Tooling
- **1Password:** Best-in-class CLI (`op`), native CI/CD integrations, SSH agent, Terraform provider
- **Bitwarden:** Strong CLI (`bw`), open source, self-hostable
- **LastPass:** Limited CLI, limited CI/CD
- **Dashlane:** No native CLI
- **Keeper:** CLI available, Secrets Manager product

## Challenges Encountered
1. **Dynamic pricing:** LastPass, Dashlane, and Keeper load pricing via JavaScript, making static extraction difficult.
2. **Third-party access:** G2, Capterra, SoftwareAdvice all returned 403 Forbidden.
3. **Keeper pricing:** Entirely dynamic; no static prices found in HTML or JS bundles.
4. **Dashlane compliance:** No SOC 2 or ISO certification mentioned on public security page; trust center uses Vanta (JS-rendered).

## Decision
**Recommended:** 1Password Business ($4,794/year for 50 seats)
**Runner-up:** Bitwarden Teams ($2,400/year for 50 seats)

1Password wins on developer tooling, admin UX, and overall polish. Bitwarden wins on price and open-source/self-hosting.
