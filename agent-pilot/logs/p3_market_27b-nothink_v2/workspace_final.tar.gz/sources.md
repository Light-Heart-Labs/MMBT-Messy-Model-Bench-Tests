# Sources

All URLs fetched during research, with timestamps and descriptions.

## 1Password

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 1 | https://1password.com/pricing/ | 2025-01-XX | Pricing page. Extracted: Business $7.99/user/month (annual), $9.99/user/month (monthly); Enterprise $9.99/user/month (annual), $11.99/user/month (monthly); Small Teams $19.95/month for up to 10 users (annual). |
| 2 | https://1password.com/business/ | 2025-01-XX | Business features page. Confirmed: SSO/SAML, CLI, API, GitHub integration, secrets management, audit logging. |
| 3 | https://1password.com/security/ | 2025-01-XX | Security page. Confirmed: SOC 2 Type II certified, zero-knowledge architecture, AES-256 encryption, regular penetration testing. |
| 4 | https://1password.com/trust/ | 2025-01-XX | Trust page (404 — redirects). SOC 2 and compliance info found on security page instead. |

## Bitwarden

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 5 | https://bitwarden.com/pricing/ | 2025-01-XX | Consumer pricing page. Confirmed: Free ($0), Premium ($1.65/user/month), Families ($3.99/month for up to 6 users). |
| 6 | https://bitwarden.com/pricing/business/ | 2025-01-XX | Business pricing page. Confirmed: Teams $4/user/month (billed annually at $48/user/year), Enterprise $6/user/month (billed annually at $72/user/year). SSO, SCIM, audit log, admin console features confirmed. |
| 7 | https://bitwarden.com/compliance/ | 2025-01-XX | Compliance page. Confirmed: SOC 2, ISO 27001, penetration testing, zero-knowledge, PBKDF2/Argon2 key derivation, open source. |
| 8 | https://bitwarden.com/help/article/security/ | 2025-01-XX | Security help article. Confirmed: encryption details, open source architecture. |

## LastPass

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 9 | https://lastpass.com/pricing/ | 2025-01-XX | Pricing page. Plans found: Premium, Families, Teams, Business. Pricing loaded dynamically; no static prices in HTML. |
| 10 | https://lastpass.com/business/ | 2025-01-XX | Business page. Confirmed: Business at $7/user/month. SSO, admin console, zero-knowledge, encryption features. |
| 11 | https://lastpass.com/security/ | 2025-01-XX | Security page. Confirmed: ISO 27001, zero-knowledge, AES-256 encryption. No SOC 2 mention found. |
| 12 | https://krebsonsecurity.com/tag/lastpass/ | 2025-01-XX | Krebs on Security LastPass tag page. Confirmed: 2022 breach coverage, articles about cracked keys from stolen data. |

## Dashlane

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 13 | https://www.dashlane.com/pricing | 2025-01-XX | Pricing page. Confirmed: Business at $11/user/month (from JSON data). Personal and Enterprise plans also listed. |
| 14 | https://www.dashlane.com/business | 2025-01-XX | Business page. Confirmed: SSO/SAML, SCIM, audit logging, admin console, zero-knowledge, encryption. |
| 15 | https://www.dashlane.com/security | 2025-01-XX | Security page. Confirmed: zero-knowledge architecture, penetration testing, encryption. No SOC 2 or ISO certification mentioned on this page. |
| 16 | https://trust.dashlane.com/ | 2025-01-XX | Trust center (Vanta-hosted). Small page; zero-knowledge mentioned. Full compliance details not accessible without JS rendering. |

## Keeper Security

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 17 | https://www.keepersecurity.com/pricing/business-and-enterprise.html | 2025-01-XX | Business & Enterprise pricing page. Pricing loaded dynamically via JavaScript; no static prices in HTML. Plans: Business Starter, Business, Enterprise. |
| 18 | https://www.keepersecurity.com/security | 2025-01-XX | Security page. Confirmed: SOC 2, FedRAMP High, ISO 27001/27017/27018, penetration testing, zero-knowledge, encryption. |
| 19 | https://www.keepersecurity.com/ | 2025-01-XX | Main page. Confirmed: SOC 2, FedRAMP, ISO 27001 certifications. |

## Third-Party Sources

| # | URL | Timestamp (UTC) | Description |
|---|-----|-----------------|-------------|
| 20 | https://www.tomsguide.com/best-picks/best-password-managers | 2025-01-XX | Comparison article. Confirmed: Keeper personal ~$20.98/year (discounted), Bitwarden Premium $10/year, Bitwarden Family $40/year. |
| 21 | https://www.cnet.com/tech/services-and-software/best-password-manager/ | 2025-01-XX | Comparison article. Confirmed: 1Password $36/year (individual), Bitwarden $10/year (individual), Dashlane $60/year (individual), NordPass $35/year (individual). |
| 22 | https://krebsonsecurity.com/tag/1password/ | 2025-01-XX | Krebs on Security 1Password tag page. No breach articles found; references to LastPass breach in context. |
| 23 | https://krebsonsecurity.com/tag/bitwarden/ | 2025-01-XX | Krebs on Security Bitwarden tag page. No breach articles found. |
| 24 | https://krebsonsecurity.com/tag/dashlane/ | 2025-01-XX | Krebs on Security Dashlane tag page. No breach articles found. |

## Sources That Could Not Be Accessed

| URL | Reason |
|-----|--------|
| https://www.g2.com/products/bitwarden-vs-1password | HTTP 403 Forbidden |
| https://www.capterra.com/password-management-software/ | HTTP 403 Forbidden |
| https://www.softwareadvice.com/password-management/keeper-security-profile/ | HTTP 403 Forbidden |
| https://www.trustradius.com/products/keeper-security/reviews | HTTP 403 Forbidden |
| https://blog.lastpass.com/ | Empty response / inaccessible |
| https://www.pcmag.com/picks/best-password-manager | HTTP 404 Not Found |
| https://www.wired.com/review/best-password-manager/ | Empty response |
| https://www.makeuseof.com/best-password-managers/ | Empty response |
| https://www.lifewire.com/best-password-managers-4868186 | Empty response |
