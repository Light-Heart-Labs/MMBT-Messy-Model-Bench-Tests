# Password Manager Evaluation for 50-Person Engineering Team

This repository contains the research and recommendation for a standardized password manager for a 50-person SaaS engineering team.

## Output Files

- **`recommendation.md`** - The primary 1-2 page recommendation memo with decision criteria, final choice, pricing, and risks.
- **`comparison.md`** - Side-by-side comparison of the 5 evaluated password managers across features, pricing, and security.
- **`sources.md`** - Complete list of all URLs consulted, with timestamps and descriptions.
- **`research/notes.md`** - Working notes and initial research.
- **`decisions/`** - ADR-style records for key decisions (e.g., selection of 5 products, criteria weighting).

## How to Read This Output

1. Start with `recommendation.md` for the executive summary and final recommendation.
2. Review `comparison.md` to understand how the chosen product stacks up against alternatives.
3. Check `sources.md` to verify all claims and see the raw data sources.
4. Refer to `research/notes.md` and `decisions/` for the research process and decision rationale.

## Methodology

- Evaluated 5 distinct password managers (not adjacent products like SSO or secrets management).
- Criteria included: SSO integration, audit logging, SOC2 compliance, per-seat pricing, admin UX, mobile/desktop coverage, and developer tool integrations.
- All factual claims are cited with public sources.
- Pricing calculations are based on 50 seats annual billing where available.
