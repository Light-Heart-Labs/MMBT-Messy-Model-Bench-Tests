# Investment Memo Repository

## Overview
This repository contains a complete investment analysis of a publicly traded US company with a market cap between $1B and $10B.

## How to Navigate

1. **Start with `/memo/`** - The final investment memo (PDF + source markdown)
2. **Review `/decisions/`** - ADR-style decision records explaining key analytical choices
3. **Check `/research/questions.md`** - Running log of questions and resolutions
4. **Examine `/model/`** - Three-statement financial model (xlsx)
5. **Trace numbers** - Every number in the memo traces back through:
   - `/raw/filings/` → Original SEC filings
   - `/extracted/` → Parsed/cleaned data with extraction scripts
   - `/model/` → Financial model cells
   - `/memo/` → Final memo claims
6. **Review `/analysis/`** - Notebooks and scripts for analysis
7. **Check `/research/dead-ends.md`** - Investigated paths that didn't pan out
8. **See `/sources.md`** - Every URL fetched with timestamp and SHA
9. **See `/tool-log.md`** - Every tool call with justification

## Company Selection
Company selection rationale documented in `/decisions/001-company-selection.md`

## Repo Structure
```
/memo/                  Final memo (PDF + source markdown)
/model/                 Three-statement financial model (xlsx)
/raw/
  /filings/             SEC filings, original format
  /transcripts/         Earnings call transcripts
  /other/               Press releases, etc.
/extracted/             Parsed/cleaned data + extraction scripts
/analysis/              Notebooks and analysis scripts
/research/
  /notes/               Working notes, dated
  /questions.md         Questions and resolutions
  /dead-ends.md         Dead ends with explanations
/decisions/             ADR-style decision records
/sources.md             URLs with timestamps and SHAs
/tool-log.md            Tool call log
README.md               This file
```
