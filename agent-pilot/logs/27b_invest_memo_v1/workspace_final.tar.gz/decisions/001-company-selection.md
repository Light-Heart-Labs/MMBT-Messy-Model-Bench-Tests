# ADR-001: Company Selection

## Status
Accepted

## Date
2025-01-15

## Context
Need to select a publicly traded US company with market cap between $1B and $10B for investment memo analysis.

## Alternatives Considered
- **C3.ai (AI)** - $1.26B: AI software company, but highly speculative with minimal revenue relative to valuation
- **Asana (ASAN)** - $1.52B: Productivity software, but slow growth and competitive market
- **Appian (APPN)** - $1.65B: Low-code platform, but niche market with limited growth visibility
- **Upstart (UPST)** - $3.21B: AI lending, but highly cyclical and regulatory risk
- **CarGurus (CARG)** - $3.39B: Auto marketplace, but mature/slow growth
- **GitLab (GTLB)** - $3.66B: DevOps platform, but high valuation multiple
- **BILL (BILL)** - $3.68B: Financial automation, but competitive and slowing growth
- **SentinelOne (S)** - $4.85B: Cybersecurity, but still unprofitable
- **Opendoor (OPEN)** - $5.28B: Real tech, but highly cyclical and unprofitable
- **UiPath (PATH)** - $5.43B: RPA leader, but growth has slowed significantly
- **Hims & Hers (HIMS)** - $6.97B: Telehealth/digital health platform
- **Celsius (CELH)** - $8.89B: Beverage company, but growth may be peaking
- **Snap (SNAP)** - $9.54B: Social media, but unprofitable and competitive
- **Instacart (CART)** - $9.98B: Grocery delivery, but margin pressure

## Decision
Selected **Hims & Hers Health, Inc. (HIMS)** for the following reasons:

1. **Market Cap**: ~$7B, squarely in the target range
2. **Growth Story**: Transitioning from pure telehealth to a broader digital health platform with DTC products
3. **Profitability**: Recently achieved GAAP profitability, making financial modeling more tractable
4. **Data Availability**: Public company with SEC filings, earnings calls, and analyst coverage
5. **Interesting Dynamics**: Regulatory risk (FDA, telehealth), competitive positioning, margin expansion potential
6. **Non-Consensus Opportunity**: Potential for mispricing around growth sustainability and margin trajectory

## Consequences
- Will need to analyze telehealth regulatory environment
- Must model both prescription and DTC product lines
- Need to assess competitive threats from incumbents and new entrants
