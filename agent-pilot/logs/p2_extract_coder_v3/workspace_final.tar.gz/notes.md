# Extraction Notes

## Summary
Extracted 20 fields from Veridyne Networks, Inc. Q3 FY2026 earnings press release dated March 18, 2026.

## Field-by-Field Notes

- **company_name**: Used "Veridyne Networks, Inc." as it appears in the header.
- **ticker_symbol**: Extracted "NASDAQ: VRDN" from the header.
- **fiscal_period**: Extracted "Q3 2026" (matches "fiscal third quarter 2026" variant).
- **fiscal_period_end_date**: Extracted "2026-02-28" (ISO 8601 from "February 28, 2026").
- **total_revenue_usd_millions**: Extracted `187.4` (from "$187.4 million").
- **revenue_yoy_growth_pct**: Extracted `38` (from "up 38% year-over-year").
- **subscription_revenue_usd_millions**: Extracted `171.2` (from "$171.2 million").
- **gaap_gross_margin_pct**: Extracted `76.3` (from "GAAP gross margin of 76.3%").
- **non_gaap_operating_income_usd_millions**: Extracted `9.8` (from "$9.8 million").
- **total_customers**: Extracted `4117` (from "Total customers grew to 4,117").
- **customers_above_100k_arr**: Extracted `1082` (from "customers contributing more than $100,000 in ARR grew to 1,082").
- **customers_above_1m_arr**: Extracted `71` (from "customers contributing more than $1 million in ARR grew to 71").
- **net_dollar_retention_pct**: Extracted `124` (from "Net dollar retention rate of 124%").
- **total_arr_usd_millions**: Extracted `710` (from "Total ARR exceeded $710 million"; see ADR002).
- **fte_count_end_of_q3**: Extracted `1847` (from "ended the quarter with 1,847 full-time employees"; see ADR003).
- **stitchwise_acquisition_total_consideration_usd_millions**: Extracted `115` (from "approximately $115 million"; see ADR001).
- **stitchwise_close_date**: Extracted "2026-01-22" (from "closed... on January 22, 2026").
- **fy2026_revenue_guidance_low_usd_millions**: Extracted `722` (from "$722-$726 million").
- **fy2026_revenue_guidance_high_usd_millions**: Extracted `726` (from "$722-$726 million").
- **share_repurchase_authorization_usd_millions**: Extracted `200` (from "up to $200 million").

## Uncertain Fields
None — all 20 fields were present in the press release.

## ADRs
- `adr001_stitchwise_consideration.md`: Rationale for Stitchwise consideration value.
- `adr002_total_arr.md`: Rationale for Total ARR value.
- `adr003_fte_count.md`: Rationale for FTE count.
- `adr004_non_gaap_operating_income.md`: Rationale for non-GAAP operating income.
