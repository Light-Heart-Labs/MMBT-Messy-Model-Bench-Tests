# ADR: Non-GAAP Operating Income Extraction

## Decision
Extract `non_gaap_operating_income_usd_millions` as `9.8`.

## Rationale
The press release states: "Non-GAAP operating income of $9.8 million, compared to a non-GAAP operating loss of $4.1 million in Q3 FY2025." This is a direct match for the field name and units (USD millions).

## Notes
- The schema notes a "wider tolerance" due to possible rounding variations, but the press release gives a precise figure.
- We use `9.8`, not `9.8 million`, per JSON number requirement.
