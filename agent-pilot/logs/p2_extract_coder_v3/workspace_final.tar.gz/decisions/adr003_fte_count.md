# ADR: FTE Count Extraction

## Decision
Extract `fte_count_end_of_q3` as `1847`.

## Rationale
The press release states: "The Company ended the quarter with 1,847 full-time employees..." This is a direct integer value for the end of Q3 (February 28, 2026).

## Notes
- The sequential increase (14.6%) is additional context but not needed for extraction.
- The schema asks for `fte_count_end_of_q3`, which matches this statement exactly.
