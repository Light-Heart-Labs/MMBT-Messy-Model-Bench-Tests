# ADR: Stitchwise Acquisition Consideration

## Decision
Extract `stitchwise_acquisition_total_consideration_usd_millions` as `115`.

## Rationale
The press release states: "Total consideration was approximately $115 million, comprised of $87 million in cash and 1.4 million shares of common stock." While the breakdown ($87M + shares) is provided, the document explicitly gives the total as "approximately $115 million". Per instructions, we defer to the document's own statement and extract `115`.

## Notes
- The share count (1.4 million) is not convertible to USD millions without a share price, so we rely on the stated total.
- "Approximately" is acceptable per schema notes.
