# ADR: Total ARR Extraction

## Decision
Extract `total_arr_usd_millions` as `710`.

## Rationale
The press release states: "Total ARR exceeded $710 million as of quarter-end." The schema notes accept "710 or any value labeled 'over 710' / '>$710M'". Since the press release says "exceeded $710 million", we extract `710` as the lower bound figure explicitly mentioned.

## Notes
- We do not round up or infer a higher value (e.g., 711) because the press release does not provide a specific number beyond "exceeded $710 million".
