"""Tests for utils.py — date parsing, byte formatting, legacy formatter, chunking.

Exercises all utility functions with edge cases: boundary values for
format_bytes, invalid dates for parse_iso_date, empty sequences for chunked,
and the legacy format_legacy function.
"""
from datetime import datetime, timezone

from logalyzer.utils import (
    parse_iso_date,
    format_bytes,
    format_legacy,
    chunked,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── parse_iso_date ──────────────────────────────────────────────────────────

def test_parse_iso_date_valid():
    """Valid YYYY-MM-DD string should parse to UTC midnight."""
    result = parse_iso_date("2026-01-15")
    assert result == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_leap_year():
    """Leap year date should parse correctly."""
    result = parse_iso_date("2024-02-29")
    assert result == datetime(2024, 2, 29, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_first_of_month():
    """First day of a month should parse correctly."""
    result = parse_iso_date("2026-03-01")
    assert result.day == 1
    assert result.month == 3


def test_parse_iso_date_last_of_year():
    """Last day of a year should parse correctly."""
    result = parse_iso_date("2025-12-31")
    assert result == datetime(2025, 12, 31, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_invalid_format_raises():
    """Invalid date format should raise ValueError."""
    try:
        parse_iso_date("01-15-2026")  # MM-DD-YYYY instead of YYYY-MM-DD
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_invalid_date_raises():
    """Invalid date (e.g., Feb 30) should raise ValueError."""
    try:
        parse_iso_date("2026-02-30")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_empty_string_raises():
    """Empty string should raise ValueError."""
    try:
        parse_iso_date("")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_returns_utc():
    """parse_iso_date should always return a UTC datetime."""
    result = parse_iso_date("2026-06-15")
    assert result.tzinfo is timezone.utc


# ── format_bytes ────────────────────────────────────────────────────────────

def test_format_bytes_zero():
    """Zero bytes should format as '0.0 B'."""
    assert format_bytes(0) == "0.0 B"


def test_format_bytes_small():
    """Small byte values should stay in B."""
    assert format_bytes(1) == "1.0 B"
    assert format_bytes(500) == "500.0 B"


def test_format_bytes_just_under_kb():
    """1023 bytes should still be in B (not KB)."""
    assert format_bytes(1023) == "1023.0 B"


def test_format_bytes_exactly_1kb():
    """1024 bytes should format as 1.0 KB."""
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_just_over_1kb():
    """1025 bytes should format as ~1.0 KB."""
    result = format_bytes(1025)
    assert "KB" in result


def test_format_bytes_1mb():
    """1 MB (1048576 bytes) should format as 1.0 MB."""
    assert format_bytes(1048576) == "1.0 MB"


def test_format_bytes_1gb():
    """1 GB should format as 1.0 GB."""
    assert format_bytes(1073741824) == "1.0 GB"


def test_format_bytes_1tb():
    """1 TB should format as 1.0 TB."""
    assert format_bytes(1099511627776) == "1.0 TB"


def test_format_bytes_fractional_kb():
    """1536 bytes (1.5 KB) should format as 1.5 KB."""
    assert format_bytes(1536) == "1.5 KB"


def test_format_bytes_large_value():
    """Very large values should reach TB or beyond."""
    result = format_bytes(1099511627776 * 2)  # 2 TB
    assert "TB" in result


# ── format_legacy ───────────────────────────────────────────────────────────

def test_format_legacy_basic():
    """format_legacy should produce pipe-separated output."""
    entry = _entry()
    result = format_legacy(entry)
    assert "10.0.0.1" in result
    assert "200" in result
    assert "/" in result
    assert "|" in result


def test_format_legacy_format():
    """format_legacy should follow the format: ip | timestamp | status | url."""
    entry = _entry(ip="1.2.3.4", status=404, url="/admin")
    result = format_legacy(entry)
    parts = [p.strip() for p in result.split("|")]
    assert parts[0] == "1.2.3.4"
    assert parts[2] == "404"
    assert parts[3] == "/admin"


def test_format_legacy_timestamp_iso():
    """format_legacy should include the ISO timestamp."""
    entry = _entry()
    result = format_legacy(entry)
    assert "2026-01-01 12:00:00" in result


# ── chunked ─────────────────────────────────────────────────────────────────

def test_chunked_empty_sequence():
    """chunked with an empty sequence should yield nothing."""
    result = list(chunked([], 3))
    assert result == []


def test_chunked_exact_fit():
    """When sequence length is exactly divisible by chunk size."""
    result = list(chunked([1, 2, 3, 4, 5, 6], 3))
    assert result == [[1, 2, 3], [4, 5, 6]]


def test_chunked_remainder():
    """When sequence length is not divisible by chunk size, last chunk is smaller."""
    result = list(chunked([1, 2, 3, 4, 5], 3))
    assert result == [[1, 2, 3], [4, 5]]


def test_chunked_single_element():
    """A single element should produce one chunk."""
    result = list(chunked([42], 3))
    assert result == [[42]]


def test_chunked_chunk_size_one():
    """Chunk size of 1 should produce one-element chunks."""
    result = list(chunked([1, 2, 3], 1))
    assert result == [[1], [2], [3]]


def test_chunked_chunk_size_larger_than_sequence():
    """Chunk size larger than sequence should produce one chunk."""
    result = list(chunked([1, 2], 10))
    assert result == [[1, 2]]


def test_chunked_with_strings():
    """chunked should work with any iterable, not just numbers."""
    result = list(chunked(["a", "b", "c", "d"], 2))
    assert result == [["a", "b"], ["c", "d"]]


def test_chunked_is_generator():
    """chunked should return a generator."""
    result = chunked([1, 2, 3], 2)
    assert hasattr(result, "__iter__")
    assert hasattr(result, "__next__")


def test_format_bytes_petabyte():
    """Values exceeding TB should reach PB."""
    # 1 PB = 1024^5 bytes
    result = format_bytes(1125899906842624)
    assert "PB" in result
    assert result == "1.0 PB"


def test_format_bytes_multi_petabyte():
    """Very large values should still format as PB."""
    result = format_bytes(1125899906842624 * 10)
    assert "PB" in result
