"""Tests for io.py — file loading helpers.

Exercises load() and load_iter() with various file conditions:
empty files, files without trailing newlines, mixed valid/invalid lines,
and large files.
"""
import os
import tempfile

from logalyzer.io import load, load_iter
from logalyzer.parser import LogEntry


# A valid CLF log line
VALID_LINE = (
    '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] '
    '"GET /apache_pb.gif HTTP/1.0" 200 2326'
)

INVALID_LINE = "this is not a valid log line"


def test_load_empty_file():
    """Loading an empty file should return an empty list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("")
        path = f.name
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_single_valid_line_with_newline():
    """A file with one valid line and a trailing newline."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 1
        assert isinstance(result[0], LogEntry)
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_single_valid_line_without_trailing_newline():
    """A file with one valid line but no trailing newline.

    This exercises the 'final line without newline' code path in load().
    """
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE)  # no trailing newline
        path = f.name
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_mixed_valid_and_invalid_lines():
    """A file with a mix of valid and invalid lines should skip invalid ones."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(INVALID_LINE + "\n")
        f.write(VALID_LINE + "\n")
        f.write(INVALID_LINE)  # no trailing newline
        path = f.name
    try:
        result = load(path)
        assert len(result) == 2
        assert all(isinstance(e, LogEntry) for e in result)
    finally:
        os.unlink(path)


def test_load_multiple_valid_lines():
    """A file with many valid lines."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        for i in range(100):
            f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 100
    finally:
        os.unlink(path)


def test_load_only_invalid_lines():
    """A file with only invalid lines should return empty list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(INVALID_LINE + "\n")
        f.write("garbage\n")
        f.write("more garbage")
        path = f.name
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_file_with_empty_lines():
    """Empty lines in the file should be skipped (parse_line returns None)."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("\n")
        f.write(VALID_LINE + "\n")
        f.write("\n")
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_empty_file():
    """load_iter on an empty file should yield nothing."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("")
        path = f.name
    try:
        result = list(load_iter(path))
        assert result == []
    finally:
        os.unlink(path)


def test_load_iter_single_line():
    """load_iter should yield one entry for one valid line."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = list(load_iter(path))
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_iter_mixed_lines():
    """load_iter should skip invalid lines just like load()."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(INVALID_LINE + "\n")
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = list(load_iter(path))
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_is_generator():
    """load_iter should return a generator, not a list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load_iter(path)
        # Should be a generator
        assert hasattr(result, "__iter__")
        assert hasattr(result, "__next__")
    finally:
        os.unlink(path)


def test_load_and_load_iter_produce_same_results():
    """load() and load_iter() should produce the same entries for the same file."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(INVALID_LINE + "\n")
        f.write(VALID_LINE)
        path = f.name
    try:
        loaded = load(path)
        iterated = list(load_iter(path))
        assert len(loaded) == len(iterated)
        for a, b in zip(loaded, iterated):
            assert a.ip == b.ip
            assert a.status == b.status
            assert a.url == b.url
    finally:
        os.unlink(path)


def test_load_nonexistent_file_raises():
    """Loading a nonexistent file should raise FileNotFoundError."""
    try:
        load("/nonexistent/path/to/file.log")
        assert False, "Expected FileNotFoundError"
    except FileNotFoundError:
        pass


def test_load_iter_nonexistent_file_raises():
    """load_iter on a nonexistent file should raise FileNotFoundError."""
    try:
        list(load_iter("/nonexistent/path/to/file.log"))
        assert False, "Expected FileNotFoundError"
    except FileNotFoundError:
        pass
