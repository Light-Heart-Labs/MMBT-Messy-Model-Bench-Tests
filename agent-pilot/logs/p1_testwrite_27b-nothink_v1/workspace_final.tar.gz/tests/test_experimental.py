"""Tests for experimental.py — anomaly detection and session windowing.

These tests exercise the 0%-coverage experimental module. The module is marked
'not yet wired into the CLI' but testing it increases coverage and validates
the logic before it's integrated.
"""
from datetime import datetime, timedelta, timezone

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1", **kw):
    """Helper to create a LogEntry with a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
        **kw,
    )


# ── detect_anomalies ────────────────────────────────────────────────────────

def test_detect_anomalies_empty_input():
    """Empty input should return empty list (no anomalies possible)."""
    assert detect_anomalies([]) == []


def test_detect_anomalies_single_entry():
    """A single entry has zero variance, so threshold = mean. No anomalies."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts)]
    result = detect_anomalies(entries)
    assert result == []


def test_detect_anomalies_uniform_distribution():
    """When all minutes have the same count, std=0, threshold=mean. No anomalies."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    result = detect_anomalies(entries)
    assert result == []


def test_detect_anomalies_spike_detected():
    """A minute with many more requests than others should be flagged.

    Need enough normal entries so the spike's z-score exceeds 3.
    The z-score formula uses population std, so a single dominant spike
    inflates std. We use 100 normal minutes + 500 spike entries.
    """
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    # 100 normal minutes with 1 request each
    entries = [_entry(base + timedelta(minutes=i)) for i in range(100)]
    # 500 requests in minute 50
    spike_time = base + timedelta(minutes=50)
    entries += [_entry(spike_time + timedelta(milliseconds=s)) for s in range(500)]
    result = detect_anomalies(entries)
    assert spike_time in result


def test_detect_anomalies_buckets_by_minute():
    """Entries within the same minute are bucketed together."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    # 50 entries in minute 0, spread across seconds
    entries = [_entry(base + timedelta(seconds=s)) for s in range(50)]
    result = detect_anomalies(entries)
    # All entries are in one bucket, so no anomaly (only 1 bucket)
    assert result == []


def test_detect_anomalies_multiple_anomalous_minutes():
    """Multiple minutes exceeding the threshold should all be returned."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 100 normal minutes with 1 request each
    for i in range(100):
        entries.append(_entry(base + timedelta(minutes=i)))
    # Two spikes at minutes 50 and 75
    spike1 = base + timedelta(minutes=50)
    spike2 = base + timedelta(minutes=75)
    for _ in range(200):
        entries.append(_entry(spike1 + timedelta(milliseconds=1)))
        entries.append(_entry(spike2 + timedelta(milliseconds=1)))
    result = detect_anomalies(entries)
    assert spike1 in result
    assert spike2 in result


def test_detect_anomalies_returns_datetime_objects():
    """Anomaly buckets should be datetime objects (minute-truncated)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base)]
    entries += [_entry(base + timedelta(minutes=5) + timedelta(milliseconds=s))
                for s in range(500)]
    result = detect_anomalies(entries)
    if result:
        for bucket in result:
            assert isinstance(bucket, datetime)
            assert bucket.second == 0
            assert bucket.microsecond == 0


# ── session_window ──────────────────────────────────────────────────────────

def test_session_window_empty_input():
    """No entries means no sessions."""
    assert session_window([]) == []


def test_session_window_single_entry():
    """A single entry forms one session."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts)]
    sessions = session_window(entries)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    assert ip == "10.0.0.1"
    assert len(session_entries) == 1


def test_session_window_single_ip_continuous():
    """All entries from one IP within the window form a single session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    assert ip == "10.0.0.1"
    assert len(session_entries) == 10


def test_session_window_gap_splits_session():
    """A gap larger than window_seconds splits a session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        # 40-minute gap (> 30 min default window)
        _entry(base + timedelta(minutes=50)),
        _entry(base + timedelta(minutes=60)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    assert len(sessions[0][1]) == 2
    assert len(sessions[1][1]) == 2


def test_session_window_multiple_ips():
    """Entries from different IPs are grouped separately."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base, ip="10.0.0.1"),
        _entry(base + timedelta(minutes=5), ip="10.0.0.2"),
        _entry(base + timedelta(minutes=10), ip="10.0.0.1"),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    ips = {s[0] for s in sessions}
    assert ips == {"10.0.0.1", "10.0.0.2"}


def test_session_window_custom_window():
    """Custom window_seconds parameter controls session splitting.

    With a 3-minute window (180s), 5-minute gaps split each entry into
    its own session, yielding 3 sessions.
    """
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=5)),
        _entry(base + timedelta(minutes=10)),
    ]
    # 3-minute window: each 5-min gap splits
    sessions = session_window(entries, window_seconds=180)
    assert len(sessions) == 3


def test_session_window_entries_sorted_by_time():
    """Entries within a session should be sorted by timestamp."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base + timedelta(minutes=10)),
        _entry(base),
        _entry(base + timedelta(minutes=5)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    _, session_entries = sessions[0]
    timestamps = [e.timestamp for e in session_entries]
    assert timestamps == sorted(timestamps)


def test_session_window_exact_window_boundary():
    """A gap exactly equal to window_seconds should NOT split (uses >, not >=)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1800)),  # exactly 30 min
    ]
    sessions = session_window(entries, window_seconds=1800)
    # gap == window_seconds, so no split (condition is gap > window_seconds)
    assert len(sessions) == 1
    assert len(sessions[0][1]) == 2


def test_session_window_just_over_boundary():
    """A gap just over window_seconds should split."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1801)),  # 1 second over
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
