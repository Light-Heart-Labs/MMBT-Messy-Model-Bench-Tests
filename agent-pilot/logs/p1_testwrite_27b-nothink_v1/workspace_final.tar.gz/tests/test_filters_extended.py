"""Tests for filters.py — expression_filter, combine_and, and edge cases.

The starter tests cover status_filter, url_regex_filter, ip_allowlist_filter,
and date_range_filter. This file adds tests for the uncovered expression_filter
and combine_and functions, plus edge cases for existing filters.
"""
from datetime import datetime, timezone

from logalyzer.filters import (
    combine_and,
    date_range_filter,
    expression_filter,
    ip_allowlist_filter,
    status_filter,
    url_regex_filter,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── expression_filter ───────────────────────────────────────────────────────

def test_expression_filter_status_range():
    """Expression filter with status range comparison."""
    pred = expression_filter("entry.status >= 400")
    assert pred(_entry(status=404)) is True
    assert pred(_entry(status=500)) is True
    assert pred(_entry(status=200)) is False


def test_expression_filter_bytes_threshold():
    """Expression filter with bytes comparison."""
    pred = expression_filter("entry.bytes > 1024")
    assert pred(_entry(bytes=2000)) is True
    assert pred(_entry(bytes=1024)) is False
    assert pred(_entry(bytes=100)) is False


def test_expression_filter_method_and_status():
    """Expression filter combining method and status."""
    pred = expression_filter("entry.method == 'POST' and entry.status == 201")
    assert pred(_entry(method="POST", status=201)) is True
    assert pred(_entry(method="GET", status=201)) is False
    assert pred(_entry(method="POST", status=200)) is False


def test_expression_filter_url_contains():
    """Expression filter checking URL substring."""
    pred = expression_filter("'admin' in entry.url")
    assert pred(_entry(url="/admin/login")) is True
    assert pred(_entry(url="/index.html")) is False


def test_expression_filter_always_true():
    """Expression filter that always returns True."""
    pred = expression_filter("True")
    assert pred(_entry()) is True
    assert pred(_entry(status=500)) is True


def test_expression_filter_always_false():
    """Expression filter that always returns False."""
    pred = expression_filter("False")
    assert pred(_entry()) is False
    assert pred(_entry(status=500)) is False


def test_expression_filter_ip_check():
    """Expression filter checking IP address."""
    pred = expression_filter("entry.ip == '10.0.0.1'")
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="192.168.1.1")) is False


# ── combine_and ─────────────────────────────────────────────────────────────

def test_combine_and_no_predicates():
    """combine_and with no predicates should always return True."""
    pred = combine_and()
    assert pred(_entry()) is True
    assert pred(_entry(status=500)) is True


def test_combine_and_single_predicate():
    """combine_and with one predicate should behave like that predicate."""
    pred = combine_and(status_filter(200))
    assert pred(_entry(status=200)) is True
    assert pred(_entry(status=404)) is False


def test_combine_and_all_match():
    """combine_and with multiple predicates, all matching."""
    pred = combine_and(
        status_filter(200),
        expression_filter("entry.method == 'GET'"),
    )
    assert pred(_entry(status=200, method="GET")) is True


def test_combine_and_first_fails():
    """combine_and should short-circuit when first predicate fails."""
    pred = combine_and(
        status_filter(404),  # fails for status=200
        expression_filter("entry.bytes > 0"),  # would pass
    )
    assert pred(_entry(status=200, bytes=100)) is False


def test_combine_and_second_fails():
    """combine_and should check second predicate when first passes."""
    pred = combine_and(
        status_filter(200),  # passes
        expression_filter("entry.bytes > 1000"),  # fails for bytes=100
    )
    assert pred(_entry(status=200, bytes=100)) is False


def test_combine_and_three_predicates():
    """combine_and with three predicates."""
    pred = combine_and(
        status_filter(200),
        expression_filter("entry.method == 'GET'"),
        ip_allowlist_filter(["10.0.0.1"]),
    )
    assert pred(_entry(status=200, method="GET", ip="10.0.0.1")) is True
    assert pred(_entry(status=200, method="GET", ip="10.0.0.2")) is False
    assert pred(_entry(status=404, method="GET", ip="10.0.0.1")) is False


# ── date_range_filter edge cases ────────────────────────────────────────────

def test_date_range_filter_only_since():
    """date_range_filter with only since (until=None)."""
    since = datetime(2026, 1, 1, tzinfo=timezone.utc)
    pred = date_range_filter(since, None)
    assert pred(_entry(timestamp=datetime(2026, 1, 2, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2025, 12, 31, tzinfo=timezone.utc))) is False


def test_date_range_filter_only_until():
    """date_range_filter with only until (since=None)."""
    until = datetime(2026, 1, 31, tzinfo=timezone.utc)
    pred = date_range_filter(None, until)
    assert pred(_entry(timestamp=datetime(2026, 1, 15, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2026, 2, 1, tzinfo=timezone.utc))) is False


def test_date_range_filter_both_none():
    """date_range_filter with both None should match everything."""
    pred = date_range_filter(None, None)
    assert pred(_entry()) is True
    assert pred(_entry(timestamp=datetime(2020, 1, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2030, 12, 31, tzinfo=timezone.utc))) is True


# ── ip_allowlist_filter edge cases ──────────────────────────────────────────

def test_ip_allowlist_empty_list():
    """ip_allowlist_filter with empty list should never match."""
    pred = ip_allowlist_filter([])
    assert pred(_entry(ip="10.0.0.1")) is False
    assert pred(_entry(ip="192.168.1.1")) is False


def test_ip_allowlist_with_set():
    """ip_allowlist_filter should work with a set (not just list)."""
    pred = ip_allowlist_filter({"10.0.0.1", "10.0.0.2"})
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="10.0.0.3")) is False


def test_ip_allowlist_single_ip():
    """ip_allowlist_filter with a single IP in the list."""
    pred = ip_allowlist_filter(["10.0.0.1"])
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="10.0.0.2")) is False


# ── url_regex_filter edge cases ─────────────────────────────────────────────

def test_url_regex_filter_empty_pattern():
    """url_regex_filter with empty pattern matches everything (re.match on empty)."""
    pred = url_regex_filter("")
    # re.match("") matches at start of any string
    assert pred(_entry(url="/anything")) is True


def test_url_regex_filter_special_regex_chars():
    """url_regex_filter with regex special characters."""
    pred = url_regex_filter(r"^/api/\d+")
    assert pred(_entry(url="/api/123")) is True
    assert pred(_entry(url="/api/abc")) is False


def test_url_regex_filter_case_sensitive():
    """url_regex_filter is case-sensitive by default."""
    pred = url_regex_filter("GET")
    assert pred(_entry(url="GET")) is True
    assert pred(_entry(url="/get")) is False
