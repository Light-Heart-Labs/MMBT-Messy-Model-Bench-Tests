"""Tests for output.py — JSON, CSV, text formatters and render_aggregate.

Exercises all output functions with edge cases: empty input, special
characters, and the render_aggregate function with different aggregate types.
"""
from datetime import datetime, timezone
from collections import Counter

from logalyzer.output import (
    to_json,
    to_csv,
    to_text,
    render_aggregate,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── to_json ─────────────────────────────────────────────────────────────────

def test_to_json_empty():
    """Empty input should produce an empty JSON array."""
    result = to_json([])
    assert result == "[]"


def test_to_json_single_entry():
    """Single entry should produce a JSON array with one object."""
    entries = [_entry()]
    result = to_json(entries)
    assert result.startswith("[")
    assert result.endswith("]")
    assert '"ip":"10.0.0.1"' in result
    assert '"status":200' in result
    assert '"bytes":100' in result


def test_to_json_multiple_entries():
    """Multiple entries should produce a JSON array with comma-separated objects."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_json(entries)
    assert result.count('"status":200') == 1
    assert result.count('"status":404') == 1


def test_to_json_url_with_special_chars():
    """URLs with special characters should be included as-is in JSON.

    Note: the to_json function does NOT escape JSON special characters in
    string values. This test documents the current behavior.
    """
    entries = [_entry(url='/path?q=1&b=2')]
    result = to_json(entries)
    assert '/path?q=1&b=2' in result


def test_to_json_iso_timestamp():
    """Timestamps should be rendered as ISO format strings."""
    entries = [_entry()]
    result = to_json(entries)
    assert '2026-01-01T12:00:00' in result


# ── to_csv ──────────────────────────────────────────────────────────────────

def test_to_csv_empty():
    """Empty input should produce only the header row."""
    result = to_csv([])
    lines = result.strip().split("\n")
    assert len(lines) == 1
    assert "ip" in lines[0]
    assert "status" in lines[0]


def test_to_csv_single_entry():
    """Single entry should produce header + one data row."""
    entries = [_entry()]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 2
    assert "10.0.0.1" in lines[1]
    assert "200" in lines[1]


def test_to_csv_multiple_entries():
    """Multiple entries should produce header + N data rows."""
    entries = [_entry(status=200), _entry(status=404), _entry(status=500)]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 4  # header + 3 data rows


def test_to_csv_header_fields():
    """CSV header should contain all expected fields."""
    result = to_csv([])
    header = result.strip().split("\n")[0]
    expected_fields = ["ip", "user", "timestamp", "method", "url", "protocol", "status", "bytes"]
    for field in expected_fields:
        assert field in header


# ── to_text ─────────────────────────────────────────────────────────────────

def test_to_text_empty():
    """Empty input should produce empty string."""
    result = to_text([])
    assert result == ""


def test_to_text_single_entry():
    """Single entry should produce one line of formatted text."""
    entries = [_entry()]
    result = to_text(entries)
    assert "10.0.0.1" in result
    assert "GET" in result
    assert "200" in result
    assert "/" in result


def test_to_text_multiple_entries():
    """Multiple entries should produce multiple lines separated by newlines."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_text(entries)
    lines = result.split("\n")
    assert len(lines) == 2


def test_to_text_ip_right_aligned():
    """IP addresses should be right-aligned in the text output.

    The format string uses {e.ip:>15} so IPs are right-aligned in a 15-char
    field. We check that the end position of the IP is the same across lines.
    """
    entries = [_entry(ip="1.2.3.4"), _entry(ip="123.45.67.89")]
    result = to_text(entries)
    lines = result.split("\n")
    # Check end position (right-aligned means same end position)
    ip1_end = lines[0].find("1.2.3.4") + len("1.2.3.4")
    ip2_end = lines[1].find("123.45.67.89") + len("123.45.67.89")
    assert ip1_end == ip2_end


# ── render_aggregate ────────────────────────────────────────────────────────

def test_render_aggregate_text_with_counter():
    """render_aggregate with a Counter should produce tab-separated text."""
    agg = Counter({"200": 10, "404": 3, "500": 1})
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_text_with_dict():
    """render_aggregate with a dict should produce tab-separated text."""
    agg = {"200": 10, "404": 3}
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result


def test_render_aggregate_text_with_list():
    """render_aggregate with a list of tuples should produce tab-separated text."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result


def test_render_aggregate_json_with_counter():
    """render_aggregate with fmt='json' and a Counter."""
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="json")
    assert '"200":10' in result
    assert '"404":3' in result
    assert result.startswith("{")
    assert result.endswith("}")


def test_render_aggregate_json_with_list():
    """render_aggregate with fmt='json' and a list of tuples."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="json")
    assert '"200":10' in result


def test_render_aggregate_unknown_format_raises():
    """render_aggregate with an unknown format should raise ValueError."""
    agg = Counter({"200": 10})
    try:
        render_aggregate(agg, fmt="xml")
        assert False, "Expected ValueError"
    except ValueError as e:
        assert "unknown format" in str(e)


def test_render_aggregate_default_format_is_text():
    """render_aggregate with no fmt argument should default to text."""
    agg = Counter({"200": 10})
    result = render_aggregate(agg)
    assert "200\t10" in result


# ── Edge cases ──────────────────────────────────────────────────────────────

def test_to_json_zero_bytes():
    """Entries with zero bytes should render correctly in JSON."""
    entries = [_entry(bytes=0)]
    result = to_json(entries)
    assert '"bytes":0' in result


def test_to_csv_zero_bytes():
    """Entries with zero bytes should render correctly in CSV."""
    entries = [_entry(bytes=0)]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert "0" in lines[1]


def test_to_text_large_bytes():
    """Entries with large byte counts should render correctly in text."""
    entries = [_entry(bytes=999999999)]
    result = to_text(entries)
    # text format doesn't show bytes, but should still render
    assert "GET" in result
