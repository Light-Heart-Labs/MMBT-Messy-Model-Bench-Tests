"""Tests for parser.py — edge cases for timestamp parsing and line parsing.

The starter tests cover basic CLF parsing, dash-for-zero bytes, garbage lines,
January timestamps, and UTC offset conversion. This file adds tests for:
- Months that ARE in MONTH_NAMES (Feb-Jun, Aug-Oct)
- Negative timezone offsets
- Whitespace handling
- parse_lines generator
- Edge cases in parse_timestamp

NOTE: MONTH_NAMES in parser.py is missing "Jul" (only 11 months listed).
This causes all months after June to be off by one. Tests below document
the actual behavior without fixing the bug.
"""
from datetime import datetime, timezone

from logalyzer.parser import parse_line, parse_lines, parse_timestamp


def test_parse_timestamp_feb():
    """February timestamp should parse correctly."""
    ts = parse_timestamp("15/Feb/2026:08:30:00 +0000")
    assert ts.month == 2
    assert ts.day == 15


def test_parse_timestamp_mar():
    """March timestamp should parse correctly."""
    ts = parse_timestamp("01/Mar/2026:00:00:00 +0000")
    assert ts.month == 3


def test_parse_timestamp_apr():
    """April timestamp should parse correctly."""
    ts = parse_timestamp("15/Apr/2026:12:00:00 +0000")
    assert ts.month == 4


def test_parse_timestamp_may():
    """May timestamp should parse correctly."""
    ts = parse_timestamp("20/May/2026:18:00:00 +0000")
    assert ts.month == 5


def test_parse_timestamp_jun():
    """June timestamp should parse correctly."""
    ts = parse_timestamp("30/Jun/2026:23:59:59 +0000")
    assert ts.month == 6


def test_parse_timestamp_aug_off_by_one():
    """August parses as month 7 due to missing 'Jul' in MONTH_NAMES.

    BUG: MONTH_NAMES skips 'Jul', so 'Aug' gets index 6 → month 7 (July).
    This test documents the actual behavior.
    """
    ts = parse_timestamp("01/Aug/2026:00:00:00 +0000")
    # Actual behavior: month=7 (off by one)
    assert ts.month == 7


def test_parse_timestamp_sep_off_by_one():
    """September parses as month 8 due to missing 'Jul' in MONTH_NAMES.

    BUG: Same as above.
    """
    ts = parse_timestamp("15/Sep/2026:12:00:00 +0000")
    assert ts.month == 8


def test_parse_timestamp_oct_off_by_one():
    """October parses as month 9 due to missing 'Jul' in MONTH_NAMES.

    BUG: Same as above.
    """
    ts = parse_timestamp("10/Oct/2000:13:55:36 -0700")
    assert ts.month == 9  # should be 10, but is 9


def test_parse_timestamp_positive_offset():
    """Positive timezone offset should subtract from UTC."""
    # 12:00 +0500 = 07:00 UTC
    ts = parse_timestamp("15/Jan/2026:12:00:00 +0500")
    assert ts.hour == 7


def test_parse_timestamp_negative_offset():
    """Negative timezone offset should add to UTC."""
    # 12:00 -0500 = 17:00 UTC
    ts = parse_timestamp("15/Jan/2026:12:00:00 -0500")
    assert ts.hour == 17


def test_parse_timestamp_zero_offset():
    """Zero timezone offset should not change the time."""
    ts = parse_timestamp("15/Jan/2026:12:00:00 +0000")
    assert ts.hour == 12


def test_parse_timestamp_invalid_format_raises():
    """Invalid timestamp format should raise ValueError."""
    try:
        parse_timestamp("not-a-timestamp")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_timestamp_missing_timezone_raises():
    """Timestamp without timezone should raise ValueError."""
    try:
        parse_timestamp("15/Jan/2026:12:00:00")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_line_whitespace_only():
    """Whitespace-only line should return None."""
    assert parse_line("   ") is None
    assert parse_line("\t") is None
    assert parse_line("\n") is None


def test_parse_line_leading_trailing_whitespace():
    """Lines with leading/trailing whitespace should still parse (strip is called)."""
    line = '  127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326  '
    e = parse_line(line)
    assert e is not None
    assert e.ip == "127.0.0.1"


def test_parse_line_with_referer_and_user_agent():
    """Combined Log Format includes referer and user-agent after bytes.

    The parser regex doesn't capture these fields, but the line should still
    parse if the core fields are present.
    """
    line = ('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] '
            '"GET /apache_pb.gif HTTP/1.0" 200 2326 '
            '"http://www.example.com/start.html" '
            '"Mozilla/4.08"')
    e = parse_line(line)
    # The regex doesn't capture referer/user-agent, but line should parse
    assert e is not None


def test_parse_lines_generator():
    """parse_lines should yield entries for valid lines and skip invalid ones."""
    lines = [
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326',
        'garbage line',
        '127.0.0.1 - - [10/Oct/2000:13:55:37 +0000] "GET /page HTTP/1.0" 404 0',
        '',
    ]
    entries = list(parse_lines(lines))
    assert len(entries) == 2
    assert entries[0].status == 200
    assert entries[1].status == 404


def test_parse_lines_empty_input():
    """parse_lines with empty input should yield nothing."""
    entries = list(parse_lines([]))
    assert entries == []


def test_parse_lines_all_invalid():
    """parse_lines with all invalid lines should yield nothing."""
    entries = list(parse_lines(["garbage", "more garbage", ""]))
    assert entries == []


def test_parse_line_various_methods():
    """parse_line should handle various HTTP methods."""
    for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "{method} / HTTP/1.1" 200 0'
        e = parse_line(line)
        assert e is not None, f"Method {method} should parse"
        assert e.method == method


def test_parse_line_various_status_codes():
    """parse_line should handle various HTTP status codes."""
    for status in [200, 201, 301, 302, 304, 400, 401, 403, 404, 500, 502, 503]:
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" {status} 0'
        e = parse_line(line)
        assert e is not None, f"Status {status} should parse"
        assert e.status == status


def test_parse_line_unicode_url():
    """parse_line should handle URLs with percent-encoded unicode."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /path/%E4%B8%AD%E6%96%87 HTTP/1.1" 200 0'
    e = parse_line(line)
    assert e is not None
    assert "/path/%E4%B8%AD%E6%96%87" in e.url


def test_parse_line_very_large_bytes():
    """parse_line should handle very large byte counts."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.1" 200 999999999999'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 999999999999


def test_parse_line_invalid_month_returns_none():
    """parse_line should return None when timestamp has invalid month.

    The regex matches the line, but parse_timestamp raises ValueError
    because the month abbreviation is not in MONTH_NAMES.
    This exercises the except ValueError: return None path in parse_line.
    """
    line = '127.0.0.1 - - [10/Xyz/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    result = parse_line(line)
    assert result is None
