# Research Notes

## 2025-01-XX: Initial exploration

### Baseline coverage
- Total: 34% (97/287 statements covered)
- `experimental.py`: 0% (32 statements)
- `io.py`: 0% (26 statements)
- `output.py`: 0% (35 statements)
- `utils.py`: 0% (21 statements)
- `cli.py`: 0% (59 statements)
- `parser.py`: 86% (7 statements missed)
- `filters.py`: 74% (10 statements missed)
- `aggregate.py`: 100%
- `__init__.py`: 100%

### Pre-existing bugs found
1. `MONTH_NAMES` in `parser.py` is missing "Jul" — only 11 months listed
2. `status_filter` in `filters.py` compares string directly to int (no conversion)
3. `url_regex_filter` uses `re.match` (start-anchored) not `re.search`
4. `filters.py` imports `Iterable` from `collections` (removed in Python 3.11)

### Workaround for Iterable import
Added monkey-patch in `conftest.py` to inject `Iterable` into `collections` module before imports happen.

## 2025-01-XX: Anomaly detection test data

The z-score anomaly detection uses population standard deviation. A single spike inflates the std, making it hard to trigger the `> mean + 3*std` threshold. Found that 100 normal minutes + 500 spike entries reliably triggers detection.

## 2025-01-XX: Session window boundary

The session window uses `>` (strictly greater than) for the gap comparison, not `>=`. A gap exactly equal to `window_seconds` does NOT split a session.
