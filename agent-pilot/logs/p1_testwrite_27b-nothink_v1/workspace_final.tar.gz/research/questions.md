# Questions

## Resolved questions

### Q1: Should I fix the 3 pre-existing test failures?
**No.** Per task rules: "If you find a bug, document it but don't fix it (the test should pass against current behavior, even if that behavior is wrong)." The 3 failing tests are in the starter code and reflect bugs in the source code.

### Q2: Can I modify conftest.py?
**Yes.** The conftest.py is in `/tests/` which is allowed to be modified. The monkey-patch for `collections.Iterable` is necessary because the source code has a Python 3.11 incompatibility that we cannot fix in source.

### Q3: Should I test the `format_legacy` function from `utils.py`?
**Yes.** It was explicitly mentioned as uncovered in the task description. Added 3 tests in `test_utils.py`.

### Q4: Should I test `experimental.py` despite being marked "experimental"?
**Yes.** The task explicitly says: "testing it is fine if the goal is increasing coverage and exercising the code path."

## Open questions

### Q5: The `to_json` function doesn't escape JSON special characters
If a URL contains a double quote, the JSON output would be malformed. This is a potential bug but testing it would require creating entries with quotes in URLs, which the parser may not accept. Documented in `test_output.py` but not actively tested as a failure case.

### Q6: The `expression_filter` uses `eval()` with restricted builtins
This is a security concern in production but is the current behavior. We test it works but don't test for security bypasses (out of scope).
