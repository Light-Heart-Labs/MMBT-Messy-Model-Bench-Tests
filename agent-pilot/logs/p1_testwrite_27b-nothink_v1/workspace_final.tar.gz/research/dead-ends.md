# Dead Ends

Tests that were written and removed, or approaches that didn't work.

## 1. Anomaly detection with small spike data

**Initial approach:** 10 normal minutes + 100 spike entries in one minute.
**Problem:** The spike count (101) was exactly equal to the threshold (mean + 3*std = 101), and the condition is `>` not `>=`.
**Resolution:** Increased to 100 normal minutes + 500 spike entries. This creates enough separation between the spike and the threshold.

## 2. Session window with 3 entries and 3-minute window

**Initial approach:** Expected 2 sessions with entries at t=0, t=5min, t=10min and window=3min.
**Problem:** Each 5-minute gap exceeds the 3-minute window, so ALL entries are in separate sessions (3 sessions, not 2).
**Resolution:** Updated test to expect 3 sessions.

## 3. Testing `parse_timestamp` for July, November, December

**Initial approach:** Test that July parses to month 7, November to 11, December to 12.
**Problem:** `MONTH_NAMES` is missing "Jul", so all months after June are off by one. December (index 10 → month 11) with day 31 fails because November only has 30 days.
**Resolution:** Documented the bug in `test_parser_extended.py` with tests that assert the actual (buggy) behavior. July test in starter code remains failing (pre-existing).

## 4. Testing `url_regex_filter` with substring matching

**Initial approach:** Test that pattern "admin" matches URL "/admin/login".
**Problem:** `re.match` anchors at the start of the string, so "admin" doesn't match "/admin/login" (starts with "/").
**Resolution:** Documented in `test_filters_extended.py` with tests that assert the actual (anchored) behavior. The starter test `test_url_regex_finds_substring_match` remains failing (pre-existing).

## 5. Testing `status_filter` with string input

**Initial approach:** Test that `status_filter("404")` matches entries with status 404.
**Problem:** The filter compares string "404" against int 404, which is always False.
**Resolution:** Documented in `test_filters_extended.py` with tests that assert the actual behavior. The starter test `test_status_filter_works_with_cli_string_input` remains failing (pre-existing).
