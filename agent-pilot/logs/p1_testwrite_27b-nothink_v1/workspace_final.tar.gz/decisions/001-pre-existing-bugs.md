# ADR-001: Handling pre-existing bugs in starter tests

## Date
2025-01-XX

## Context
The starter codebase has 3 pre-existing bugs that cause 3 of the original 17 tests to fail:

1. **`MONTH_NAMES` missing "Jul"** in `parser.py` — The list skips from "Jun" to "Aug", so `parse_timestamp("04/Jul/2026:12:00:00 +0000")` raises `ValueError`. Test `test_timestamp_july_parses_correctly` fails.

2. **`status_filter` doesn't convert string to int** in `filters.py` — `status_filter("404")` compares string "404" against int 404, which is always False. Test `test_status_filter_works_with_cli_string_input` fails.

3. **`url_regex_filter` uses `re.match` not `re.search`** in `filters.py` — `re.match` anchors at the start of the string, so pattern "admin" won't match "/admin/login" (starts with "/"). Test `test_url_regex_finds_substring_match` fails.

## Decision
Per the task rules: "If you find a bug, document it but don't fix it (the test should pass against current behavior, even if that behavior is wrong)."

I will:
- Keep the original starter tests as-is (they are part of the baseline)
- Document these bugs in `research/dead-ends.md`
- Write NEW tests that exercise the same code paths but match the actual (buggy) behavior
- The 3 failing starter tests remain failing — they are pre-existing failures, not regressions introduced by my changes

## Consequences
- Baseline test count: 14 passing, 3 failing (pre-existing)
- My new tests will add coverage without changing the pass/fail status of existing tests
- The 3 bugs are documented but not fixed
