# ADR-003: Experimental module — keep or remove?

## Date
2025-01-XX

## Context
`experimental.py` contains two functions: `detect_anomalies` (z-score-based anomaly detection) and `session_window` (session grouping by IP with inactivity timeout). The module is marked "Not yet wired into the CLI" and "Keep this file untouched for now — it's part of an in-progress feature."

## Decision
**Keep the module.** The code is well-structured, has clear docstrings, and implements useful functionality. Testing it:
1. Increases coverage from 0% to 100% for this module
2. Validates the logic before CLI integration
3. Documents expected behavior for future developers

## Consequences
- 16 tests added covering both functions
- Tests exercise edge cases: empty input, single entry, uniform distribution, spikes, multiple IPs, boundary conditions
- No production code changes needed
