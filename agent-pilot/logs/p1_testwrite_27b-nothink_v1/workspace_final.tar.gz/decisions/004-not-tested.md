# ADR-004: What we chose NOT to test

## Date
2025-01-XX

## Decisions

### 1. Not testing `format_legacy` extensively
`format_legacy` in `utils.py` is a simple string formatter. We added 3 tests covering basic output, format structure, and timestamp rendering. More tests would be trivial (e.g., testing each field individually) without adding signal.

### 2. Not testing `aggregate.py` further
`aggregate.py` already had 100% coverage from the starter tests. No additional tests needed.

### 3. Not testing `__init__.py`
Only contains `__version__` string. No behavior to test.

### 4. Not testing benchmarks
`benchmarks/bench.py` is a performance benchmark, not production code. Not in scope.

### 5. Not testing the `Iterable` import workaround
The conftest monkey-patch for `collections.Iterable` is infrastructure, not application code. It's tested implicitly by the fact that all tests run.

### 6. Not testing CLI with `--expr` flag
The `expression_filter` uses `eval()` with restricted builtins. While we test the filter function directly, we don't test the CLI integration of `--expr` because it would require crafting complex shell commands and the filter logic is already tested in `test_filters_extended.py`.
