# ADR-002: Test strategy for under-covered modules

## Date
2025-01-XX

## Context
Baseline coverage is 34%. The following modules have 0% coverage:
- `experimental.py` (32 statements) — anomaly detection and session windowing
- `io.py` (26 statements) — file loading helpers
- `output.py` (35 statements) — JSON, CSV, text formatters
- `utils.py` (21 statements) — date parsing, byte formatting, legacy formatter, chunking
- `cli.py` (59 statements) — CLI entry point

Partially covered:
- `parser.py` (86%) — missing edge cases for timestamps, malformed lines
- `filters.py` (74%) — missing expression_filter, combine_and, edge cases

## Decision
I will write tests for:

### High priority (0% coverage modules):
1. **`experimental.py`** — Test `detect_anomalies` with empty input, single entry, normal distribution, and spike scenarios. Test `session_window` with single IP, multiple IPs, and gap-based session splitting.

2. **`io.py`** — Test `load` and `load_iter` with real temp files, empty files, files with no trailing newline, and files with mixed valid/invalid lines.

3. **`output.py`** — Test `to_json`, `to_csv`, `to_text` with empty entries, single entry, special characters in URLs. Test `render_aggregate` with Counter, list, and unknown format. Test `format_legacy` from utils.

4. **`utils.py`** — Test `parse_iso_date` with valid/invalid dates, `format_bytes` at boundary values (0, 1023, 1024, 1048576, etc.), `format_legacy`, `chunked` with various sizes.

5. **`cli.py`** — Test `build_parser` argument parsing, `main` with various flag combinations using temp files.

### Medium priority (edge cases for partially covered):
6. **`parser.py`** — Test all 12 months, negative timezone offsets, empty lines, whitespace-only lines, lines with extra fields.

7. **`filters.py`** — Test `expression_filter`, `combine_and` with zero/one/many predicates, `date_range_filter` with only since or only until.

## Consequences
- Expected coverage increase: from 34% to ~75%+
- No production code changes
- All new tests pass against current behavior
