# CHANGELOG

## v0.3.2-test-additions (2025-01-XX)

### Coverage Delta
- **Before:** 34% (97/287 statements covered)
- **After:** 99% (286/287 statements covered)
- **Delta:** +65 percentage points

### Per-module coverage

| Module | Before | After |
|--------|--------|-------|
| `__init__.py` | 100% | 100% |
| `aggregate.py` | 100% | 100% |
| `cli.py` | 0% | 98% |
| `experimental.py` | 0% | 100% |
| `filters.py` | 74% | 100% |
| `io.py` | 0% | 100% |
| `output.py` | 0% | 100% |
| `parser.py` | 86% | 100% |
| `utils.py` | 0% | 100% |
| **TOTAL** | **34%** | **99%** |

### Test Files Added

| File | Tests | Purpose |
|------|-------|---------|
| `tests/test_experimental.py` | 16 | Anomaly detection and session windowing |
| `tests/test_io.py` | 14 | File loading (load, load_iter) with edge cases |
| `tests/test_output.py` | 23 | JSON/CSV/text formatters and render_aggregate |
| `tests/test_utils.py` | 31 | Date parsing, byte formatting, legacy formatter, chunking |
| `tests/test_filters_extended.py` | 22 | expression_filter, combine_and, filter edge cases |
| `tests/test_parser_extended.py` | 24 | All months, whitespace, parse_lines, methods, status codes |
| `tests/test_cli.py` | 26 | Argument parsing and main() integration |
| **New tests total** | **156** | |

### Test Count Summary
- **Starter tests:** 17 (14 passing, 3 failing — pre-existing bugs)
- **New tests:** 156 (all passing)
- **Total:** 173 (170 passing, 3 failing — pre-existing bugs)

### Pre-existing Bugs (Not Fixed)
1. `MONTH_NAMES` in `parser.py` missing "Jul" — causes month offset for Jul-Dec
2. `status_filter` in `filters.py` doesn't convert string to int
3. `url_regex_filter` in `filters.py` uses `re.match` (start-anchored) not `re.search`

### Files Modified
- `tests/conftest.py` — Added monkey-patch for `collections.Iterable` (Python 3.11 compatibility)

### Files Added
- `tests/test_experimental.py`
- `tests/test_io.py`
- `tests/test_output.py`
- `tests/test_utils.py`
- `tests/test_filters_extended.py`
- `tests/test_parser_extended.py`
- `tests/test_cli.py`
- `decisions/001-pre-existing-bugs.md`
- `decisions/002-test-strategy.md`
- `decisions/003-experimental-module.md`
- `decisions/004-not-tested.md`
- `research/notes/2025-01-exploration.md`
- `research/questions.md`
- `research/dead-ends.md`
- `CHANGELOG.md`

### No Production Code Changes
All files in `logalyzer/` are byte-identical to the input. Only test files and documentation were added.

### Uncovered Lines (1 remaining)
- `cli.py:84` — `sys.exit(main())` in `if __name__ == "__main__"` block. This line is only executed when the module is run as a script, not when imported by pytest. Cannot be tested through the test framework.
