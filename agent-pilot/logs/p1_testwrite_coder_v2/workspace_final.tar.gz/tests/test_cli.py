"""Tests for cli.py - command-line interface."""
import tempfile
import os

import pytest

from logalyzer.cli import build_parser, main


class TestBuildParser:
    """Tests for build_parser() - argument parser builder."""

    def test_parser_has_paths_argument(self):
        """Parser should have paths argument."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log"])
        assert args.paths == ["/path/to/log"]

    def test_parser_has_status_filter(self):
        """Parser should have --status filter."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log", "--status", "404"])
        assert args.status == "404"

    def test_parser_has_url_filter(self):
        """Parser should have --url filter."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log", "--url", "/admin"])
        assert args.url == "/admin"

    def test_parser_has_ip_filter(self):
        """Parser should have --ip filter."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log", "--ip", "10.0.0.1"])
        assert args.ip == ["10.0.0.1"]

    def test_parser_has_multiple_ip_filters(self):
        """Parser should support multiple --ip filters."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log", "--ip", "10.0.0.1", "--ip", "10.0.0.2"])
        assert args.ip == ["10.0.0.1", "10.0.0.2"]

    def test_parser_has_since_filter(self):
        """Parser should have --since filter."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log", "--since", "2026-01-01"])
        assert args.since is not None

    def test_parser_has_until_filter(self):
        """Parser should have --until filter."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log", "--until", "2026-01-31"])
        assert args.until is not None

    def test_parser_has_expr_filter(self):
        """Parser should have --expr filter."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log", "--expr", "entry.status >= 500"])
        assert args.expr == "entry.status >= 500"

    def test_parser_has_aggregate_option(self):
        """Parser should have --aggregate option."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log", "--aggregate", "status"])
        assert args.aggregate == "status"

    def test_parser_has_top_option(self):
        """Parser should have --top option."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log", "--top", "10"])
        assert args.top == 10

    def test_parser_has_format_option(self):
        """Parser should have --format option."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log", "--format", "json"])
        assert args.format == "json"

    def test_parser_default_format_is_text(self):
        """Parser should default to text format."""
        parser = build_parser()
        args = parser.parse_args(["/path/to/log"])
        assert args.format == "text"


class TestMain:
    """Tests for main() - CLI entry point."""

    def test_main_with_valid_log_file(self, capsys):
        """main() should process valid log file."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.flush()
            
            result = main([f.name])
            
            assert result == 0
            os.unlink(f.name)

    def test_main_with_empty_log_file(self, capsys):
        """main() should handle empty log file."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('')
            f.flush()
            
            result = main([f.name])
            
            assert result == 0
            os.unlink(f.name)

    def test_main_with_json_format(self, capsys):
        """main() should output JSON when --format json is specified."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.flush()
            
            result = main([f.name, "--format", "json"])
            
            assert result == 0
            output = capsys.readouterr().out
            assert '"ip":"127.0.0.1"' in output
            os.unlink(f.name)

    def test_main_with_csv_format(self, capsys):
        """main() should output CSV when --format csv is specified."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.flush()
            
            result = main([f.name, "--format", "csv"])
            
            assert result == 0
            output = capsys.readouterr().out
            assert "ip,user,timestamp,method,url,protocol,status,bytes" in output
            os.unlink(f.name)

    def test_main_with_status_filter(self, capsys):
        """main() should filter by status code."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 404 100\n')
            f.flush()
            
            result = main([f.name, "--status", "404"])
            
            assert result == 0
            os.unlink(f.name)

    def test_main_with_url_filter(self, capsys):
        """main() should filter by URL pattern."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /admin/login HTTP/1.0" 200 2326\n')
            f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 100\n')
            f.flush()
            
            result = main([f.name, "--url", "/admin"])
            
            assert result == 0
            os.unlink(f.name)

    def test_main_with_ip_filter(self, capsys):
        """main() should filter by IP address."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 100\n')
            f.flush()
            
            result = main([f.name, "--ip", "10.0.0.1"])
            
            assert result == 0
            os.unlink(f.name)

    def test_main_with_aggregate_status(self, capsys):
        """main() should aggregate by status when --aggregate status is specified."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 404 100\n')
            f.flush()
            
            result = main([f.name, "--aggregate", "status"])
            
            assert result == 0
            output = capsys.readouterr().out
            assert "200" in output
            assert "404" in output
            os.unlink(f.name)

    def test_main_with_aggregate_url(self, capsys):
        """main() should aggregate by URL when --aggregate url is specified."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /a HTTP/1.0" 200 2326\n')
            f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /a HTTP/1.1" 201 100\n')
            f.write('10.0.0.2 - - [10/Oct/2000:14:00:00 +0000] "GET /b HTTP/1.1" 200 100\n')
            f.flush()
            
            result = main([f.name, "--aggregate", "url"])
            
            assert result == 0
            output = capsys.readouterr().out
            assert "/a" in output
            assert "/b" in output
            os.unlink(f.name)

    def test_main_with_aggregate_hour(self, capsys):
        """main() should aggregate by hour when --aggregate hour is specified."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 100\n')
            f.flush()
            
            result = main([f.name, "--aggregate", "hour"])
            
            assert result == 0
            output = capsys.readouterr().out
            os.unlink(f.name)

    def test_main_with_top_option(self, capsys):
        """main() should limit aggregate results when --top is specified."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            for i in range(20):
                f.write(f'127.0.0.{i % 256} - - [10/Oct/2000:13:55:36 -0700] "GET /u{i} HTTP/1.0" 200 2326\n')
            f.flush()
            
            result = main([f.name, "--aggregate", "url", "--top", "5"])
            
            assert result == 0
            output = capsys.readouterr().out
            # Should have 5 entries
            assert output.count("\t") == 5
            os.unlink(f.name)

    def test_main_with_multiple_files(self, capsys):
        """main() should process multiple files."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f1:
            f1.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f1.flush()
            
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f2:
            f2.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 100\n')
            f2.flush()
            
        result = main([f1.name, f2.name])
        
        assert result == 0
        os.unlink(f1.name)
        os.unlink(f2.name)

    def test_main_with_expression_filter(self, capsys):
        """main() should filter by expression when --expr is specified."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 500 100\n')
            f.flush()
            
            result = main([f.name, "--expr", "entry.status >= 500"])
            
            assert result == 0
            os.unlink(f.name)

    def test_main_returns_zero_on_success(self):
        """main() should return 0 on success."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
            f.flush()
            
            result = main([f.name])
            
            assert result == 0
            os.unlink(f.name)
