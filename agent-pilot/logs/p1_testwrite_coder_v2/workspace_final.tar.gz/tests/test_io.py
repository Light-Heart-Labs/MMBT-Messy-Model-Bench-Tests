"""Tests for io.py - file loading helpers."""
import tempfile
import os

from logalyzer.io import load, load_iter
from logalyzer.parser import LogEntry


def test_load_returns_list_of_entries():
    """load() should return a list of LogEntry objects."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
        f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 100\n')
        f.flush()
        
        entries = load(f.name)
        
        assert isinstance(entries, list)
        assert len(entries) == 2
        assert all(isinstance(e, LogEntry) for e in entries)
        
        os.unlink(f.name)


def test_load_handles_empty_file():
    """load() should return empty list for empty file."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('')
        f.flush()
        
        entries = load(f.name)
        
        assert entries == []
        
        os.unlink(f.name)


def test_load_handles_file_with_only_whitespace():
    """load() should return empty list for file with only whitespace."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('   \n\t\n   \n')
        f.flush()
        
        entries = load(f.name)
        
        assert entries == []
        
        os.unlink(f.name)


def test_load_handles_mixed_valid_invalid_lines():
    """load() should skip invalid lines and return only valid entries."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
        f.write('this is not a valid log line\n')
        f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 100\n')
        f.write('another invalid line\n')
        f.flush()
        
        entries = load(f.name)
        
        assert len(entries) == 2
        assert entries[0].ip == "127.0.0.1"
        assert entries[1].ip == "10.0.0.1"
        
        os.unlink(f.name)


def test_load_handles_file_without_trailing_newline():
    """load() should handle files without trailing newline."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326')
        f.flush()
        
        entries = load(f.name)
        
        assert len(entries) == 1
        assert entries[0].ip == "127.0.0.1"
        
        os.unlink(f.name)


def test_load_handles_dash_for_zero_bytes():
    """load() should handle dash for bytes field (convert to 0)."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 304 -\n')
        f.flush()
        
        entries = load(f.name)
        
        assert len(entries) == 1
        assert entries[0].bytes == 0
        
        os.unlink(f.name)


def test_load_handles_unicode_url():
    """load() should handle URLs with unicode characters."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /path/with/émojis/🎉 HTTP/1.0" 200 2326\n')
        f.flush()
        
        entries = load(f.name)
        
        assert len(entries) == 1
        assert "émojis" in entries[0].url
        assert "🎉" in entries[0].url
        
        os.unlink(f.name)


def test_load_iter_returns_generator():
    """load_iter() should return a generator."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
        f.flush()
        
        entries = load_iter(f.name)
        
        # Should be a generator
        assert hasattr(entries, '__iter__')
        assert hasattr(entries, '__next__')
        
        entries_list = list(entries)
        assert len(entries_list) == 1
        assert entries_list[0].ip == "127.0.0.1"
        
        os.unlink(f.name)


def test_load_iter_handles_empty_file():
    """load_iter() should return empty generator for empty file."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('')
        f.flush()
        
        entries = load_iter(f.name)
        
        entries_list = list(entries)
        assert entries_list == []
        
        os.unlink(f.name)


def test_load_iter_handles_mixed_valid_invalid_lines():
    """load_iter() should skip invalid lines and return only valid entries."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
        f.write('this is not a valid log line\n')
        f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 100\n')
        f.write('another invalid line\n')
        f.flush()
        
        entries = load_iter(f.name)
        
        entries_list = list(entries)
        assert len(entries_list) == 2
        assert entries_list[0].ip == "127.0.0.1"
        assert entries_list[1].ip == "10.0.0.1"
        
        os.unlink(f.name)


def test_load_iter_is_memory_efficient():
    """load_iter() should not load all entries into memory at once."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        # Write 1000 log lines
        for i in range(1000):
            f.write(f'127.0.0.{i % 256} - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n')
        f.flush()
        
        entries = load_iter(f.name)
        
        # Should be able to iterate without loading all into memory
        count = 0
        for entry in entries:
            count += 1
            if count >= 10:
                break
        
        assert count == 10
        
        os.unlink(f.name)


def test_load_iter_returns_generator_for_empty_file():
    """load_iter() should return empty generator for empty file."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('')
        f.flush()
        
        entries = load_iter(f.name)
        
        # Should be a generator
        assert hasattr(entries, '__iter__')
        
        entries_list = list(entries)
        assert entries_list == []
        
        os.unlink(f.name)


def test_load_iter_handles_large_file():
    """load_iter() should handle large files efficiently."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        # Write 10000 log lines
        for i in range(10000):
            f.write(f'127.0.0.{i % 256} - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n')
        f.flush()
        
        entries = load_iter(f.name)
        
        # Should be able to iterate through all entries
        entries_list = list(entries)
        assert len(entries_list) == 10000
        
        os.unlink(f.name)


def test_load_iter_handles_file_without_trailing_newline():
    """load_iter() should handle files without trailing newline."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326')
        f.flush()
        
        entries = load_iter(f.name)
        
        entries_list = list(entries)
        assert len(entries_list) == 1
        assert entries_list[0].ip == "127.0.0.1"
        
        os.unlink(f.name)


def test_load_iter_handles_multiple_lines_without_trailing_newline():
    """load_iter() should handle multiple lines without trailing newline."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
        f.write('127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET /apache_pb.gif HTTP/1.0" 200 2326\n')
        f.write('10.0.0.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 100')
        f.flush()
        
        entries = load_iter(f.name)
        
        entries_list = list(entries)
        assert len(entries_list) == 2
        assert entries_list[0].ip == "127.0.0.1"
        assert entries_list[1].ip == "10.0.0.1"
        
        os.unlink(f.name)
