"""Tests for output.py - output formatters."""
from datetime import datetime, timezone

from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.parser import LogEntry


def make_entry(**kw):
    """Create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


class TestToJson:
    """Tests for to_json() - JSON output formatter."""

    def test_single_entry(self):
        """Single entry should be formatted as JSON array with one object."""
        entry = make_entry(ip="127.0.0.1", url="/test", status=200, bytes=500)
        result = to_json([entry])
        
        assert '"ip":"127.0.0.1"' in result
        assert '"user":"-"' in result
        assert '"timestamp":"2026-01-01T12:00:00+00:00"' in result
        assert '"method":"GET"' in result
        assert '"url":"/test"' in result
        assert '"protocol":"HTTP/1.1"' in result
        assert '"status":200' in result
        assert '"bytes":500' in result

    def test_multiple_entries(self):
        """Multiple entries should be formatted as JSON array."""
        entries = [
            make_entry(ip="10.0.0.1", url="/a", status=200, bytes=100),
            make_entry(ip="10.0.0.2", url="/b", status=404, bytes=200),
        ]
        result = to_json(entries)
        
        assert result.startswith('[')
        assert result.endswith(']')
        assert '"ip":"10.0.0.1"' in result
        assert '"ip":"10.0.0.2"' in result

    def test_empty_list(self):
        """Empty list should return empty JSON array."""
        result = to_json([])
        assert result == "[]"

    def test_special_characters_in_url(self):
        """URLs with special characters should be properly escaped."""
        entry = make_entry(url='/path?query=value&other=123')
        result = to_json([entry])
        
        assert '"url":"/path?query=value&other=123"' in result

    def test_unicode_in_url(self):
        """URLs with unicode characters should be properly handled."""
        entry = make_entry(url='/path/with/emojis/unicode')
        result = to_json([entry])
        
        assert 'emojis' in result
        assert 'unicode' in result

    def test_bytes_field_zero(self):
        """Bytes field of 0 should be formatted correctly."""
        entry = make_entry(bytes=0)
        result = to_json([entry])
        
        assert '"bytes":0' in result


class TestToCsv:
    """Tests for to_csv() - CSV output formatter."""

    def test_single_entry(self):
        """Single entry should be formatted as CSV with header."""
        entry = make_entry(ip="127.0.0.1", url="/test", status=200, bytes=500)
        result = to_csv([entry])
        
        lines = result.strip().splitlines()  # Use splitlines() to handle \r\n
        assert len(lines) == 2  # Header + data
        
        header = lines[0]
        assert header == "ip,user,timestamp,method,url,protocol,status,bytes"
        
        data = lines[1]
        assert "127.0.0.1" in data
        assert "/test" in data
        assert "200" in data
        assert "500" in data

    def test_multiple_entries(self):
        """Multiple entries should each have their own row."""
        entries = [
            make_entry(ip="10.0.0.1", url="/a", status=200, bytes=100),
            make_entry(ip="10.0.0.2", url="/b", status=404, bytes=200),
        ]
        result = to_csv(entries)
        
        lines = result.strip().splitlines()
        assert len(lines) == 3  # Header + 2 data rows

    def test_empty_list(self):
        """Empty list should return only header."""
        result = to_csv([])
        
        lines = result.strip().splitlines()
        assert len(lines) == 1
        assert lines[0] == "ip,user,timestamp,method,url,protocol,status,bytes"

    def test_timestamp_format(self):
        """Timestamp should be in ISO format."""
        entry = make_entry(timestamp=datetime(2026, 1, 1, 12, 30, 45, tzinfo=timezone.utc))
        result = to_csv([entry])
        
        assert "2026-01-01T12:30:45+00:00" in result

    def test_special_characters_in_url(self):
        """URLs with special characters should be properly quoted."""
        entry = make_entry(url='/path?query=value&other=123')
        result = to_csv([entry])
        
        # CSV should handle the special characters
        assert '/path?query=value&other=123' in result


class TestToText:
    """Tests for to_text() - plain text output formatter."""

    def test_single_entry(self):
        """Single entry should be formatted as readable text."""
        entry = make_entry(ip="127.0.0.1", url="/test", status=200, bytes=500)
        result = to_text([entry])
        
        assert "2026-01-01T12:00:00+00:00" in result
        assert "127.0.0.1" in result
        assert "GET" in result
        assert "200" in result
        assert "/test" in result

    def test_multiple_entries(self):
        """Multiple entries should each have their own line."""
        entries = [
            make_entry(ip="10.0.0.1", url="/a", status=200, bytes=100),
            make_entry(ip="10.0.0.2", url="/b", status=404, bytes=200),
        ]
        result = to_text(entries)
        
        lines = result.strip().split('\n')
        assert len(lines) == 2

    def test_empty_list(self):
        """Empty list should return empty string."""
        result = to_text([])
        assert result == ""

    def test_timestamp_format(self):
        """Timestamp should be in ISO format."""
        entry = make_entry(timestamp=datetime(2026, 1, 1, 12, 30, 45, tzinfo=timezone.utc))
        result = to_text([entry])
        
        assert "2026-01-01T12:30:45+00:00" in result

    def test_method_and_status_in_output(self):
        """Method and status should be in the output."""
        entry = make_entry(method="POST", status=201)
        result = to_text([entry])
        
        assert "POST" in result
        assert "201" in result


class TestRenderAggregate:
    """Tests for render_aggregate() - aggregate result formatter."""

    def test_text_format_with_dict(self):
        """Dict should be formatted as key-value pairs in text format."""
        agg = {"GET": 10, "POST": 5, "DELETE": 2}
        result = render_aggregate(agg, fmt="text")
        
        lines = result.strip().split('\n')
        assert len(lines) == 3
        assert "GET" in result
        assert "10" in result
        assert "POST" in result
        assert "5" in result

    def test_text_format_with_list_of_tuples(self):
        """List of tuples should be formatted as key-value pairs."""
        agg = [("/a", 10), ("/b", 5), ("/c", 2)]
        result = render_aggregate(agg, fmt="text")
        
        lines = result.strip().split('\n')
        assert len(lines) == 3
        assert "/a" in result
        assert "10" in result

    def test_json_format_with_dict(self):
        """Dict should be formatted as JSON object."""
        agg = {"GET": 10, "POST": 5}
        result = render_aggregate(agg, fmt="json")
        
        assert '"GET":10' in result
        assert '"POST":5' in result
        assert result.startswith('{')
        assert result.endswith('}')

    def test_json_format_with_list_of_tuples(self):
        """List of tuples should be formatted as JSON object."""
        agg = [("/a", 10), ("/b", 5)]
        result = render_aggregate(agg, fmt="json")
        
        assert '"/a":10' in result
        assert '"/b":5' in result

    def test_unknown_format_raises_error(self):
        """Unknown format should raise ValueError."""
        agg = {"GET": 10}
        
        try:
            render_aggregate(agg, fmt="unknown")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            assert "unknown format" in str(e)

    def test_empty_dict(self):
        """Empty dict should return empty text output."""
        agg = {}
        result = render_aggregate(agg, fmt="text")
        assert result == ""

    def test_empty_list(self):
        """Empty list should return empty text output."""
        agg = []
        result = render_aggregate(agg, fmt="text")
        assert result == ""

    def test_json_format_empty_dict(self):
        """Empty dict should return empty JSON object."""
        agg = {}
        result = render_aggregate(agg, fmt="json")
        assert result == "{}"

    def test_json_format_empty_list(self):
        """Empty list should return empty JSON object."""
        agg = []
        result = render_aggregate(agg, fmt="json")
        assert result == "{}"
