"""Tests for utils.py - utility functions."""
from datetime import datetime, timezone

import pytest

from logalyzer.parser import LogEntry
from logalyzer.utils import parse_iso_date, format_bytes, format_legacy, chunked


class TestParseIsoDate:
    """Tests for parse_iso_date() - ISO date parsing."""

    def test_parses_basic_date(self):
        """Basic YYYY-MM-DD should be parsed correctly."""
        result = parse_iso_date("2026-01-15")
        assert result.year == 2026
        assert result.month == 1
        assert result.day == 15

    def test_returns_utc_datetime(self):
        """Result should have UTC timezone."""
        result = parse_iso_date("2026-01-15")
        assert result.tzinfo is timezone.utc

    def test_midnight_timestamp(self):
        """Result should be at midnight (00:00:00)."""
        result = parse_iso_date("2026-01-15")
        assert result.hour == 0
        assert result.minute == 0
        assert result.second == 0

    def test_leap_year(self):
        """Leap year dates should be parsed correctly."""
        result = parse_iso_date("2024-02-29")
        assert result.year == 2024
        assert result.month == 2
        assert result.day == 29

    def test_invalid_date_raises_error(self):
        """Invalid date should raise ValueError."""
        with pytest.raises(ValueError):
            parse_iso_date("2026-13-01")  # Invalid month

        with pytest.raises(ValueError):
            parse_iso_date("2026-02-30")  # Invalid day

    def test_invalid_format_raises_error(self):
        """Invalid format should raise ValueError."""
        with pytest.raises(ValueError):
            parse_iso_date("01-15-2026")  # Wrong format

        with pytest.raises(ValueError):
            parse_iso_date("2026/01/15")  # Wrong separator


class TestFormatBytes:
    """Tests for format_bytes() - byte formatting."""

    def test_formats_bytes(self):
        """Bytes should be formatted with B suffix."""
        assert format_bytes(100) == "100.0 B"
        assert format_bytes(1) == "1.0 B"
        assert format_bytes(0) == "0.0 B"

    def test_formats_kilobytes(self):
        """Bytes >= 1024 should be formatted as KB."""
        assert format_bytes(1024) == "1.0 KB"
        assert format_bytes(2048) == "2.0 KB"
        assert format_bytes(1536) == "1.5 KB"

    def test_formats_megabytes(self):
        """Bytes >= 1024*1024 should be formatted as MB."""
        assert format_bytes(1024 * 1024) == "1.0 MB"
        assert format_bytes(2 * 1024 * 1024) == "2.0 MB"
        assert format_bytes(1.5 * 1024 * 1024) == "1.5 MB"

    def test_formats_gigabytes(self):
        """Bytes >= 1024*1024*1024 should be formatted as GB."""
        assert format_bytes(1024 * 1024 * 1024) == "1.0 GB"
        assert format_bytes(2 * 1024 * 1024 * 1024) == "2.0 GB"

    def test_formats_terabytes(self):
        """Bytes >= 1024^4 should be formatted as TB."""
        assert format_bytes(1024 ** 4) == "1.0 TB"
        assert format_bytes(2 * 1024 ** 4) == "2.0 TB"

    def test_formats_petabytes(self):
        """Bytes >= 1024^5 should be formatted as PB."""
        assert format_bytes(1024 ** 5) == "1.0 PB"
        assert format_bytes(2 * 1024 ** 5) == "2.0 PB"

    def test_large_numbers(self):
        """Large numbers should be formatted correctly."""
        assert format_bytes(1024 ** 6) == "1024.0 PB"


class TestFormatLegacy:
    """Tests for format_legacy() - legacy formatter."""

    def test_formats_entry(self):
        """Entry should be formatted as pipe-separated string."""
        entry = LogEntry(
            ip="127.0.0.1",
            user="frank",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="GET",
            url="/test",
            protocol="HTTP/1.1",
            status=200,
            bytes=100,
        )
        result = format_legacy(entry)
        
        # format_legacy only includes ip, timestamp, status, url
        assert "127.0.0.1" in result
        assert "2026-01-01 12:00:00+00:00" in result
        assert "200" in result
        assert "/test" in result
        assert "|" in result

    def test_handles_dash_user(self):
        """Entry with dash user should be formatted correctly."""
        entry = LogEntry(
            ip="127.0.0.1",
            user="-",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="GET",
            url="/test",
            protocol="HTTP/1.1",
            status=200,
            bytes=100,
        )
        result = format_legacy(entry)
        
        assert "127.0.0.1" in result
        assert "-" in result


class TestChunked:
    """Tests for chunked() - chunking generator."""

    def test_chunks_empty_list(self):
        """Empty list should yield no chunks."""
        result = list(chunked([], 3))
        assert result == []

    def test_chunks_single_element(self):
        """Single element should be in one chunk."""
        result = list(chunked([1], 3))
        assert result == [[1]]

    def test_chunks_exact_size(self):
        """List with exact chunk size should yield one chunk."""
        result = list(chunked([1, 2, 3], 3))
        assert result == [[1, 2, 3]]

    def test_chunks_multiple_chunks(self):
        """List with multiple chunks should yield multiple chunks."""
        result = list(chunked([1, 2, 3, 4, 5, 6], 3))
        assert result == [[1, 2, 3], [4, 5, 6]]

    def test_chunks_partial_last_chunk(self):
        """Last chunk should contain remaining elements."""
        result = list(chunked([1, 2, 3, 4, 5], 3))
        assert result == [[1, 2, 3], [4, 5]]

    def test_chunk_size_one(self):
        """Chunk size of 1 should yield single-element chunks."""
        result = list(chunked([1, 2, 3], 1))
        assert result == [[1], [2], [3]]

    def test_chunk_size_larger_than_list(self):
        """Chunk size larger than list should yield one chunk."""
        result = list(chunked([1, 2], 5))
        assert result == [[1, 2]]

    def test_chunks_generator(self):
        """chunked should return a generator."""
        result = chunked([1, 2, 3], 2)
        assert hasattr(result, '__iter__')
        assert hasattr(result, '__next__')

    def test_chunks_preserves_order(self):
        """Chunks should preserve the order of elements."""
        result = list(chunked([1, 2, 3, 4, 5, 6], 2))
        flattened = [item for chunk in result for item in chunk]
        assert flattened == [1, 2, 3, 4, 5, 6]

    def test_chunks_with_strings(self):
        """chunked should work with strings."""
        result = list(chunked("abcdef", 2))
        assert result == [["a", "b"], ["c", "d"], ["e", "f"]]

    def test_chunks_with_mixed_types(self):
        """chunked should work with mixed types."""
        result = list(chunked([1, "a", 2.0, None], 2))
        assert result == [[1, "a"], [2.0, None]]
