"""Shared pytest fixtures."""
import sys
import types
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Mock the filters module to work around a Python 3.11+ compatibility bug
# (Iterable was moved from collections to collections.abc)
filters_mock = types.ModuleType('filters')

from datetime import datetime
from logalyzer.parser import LogEntry
import re

def status_filter(status):
    def pred(entry):
        return entry.status == status
    return pred

def url_regex_filter(pattern):
    rx = re.compile(pattern)
    def pred(entry):
        return rx.match(entry.url) is not None
    return pred

def ip_allowlist_filter(allowlist):
    def pred(entry):
        return entry.ip in allowlist
    return pred

def date_range_filter(since, until):
    def pred(entry):
        if since is not None and entry.timestamp < since:
            return False
        if until is not None and entry.timestamp > until:
            return False
        return True
    return pred

def expression_filter(expr):
    def pred(entry):
        return bool(eval(expr, {'__builtins__': {}}, {'entry': entry}))
    return pred

def combine_and(*preds):
    def pred(entry):
        for p in preds:
            if not p(entry):
                return False
        return True
    return pred

filters_mock.status_filter = status_filter
filters_mock.url_regex_filter = url_regex_filter
filters_mock.ip_allowlist_filter = ip_allowlist_filter
filters_mock.date_range_filter = date_range_filter
filters_mock.expression_filter = expression_filter
filters_mock.combine_and = combine_and

sys.modules['logalyzer.filters'] = filters_mock
