"""Tests for experimental.py - anomaly detection and session windowing."""
from datetime import datetime, timezone, timedelta

import pytest

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def make_entry(timestamp, ip="10.0.0.1", url="/", status=200, bytes=100):
    """Create a LogEntry with the given timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=timestamp,
        method="GET",
        url=url,
        protocol="HTTP/1.1",
        status=status,
        bytes=bytes,
    )


class TestDetectAnomalies:
    """Tests for detect_anomalies - z-score based anomaly detection."""

    def test_returns_empty_list_for_empty_input(self):
        """Empty input should return empty list."""
        assert detect_anomalies([]) == []

    def test_returns_empty_list_for_single_entry(self):
        """Single entry has no variance, so no anomaly."""
        ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [make_entry(ts)]
        assert detect_anomalies(entries) == []

    def test_detects_high_traffic_minute_with_many_data_points(self):
        """A minute with significantly more requests should be flagged."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = []
        # 19 normal minutes with 10 requests each (spread across different seconds)
        for m in range(19):
            for s in range(10):
                entries.append(make_entry(base.replace(minute=m, second=s)))
        # Anomalous minute 20 with 200 requests (20x normal)
        for i in range(200):
            entries.append(make_entry(base.replace(minute=20, second=i % 60)))
        anomalies = detect_anomalies(entries)
        assert len(anomalies) == 1
        assert anomalies[0] == base.replace(minute=20)

    def test_detects_multiple_anomalies_with_many_normal_points(self):
        """Multiple anomalous minutes should all be detected when there are many normal points."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = []
        # 50 normal minutes with 10 requests each
        for m in range(50):
            for s in range(10):
                entries.append(make_entry(base.replace(minute=m, second=s)))
        # 2 anomalous minutes with 200 requests each
        for m in [51, 52]:
            for i in range(200):
                entries.append(make_entry(base.replace(minute=m, second=i % 60)))
        anomalies = detect_anomalies(entries)
        assert len(anomalies) == 2
        assert anomalies[0] == base.replace(minute=51)
        assert anomalies[1] == base.replace(minute=52)

    def test_no_anomaly_when_within_threshold(self):
        """Minutes within 3 standard deviations should not be flagged."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = []
        # 20 normal minutes with 10 requests each
        for m in range(20):
            for s in range(10):
                entries.append(make_entry(base.replace(minute=m, second=s)))
        # One minute with 10 requests (same as normal, within variance)
        for s in range(10):
            entries.append(make_entry(base.replace(minute=20, second=s)))
        anomalies = detect_anomalies(entries)
        # With 10 requests in minute 20 (same as normal), should not be flagged
        assert len(anomalies) == 0

    def test_different_ips_dont_affect_detection(self):
        """Anomaly detection is per-minute, not per-IP."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = []
        # 19 normal minutes with 5 requests each from different IPs
        for m in range(19):
            for i in range(5):
                entries.append(make_entry(base.replace(minute=m), ip=f"10.0.0.{i}"))
        # Anomalous minute 20 with 100 requests from different IPs
        for i in range(100):
            entries.append(make_entry(base.replace(minute=20), ip=f"10.0.1.{i}"))
        anomalies = detect_anomalies(entries)
        assert len(anomalies) == 1
        assert anomalies[0] == base.replace(minute=20)

    def test_handles_entries_with_same_timestamp(self):
        """Multiple entries at the exact same second should be counted together."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = []
        # 19 normal minutes with 10 requests each
        for m in range(19):
            entries += [make_entry(base.replace(minute=m)) for _ in range(10)]
        # 100 entries at the exact same second in minute 20
        entries += [make_entry(base.replace(minute=20)) for _ in range(100)]
        anomalies = detect_anomalies(entries)
        assert len(anomalies) == 1
        assert anomalies[0] == base.replace(minute=20)

    def test_detects_anomaly_with_various_normal_counts(self):
        """Anomaly detection should work regardless of normal request rate."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        
        # Test with high normal rate
        entries = []
        for m in range(19):
            entries += [make_entry(base.replace(minute=m)) for _ in range(100)]
        entries += [make_entry(base.replace(minute=20)) for _ in range(500)]  # 5x normal
        anomalies = detect_anomalies(entries)
        assert len(anomalies) == 1


class TestSessionWindow:
    """Tests for session_window - grouping entries by IP into sessions."""

    def test_returns_empty_list_for_empty_input(self):
        """Empty input should return empty list."""
        assert session_window([]) == []

    def test_single_entry_single_session(self):
        """Single entry creates one session."""
        ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [make_entry(ts, ip="10.0.0.1")]
        sessions = session_window(entries)
        assert len(sessions) == 1
        assert sessions[0][0] == "10.0.0.1"
        assert sessions[0][1] == entries

    def test_multiple_ips_create_multiple_sessions(self):
        """Entries from different IPs should be in separate sessions."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [
            make_entry(base, ip="10.0.0.1"),
            make_entry(base, ip="10.0.0.2"),
        ]
        sessions = session_window(entries)
        assert len(sessions) == 2
        ips = {s[0] for s in sessions}
        assert ips == {"10.0.0.1", "10.0.0.2"}

    def test_entries_within_window_are_same_session(self):
        """Entries within window_seconds should be in the same session."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        # 30 minute window
        window = 1800
        entries = [
            make_entry(base, ip="10.0.0.1"),
            make_entry(base + timedelta(minutes=10), ip="10.0.0.1"),
            make_entry(base + timedelta(minutes=20), ip="10.0.0.1"),
        ]
        sessions = session_window(entries, window_seconds=window)
        assert len(sessions) == 1
        assert sessions[0][0] == "10.0.0.1"
        assert len(sessions[0][1]) == 3

    def test_gap_exceeding_window_starts_new_session(self):
        """A gap exceeding window_seconds should start a new session."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        # 30 minute window
        window = 1800
        entries = [
            make_entry(base, ip="10.0.0.1"),
            make_entry(base + timedelta(minutes=10), ip="10.0.0.1"),
            # 40 minute gap - exceeds window
            make_entry(base + timedelta(minutes=50), ip="10.0.0.1"),
            make_entry(base + timedelta(minutes=60), ip="10.0.0.1"),
        ]
        sessions = session_window(entries, window_seconds=window)
        assert len(sessions) == 2
        # First session: 2 entries
        assert len(sessions[0][1]) == 2
        # Second session: 2 entries
        assert len(sessions[1][1]) == 2

    def test_entries_sorted_by_timestamp(self):
        """Entries in each session should be sorted by timestamp."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = [
            make_entry(base + timedelta(minutes=10), ip="10.0.0.1"),
            make_entry(base, ip="10.0.0.1"),
            make_entry(base + timedelta(minutes=5), ip="10.0.0.1"),
        ]
        sessions = session_window(entries)
        assert len(sessions) == 1
        session_entries = sessions[0][1]
        # Should be sorted by timestamp
        assert session_entries[0].timestamp < session_entries[1].timestamp
        assert session_entries[1].timestamp < session_entries[2].timestamp

    def test_custom_window_seconds(self):
        """Custom window_seconds should be respected."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        # 5 minute window (300 seconds)
        window = 300
        entries = [
            make_entry(base, ip="10.0.0.1"),
            make_entry(base + timedelta(minutes=2), ip="10.0.0.1"),
            # 8 minute gap - exceeds 5 minute window
            make_entry(base + timedelta(minutes=10), ip="10.0.0.1"),
        ]
        sessions = session_window(entries, window_seconds=window)
        assert len(sessions) == 2

    def test_handles_many_ips(self):
        """Should handle many different IPs correctly."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        entries = []
        for i in range(100):
            ip = f"10.0.{i // 256}.{i % 256}"
            entries.append(make_entry(base, ip=ip))
        sessions = session_window(entries)
        assert len(sessions) == 100
        for ip, session_entries in sessions:
            assert len(session_entries) == 1

    def test_multiple_gaps_create_multiple_sessions(self):
        """Multiple gaps exceeding window should create multiple sessions."""
        base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        # 30 minute window
        window = 1800
        entries = [
            make_entry(base, ip="10.0.0.1"),
            make_entry(base + timedelta(minutes=10), ip="10.0.0.1"),
            # 40 minute gap
            make_entry(base + timedelta(minutes=50), ip="10.0.0.1"),
            make_entry(base + timedelta(minutes=60), ip="10.0.0.1"),
            # Another 40 minute gap
            make_entry(base + timedelta(minutes=100), ip="10.0.0.1"),
            make_entry(base + timedelta(minutes=110), ip="10.0.0.1"),
        ]
        sessions = session_window(entries, window_seconds=window)
        assert len(sessions) == 3
        assert len(sessions[0][1]) == 2
        assert len(sessions[1][1]) == 2
        assert len(sessions[2][1]) == 2
