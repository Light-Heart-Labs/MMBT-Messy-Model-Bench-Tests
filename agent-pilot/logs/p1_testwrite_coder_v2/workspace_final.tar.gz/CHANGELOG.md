# Changelog

## [0.1.0] - 2024-04-28

### Added Tests

#### test_experimental.py (17 tests)
- Tests for `detect_anomalies()`:
  - Empty input handling
  - Single entry handling
  - High traffic minute detection
  - Multiple anomalies detection
  - Threshold boundary conditions
  - IP distribution independence
  - Same timestamp handling
  - Various normal count rates

- Tests for `session_window()`:
  - Empty input handling
  - Single entry handling
  - Multiple IP handling
  - Window boundary conditions
  - Timestamp sorting
  - Custom window seconds
  - Many IPs handling
  - Multiple gaps handling

#### test_io.py (15 tests)
- Tests for `load()`:
  - Returns list of entries
  - Empty file handling
  - Whitespace-only file handling
  - Mixed valid/invalid lines
  - No trailing newline handling
  - Dash for zero bytes
  - Unicode URL handling

- Tests for `load_iter()`:
  - Returns generator
  - Empty file handling
  - Mixed valid/invalid lines
  - Memory efficiency
  - Large file handling
  - No trailing newline handling

#### test_output.py (25 tests)
- Tests for `to_json()`:
  - Single entry formatting
  - Multiple entries formatting
  - Empty list handling
  - Special characters in URL
  - Unicode in URL
  - Bytes field of zero

- Tests for `to_csv()`:
  - Single entry formatting
  - Multiple entries formatting
  - Empty list handling
  - Timestamp format
  - Special characters in URL

- Tests for `to_text()`:
  - Single entry formatting
  - Multiple entries formatting
  - Empty list handling
  - Timestamp format
  - Method and status in output

- Tests for `render_aggregate()`:
  - Dict formatting (text/json)
  - List of tuples formatting (text/json)
  - Unknown format error handling
  - Empty dict/list handling

#### test_utils.py (26 tests)
- Tests for `parse_iso_date()`:
  - Basic date parsing
  - UTC timezone
  - Midnight timestamp
  - Leap year handling
  - Invalid date handling
  - Invalid format handling

- Tests for `format_bytes()`:
  - Bytes formatting
  - Kilobytes formatting
  - Megabytes formatting
  - Gigabytes formatting
  - Terabytes formatting
  - Petabytes formatting
  - Large numbers

- Tests for `format_legacy()`:
  - Entry formatting
  - Dash user handling

- Tests for `chunked()`:
  - Empty list handling
  - Single element handling
  - Exact size chunks
  - Multiple chunks
  - Partial last chunk
  - Chunk size of 1
  - Large chunk size
  - Generator behavior
  - Order preservation
  - String handling
  - Mixed types

#### test_cli.py (26 tests)
- Tests for `build_parser()`:
  - Paths argument
  - Status filter
  - URL filter
  - IP filter (single and multiple)
  - Since/Until filters
  - Expression filter
  - Aggregate options
  - Top option
  - Format option
  - Default format

- Tests for `main()`:
  - Valid log file processing
  - Empty log file handling
  - JSON format output
  - CSV format output
  - Status filter
  - URL filter
  - IP filter
  - Aggregate status/url/hour
  - Top option
  - Multiple files
  - Expression filter
  - Return value

### Coverage Improvement

| Module | Before | After | Delta |
|--------|--------|-------|-------|
| `logalyzer/__init__.py` | 100% | 100% | 0% |
| `logalyzer/aggregate.py` | 100% | 100% | 0% |
| `logalyzer/cli.py` | 0% | 97% | +97% |
| `logalyzer/experimental.py` | 0% | 100% | +100% |
| `logalyzer/filters.py` | 0% | 0% | 0% |
| `logalyzer/io.py` | 0% | 100% | +100% |
| `logalyzer/output.py` | 0% | 100% | +100% |
| `logalyzer/parser.py` | 86% | 86% | 0% |
| `logalyzer/utils.py` | 0% | 100% | +100% |
| **TOTAL** | **24%** | **84%** | **+60%** |

### Known Issues

3 baseline tests fail due to bugs in the codebase (not fixed per requirements):

1. `test_status_filter_works_with_cli_string_input`: The `status_filter()` function doesn't handle string status codes from CLI (compares int vs string directly).

2. `test_url_regex_finds_substring_match`: The `url_regex_filter()` function uses `re.match()` which only matches at the beginning of the string, not substring matching as expected.

3. `test_timestamp_july_parses_correctly`: The `MONTH_NAMES` list in `parser.py` is missing "Jul", causing `parse_timestamp()` to raise `ValueError` for July dates.

These issues are documented in `decisions/001-bugs-found.md`.

### Files Added

- `tests/test_experimental.py`
- `tests/test_io.py`
- `tests/test_output.py`
- `tests/test_utils.py`
- `tests/test_cli.py`
- `decisions/001-bugs-found.md`
- `research/notes/`
- `research/questions.md`
- `research/dead-ends.md`
