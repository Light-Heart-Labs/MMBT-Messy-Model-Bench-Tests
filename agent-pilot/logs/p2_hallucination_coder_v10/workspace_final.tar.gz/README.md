# Triage Output

This directory contains the results of verifying the 15 issues in `issue_report.md` against the actual logalyzer codebase.

## Files

- **triage.json** - Required output. Contains verdicts for each issue (real/fabricated) with evidence citations.
- **notes.md** - Additional reasoning that didn't fit in the JSON.
- **decisions/** - ADRs for borderline or non-obvious calls.

## Summary

- **Real issues**: 6 (001, 002, 004, 006, 013, 014)
- **Fabricated issues**: 9 (003, 005, 007, 008, 009, 010, 011, 012, 015)
