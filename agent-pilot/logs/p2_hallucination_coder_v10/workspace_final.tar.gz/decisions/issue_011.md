# Decision: Issue 011 is Fabricated

## Issue Claim
The report claims `by_status()` in `aggregate.py` double-counts 3xx redirects when called with chained iterators.

## Verification
- `by_status()` simply iterates through entries and increments `c[e.status] += 1`
- There is no special handling for 3xx status codes
- The Counter correctly counts each entry once by its status code
- No deduplication logic is needed or expected for this function

## Verdict
Fabricated - the function works as designed and doesn't double-count entries.
