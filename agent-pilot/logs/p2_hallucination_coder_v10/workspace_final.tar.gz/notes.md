# Triage Notes

## Issue 001 - Real
The import `from collections import Iterable` on line 5 of `filters.py` is indeed deprecated. In Python 3.10+, this raises `ImportError`. Should be `from collections.abc import Iterable`.

## Issue 002 - Real
The `expression_filter()` function uses `eval()` with restricted builtins, but even with `{"__builtins__": {}}`, `eval()` can still access attributes and trigger expensive operations via the `entry` object. A safer approach would be a proper expression parser.

## Issue 004 - Real
README.md claims "Real-time tail mode for live log streams" but there's no `--tail` flag and no streaming logic in the codebase. This is a documentation mismatch.

## Issue 006 - Real
`experimental.py` exists but is not imported by any other module in the codebase. It contains `detect_anomalies()` and `session_window()` functions that are not wired into the CLI.

## Issue 013 - Real
The `load()` function in `io.py` uses:
- `result = result + [entry]` (line 17, 27) - creates new list each iteration, O(n²)
- `accumulated += ch` (line 24) - string concatenation in loop, O(n²)

Both patterns are inefficient for large files.

## Issue 014 - Real
The `ip_allowlist_filter()` function uses `entry.ip in allowlist` where `allowlist` is typically a list passed from `args.ip` (via argparse with `action="append"`). For lists with many entries, this is O(n) per check. Converting to a set would give O(1) membership tests.

## Fabricated Issues Summary

- **003**: No SQL code exists
- **005**: `--top` flag is correctly implemented
- **007**: No `web.py` file
- **008**: No 8192-char truncation
- **009**: `format_legacy()` is in `utils.py`, not `output.py`
- **010**: No race condition in the function itself
- **011**: No double-counting logic
- **012**: No `cache.py` file
- **015**: `__init__.py` doesn't import `LogEntry`
