# Project Lighthouse — Executive Committee Review

## Overview

This package contains the executive committee review for the acquisition of Borealis Analytics, Inc. ("Borealis") as outlined in the deal pack (`/input/repo/deal_pack.md`).

## Files

| File | Purpose |
|------|---------|
| `memo.md` | 1-page memo (≤700 words) with recommendation, concerns, and diligence asks |
| `concerns.md` | Detailed enumeration of all concerns with the deal pack |
| `asks.md` | 2-week diligence ask list (specific questions, owners, deadlines) |
| `decisions/` | ADRs (architectural decision records) for key judgment calls |
| `README.md` | This file |

## Recommendation Summary

- **Stance:** HOLD (do not proceed to LOI at this time)
- **Conditions to change to PROCEED:**
  1. Cash flow statement confirms cash collected ≥ GAAP revenue
  2. Cohort-level retention data shows logo retention ≥95% across cohorts
  3. Synergy estimate is validated with detailed breakdown
  4. Customer migration fallback plan exists if integration slips

## Next Steps

1. Review `memo.md` for the executive summary.
2. If you want depth, read `concerns.md` for the full list of issues.
3. If you want actionability, read `asks.md` for the 2-week diligence plan.
4. If you want to understand the reasoning, read the ADRs in `decisions/`.

## Release

Tag: `v1.0.0` — Executive Committee Review Complete
