# Diligence Asks — Project Lighthouse (Borealis Analytics)

**Owner:** Corp Dev team  
**Deadline:** 2 weeks from today (by 2026-04-29)

---

## 1. Cash Flow & Revenue Quality

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide a 12-month cash flow statement (operating, investing, financing) for FY2025 and Q1 FY2026. Break down cash collected vs. GAAP revenue recognized. | Corp Dev / Finance | 2026-04-25 |
| Share the customer contract schedule (anonymized): contract terms, renewal dates, payment schedules, and early-termination clauses for the top 20 customers. | Corp Dev | 2026-04-25 |

## 2. Customer Retention & Concentration

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide cohort-level retention data: logo retention, net retention, and expansion revenue by customer cohort (e.g., FY2024 signups, FY2025 signups). | Corp Dev / Product | 2026-04-25 |
| List all customers with contracts >$100K ARR and their renewal dates in the next 12 months. | Corp Dev | 2026-04-25 |
| Share the results of the 1 customer reference call that did *not* consent to be quoted (e.g., reasons for non-response, if any feedback was given). | Corp Dev | 2026-04-25 |

## 3. Tech & Product Deep Dive

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide engineering metrics: test coverage %, CI/CD pass rate, mean time to recovery (MTTR), and security audit results (SOC 2 or equivalent). | Corp Dev / Eng | 2026-04-26 |
| Share a high-level architecture diagram of Aurora and a list of third-party integrations (with SLAs). | Corp Dev / Eng | 2026-04-26 |
| Provide the product roadmap for the next 12 months, including features planned for post-close integration. | Corp Dev / Product | 2026-04-26 |

## 4. Integration & Synergy Validation

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide a detailed integration plan with milestones, dependencies, and risk mitigation for each phase (infrastructure, data, product, org). | Corp Dev / Integration Lead | 2026-04-27 |
| Break down the $3.2M synergy estimate: infrastructure savings, headcount overlap, and license consolidation. Include sensitivity analysis (±20%). | Corp Dev / Finance | 2026-04-27 |
| Share retention agreements or incentives for the top 5 engineering hires and the CTO. | Corp Dev / HR | 2026-04-27 |

## 5. Growth & Pipeline

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide FY2026 revenue guidance (board-approved) and pipeline coverage (committed, best case, upside) by quarter. | Corp Dev / Finance | 2026-04-28 |
| Share the sales team structure: quota-carrying reps, average deal size, sales cycle length, and win rate. | Corp Dev / Sales | 2026-04-28 |
| Provide churn analysis: reasons for churn in FY2025, and whether any were due to product, pricing, or support issues. | Corp Dev / Product | 2026-04-28 |

## 6. Legal & Compliance

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide a summary of open litigation, IP ownership documentation, and data privacy compliance (GDPR, CCPA). | Corp Dev / Legal | 2026-04-29 |
| Share the cap table and most recent 409A valuation. | Corp Dev / Finance | 2026-04-29 |

---

**Note:** These asks are designed to address the top concerns identified in the memo. If any ask cannot be fulfilled, flag it immediately with explanation.
