# Executive Committee Review — Project Lighthouse (Borealis Analytics)

**Date:** 2026-04-17  
**Prepared for:** Executive Committee  
**Recommendation:** **HOLD** — Do not proceed to LOI at this time.

---

## Recommendation

I recommend **HOLD**. The deal pack is compelling but incomplete. It presents a one-sided, advocacy-oriented narrative that overstates strategic fit and underexplains financial and customer risks. Before committing to an LOI at $84M, we need two weeks of targeted diligence to validate the pack’s key claims.

**Conditions to change stance to PROCEED:**
1. **Cash flow clarity:** Cash collected ≥ GAAP revenue (no material lag).
2. **Retention transparency:** Cohort-level logo retention ≥95% across all cohorts; no single customer >15% of ARR.
3. **Synergy validation:** $3.2M annual savings broken down and tied to integration milestones.
4. **Migration fallback:** Plan for Aurora customers if integration slips beyond 12 months.

If any of these conditions are unmet, I recommend PASS.

---

## Strongest Concerns

**1. Revenue vs. Cash Mismatch.** The pack reports $9.2M GAAP revenue but omits cash flow data. Early-stage SaaS companies often recognize revenue upfront while cash collection lags. Without cash flow data, we cannot assess whether Borealis is burning cash despite "strong" revenue growth. Per the financials table, the $4.1M cash on hand and $750K burn rate imply 22 months of runway — but if cash collection lags, this runway may be overstated.

**2. Net vs. Logo Retention Discrepancy.** Net retention (118%) and logo retention (91%) are a 27-point spread for only 280 customers. This suggests a few large customers drive expansion while the majority churn. The pack does not provide cohort-level data to validate this. If the top 5–10 customers represent >50% of ARR, the business is highly concentrated and vulnerable.

**3. Customer Testimonial Selection Bias.** The pack quotes 4 of 5 top customers who *agreed* to be quoted. We do not know why the 1 customer declined or whether negative experiences led to non-response or churn. This is a classic advocacy-document flaw: only happy customers are quoted.

**4. Integration Over-Optimism.** The pack claims a 4–6 month integration timeline and 85% retention. It does not address cultural or technical friction (e.g., Python + Postgres + dbt vs. our stack) or customer migration risk. If integration slips beyond 12 months, what happens to Aurora customers? No fallback plan is mentioned.

---

## Diligence Asks (Next 2 Weeks)

To de-risk the deal, I propose the following targeted asks (detailed in `/workspace/asks.md`):

1. **Cash flow statement** for FY2025 and Q1 FY2026, with cash collected vs. GAAP revenue.
2. **Cohort-level retention data** (logo, net, expansion) and customer contract schedule (top 20).
3. **Engineering metrics**: test coverage %, CI/CD pass rate, MTTR, security audit results.
4. **Integration plan** with milestones, synergy breakdown ($3.2M), and retention agreements for top 5 engineers/CTO.

If these asks cannot be fulfilled, we should PASS.

---

## Conclusion

The deal pack is well-written but not balanced. It presents Borealis as a "clean" financial and strategic fit, but omits critical data on cash flow, customer concentration, and integration risk. A HOLD preserves optionality and allows us to conduct focused diligence before committing to an LOI. If the next two weeks confirm the pack’s claims, I am open to PROCEEDING. If not, we walk away.
