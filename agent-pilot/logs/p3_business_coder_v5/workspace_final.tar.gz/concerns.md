# Concerns with the Deal Pack — Project Lighthouse (Borealis Analytics)

## 1. Overstated Strategic Rationale

- **Claim:** "Borealis would extend our analytics surface area into mid-market e-commerce, a segment we currently service only via partner integrations."
- **Concern:** The pack does not clarify whether our current partner integrations are *effective* or *underperforming*. If our partners are failing to serve this segment, Borealis may inherit those same challenges. The pack presents the opportunity as "greenfield" when it may be "troubled."
- **Omission:** No data on our current partner revenue from the mid-market e-commerce segment or churn rates among those partners.

## 2. Revenue Recognition vs. Cash Collection

- **Claim:** Revenue (recognized GAAP) $9.2M in FY2025.
- **Concern:** The pack does not distinguish between recognized GAAP revenue and cash collected. Early-stage SaaS companies often recognize revenue upfront for annual contracts, but cash collection lags. Without cash flow data, we cannot assess whether Borealis is burning cash despite "strong" revenue growth.
- **Risk:** If cash collection lags significantly, the $4.1M cash on hand may not provide the 22 months of runway implied by the $750K burn rate.

## 3. Net Retention vs. Logo Retention Discrepancy

- **Claim:** Net retention 118%, Logo retention 91%.
- **Concern:** A 27-point spread between net and logo retention is unusually high for a company with only 280 customers. This suggests a few large customers are driving almost all expansion, while the majority of customers are churning. The pack does not provide cohort-level data to validate this.
- **Risk:** If the top 5–10 customers represent >50% of ARR, the business is highly concentrated and vulnerable to single-customer churn.

## 4. Customer Testimonials — Selection Bias

- **Claim:** 4 of 5 top customers willing to be quoted, NPS in the high 40s.
- **Concern:** The pack only quotes customers who *agreed* to be quoted. This is selection bias. We do not know the response rate or whether negative experiences led to non-response or churn.
- **Omission:** No data on why the 1 customer declined to be quoted or whether any of the 4 quoted customers have contracts expiring soon.

## 5. Integration Plan — Overly Optimistic

- **Claim:** 4–6 month full integration timeline, ~85% retention expected.
- **Concern:** The pack does not address potential cultural or operational friction. Borealis is a Python + Postgres + dbt shop; our current stack may differ. Engineering teams often underestimate integration complexity.
- **Omission:** No mention of customer migration risk. If Aurora is sunset in 12 months, what happens if the integration slips beyond that? Are there fallback plans?

## 6. Valuation — Missing Growth Context

- **Claim:** Borealis at ~7.4x ARR, in line with comps.
- **Concern:** The comps (Hexa, Aspen, Trellis) are all acquired by *strategic* buyers (Salesforce, Snowflake, HubSpot) who pay a control premium. Our company is not a strategic buyer in the same sense. The pack does not adjust for control vs. minority premium.
- **Omission:** Borealis' growth rate may be decelerating. FY2025 revenue grew 80% YoY, but we don't know FY2026 growth expectations or current pipeline coverage.

## 7. Tech Debt — "Clean" is Subjective

- **Claim:** Codebase is "modern Python + Postgres + dbt" — clean, well-tested.
- **Concern:** "Clean" is not a technical term. The pack does not provide metrics: test coverage %, CI/CD pass rate, mean time to production, or security audit results. Engineering review found "no concerning patterns" — but what patterns were reviewed?
- **Risk:** A "clean" codebase can still have scalability or data governance issues that surface post-integration.

## 8. Burn Rate and Runway — Ambiguity

- **Claim:** Burn rate $750K/month, 22 months runway.
- **Concern:** Burn rate is "average monthly" — is this operating cash burn only, or does it include capex? Is it GAAP or non-GAAP? The pack does not specify.
- **Risk:** If burn includes one-time costs (e.g., legal, severance), runway may be overstated.

## 9. Synergy Estimate — Unsubstantiated

- **Claim:** $3.2M annual cost savings from consolidated infra.
- **Concern:** No breakdown of how this $3.2M is calculated. Is it infrastructure, headcount, or license savings? Has a detailed integration finance team validated this?
- **Omission:** No sensitivity analysis. What if integration delays push synergy capture to Year 2 or Year 3?

## 10. LOI Deadline Pressure

- **Claim:** Decision needed by 2026-04-30.
- **Concern:** The pack is dated 2026-04-15, giving only 2 weeks for executive committee review. Given the concerns above, this timeline may not allow sufficient time for thorough diligence.
- **Risk:** Rushed decision-making may lead to overlooking critical issues.
