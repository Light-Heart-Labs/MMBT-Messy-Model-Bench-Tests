# ADR-0001: Why Split output.py

## Status

Accepted

## Context

The `logalyzer/output.py` module mixed four distinct concerns:

1. **JSON serialization** (`to_json`) — hand-crafted JSON string building for log entries
2. **CSV serialization** (`to_csv`) — CSV output using the `csv` stdlib module
3. **Plain-text formatting** (`to_text`) — human-readable line-based output
4. **Aggregate rendering** (`render_aggregate`) — multi-format rendering for aggregation results
5. **Legacy formatting** (`format_legacy`) — backwards-compat shim for v0.1 CLI output

This accretion made the module harder to navigate, test, and evolve. Each concern has different dependencies (e.g., `csv` is only needed by CSV rendering), different usage patterns, and different evolution trajectories.

## Decision

Split `logalyzer/output.py` into a `logalyzer/output/` package with one module per concern:

| Module | Contents |
|--------|----------|
| `json_renderer.py` | `to_json()` |
| `csv_renderer.py` | `to_csv()` |
| `plain_renderer.py` | `to_text()`, `render_aggregate()` |
| `legacy.py` | `format_legacy()` |
| `__init__.py` | Re-exports all public API |

## Consequences

- **Positive**: Each module has a single, clear responsibility. Dependencies are scoped (e.g., `csv` import only in `csv_renderer.py`). New output formats can be added as new modules without touching existing ones.
- **Neutral**: The public API surface is unchanged. All existing imports continue to work via `__init__.py` re-exports.
- **Negative**: Slightly more files to maintain, but the trade-off is worth it for clarity.

## Alternatives Considered

- **Keep as single file**: Would avoid the refactor but perpetuate the accretion problem.
- **Add a `renderers.py` module**: Would group all renderers together but still mix concerns.
- **Use a factory/registry pattern**: Overkill for a small CLI tool; adds unnecessary indirection.
