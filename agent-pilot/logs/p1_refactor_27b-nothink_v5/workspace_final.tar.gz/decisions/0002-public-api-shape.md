# ADR-0002: Public API Shape

## Status

Accepted

## Context

The `logalyzer/output` package must maintain full backward compatibility. Any code that imports from `logalyzer.output` must continue to work without modification.

## Decision

The `logalyzer/output/__init__.py` re-exports exactly these symbols:

| Symbol | Source Module | Used By |
|--------|--------------|---------|
| `to_json` | `json_renderer.py` | `cli.py` |
| `to_csv` | `csv_renderer.py` | `cli.py` |
| `to_text` | `plain_renderer.py` | `cli.py` |
| `render_aggregate` | `plain_renderer.py` | `cli.py` |
| `format_legacy` | `legacy.py` | External scripts (backwards compat) |

### Why `render_aggregate` goes in `plain_renderer.py`

`render_aggregate` is a general-purpose renderer that supports text, json, and csv formats for aggregate data (Counters, dicts, lists). It was placed in `plain_renderer.py` because:

1. Its default format is "text"
2. It's the most general rendering function (handles multiple data types)
3. It doesn't fit cleanly into JSON or CSV modules since it supports all three formats
4. It's conceptually a "plain text renderer" that happens to support alternative output formats

### Why `format_legacy` is in `legacy.py`

`format_legacy` is a backwards-compatibility shim for the v0.1 CLI output format. It was placed in its own `legacy.py` module because:

1. It's not used internally by the current codebase
2. It exists solely for external scripts that may depend on the old format
3. Isolating it makes it clear that it's deprecated and not part of the active API
4. It can be removed in a future major version without affecting other modules

### Import Compatibility

The `__init__.py` uses direct imports from submodules:

```python
from .json_renderer import to_json
from .csv_renderer import to_csv
from .plain_renderer import to_text, render_aggregate
from .legacy import format_legacy
```

This ensures that `from logalyzer.output import X` works for all public symbols, matching the behavior of the original `output.py` module.

## Consequences

- All existing call sites in `cli.py` continue to work without modification
- External scripts importing `format_legacy` from `logalyzer.output` continue to work
- The `__all__` list documents the complete public API surface
