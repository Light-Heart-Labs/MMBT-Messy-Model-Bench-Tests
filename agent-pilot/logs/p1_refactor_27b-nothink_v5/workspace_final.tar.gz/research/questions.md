# Questions and Resolutions

## Q1: Where does `format_legacy` live?

**Question**: The task description says `format_legacy` is in `output.py`, but it's actually in `utils.py`. Should I move it from `utils.py`?

**Resolution**: The task says "Only `logalyzer/output.py` may be split" and "Don't change unrelated code." Since `utils.py` is unrelated, I left it unchanged. I created a new `format_legacy` in `output/legacy.py` that produces identical output. The verification check `from logalyzer.output import format_legacy` works via the `__init__.py` re-export.

## Q2: Where does `render_aggregate` belong?

**Question**: `render_aggregate` supports text, json, and csv formats. Which module should it go in?

**Resolution**: Placed in `plain_renderer.py` because its default format is "text" and it's the most general rendering function. It doesn't fit cleanly into a single-format module.

## Q3: Should I fix the pre-existing bugs?

**Question**: The codebase has two pre-existing bugs: `collections.Iterable` import error and missing "Jul" in `MONTH_NAMES`.

**Resolution**: No. The task explicitly says "No bug fixes. If you encounter a bug, document it in `dead-ends.md` but don't fix it." These are documented in `dead-ends.md`.

## Q4: Should I modify `cli.py`?

**Question**: `cli.py` imports from `logalyzer.output`. Does it need changes?

**Resolution**: No. The `__init__.py` re-exports all the same symbols, so `cli.py`'s imports work without modification.
