# Dead Ends

## Pre-existing Bug: `collections.Iterable` Import Error

**File**: `logalyzer/filters.py`, line 5

**Issue**: `from collections import Iterable` fails on Python 3.11 because `Iterable` was moved to `collections.abc` in Python 3.3 and removed from `collections` in Python 3.9+.

**Impact**: `test_filters.py` fails to collect. The CLI also fails to start because `cli.py` imports from `filters.py`.

**Resolution**: Documented but NOT fixed. The task explicitly says "No bug fixes." This is a pre-existing issue in the codebase.

## Pre-existing Bug: Missing "Jul" in MONTH_NAMES

**File**: `logalyzer/parser.py`, line 28-31

**Issue**: The `MONTH_NAMES` list skips "Jul":
```python
MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Aug", "Sep", "Oct", "Nov", "Dec",
]
```

**Impact**: `test_parser.py::test_timestamp_july_parses_correctly` fails with `ValueError: 'Jul' is not in list`. Any log entries with July timestamps will fail to parse.

**Resolution**: Documented but NOT fixed. The task explicitly says "No bug fixes." This is a pre-existing issue in the codebase.

## Approach Considered: Moving `format_legacy` from `utils.py`

**Approach**: Initially considered moving `format_legacy` from `utils.py` to `output/legacy.py` and removing it from `utils.py`.

**Why Reverted**: The task says "Only `logalyzer/output.py` may be split" and "Don't change unrelated code." Modifying `utils.py` would violate this constraint. Instead, I created a duplicate definition in `output/legacy.py` that produces identical output.

## Approach Considered: Putting `render_aggregate` in its own module

**Approach**: Considered creating a separate `aggregate_renderer.py` module for `render_aggregate`.

**Why Rejected**: The task specifies exactly 4 modules (json, csv, plain, legacy). Adding a 5th module would exceed the spec. `render_aggregate` was placed in `plain_renderer.py` as the best fit.
