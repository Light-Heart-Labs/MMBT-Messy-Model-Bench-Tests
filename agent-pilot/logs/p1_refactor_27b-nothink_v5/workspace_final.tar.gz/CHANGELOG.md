# CHANGELOG

## v0.3.1 — Refactor: Split `output.py` into `output/` Package

### What Changed

The monolithic `logalyzer/output.py` module was split into a focused `logalyzer/output/` package:

**Before:**
```
logalyzer/
  output.py          # Mixed: JSON, CSV, plain text, aggregate rendering
```

**After:**
```
logalyzer/
  output/
    __init__.py         # Re-exports public API
    json_renderer.py    # to_json()
    csv_renderer.py     # to_csv()
    plain_renderer.py   # to_text(), render_aggregate()
    legacy.py           # format_legacy()
```

### What Moved Where

| Function | Old Location | New Location |
|----------|-------------|--------------|
| `to_json` | `output.py` | `output/json_renderer.py` |
| `to_csv` | `output.py` | `output/csv_renderer.py` |
| `to_text` | `output.py` | `output/plain_renderer.py` |
| `render_aggregate` | `output.py` | `output/plain_renderer.py` |
| `format_legacy` | `utils.py` | `output/legacy.py` (new definition; original in `utils.py` unchanged) |

### Why

- Each module now has a single, clear responsibility
- Dependencies are scoped (e.g., `csv` import only in `csv_renderer.py`)
- New output formats can be added as new modules without touching existing ones
- The legacy `format_legacy` function is isolated, making it clear it's deprecated

### Backward Compatibility

All existing imports continue to work:
- `from logalyzer.output import to_json, to_csv, to_text, render_aggregate` ✓
- `from logalyzer.output import format_legacy` ✓
- `cli.py` imports work without modification ✓

### Verification Results

1. **`pytest -q`**: 11 tests collected, 1 pre-existing failure (`test_timestamp_july_parses_correctly`), 1 pre-existing collection error (`test_filters.py` — `collections.Iterable` import). Same results as original codebase.

2. **`python -c "from logalyzer.output import format_legacy; print(format_legacy)"`**: Works correctly, prints `<function format_legacy at 0x...>`.

3. **`git diff /input/repo/tests /workspace/tests`**: Empty — no test files were modified.

4. **Non-output file diffs**: All non-output files (`parser.py`, `utils.py`, `cli.py`, `filters.py`, `aggregate.py`, `io.py`, `experimental.py`, `__init__.py`) are byte-identical to the original.

### Pre-existing Issues (Not Fixed)

- `filters.py`: `from collections import Iterable` fails on Python 3.9+ (moved to `collections.abc`)
- `parser.py`: `MONTH_NAMES` list is missing "Jul", causing July timestamps to fail parsing

These are documented in `research/dead-ends.md` and are out of scope for this refactor.
