# ADR 001: Company Selection

**Date:** 2024-10-01  
**Status:** Approved  
**Author:** AI Analyst

## Decision
Select **DocuSign, Inc. (DOCU)** as the investment target.

## Rationale
- Market cap: ~$8.5B (within $1B-$10B range)
- Clear digital signature market leadership with expanding product suite
- Transitioning from transactional to subscription model
- Strong enterprise customer base with recurring revenue potential
- Growing AI/automation opportunities in document workflow space

## Alternatives Considered
1. **UiPath (PATH)**: Strong RPA leader but facing competitive pressure and profitability challenges
2. **Palo Alto Networks (PANW)**: Larger market cap (~$70B), outside target range
3. **Snowflake (SNOW)**: Larger market cap (~$90B), outside target range

## Notes
DocuSign offers a compelling mix of market leadership, transition potential, and reasonable valuation. The company's pivot toward AI-powered document intelligence provides an interesting growth vector.
