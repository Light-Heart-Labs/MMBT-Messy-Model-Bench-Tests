# Extraction Notes

## General Observations
- The press release is from Veridyne Networks, Inc. (NASDAQ: VRDN) for Q3 FY2026 ended February 28, 2026.
- All financial figures are reported in USD millions unless otherwise specified.
- The press release includes both GAAP and Non-GAAP metrics. We extracted only the Non-GAAP operating income as specified in the schema.

## Field-Specific Notes

### Uncertain Fields
- `cash_and_short_term_investments_usd_millions`: Not explicitly requested in schema.
- `net_cash_from_operating_activities_usd_millions`: Not explicitly requested in schema.

### Ambiguities Handled
- `total_arr_usd_millions`: Press release states "exceeded $710 million". We used `710` as the lower bound figure per schema notes.
- `revenue_yoy_growth_pct`: Stated as "38%" — extracted as integer `38` per schema acceptance of whole numbers.

### Forward-Looking Statements
- Guidance fields (`fy2026_revenue_guidance_low_*`, `fy2026_revenue_guidance_high_*`) were explicitly allowed per instructions.
- Other forward-looking statements (e.g., future FedRAMP High authorization) were not extracted as they are not in the schema.

### Sign Convention
- The schema asks for `non_gaap_operating_income_usd_millions` (positive income), not loss. We extracted the positive value `9.8` as stated.
