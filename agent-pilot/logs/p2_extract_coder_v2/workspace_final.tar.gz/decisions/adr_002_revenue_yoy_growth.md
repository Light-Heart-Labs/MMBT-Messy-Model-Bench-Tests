# ADR 002: Revenue YoY Growth Extraction

## Decision
Extract `revenue_yoy_growth_pct` as `38`.

## Rationale
The press release states: "up 38% year-over-year". The schema accepts integers or percentages. Since the figure is stated as a whole number, we use integer `38`.
