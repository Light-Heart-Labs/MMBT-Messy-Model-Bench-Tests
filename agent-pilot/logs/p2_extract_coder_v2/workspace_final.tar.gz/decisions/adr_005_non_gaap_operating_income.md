# ADR 005: Non-GAAP Operating Income Extraction

## Decision
Extract `non_gaap_operating_income_usd_millions` as `9.8`.

## Rationale
The press release states: "Non-GAAP operating income of $9.8 million". This is an exact figure and matches the required units (USD millions). No conversion is needed.
