# ADR 008: Customers Above $1M ARR Extraction

## Decision
Extract `customers_above_1m_arr` as `71`.

## Rationale
The press release states: "Customers contributing more than $1 million in ARR grew to 71". The schema requires an integer. We store as integer `71`.
