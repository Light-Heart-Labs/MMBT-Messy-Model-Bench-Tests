# ADR 007: Customers Above $100k ARR Extraction

## Decision
Extract `customers_above_100k_arr` as `1082`.

## Rationale
The press release states: "Customers contributing more than $100,000 in annual recurring revenue (ARR) grew to 1,082". The schema requires an integer. We remove the comma and store as integer `1082`.
