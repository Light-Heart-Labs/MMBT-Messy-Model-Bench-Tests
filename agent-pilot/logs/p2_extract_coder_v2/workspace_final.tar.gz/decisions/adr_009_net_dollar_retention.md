# ADR 009: Net Dollar Retention Rate Extraction

## Decision
Extract `net_dollar_retention_pct` as `124`.

## Rationale
The press release states: "Net dollar retention rate of 124% for the trailing twelve months". The schema requires a number in percent. We store as number `124`.
