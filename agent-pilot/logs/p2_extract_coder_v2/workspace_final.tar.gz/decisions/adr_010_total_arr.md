# ADR 010: Total ARR Extraction

## Decision
Extract `total_arr_usd_millions` as `710`.

## Rationale
The press release states: "Total ARR exceeded $710 million as of quarter-end". The schema notes: "accept 710 or any value labeled 'over 710' / '>$710M'". Since the figure is stated as "exceeded $710 million", we use `710` as the lower bound figure.
