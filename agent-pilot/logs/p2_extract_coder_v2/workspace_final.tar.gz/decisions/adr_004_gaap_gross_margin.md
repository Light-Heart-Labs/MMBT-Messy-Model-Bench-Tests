# ADR 004: GAAP Gross Margin Extraction

## Decision
Extract `gaap_gross_margin_pct` as `76.3`.

## Rationale
The press release states: "GAAP gross margin of 76.3%". This is an exact figure and matches the required units (percent). No conversion is needed.
