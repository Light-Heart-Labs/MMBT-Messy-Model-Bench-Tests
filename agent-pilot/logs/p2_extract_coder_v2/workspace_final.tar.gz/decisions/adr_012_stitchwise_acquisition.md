# ADR 012: Stitchwise Acquisition Consideration Extraction

## Decision
Extract `stitchwise_acquisition_total_consideration_usd_millions` as `115`.

## Rationale
The press release states: "Total consideration was approximately $115 million, comprised of $87 million in cash and 1.4 million shares of common stock". The schema explicitly notes this phrasing and accepts `115` as the value. We use the stated approximate total.
