# ADR 001: Total Revenue Extraction

## Decision
Extract `total_revenue_usd_millions` as `187.4`.

## Rationale
The press release states: "Total revenue of $187.4 million". This is an exact figure and matches the required units (USD millions). No conversion is needed.
