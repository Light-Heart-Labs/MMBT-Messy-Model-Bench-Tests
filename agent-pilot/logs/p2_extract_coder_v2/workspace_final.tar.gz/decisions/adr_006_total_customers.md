# ADR 006: Total Customers Extraction

## Decision
Extract `total_customers` as `4117`.

## Rationale
The press release states: "Total customers grew to 4,117". The schema requires an integer. We remove the comma and store as integer `4117`.
