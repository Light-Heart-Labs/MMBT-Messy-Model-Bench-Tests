# ADR 014: FY2026 Revenue Guidance Extraction

## Decision
Extract:
- `fy2026_revenue_guidance_low_usd_millions` as `722`
- `fy2026_revenue_guidance_high_usd_millions` as `726`

## Rationale
The press release states: "Total revenue: $722-$726 million (previously $702-$710 million)". The schema requires USD millions. We extract the low and high bounds directly.
