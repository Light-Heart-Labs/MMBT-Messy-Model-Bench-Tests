# ADR 015: Share Repurchase Authorization Extraction

## Decision
Extract `share_repurchase_authorization_usd_millions` as `200`.

## Rationale
The press release states: "The Board of Directors authorized a share repurchase program of up to $200 million". The schema requires USD millions. We extract `200` directly.
