# ADR 011: FTE Count Extraction

## Decision
Extract `fte_count_end_of_q3` as `1847`.

## Rationale
The press release states: "The Company ended the quarter with 1,847 full-time employees". The schema requires an integer. We remove the comma and store as integer `1847`.
