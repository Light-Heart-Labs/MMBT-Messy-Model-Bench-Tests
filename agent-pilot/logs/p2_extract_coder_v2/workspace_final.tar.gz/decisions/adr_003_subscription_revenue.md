# ADR 003: Subscription Revenue Extraction

## Decision
Extract `subscription_revenue_usd_millions` as `171.2`.

## Rationale
The press release states: "Subscription revenue of $171.2 million". This is an exact figure and matches the required units (USD millions). No conversion is needed.
