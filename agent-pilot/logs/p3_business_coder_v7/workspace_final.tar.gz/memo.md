# Executive Committee Review Memo: Borealis Analytics Acquisition  
**Date**: 2026-04-20  
**From**: [Your Name], Executive Committee  

---

## Recommendation

**HOLD** — Do not issue the LOI at $84M at this time.

I would recommend proceeding *only if* the following diligence asks are completed satisfactorily within the next two weeks (by 2026-04-29), and if the following conditions are met:

1. **Revenue quality is validated**: Growth is shown to be sustainable, not driven by one-off deals or aggressive revenue recognition.
2. **Customer churn risk is mitigated**: Logo retention is confirmed to be ≥95% (not 91%) and net/Logo retention spread is ≤15 points.
3. **Integration risk is quantified**: A detailed integration plan with realistic timeline (≥6 months), migration risk mitigation, and retention plan for the Borealis team is provided and validated.
4. **Valuation is stress-tested**: IRR remains ≥20% under a downside scenario (e.g., 10% lower ARR growth, 6-month integration delay).

If these conditions are not met, I recommend **PASS** — walk away and revisit in 6–12 months if strategic needs change.

---

## Strongest Concerns with the Deal Pack

### 1. Overstated Strategic Value  
The pack claims Borealis fills a “gap” in mid-market e-commerce, but provides *no data* on our current revenue from that segment or whether we’ve attempted to grow it organically. This reads like post-hoc justification, not strategic analysis.

### 2. Revenue Growth Sustainability  
80% YoY revenue growth is impressive, but the pack does not break down *how* that growth was achieved. Was it from a few large deals? Price increases? Channel partners? Without this, the $11.4M ARR may be inflated relative to sustainable run-rate.

### 3. Customer Satisfaction Metrics Are Misleading  
The pack cites NPS in the “high 40s” as “strong satisfaction,” but NPS ≥50 is typically the benchmark for “good.” More concerning: only 5 of 280 customers were contacted, and only 4 were willing to be quoted. This is a tiny, non-random sample — not a reliable indicator of overall sentiment.

### 4. Integration Risk Is Understated  
The pack assumes a 4–6 month integration and 85% team retention, but provides no details on execution risk. Aurora’s sunset in 12 months post-close is aggressive. What happens if customers resist migration? What if retention falls below 70%? These are not edge cases — they are likely.

### 5. Comparable Transactions Are Flawed  
The comps (Hexa, Aspen, Trellis) are presented as proof of valuation reasonableness, but the pack gives *no context* on their growth rates, margins, or deal structure. A 7.4x ARR multiple is reasonable only if Borealis matches the growth profile of those companies — which the pack does not demonstrate.

---

## Next Steps

The next two weeks are critical. I expect the Corp Dev team to deliver the diligence asks outlined in `/workspace/asks.md`. If the findings confirm the pack’s optimism, I will reconsider my stance. But if they reveal material gaps — in revenue quality, customer retention, or integration risk — the deal should be abandoned.

This is not a ratification memo. It is a risk assessment. The pack is advocacy, not analysis. My job is to balance that advocacy with skepticism — and at this stage, the skepticism wins.
