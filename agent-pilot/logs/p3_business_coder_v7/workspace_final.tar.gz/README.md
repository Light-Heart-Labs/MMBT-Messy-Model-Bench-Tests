# Borealis Analytics Acquisition Review — Output Structure

## Files

| File | Purpose |
|------|---------|
| `memo.md` | **Primary deliverable**: 1-page executive summary with recommendation, concerns, and next steps. |
| `concerns.md` | Detailed enumeration of every concern identified in the deal pack, ranked by severity. |
| `asks.md` | Diligence ask list for the next 2 weeks: specific questions, owners, and deadlines. |
| `decisions/` | ADRs (Architectural Decision Records) for any judgment calls made during the review. |

## How to Use This Output

1. **Start with `memo.md`** — This is the concise, executive-facing summary. It contains the recommendation and key rationale.

2. **Review `concerns.md`** — This provides the full context for the memo’s conclusions. It is not exhaustive but covers the most material issues.

3. **Review `asks.md`** — This is the action plan for the next two weeks. It translates concerns into specific, time-bound diligence tasks.

4. **Check `decisions/`** — If any judgment calls were made (e.g., ranking concerns, defining success criteria), they are documented here.

## Key Assumptions

- The deal pack is the only source of facts. No external data was used.
- The Corp Dev team’s recommendation is treated as one input among many — not a conclusion.
- “Strong” concerns are those that could materially impact valuation, integration, or post-close performance.

## Release Tag

This output is tagged as `v1.0.0` to mark the completion of the executive committee review.
