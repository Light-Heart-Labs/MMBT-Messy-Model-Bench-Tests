# Concerns with the Borealis Acquisition Deal Pack

## 1. Overstated Strategic Rationale

- **Claim**: "Borealis would extend our analytics surface area into mid-market e-commerce, a segment we currently service only via partner integrations."
- **Concern**: This is presented as a clear strategic gap, but the pack provides no data on the size of that segment, our current revenue from partner-served mid-market e-commerce, or whether we've attempted to grow it organically. Is this a new market or a repositioning of existing partner work? Without this context, the strategic necessity is unclear.

## 2. Revenue Growth Sustainability

- **Claim**: 80% YoY revenue growth ($5.1M → $9.2M) and 92% YoY ARR growth.
- **Concern**: The pack does not break down growth drivers. Was growth driven by:
  - Expansion of the sales team?
  - Price increases?
  - One-time large deals?
  - Channel partners?
  - A specific vertical that may be saturated?
- **Risk**: If growth is not repeatable, the $11.4M ARR may be inflated relative to sustainable run-rate.

## 3. Net Retention vs Logo Retention Discrepancy

- **Claim**: Net retention 118%, Logo retention 91%.
- **Concern**: A 27-point spread is unusually high for a SaaS company with only 280 customers. With such a small customer base, a few large expansions can disproportionately boost net retention while the underlying churn is concerning. The pack does not explain this spread or provide cohort-level data.

## 4. Customer Testimonials — Small Sample, Potential Bias

- **Claim**: "Pre-LOI conversations with their five largest customers indicate strong satisfaction (NPS in the high 40s)."
- **Concerns**:
  - Only 5 customers were contacted, and only 4 willing to be quoted. With 280 customers, this is a tiny, non-random sample.
  - The pack does not disclose how these 5 were selected (e.g., largest, longest tenure, most recent renewal).
  - NPS in the high 40s is not "strong satisfaction" — it's below the typical "good" benchmark of 50–60. This is potentially misleading.

## 5. Integration Risk Understated

- **Claim**: "4-6 month full integration timeline", "85% retention expected".
- **Concerns**:
  - No details on how the integration will be executed. Will engineering teams be merged? Will there be a "lift and shift" vs. rebuild?
  - Aurora platform sunset in 12 months post-close is aggressive. What happens if migration lags or customers resist?
  - 85% retention is optimistic without a detailed retention plan or evidence of binding agreements beyond VP Eng.

## 6. Burn Rate and Runway — Misleading Context

- **Claim**: "$750K avg monthly burn, 22 months runway at last cap raise."
- **Concern**: This runway figure assumes no revenue growth and no additional funding. Borealis raised capital with a specific use case in mind. If that plan is no longer viable (e.g., growth stalled), the runway may be shorter than stated. The pack does not clarify if the burn rate is current or historical.

## 7. Comparable Transactions — Apples-to-Oranges

- **Claim**: Borealis at ~7.4x ARR is "in line with the lower comps".
- **Concerns**:
  - No details on the financial health of the comparables at acquisition (e.g., growth rates, margins, profitability).
  - Salesforce, Snowflake, and HubSpot are strategic acquirers with different valuation frameworks than a typical financial buyer.
  - No information on deal structure (e.g., earnouts, escrow, liability assumptions).
  - The pack does not disclose whether these companies had similar customer concentration or tech debt.

## 8. Engineering Review — No Independent Validation

- **Claim**: "Our PM team validated all three [features] are differentiated vs current alternatives."
- **Concern**: This is internal validation only. No third-party analyst input, customer comparison testing, or product audit is cited. Differentiation claims are common in deal packs but must be stress-tested.

## 9. Synergy Estimate — No Breakdown

- **Claim**: "$3.2M annual cost savings from consolidated infra."
- **Concern**: No details on how this was calculated. Is this purely infrastructure savings? What about integration costs, migration costs, potential revenue disruption? A net synergy analysis is missing.

## 10. Missing Key Risks Section

- **Omission**: There is no explicit "Key Risks" section. Standard diligence should call out:
  - Customer concentration (top 10 customers?)
  - Product dependency risks
  - Key person risk beyond CTO (e.g., VP Sales?)
  - Regulatory or compliance exposure (e.g., data privacy)
  - Contract terms with customers (e.g., auto-renewal, termination clauses)

## 11. Valuation — No Sensitivity Analysis

- **Claim**: IRR estimate 28–34% over 4-year hold.
- **Concern**: No sensitivity analysis around key assumptions (e.g., ARR growth, margin expansion, integration timeline slippage). A 10% change in growth or 6-month delay in integration could materially impact IRR.

## 12. Lack of Post-Mortem or Alternative Analysis

- **Omission**: No discussion of why Borealis is selling now, or why they didn’t continue independently. No analysis of alternative strategic options (e.g., partnership vs. acquisition).
