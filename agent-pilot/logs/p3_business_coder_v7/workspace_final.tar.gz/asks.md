# Diligence Asks — Borealis Analytics Acquisition
**Owner**: Corp Dev Team  
**Deadline**: 2 weeks from today (by 2026-04-29)

---

## 1. Revenue Quality & Growth Sustainability

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide a breakdown of FY2025 revenue growth: (a) new vs. expansion, (b) by sales channel (direct vs. partner), (c) by vertical. Include average deal size and sales cycle length. | Corp Dev | 2026-04-25 |
| Share cohort analysis of customer ARR growth and churn over the last 12 months. Specifically: top 10 customers, renewal rates by cohort, expansion rates by cohort. | Finance (Borealis) | 2026-04-25 |
| Provide the revenue recognition policy and any deferred revenue adjustments. | Finance (Borealis) | 2026-04-25 |

## 2. Customer Risk & Satisfaction

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide a full list of all customers (name, ARR, start date, contract end date, renewal status). | Corp Dev | 2026-04-25 |
| Conduct 10 additional reference calls: 5 from top 10 customers, 3 from customers who churned in last 12 months, 2 from customers in the bottom half of ARR. Document NPS and verbatim feedback. | Corp Dev | 2026-04-27 |
| Share the full customer contract terms (auto-renewal, termination clauses, price cap, data ownership). | Legal | 2026-04-26 |

## 3. Integration & Synergy Validation

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide a detailed integration plan: (a) org structure post-close, (b) key milestones and dependencies, (c) risk mitigation for migration slippage. | Integration Lead (Our side) | 2026-04-27 |
| Break down the $3.2M synergy estimate: infrastructure, headcount, G&A. Include assumptions and timeline for realization. | Finance (Our) | 2026-04-26 |
| Provide retention plan for Borealis team: binding agreements, retention bonuses, key person insurance. | HR | 2026-04-27 |

## 4. Product & Tech Deep Dive

| Ask | Owner | Deadline |
|-----|-------|----------|
| Independent third-party code audit (outside of Corp Dev's engineering review) covering: (a) tech debt score, (b) security posture, (c) scalability limits. | Third-party vendor (engaged by Legal) | 2026-04-29 |
| Product comparison matrix: Aurora vs. our flagship analytics product, with feature-by-feature gap analysis and migration effort estimate. | Product Team | 2026-04-27 |

## 5. Financial & Valuation Stress Test

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide sensitivity analysis of IRR to: (a) ARR growth (±10pp), (b) integration timeline (±6 months), (c) gross margin (±5pp). | Finance (Our) | 2026-04-26 |
| Clarify Borealis' burn rate and runway assumptions: Is the $750K burn rate current or historical? What is the latest monthly burn as of 2026-04-15? | Finance (Borealis) | 2026-04-25 |

## 6. Strategic Fit & Alternatives

| Ask | Owner | Deadline |
|-----|-------|----------|
| Provide data on our current mid-market e-commerce revenue (direct + partner-served), growth rate, and strategic goals for that segment. | Strategy Team | 2026-04-25 |
| Provide a brief "why sell?" analysis from Borealis: Why now? Why not raise Series B? Why not stay independent? | Corp Dev | 2026-04-26 |

## 7. Risk Register Update

| Ask | Owner | Deadline |
|-----|-------|----------|
| Finalize and sign off on a risk register covering: customer concentration, key person risk, integration risk, regulatory risk, and post-close execution risk. Include mitigation plans. | Legal + Corp Dev | 2026-04-28 |

---

**Deliverable**: A consolidated diligence report by 2026-04-29, with findings and updated recommendation.
