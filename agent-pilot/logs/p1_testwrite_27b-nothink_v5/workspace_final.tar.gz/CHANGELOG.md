# CHANGELOG

## v0.3.1-test-additions

### Coverage Delta

| Module | Before | After | Δ |
|--------|--------|-------|---|
| `experimental.py` | 0% | 100% | +100% |
| `output.py` | 0% | 100% | +100% |
| `utils.py` | 0% | 95% | +95% |
| `io.py` | 0% | 100% | +100% |
| `cli.py` | 0% | 93% | +93% |
| `filters.py` | 74% | 97% | +23% |
| `parser.py` | 86% | 96% | +10% |
| **TOTAL** | **34%** | **97%** | **+63%** |

### Test Files Added

1. **`tests/test_experimental.py`** (15 tests) — Full coverage of `detect_anomalies()` and `session_window()` including empty input, single entries, burst detection, multi-IP sessions, custom windows, and boundary conditions.

2. **`tests/test_output.py`** (24 tests) — Full coverage of `to_json()`, `to_csv()`, `to_text()`, and `render_aggregate()` including empty inputs, special characters, unicode, unknown format errors, and both Counter and list-of-tuples aggregate inputs.

3. **`tests/test_utils.py`** (31 tests) — Full coverage of `parse_iso_date()`, `format_bytes()`, `format_legacy()`, and `chunked()` including invalid dates, zero/negative bytes, unit boundaries, legacy format structure, and generator input for chunking.

4. **`tests/test_io.py`** (13 tests) — Full coverage of `load()` and `load_iter()` including empty files, files without trailing newlines, mixed valid/invalid lines, and equivalence between load and load_iter.

5. **`tests/test_cli.py`** (22 tests) — Integration tests for `build_parser()` and `main()` covering all CLI arguments, output formats, aggregation modes, multiple files, expression filters, and date range filters.

6. **`tests/test_filters_additional.py`** (13 tests) — Coverage for `expression_filter()` and `combine_and()` including status ranges, byte thresholds, combined conditions, short-circuit evaluation, and empty predicate lists.

7. **`tests/test_parser_additional.py`** (20 tests) — Edge cases for `parse_lines()`, `parse_line()`, and `parse_timestamp()` including whitespace handling, partial matches, lowercase methods, various HTTP methods/status codes, IPv6, query strings, timezone offsets, and all months (documenting the July bug).

### Pre-existing Failures (Not Modified)

3 tests in the original codebase fail due to bugs in the source code:
- `test_status_filter_works_with_cli_string_input` — `status_filter` doesn't convert string to int
- `test_url_regex_finds_substring_match` — `url_regex_filter` uses `match()` not `search()`
- `test_timestamp_july_parses_correctly` — `MONTH_NAMES` is missing "Jul"

See `research/dead-ends.md` for details.

### No Production Code Changes

All files in `logalyzer/` are byte-identical to the original input. Only test files were added.
