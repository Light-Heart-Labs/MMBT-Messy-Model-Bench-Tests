# Dead Ends

## Pre-existing test failures (not modified per rules)

### 1. `test_status_filter_works_with_cli_string_input` (test_filters.py)

**Bug:** `status_filter` compares `entry.status == status` directly. When CLI passes `"404"` (string) and entry has `status=404` (int), `"404" == 404` is `False`. The filter does not convert the string to int.

**Impact:** The `--status` CLI flag is effectively broken for string input.

**Action:** Documented, not fixed. Test remains failing.

### 2. `test_url_regex_finds_substring_match` (test_filters.py)

**Bug:** `url_regex_filter` uses `rx.match(entry.url)` which only matches at the start of the string. Pattern `"admin"` won't match `"/admin/login"` because the URL starts with `/`. The test expects substring matching but the code does anchor matching.

**Impact:** URL regex filtering only works for patterns that match from the beginning of the URL.

**Action:** Documented, not fixed. Test remains failing.

### 3. `test_timestamp_july_parses_correctly` (test_parser.py)

**Bug:** `MONTH_NAMES` list in `parser.py` is missing "Jul" (July). The list goes from "Jun" to "Aug", skipping July entirely. This causes `ValueError: 'Jul' is not in list` when parsing any July timestamp.

**Impact:** Any log entries from July cannot be parsed.

**Action:** Documented, not fixed. Test remains failing.

## Notes on conftest.py modification

The original `conftest.py` only set up `sys.path`. We added a monkey-patch for `collections.Iterable` because `filters.py` imports it from `collections` (deprecated in Python 3.11, moved to `collections.abc`). This is a workaround for a source code bug that we cannot fix. The monkey-patch is in `tests/conftest.py` only.
