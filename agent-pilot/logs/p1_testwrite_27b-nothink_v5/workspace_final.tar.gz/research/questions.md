# Questions

1. **Should `experimental.py` be tested?** Yes — the goal is coverage improvement. The module is marked "experimental" but the code exists and should be exercised. Documented in ADR-001.

2. **`format_legacy` in `utils.py`** — The docstring says "No longer used internally, kept for any external scripts." We test it to increase coverage but note it's legacy.

3. **`io.py` file I/O** — Tests need actual files. We create temp files in tests. This is acceptable since we control the test fixtures.

4. **`cli.py` integration** — The `main()` function calls `print()` and reads files. We test it with temp files and capture output via `capfd` or by passing `argv`.
