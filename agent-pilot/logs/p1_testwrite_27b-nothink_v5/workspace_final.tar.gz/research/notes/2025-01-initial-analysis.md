# Research Notes — 2025-01-XX

## Initial Analysis

Examined all source files in the logalyzer package:
- `parser.py` (50 stmts): CLF parsing with regex, timestamp parsing with manual timezone conversion
- `utils.py` (21 stmts): ISO date parsing, byte formatting, legacy format, chunking
- `experimental.py` (32 stmts): Z-score anomaly detection, session windowing
- `output.py` (35 stmts): Hand-built JSON, CSV via csv module, plain text, aggregate rendering
- `filters.py` (38 stmts): Status, URL regex, IP allowlist, date range, expression, combine_and
- `aggregate.py` (25 stmts): By status, URL, hour, total bytes
- `io.py` (26 stmts): Character-by-character file reader, generator variant
- `cli.py` (59 stmts): argparse setup, main entry point

## Bugs Found

1. **`parser.py`**: `MONTH_NAMES` list is missing "Jul" (July). This causes `ValueError` for July timestamps and shifts all subsequent months (Aug→7, Sep→8, etc.).

2. **`filters.py`**: `status_filter` does `entry.status == status` without type conversion. CLI passes strings, entries have ints. `"404" == 404` is `False`.

3. **`filters.py`**: `url_regex_filter` uses `rx.match()` which only matches at string start. Pattern "admin" won't match "/admin/login".

4. **`filters.py`**: Imports `Iterable` from `collections` which was removed in Python 3.11 (moved to `collections.abc`). Worked around with monkey-patch in conftest.py.

## Design Decisions

- Tested `experimental.py` despite being marked "experimental" — the goal is coverage improvement.
- Tested `format_legacy()` despite being deprecated — the goal is coverage improvement.
- All tests pass against current (buggy) behavior. No source code changes.
- Used temp files for io.py tests to exercise actual file I/O.
- Used `capfd`-style approach (main() prints to stdout) for CLI tests.
