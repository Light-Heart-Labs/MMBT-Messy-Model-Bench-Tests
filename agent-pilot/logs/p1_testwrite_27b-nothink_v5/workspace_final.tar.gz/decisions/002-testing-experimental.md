# ADR-002: Testing experimental.py

## Context

`experimental.py` contains two functions: `detect_anomalies()` (z-score-based anomaly detection) and `session_window()` (session grouping by IP). The module is marked "experimental" and "Not yet wired into the CLI."

## Decision

We wrote 15 tests covering both functions, achieving 100% coverage.

## Rationale

- The goal of this exercise is increasing test coverage, and `experimental.py` had 0% coverage.
- Testing the code validates that the algorithms work as documented.
- The tests document edge case behavior (empty input, single entry, boundary conditions) that would be valuable if the feature is ever wired into the CLI.

## Recommendation (out of scope)

If this code is not going to be used, consider:
1. Adding a `@pytest.mark.skipif` decorator to skip these tests in CI
2. Or removing the module entirely (refactoring, out of scope for this exercise)
