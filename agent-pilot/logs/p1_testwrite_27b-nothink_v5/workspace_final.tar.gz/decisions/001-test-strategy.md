# ADR-001: Test Strategy for logalyzer Coverage Improvement

## Context

The logalyzer codebase has several modules with 0% or low test coverage:
- `experimental.py`: 0% coverage (32 statements)
- `output.py`: 0% coverage (35 statements)
- `utils.py`: 0% coverage (21 statements)
- `io.py`: 0% coverage (26 statements)
- `cli.py`: 0% coverage (59 statements)
- `filters.py`: 74% coverage (some functions uncovered)
- `parser.py`: 86% coverage (some edge cases uncovered)

Baseline coverage: 34% (14 passing tests, 3 pre-existing failures).

## Decision

Target modules in order of highest impact (statements uncovered / test effort):
1. `experimental.py` — 32 stmts, 0% coverage. Two functions: `detect_anomalies` and `session_window`.
2. `output.py` — 35 stmts, 0% coverage. Functions: `to_json`, `to_csv`, `to_text`, `render_aggregate`.
3. `utils.py` — 21 stmts, 0% coverage. Functions: `parse_iso_date`, `format_bytes`, `format_legacy`, `chunked`.
4. `io.py` — 26 stmts, 0% coverage. Functions: `load`, `load_iter`.
5. `cli.py` — 59 stmts, 0% coverage. Functions: `build_parser`, `main`.
6. `filters.py` — 10 stmts uncovered. `expression_filter` and `combine_and` are untested.
7. `parser.py` — 7 stmts uncovered. Edge cases for `parse_timestamp`, `parse_lines`.

## Rationale

- `experimental.py` is marked "experimental" but testing it increases coverage and validates the code paths.
- `output.py` has hand-built JSON (no `json` module) — edge cases with special characters are valuable.
- `utils.py` has `format_legacy` which is explicitly called out as uncovered.
- `io.py` has a character-by-character file reader — edge cases with empty files, no trailing newline.
- `cli.py` is the main entry point — integration tests here exercise the full pipeline.

## What we chose NOT to test

- The 3 pre-existing failing tests document bugs in the source code (see `research/dead-ends.md`). We do not modify them.
- We do not test `cli.py`'s `main()` with actual file I/O in a way that depends on filesystem state beyond what we create ourselves.
