"""Tests for utils.py — date parsing, byte formatting, legacy format, chunking.

These tests cover edge cases like invalid dates, zero/negative byte counts,
very large numbers, empty sequences, and the legacy format function.
"""
from datetime import datetime, timezone

from logalyzer.utils import parse_iso_date, format_bytes, format_legacy, chunked
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── parse_iso_date ────────────────────────────────────────────────────────


def test_parse_iso_date_valid():
    """A valid YYYY-MM-DD string should parse to a UTC datetime at midnight."""
    dt = parse_iso_date("2026-01-15")
    assert dt == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_leap_year():
    """Feb 29 on a leap year should parse correctly."""
    dt = parse_iso_date("2024-02-29")
    assert dt == datetime(2024, 2, 29, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_first_of_month():
    """First day of a month should parse correctly."""
    dt = parse_iso_date("2026-03-01")
    assert dt.day == 1
    assert dt.month == 3


def test_parse_iso_date_last_of_year():
    """December 31 should parse correctly."""
    dt = parse_iso_date("2026-12-31")
    assert dt.month == 12
    assert dt.day == 31


def test_parse_iso_date_invalid_format_raises():
    """An invalid date format should raise ValueError from strptime."""
    try:
        parse_iso_date("01-15-2026")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_nonexistent_date_raises():
    """A nonexistent date like Feb 30 should raise ValueError."""
    try:
        parse_iso_date("2026-02-30")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_empty_string_raises():
    """An empty string should raise ValueError."""
    try:
        parse_iso_date("")
        assert False, "Expected ValueError"
    except ValueError:
        pass


# ── format_bytes ──────────────────────────────────────────────────────────


def test_format_bytes_zero():
    """Zero bytes should format as '0.0 B'."""
    assert format_bytes(0) == "0.0 B"


def test_format_bytes_small():
    """Small byte counts should stay in bytes."""
    assert format_bytes(1) == "1.0 B"
    assert format_bytes(500) == "500.0 B"


def test_format_bytes_exactly_1023():
    """1023 bytes is still in the B range (< 1024)."""
    assert format_bytes(1023) == "1023.0 B"


def test_format_bytes_exactly_1024():
    """1024 bytes should be 1.0 KB."""
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_1_kb():
    """1024 bytes = 1.0 KB."""
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_1_mb():
    """1 MB = 1048576 bytes."""
    assert format_bytes(1048576) == "1.0 MB"


def test_format_bytes_1_gb():
    """1 GB = 1073741824 bytes."""
    assert format_bytes(1073741824) == "1.0 GB"


def test_format_bytes_1_tb():
    """1 TB = 1099511627776 bytes."""
    assert format_bytes(1099511627776) == "1.0 TB"


def test_format_bytes_fractional_kb():
    """1536 bytes = 1.5 KB."""
    assert format_bytes(1536) == "1.5 KB"


def test_format_bytes_fractional_mb():
    """1572864 bytes = 1.5 MB."""
    assert format_bytes(1572864) == "1.5 MB"


def test_format_bytes_very_large():
    """Very large numbers should reach TB or beyond."""
    result = format_bytes(1099511627776 * 2)
    assert "TB" in result


def test_format_bytes_exactly_at_boundary():
    """Values exactly at unit boundaries should transition correctly."""
    # 1024 * 1024 - 1 = 1048575, still in KB
    assert format_bytes(1048575) == "1024.0 KB"


# ── format_legacy ─────────────────────────────────────────────────────────


def test_format_legacy_basic():
    """The legacy format should produce 'ip | timestamp | status | url'."""
    entry = _entry()
    result = format_legacy(entry)
    assert "10.0.0.1" in result
    assert "200" in result
    assert "/" in result
    assert "|" in result


def test_format_legacy_format_structure():
    """The legacy format has exactly 4 pipe-separated fields."""
    entry = _entry()
    result = format_legacy(entry)
    parts = result.split(" | ")
    assert len(parts) == 4
    assert parts[0] == "10.0.0.1"
    assert parts[2] == "200"
    assert parts[3] == "/"


def test_format_legacy_with_different_status():
    """Different status codes should appear in the output."""
    entry = _entry(status=404)
    result = format_legacy(entry)
    assert "404" in result


def test_format_legacy_with_complex_url():
    """Complex URLs should be preserved in the output."""
    entry = _entry(url="/api/v1/users?page=2")
    result = format_legacy(entry)
    assert "/api/v1/users?page=2" in result


# ── chunked ───────────────────────────────────────────────────────────────


def test_chunked_empty_sequence():
    """An empty sequence should produce no chunks."""
    result = list(chunked([], 3))
    assert result == []


def test_chunked_exact_multiple():
    """A sequence whose length is an exact multiple of chunk size."""
    result = list(chunked([1, 2, 3, 4, 5, 6], 3))
    assert result == [[1, 2, 3], [4, 5, 6]]


def test_chunked_remainder():
    """A sequence with a remainder should have a smaller final chunk."""
    result = list(chunked([1, 2, 3, 4, 5], 3))
    assert result == [[1, 2, 3], [4, 5]]


def test_chunked_single_element():
    """A single element should produce one chunk."""
    result = list(chunked([42], 3))
    assert result == [[42]]


def test_chunked_chunk_size_one():
    """Chunk size of 1 should produce one-element chunks."""
    result = list(chunked([1, 2, 3], 1))
    assert result == [[1], [2], [3]]


def test_chunked_chunk_size_larger_than_sequence():
    """Chunk size larger than sequence should produce one chunk."""
    result = list(chunked([1, 2], 10))
    assert result == [[1, 2]]


def test_chunked_generator_input():
    """chunked should work with generator input (not just lists)."""
    def gen():
        for i in range(7):
            yield i
    result = list(chunked(gen(), 3))
    assert result == [[0, 1, 2], [3, 4, 5], [6]]


def test_chunked_preserves_order():
    """Elements should appear in the same order as the input."""
    result = list(chunked([3, 1, 4, 1, 5], 2))
    assert result == [[3, 1], [4, 1], [5]]
