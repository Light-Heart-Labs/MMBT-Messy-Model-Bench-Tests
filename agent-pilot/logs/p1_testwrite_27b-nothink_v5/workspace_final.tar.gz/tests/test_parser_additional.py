"""Additional tests for parser.py — edge cases and uncovered paths.

The original test_parser.py covers basic CLF parsing, dash bytes, garbage lines,
January timestamps, and UTC conversion. These tests cover:
- parse_lines() generator
- parse_timestamp edge cases
- parse_line with various malformed inputs
- All months (documenting the July bug's cascading effect)
"""

from logalyzer.parser import parse_line, parse_lines, parse_timestamp


def test_parse_lines_generator():
    """parse_lines should yield LogEntry objects for valid lines."""
    lines = [
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326',
        '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512',
    ]
    entries = list(parse_lines(lines))
    assert len(entries) == 2
    assert entries[0].ip == "127.0.0.1"
    assert entries[1].ip == "192.168.1.1"


def test_parse_lines_skips_invalid():
    """parse_lines should skip invalid lines and only yield valid entries."""
    lines = [
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326',
        'garbage line',
        '',
        '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512',
    ]
    entries = list(parse_lines(lines))
    assert len(entries) == 2


def test_parse_lines_empty_input():
    """parse_lines with empty input should yield nothing."""
    entries = list(parse_lines([]))
    assert entries == []


def test_parse_lines_generator_type():
    """parse_lines should return a generator, not a list."""
    result = parse_lines([])
    assert hasattr(result, '__iter__')
    assert hasattr(result, '__next__')


def test_parse_line_whitespace_only():
    """A line with only whitespace should return None."""
    assert parse_line("   ") is None
    assert parse_line("\t") is None
    assert parse_line("\n") is None


def test_parse_line_leading_trailing_whitespace():
    """Lines with leading/trailing whitespace should still parse (strip is called)."""
    line = '  127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326  '
    entry = parse_line(line)
    assert entry is not None
    assert entry.ip == "127.0.0.1"


def test_parse_line_partial_match():
    """A line that partially matches the regex but is incomplete should return None."""
    assert parse_line('127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0"') is None


def test_parse_line_lowercase_method():
    """A line with a lowercase HTTP method should not match (regex requires [A-Z]+)."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "get / HTTP/1.0" 200 2326'
    assert parse_line(line) is None


def test_parse_timestamp_positive_offset():
    """A positive timezone offset should convert correctly to UTC."""
    # 13:55:36 +0700 → 06:55:36 UTC
    ts = parse_timestamp("10/Oct/2000:13:55:36 +0700")
    assert ts.hour == 6
    assert ts.minute == 55


def test_parse_timestamp_zero_offset():
    """A +0000 offset should not change the time."""
    ts = parse_timestamp("10/Oct/2000:13:55:36 +0000")
    assert ts.hour == 13
    assert ts.minute == 55


def test_parse_timestamp_negative_offset():
    """A negative timezone offset should convert correctly to UTC."""
    # 13:55:36 -0500 → 18:55:36 UTC
    ts = parse_timestamp("10/Oct/2000:13:55:36 -0500")
    assert ts.hour == 18
    assert ts.minute == 55


def test_parse_timestamp_invalid_format():
    """An invalid timestamp format should raise ValueError."""
    try:
        parse_timestamp("not-a-timestamp")
        assert False, "Expected ValueError"
    except ValueError as e:
        assert "unrecognized timestamp format" in str(e)


def test_parse_timestamp_months_before_july_bug():
    """Months Jan-Jun parse correctly (before the missing-Jul bug takes effect)."""
    months = [
        ("Jan", 1), ("Feb", 2), ("Mar", 3), ("Apr", 4),
        ("May", 5), ("Jun", 6),
    ]
    for month_str, expected_num in months:
        ts = parse_timestamp(f"15/{month_str}/2026:08:30:00 +0000")
        assert ts.month == expected_num, f"Failed for {month_str}"


def test_parse_timestamp_months_after_july_bug():
    """Months Aug-Dec are shifted by 1 due to missing 'Jul' in MONTH_NAMES.

    This documents the current (buggy) behavior: Aug→7, Sep→8, Oct→9, etc.
    The bug is in parser.py where MONTH_NAMES skips 'Jul'.
    """
    # Due to the missing 'Jul', the index mapping is off by 1 for Aug-Dec
    months = [
        ("Aug", 7),   # should be 8, but is 7
        ("Sep", 8),   # should be 9, but is 8
        ("Oct", 9),   # should be 10, but is 9
        ("Nov", 10),  # should be 11, but is 10
        ("Dec", 11),  # should be 12, but is 11
    ]
    for month_str, actual_num in months:
        ts = parse_timestamp(f"15/{month_str}/2026:08:30:00 +0000")
        assert ts.month == actual_num, f"Failed for {month_str}: got {ts.month}"


def test_parse_line_various_status_codes():
    """Lines with various status codes should parse correctly."""
    for status in [200, 301, 302, 400, 403, 404, 500, 502, 503]:
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" {status} 100'
        entry = parse_line(line)
        assert entry is not None, f"Failed to parse status {status}"
        assert entry.status == status


def test_parse_line_various_methods():
    """Lines with various HTTP methods should parse correctly."""
    for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "{method} / HTTP/1.0" 200 100'
        entry = parse_line(line)
        assert entry is not None, f"Failed to parse method {method}"
        assert entry.method == method


def test_parse_line_large_byte_count():
    """Lines with very large byte counts should parse correctly."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 999999999'
    entry = parse_line(line)
    assert entry is not None
    assert entry.bytes == 999999999


def test_parse_line_ipv6_address():
    """Lines with IPv6 addresses should parse (IP is just non-whitespace)."""
    line = '::1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
    entry = parse_line(line)
    assert entry is not None
    assert entry.ip == "::1"


def test_parse_line_url_with_query_string():
    """Lines with URLs containing query strings should parse correctly."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /search?q=hello+world HTTP/1.1" 200 500'
    entry = parse_line(line)
    assert entry is not None
    assert entry.url == "/search?q=hello+world"


def test_parse_line_user_field_with_name():
    """Lines with a non-dash user field should parse correctly."""
    line = '127.0.0.1 - john [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
    entry = parse_line(line)
    assert entry is not None
    assert entry.user == "john"
