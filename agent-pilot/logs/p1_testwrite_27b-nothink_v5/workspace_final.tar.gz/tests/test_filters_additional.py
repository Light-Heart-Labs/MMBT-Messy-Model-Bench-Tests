"""Additional tests for filters.py — expression_filter and combine_and.

The original test_filters.py covers status_filter, url_regex_filter,
ip_allowlist_filter, and date_range_filter. These tests cover the
remaining uncovered functions.
"""
from datetime import datetime, timezone

from logalyzer.filters import expression_filter, combine_and
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── expression_filter ─────────────────────────────────────────────────────


def test_expression_filter_status_range():
    """Expression 'entry.status >= 500' should match 5xx entries."""
    pred = expression_filter("entry.status >= 500")
    assert pred(_entry(status=500)) is True
    assert pred(_entry(status=503)) is True
    assert pred(_entry(status=499)) is False
    assert pred(_entry(status=200)) is False


def test_expression_filter_bytes_threshold():
    """Expression 'entry.bytes > 1024' should match large responses."""
    pred = expression_filter("entry.bytes > 1024")
    assert pred(_entry(bytes=2048)) is True
    assert pred(_entry(bytes=1024)) is False  # not > 1024
    assert pred(_entry(bytes=0)) is False


def test_expression_filter_method():
    """Expression 'entry.method == "POST"' should match POST requests."""
    pred = expression_filter("entry.method == 'POST'")
    assert pred(_entry(method="POST")) is True
    assert pred(_entry(method="GET")) is False


def test_expression_filter_combined_conditions():
    """Expression with multiple conditions using 'and'."""
    pred = expression_filter("entry.status >= 400 and entry.method == 'GET'")
    assert pred(_entry(status=404, method="GET")) is True
    assert pred(_entry(status=404, method="POST")) is False
    assert pred(_entry(status=200, method="GET")) is False


def test_expression_filter_ip_match():
    """Expression matching on IP address."""
    pred = expression_filter("entry.ip == '10.0.0.1'")
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="192.168.1.1")) is False


def test_expression_filter_url_contains():
    """Expression checking if URL contains a substring."""
    pred = expression_filter("'admin' in entry.url")
    assert pred(_entry(url="/admin/login")) is True
    assert pred(_entry(url="/index.html")) is False


def test_expression_filter_always_true():
    """Expression that always evaluates to True."""
    pred = expression_filter("True")
    assert pred(_entry()) is True


def test_expression_filter_always_false():
    """Expression that always evaluates to False."""
    pred = expression_filter("False")
    assert pred(_entry()) is False


# ── combine_and ───────────────────────────────────────────────────────────


def test_combine_and_single_predicate():
    """A single predicate should behave identically."""
    from logalyzer.filters import status_filter
    pred = combine_and(status_filter(200))
    assert pred(_entry(status=200)) is True
    assert pred(_entry(status=404)) is False


def test_combine_and_two_predicates():
    """Two predicates should both need to match."""
    from logalyzer.filters import status_filter
    pred = combine_and(status_filter(200), expression_filter("entry.bytes > 50"))
    assert pred(_entry(status=200, bytes=100)) is True
    assert pred(_entry(status=200, bytes=10)) is False
    assert pred(_entry(status=404, bytes=100)) is False


def test_combine_and_three_predicates():
    """Three predicates should all need to match."""
    from logalyzer.filters import status_filter
    pred = combine_and(
        status_filter(200),
        expression_filter("entry.method == 'GET'"),
        expression_filter("entry.bytes > 0"),
    )
    assert pred(_entry(status=200, method="GET", bytes=100)) is True
    assert pred(_entry(status=200, method="POST", bytes=100)) is False
    assert pred(_entry(status=404, method="GET", bytes=100)) is False
    assert pred(_entry(status=200, method="GET", bytes=0)) is False


def test_combine_and_short_circuits():
    """combine_and should short-circuit on first False predicate.

    We verify this by checking that a predicate that would raise an error
    is never called when an earlier predicate returns False.
    """

    def always_false(entry):
        return False

    def would_error(entry):
        raise RuntimeError("should not be called")

    pred = combine_and(always_false, would_error)
    # Should return False without calling would_error
    assert pred(_entry(status=200)) is False


def test_combine_and_no_predicates():
    """combine_and with no predicates should return True for all entries."""
    pred = combine_and()
    assert pred(_entry()) is True
