"""Tests for io.py — file loading helpers.

These tests cover edge cases like empty files, files without trailing newlines,
malformed lines mixed with valid ones, and the character-by-character reader.
"""
import os
import tempfile

from logalyzer.io import load, load_iter


def _write_log(content):
    """Write content to a temp file and return the path."""
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False)
    f.write(content)
    f.close()
    return f.name


def test_load_empty_file():
    """An empty file should return an empty list."""
    path = _write_log("")
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_single_line_with_newline():
    """A file with one valid log line and a trailing newline."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
    path = _write_log(line)
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_single_line_without_trailing_newline():
    """A file with one valid log line but no trailing newline.

    This exercises the 'if accumulated' branch at the end of load().
    """
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    path = _write_log(line)
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_multiple_lines():
    """A file with multiple valid log lines."""
    lines = (
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
        '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512\n'
    )
    path = _write_log(lines)
    try:
        result = load(path)
        assert len(result) == 2
        assert result[0].ip == "127.0.0.1"
        assert result[1].ip == "192.168.1.1"
    finally:
        os.unlink(path)


def test_load_mixed_valid_and_invalid_lines():
    """A file with valid and invalid lines should skip the invalid ones."""
    content = (
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
        'this is garbage\n'
        '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512\n'
        '\n'  # empty line
    )
    path = _write_log(content)
    try:
        result = load(path)
        assert len(result) == 2
        assert result[0].ip == "127.0.0.1"
        assert result[1].ip == "192.168.1.1"
    finally:
        os.unlink(path)


def test_load_only_invalid_lines():
    """A file with only invalid lines should return an empty list."""
    content = "garbage line 1\ngarbage line 2\n"
    path = _write_log(content)
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_only_empty_lines():
    """A file with only empty lines should return an empty list."""
    content = "\n\n\n"
    path = _write_log(content)
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_bytes_dash():
    """Lines with '-' for bytes should parse as 0."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 304 -\n'
    path = _write_log(line)
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].bytes == 0
    finally:
        os.unlink(path)


# ── load_iter ─────────────────────────────────────────────────────────────


def test_load_iter_empty_file():
    """An empty file should yield no entries."""
    path = _write_log("")
    try:
        result = list(load_iter(path))
        assert result == []
    finally:
        os.unlink(path)


def test_load_iter_single_line():
    """A file with one valid line should yield one entry."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
    path = _write_log(line)
    try:
        result = list(load_iter(path))
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_iter_skips_invalid_lines():
    """Invalid lines should be silently skipped by the generator."""
    content = (
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
        'garbage\n'
        '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512\n'
    )
    path = _write_log(content)
    try:
        result = list(load_iter(path))
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_is_generator():
    """load_iter should return a generator, not a list."""
    path = _write_log('127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n')
    try:
        result = load_iter(path)
        # Should be a generator
        assert hasattr(result, '__iter__')
        assert hasattr(result, '__next__')
    finally:
        os.unlink(path)


def test_load_vs_load_iter_equivalence():
    """load() and load_iter() should produce the same results for the same file."""
    content = (
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326\n'
        'garbage\n'
        '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "POST /api HTTP/1.1" 201 512\n'
    )
    path = _write_log(content)
    try:
        loaded = load(path)
        iterated = list(load_iter(path))
        assert len(loaded) == len(iterated)
        for a, b in zip(loaded, iterated):
            assert a.ip == b.ip
            assert a.status == b.status
    finally:
        os.unlink(path)
