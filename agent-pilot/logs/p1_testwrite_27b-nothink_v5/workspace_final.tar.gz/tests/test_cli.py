"""Tests for cli.py — command-line interface integration.

These tests exercise the CLI's argument parsing, filter application,
aggregation, and output formatting through the main() function.
"""
import os
import tempfile

from logalyzer.cli import build_parser, main


def _write_log(content):
    """Write content to a temp file and return the path."""
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False)
    f.write(content)
    f.close()
    return f.name


LOG_LINE_200 = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /index.html HTTP/1.0" 200 2326\n'
LOG_LINE_404 = '192.168.1.1 - - [10/Oct/2000:14:00:00 +0000] "GET /missing HTTP/1.1" 404 123\n'
LOG_LINE_500 = '10.0.0.1 - admin [10/Oct/2000:15:00:00 +0000] "POST /api HTTP/1.1" 500 999\n'


# ── build_parser ──────────────────────────────────────────────────────────


def test_build_parser_has_version():
    """The parser should have a --version action."""
    parser = build_parser()
    # --version should be recognized
    try:
        parser.parse_args(["--version"])
    except SystemExit:
        pass  # --version triggers sys.exit


def test_build_parser_requires_paths():
    """The parser should require at least one log file path."""
    parser = build_parser()
    try:
        parser.parse_args([])
        assert False, "Expected error for missing paths"
    except SystemExit:
        pass


def test_build_parser_accepts_status_filter():
    """The --status argument should be accepted."""
    parser = build_parser()
    args = parser.parse_args(["--status", "404", "file.log"])
    assert args.status == "404"


def test_build_parser_accepts_url_filter():
    """The --url argument should be accepted."""
    parser = build_parser()
    args = parser.parse_args(["--url", "/api", "file.log"])
    assert args.url == "/api"


def test_build_parser_accepts_multiple_ips():
    """The --ip argument should be repeatable."""
    parser = build_parser()
    args = parser.parse_args(["--ip", "10.0.0.1", "--ip", "10.0.0.2", "file.log"])
    assert args.ip == ["10.0.0.1", "10.0.0.2"]


def test_build_parser_accepts_since_until():
    """The --since and --until arguments should be accepted."""
    parser = build_parser()
    args = parser.parse_args(["--since", "2026-01-01", "--until", "2026-12-31", "file.log"])
    assert args.since is not None
    assert args.until is not None


def test_build_parser_accepts_aggregate():
    """The --aggregate argument should accept status, url, hour."""
    parser = build_parser()
    for agg in ["status", "url", "hour"]:
        args = parser.parse_args(["--aggregate", agg, "file.log"])
        assert args.aggregate == agg


def test_build_parser_accepts_format():
    """The --format argument should accept text, json, csv."""
    parser = build_parser()
    for fmt in ["text", "json", "csv"]:
        args = parser.parse_args(["--format", fmt, "file.log"])
        assert args.format == fmt


def test_build_parser_default_format_is_text():
    """Without --format, the default should be 'text'."""
    parser = build_parser()
    args = parser.parse_args(["file.log"])
    assert args.format == "text"


# ── main() integration ────────────────────────────────────────────────────


def test_main_text_output():
    """main() with default text format should produce readable output."""
    path = _write_log(LOG_LINE_200)
    try:
        ret = main(["file.log".replace("file.log", path)])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_json_output():
    """main() with --format json should produce JSON output."""
    path = _write_log(LOG_LINE_200)
    try:
        ret = main(["--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_csv_output():
    """main() with --format csv should produce CSV output."""
    path = _write_log(LOG_LINE_200)
    try:
        ret = main(["--format", "csv", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_aggregate_status():
    """main() with --aggregate status should produce status counts."""
    path = _write_log(LOG_LINE_200 + LOG_LINE_404 + LOG_LINE_500)
    try:
        ret = main(["--aggregate", "status", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_aggregate_url():
    """main() with --aggregate url should produce URL counts."""
    path = _write_log(LOG_LINE_200 + LOG_LINE_404)
    try:
        ret = main(["--aggregate", "url", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_aggregate_hour():
    """main() with --aggregate hour should produce hourly counts."""
    path = _write_log(LOG_LINE_200 + LOG_LINE_404)
    try:
        ret = main(["--aggregate", "hour", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_aggregate_url_with_top():
    """main() with --aggregate url --top N should limit results."""
    path = _write_log(LOG_LINE_200 + LOG_LINE_404 + LOG_LINE_500)
    try:
        ret = main(["--aggregate", "url", "--top", "2", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_empty_file():
    """main() with an empty file should produce empty output and return 0."""
    path = _write_log("")
    try:
        ret = main([path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_multiple_files():
    """main() should handle multiple file paths."""
    path1 = _write_log(LOG_LINE_200)
    path2 = _write_log(LOG_LINE_404)
    try:
        ret = main([path1, path2])
        assert ret == 0
    finally:
        os.unlink(path1)
        os.unlink(path2)


def test_main_expr_filter():
    """main() with --expr should apply a Python expression filter."""
    path = _write_log(LOG_LINE_200 + LOG_LINE_404)
    try:
        ret = main(["--expr", "entry.status >= 400", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_since_filter():
    """main() with --since should filter by date."""
    path = _write_log(LOG_LINE_200)
    try:
        # Since before the log date — should include the entry
        ret = main(["--since", "1999-01-01", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_until_filter():
    """main() with --until should filter by date."""
    path = _write_log(LOG_LINE_200)
    try:
        # Until after the log date — should include the entry
        ret = main(["--until", "2026-12-31", path])
        assert ret == 0
    finally:
        os.unlink(path)


def test_main_aggregate_json_format():
    """main() with --aggregate and --format json should produce JSON."""
    path = _write_log(LOG_LINE_200 + LOG_LINE_404)
    try:
        ret = main(["--aggregate", "status", "--format", "json", path])
        assert ret == 0
    finally:
        os.unlink(path)
