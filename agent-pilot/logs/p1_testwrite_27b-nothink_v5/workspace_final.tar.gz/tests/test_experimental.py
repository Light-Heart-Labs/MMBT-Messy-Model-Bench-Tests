"""Tests for experimental.py — anomaly detection and session windowing.

These tests exercise the full code paths of detect_anomalies() and session_window(),
including edge cases like empty input, single-entry input, and burst patterns.
"""
from datetime import datetime, timedelta, timezone

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1"):
    """Helper to create a LogEntry at a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )


# ── detect_anomalies ──────────────────────────────────────────────────────


def test_detect_anomalies_empty_input():
    """Empty input should return an empty list (no buckets to analyze)."""
    assert detect_anomalies([]) == []


def test_detect_anomalies_single_entry():
    """A single entry produces one bucket with count=1, std=0, threshold=1.
    Since 1 is not > 1, no anomalies are detected."""
    entries = [_entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))]
    assert detect_anomalies(entries) == []


def test_detect_anomalies_uniform_distribution():
    """When all minutes have the same count, std=0, threshold=mean.
    No bucket exceeds the threshold."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    # 10 minutes, 1 request each → mean=1, std=0, threshold=1
    assert detect_anomalies(entries) == []


def test_detect_anomalies_burst_detected():
    """A minute with a large burst should be flagged as anomalous.

    We create 10 minutes with 1 request each, then one minute with 100 requests.
    The burst minute should exceed mean + 3*std.
    """
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 10 normal minutes, 1 request each
    for i in range(10):
        entries.append(_entry(base + timedelta(minutes=i)))
    # 1 burst minute, 100 requests
    burst_time = base + timedelta(minutes=10)
    for _ in range(100):
        entries.append(_entry(burst_time))

    anomalies = detect_anomalies(entries)
    assert burst_time in anomalies


def test_detect_anomalies_multiple_ips_same_minute():
    """Requests from different IPs in the same minute should be counted together.
    The anomaly detection operates on per-minute counts, not per-IP counts."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    for i in range(5):
        entries.append(_entry(base, ip=f"10.0.0.{i}"))
    # 5 requests in 1 minute → count=5, mean=5, std=0, threshold=5
    # 5 is not > 5, so no anomaly
    assert detect_anomalies(entries) == []


def test_detect_anomalies_seconds_truncated_to_minute():
    """Timestamps with different seconds but same minute should be bucketed together."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=30)),
        _entry(base + timedelta(seconds=59)),
    ]
    # All 3 in the same minute bucket
    counts = {}
    for e in entries:
        bucket = e.timestamp.replace(second=0, microsecond=0)
        counts[bucket] = counts.get(bucket, 0) + 1
    assert len(counts) == 1
    assert counts[base] == 3


def test_detect_anomalies_returns_list_of_datetimes():
    """Anomaly buckets should be datetime objects (minute-truncated)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    for i in range(5):
        entries.append(_entry(base + timedelta(minutes=i)))
    burst_time = base + timedelta(minutes=5)
    for _ in range(50):
        entries.append(_entry(burst_time))

    anomalies = detect_anomalies(entries)
    for a in anomalies:
        assert isinstance(a, datetime)
        assert a.second == 0
        assert a.microsecond == 0


# ── session_window ────────────────────────────────────────────────────────


def test_session_window_empty_input():
    """No entries → no sessions."""
    assert session_window([]) == []


def test_session_window_single_entry():
    """A single entry forms one session."""
    entry = _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))
    sessions = session_window([entry])
    assert len(sessions) == 1
    ip, evs = sessions[0]
    assert ip == "10.0.0.1"
    assert len(evs) == 1


def test_session_window_single_ip_continuous():
    """All entries from one IP within the window form a single session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    ip, evs = sessions[0]
    assert ip == "10.0.0.1"
    assert len(evs) == 10


def test_session_window_gap_splits_session():
    """A gap larger than window_seconds splits a session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        # 40-minute gap (> 30 min default window)
        _entry(base + timedelta(minutes=50)),
        _entry(base + timedelta(minutes=60)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    assert len(sessions[0][1]) == 2
    assert len(sessions[1][1]) == 2


def test_session_window_multiple_ips():
    """Entries from different IPs form separate sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base, ip="10.0.0.1"),
        _entry(base + timedelta(minutes=5), ip="10.0.0.2"),
        _entry(base + timedelta(minutes=10), ip="10.0.0.1"),
    ]
    sessions = session_window(entries, window_seconds=1800)
    # Two IPs, each with their own session
    assert len(sessions) == 2
    ips = {s[0] for s in sessions}
    assert ips == {"10.0.0.1", "10.0.0.2"}


def test_session_window_custom_window():
    """A custom window_seconds parameter should be respected.

    We use a 300s window with gaps of 301s to ensure the gap exceeds the window.
    """
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=301)),  # 301s > 300s window
        _entry(base + timedelta(seconds=602)),  # another 301s gap
    ]
    sessions = session_window(entries, window_seconds=300)
    assert len(sessions) == 3


def test_session_window_entries_sorted_by_time():
    """Entries within a session should be sorted by timestamp."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base + timedelta(minutes=10)),
        _entry(base),
        _entry(base + timedelta(minutes=5)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    _, evs = sessions[0]
    timestamps = [e.timestamp for e in evs]
    assert timestamps == sorted(timestamps)


def test_session_window_exact_window_boundary():
    """A gap exactly equal to window_seconds should NOT split the session
    (the code uses > not >=)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1800)),  # exactly 30 min
    ]
    sessions = session_window(entries, window_seconds=1800)
    # gap == 1800, which is NOT > 1800, so single session
    assert len(sessions) == 1
    assert len(sessions[0][1]) == 2
