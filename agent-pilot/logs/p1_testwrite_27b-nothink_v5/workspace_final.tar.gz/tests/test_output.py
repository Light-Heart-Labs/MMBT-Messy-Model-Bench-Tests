"""Tests for output.py — JSON, CSV, text, and aggregate rendering.

These tests cover edge cases like empty input, special characters in URLs,
unicode content, and the hand-built JSON formatter's behavior with edge cases.
"""
from datetime import datetime, timezone
from collections import Counter

from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── to_json ───────────────────────────────────────────────────────────────


def test_to_json_empty_input():
    """Empty input should produce an empty JSON array."""
    assert to_json([]) == "[]"


def test_to_json_single_entry():
    """A single entry should produce a JSON array with one object."""
    entries = [_entry()]
    result = to_json(entries)
    assert result.startswith("[")
    assert result.endswith("]")
    assert '"ip":"10.0.0.1"' in result
    assert '"status":200' in result
    assert '"bytes":100' in result


def test_to_json_multiple_entries():
    """Multiple entries should be comma-separated within the array."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_json(entries)
    # Should have two objects separated by comma
    assert result.count('"ip"') == 2
    assert '"status":200' in result
    assert '"status":404' in result


def test_to_json_zero_bytes():
    """Entries with 0 bytes should render as "bytes":0."""
    entries = [_entry(bytes=0)]
    result = to_json(entries)
    assert '"bytes":0' in result


def test_to_json_special_url_characters():
    """URLs with special characters should be included as-is in the JSON.

    Note: the hand-built JSON does NOT escape special characters like quotes
    or backslashes. This test documents the current behavior.
    """
    entries = [_entry(url="/path?foo=bar&baz=1")]
    result = to_json(entries)
    assert '/path?foo=bar&baz=1' in result


def test_to_json_unicode_url():
    """URLs with unicode characters should be included as-is."""
    entries = [_entry(url="/café")]
    result = to_json(entries)
    assert "/café" in result


def test_to_json_iso_timestamp():
    """Timestamps should be rendered in ISO format."""
    entries = [_entry()]
    result = to_json(entries)
    assert "2026-01-01T12:00:00+00:00" in result


# ── to_csv ────────────────────────────────────────────────────────────────


def test_to_csv_empty_input():
    """Empty input should produce just the header row."""
    result = to_csv([])
    lines = result.strip().split('\n')
    assert len(lines) == 1
    assert "ip,user,timestamp,method,url,protocol,status,bytes" in lines[0]


def test_to_csv_single_entry():
    """A single entry should produce header + one data row."""
    entries = [_entry()]
    result = to_csv(entries)
    lines = result.strip().split('\n')
    assert len(lines) == 2
    assert "10.0.0.1" in lines[1]


def test_to_csv_multiple_entries():
    """Multiple entries should each get their own row."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_csv(entries)
    lines = result.strip().split('\n')
    assert len(lines) == 3  # header + 2 data rows


def test_to_csv_comma_in_url():
    """URLs with commas should be properly quoted by the csv module."""
    entries = [_entry(url="/path,with,commas")]
    result = to_csv(entries)
    # csv.writer should quote fields containing commas
    assert '"path,with,commas"' in result or 'path,with,commas' in result


# ── to_text ───────────────────────────────────────────────────────────────


def test_to_text_empty_input():
    """Empty input should produce an empty string."""
    assert to_text([]) == ""


def test_to_text_single_entry():
    """A single entry should produce one line of formatted text."""
    entries = [_entry()]
    result = to_text(entries)
    assert "10.0.0.1" in result
    assert "GET" in result
    assert "200" in result
    assert "/" in result


def test_to_text_multiple_entries():
    """Multiple entries should be newline-separated."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_text(entries)
    lines = result.split('\n')
    assert len(lines) == 2


def test_to_text_ip_alignment():
    """IPs should be right-aligned in a 15-character field."""
    entries = [_entry(ip="1.2.3.4"), _entry(ip="192.168.1.100")]
    result = to_text(entries)
    lines = result.split('\n')
    # Both lines should have consistent formatting
    for line in lines:
        assert "GET" in line


def test_to_text_various_status_codes():
    """Different status codes should be rendered correctly."""
    entries = [_entry(status=200), _entry(status=301), _entry(status=500)]
    result = to_text(entries)
    assert "200" in result
    assert "301" in result
    assert "500" in result


# ── render_aggregate ──────────────────────────────────────────────────────


def test_render_aggregate_text_with_items():
    """A Counter-like object with .items() should render as key\tvalue lines."""
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_text_with_list_of_tuples():
    """A list of (key, value) tuples should render as key\tvalue lines."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_json_with_items():
    """A Counter-like object should render as JSON-like key:value pairs."""
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="json")
    assert '"200":10' in result
    assert '"404":3' in result


def test_render_aggregate_json_with_list():
    """A list of tuples should render as JSON-like key:value pairs."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="json")
    assert '"200":10' in result
    assert '"404":3' in result


def test_render_aggregate_unknown_format_raises():
    """An unknown format should raise ValueError."""
    agg = Counter({"200": 10})
    try:
        render_aggregate(agg, fmt="xml")
        assert False, "Expected ValueError"
    except ValueError as e:
        assert "unknown format" in str(e)


def test_render_aggregate_empty_counter():
    """An empty Counter should render as empty text."""
    agg = Counter()
    result = render_aggregate(agg, fmt="text")
    assert result == ""


def test_render_aggregate_empty_list():
    """An empty list should render as empty text."""
    agg = []
    result = render_aggregate(agg, fmt="text")
    assert result == ""


def test_render_aggregate_json_empty_counter():
    """An empty Counter should render as empty JSON object."""
    agg = Counter()
    result = render_aggregate(agg, fmt="json")
    assert result == "{}"
