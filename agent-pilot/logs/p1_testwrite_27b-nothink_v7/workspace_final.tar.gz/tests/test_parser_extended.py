"""Additional tests for parser.py — parse_lines generator, edge cases.

The existing test_parser.py covers basic parsing. This file covers:
- parse_lines generator behavior
- Edge cases for parse_timestamp (timezone offsets, boundary dates)
- Edge cases for parse_line (whitespace, special characters)
"""
from datetime import datetime, timezone, timedelta

from logalyzer.parser import parse_line, parse_lines, parse_timestamp


def test_parse_lines_empty_iterable():
    """parse_lines with empty iterable should yield nothing."""
    result = list(parse_lines([]))
    assert result == []


def test_parse_lines_single_line():
    """parse_lines with one valid line should yield one entry."""
    lines = ['127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326']
    result = list(parse_lines(lines))
    assert len(result) == 1
    assert result[0].ip == "127.0.0.1"


def test_parse_lines_skips_invalid():
    """parse_lines should skip lines that don't match the format."""
    lines = [
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326',
        'garbage line',
        '',
        '127.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "POST /api HTTP/1.0" 201 100',
    ]
    result = list(parse_lines(lines))
    assert len(result) == 2
    assert result[0].ip == "127.0.0.1"
    assert result[1].ip == "127.0.0.2"


def test_parse_lines_is_generator():
    """parse_lines should return a generator."""
    result = parse_lines([])
    assert hasattr(result, '__next__')


def test_parse_lines_preserves_order():
    """parse_lines should yield entries in the order they appear."""
    lines = [
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /a HTTP/1.0" 200 100',
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET /b HTTP/1.0" 200 200',
        '10.0.0.3 - - [10/Oct/2000:13:55:38 +0000] "GET /c HTTP/1.0" 200 300',
    ]
    result = list(parse_lines(lines))
    assert [e.url for e in result] == ["/a", "/b", "/c"]


def test_parse_line_leading_trailing_whitespace():
    """parse_line should strip leading/trailing whitespace."""
    line = '  127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326  '
    e = parse_line(line)
    assert e is not None
    assert e.ip == "127.0.0.1"


def test_parse_line_only_whitespace():
    """parse_line with only whitespace should return None."""
    assert parse_line("   ") is None
    assert parse_line("\t") is None
    assert parse_line("\n") is None


def test_parse_line_with_dash_bytes():
    """parse_line should treat '-' as 0 bytes."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 304 -'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 0


def test_parse_line_various_status_codes():
    """parse_line should handle various HTTP status codes."""
    for status in [100, 200, 201, 301, 302, 304, 400, 401, 403, 404, 500, 502, 503]:
        line = f'10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" {status} 100'
        e = parse_line(line)
        assert e is not None, f"Failed to parse status {status}"
        assert e.status == status


def test_parse_line_various_methods():
    """parse_line should handle various HTTP methods."""
    for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
        line = f'10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "{method} / HTTP/1.0" 200 100'
        e = parse_line(line)
        assert e is not None, f"Failed to parse method {method}"
        assert e.method == method


def test_parse_line_unicode_url():
    """parse_line should handle URLs with percent-encoded unicode."""
    line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /path/%E4%B8%AD%E6%96%87 HTTP/1.0" 200 100'
    e = parse_line(line)
    assert e is not None
    assert "/path/%E4%B8%AD%E6%96%87" in e.url


def test_parse_line_long_url():
    """parse_line should handle very long URLs."""
    long_url = "/" + "a" * 1000
    line = f'10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET {long_url} HTTP/1.0" 200 100'
    e = parse_line(line)
    assert e is not None
    assert e.url == long_url


def test_parse_line_ipv6_address():
    """parse_line should handle IPv6 addresses (as non-whitespace)."""
    line = '::1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
    e = parse_line(line)
    assert e is not None
    assert e.ip == "::1"


def test_parse_line_zero_bytes_explicit():
    """parse_line should handle explicit 0 bytes (not dash)."""
    line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 204 0'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 0


def test_parse_timestamp_positive_timezone():
    """Timestamp with positive timezone offset should convert correctly to UTC."""
    # 13:00 +0500 = 08:00 UTC
    ts = parse_timestamp("10/Oct/2000:13:00:00 +0500")
    assert ts.hour == 8
    assert ts.minute == 0


def test_parse_timestamp_negative_timezone():
    """Timestamp with negative timezone offset should convert correctly to UTC."""
    # 13:00 -0500 = 18:00 UTC
    ts = parse_timestamp("10/Oct/2000:13:00:00 -0500")
    assert ts.hour == 18
    assert ts.minute == 0


def test_parse_timestamp_utc_offset():
    """Timestamp with +0000 should remain unchanged."""
    ts = parse_timestamp("10/Oct/2000:13:00:00 +0000")
    assert ts.hour == 13
    assert ts.minute == 0


def test_parse_timestamp_malformed_raises():
    """Malformed timestamp should raise ValueError."""
    try:
        parse_timestamp("not-a-timestamp")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass


def test_parse_timestamp_missing_seconds_raises():
    """Timestamp missing seconds should raise ValueError."""
    try:
        parse_timestamp("10/Oct/2000:13:00 +0000")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass


def test_parse_timestamp_all_months_except_jul():
    """Test all months that ARE in MONTH_NAMES (Jul is missing — known bug)."""
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Aug", "Sep", "Oct", "Nov", "Dec"]
    for month in months:
        ts = parse_timestamp(f"15/{month}/2026:08:30:00 +0000")
        assert ts is not None, f"Failed to parse month {month}"


def test_parse_line_user_field_dash():
    """parse_line should handle '-' as user (unauthenticated)."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    e = parse_line(line)
    assert e is not None
    assert e.user == "-"


def test_parse_line_user_field_with_name():
    """parse_line should handle named users."""
    line = '127.0.0.1 - frank [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    e = parse_line(line)
    assert e is not None
    assert e.user == "frank"


def test_parse_line_protocol_variants():
    """parse_line should handle different HTTP protocol versions."""
    for proto in ["HTTP/1.0", "HTTP/1.1", "HTTP/2.0"]:
        line = f'10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / {proto}" 200 100'
        e = parse_line(line)
        assert e is not None, f"Failed to parse protocol {proto}"
        assert e.protocol == proto


def test_parse_line_invalid_timestamp_returns_none():
    """parse_line should return None when timestamp is unparseable.
    This exercises the except ValueError branch in parse_line."""
    # The regex will match this line, but parse_timestamp will fail
    # because the month name is invalid
    line = '10.0.0.1 - - [10/Xyz/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
    e = parse_line(line)
    assert e is None
