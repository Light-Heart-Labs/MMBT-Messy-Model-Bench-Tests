"""Shared pytest fixtures."""
import sys
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Monkey-patch: logalyzer/filters.py uses `from collections import Iterable`
# which was removed in Python 3.11 (moved to collections.abc).
# We cannot modify the source, so we provide a compatibility shim.
import collections
if not hasattr(collections, "Iterable"):
    from collections.abc import Iterable as _Iterable
    collections.Iterable = _Iterable
