"""Tests for utils.py — utility functions (parse_iso_date, format_bytes, format_legacy, chunked).

Covers edge cases: zero/negative bytes, very large values, empty sequences,
boundary conditions for chunking, and the legacy format function.
"""
from datetime import datetime, timezone

from logalyzer.utils import parse_iso_date, format_bytes, format_legacy, chunked
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── parse_iso_date ──────────────────────────────────────────────────────────

def test_parse_iso_date_basic():
    """Basic YYYY-MM-DD date should parse to midnight UTC."""
    dt = parse_iso_date("2026-01-15")
    assert dt == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_leap_year():
    """Leap year date should parse correctly."""
    dt = parse_iso_date("2024-02-29")
    assert dt == datetime(2024, 2, 29, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_end_of_year():
    """Last day of year should parse correctly."""
    dt = parse_iso_date("2026-12-31")
    assert dt == datetime(2026, 12, 31, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_start_of_year():
    """First day of year should parse correctly."""
    dt = parse_iso_date("2026-01-01")
    assert dt == datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_returns_utc():
    """Parsed datetime should always have UTC timezone."""
    dt = parse_iso_date("2026-06-15")
    assert dt.tzinfo is timezone.utc


def test_parse_iso_date_invalid_format_raises():
    """Invalid date format should raise ValueError from strptime."""
    try:
        parse_iso_date("not-a-date")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass


def test_parse_iso_date_invalid_date_raises():
    """Invalid date like Feb 30 should raise ValueError."""
    try:
        parse_iso_date("2026-02-30")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass


# ── format_bytes ────────────────────────────────────────────────────────────

def test_format_bytes_zero():
    """Zero bytes should format as '0.0 B'."""
    assert format_bytes(0) == "0.0 B"


def test_format_bytes_one():
    """One byte should format as '1.0 B'."""
    assert format_bytes(1) == "1.0 B"


def test_format_bytes_below_kb():
    """Values below 1024 should stay in bytes."""
    assert format_bytes(500) == "500.0 B"


def test_format_bytes_exactly_kb():
    """Exactly 1024 bytes should format as '1.0 KB'."""
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_exactly_mb():
    """Exactly 1 MB should format as '1.0 MB'."""
    assert format_bytes(1024 * 1024) == "1.0 MB"


def test_format_bytes_exactly_gb():
    """Exactly 1 GB should format as '1.0 GB'."""
    assert format_bytes(1024 ** 3) == "1.0 GB"


def test_format_bytes_exactly_tb():
    """Exactly 1 TB should format as '1.0 TB'."""
    assert format_bytes(1024 ** 4) == "1.0 TB"


def test_format_bytes_petabyte_range():
    """Values beyond TB should format as PB."""
    result = format_bytes(1024 ** 5)
    assert "PB" in result


def test_format_bytes_fractional_kb():
    """Values between B and KB should show as B, not fractional KB."""
    assert format_bytes(512) == "512.0 B"


def test_format_bytes_fractional_mb():
    """Values between KB and MB should show as KB with one decimal."""
    result = format_bytes(1024 * 1.5)
    assert "B" in result


def test_format_bytes_very_large():
    """Extremely large values should still format without error."""
    result = format_bytes(1024 ** 6)
    assert "PB" in result


def test_format_bytes_negative():
    """Negative byte values — the function doesn't guard against this.
    It will produce negative formatted output (documented behavior, not a fix)."""
    result = format_bytes(-1024)
    assert "B" in result
    # negative values stay in B because -n < 1024 is always True


# ── format_legacy ───────────────────────────────────────────────────────────

def test_format_legacy_basic():
    """Legacy format should produce pipe-delimited string."""
    entry = _entry()
    result = format_legacy(entry)
    assert "10.0.0.1" in result
    assert "200" in result
    assert "/" in result
    assert "|" in result


def test_format_legacy_format_structure():
    """Legacy format follows: ip | timestamp | status | url."""
    entry = _entry(ip="1.2.3.4", status=404, url="/admin")
    result = format_legacy(entry)
    parts = result.split(" | ")
    assert parts[0] == "1.2.3.4"
    assert parts[2] == "404"
    assert parts[3] == "/admin"


def test_format_legacy_timestamp_included():
    """Timestamp should be included in legacy format."""
    entry = _entry()
    result = format_legacy(entry)
    assert "2026-01-01" in result


# ── chunked ─────────────────────────────────────────────────────────────────

def test_chunked_empty_sequence():
    """Empty sequence should produce no chunks."""
    result = list(chunked([], 3))
    assert result == []


def test_chunked_exact_multiple():
    """Sequence length exactly divisible by chunk size should produce even chunks."""
    result = list(chunked([1, 2, 3, 4, 5, 6], 3))
    assert result == [[1, 2, 3], [4, 5, 6]]


def test_chunked_remainder():
    """Sequence with remainder should produce a smaller final chunk."""
    result = list(chunked([1, 2, 3, 4, 5], 2))
    assert result == [[1, 2], [3, 4], [5]]


def test_chunked_single_element():
    """Single element with chunk size 1 should produce one chunk."""
    result = list(chunked([42], 1))
    assert result == [[42]]


def test_chunked_chunk_size_larger_than_sequence():
    """Chunk size larger than sequence should produce one chunk."""
    result = list(chunked([1, 2], 10))
    assert result == [[1, 2]]


def test_chunked_chunk_size_one():
    """Chunk size of 1 should produce one-element chunks."""
    result = list(chunked([1, 2, 3], 1))
    assert result == [[1], [2], [3]]


def test_chunked_is_generator():
    """chunked should return a generator, not a list."""
    result = chunked([1, 2, 3], 2)
    # Should be a generator object
    assert hasattr(result, '__next__')


def test_chunked_with_strings():
    """chunked should work with any iterable, not just numbers."""
    result = list(chunked(["a", "b", "c", "d"], 2))
    assert result == [["a", "b"], ["c", "d"]]
