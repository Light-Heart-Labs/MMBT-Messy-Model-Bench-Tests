"""Tests for io.py — file loading (load, load_iter).

Tests file I/O with various edge cases: empty files, malformed lines,
files without trailing newlines, and the generator-based load_iter.
"""
import os
import tempfile

from logalyzer.io import load, load_iter


def _write_log(content):
    """Write content to a temp file and return the path."""
    f = tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False)
    f.write(content)
    f.close()
    return f.name


# ── load ────────────────────────────────────────────────────────────────────

def test_load_empty_file():
    """Empty file should return empty list."""
    path = _write_log("")
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_single_line():
    """Single valid log line should return one entry."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 2326'
    path = _write_log(line + "\n")
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_multiple_lines():
    """Multiple valid lines should return multiple entries."""
    content = (
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "POST /api HTTP/1.0" 201 200\n'
    )
    path = _write_log(content)
    try:
        result = load(path)
        assert len(result) == 2
        assert result[0].ip == "10.0.0.1"
        assert result[1].ip == "10.0.0.2"
    finally:
        os.unlink(path)


def test_load_skips_malformed_lines():
    """Malformed lines should be silently skipped."""
    content = (
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n'
        'this is garbage\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "POST /api HTTP/1.0" 201 200\n'
    )
    path = _write_log(content)
    try:
        result = load(path)
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_no_trailing_newline():
    """File without trailing newline should still parse the last line."""
    line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
    path = _write_log(line)  # no trailing newline
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "10.0.0.1"
    finally:
        os.unlink(path)


def test_load_only_empty_lines():
    """File with only empty lines should return empty list."""
    path = _write_log("\n\n\n")
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_only_malformed_lines():
    """File with only malformed lines should return empty list."""
    path = _write_log("garbage1\ngarbage2\ngarbage3\n")
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_mixed_valid_and_empty_lines():
    """Mix of valid, empty, and malformed lines should only return valid entries."""
    content = (
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n'
        '\n'
        'garbage\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET /page HTTP/1.0" 404 0\n'
    )
    path = _write_log(content)
    try:
        result = load(path)
        assert len(result) == 2
        assert result[0].status == 200
        assert result[1].status == 404
    finally:
        os.unlink(path)


def test_load_preserves_order():
    """Entries should be returned in the order they appear in the file."""
    content = (
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /a HTTP/1.0" 200 100\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET /b HTTP/1.0" 200 200\n'
        '10.0.0.3 - - [10/Oct/2000:13:55:38 +0000] "GET /c HTTP/1.0" 200 300\n'
    )
    path = _write_log(content)
    try:
        result = load(path)
        assert [e.url for e in result] == ["/a", "/b", "/c"]
    finally:
        os.unlink(path)


# ── load_iter ───────────────────────────────────────────────────────────────

def test_load_iter_empty_file():
    """Empty file should yield no entries."""
    path = _write_log("")
    try:
        result = list(load_iter(path))
        assert result == []
    finally:
        os.unlink(path)


def test_load_iter_single_line():
    """Single valid line should yield one entry."""
    line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n'
    path = _write_log(line)
    try:
        result = list(load_iter(path))
        assert len(result) == 1
    finally:
        os.unlink(path)


def test_load_iter_skips_malformed():
    """Malformed lines should be silently skipped by the generator."""
    content = (
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n'
        'garbage\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET / HTTP/1.0" 200 200\n'
    )
    path = _write_log(content)
    try:
        result = list(load_iter(path))
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_is_generator():
    """load_iter should return a generator, not a list."""
    path = _write_log('10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100\n')
    try:
        result = load_iter(path)
        assert hasattr(result, '__next__')
    finally:
        os.unlink(path)


def test_load_iter_no_trailing_newline():
    """File without trailing newline should still yield the last entry."""
    line = '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET / HTTP/1.0" 200 100'
    path = _write_log(line)
    try:
        result = list(load_iter(path))
        assert len(result) == 1
    finally:
        os.unlink(path)


def test_load_iter_preserves_order():
    """Entries should be yielded in file order."""
    content = (
        '10.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "GET /a HTTP/1.0" 200 100\n'
        '10.0.0.2 - - [10/Oct/2000:13:55:37 +0000] "GET /b HTTP/1.0" 200 200\n'
    )
    path = _write_log(content)
    try:
        result = list(load_iter(path))
        assert [e.url for e in result] == ["/a", "/b"]
    finally:
        os.unlink(path)
