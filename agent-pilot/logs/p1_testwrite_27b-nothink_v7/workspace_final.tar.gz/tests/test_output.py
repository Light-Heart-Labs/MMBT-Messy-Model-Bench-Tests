"""Tests for output.py — formatters (JSON, CSV, text, render_aggregate).

Covers edge cases: empty entries, special characters in fields, large byte values,
and the legacy format_legacy function.
"""
from datetime import datetime, timezone
from collections import Counter

from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── to_json ─────────────────────────────────────────────────────────────────

def test_to_json_empty():
    """Empty entries list should produce an empty JSON array."""
    assert to_json([]) == "[]"


def test_to_json_single_entry():
    """Single entry should produce a JSON array with one object."""
    entries = [_entry()]
    result = to_json(entries)
    assert result.startswith("[")
    assert result.endswith("]")
    assert '"ip":"10.0.0.1"' in result
    assert '"status":200' in result
    assert '"bytes":100' in result


def test_to_json_multiple_entries():
    """Multiple entries should be comma-separated within the array."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_json(entries)
    assert '"status":200' in result
    assert '"status":404' in result
    # Two objects separated by comma
    assert result.count('"ip"') == 2


def test_to_json_zero_bytes():
    """Zero bytes should render as 0, not as a dash."""
    entries = [_entry(bytes=0)]
    result = to_json(entries)
    assert '"bytes":0' in result


def test_to_json_large_bytes():
    """Large byte values should render correctly as integers."""
    entries = [_entry(bytes=999999999)]
    result = to_json(entries)
    assert '"bytes":999999999' in result


def test_to_json_special_url_characters():
    """URLs with special characters should be included as-is."""
    entries = [_entry(url="/path?foo=bar&baz=1")]
    result = to_json(entries)
    assert '/path?foo=bar&baz=1' in result


def test_to_json_iso_timestamp():
    """Timestamps should be rendered in ISO format."""
    entries = [_entry()]
    result = to_json(entries)
    assert "2026-01-01T12:00:00" in result


# ── to_csv ──────────────────────────────────────────────────────────────────

def test_to_csv_empty():
    """Empty entries should produce only the header row."""
    result = to_csv([])
    lines = result.strip().split('\n')
    assert len(lines) == 1
    assert "ip,user,timestamp,method,url,protocol,status,bytes" in lines[0]


def test_to_csv_single_entry():
    """Single entry should produce header + one data row."""
    entries = [_entry()]
    result = to_csv(entries)
    lines = result.strip().split('\n')
    assert len(lines) == 2
    assert "10.0.0.1" in lines[1]


def test_to_csv_multiple_entries():
    """Multiple entries should produce header + N data rows."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_csv(entries)
    lines = result.strip().split('\n')
    assert len(lines) == 3


def test_to_csv_comma_in_field():
    """Fields with commas should be properly quoted by csv.writer."""
    entries = [_entry(url="/path,with,commas")]
    result = to_csv(entries)
    # csv.writer should quote the field
    assert '"/path,with,commas"' in result or "/path,with,commas" in result


# ── to_text ─────────────────────────────────────────────────────────────────

def test_to_text_empty():
    """Empty entries should produce an empty string."""
    assert to_text([]) == ""


def test_to_text_single_entry():
    """Single entry should produce one formatted line."""
    entries = [_entry()]
    result = to_text(entries)
    assert "10.0.0.1" in result
    assert "GET" in result
    assert "200" in result
    assert "/" in result


def test_to_text_multiple_entries():
    """Multiple entries should be newline-separated."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_text(entries)
    lines = result.split('\n')
    assert len(lines) == 2


def test_to_text_ip_alignment():
    """IP addresses should be right-aligned in 15-char field."""
    entries = [_entry(ip="1.2.3.4")]
    result = to_text(entries)
    # IP should be right-aligned with padding
    assert "1.2.3.4" in result


def test_to_text_method_alignment():
    """HTTP method should be left-aligned in 6-char field."""
    entries = [_entry(method="GET")]
    result = to_text(entries)
    assert "GET   " in result or "GET" in result


# ── render_aggregate ────────────────────────────────────────────────────────

def test_render_aggregate_text_counter():
    """Counter objects should render as key\tvalue lines."""
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_text_dict():
    """Dict objects should render as key\tvalue lines."""
    agg = {"200": 10, "404": 3}
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_text_list_of_tuples():
    """List of (key, value) tuples should render as key\tvalue lines."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_json_counter():
    """Counter objects should render as JSON-like key:value pairs."""
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="json")
    assert '"200":10' in result
    assert '"404":3' in result


def test_render_aggregate_json_list():
    """List of tuples should render as JSON-like key:value pairs."""
    agg = [("200", 10), ("404", 3)]
    result = render_aggregate(agg, fmt="json")
    assert '"200":10' in result
    assert '"404":3' in result


def test_render_aggregate_unknown_format_raises():
    """Unknown format should raise ValueError."""
    agg = Counter({"200": 10})
    try:
        render_aggregate(agg, fmt="xml")
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "unknown format" in str(e)


def test_render_aggregate_empty_counter_text():
    """Empty Counter should produce empty string."""
    agg = Counter()
    result = render_aggregate(agg, fmt="text")
    assert result == ""


def test_render_aggregate_empty_list_json():
    """Empty list should produce empty JSON object."""
    agg = []
    result = render_aggregate(agg, fmt="json")
    assert result == "{}"
