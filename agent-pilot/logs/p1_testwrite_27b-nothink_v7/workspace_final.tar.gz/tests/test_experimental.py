"""Tests for experimental.py — anomaly detection and session windowing.

These tests exercise the full logic of detect_anomalies and session_window,
including edge cases like empty input, single entries, and uniform distributions.
"""
from datetime import datetime, timezone, timedelta

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1"):
    """Helper to create a LogEntry at a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )


# ── detect_anomalies ────────────────────────────────────────────────────────

def test_detect_anomalies_empty_input():
    """Empty input should return empty list (no anomalies possible)."""
    assert detect_anomalies([]) == []


def test_detect_anomalies_single_entry():
    """A single entry has zero variance, so threshold = mean. No anomalies."""
    entries = [_entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))]
    assert detect_anomalies(entries) == []


def test_detect_anomalies_uniform_distribution():
    """Uniform request counts across minutes should yield no anomalies."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    # Each minute has exactly 1 request → std=0, threshold=1, no bucket > 1
    assert detect_anomalies(entries) == []


def test_detect_anomalies_spike_detected():
    """A minute with many more requests than others should be flagged."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 10 minutes with 1 request each
    for i in range(10):
        entries.append(_entry(base + timedelta(minutes=i)))
    # 1 minute with 100 requests (clear spike)
    spike_time = base + timedelta(minutes=10)
    for _ in range(100):
        entries.append(_entry(spike_time))

    anomalies = detect_anomalies(entries)
    # The spike minute should be in the results
    assert spike_time.replace(second=0, microsecond=0) in anomalies


def test_detect_anomalies_all_same_minute():
    """All entries in the same minute → one bucket, zero variance, no anomalies."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base) for _ in range(50)]
    assert detect_anomalies(entries) == []


def test_detect_anomalies_many_buckets_one_spike():
    """Many normal minutes with 1 request, one spike minute with 200.
    With enough normal buckets, the spike exceeds 3 std devs."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 20 normal minutes with 1 request each
    for i in range(20):
        entries.append(_entry(base + timedelta(minutes=i)))
    # 1 spike minute with 200 requests
    spike_time = base + timedelta(minutes=20)
    for _ in range(200):
        entries.append(_entry(spike_time))

    anomalies = detect_anomalies(entries)
    assert spike_time.replace(second=0, microsecond=0) in anomalies


def test_detect_anomalies_seconds_truncated_to_minute():
    """Timestamps with different seconds but same minute should be bucketed together."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=30)),
        _entry(base + timedelta(seconds=59)),
    ]
    # All three are in the same minute bucket
    counts = detect_anomalies(entries)
    # With 3 entries in one bucket and std=0, threshold=3, no bucket > 3
    assert counts == []


def test_detect_anomalies_returns_list_of_datetimes():
    """Anomalies should be returned as datetime objects (minute-bucketed)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    for i in range(20):
        entries.append(_entry(base + timedelta(minutes=i)))
    spike_time = base + timedelta(minutes=20)
    for _ in range(200):
        entries.append(_entry(spike_time))

    anomalies = detect_anomalies(entries)
    for a in anomalies:
        assert isinstance(a, datetime)
        assert a.second == 0
        assert a.microsecond == 0


# ── session_window ──────────────────────────────────────────────────────────

def test_session_window_empty_input():
    """No entries → no sessions."""
    assert session_window([]) == []


def test_session_window_single_entry():
    """One entry → one session with one entry."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base)]
    sessions = session_window(entries)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    assert ip == "10.0.0.1"
    assert len(session_entries) == 1


def test_session_window_same_ip_same_session():
    """Entries from the same IP within the window should be one session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        _entry(base + timedelta(minutes=20)),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 1
    _, session_entries = sessions[0]
    assert len(session_entries) == 3


def test_session_window_gap_splits_session():
    """A gap larger than window_seconds should split into two sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        # 40-minute gap (default window is 1800s = 30min)
        _entry(base + timedelta(minutes=50)),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 2
    _, first = sessions[0]
    _, second = sessions[1]
    assert len(first) == 2
    assert len(second) == 1


def test_session_window_custom_window():
    """Custom window_seconds should control session splitting."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=5)),
        _entry(base + timedelta(minutes=10)),
    ]
    # With 2-minute window, each gap of 5 minutes splits
    sessions = session_window(entries, window_seconds=120)
    assert len(sessions) == 3


def test_session_window_multiple_ips():
    """Different IPs should produce separate sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base, ip="10.0.0.1"),
        _entry(base + timedelta(minutes=1), ip="10.0.0.2"),
        _entry(base + timedelta(minutes=2), ip="10.0.0.1"),
    ]
    sessions = session_window(entries)
    assert len(sessions) == 2
    ips = {ip for ip, _ in sessions}
    assert ips == {"10.0.0.1", "10.0.0.2"}


def test_session_window_entries_sorted_by_time():
    """Entries within a session should be sorted by timestamp."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base + timedelta(minutes=10)),
        _entry(base),
        _entry(base + timedelta(minutes=5)),
    ]
    sessions = session_window(entries)
    _, session_entries = sessions[0]
    timestamps = [e.timestamp for e in session_entries]
    assert timestamps == sorted(timestamps)


def test_session_window_boundary_gap_exactly_window():
    """A gap exactly equal to window_seconds should NOT split (condition is >)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1800)),  # exactly 30 min
    ]
    sessions = session_window(entries, window_seconds=1800)
    # gap == window_seconds, not >, so same session
    assert len(sessions) == 1
    assert len(sessions[0][1]) == 2
