"""Additional tests for filters.py — expression_filter, combine_and, edge cases.

The existing test_filters.py covers status_filter, url_regex_filter, ip_allowlist_filter,
and date_range_filter. This file covers the untested expression_filter and combine_and,
plus edge cases for existing filters.
"""
from datetime import datetime, timezone

from logalyzer.filters import (
    combine_and,
    expression_filter,
    ip_allowlist_filter,
    status_filter,
    url_regex_filter,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── expression_filter ───────────────────────────────────────────────────────

def test_expression_filter_status_comparison():
    """Expression filter should evaluate Python expressions against entry."""
    pred = expression_filter("entry.status >= 400")
    assert pred(_entry(status=404)) is True
    assert pred(_entry(status=200)) is False


def test_expression_filter_bytes_comparison():
    """Expression filter should work with bytes field."""
    pred = expression_filter("entry.bytes > 50")
    assert pred(_entry(bytes=100)) is True
    assert pred(_entry(bytes=10)) is False


def test_expression_filter_method_check():
    """Expression filter should work with string comparison on method."""
    pred = expression_filter("entry.method == 'POST'")
    assert pred(_entry(method="POST")) is True
    assert pred(_entry(method="GET")) is False


def test_expression_filter_combined_conditions():
    """Expression filter should support compound boolean expressions."""
    pred = expression_filter("entry.status >= 500 and entry.bytes > 0")
    assert pred(_entry(status=500, bytes=100)) is True
    assert pred(_entry(status=500, bytes=0)) is False
    assert pred(_entry(status=200, bytes=100)) is False


def test_expression_filter_or_condition():
    """Expression filter should support OR conditions."""
    pred = expression_filter("entry.method == 'GET' or entry.method == 'POST'")
    assert pred(_entry(method="GET")) is True
    assert pred(_entry(method="POST")) is True
    assert pred(_entry(method="DELETE")) is False


def test_expression_filter_url_contains():
    """Expression filter should work with string containment checks."""
    pred = expression_filter("'admin' in entry.url")
    assert pred(_entry(url="/admin/login")) is True
    assert pred(_entry(url="/index.html")) is False


def test_expression_filter_builtins_restricted():
    """Expression filter should not have access to builtins (security)."""
    pred = expression_filter("__builtins__")
    # With __builtins__ set to {}, this should evaluate to falsy
    result = pred(_entry())
    assert result is False


def test_expression_filter_ip_check():
    """Expression filter should work with IP string comparison."""
    pred = expression_filter("entry.ip.startswith('10.')")
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="192.168.1.1")) is False


# ── combine_and ─────────────────────────────────────────────────────────────

def test_combine_and_single_predicate():
    """Combining a single predicate should behave like that predicate."""
    pred = combine_and(status_filter(200))
    assert pred(_entry(status=200)) is True
    assert pred(_entry(status=404)) is False


def test_combine_and_two_predicates():
    """Two predicates combined with AND should both need to match."""
    pred = combine_and(status_filter(200), url_regex_filter(r"^/api"))
    assert pred(_entry(status=200, url="/api/users")) is True
    assert pred(_entry(status=404, url="/api/users")) is False
    assert pred(_entry(status=200, url="/index.html")) is False


def test_combine_and_three_predicates():
    """Three predicates should all need to match."""
    pred = combine_and(
        status_filter(200),
        ip_allowlist_filter(["10.0.0.1", "10.0.0.2"]),
        url_regex_filter(r"^/api"),
    )
    assert pred(_entry(status=200, ip="10.0.0.1", url="/api/users")) is True
    assert pred(_entry(status=404, ip="10.0.0.1", url="/api/users")) is False
    assert pred(_entry(status=200, ip="10.0.0.3", url="/api/users")) is False
    assert pred(_entry(status=200, ip="10.0.0.1", url="/index.html")) is False


def test_combine_and_no_predicates():
    """Combining zero predicates should return True for all entries."""
    pred = combine_and()
    assert pred(_entry()) is True
    assert pred(_entry(status=500)) is True


def test_combine_and_short_circuits():
    """combine_and should short-circuit on first False predicate."""
    call_count = [0]

    def counting_pred(entry):
        call_count[0] += 1
        return False

    def second_pred(entry):
        call_count[0] += 1
        return True

    pred = combine_and(counting_pred, second_pred)
    pred(_entry())
    # Only the first predicate should have been called
    assert call_count[0] == 1


# ── Edge cases for existing filters ─────────────────────────────────────────

def test_status_filter_zero_status():
    """Status filter should work with status code 0 (edge case)."""
    pred = status_filter(0)
    assert pred(_entry(status=0)) is True
    assert pred(_entry(status=200)) is False


def test_status_filter_large_status():
    """Status filter should work with unusual status codes."""
    pred = status_filter(999)
    assert pred(_entry(status=999)) is True
    assert pred(_entry(status=200)) is False


def test_ip_allowlist_empty():
    """Empty allowlist should match nothing."""
    pred = ip_allowlist_filter([])
    assert pred(_entry(ip="10.0.0.1")) is False


def test_ip_allowlist_with_set():
    """Allowlist should work with sets (any iterable)."""
    pred = ip_allowlist_filter({"10.0.0.1", "10.0.0.2"})
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="10.0.0.3")) is False


def test_url_regex_special_characters():
    """URL regex should handle special regex characters in patterns."""
    # Unescaped dot matches any character in regex
    pred = url_regex_filter(r"^/api.json$")
    assert pred(_entry(url="/api.json")) is True
    assert pred(_entry(url="/apiXjson")) is True  # . matches any char
    # Escaped dot matches only literal dot
    pred_escaped = url_regex_filter(r"^/api\.json$")
    assert pred_escaped(_entry(url="/api.json")) is True
    assert pred_escaped(_entry(url="/apiXjson")) is False


def test_url_regex_case_sensitive():
    """URL regex should be case-sensitive by default."""
    pred = url_regex_filter(r"^/API")
    assert pred(_entry(url="/API/users")) is True
    assert pred(_entry(url="/api/users")) is False


def test_date_range_until_excludes_after():
    """date_range_filter should exclude entries after the until boundary."""
    from logalyzer.filters import date_range_filter
    from datetime import datetime, timezone
    until = datetime(2026, 1, 2, tzinfo=timezone.utc)
    pred = date_range_filter(None, until)
    assert pred(_entry(timestamp=datetime(2026, 1, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2026, 1, 3, tzinfo=timezone.utc))) is False
