# Research Notes

## 2025-01-01: Initial Analysis

### Baseline Coverage
- Total: 34% (14 passed, 3 failed)
- experimental.py: 0%
- output.py: 0%
- utils.py: 0%
- io.py: 0%
- cli.py: 0%
- filters.py: 74%
- parser.py: 86%
- aggregate.py: 100%

### Known Bugs (pre-existing test failures)
1. `MONTH_NAMES` in parser.py is missing "Jul" — causes ValueError for July timestamps
2. `status_filter` does direct `==` comparison — fails when CLI passes string "404" vs int 404
3. `url_regex_filter` uses `re.match` (anchored at start) — doesn't match "admin" in "/admin/login"

### Python 3.11 Compatibility Issue
`from collections import Iterable` in filters.py is removed in 3.11.
Workaround: monkey-patch in conftest.py.
