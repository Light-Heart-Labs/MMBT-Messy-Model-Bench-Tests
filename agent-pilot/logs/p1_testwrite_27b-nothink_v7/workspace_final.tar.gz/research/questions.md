# Questions

1. Should we test `expression_filter` with dangerous expressions? The eval has `__builtins__` set to `{}`, which is a security measure. We should test that it works for valid expressions and that it rejects attempts to access builtins.

2. The `format_legacy` function is marked as legacy — should we test it? Yes, per the task requirements, we test dead code to increase coverage.

3. The `chunked` function in utils.py — what happens with size=0? Need to check behavior.

4. `by_hour` in aggregate.py uses `time.localtime()` which depends on the system timezone. The existing test passes because it uses UTC timestamps and the system is likely UTC. We should verify this doesn't cause flakiness.
