# Dead Ends

## Pre-existing Test Failures (Not Fixed)

### test_status_filter_works_with_cli_string_input
The `status_filter` function does `entry.status == status` where `entry.status` is always `int`. When the CLI passes `"404"` (string), the comparison fails. This is a bug in the source code. We cannot fix it.

### test_url_regex_finds_substring_match
The `url_regex_filter` uses `rx.match(entry.url)` which anchors at the start of the string. Pattern `"admin"` won't match `"/admin/login"` because it starts with `/`. This is a bug — should use `rx.search()`. We cannot fix it.

### test_timestamp_july_parses_correctly
The `MONTH_NAMES` list in parser.py is missing "Jul" (July). The list has: Jan, Feb, Mar, Apr, May, Jun, Aug, Sep, Oct, Nov, Dec. July is skipped. This causes `ValueError: 'Jul' is not in list`. We cannot fix it.

## Tests Written and Removed

### None yet
(Will be updated if any tests prove unstable or don't actually exercise code.)
