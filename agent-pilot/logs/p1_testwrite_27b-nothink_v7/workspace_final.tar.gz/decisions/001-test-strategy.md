# ADR-001: Test Strategy for logalyzer Coverage Improvement

## Context

The logalyzer codebase has 34% test coverage. Key uncovered areas:
- `experimental.py` — 0% coverage (anomaly detection, session windowing)
- `output.py` — 0% coverage (JSON, CSV, text formatters, render_aggregate)
- `utils.py` — 0% coverage (parse_iso_date, format_bytes, format_legacy, chunked)
- `io.py` — 0% coverage (file loading)
- `cli.py` — 0% coverage (CLI entry point)
- `filters.py` — 74% coverage (expression_filter, combine_and not tested)
- `parser.py` — 86% coverage (parse_lines generator not tested)

## Decision

Target modules in priority order:
1. **experimental.py** — Full coverage. Two functions with clear logic.
2. **output.py** — Full coverage. Multiple formatters with edge cases.
3. **utils.py** — Full coverage. Edge cases for format_bytes (zero, negative, very large), chunked (empty, exact multiple), format_legacy.
4. **io.py** — Coverage via temp files. Test empty files, malformed lines, files without trailing newline.
5. **filters.py** — Test expression_filter, combine_and, edge cases.
6. **parser.py** — Test parse_lines generator, edge cases for parse_timestamp.
7. **cli.py** — Test main() with various argument combinations.

## Rationale

- experimental.py and output.py are the biggest coverage gaps (0%)
- utils.py has small functions with many edge cases (negative bytes, empty sequences)
- io.py exercises the full pipeline (file I/O + parsing)
- filters.py has untested expression_filter (eval-based) and combine_and

## Not Testing

- We do NOT fix the 3 pre-existing test failures:
  1. `test_status_filter_works_with_cli_string_input` — bug: status_filter compares int vs string
  2. `test_url_regex_finds_substring_match` — bug: uses re.match (anchored) instead of re.search
  3. `test_timestamp_july_parses_correctly` — bug: MONTH_NAMES list missing "Jul"
- We do NOT modify any source files in `/logalyzer/`
