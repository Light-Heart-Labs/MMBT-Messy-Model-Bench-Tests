# ADR-003: Handling Pre-existing Test Failures

## Context

Three tests in the original codebase fail due to bugs in the source code:

1. **`test_status_filter_works_with_cli_string_input`** — The `status_filter` function compares `entry.status == status` using `==`. When the CLI passes `"404"` (string) and `entry.status` is `404` (int), the comparison fails because `"404" != 404`.

2. **`test_url_regex_finds_substring_match`** — The `url_regex_filter` function uses `rx.match(entry.url)` which anchors at the start of the string. Pattern `"admin"` won't match `"/admin/login"` because the URL starts with `/`.

3. **`test_timestamp_july_parses_correctly`** — The `MONTH_NAMES` list in `parser.py` is: `["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Aug", "Sep", "Oct", "Nov", "Dec"]`. "Jul" (July) is missing, causing `ValueError: 'Jul' is not in list`.

## Decision

We do NOT fix these bugs. We do NOT modify the failing tests. We document them in `research/dead-ends.md` and ensure our new tests pass against the current (buggy) behavior.

## Rationale

1. **Task constraint:** "No production code changes."
2. **Task constraint:** "If you find a bug, document it but don't fix it."
3. **Baseline preservation:** All originally-passing tests must still pass. The 3 failures existed before our changes.

## Our Approach

- Our new tests avoid the buggy code paths (e.g., we test `url_regex_filter` with anchored patterns like `^/admin` which work correctly).
- We document the bugs in `research/dead-ends.md` and `CHANGELOG.md`.
- We verify that the same 3 tests fail after our changes (no regressions).
