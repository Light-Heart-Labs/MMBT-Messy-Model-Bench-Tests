# ADR-002: Testing experimental.py — Dead Code Coverage

## Context

`experimental.py` is marked as "experimental" and "Not yet wired into the CLI." It contains two functions:
- `detect_anomalies()` — z-score-based anomaly detection on per-minute request counts
- `session_window()` — session grouping by IP with configurable inactivity timeout

## Decision

We test both functions to 100% coverage.

## Rationale

1. **Coverage goal:** The task requires increasing coverage. `experimental.py` was at 0%.
2. **Well-defined logic:** Both functions have clear, deterministic behavior that is testable.
3. **No side effects:** Neither function has I/O, network calls, or global state.
4. **Edge cases are valuable:** Testing empty input, single entries, boundary conditions, and uniform distributions exercises code paths that would otherwise never run.

## Recommendation (Out of Scope)

The code should be kept for now since it's part of an "in-progress feature." However:
- `detect_anomalies` uses population standard deviation (divides by N, not N-1), which is fine for this use case but worth noting.
- `session_window` sorts entries per-IP, which is O(n log n) per IP. For very large datasets, a streaming approach might be better.
- Neither function is exported from `__init__.py`, so they're not part of the public API.

## Not Testing

- We do not test integration with the CLI (it's not wired in).
- We do not test performance characteristics (that's the domain of `benchmarks/bench.py`).
