# CHANGELOG

## v0.3.2-test-coverage (2025-01-01)

### Coverage Delta
- **Before:** 34% (190/287 statements missed)
- **After:** 99% (2/287 statements missed)
- **Delta:** +65 percentage points

### Per-Module Coverage

| Module | Before | After |
|--------|--------|-------|
| `__init__.py` | 100% | 100% |
| `aggregate.py` | 100% | 100% |
| `cli.py` | 0% | 97% |
| `experimental.py` | 0% | 100% |
| `filters.py` | 74% | 100% |
| `io.py` | 0% | 100% |
| `output.py` | 0% | 100% |
| `parser.py` | 86% | 100% |
| `utils.py` | 0% | 100% |

### Test Files Added

| File | Tests | Coverage Target |
|------|-------|-----------------|
| `tests/test_experimental.py` | 16 | `experimental.py` (detect_anomalies, session_window) |
| `tests/test_output.py` | 24 | `output.py` (to_json, to_csv, to_text, render_aggregate) |
| `tests/test_utils.py` | 30 | `utils.py` (parse_iso_date, format_bytes, format_legacy, chunked) |
| `tests/test_io.py` | 15 | `io.py` (load, load_iter) |
| `tests/test_filters_extended.py` | 20 | `filters.py` (expression_filter, combine_and, edge cases, date_range until) |
| `tests/test_parser_extended.py` | 24 | `parser.py` (parse_lines, edge cases, invalid timestamp branch) |
| `tests/test_cli.py` | 23 | `cli.py` (build_parser, main, all filter combinations) |

**Total new tests:** 152

### Uncovered Lines (2 remaining)

Both are in `cli.py` and cannot be tested without modifying source code:
1. **Line 43** (`preds.append(status_filter(args.status))`) — The `status_filter` function has a known bug where it compares `int` status codes with `str` CLI args. Passing `--status "200"` filters out ALL entries (including those with status 200), making it impossible to exercise this branch while also verifying output.
2. **Line 84** (`sys.exit(main())`) — The `if __name__ == "__main__"` block. Cannot be tested without modifying `sys.argv` or the source code.

### Pre-existing Test Failures (Unchanged)

Three tests in the original codebase fail due to bugs in the source code. These are documented but NOT fixed:

1. `test_status_filter_works_with_cli_string_input` — `status_filter` does `entry.status == status` where status is int but CLI passes string
2. `test_url_regex_finds_substring_match` — `url_regex_filter` uses `re.match` (anchored) instead of `re.search`
3. `test_timestamp_july_parses_correctly` — `MONTH_NAMES` list in `parser.py` is missing "Jul"

### Test Results

- **Before:** 14 passed, 3 failed
- **After:** 166 passed, 3 failed (same 3 pre-existing failures)
- **Zero regressions** — all originally-passing tests still pass

### Compatibility Note

A monkey-patch was added to `tests/conftest.py` to provide `collections.Iterable` compatibility for Python 3.11 (the import was removed from `collections` in 3.3 and fully removed in 3.11). This does not modify any source code.
