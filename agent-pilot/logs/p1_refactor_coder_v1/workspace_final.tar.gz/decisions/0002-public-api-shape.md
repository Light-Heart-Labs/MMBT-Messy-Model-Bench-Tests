# Decision 0002: Public API Shape

## Context

The `logalyzer.output` module needs to be refactored into a package with multiple modules. The refactoring must preserve the existing public API so that existing code (specifically `cli.py`) continues to work without modification.

## Current Public API

The current `logalyzer.output` module exports the following functions:
- `to_json(entries: Iterable[LogEntry]) -> str`
- `to_csv(entries: Iterable[LogEntry]) -> str`
- `to_text(entries: Iterable[LogEntry]) -> str`
- `render_aggregate(agg: Any, fmt: str = "text") -> str`

Additionally, the verification step requires that `format_legacy` be importable from `logalyzer.output`, even though it's currently in `logalyzer.utils`.

## New Package Structure

The new `logalyzer/output/` package will have the following modules:

1. **`__init__.py`**: Re-exports the public API
2. **`json_renderer.py`**: Contains `to_json()`
3. **`csv_renderer.py`**: Contains `to_csv()`
4. **`plain_renderer.py`**: Contains `to_text()`
5. **`legacy.py`**: Contains `format_legacy()` and any backward-compatibility shims

## Public API Re-exports

The `__init__.py` will re-export:
- `to_json` from `json_renderer`
- `to_csv` from `csv_renderer`
- `to_text` from `plain_renderer`
- `render_aggregate` from `plain_renderer` (or a new module)
- `format_legacy` from `legacy` (moved from `utils.py`)

## Rationale

This structure:
- Separates concerns: each renderer is in its own module
- Maintains backward compatibility: the public API is unchanged
- Allows future expansion: new renderers can be added without affecting existing code
- Keeps legacy code isolated: `format_legacy()` is in a dedicated module

## Alternatives Considered

1. **Keep all renderers in one module**: This would defeat the purpose of the refactor.
2. **Put render_aggregate in a separate module**: This would require changing cli.py imports, which is not allowed.
3. **Keep format_legacy in utils.py**: This would require changing the import in __init__.py to `from ..utils import format_legacy`, which is less clean and doesn't match the spec.

## Conclusion

The new package structure as described above will be implemented.
