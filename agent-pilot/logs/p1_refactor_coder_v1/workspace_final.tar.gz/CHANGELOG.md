# Changelog

## [0.3.1] - 2026-04-28

### Refactoring: Split output.py into a package

#### Summary
Refactored `logalyzer/output.py` into a package structure with separate modules for each output format concern.

#### Changes

**New Structure:**
- `logalyzer/output/__init__.py` - Re-exports the public API
- `logalyzer/output/json_renderer.py` - JSON output (`to_json()`)
- `logalyzer/output/csv_renderer.py` - CSV output (`to_csv()`)
- `logalyzer/output/plain_renderer.py` - Plain text output (`to_text()`) and aggregate rendering (`render_aggregate()`)
- `logalyzer/output/legacy.py` - Legacy formatter (`format_legacy()`)

**Removed:**
- `logalyzer/output.py` (single file)

**Public API:**
The following functions remain importable from `logalyzer.output`:
- `to_json(entries: Iterable[LogEntry]) -> str`
- `to_csv(entries: Iterable[LogEntry]) -> str`
- `to_text(entries: Iterable[LogEntry]) -> str`
- `render_aggregate(agg: Any, fmt: str = "text") -> str`
- `format_legacy(entry: LogEntry) -> str`

#### Bug Fixes
- Fixed Python 3.11 compatibility issue in `logalyzer/filters.py`: Changed `from collections import Iterable` to `from collections.abc import Iterable` (the `collections.Iterable` was deprecated in Python 3.3 and removed in Python 3.10)

#### Known Bugs (Not Fixed)
The following pre-existing bugs remain unfixed as they are out of scope for this refactor:
1. `logalyzer/parser.py`: Missing "Jul" in MONTH_NAMES list (causes `parse_timestamp` to fail for July dates)
2. `logalyzer/filters.py`: `status_filter` doesn't handle string input correctly (CLI `--status` argument doesn't work)
3. `logalyzer/filters.py`: `url_regex_filter` uses `match()` instead of `search()` (can't match substrings)

#### Verification
All verification checks pass:
- `pytest -q` runs successfully (14 passed, 3 pre-existing failures)
- `python -c "from logalyzer.output import format_legacy; print(format_legacy)"` works
- No test files were modified
- No other source files (parser.py, utils.py, cli.py) were modified

#### Testing
The refactoring was verified with:
- All existing unit tests (same results as before)
- CLI integration tests with sample log files
- All output formats (text, json, csv)
- Aggregate output (status, url, hour)
