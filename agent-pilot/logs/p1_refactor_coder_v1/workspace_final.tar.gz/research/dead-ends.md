# Dead Ends and Known Bugs

## Python 3.11 Compatibility Issue

**Issue**: The `filters.py` file imports `Iterable` from `collections` instead of `collections.abc`.

**Status**: Fixed (necessary to run tests with Python 3.11)

**Resolution**: Changed `from collections import Iterable` to `from collections.abc import Iterable`

## Bug: Missing July in MONTH_NAMES

**File**: `logalyzer/parser.py`

**Issue**: The `MONTH_NAMES` list is missing "Jul", causing `parse_timestamp` to fail when parsing July dates.

**Evidence**: `test_timestamp_july_parses_correctly` fails with `ValueError: 'Jul' is not in list`

**Impact**: Timestamps in July cannot be parsed correctly.

**Decision**: Not fixing - out of scope for this refactor. This is a pre-existing bug.

## Bug: Status Filter Doesn't Handle String Input

**File**: `logalyzer/filters.py`

**Issue**: The `status_filter` function compares `entry.status` (an int) directly with the `status` parameter. When the CLI passes `--status` as a string (e.g., "404"), the comparison fails because `404 != "404"`.

**Evidence**: `test_status_filter_works_with_cli_string_input` fails.

**Impact**: The CLI `--status` argument doesn't work correctly.

**Decision**: Not fixing - out of scope for this refactor. This is a pre-existing bug.

## Bug: URL Regex Filter Uses `match` Instead of `search`

**File**: `logalyzer/filters.py`

**Issue**: The `url_regex_filter` function uses `rx.match()` which only matches at the beginning of the string. The test expects it to find substrings (e.g., "admin" should match "/admin/login").

**Evidence**: `test_url_regex_finds_substring_match` fails.

**Impact**: URL regex filters can't match URLs that don't start with the pattern.

**Decision**: Not fixing - out of scope for this refactor. This is a pre-existing bug.

## Bug: Missing "Jul" in MONTH_NAMES

**File**: `logalyzer/parser.py`

**Issue**: The `MONTH_NAMES` list is missing "Jul", causing `parse_timestamp` to fail when parsing July dates.

**Evidence**: `test_timestamp_july_parses_correctly` fails with `ValueError: 'Jul' is not in list`

**Impact**: Timestamps in July cannot be parsed correctly.

**Decision**: Not fixing - out of scope for this refactor. This is a pre-existing bug.
