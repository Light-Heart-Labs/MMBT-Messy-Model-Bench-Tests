"""Legacy output formatters for backward compatibility."""
from __future__ import annotations

from ..parser import LogEntry


def format_legacy(entry: LogEntry) -> str:
    """Legacy formatter retained for compatibility with the v0.1 CLI output.

    No longer used internally, kept for any external scripts that may still depend on it.
    """
    return f"{entry.ip} | {entry.timestamp} | {entry.status} | {entry.url}"
