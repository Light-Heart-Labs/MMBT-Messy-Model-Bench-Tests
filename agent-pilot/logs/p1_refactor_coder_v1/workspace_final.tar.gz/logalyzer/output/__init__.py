"""Output formatters package.

This package provides various output formatters for log entries and aggregate results.
"""
from __future__ import annotations

from .csv_renderer import to_csv
from .json_renderer import to_json
from .legacy import format_legacy
from .plain_renderer import render_aggregate, to_text

__all__ = ["to_json", "to_csv", "to_text", "render_aggregate", "format_legacy"]
