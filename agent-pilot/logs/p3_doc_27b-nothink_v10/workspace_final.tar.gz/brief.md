# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment

**Date:** 2026-03-10 | **To:** Investment Committee | **Subject:** PASS

---

## Recommendation: PASS

We recommend passing on a follow-on investment in Nimbus Logistics. The company has a credible engineering team and real product-market fit in mid-market logistics, but customer concentration, negative cash flow, and a strategic pivot away from the growth narrative that justified the Series B create unacceptable risk at the $560M valuation.

This is not a "more diligence needed" call. The existing public record already reveals structural issues that would need to be resolved before a GO. Conditions for reversal are listed below.

---

## The Numbers: What's Real and What's Inflated

Nimbus closed an $84M Series B at $560M post-money on January 14, 2026, led by Lightning Capital with Sequoia, Accel, and FedEx Ventures [Source 1, Source 5]. Total funding: $128M [Source 1].

The company reports $42M ARR as of Q4 2025, up from $11M a year prior [Source 1]. This figure is inflated. Two top-five customers left in late 2025: Sundry Brands ($4.2M ARR, November non-renewal) and Klatch (December departure) [Source 2]. Adjusted for churn, current run-rate ARR is closer to $36-37M [Source 2]. The $42M figure includes both contracts in their final quarter.

The valuation was repriced downward from an original $720M target after the Sundry non-renewal became known to the lead investor in early December [Source 2]. Even sophisticated investors already discounted the story.

---

## The Burn Problem

A former senior engineer reports burn of ~$4M/month against ~$3.5M in monthly revenue (mid-2025), yielding ~$500K/month net burn [Source 3]. The company quietly laid off 22 people (~11% of the org) in February 2025, mostly in customer success and BD — unannounced publicly [Source 3].

A leaked internal memo (February 28, 2026) from CEO Mira Patel outlines further restructuring: 30% reduction in international headcount (Berlin: 41 → 28-30), deferral of international expansion to 2027, and elimination of the "Nimbus Lite" tier, affecting ~310 customers [Source 4]. The memo states the Series B provides 24+ months of runway at current burn, extended to 36+ months with restructuring, targeting cash-flow breakeven by Q4 2026 [Source 4]. A $50M credit facility from Silicon Valley Bridge has been secured, described as "insurance, not operating capital" [Source 4].

---

## Customer Concentration Risk

The top five customers represent ~38% of ARR [Source 3]. Losing two of those five in six months — including the largest contract — is material. The former employee notes the Sundry loss "was not a shock to the team" [Source 3].

CEO Patel told TechCrunch that three new $1M+ ARR contracts were signed in Q1 2026 and that net retention remains above 110% [Source 2]. These claims are unverified and should be treated as the company's stated position, not confirmed fact.

---

## The Strategic Pivot

The press release states the new capital will "accelerate our expansion into international markets" [Source 1]. The leaked memo defers international expansion to 2027 and reframes Berlin as a "support hub" [Source 4]. The Nimbus Lite elimination — 310 small customers — signals contraction, not expansion [Source 4].

---

## What's Working

The engineering architecture is praised as strong, and CTO Daniel Wong is credible [Source 3]. Customer relationships with mid-market brands appear genuine [Source 3]. The company serves 1,400+ e-commerce brands [Source 1], and FedEx Ventures' participation signals some institutional confidence [Source 1].

---

## Conditions That Would Change This to GO

1. **Contract verification**: The three claimed $1M+ Q1 contracts confirmed with signed agreements.
2. **Retention data**: Independent verification of >110% net revenue retention on a cohort basis.
3. **Credit facility terms**: No restrictive covenants that could trigger acceleration.
4. **Unit economics**: Post-Lite-tier sunset, remaining customers show positive contribution margin.
5. **Valuation reset**: A follow-on reflecting the $36-37M adjusted ARR, not the $560M Series B price.

---

## Bottom Line

Nimbus has a real product and capable team, but it is burning cash, losing concentrated customers, and pivoting away from the growth strategy that justified its last round. The $560M valuation was already repriced down by $160M. A follow-on at current terms pays a premium for a story the company is already rewriting.

**Recommendation: PASS.**
