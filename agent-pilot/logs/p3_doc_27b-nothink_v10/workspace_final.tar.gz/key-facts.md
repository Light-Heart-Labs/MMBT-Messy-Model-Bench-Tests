# Key Facts — Nimbus Logistics Executive Brief

Every material fact incorporated into the brief, with source attribution.

## Financials

| Fact | Value | Source |
|------|-------|--------|
| Series B amount | $84M | [Source 1], [Source 5] |
| Post-money valuation | $560M | [Source 1] |
| Previous valuation (Series A, 2023) | $230M | [Source 1] |
| Total funding raised | $128M | [Source 1] |
| Reported ARR (Q4 2025) | $42M | [Source 1] |
| ARR one year prior | $11M | [Source 1] |
| Adjusted ARR (post-churn) | $36-37M | [Source 2] |
| Monthly burn rate (mid-2025) | ~$4M/month | [Source 3] |
| Monthly revenue (mid-2025) | ~$3.5M/month | [Source 3] |
| Net monthly burn | ~$500K/month | Derived from [Source 3] |
| Sundry Brands contract value | $4.2M ARR | [Source 2] |
| Credit facility secured | $50M from Silicon Valley Bridge | [Source 4] |
| Runway at current burn | 24+ months | [Source 4] |
| Runway with restructuring | 36+ months | [Source 4] |

## Customers & Market

| Fact | Value | Source |
|------|-------|--------|
| Total customers | 1,400+ e-commerce brands | [Source 1] |
| Top 5 customer concentration | ~38% of ARR | [Source 3] |
| Customers lost in late 2025 | Sundry Brands (Nov), Klatch (Dec) | [Source 2] |
| Nimbus Lite customers being sunset | ~310 customers ($5K-$20K ARR each) | [Source 4] |
| New contracts signed Q1 2026 | 3 contracts, $1M+ ARR each (claimed) | [Source 2] |
| Net retention rate | Claimed above 110% | [Source 2] |

## Organization

| Fact | Value | Source |
|------|-------|--------|
| Employee count | 187 (as of press release date) | [Source 1] |
| Offices | Oakland, Austin, Berlin | [Source 1] |
| Layoffs (Feb 2025) | 22 people (~11% of org) | [Source 3] |
| Berlin headcount reduction | 41 → 28-30 by end Q2 2026 | [Source 4] |
| International expansion | Deferred to 2027 | [Source 4] |

## Investors & Deal Structure

| Fact | Value | Source |
|------|-------|--------|
| Lead investor | Lightning Capital | [Source 1], [Source 5] |
| Participating investors | Sequoia, Accel, FedEx Ventures, 3 unnamed | [Source 1], [Source 5] |
| Total investors | 7 | [Source 5] |
| Security type | Series B Preferred | [Source 5] |
| Original target valuation | $720M (repriced down) | [Source 2] |
| Use of proceeds | Expansion, working capital, general corporate purposes | [Source 5] |

## Timeline

| Date | Event | Source |
|------|-------|--------|
| 2021 | Company founded | [Source 1] |
| 2023 | Series A at $230M valuation | [Source 1] |
| Feb 2025 | 22-person layoff (unannounced) | [Source 3] |
| Nov 2025 | Sundry Brands non-renewal | [Source 2] |
| Dec 2025 | Klatch departure | [Source 2] |
| Jan 14, 2026 | Series B closed | [Source 1], [Source 5] |
| Feb 28, 2026 | Internal restructuring memo | [Source 4] |
| Q4 2026 | Target for cash-flow breakeven | [Source 4] |
