# Working Notes — Nimbus Logistics Source Analysis

## Source-by-Source Summary

### Source 1: Press Release (2026-01-14)
- $84M Series B, led by Lightning Capital
- Post-money valuation: $560M (up from $230M Series A in 2023)
- Total funding: $128M across all rounds
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400+ e-commerce brands on platform
- 187 employees across Oakland, Austin, Berlin
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (strategic)
- Use of proceeds: international expansion, AI-driven inventory optimization
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO)

### Source 2: TechCrunch (2026-01-15)
- Lost two top-5 customers in late 2025
- Sundry Brands: $4.2M ARR, did not renew in November
- Klatch (fast-fashion): exited in December, migrated to competitor
- Adjusted ARR after churn: $36-37M (vs. $42M in press release)
- Series B was originally targeted at $720M valuation, repriced down to $560M after Sundry news
- CEO claims 3 new $1M+ ARR contracts signed in Q1
- Net retention claimed above 110%

### Source 3: Former Employee Blog (2026-02-22)
- 14 months at company, left ~January 2026
- Engineering quality praised; CTO Daniel Wong is strong
- Burn rate: ~$4M/month (mid-2025), revenue ~$3.5M/month
- Net burn: ~$500K/month
- Layoffs: 22 people (~11% of org) in February 2025, mostly customer success and BD
- Not publicly announced
- Top 5 customers = ~38% of ARR (customer concentration risk)
- Sundry loss was not a shock internally
- Compensation competitive: $215K base + $50K equity vest for senior engineer

### Source 4: Leaked Internal Memo (2026-03-05)
- Dated February 28, 2026, from CEO Mira Patel
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
- International expansion deferred to 2027
- Berlin reframed as "support hub"
- Nimbus Lite tier being sunset (~310 customers, $5K-$20K ARR each)
- 90-day notice for affected customers
- New $50M credit facility from Silicon Valley Bridge
- Runway: 24+ months at current burn, extended to 36+ months with restructuring
- Target: operating-cash-flow breakeven by Q4 2026
- Series C conversations planned from "position of strength"

### Source 5: SEC Form D (2026-01-22)
- Confirms $84M total offering, all sold
- 7 investors total
- Securities: Series B Preferred
- Use of proceeds: "expansion, working capital, general corporate purposes"
- No executive compensation disclosed in connection with offering

## Key Tensions Identified

1. **ARR inflation**: $42M (press release) vs. $36-37M adjusted (TechCrunch sources)
2. **Valuation repricing**: $720M target → $560M actual (down ~22%)
3. **Customer concentration**: Top 5 = 38% of ARR; lost 2 of top 5 in 6 months
4. **Burn vs. revenue**: $4M/month burn vs. $3.5M/month revenue = net negative
5. **International strategy pivot**: Press release says "accelerate international expansion"; memo says "defer to 2027"
6. **Layoffs hidden**: 22 people cut in Feb 2025, not publicly announced
7. **Product tier elimination**: Nimbus Lite sunset contradicts growth narrative
8. **Credit facility**: $50M from Silicon Valley Bridge — "insurance, not operating capital"

## Recommendation Reasoning

**Stance: PASS on follow-on at current terms. More diligence needed.**

Rationale:
- The company is burning cash ($500K/month net) and the path to profitability requires significant restructuring
- Customer concentration is a real risk (38% from top 5, lost 2 of 5)
- The international expansion narrative (press release) is already being reversed (memo)
- The valuation repricing from $720M to $560M suggests sophisticated investors already discounted the story
- However, the engineering is solid, the CTO is strong, and the $50M credit facility provides runway
- The 36-month runway with restructuring gives time to prove the model

**Conditions that would change this to GO:**
- Evidence that the 3 new $1M+ contracts are real and signed
- Confirmation that net retention is genuinely above 110%
- Clarity on whether the $50M credit facility has covenants that could trigger
- Understanding of the unit economics post-Lite-tier sunset
