# Dead Ends — Ideas Considered and Abandoned

## Considered but Rejected

1. **Recommendation: GO with price protection**
   - Initially considered recommending a follow-on with strict valuation floors and liquidation preferences.
   - Rejected because the fundamental business metrics (burn, churn, concentration) are unresolved and a price floor doesn't fix the underlying unit-economics problem.

2. **Recommendation: GO because of FedEx strategic**
   - FedEx Ventures' participation could signal distribution upside.
   - Rejected because the strategic investment is already in the Series B round — it's not a new signal for a follow-on. Also, FedEx Ventures often makes small strategic bets that don't imply deep partnership.

3. **Including specific churn rate calculations**
   - Attempted to calculate gross churn from the Sundry ($4.2M) and Klatch losses.
   - Rejected because we don't know Klatch's ARR value, so any churn rate would be speculative.

4. **Commenting on the CTO's credibility as a positive**
   - The former employee blog praises Daniel Wong.
   - Rejected as a standalone point because engineering quality, while important, doesn't offset the commercial risks. Mentioned briefly in context only.

5. **Speculating on the three unnamed Form D investors**
   - The Form D lists 7 investors but only names 4.
   - Rejected because we have no information about the other three and speculation would violate the "no invented facts" rule.

6. **Treating the leaked memo as ground truth**
   - Initially drafted language treating the memo's claims as facts.
   - Corrected to use "according to the leaked memo" and "the memo states" to maintain appropriate epistemic distance.
