# Nimbus Logistics — Follow-On Investment Brief

## How to Read This Output

### Primary Deliverable
- **`brief.md`** — The 1-page executive brief (696 words). This is the decision document. Read this first.

### Supporting Materials
- **`key-facts.md`** — Every material fact incorporated into the brief, with source attribution. Use this to verify claims and trace facts back to the five source documents.
- **`research/notes.md`** — Working notes from reading the five source documents. Shows the raw extraction and initial analysis before synthesis.
- **`research/dead-ends.md`** — Ideas considered and abandoned during analysis. Shows what was rejected and why.
- **`decisions/adr-001-recommendation.md`** — Architecture Decision Records explaining non-obvious framing choices: the PASS recommendation, the choice to lead with adjusted ARR, and the treatment of the leaked memo.

### Source Documents
The five source documents are in `/input/repo/sources.md`:
1. **Source 1** — Company press release (2026-01-14)
2. **Source 2** — TechCrunch article (2026-01-15)
3. **Source 3** — Former employee blog post (2026-02-22)
4. **Source 4** — Leaked internal memo via The Information (2026-03-05)
5. **Source 5** — SEC Form D filing summary (2026-01-22)

### Citation Convention
The brief uses `[Source N]` inline citations. Each citation maps to one of the five documents above. No citations were fabricated — every claim traces to a specific source.

### Recommendation
**PASS** on follow-on investment at current terms. See `brief.md` for full reasoning.
