# ADR-001: Recommendation Stance — PASS with Conditions

## Context
The brief requires a clear stance: GO, PASS, or MORE DILIGENCE NEEDED.

## Decision
**PASS on follow-on investment at current terms.** Not "more diligence needed" — the existing sources already reveal material red flags that would need to be resolved before a GO.

## Rationale
- "More diligence needed" is a hedge that doesn't help the partner. The sources already show: negative cash flow, customer concentration, valuation repricing, and a strategic pivot away from the stated growth plan. These are not things that can be fixed with a diligence call — they are structural issues.
- A PASS stance is honest about the risk profile while leaving the door open for a future GO if specific conditions are met.
- The conditions for reversal are explicit and testable (contract verification, retention data, credit facility terms).

## Alternatives Considered
- **GO with protective terms**: Rejected because protective terms don't fix unit economics.
- **MORE DILIGENCE NEEDED**: Rejected because the existing information is sufficient to form a negative view; asking for more data is a way of saying "I don't want to say no."

---

# ADR-002: ARR Figure to Lead With

## Context
The company claims $42M ARR (press release). TechCrunch sources say adjusted ARR is $36-37M after accounting for December churn.

## Decision
Lead with the $36-37M adjusted figure, noting the $42M claim and why it's inflated.

## Rationale
- The $42M figure includes two customers who had already left or were leaving. It's not a bad-faith lie but it is a misleading snapshot.
- An investor brief should present the most accurate picture available, not the company's preferred narrative.
- The TechCrunch sources are unnamed but the math is straightforward: $42M minus Sundry ($4.2M) minus Klatch (unknown but material) = $36-37M.

## Alternatives Considered
- **Use $42M and note the adjustment**: This gives the company's number primacy, which is inappropriate for an investor brief.
- **Average the two**: No principled basis for averaging.

---

# ADR-003: Treatment of the Leaked Memo

## Context
The leaked memo (Source 4) contains significant strategic information but is not a public company statement.

## Decision
Cite the memo as a source of information but use qualifying language ("according to the leaked memo," "the memo states"). Do not treat it as confirmed fact.

## Rationale
- The memo is attributed to CEO Mira Patel and was obtained by The Information, a credible outlet.
- However, it is internal and leaked — the company has not confirmed its contents.
- The memo's claims about restructuring are consistent with other signals (layoffs, international pivot), which increases confidence in its accuracy.

## Alternatives Considered
- **Ignore the memo**: Would leave a significant gap in the analysis.
- **Treat as confirmed fact**: Would overstate certainty.
