# Outage Brief — Friday, 14:11–18:24 UTC

**Summary:** A configuration change to our authentication service caused our primary API to return errors for approximately 4 hours, impacting 11,400 customer accounts.

**Impact:** 28 enterprise accounts experienced revenue loss during business hours. Four customers had downstream automation failures requiring manual remediation. We received 217 support tickets and 31 refund requests.

**Root Cause:** A configuration update intended to increase request limits inadvertently triggered an internal safeguard that blocked all authentication requests. The status page remained green for the first 40 minutes because it monitored the wrong service path.

**Board Signal:** This is the second outage exceeding 4 hours in 2026. The first occurred in February. A third would necessitate a full reliability program review.

**Remediations Underway:**
1. Staged, per-region rollout for configuration changes (1 sprint).
2. Fix to decouple the internal safeguard from a hard-coded limit (2 weeks).
3. Status-page monitoring corrected to reflect actual customer-facing service paths (already deployed).
4. New policy: proactive customer communication within 15 minutes of confirmed impact.

**Financial Exposure:** SLA credits are owed to affected accounts per our 99.9% monthly uptime commitment. Legal and finance are processing 31 refund requests case by case.
