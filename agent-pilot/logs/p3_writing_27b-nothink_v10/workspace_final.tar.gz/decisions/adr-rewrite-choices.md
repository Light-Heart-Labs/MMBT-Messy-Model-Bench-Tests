# Architecture Decision Records — Rewrite Choices

## ADR-01: CEO Brief — Omission of Technical Root Cause Detail

**Status:** Accepted

**Context:** The source memo contains detailed technical explanation of the root cause (rate-limit thresholds, internal limiter fraction, hard-coded MAX value). The CEO brief spec explicitly excludes "engineering-jargon without translation" and "detailed fraction-against-MAX explanations."

**Decision:** Replace technical root cause with a plain-language summary: "A configuration update intended to increase request limits inadvertently triggered an internal safeguard that blocked all authentication requests." This preserves the causal chain (config change → safeguard triggered → auth blocked) without introducing jargon.

**Consequences:** The CEO loses the technical depth but gains a clear, actionable understanding of what went wrong and what is being fixed.

---

## ADR-02: Customer Email — Omission of Named Engineer

**Status:** Accepted

**Context:** The source memo names Marcus as the person who deployed the config change. The customer email spec explicitly prohibits "blame on a named individual."

**Decision:** Remove all references to Marcus. Attribute the cause to "a configuration change we deployed" using first-person plural to convey collective accountability without singling out an individual.

**Consequences:** Customers receive a message that takes responsibility without creating a blame narrative.

---

## ADR-03: Customer Email — Omission of "Second Outage in 90 Days" Framing

**Status:** Accepted

**Context:** The source memo flags this as the second 4+ hour outage in 2026, with a board-level signal. The customer email spec explicitly prohibits "the 'second outage in 90 days' framing."

**Decision:** Omit any reference to prior outages or frequency patterns. The customer email focuses solely on this incident and the remediation commitments.

**Consequences:** Customers are not exposed to internal risk assessments or board-level concerns.

---

## ADR-04: Legal Summary — Use of "Incident" Over "Outage"

**Status:** Accepted

**Context:** The legal summary spec requires using "incident" not "outage."

**Decision:** All instances of "outage" are replaced with "incident" throughout the legal summary. The title reads "Incident Summary — SLA Credit Review."

**Consequences:** Terminology aligns with the spec's requirement for dispassionate, precise language.

---

## ADR-05: Legal Summary — Omission of Engineering Remediation Details

**Status:** Accepted

**Context:** The source memo describes five remediations (staged config rollout, internal limiter fix, status-page fix, comms policy, runbook update). The legal summary spec excludes "engineering remediation details (irrelevant to counsel)."

**Decision:** Omit all remediation details from the legal summary. The legal summary focuses exclusively on facts relevant to SLA-credit determinations: timeline, scope, SLA threshold, downstream harm, and credit-request handling.

**Consequences:** Counsel receives a clean, focused document for credit-processing decisions without extraneous technical content.

---

## ADR-06: CEO Brief — Inclusion of "Second Occurrence in 90 Days" Framing

**Status:** Accepted

**Context:** The CEO brief spec requires "second-occurrence-in-90-days framing (board signal)." The source memo states this is the second 4+ hour outage in 2026, with the first in February.

**Decision:** Include the framing as "This is the second outage exceeding 4 hours in 2026. The first occurred in February. A third would necessitate a full reliability program review." This preserves the board signal without the exact "90 days" phrasing, since the source memo says "second data point in 90 days" but the February-to-Friday gap is approximately 3.5 months.

**Consequences:** The CEO receives the board-level signal as required, with accurate framing from the source.

---

## ADR-07: All Rewrites — No Invented Facts

**Status:** Accepted

**Context:** The rules state "Every number, time, and customer count in your rewrites must be present in the source memo."

**Decision:** All numerical values (11,400 accounts, 28 enterprise accounts, 4 downstream cases, 217 tickets, 31 refund requests, 14:11–18:24 UTC, 99.9% SLA) are taken directly from the source memo. No interpolation or estimation was performed.

**Consequences:** Full faithfulness to source material is maintained across all three rewrites.
