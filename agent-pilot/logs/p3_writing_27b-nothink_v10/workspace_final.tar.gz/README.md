# Incident Rewrite Output

This directory contains three audience-tailored rewrites of an internal engineering memo documenting a 4-hour API outage on Friday (14:11–18:24 UTC). Each rewrite is constrained by the specifications in `/input/repo/audience_briefs.json` and draws exclusively from the source memo at `/input/repo/draft_memo.md` — no facts were invented.

## Files

| File | Audience | Max Words | Actual Words |
|------|----------|-----------|-------------|
| `ceo_brief.md` | CEO / Board prep | 250 | 195 |
| `customer_email.md` | Affected customers (mass email) | 350 | 260 |
| `legal_summary.md` | In-house counsel (SLA review) | 400 | 253 |
| `decisions/adr-rewrite-choices.md` | ADR-style records of non-obvious editorial choices | — | — |
| `research/notes.md` | Working notes with extracted facts and per-audience decisions | — | — |

## How to Read

- **ceo_brief.md** is a concise, executive-level summary for the CEO's board preparation. It includes the outage summary, impact scope, the second-occurrence board signal, and key remediations. It omits engineering jargon, named individuals, and internal apologies per spec.
- **customer_email.md** is a warm, accountable mass email to affected customers. It explains the incident in plain language, outlines commitments, offers SLA credits explicitly, and provides a contact path. It omits named engineers, the "second outage in 90 days" framing, and engineering jargon per spec.
- **legal_summary.md** is a precise, dispassionate factual record for in-house counsel reviewing SLA-credit obligations. It uses "incident" not "outage," enumerates the time window, account counts, SLA threshold, downstream harm cases, and credit-request handling recommendations. It omits speculation, named-employee blame, marketing language, and engineering remediation details per spec.
