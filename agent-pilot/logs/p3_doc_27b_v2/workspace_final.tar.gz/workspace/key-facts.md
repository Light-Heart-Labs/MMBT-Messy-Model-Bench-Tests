# Key Facts Incorporated in Brief

Each fact below traces to one or more of the five sources. Source numbers correspond to the source pack.

## Financials & Valuation

| Fact | Source(s) |
|------|-----------|
| $84M Series B closed 2026-01-14 | [Source 1], [Source 5] |
| Post-money valuation: $560M | [Source 1] |
| Previous valuation: $230M (Series A, 2023) | [Source 1] |
| Total funding raised: $128M | [Source 1] |
| ARR reported: $42M as of Q4 2025 | [Source 1] |
| ARR prior year: $11M | [Source 1] |
| ARR adjusted for churn: $36-37M | [Source 2] |
| ARR figure includes churned contracts in final quarter | [Source 2] |
| Series B originally targeted $720M valuation, repriced down | [Source 2] |
| Burn rate: ~$4M/month (mid-2025) | [Source 3] |
| Revenue: ~$3.5M/month (mid-2025) | [Source 3] |
| Net burn: ~$500K/month | [Source 3] (derived) |
| $50M credit facility from Silicon Valley Bridge | [Source 4] |
| Runway: 24+ months at current burn, 36+ months post-restructuring | [Source 4] |
| 7 investors in Series B | [Source 5] |

## Customers & Product

| Fact | Source(s) |
|------|-----------|
| 1,400+ e-commerce brands on platform | [Source 1] |
| Named customers: Maevia, Truant Coffee, Brick & Cobble | [Source 1] |
| Lost Sundry Brands: $4.2M ARR, largest contract, November 2025 | [Source 2] |
| Lost Klatch: fast-fashion brand, December 2025, migrated to competitor | [Source 2] |
| Top 5 customers = ~38% of ARR | [Source 3] |
| 3 new $1M+ ARR contracts signed in Q1 2026 | [Source 2] |
| Net retention claimed above 110% | [Source 2] |
| Nimbus Lite tier sunset: ~310 customers, $5K-$20K ARR each | [Source 4] |

## Organization & Governance

| Fact | Source(s) |
|------|-----------|
| 187 employees (Oakland, Austin, Berlin) | [Source 1] |
| Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) | [Source 1] |
| 22 employees laid off (~11% of org) in Feb 2025, not publicly announced | [Source 3] |
| Berlin headcount: 41, planned reduction to 28-30 by end Q2 2026 | [Source 4] |
| International expansion deferred to 2027 | [Source 4] |
| Restructuring targets cash-flow breakeven by Q4 2026 | [Source 4] |
| Compensation: senior engineers at $215K base + $50K equity/yr | [Source 3] |

## Investors

| Fact | Source(s) |
|------|-----------|
| Lightning Capital: lead investor | [Source 1], [Source 5] |
| Sequoia Capital: pro-rata participation | [Source 1], [Source 5] |
| Accel: pro-rata participation | [Source 1], [Source 5] |
| FedEx Ventures: strategic investment | [Source 1], [Source 5] |
| 3 additional investors (unnamed) | [Source 5] |
