# Working Notes — Nimbus Logistics Source Analysis

## Source-by-Source Summary

### Source 1: Press Release (2026-01-14)
- $84M Series B led by Lightning Capital
- Post-money valuation: $560M (up from $230M Series A in 2023)
- Total funding: $128M across all rounds
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400+ e-commerce brands on platform
- 187 employees across Oakland, Austin, Berlin
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (strategic)
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO)
- Platform: warehouse management + carrier orchestration + demand forecasting
- Named customers: Maevia, Truant Coffee, Brick & Cobble

### Source 2: TechCrunch (2026-01-15)
- Lost two top-five customers in late 2025:
  - Sundry Brands: $4.2M ARR, largest contract, non-renewal in November
  - Klatch: fast-fashion brand, exited December, migrated to competitor
- ARR adjusted for churn: $36-37M (vs. $42M in press release)
- $42M figure includes both contracts in their final quarter
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026
- Net retention claimed above 110%
- Series B was meant to close late 2025 at $720M valuation, repriced down to $560M after Sundry news

### Source 3: Former Employee Blog (2026-02-22)
- Author: "Daniel R", former senior engineer, 14 months tenure
- Positive: good architecture, real customer love, competitive comp ($215K base + $50K equity/yr)
- Negative:
  - Burn ~$4M/month vs ~$3.5M/month revenue (mid-2025)
  - Layoffs: 22 people (~11% of org) in Feb 2025, mostly customer success and BD, not publicly announced
  - Customer concentration: top 5 customers = ~38% of ARR
  - Sundry loss was not a shock internally
- Recommendation: good for senior engineers, not for those needing job security

### Source 4: Leaked Internal Memo (2026-03-05)
- Dated Feb 28, 2026, from CEO Mira Patel
- Restructuring plan for cash-flow breakeven by Q4 2026:
  - 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
  - International expansion deferred to 2027
  - Berlin reframed as "support hub"
  - Nimbus Lite tier sunset (~310 customers, $5K-$20K ARR each, 90-day notice)
  - New $50M credit facility from Silicon Valley Bridge
- Runway: 24+ months at current burn, extended to 36+ months with restructuring
- Breakeven by Q4 2026 triggers Series C conversations

### Source 5: SEC Form D (2026-01-22)
- Confirms $84M total offering, all sold
- 7 investors total
- Security type: Series B Preferred Equity
- Use of proceeds: "expansion, working capital, general corporate purposes"
- No officer/director compensation disclosed in connection with offering

## Key Tensions Identified

1. **ARR discrepancy**: $42M (press release) vs $36-37M adjusted (TechCrunch sources)
2. **Valuation repricing**: $720M target → $560M actual (down ~22%)
3. **Customer concentration**: Top 5 = 38% of ARR (blog), loss of largest ($4.2M) is material
4. **Burn rate**: $4M/mo vs $3.5M/mo revenue = net burn ~$500K/mo (blog)
5. **Layoffs not disclosed**: 22 people cut in Feb 2025, not announced publicly
6. **International pivot**: Berlin office being downsized 30%, expansion deferred
7. **Product tier elimination**: Nimbus Lite sunset affecting ~310 small customers
8. **Credit facility**: $50M from Silicon Valley Bridge — "insurance, not operating capital"

## Source Quality Assessment

- **Press Release**: Company narrative, optimistic framing, confirmed ARR includes churned contracts
- **TechCrunch**: Journalistic, cites "two sources familiar with finances," company confirmed Sundry but not Klatch
- **Blog Post**: Single ex-employee perspective, but specific numbers (burn, layoffs, concentration) that are internally plausible
- **Leaked Memo**: Internal document obtained by The Information, specific and actionable, company declined to confirm specifics
- **SEC Form D**: Regulatory filing, confirms deal structure but limited detail
