# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Assessment

**Date:** 2026-03-15
**Recommendation:** **Pass at current terms — more diligence required**

---

## Bottom Line

Nimbus Logistics has a credible platform and strong backers, but the gap between the company's public narrative and its operational reality is too wide to commit capital without deeper diligence. The Series B closed at $560M post-money after being repriced down from a $720M target [Source 2], and the reported $42M ARR includes two major churned contracts, putting the true run-rate closer to $36–37M [Source 2]. Combined with undisclosed layoffs, customer concentration risk, and a restructuring that abandons the international expansion thesis, the risk profile is higher than the press materials suggest.

---

## The Numbers

**ARR:** The company reports $42M ARR as of Q4 2025 [Source 1], up from $11M a year prior. However, this figure includes Sundry Brands ($4.2M ARR, the largest contract) and Klatch in their final quarters before non-renewal and exit [Source 2]. Adjusted for December churn, the run-rate is approximately $36–37M [Source 2]. The company claims three new $1M+ contracts in Q1 2026 and net retention above 110% [Source 2], but these have not been independently verified.

**Burn:** A former senior engineer reports monthly burn of ~$4M against ~$3.5M in monthly revenue as of mid-2025, implying net burn of roughly $500K/month [Source 3]. The leaked internal memo states the Series B provides 24+ months of runway at current burn, extendable to 36+ months post-restructuring [Source 4].

**Valuation:** The $560M post-money valuation more than doubles the $230M Series A from 2023 [Source 1]. But insiders report the round was originally priced at $720M and repriced downward after the Sundry non-renewal became known to the lead investor in early December [Source 2].

---

## The Tensions

**Customer concentration is material.** The top five customers represent approximately 38% of ARR [Source 3]. The loss of Sundry Brands alone ($4.2M ARR) represents roughly 10% of the reported ARR [Source 2]. The former employee notes the Sundry loss "was not a shock to the team" [Source 3], suggesting concentration risk was known internally but not disclosed to investors until the fundraise.

**Transparency is a concern.** The company quietly laid off 22 employees (~11% of the organization) in February 2025 without public announcement [Source 3]. The current headcount of 187 [Source 1] may already reflect undisclosed cuts. The ARR figure presented to the market includes churned contracts [Source 2]. These signal a company that manages its narrative selectively.

**The growth story is being rewritten.** The press release emphasizes "expansion into international markets" [Source 1], but the leaked internal memo reveals a 30% reduction in Berlin headcount (from 41 to 28–30), a pause on EMEA hiring, and international expansion deferred to 2027 [Source 4]. Berlin is being reframed as a "support hub" [Source 4]. Additionally, the Nimbus Lite tier is being sunset, affecting approximately 310 small customers ($5K–$20K ARR each) [Source 4].

**The credit facility is a signal.** A $50M credit facility from Silicon Valley Bridge has been secured, described internally as "insurance, not operating capital" [Source 4]. This is prudent risk management, but it also suggests the company is preparing for a longer path to profitability than the market may expect.

---

## What's Working

The platform has genuine product-market fit. The carrier-orchestration layer is described as "some of the cleanest distributed-systems code" by a former engineer [Source 3], and customer relationships appear authentic [Source 3]. The investor roster is strong: Lightning Capital (lead), Sequoia and Accel (pro-rata), and FedEx Ventures (strategic) [Source 1, Source 5]. The restructuring plan targets cash-flow breakeven by Q4 2026, positioning the company for Series C from strength [Source 4].

---

## Conditions That Would Change This Recommendation

A follow-on becomes attractive if diligence confirms:
1. **Adjusted ARR is stabilizing or growing** — the $36–37M run-rate [Source 2] needs verification and an upward trajectory.
2. **Customer concentration is decreasing** — the top-5 dependency at ~38% [Source 3] must be demonstrably declining.
3. **The three new $1M+ contracts are real and durable** [Source 2] — these need independent verification.
4. **Transparency improves** — the company should provide audited financials and explain the undisclosed layoffs [Source 3].

---

## Conclusion

Nimbus Logistics is a real company with a real product, strong backers, and a plausible path to profitability. But the gap between the $42M ARR headline and the $36–37M reality, the repriced valuation, the undisclosed layoffs, and the abandoned international thesis all point to a company in a tougher position than its public materials convey. **Pass at current terms.** Revisit if the conditions above are met.
