# Borealis Analytics Acquisition Review

This directory contains the executive committee's independent review of the Corp Dev team's diligence pack for the proposed acquisition of Borealis Analytics.

## Files

- **`memo.md`** — The 1-page memo with the recommendation, concerns, and diligence asks.
- **`concerns.md`** — A longer enumeration of every concern considered, including ones ranked lower.
- **`asks.md`** — The 2-week diligence-ask list (specific questions, owners, deadlines).
- **`decisions/`** — ADRs for key judgment calls (e.g., HOLD recommendation, memo structure).

## Summary

The Corp Dev team recommends **PROCEEDING to LOI at $84M**. After independent review, the recommendation is **HOLD** — do not issue the LOI yet. Conduct the 2-week diligence plan to de-risk the deal before reconsidering.

Key concerns:

- Valuation may be aggressive (7.4x ARR for a small, early-stage company with 9% churn).
- Customer validation is insufficient (only 5 customers contacted, no churned customers).
- Integration plan is overly optimistic (12-month sunset, 85% retention, no migration details).
- No formal retention plan for key engineering talent.

If the 2-week diligence de-risks the deal (e.g., strong unit economics, >80% customer willingness to migrate), the recommendation may change to PROCEED.

## Next Steps

1. Review `memo.md` for the executive committee summary.
2. Review `asks.md` to assign the 2-week diligence tasks.
3. Review `concerns.md` for a deeper dive into the issues.
4. Review `decisions/` for the rationale behind key judgments.
