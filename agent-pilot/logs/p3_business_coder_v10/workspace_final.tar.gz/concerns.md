# Concerns with the Borealis Acquisition Deal Pack

## 1. Overstated Strategic Rationale

- **Claim**: "Borealis would extend our analytics surface area into mid-market e-commerce, a segment we currently service only via partner integrations."
- **Concern**: This is presented as a clear strategic gap, but the pack provides no data on the size of that segment, our current revenue from partner-served accounts, or whether we've attempted to grow that segment organically. Without this context, it's unclear if this is a *new* opportunity or a *faster* way to access an existing one.

## 2. Financial Metrics — Lack of Context and Potential Overoptimism

- **Claim**: "Revenue (recognized GAAP) $9.2M (Up from $5.1M in FY2024 (80% YoY))"
- **Concern**: 80% YoY growth is impressive, but the pack doesn't break down *how* this growth was achieved. Was it driven by price increases, new logos, or expansion? If it's heavily reliant on discounting or large one-time deals, that could be unsustainable. Also, no guidance on future growth trajectory or seasonality.

- **Claim**: "Gross margin 71% (Acceptable for early-growth stage)"
- **Concern**: While 71% is acceptable for early-stage, the pack doesn't compare it to our current platform's gross margin or to the comps. If our platform runs at 80%+, integrating Borealis could *drag down* overall gross margin unless they can scale efficiently.

- **Claim**: "Net retention 118% (Strong)"
- **Concern**: Net retention includes expansion revenue. Without knowing the *logo retention* (91%) and *dollar retention* breakdown, it's unclear if the net retention is driven by expansion of existing customers or by low churn. A 9% churn rate for a SaaS company is not "within typical range" — it's relatively high for a mature product.

## 3. Customer Testimonials — Small Sample, Potential Bias

- **Claim**: "Pre-LOI conversations with their five largest customers indicate strong satisfaction (NPS in the high 40s)."
- **Concern**: Only 5 customers were contacted, and only 4 were willing to be quoted. This is a tiny sample size for a company with 280 customers. The pack doesn't disclose how these 5 were selected — were they the most satisfied? The pack also doesn't ask about *integration concerns* or *vendor lock-in* fears, which are critical for an acquisition.

## 4. Valuation — Comps May Not Be Apples-to-Apples

- **Claim**: "Borealis at $84M / $11.4M ARR = ~7.4x, in line with the lower comps."
- **Concern**: The comps (Hexa, Aspen, Trellis) are all much larger deals (likely >$100M) with different growth profiles and product maturity. Borealis is a Series-A company with $11.4M ARR, while the comps are likely Series C+ or revenue-stage. The 7.4x multiple may be reasonable for a *mature* business but is aggressive for a company with only 280 customers and a 9% churn rate.

## 5. Integration Plan — Overly Optimistic

- **Claim**: "85% retention expected based on conversations with their VP Eng."
- **Concern**: This is a very high retention rate, especially for a company being acquired. The pack doesn't disclose any retention incentives or retention periods for key employees. Without a formal retention plan, it's unlikely that 85% of the team will stay.

- **Claim**: "Aurora platform sunset planned for 12 months post-close"
- **Concern**: Sunsetting a product in 12 months is a massive undertaking. The pack doesn't disclose the customer migration plan, the cost of the migration, or the risk of customer churn during the transition. Many customers may resist moving to a new platform, especially if it requires retraining or changes to their workflows.

## 6. Tech Debt — "Clean" is Subjective

- **Claim**: "Their codebase is 'modern Python + Postgres + dbt' — clean, well-tested."
- **Concern**: This is a qualitative assessment with no evidence. The pack doesn't disclose the results of the engineering review (e.g., code coverage, test pass rates, security vulnerabilities). "Modern" doesn't mean "maintainable" or "scalable."

## 7. Burn Rate and Runway — Hidden Risk

- **Claim**: "Burn rate (avg monthly) $750K, 22 months runway at last cap raise"
- **Concern**: 22 months of runway is substantial, but the pack doesn't disclose the terms of the last cap raise (e.g., liquidation preference, valuation). If the last round was at a high valuation, the company may be "down round" in a sale, which could create misaligned incentives with employees.

## 8. No Disclosed Risks or Mitigation Plan

- The pack is entirely positive, with no section on "Risks and Mitigation." This is a red flag. Every acquisition has risks — integration, retention, market, regulatory — and the pack should explicitly address them.

## 9. No Discussed Alternatives

- The pack doesn't discuss why acquisition is the best path vs. building in-house, partnering, or waiting. This is a key part of strategic analysis.

## 10. Sign-Off Without Independent Validation

- The pack is signed off by VP Corp Dev, VP Eng (technical review), and CFO (financial review), but there's no indication that these reviews were independent or adversarial. Corp Dev is incentivized to close deals; their recommendation should be treated as a starting point, not a conclusion.
