# Executive Committee Review: Borealis Analytics Acquisition

**Date:** 2026-04-16  
**Prepared by:** Executive Committee Member  
**Recommendation: HOLD** — Do not issue the LOI yet. Conduct 2 weeks of targeted diligence before reconsidering.

## Recommendation

I recommend **HOLD** — do not proceed to LOI at $84M at this time. The deal pack is well-written but overly optimistic in key areas. The valuation (7.4x ARR) appears aggressive for a company with only 280 customers and a 9% churn rate. Customer validation is insufficient (only 5 customers contacted, no churned customers), and the integration plan lacks detail on migration risk and retention incentives.

I would change my stance to **PROCEED** if the next 2 weeks of diligence show:

1. Strong unit economics (e.g., CAC payback < 12 months, LTV:CAC > 3x).
2. >80% of 10+ sampled customers (including churned) are willing to migrate.
3. A feasible 6-month migration plan with no critical technical debt.
4. A formal retention plan for key engineering talent.

## Strongest Concerns

1. **Valuation vs. Risk Profile**: At $84M / $11.4M ARR = 7.4x, Borealis is priced at the high end of the comps (7x–12x), but the comps are for larger, more mature companies. Borealis is a Series-A company with only 280 customers and a 9% churn rate — this is not "within typical range" for a company of this size.

2. **Customer Validation Gap**: The pack cites NPS in the "high 40s" from 5 customers, but only 4 were willing to be quoted. This is a tiny sample for 280 customers, and no churned customers were included. The pack doesn’t ask about integration concerns or vendor lock-in fears — critical for an acquisition.

3. **Integration Risk**: The 12-month Aurora sunset is aggressive, but the pack provides no details on the migration plan, customer retraining, or risk of churn during transition. The 85% team retention rate is optimistic without a formal retention plan.

4. **Financial Metrics Lacking Context**: The 80% YoY revenue growth is impressive, but the pack doesn’t break down how it was achieved (new logos vs. expansion vs. price). Gross margin (71%) is "acceptable" but may drag down our overall margin if we can’t scale efficiently.

## Diligence Asks for Next 2 Weeks

1. **Financials (FP&A Lead)**: Break down revenue growth drivers, CAC payback, and LTV:CAC. Provide a 12-month forecast.
2. **Customers (Head of Product)**: Conduct reference calls with 10 customers (including 3 churned) and ask about migration willingness and integration concerns.
3. **Technical (Chief Architect)**: Detailed codebase review (coverage, security, scalability) and migration cost/timeline estimate.
4. **Retention (Head of HR)**: Draft a retention plan for engineering team and conduct confidential interviews with 5 key engineers.
5. **Legal (General Counsel)**: Review customer contracts for change-of-control clauses and cap table for liquidation preferences.

## Conclusion

The deal has strategic merit — Borealis’s product fills a gap in our mid-market e-commerce offering. But the pack is an advocacy document, not a balanced analysis. The $84M price tag is not justified without more data. I recommend holding the LOI and conducting the 2-week diligence plan. If the next round of diligence de-risks the deal, I will support proceeding to LOI. If not, we should walk away.
