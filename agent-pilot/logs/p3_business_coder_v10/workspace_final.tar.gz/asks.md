# Diligence Asks for the Next 2 Weeks

## 1. Financial Deep Dive (Owner: FP&A Lead, Deadline: 2026-04-25)

- [ ] **Ask 1.1**: Break down FY2025 revenue growth by driver (new logos vs. expansion vs. price). What is the *dollar retention* rate (not just net retention)?
- [ ] **Ask 1.2**: Provide a 12-month revenue forecast with assumptions (e.g., churn, expansion, pricing). How does this compare to the Corp Dev team's IRR estimate?
- [ ] **Ask 1.3**: What is Borealis's CAC payback period? What is their LTV:CAC ratio? Are they unit-economic positive?

## 2. Customer Validation (Owner: Head of Product, Deadline: 2026-04-25)

- [ ] **Ask 2.1**: Conduct reference calls with *10* Borealis customers (not just the top 5), including 3 churned customers and 3 customers who declined to be quoted in the pack. Ask about integration concerns, vendor lock-in fears, and satisfaction with support.
- [ ] **Ask 2.2**: Survey Borealis customers on their willingness to migrate to our platform. What would it take to convince them? What are their biggest concerns?

## 3. Technical Deep Dive (Owner: Chief Architect, Deadline: 2026-04-25)

- [ ] **Ask 3.1**: Provide a detailed engineering review of Borealis's codebase, including code coverage, test pass rates, security vulnerabilities, and scalability concerns.
- [ ] **Ask 3.2**: What is the estimated cost and timeline to sunset Aurora and migrate all customers to our platform? Include a risk assessment of the migration.

## 4. Team Retention Plan (Owner: Head of HR, Deadline: 2026-04-25)

- [ ] **Ask 4.1**: Draft a retention plan for Borealis's engineering team, including retention bonuses, vesting schedules, and post-acquisition roles.
- [ ] **Ask 4.2**: Conduct confidential interviews with 5 key Borealis engineers (not just the VP Eng) to understand their post-acquisition intentions.

## 5. Competitive and Market Analysis (Owner: VP Corp Dev, Deadline: 2026-04-25)

- [ ] **Ask 5.1**: Provide a more rigorous comp analysis, including at least 3 deals with similar ARR ($10M–$15M) and growth stage (Series A/B).
- [ ] **Ask 5.2**: What is the size of the mid-market e-commerce analytics segment? How much revenue do we currently generate from this segment via partners?

## 6. Legal and Contractual Review (Owner: General Counsel, Deadline: 2026-04-25)

- [ ] **Ask 6.1**: Review Borealis's customer contracts for change-of-control clauses, termination-on-acquisition triggers, or other deal-breakers.
- [ ] **Ask 6.2**: Review Borealis's cap table for liquidation preferences, anti-dilution provisions, or other investor rights that could impact the acquisition.

## 7. Integration Plan (Owner: Integration Program Manager, Deadline: 2026-04-25)

- [ ] **Ask 7.1**: Develop a detailed integration plan, including key milestones, resource requirements, and risk mitigation strategies.
- [ ] **Ask 7.2**: What is the estimated cost of the integration (including migration, retraining, and support)?

## 8. Alternatives Analysis (Owner: VP Strategy, Deadline: 2026-04-25)

- [ ] **Ask 8.1**: What is the cost and timeline to build a similar capability in-house? What are the key risks?
- [ ] **Ask 8.2**: What are the terms of a potential partnership with Borealis instead of an acquisition?

## 9. Final Recommendation (Owner: Executive Committee, Deadline: 2026-04-30)

- [ ] **Ask 9.1**: Based on the above diligence, what is the final recommendation: proceed to LOI, hold, or pass?
- [ ] **Ask 9.2**: If proceeding, what are the non-negotiables (e.g., price, retention plan, integration timeline)?
