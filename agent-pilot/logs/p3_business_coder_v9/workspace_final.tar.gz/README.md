# Borealis Analytics Acquisition Review

## Overview

This repository contains an independent executive review of the Corp Dev team's acquisition diligence pack for Borealis Analytics.

## Files

| File | Purpose |
|------|---------|
| `memo.md` | **Primary deliverable**: 1-page memo with recommendation, concerns, and next steps. |
| `concerns.md` | Detailed enumeration of all concerns with the deal pack. |
| `asks.md` | 2-week diligence plan with specific questions, owners, and deadlines. |
| `decisions/adr001.md` | Architectural Decision Record for memo tone and recommendation framework. |

## Key Findings

- **Recommendation**: HOLD — not PROCEED or PASS — with conditions for moving forward.
- **Top Concerns**: Revenue quality, customer satisfaction validation, integration risk, synergy overstatement.
- **Critical Diligence Asks**: Revenue breakdown, customer concentration, integration plan, financial reconciliation.

## Timeline

- **Pack Date**: 2026-04-15
- **Decision Deadline**: 2026-04-30 (LOI)
- **Diligence Sprint**: 2026-04-16 to 2026-04-27
- **Final Briefing**: 2026-04-28
- **Extended LOI Deadline**: 2026-05-07 (if needed)

## How to Use This Review

1. Read `memo.md` for the executive summary.
2. Review `concerns.md` for a deeper understanding of the pack's weaknesses.
3. Use `asks.md` as a checklist for the next 2 weeks of diligence.
4. Refer to `decisions/adr001.md` for the rationale behind the HOLD recommendation.
