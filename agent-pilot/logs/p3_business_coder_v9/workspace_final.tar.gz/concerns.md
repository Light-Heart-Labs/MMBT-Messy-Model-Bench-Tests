# Concerns with the Borealis Acquisition Deal Pack

## 1. Overstated Strategic Rationale

- **Claim**: "Borealis would extend our analytics surface area into mid-market e-commerce, a segment we currently service only via partner integrations."
- **Concern**: This is presented as a clear strategic gap, but the pack provides no data on the size of that segment, our current revenue from partner-served accounts, or whether those partners would be threatened by a direct acquisition. If our partners are the primary channel for this segment, this could be a competitive threat rather than an expansion.

## 2. Revenue Quality and Growth Sustainability

- **Claim**: 80% YoY revenue growth ($5.1M → $9.2M) and 92% ARR growth.
- **Concern**: No breakdown of revenue composition. Is growth driven by new logos or expansion of existing customers? The logo retention is 91%, which is healthy, but net retention (118%) suggests heavy expansion. If growth is primarily expansion-driven, it may be more fragile than the headline numbers suggest. The pack does not disclose the breakdown of new vs. expansion revenue.

## 3. Customer Testimonials — Small Sample, High Variance

- **Claim**: NPS in the high 40s from top 5 customers.
- **Concern**: Only 4 out of 5 customers were willing to be quoted. A 20% non-response rate from reference calls can indicate underlying issues (e.g., dissatisfaction, churn risk). Also, with only 4 quoted testimonials, the pack cherry-picks the most positive quotes. No mention of any negative feedback or churned customers.

## 4. Tech Debt Assessment — Too Optimistic?

- **Claim**: "Modern Python + Postgres + dbt — clean, well-tested. Engineering review found no concerning patterns."
- **Concern**: This is a high-level assessment. The pack provides no details on test coverage percentages, CI/CD maturity, or any specific technical debt items flagged. "No concerning patterns" is vague and could mask significant integration complexity.

## 5. Integration Plan — Overly Optimistic Timeline and Retention

- **Claim**: 4-6 month integration timeline; ~85% retention expected.
- **Concern**: No details on how the integration will be executed. What teams are involved? What are the key dependencies? The 85% retention estimate is based on "conversations with their VP Eng" — not a formal retention plan or employee engagement survey. With only 14 engineers, losing even 2-3 key people could derail the integration.

## 6. Synergy Estimate — Unsubstantiated

- **Claim**: $3.2M annual cost savings from consolidated infra.
- **Concern**: No methodology provided. How was this number calculated? Is it based on actual usage overlap, or theoretical optimization? Given the 4-6 month integration timeline, the near-term P&L impact may be negative despite the long-term savings.

## 7. Comparable Transactions — Misleading Comparison

- **Claim**: Borealis at ~7.4x ARR is "in line with the lower comps."
- **Concern**: The comps are at different stages:
  - Hexa Insights: acquired by Salesforce (strategic buyer, premium pricing)
  - Aspen Data: acquired by Snowflake (platform fit, premium pricing)
  - Trellis Analytics: acquired by HubSpot (mid-market fit, lower premium)
  - Borealis: Series-A, early-stage, smaller ARR ($11.4M vs. likely $20M+ for comps)
  The pack does not adjust for stage, growth rate, or profitability. A 7.4x multiple for a company growing at 80% revenue growth is actually high for its stage.

## 8. Burn Rate and Runway — Hidden Risk

- **Claim**: $750K avg monthly burn, $4.1M cash, 22 months runway.
- **Concern**: Runway is calculated at current burn, but integration costs (severance, migration, integration team) could spike burn in the short term. Also, no mention of any debt or liabilities beyond cash. What about deferred revenue, accrued compensation, or legal contingencies?

## 9. Product Roadmap — No Customer Feedback Loop

- **Claim**: "PM team validated all three features are differentiated."
- **Concern**: No data on customer adoption or usage of these features. Are customers actually using the new capabilities, or are they underutilized? A feature-rich product that customers don’t adopt is a risk.

## 10. LOI Deadline Pressure

- **Claim**: Decision needed by 2026-04-30.
- **Concern**: The pack is dated 2026-04-15, giving only 2 weeks for executive review. Given the concerns above, this timeline pressures the committee to rely on the Corp Dev team’s assessment without sufficient independent validation.

## 11. Missing: Customer Concentration Risk

- **Omission**: No disclosure of top-5 or top-10 customer concentration. If a single customer or a small group accounts for a disproportionate share of ARR, churn in that segment could materially impact the valuation.

## 12. Missing: Competitive Landscape

- **Omission**: No discussion of competitors (e.g., Segment, Amplitude, Mixpanel) or how Borealis differentiates beyond the 3 features mentioned. The pack focuses on feature overlap with *our* products, not with *third-party* products.

## 13. Missing: Legal and Contractual Risks

- **Omission**: No mention of:
  - Key customer contract terms (e.g., termination clauses, SLAs)
  - IP ownership (especially for the 3 new features)
  - Employee contracts (non-compete clauses, vesting schedules)
  - Any ongoing or potential litigation.

## 14. Financials — GAAP Revenue vs. Cash Revenue

- **Concern**: GAAP revenue recognition may differ significantly from cash collections. If Borealis has aggressive revenue recognition policies (e.g., upfront recognition of multi-year contracts), the cash flow profile could be weaker than the GAAP numbers suggest.

## 15. Valuation — No Sensitivity Analysis

- **Omission**: No discussion of valuation range. What’s the minimum acceptable price? What happens to the IRR if the multiple increases to 8x or 9x? The pack presents a single point estimate ($84M) without scenario analysis.
