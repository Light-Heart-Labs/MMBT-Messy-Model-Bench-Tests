# Executive Committee Memo: Borealis Analytics Acquisition

**Date:** 2026-04-16  
**From:** Executive Committee Member  
**Subject:** Independent Review of Deal Pack — Recommendation: **HOLD**

---

## Recommendation

**HOLD** — do not issue the LOI at this time. Instead, approve a 2-week diligence sprint to address the top concerns below. If conditions are met, I will recommend PROCEED; if not, PASS.

### Conditions to Shift to PROCEED

1. **Revenue quality validated**: ≥60% of FY2025 growth is new logo growth (not just expansion), and top-5 customers represent ≤30% of ARR.
2. **Customer satisfaction triangulated**: 3+ additional reference calls (including churned customers) confirm satisfaction and NPS in the 40s.
3. **Integration plan detailed and signed off**: Timeline ≤6 months, retention plan with ≥80% commitment from engineering team, and synergy estimate ($3.2M) line-item validated.
4. **Financials reconciled**: GAAP revenue matches cash collections, and balance sheet discloses all liabilities.

If any condition is unmet, recommend PASS.

---

## Strongest Concerns with the Deal Pack

1. **Overstated Strategic Rationale**: The pack claims Borealis fills a "mid-market e-commerce gap," but provides no data on our current revenue from partner-served accounts or whether partners would be threatened. This could be a competitive threat, not an expansion.

2. **Revenue Quality Opaque**: 80% YoY revenue growth sounds strong, but the pack omits the breakdown of new vs. expansion revenue. If growth is primarily expansion-driven, it may be more fragile than the headline numbers suggest.

3. **Customer Testimonials — Small Sample, Cherry-Picked**: Only 4 of 5 reference customers were willing to be quoted — a 20% non-response rate can indicate dissatisfaction. The pack cherry-picks the most positive quotes without mentioning any negative feedback.

4. **Tech Debt Assessment — Too Optimistic**: "Clean, well-tested" is vague. No test coverage %, CI/CD maturity, or specific debt items are disclosed. "No concerning patterns" is a red flag for insufficient technical diligence.

5. **Synergy Estimate — Unsubstantiated**: $3.2M annual savings is stated without methodology. Given the 4-6 month integration timeline, near-term P&L impact may be negative.

6. **Comparable Transactions — Misleading**: The pack compares Borealis (Series-A, $11.4M ARR) to larger, later-stage companies. A 7.4x multiple for an 80% growth company is actually high for its stage — no adjustment is made.

---

## Next 2 Weeks: Diligence Asks

I recommend the following focused diligence (detailed in `asks.md`):

- **Revenue Quality**: Breakdown of new vs. expansion revenue, top-5/10 customer concentration, key contract terms.
- **Customer Validation**: Additional reference calls (including churned customers), competitive win/loss analysis.
- **Integration Risk**: Detailed integration plan, engineering metrics (test coverage, MTTR), technical deep dive.
- **Financial & Legal**: GAAP-to-cash reconciliation, full balance sheet, IP ownership for new features, employee retention plan.
- **Valuation**: Sensitivity analysis (IRR at 6x–9x ARR), proposed LOI structure (cash/stock split, escrow).

All asks must be completed by 2026-04-27 to allow 3 days for executive review before the LOI deadline.

---

## Conclusion

The Corp Dev team’s recommendation is advocacy, not balanced analysis. While Borealis has compelling attributes (strong ARR growth, clean tech stack, in-line valuation), the pack omits critical context and overstates confidence in integration and synergy assumptions.

A HOLD is not a rejection — it is disciplined execution. With focused diligence, we can either de-risk the deal and proceed with confidence, or walk away without wasting time and capital on a flawed acquisition.
