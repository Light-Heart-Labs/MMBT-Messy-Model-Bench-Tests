# Diligence Asks for Borealis Analytics — Next 2 Weeks

## Priority 1: Revenue Quality & Customer Concentration

| Ask | Owner | Deadline | Why |
|-----|-------|----------|-----|
| Provide breakdown of FY2025 revenue: new vs. expansion, by customer segment (e-commerce vs. other). | Borealis CFO | 2026-04-22 | To assess growth sustainability and strategic fit. |
| Identify top 5 and top 10 customers by ARR, and disclose any single-customer concentration >15%. | Borealis CEO | 2026-04-22 | To assess customer concentration risk. |
| Share key customer contract terms: renewal dates, termination clauses, SLAs, and pricing escalation terms. | Borealis Legal (via Corp Dev) | 2026-04-24 | To assess revenue visibility and churn risk. |

## Priority 2: Customer & Market Validation

| Ask | Owner | Deadline | Why |
|-----|-------|----------|-----|
| Provide list of all customers who declined reference calls (anonymized if needed), and any churned customers from the top 10 in the last 12 months. | Borealis VP Sales | 2026-04-22 | To validate the 4/5 reference response rate and NPS claims. |
| Conduct 3 additional reference calls with churned customers or non-quote-eligible customers (安排 by our Corp Dev team). | Our Corp Dev | 2026-04-26 | To triangulate satisfaction claims. |
| Provide competitive win/loss analysis for FY2025: win rates vs. Segment, Amplitude, Mixpanel; reasons for losses. | Borealis VP Sales | 2026-04-23 | To assess true competitive positioning. |

## Priority 3: Technical & Integration Risk

| Ask | Owner | Deadline | Why |
|-----|-------|----------|-----|
| Share engineering metrics: test coverage %, CI/CD pass rate, mean time to recovery (MTTR), and tech debt backlog (prioritized). | Borealis CTO | 2026-04-22 | To validate "clean codebase" claim. |
| Provide detailed integration plan: key milestones, dependencies, team assignments, and risk mitigation for the 4-6 month timeline. | Borealis VP Eng + Our Integration Lead | 2026-04-25 | To assess feasibility of integration timeline. |
| Conduct a 90-minute technical deep dive with Borealis engineering team (focused on scalability, data pipeline, and security). | Our VP Eng | 2026-04-27 | To validate tech debt assessment. |

## Priority 4: Financial & Legal Due Diligence

| Ask | Owner | Deadline | Why |
|-----|-------|----------|-----|
| Reconcile GAAP revenue to cash collections for FY2025 and Q1 2026. | Borealis CFO | 2026-04-22 | To assess cash flow quality. |
| Provide full balance sheet (including deferred revenue, accrued liabilities, and any debt). | Borealis CFO | 2026-04-23 | To assess true cash on hand and obligations. |
| Confirm IP ownership for all 3 new features (event-based segmentation, real-time pipelines, embedded dashboards) and share any third-party licenses. | Borealis Legal | 2026-04-24 | To assess IP risk. |
| Share employee retention plan and non-compete agreements for engineering team. | Borealis CEO | 2026-04-25 | To validate 85% retention assumption. |

## Priority 5: Valuation & Deal Structuring

| Ask | Owner | Deadline | Why |
|-----|-------|----------|-----|
| Provide sensitivity analysis: IRR at 6x, 7x, 8x, and 9x ARR multiples. | Our FP&A (with Corp Dev) | 2026-04-26 | To assess valuation range. |
| Share proposed LOI structure: cash/stock split, earnout terms, escrow percentage, and key representations & warranties. | Our Corp Dev | 2026-04-27 | To assess deal risk allocation. |

## Summary

- **Total Asks**: 14 specific diligence items.
- **Critical Path**: Revenue quality, customer concentration, and integration plan are the highest-priority items — they directly impact the valuation and synergy assumptions.
- **Deadline Alignment**: All asks must be completed by 2026-04-27 to allow 3 days for executive review before the 2026-04-30 LOI deadline.
