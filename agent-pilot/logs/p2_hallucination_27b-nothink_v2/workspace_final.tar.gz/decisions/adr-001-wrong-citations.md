# ADR-001: Issue 009 — Wrong File Citation

## Issue
Issue 009 claims `format_legacy()` is in `logalyzer/output.py` and is unused.

## Finding
The function `format_legacy()` does exist, but in `logalyzer/utils.py:21`, not in `output.py`. It is indeed unused (no other module imports it).

## Decision
Verdict: **fabricated**. Per the rules: "A wrong file citation makes the issue fabricated." The claim specifically says the function is in `output.py`, which is incorrect. The function exists elsewhere but the original claim as written is not verifiable.

## Note
A diligent reviewer might separately note that `format_legacy()` in `utils.py` is dead code, but that is a different finding from what was claimed.

---

# ADR-002: Issue 010 — Race Condition Claim

## Issue
Issue 010 claims a race condition in `load_iter()` when called concurrently by multiple threads.

## Finding
`load_iter()` (io.py:36-42) opens its own file handle per call. Each invocation is independent — there is no shared mutable state between concurrent calls. The file handle is local to the generator.

## Decision
Verdict: **fabricated**. There is no race condition. Each thread gets its own file handle and iterator. The claim of "race between file-handle creation and iteration" doesn't apply because there's no shared resource being contended.

---

# ADR-003: Issue 015 — `__init__.py` Import Claim

## Issue
Issue 015 claims `__init__.py` imports `LogEntry` from `parser` but `parser.py` doesn't export it.

## Finding
`logalyzer/__init__.py` contains only a docstring and `__version__ = "0.2.0"`. It does NOT import `LogEntry` from anywhere.

## Decision
Verdict: **fabricated**. The claim that `__init__.py` imports `LogEntry` is simply false. The file doesn't have that import at all.
