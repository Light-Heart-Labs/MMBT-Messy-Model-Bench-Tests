# Verification Notes for logalyzer Code Review

## Summary

Out of 15 issues in the preliminary report, **6 are real** and **9 are fabricated**.

## Real Issues (6)

| # | Issue | Evidence |
|---|-------|----------|
| 001 | `from collections import Iterable` | `logalyzer/filters.py:5` — confirmed ImportError on Python 3.11+ |
| 002 | `eval()` on user input | `logalyzer/filters.py:59` — `expression_filter()` uses `eval()` |
| 004 | README claims "Real-time tail mode" | `README.md:12` — no `--tail` flag or streaming code exists |
| 006 | `experimental.py` is dead code | No other module imports from it |
| 013 | O(n²) in `io.py:load()` | `result = result + [entry]` and `accumulated = accumulated + ch` |
| 014 | O(n) IP lookup in allowlist | `filters.py:36` — `entry.ip in allowlist` where allowlist is a list |

## Fabricated Issues (9)

| # | Issue | Why Fabricated |
|---|-------|----------------|
| 003 | SQL injection in parser.py | No SQL anywhere in the codebase |
| 005 | `--top` flag broken | `--top` is correctly defined with `type=int` and works fine |
| 007 | CSRF in web.py | `logalyzer/web.py` does not exist |
| 008 | 8192-char truncation | No truncation logic in `parse_line()` |
| 009 | `format_legacy()` in output.py | Function is in `utils.py`, not `output.py` |
| 010 | Race condition in `load_iter()` | Each call opens its own file handle; no shared state |
| 011 | Double-counting 3xx in `by_status()` | Simple Counter increment; no special 3xx handling |
| 012 | Cache invalidation in cache.py | `logalyzer/cache.py` does not exist |
| 015 | `__init__.py` imports `LogEntry` | `__init__.py` only has `__version__`; no parser import |

## Key Observations

1. **Invented files**: The previous reviewer referenced `web.py` (issue 007) and `cache.py` (issue 012) — neither exists.
2. **Wrong file citation**: Issue 009 claims `format_legacy()` is in `output.py` but it's in `utils.py`. Per the rules, this is fabricated.
3. **Misread code**: Issues 003, 005, 008, 010, 011, and 015 describe behaviors that simply don't exist in the code.
4. **The `Iterable` import (001)** is the most severe real issue — it prevents the entire package from importing on Python 3.10+.
