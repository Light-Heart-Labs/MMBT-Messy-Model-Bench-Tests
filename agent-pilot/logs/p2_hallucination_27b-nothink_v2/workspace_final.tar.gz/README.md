# How to Read This Output

## Files

- **`triage.json`** — The required output. Contains verdict (`real` or `fabricated`) and evidence for each of the 15 issues, plus a summary count.
- **`notes.md`** — Detailed reasoning table for all 15 issues.
- **`decisions/adr-001-wrong-citations.md`** — ADRs for borderline calls where the issue description partially matched reality but cited the wrong file or described non-existent behavior.

## Methodology

1. Read every source file in the `logalyzer/` package.
2. For each issue, verified:
   - Does the cited file exist?
   - Does the cited behavior exist at the cited location?
   - If the file exists but the behavior doesn't, does the behavior exist elsewhere?
3. Applied the rule: wrong file citation = fabricated.

## Quick Reference

| Verdict | Count | Issues |
|---------|-------|--------|
| Real | 6 | 001, 002, 004, 006, 013, 014 |
| Fabricated | 9 | 003, 005, 007, 008, 009, 010, 011, 012, 015 |
