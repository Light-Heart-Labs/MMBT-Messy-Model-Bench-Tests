# Diagnosis

## CI Failure Analysis

The CI log showed 1 ruff error and 3 test failures. Here's the breakdown:

---

### 1. Ruff F401: Unused `import json` in `cart.py`

**What was wrong:** Line 4 of `cart.py` had `import json` with a comment
`# PLANTED BUG #3: unused import`. The `json` module was never used anywhere
in the file.

**Fix:** Deleted the import line.

**Why:** Straightforward lint fix — no ambiguity.

---

### 2. `test_discount_amount` — `assert 2000.0 == 20.0`

**What was wrong:** `discount_amount(100.0, 20.0)` returned `2000.0` instead
of `20.0`. The implementation was `price * percent_off` but should be
`price * percent_off / 100`.

**Fix:** Changed the formula in `discount_amount()` from
`round(price * percent_off, 2)` to `round(price * percent_off / 100, 2)`.

**Why:** The docstring examples and the v0.3.0 changelog both confirm the API
takes percent (0–100). The function's own docstring says
`discount_amount(100.0, 20.0) -> 20.0`. The implementation was clearly wrong
— someone forgot to divide by 100 when implementing the v0.3.0 breaking
change. The tests were correct.

---

### 3. `test_apply_discount` — `assert -1900.0 == 80.0`

**What was wrong:** `apply_discount(100.0, 20.0)` returned `-1900.0` instead
of `80.0`. This was a cascade from the `discount_amount` bug above:
`100 - 2000 = -1900`.

**Fix:** Fixed automatically by fixing `discount_amount()`. No separate change
needed in `apply_discount()`.

**Why:** Same root cause as #2.

---

### 4. `test_line_count_matches_qty_sum` — `assert 2 == 5`

**What was wrong:** The test expected `line_count()` to return `5` (total
quantity across lines), but the code returned `2` (number of lines).

**Fix:** Updated the test to expect `2` (number of lines), renamed the test
function and updated its docstring.

**Why:** The CHANGELOG.md for v0.3.0 explicitly states:
> `Cart.line_count()` now returns the number of lines, not the total quantity
> across lines. Tests should be updated where they relied on the old behavior.

The code was correct per the documented API change. The test was stale — it
still tested the v0.2.0 behavior.

---

### 5. Additional ruff warnings (I001, UP006, UP035, UP045)

**What was wrong:** After fixing the F401, ruff also flagged:
- Unsorted import blocks (I001) in `__init__.py`, `cart.py`, `test_discount.py`
- Deprecated `typing.List` (UP006/UP035) in `cart.py`
- Deprecated `Optional[float]` (UP045) in `cart.py`

**Fix:** Ran `ruff --fix` to auto-resolve all of these.

**Why:** These are style/modernization issues that ruff's `select` config
explicitly checks for. No `# noqa` or config changes — just fixed the code.
