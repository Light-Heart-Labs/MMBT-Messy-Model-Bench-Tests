# Changelog

## v0.3.2 (current — CI green)

**Bug fixes:**

- **`discount_amount()` was not dividing by 100.** The v0.3.0 breaking change
  switched the API from fraction (0.0–1.0) to percent (0–100), but the
  implementation still multiplied `price * percent_off` without dividing by 100.
  This caused `discount_amount(100.0, 20.0)` to return `2000.0` instead of
  `20.0`, and cascaded into `apply_discount()` returning `-1900.0` instead of
  `80.0`. Fixed by changing the formula to `price * percent_off / 100`.

- **`test_line_count_matches_qty_sum` was testing the old v0.2.0 API.** Per the
  v0.3.0 changelog, `Cart.line_count()` was changed to return the number of
  lines (not total quantity). The test still asserted the old behavior
  (`line_count() == 5` for total qty). Updated the test to assert `line_count()
  == 2` (number of lines), renamed to `test_line_count_returns_number_of_lines`.

- **Removed unused `import json` from `cart.py`.** This was a planted bug
  triggering ruff F401.

- **Resolved ruff lint warnings:** sorted import blocks (I001), replaced
  deprecated `typing.List` with built-in `list` (UP006/UP035), replaced
  `Optional[float]` with `float | None` (UP045).

**Verification:**

- `ruff check src/ tests/` → All checks passed (exit 0)
- `pytest -q` → 7 passed, 0 failed (exit 0)

## v0.3.1 (previous — CI red)

CI was failing on this version. See `ci_failure.log` for the full output.

## v0.3.0

- **BREAKING**: `discount_amount()` and `apply_discount()` now take percent (0-100)
  instead of fraction (0.0-1.0). Update callers from `apply_discount(p, 0.2)` to
  `apply_discount(p, 20.0)`.
- `Cart.line_count()` now returns the number of lines, not the total quantity
  across lines. Tests should be updated where they relied on the old behavior.

## v0.2.0

- Added `Cart.set_discount()` for cart-wide discounts.
- `Cart.line_count()` returns total quantity across lines.

## v0.1.0

- Initial release.
