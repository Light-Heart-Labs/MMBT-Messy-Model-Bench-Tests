# ADR-001: Fix discount_amount implementation, not the tests

**Status:** Accepted
**Date:** 2025-01-XX

## Context

`discount_amount(100.0, 20.0)` returned `2000.0` instead of `20.0`. The
function's docstring examples clearly state the expected behavior:
`discount_amount(100.0, 20.0) -> 20.0`. The v0.3.0 changelog documents that
the API switched from fraction to percent.

## Decision

Fix the implementation (`price * percent_off / 100`) rather than changing the
tests. The tests were correct; the implementation had a bug introduced during
the v0.3.0 migration.

## Consequences

- `discount_amount` and `apply_discount` now return correct values.
- No public API change — the fix makes the code match its documented behavior.

---

# ADR-002: Update test_line_count to match v0.3.0 API

**Status:** Accepted
**Date:** 2025-01-XX

## Context

`Cart.line_count()` returns `len(self.lines)` (number of lines). The test
expected total quantity (5). The v0.3.0 changelog explicitly says:
> `Cart.line_count()` now returns the number of lines, not the total quantity
> across lines. Tests should be updated where they relied on the old behavior.

## Decision

Update the test to match the new API (expect 2 lines), rather than reverting
the code to the old behavior. The code is correct per the documented API
change; the test was stale.

## Consequences

- Test now correctly validates the v0.3.0+ behavior.
- No public API change — the test now matches the documented contract.
