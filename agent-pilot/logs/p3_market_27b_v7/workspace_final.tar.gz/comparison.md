# Password Manager Comparison: 5 Products Evaluated

**Date:** 2025-07-11  
**Context:** 50-person engineering team at a Series-B SaaS company  
**Goal:** Replace shadow-IT password storage (browser, sticky notes, Slack DMs)

---

## Pricing Comparison

| Feature | 1Password Business | Bitwarden Teams | Bitwarden Enterprise | LastPass Business | Dashlane Business | Keeper Business |
|---------|:-:|:-:|:-:|:-:|:-:|:-:|
| **Per-seat price** (annual billing) | $7.99/mo [1] | $4.00/mo [2] | $6.00/mo [2] | $7.00/mo [3] | $11.00/mo [4] | Not publicly listed [5] |
| **50 seats / year** | **$4,794** | **$2,400** | **$3,600** | **$4,200** | **$6,600** | Unknown |
| **Free trial** | 14 days [1] | Yes [2] | Yes [2] | 14 days [3] | Yes [4] | Yes [5] |
| **Volume discount** | Contact sales [1] | Contact sales [2] | Contact sales [2] | Site license available [3] | Contact sales [4] | Contact sales [5] |

---

## Security Architecture

| Feature | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---------|:-:|:-:|:-:|:-:|:-:|
| **Zero-knowledge** | Yes [6] | Yes [7] | Yes [8] | Yes [9] | Yes [5] |
| **Encryption** | AES-256 [6] | AES-256 [7] | AES-256 [8] | AES-256-CBC-HMAC [9] | AES-256 [5] |
| **Key derivation** | PBKDF2 / Argon2 [6] | PBKDF2 SHA-256, Argon2 optional [7] | PBKDF2 SHA-256 [8] | Proprietary [9] | Proprietary [5] |
| **Open source** | No (audited) [6] | Yes [7] | No [8] | No [9] | No [5] |
| **Bug bounty** | Yes — industry's largest [6] | Yes [7] | Yes [8] | Not confirmed | Not confirmed |
| **Security incidents** | None publicized | None publicized | 8+ incidents (2011–2026) [10] | None publicized | None publicized |

---

## Compliance & Certifications

| Certification | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---------------|:-:|:-:|:-:|:-:|:-:|
| **SOC 2 Type II** | Yes [6] | Yes [7] | Yes [8] | Not confirmed | Yes [5] |
| **SOC 3** | Not confirmed | Yes [7] | Yes [8] | Not confirmed | Not confirmed |
| **ISO 27001** | Not confirmed | Yes [7] | Yes [8] | Not confirmed | Not confirmed |
| **HIPAA** | Not confirmed | Yes [7] | Not confirmed | Not confirmed | Not confirmed |
| **FedRAMP** | Not confirmed | Not confirmed | Not confirmed | Not confirmed | Not confirmed |
| **GDPR** | Not confirmed | Yes [7] | Not confirmed | Not confirmed | Not confirmed |

---

## SSO & Identity Integration

| Feature | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---------|:-:|:-:|:-:|:-:|:-:|
| **SAML SSO** | Yes [1] | Yes [2] | Yes [3] | Yes [4] | Yes [5] |
| **SCIM provisioning** | Yes [1] | Yes [2] | Not confirmed | Yes [4] | Not confirmed |
| **Okta** | Yes [1] | Not confirmed | Yes [3] | Yes [4] | Not confirmed |
| **Microsoft Entra ID** | Yes [1] | Yes [2] | Yes [3] | Yes [4] | Not confirmed |
| **Google Workspace** | Not confirmed | Not confirmed | Yes [3] | Yes [4] | Not confirmed |
| **Duo** | Yes [1] | Not confirmed | Not confirmed | Yes [4] | Not confirmed |
| **OneLogin** | Yes [1] | Not confirmed | Yes [3] | Not confirmed | Not confirmed |

---

## Developer Tools

| Feature | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---------|:-:|:-:|:-:|:-:|:-:|
| **CLI** | Yes [11] | Yes [2] | Yes [3] | Not confirmed | Not confirmed |
| **SDKs** | Python, JS, Go [11] | Open source [7] | Not confirmed | Not confirmed | Not confirmed |
| **SSH key management** | Yes [11] | No | No | No | No |
| **Secrets management** | Yes — built-in [11] | Yes — separate product [2] | No | No | Yes — separate product [5] |
| **CI/CD integration** | Kubernetes, Terraform, Ansible, Pulumi [11] | Not confirmed | No | No | No |
| **Git commit signing** | Yes [11] | No | No | No | No |
| **GitHub integration** | Yes [11] | Not confirmed | No | No | No |

---

## Admin & Audit Features

| Feature | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|---------|:-:|:-:|:-:|:-:|:-:|
| **Admin console** | Yes [1] | Yes [2] | Yes [3] | Yes [4] | Yes [5] |
| **Audit logs** | Yes [1] | Yes — event logs [2] | Yes [3] | Yes — encrypted [4] | Yes [5] |
| **SIEM integration** | Yes [1] | Yes [2] | Yes [3] | Not confirmed | Not confirmed |
| **Role-based permissions** | Yes [1] | Yes — Enterprise tier [2] | Yes [3] | Yes [4] | Yes [5] |
| **Password health reports** | Yes — Watchtower [1] | Yes [2] | Yes [3] | Yes [4] | Yes [5] |
| **Multi-tenant support** | Yes [1] | Not confirmed | Not confirmed | Not confirmed | Not confirmed |
| **Device trust / health** | Yes [1] | Not confirmed | Not confirmed | Yes — device binding [9] | Not confirmed |

---

## Platform Coverage

| Platform | 1Password | Bitwarden | LastPass | Dashlane | Keeper |
|----------|:-:|:-:|:-:|:-:|:-:|
| **macOS** | Yes | Yes | Yes | Yes | Yes |
| **Windows** | Yes | Yes | Yes | Yes | Yes |
| **Linux** | Yes | Yes | Yes | Yes | Yes |
| **iOS** | Yes | Yes | Yes | Yes | Yes |
| **Android** | Yes | Yes | Yes | Yes | Yes |
| **Browser extensions** | Yes | Yes | Yes | Yes | Yes |
| **Self-hostable** | No | Yes [7] | No | No | Yes [5] |

---

## Security Incident History

| Product | Incidents | Details |
|---------|-----------|---------|
| **1Password** | None publicized | Industry's largest bug bounty program [6] |
| **Bitwarden** | None publicized | Open source, independently audited [7] |
| **LastPass** | **8+ incidents** | 2011 incident, 2015 breach, 2017 Android vulns, 2021 trackers incident, 2022 two separate breaches (customer data + partially-encrypted vault theft), 2024 injection attacks, 2025 clickjacking, 2026 ETH Zurich analysis [10] |
| **Dashlane** | None publicized | 8 security patents [9] |
| **Keeper** | None publicized | SOC 2 certified [5] |

---

## Sources

[1] https://1password.com/teams/pricing/ — 1Password pricing page (fetched 2025-07-11)  
[2] https://bitwarden.com/ — Bitwarden main page with pricing (fetched 2025-07-11)  
[3] https://lastpass.com/business/ — LastPass Business page (fetched 2025-07-11)  
[4] https://www.dashlane.com/pricing/ — Dashlane pricing page (fetched 2025-07-11)  
[5] https://www.keepersecurity.com/pricing/business-and-enterprise.html — Keeper pricing page (fetched 2025-07-11)  
[6] https://1password.com/security/ — 1Password security page (fetched 2025-07-11)  
[7] https://bitwarden.com/compliance/ — Bitwarden compliance page (fetched 2025-07-11)  
[8] https://lastpass.com/security/ — LastPass security page (fetched 2025-07-11)  
[9] https://www.dashlane.com/security/ — Dashlane security page (fetched 2025-07-11)  
[10] https://en.wikipedia.org/wiki/LastPass — LastPass Wikipedia article, Security incidents section (fetched 2025-07-11)  
[11] https://1password.com/developers/ — 1Password developer tools page (fetched 2025-07-11)
