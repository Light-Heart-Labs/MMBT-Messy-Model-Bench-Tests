# Sources — URLs Fetched During Research

**Research date:** 2026-05-02 08:53:48 UTC

All URLs were fetched using Python `urllib.request` with a standard browser User-Agent.
SHA-256 hashes are provided for verification of page content at time of fetch.

## [1] https://1password.com/teams/pricing/
- **Description:** 1Password pricing page — Business $7.99/user/mo, Teams Starter Pack $19.95/mo
- **SHA-256:** `070d4778d98f63a5f2e7170241a9a8a853d35cd79cc0de16a93b17cd0e369b34`
- **Size:** 443,106 bytes

## [2] https://1password.com/security/
- **Description:** 1Password security page — SOC 2 Type 2, zero-knowledge, bug bounty
- **SHA-256:** `5c0537c4dfb87d349486faf8239a47e2272c04ec5cd4db07bdfbda075b0b0571`
- **Size:** 236,702 bytes

## [3] https://1password.com/developers/
- **Description:** 1Password developer tools — CLI, SDKs, SSH, secrets management, CI/CD
- **SHA-256:** `b844be08caefd3dd4f42c587bd8fa4a1f9597900b01c2395b08c62027befafea`
- **Size:** 237,142 bytes

## [4] https://1password.com/business/
- **Description:** 1Password Business features — SSO, audit logs, admin controls
- **SHA-256:** `331494e7748ebaec68a9953852745952a37da14a8f68433520fc2cf974558dff`
- **Size:** 293,503 bytes

## [5] https://bitwarden.com/
- **Description:** Bitwarden main page — Teams $4/user/mo, Enterprise $6/user/mo pricing
- **SHA-256:** `b19427405b83fb2d7d40fbc9f233b15a4cec798da78edb727e43057b8607a439`
- **Size:** 1,227,070 bytes

## [6] https://bitwarden.com/pricing/
- **Description:** Bitwarden pricing page — plan details and features
- **SHA-256:** `18067793ba2df8138400890ff360dc460f3e80e4926cfe4183696b801b75323f`
- **Size:** 631,080 bytes

## [7] https://bitwarden.com/compliance/
- **Description:** Bitwarden compliance page — SOC 2, SOC 3, ISO 27001, HIPAA, GDPR
- **SHA-256:** `698e1afac43024dcfeccc79a363a49bc0714f896a4fa6dd642cecc5af261c593`
- **Size:** 810,945 bytes

## [8] https://lastpass.com/business/
- **Description:** LastPass Business page — $7/user/month pricing
- **SHA-256:** `38bb012229ec70285acfad63f25a3581dcebaae26185daf1e29095ded38dcd40`
- **Size:** 253,842 bytes

## [9] https://lastpass.com/security/
- **Description:** LastPass security page — SOC 2 Type II, AES-256, zero-knowledge
- **SHA-256:** `fc99c8a8e9dd1f7bab4ecc5b2226e1799a9bf1d05bc5cb26444d51dc89d63138`
- **Size:** 185,734 bytes

## [10] https://en.wikipedia.org/wiki/LastPass
- **Description:** LastPass Wikipedia — Security incidents section (2011-2026)
- **SHA-256:** `4bd439fa437e537df0553c803e0664455b892610f52733ff503816a8e869af8e`
- **Size:** 179,874 bytes

## [11] https://www.dashlane.com/pricing/
- **Description:** Dashlane pricing page — Business $11/user/month
- **SHA-256:** `9a62af6e97a571c09c5c5afb9c614b728dd47e80c933eebd3915aa250a35c0ed`
- **Size:** 562,798 bytes

## [12] https://www.dashlane.com/security/
- **Description:** Dashlane security page — AES-256-CBC-HMAC, zero-knowledge, patents
- **SHA-256:** `24b2a93e85314d0228835c1cb3373eff9a351b5e658eda357807da006013fb4d`
- **Size:** 359,507 bytes

## [13] https://www.dashlane.com/business-password-manager/
- **Description:** Dashlane Business features — SSO, SCIM, audit logs
- **SHA-256:** `dc29b17a3862df8eeab66c6c047e2f6e21cb2c0e5213e252d7009dca17bbd4c2`
- **Size:** 492,584 bytes

## [14] https://www.keepersecurity.com/pricing/business-and-enterprise.html
- **Description:** Keeper Business/Enterprise pricing — prices dynamically loaded, not publicly listed
- **SHA-256:** `27b2e75632d249030308a2db7a9494a2d453dcb82aedd3c8c7dbb1e8489d4628`
- **Size:** 88,711 bytes

## [15] https://www.keepersecurity.com/
- **Description:** Keeper main page — product overview and navigation
- **SHA-256:** `f3754eae0a15913f3d2f5419779c78dd19ccca92e9ad9e31d4f8b3975568f374`
- **Size:** 67,877 bytes
