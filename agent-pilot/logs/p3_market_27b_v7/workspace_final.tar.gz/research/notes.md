# Research Notes — Password Manager Evaluation

## Date: 2025-07-11
## Researcher: Autonomous research agent

---

## Products Evaluated

### 1. 1Password (AgileBits)
- **Business tier**: $7.99/user/month, billed annually
- **Teams Starter Pack**: $19.95/month flat for up to 10 users
- **Source**: https://1password.com/teams/pricing/ (fetched 2025-07-11)
- **Security**: SOC 2 Type 2, zero-knowledge encryption, AES-256, industry's largest bug bounty
- **SSO**: Okta, Entra ID, OneLogin, Duo, and more
- **Developer tools**: CLI, SDKs (Python, JavaScript, Go), API, SSH key management, secrets management, CI/CD integration (Kubernetes, Terraform, Ansible, Pulumi)
- **Audit**: Audit-ready activity logs, Watchtower breach alerts
- **Platforms**: macOS, Windows, Linux, iOS, Android, browser extensions, CLI
- **No known major security incidents**

### 2. Bitwarden (8x8, Inc.)
- **Teams tier**: $4/user/month, billed annually
- **Enterprise tier**: $6/user/month, billed annually
- **Source**: https://bitwarden.com/ (main page pricing section, fetched 2025-07-11)
- **Security**: SOC 2, SOC 3, ISO 27001, HIPAA compliant, zero-knowledge, AES-256, PBKDF2 SHA-256 (Argon2 optional), open source
- **SSO**: SSO integration, SCIM provisioning, directory sync
- **Developer tools**: Secrets Manager (separate product), open source SDKs, CLI
- **Audit**: Event logs, security reports, SIEM integration
- **Platforms**: All major platforms, self-hostable
- **Open source**: Full source code available on GitHub

### 3. LastPass (GoTo/LogMeIn)
- **Business tier**: $7/user/month
- **Source**: https://lastpass.com/business/ (fetched 2025-07-11)
- **Security**: SOC 2 Type II, SOC 3, ISO 27001, BSI C5, zero-knowledge, AES-256, PBKDF2 SHA-256
- **SSO**: Okta, Microsoft Entra ID, Google Workspace, OneLogin
- **Audit**: Activity logs, SIEM integration, compliance reporting
- **Platforms**: All major platforms
- **Security incidents**: Multiple documented incidents:
  - 2011: Security incident
  - 2015: Security breach
  - 2017: Android app vulnerabilities
  - 2021: Third-party trackers and security incident
  - 2022: Customer data and partially-encrypted vault theft (two separate breaches)
  - 2024: Leakage via injection attacks
  - 2025: DOM-based extension clickjacking
  - 2026: ETH Zurich security analysis
  - Source: https://en.wikipedia.org/wiki/LastPass

### 4. Dashlane (Zscaler)
- **Business tier**: $11/user/month, billed annually
- **Source**: https://www.dashlane.com/pricing/ (fetched 2025-07-11)
- **Security**: Zero-knowledge, AES-256-CBC-HMAC, patented security model (8 patents), device binding
- **SSO**: SAML 2.0, SCIM provisioning, Google Workspace, Microsoft Entra ID, Okta, Duo
- **Audit**: Encrypted audit logs, activity reporting, password health scores
- **Platforms**: All major platforms
- **Credential protection**: Omnix™ credential risk detection ($11 add-on)

### 5. Keeper (Keeper Security)
- **Business tier**: Pricing not publicly listed (dynamically loaded on website)
- **Enterprise tier**: Pricing not publicly listed
- **Source**: https://www.keepersecurity.com/pricing/business-and-enterprise.html (fetched 2025-07-11)
- **Note**: Page says "Starts at [dynamic] per user per month, billed annually"
- **Security**: SOC 2, zero-knowledge, AES-256
- **SSO**: SAML 2.0
- **Audit**: Activity logs, compliance reporting
- **Platforms**: All major platforms
- **Concern**: Pricing not transparent — must contact sales

---

## Key Findings

### Pricing Summary (per user, per month, annual billing)
| Product | Tier | Price | 50 seats/year |
|---------|------|-------|---------------|
| 1Password | Business | $7.99 | $4,794 |
| Bitwarden | Teams | $4.00 | $2,400 |
| Bitwarden | Enterprise | $6.00 | $3,600 |
| LastPass | Business | $7.00 | $4,200 |
| Dashlane | Business | $11.00 | $6,600 |
| Keeper | Business | Not listed | Unknown |

### Security Incident History
- **1Password**: No major publicized incidents
- **Bitwarden**: No major publicized incidents
- **LastPass**: 8+ documented security incidents (2011–2026)
- **Dashlane**: No major publicized incidents
- **Keeper**: No major publicized incidents

### Compliance
- **1Password**: SOC 2 Type 2
- **Bitwarden**: SOC 2, SOC 3, ISO 27001, HIPAA, GDPR
- **LastPass**: SOC 2 Type II, SOC 3, ISO 27001, BSI C5
- **Dashlane**: Zero-knowledge architecture, 8 security patents
- **Keeper**: SOC 2

### Developer Integration
- **1Password**: Best-in-class — CLI, SDKs (Python/JS/Go), SSH, secrets management, CI/CD
- **Bitwarden**: Good — open source, CLI, Secrets Manager (separate product)
- **LastPass**: Basic — API access
- **Dashlane**: Basic — API access
- **Keeper**: Basic — API access

---

## Decision Rationale

### Why 1Password Business over Bitwarden Enterprise?
- 1Password has superior developer tooling (SDKs, SSH, secrets management built-in)
- 1Password has better admin UX and onboarding experience
- Bitwarden is cheaper but requires more self-management
- 1Password's zero-knowledge architecture is battle-tested with no incidents

### Why not LastPass?
- Extensive security incident history is a disqualifier for a SaaS company needing SOC2 compliance
- 8+ documented breaches/incidents from 2011–2026

### Why not Dashlane?
- Most expensive option at $11/user/month ($6,600/year for 50 seats)
- No clear advantage over 1Password to justify 39% price premium

### Why not Keeper?
- Pricing not transparent — must contact sales
- Less developer-focused than 1Password
- No clear advantage to justify the uncertainty
