# ADR-001: Selection of 5 Password Managers for Evaluation

## Status
Accepted

## Context
We need to evaluate password managers for a 50-person engineering team at a Series-B SaaS company. The team currently uses shadow-IT password storage (browser, sticky notes, Slack DMs). The CTO wants this fixed in 90 days.

## Decision
We will evaluate the following 5 password managers:

1. **1Password** — Leading enterprise password manager with strong security posture
2. **Bitwarden** — Open-source, self-hostable option with growing enterprise features
3. **LastPass** — Well-known brand, though with recent security incidents
4. **Dashlane** — Consumer-friendly with enterprise features
5. **Keeper** — Long-standing enterprise security vendor

## Rationale
These 5 represent the major players in the team/enterprise password manager space:
- **1Password**: Widely regarded as the gold standard for security and UX
- **Bitwarden**: Open-source alternative that appeals to engineering teams
- **LastPass**: Market leader by user count, but with notable security history
- **Dashlane**: Strong competitor with good feature set
- **Keeper**: Enterprise-focused with long track record

We excluded:
- **Keeper** alternatives like RoboForm (niche, declining)
- **SSO products** (Okta, Auth0) — these are adjacent but not password managers
- **Secrets management** (HashiCorp Vault, AWS Secrets Manager) — different category
- **Browser-native** (Chrome Password Manager) — not a team solution

## Criteria for Evaluation
1. **Security**: Zero-knowledge architecture, encryption standards, audit history
2. **Compliance**: SOC2, FedRAMP, HIPAA certifications
3. **Pricing**: Per-seat cost for 50 users, annual billing
4. **Features**: SSO integration, audit logs, admin console, mobile/desktop coverage
5. **Developer Integration**: CLI tools, API access, CI/CD compatibility
6. **Vendor Risk**: Company stability, incident history, lock-in concerns
