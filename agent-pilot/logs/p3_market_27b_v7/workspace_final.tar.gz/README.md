# Password Manager Evaluation — Output Guide

## How to Read This Output

This directory contains the complete research and recommendation for selecting a password manager for a 50-person engineering team at a Series-B SaaS company.

### Primary Deliverable

- **`recommendation.md`** — The 1-2 page recommendation memo. Start here. It contains:
  - Decision criteria used for evaluation
  - Specific product + tier + pricing recommendation (1Password Business at $7.99/user/month)
  - Clear runner-up (Bitwarden Enterprise) with conditions under which it would win
  - Concerns and risks with the chosen product
  - 90-day implementation timeline

### Supporting Documents

- **`comparison.md`** — Side-by-side feature/pricing/security comparison of all 5 evaluated products:
  1. 1Password Business
  2. Bitwarden Teams / Enterprise
  3. LastPass Business
  4. Dashlane Business
  5. Keeper Business

- **`sources.md`** — Every URL fetched during research, with:
  - Timestamp of fetch
  - SHA-256 hash of page content at time of fetch
  - Brief description of what was obtained from each page

- **`research/notes.md`** — Working notes with raw findings, key data points, and decision rationale

- **`decisions/`** — ADR-style records for non-obvious calls:
  - `001-select-5-products.md` — Rationale for selecting the 5 products evaluated

### Quick Reference

| Product | Tier | Price/user/mo | 50 seats/year | Verdict |
|---------|------|---------------|---------------|---------|
| **1Password** | Business | $7.99 | $4,794 | **RECOMMENDED** |
| Bitwarden | Enterprise | $6.00 | $3,600 | Runner-up |
| LastPass | Business | $7.00 | $4,200 | Disqualified (security incidents) |
| Dashlane | Business | $11.00 | $6,600 | Too expensive |
| Keeper | Business | Not listed | Unknown | Pricing not transparent |

### Methodology

All factual claims are cited with numbered references linking to `sources.md`. Every numeric claim (pricing, feature counts, compliance certifications) was verified against the vendor's official website. Security incident history was cross-referenced with Wikipedia and independent sources.

Where pricing was not publicly available (Keeper), this is explicitly flagged rather than estimated.
