# Incident Summary — SLA Credit Review

**Incident Window:** 14:11 UTC to 18:24 UTC, Friday (approximately 4 hours 13 minutes).

**Scope of Impact:**
- 11,400 customer accounts were affected.
- 28 enterprise accounts (those with named customer success managers) experienced revenue impact during business hours.
- 4 accounts had documented downstream automation failures requiring manual remediation.
- 217 inbound support tickets were received.
- 31 refund requests have been submitted to date.

**Service Level Agreement:**
- Contractual SLA: 99.9% monthly uptime, with credits for breach.
- The SLA was nominally breached for the affected accounts during the incident window.
- The company's position is not to contest credit requests where the SLA was clearly breached.

**Credit Request Categories:**
1. **SLA-driven requests:** Accounts that can demonstrate the SLA threshold was breached. These should be processed per the contractual terms of the applicable MSA.
2. **Relationship-driven requests:** Accounts requesting credits on the basis of goodwill or perceived service quality, where the SLA was not demonstrably breached. These are not contractual obligations and should be handled case by case by finance and customer success.

**Known Downstream Harm:**
Four customers experienced documented downstream automation failures. In addition to standard SLA credits, the company is proposing complimentary data-cleanup support engagements for these four accounts.

**Refund Request Status:**
Of the 31 refund requests received, some are SLA-credit-only and others request full-month credit. Legal and finance are reviewing these individually.

**Recommendation:**
Process SLA-driven credit requests per contractual terms. Evaluate relationship-driven requests on a case-by-case basis through finance and customer success channels.
