# Incident Rewrite Output

This directory contains three audience-specific rewrites of an internal engineering memo documenting a ~4-hour API outage on Friday (14:11–18:24 UTC). Each rewrite is tailored to its target audience per the specifications in `/input/repo/audience_briefs.json`.

## Files

| File | Audience | Max Words | Actual Words |
|------|----------|-----------|-------------|
| `ceo_brief.md` | CEO / Board prep | 250 | 193 |
| `customer_email.md` | Affected customers (mass email) | 350 | 260 |
| `legal_summary.md` | In-house counsel (SLA review) | 400 | 254 |
| `decisions/adr-001-content-omissions.md` | ADR: rationale for content choices per audience | — | — |
| `research/notes.md` | Working notes: extracted facts and per-audience decisions | — | — |

## How to Read

Each rewrite uses only facts present in the source memo (`/input/repo/draft_memo.md`). No numbers, times, or customer counts were invented. The three rewrites differ in tone, content selection, and framing to match their respective audiences:

- **CEO brief:** Executive summary with board-level signal (second outage in 90 days), impact scope, and remediation status. No engineering jargon.
- **Customer email:** Warm, accountable tone. Plain-language root cause, explicit SLA credit offer, and commitments. No named individuals or internal board signals.
- **Legal summary:** Dispassionate, factual enumeration for SLA credit determination. Uses "incident" not "outage." No marketing language or engineering details.
