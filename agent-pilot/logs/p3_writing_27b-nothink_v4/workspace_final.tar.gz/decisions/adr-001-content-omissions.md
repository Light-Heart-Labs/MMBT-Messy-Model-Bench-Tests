# ADR-001: Content Omission Decisions by Audience

## Decision: What to omit from each rewrite

### CEO Brief
- **Omitted:** Named individuals (Marcus, Priya, Sarah). The CEO needs to know what happened and what's being done, not who did what.
- **Omitted:** Detailed technical explanation of the fraction-against-MAX mechanism. Replaced with plain-language description ("internal safeguard that blocked all authentication requests").
- **Omitted:** "Sorry Sarah" and other informal apologies.
- **Included:** The "second outage in 90 days" framing as required — this is the board signal the CEO needs to prepare for.
- **Included:** All four remediations, translated into business terms (sprints, weeks, already deployed).

### Customer Email
- **Omitted:** Named engineer (Marcus). No individual should be blamed in a customer-facing communication.
- **Omitted:** "Second outage in 90 days" framing. This is an internal board signal, not customer-facing information.
- **Omitted:** Internal candor about unaddressed warnings (Sarah's June warning). This would undermine customer confidence.
- **Omitted:** Engineering jargon (rate limiter, MAX, throttling internals). Root cause explained in plain language.
- **Included:** Explicit SLA credit offer with contact path (CSM or support).
- **Included:** All four remediation commitments, translated to customer-benefit language.

### Legal Summary
- **Omitted:** Named-employee blame. Irrelevant to SLA credit determination.
- **Omitted:** Engineering remediation details. Counsel does not need to know about sprint timelines or code fixes.
- **Omitted:** Speculation about future outages or reliability program overhaul.
- **Omitted:** Marketing language and informal candor.
- **Included:** Exact time window with timezone, account counts, tier breakdown, SLA threshold, downstream harm cases, and credit-request handling recommendation.
- **Used "incident" not "outage"** as specified in the tone requirements.
