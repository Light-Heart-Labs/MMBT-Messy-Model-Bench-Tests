# ADR-002: Handling Pre-existing Source Bugs

## Context

Three starter tests fail due to bugs in the source code:
1. `status_filter` doesn't convert string to int
2. `url_regex_filter` uses `re.match` (start-anchored) instead of `re.search`
3. `MONTH_NAMES` is missing "Jul" (July), causing cascading month index errors

## Decision

- Do NOT fix these bugs (out of scope — no production code changes)
- Do NOT modify the failing starter tests
- Document all bugs in `research/dead-ends.md`
- Write new tests that work around the bugs (use int status, anchored regex patterns, avoid July dates)
- Write tests that document the buggy behavior (e.g., `test_july_raises_value_error`)

## Rationale

The task explicitly states: "If you find a bug, document it but don't fix it (the test should pass against current behavior, even if that behavior is wrong)."

## Additional Bugs Found

During testing, I discovered additional bugs:
- `session_window()` has a logic error where the gap check uses `zip(evs, evs[1:])` but only appends `nxt` to `cur`, meaning `prev` is never in the session. This causes sessions to never split at the exact window boundary.
- `MONTH_NAMES` missing July causes Aug-Dec to have shifted month numbers (Aug→7, Sep→8, etc.)

These are documented in test docstrings and dead-ends.md.
