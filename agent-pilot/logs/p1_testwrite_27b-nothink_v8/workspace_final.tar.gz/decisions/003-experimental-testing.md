# ADR-003: Experimental Module Testing

## Context

`experimental.py` is marked as "experimental" and "not yet wired into the CLI."
It has 0% test coverage.

## Decision

Test both `detect_anomalies()` and `session_window()` thoroughly.

## Rationale

1. The code exists in the codebase and should be exercised
2. Testing documents current behavior and prevents silent regressions
3. The task explicitly says testing experimental code is fine for coverage goals
4. `session_window()` has a bug that we document in tests rather than fix

## Recommendation (for future work)

The `session_window()` function has a logic bug where sessions never split
at the exact window boundary. This should be fixed in a future PR. The bug
is in how `prev` and `nxt` are used from `zip(evs, evs[1:])` — `prev` is
never added to `cur`, only `nxt` is.
