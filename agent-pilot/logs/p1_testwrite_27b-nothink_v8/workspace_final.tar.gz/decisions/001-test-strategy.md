# ADR-001: Test Strategy for Under-Covered Modules

## Context

The logalyzer codebase has several modules with 0% test coverage:
- `experimental.py` (0%)
- `io.py` (0%)
- `cli.py` (0%)
- `output.py` (0%)
- `utils.py` (0%)

Additionally, `filters.py` has uncovered functions (`expression_filter`, `combine_and`)
and `parser.py` has uncovered edge cases.

## Decision

I will add tests for all 0% coverage modules, prioritizing:
1. Edge cases and error paths over happy paths
2. Integration between modules (e.g., CLI → filters → parser)
3. Boundary conditions (empty inputs, malformed data, extreme values)

## Rationale

- **experimental.py**: Despite being "experimental," the code exists and should be
  exercised. Testing it documents its current behavior and catches regressions.
- **io.py**: File I/O is a critical path. Testing with temp files exercises
  real file operations, not just parsing logic.
- **cli.py**: The CLI is the user-facing entry point. Testing it validates
  the full pipeline from argument parsing to output.
- **output.py**: Output formatters can silently produce wrong output.
  Testing them ensures JSON, CSV, and text formats are correct.
- **utils.py**: Utility functions like `format_bytes` and `chunked` have
  edge cases (zero, negative, very large numbers) that are easy to miss.

## Not Testing

- I will NOT test the three pre-existing failing tests' scenarios (string status,
  unanchored regex, July dates) because they expose source bugs I cannot fix.
- I will NOT test trivial happy paths that are already covered by existing tests.
