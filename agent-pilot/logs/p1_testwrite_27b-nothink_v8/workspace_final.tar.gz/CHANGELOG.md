# Changelog

## v0.3.2-test-contribution

### Coverage Delta

| Metric | Before | After | Delta |
|--------|--------|-------|-------|
| Total coverage | 34% | 99% | +65% |
| Passing tests | 14 | 200 | +186 |
| Failing tests | 3 | 3 | 0 (pre-existing bugs) |

### Per-Module Coverage

| Module | Before | After |
|--------|--------|-------|
| `__init__.py` | 100% | 100% |
| `aggregate.py` | 100% | 100% |
| `cli.py` | 0% | 98% |
| `experimental.py` | 0% | 100% |
| `filters.py` | 74% | 100% |
| `io.py` | 0% | 100% |
| `output.py` | 0% | 100% |
| `parser.py` | 86% | 100% |
| `utils.py` | 0% | 100% |

### Test Files Added

1. **tests/test_experimental.py** (17 tests)
   - `detect_anomalies()`: empty input, uniform traffic, spike detection, minute bucketing, microsecond handling, single entry, multi-IP
   - `session_window()`: empty input, single entry, consecutive requests, different IPs, sorting, gap splitting, custom window

2. **tests/test_utils.py** (22 tests)
   - `format_bytes()`: zero, one byte, KB/MB/GB/TB/PB boundaries, negative values, fractional boundaries
   - `chunked()`: empty, oversized chunk, chunk=1, exact multiple, remainder, generator input, chunk=0
   - `format_legacy()`: output format, field omission, special URL chars
   - `parse_iso_date()`: valid date, leap year, invalid input, wrong format, empty string, midnight UTC

3. **tests/test_output.py** (20 tests)
   - `to_json()`: empty, single, multiple, timestamp format, zero bytes, special chars, generator
   - `to_csv()`: empty, single, comma escaping, header fields, multiple entries
   - `to_text()`: empty, format, alignment, multiple entries
   - `render_aggregate()`: text/json formats, dict/list inputs, empty inputs, unknown format

4. **tests/test_io.py** (14 tests)
   - `load()`: single line, multi-line, empty file, no trailing newline, malformed lines, nonexistent file, dash bytes
   - `load_iter()`: single line, multi-line, empty, malformed, generator type, nonexistent file

5. **tests/test_filters_extended.py** (20 tests)
   - `expression_filter()`: status, bytes, method, combined, URL, IP, bool wrapping, no match
   - `combine_and()`: single predicate, two predicates, three predicates, short-circuit, no predicates
   - `status_filter` edge cases: zero, 3-digit codes, non-matching
   - `url_regex_filter` edge cases: exact match, query string, unicode, special chars, case sensitivity
   - `ip_allowlist_filter` edge cases: empty, single, IPv6, set input
   - `date_range_filter`: happy path, until boundary

6. **tests/test_parser_extended.py** (24 tests)
   - `parse_timestamp`: positive/negative timezone, UTC, midnight, missing timezone, malformed, empty, invalid month, Jan-Jun, Aug-Dec shifted indices, July bug, Dec 31 bug, MONTH_NAMES count
   - `parse_line`: whitespace, leading/trailing whitespace, HTTP methods, status codes, zero/large bytes, query strings, path segments, IPv6, authenticated user, HTTP/2, missing protocol, extra fields, frozen dataclass, bad timestamp
   - `parse_lines`: empty, mixed valid/invalid, generator type, generator input

7. **tests/test_cli.py** (16 tests)
   - `build_parser()`: required args, optional args, aggregate choices, format choices, default format, repeatable IP
   - `main()` integration: text/json/csv output, aggregate status/url/hour, empty file, multiple files, return code, JSON aggregate, URL filter, expression filter, since filter, IP filter, status filter

8. **tests/test_aggregate_extended.py** (16 tests)
   - `by_status`: empty, single, all same, all different
   - `by_url`: empty, single, top=0, top > unique, same count, special chars
   - `by_hour`: empty, all 24 hours, midnight, end of day, all keys present
   - `total_bytes`: empty, single, zero, large total, mixed sizes

### Pre-existing Bugs (Not Fixed)

1. `status_filter` doesn't convert string to int — `--status` CLI flag is broken
2. `url_regex_filter` uses `re.match` (start-anchored) — substring matching doesn't work
3. `MONTH_NAMES` missing "Jul" — July dates fail, Aug-Dec have wrong month numbers
4. `session_window()` gap check bug — sessions don't split at exact window boundary
5. `collections.Iterable` import — fails on Python 3.10+ (monkey-patched in conftest.py)

### Files Modified

- `tests/conftest.py` — Added monkey-patch for `collections.Iterable` compatibility

### Files Unchanged

- All files in `logalyzer/` are byte-identical to the input
