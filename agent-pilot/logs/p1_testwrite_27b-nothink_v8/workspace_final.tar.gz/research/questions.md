# Questions

## 1. Should I test `cli.py`?

The CLI module has 0% coverage. It's an argparse wrapper that delegates to
other modules. Testing it would require mocking `sys.argv` or calling
`main()` with argv arguments. I chose to test it via `main(argv=...)`
with temporary log files, which exercises the full integration path.

## 2. Should I test `io.py`?

The `io.py` module has 0% coverage. It reads files and delegates to `parse_line`.
I test it with temporary files to exercise file I/O paths.

## 3. The `collections.Iterable` import bug

The source code imports `Iterable` from `collections` (deprecated since 3.3,
removed in 3.10+). I monkey-patch this in `conftest.py` so tests can run.
This is a workaround, not a fix — the source code remains unchanged.

## 4. Should I test `format_legacy()` in `utils.py`?

Yes — it's explicitly called out as uncovered. It's a simple formatter,
but testing it ensures the legacy path works and documents its output format.

## 5. `experimental.py` — test or not?

The file is marked "experimental" and "not yet wired into the CLI."
The task says testing it is fine if the goal is increasing coverage.
I test both `detect_anomalies()` and `session_window()` to exercise
the code paths and document their behavior.
