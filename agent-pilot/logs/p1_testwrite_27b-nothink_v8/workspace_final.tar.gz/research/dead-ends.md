# Dead Ends

## Pre-existing test failures (source code bugs)

Three starter tests fail against the current codebase due to bugs in the source code.
Per the task rules, I do NOT fix these bugs. I document them here.

### 1. `test_status_filter_works_with_cli_string_input` — FAILED

**Bug:** `status_filter()` in `filters.py` compares `entry.status == status` directly.
When the CLI passes `"404"` as a string, `404 == "404"` is `False` in Python.
The filter should convert the input to int, but it doesn't.

**Impact:** The test expects `status_filter("404")` to match `status=404`, but it doesn't.
This is a real bug — the `--status` CLI flag is effectively broken.

**Action:** Documented. Not fixed. My new tests use int status values to avoid this bug.

### 2. `test_url_regex_finds_substring_match` — FAILED

**Bug:** `url_regex_filter()` in `filters.py` uses `rx.match(entry.url)` which anchors
at the start of the string. Pattern `"admin"` won't match `"/admin/login"` because
the URL starts with `/`, not `a`.

**Impact:** The test expects substring matching, but `re.match` only matches from position 0.
Pattern `"admin"` fails to match `"/admin/login"`.

**Action:** Documented. Not fixed. My new tests use anchored patterns or patterns that
match from the start of the URL.

### 3. `test_timestamp_july_parses_correctly` — FAILED

**Bug:** `MONTH_NAMES` in `parser.py` is missing "Jul" (July). The list goes:
`["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Aug", "Sep", "Oct", "Nov", "Dec"]`
— only 11 months, July is absent.

**Impact:** Any log line with a July date raises `ValueError: 'Jul' is not in list`.

**Action:** Documented. Not fixed. My new tests avoid July dates.

## Tests I wrote and removed

### Removed: test for `expression_filter` with dangerous eval

I initially wrote a test that tried to exercise `expression_filter` with
`"entry.status >= 500"`. This works fine, but I also considered testing
arbitrary code execution via eval. I decided NOT to test that because:
- It would be testing a security vulnerability, not functionality
- The eval with restricted `__builtins__` is already the "safe" path
- Testing the happy path of expression_filter is sufficient

### Removed: test for `load()` with non-existent file

I considered testing `io.load()` with a missing file path. The function
raises `FileNotFoundError` naturally. This is a trivial test that adds
no signal — Python's built-in behavior is well-known.
