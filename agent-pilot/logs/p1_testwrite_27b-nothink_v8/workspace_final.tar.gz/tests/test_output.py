"""Tests for output.py — JSON, CSV, text, and aggregate renderers.

Targets: to_json (special chars, empty), to_csv (escaping), to_text (formatting),
render_aggregate (all formats, edge cases).
"""
import pytest

from logalyzer.output import (
    render_aggregate,
    to_csv,
    to_json,
    to_text,
)
from logalyzer.parser import LogEntry
from datetime import datetime, timezone


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


class TestToJson:
    """Test JSON output formatting."""

    def test_empty_entries(self):
        """Empty input produces empty JSON array."""
        assert to_json([]) == "[]"

    def test_single_entry(self):
        """Single entry produces a JSON array with one object."""
        entries = [_entry()]
        result = to_json(entries)
        assert result.startswith("[")
        assert result.endswith("]")
        assert '"ip":"10.0.0.1"' in result
        assert '"status":200' in result
        assert '"bytes":100' in result

    def test_multiple_entries(self):
        """Multiple entries are comma-separated in the JSON array."""
        entries = [_entry(status=200), _entry(status=404)]
        result = to_json(entries)
        assert '"status":200' in result
        assert '"status":404' in result

    def test_timestamp_isoformat(self):
        """Timestamp is rendered as ISO format string."""
        entries = [_entry()]
        result = to_json(entries)
        assert "2026-01-01T12:00:00+00:00" in result

    def test_zero_bytes(self):
        """Zero bytes is rendered as 0, not '-'."""
        entries = [_entry(bytes=0)]
        result = to_json(entries)
        assert '"bytes":0' in result

    def test_url_with_special_chars(self):
        """URLs with special characters are included as-is (no escaping in hand-built JSON)."""
        entries = [_entry(url="/search?q=test")]
        result = to_json(entries)
        assert '/search?q=test' in result

    def test_generator_input(self):
        """to_json works with generator input (consumes the iterable)."""
        def gen():
            yield _entry(status=200)
            yield _entry(status=404)
        result = to_json(gen())
        assert '"status":200' in result
        assert '"status":404' in result


class TestToCsv:
    """Test CSV output formatting."""

    def test_empty_entries(self):
        """Empty input produces only the header row."""
        result = to_csv([])
        assert "ip,user,timestamp,method,url,protocol,status,bytes" in result
        lines = result.strip().split('\n')
        assert len(lines) == 1

    def test_single_entry(self):
        """Single entry produces header + one data row."""
        entries = [_entry()]
        result = to_csv(entries)
        lines = result.strip().split('\n')
        assert len(lines) == 2
        assert "10.0.0.1" in lines[1]

    def test_csv_escaping_comma_in_url(self):
        """URLs with commas are properly quoted by csv.writer."""
        entries = [_entry(url="/path,a,b")]
        result = to_csv(entries)
        # csv.writer should quote fields containing commas
        assert '"/path,a,b"' in result or "/path,a,b" in result

    def test_csv_header_fields(self):
        """CSV header contains all expected fields."""
        result = to_csv([])
        header = result.strip().split('\n')[0]
        expected = ["ip", "user", "timestamp", "method", "url", "protocol", "status", "bytes"]
        for field in expected:
            assert field in header

    def test_multiple_entries(self):
        """Multiple entries produce multiple data rows."""
        entries = [_entry(status=200), _entry(status=404), _entry(status=500)]
        result = to_csv(entries)
        lines = result.strip().split('\n')
        assert len(lines) == 4  # header + 3 data rows


class TestToText:
    """Test plain text output formatting."""

    def test_empty_entries(self):
        """Empty input produces empty string."""
        assert to_text([]) == ""

    def test_single_entry_format(self):
        """Single entry is formatted as: timestamp  ip  method status url."""
        entries = [_entry()]
        result = to_text(entries)
        assert "2026-01-01T12:00:00+00:00" in result
        assert "10.0.0.1" in result
        assert "GET" in result
        assert "200" in result
        assert "/" in result

    def test_ip_right_aligned(self):
        """IP addresses are right-aligned in a 15-char field."""
        entries = [_entry(ip="1.1.1.1"), _entry(ip="192.168.1.100")]
        result = to_text(entries)
        lines = result.split('\n')
        # Both lines should have the IP right-aligned
        assert "1.1.1.1" in lines[0]
        assert "192.168.1.100" in lines[1]

    def test_method_left_aligned(self):
        """HTTP method is left-aligned in a 6-char field."""
        entries = [_entry(method="GET"), _entry(method="POST")]
        result = to_text(entries)
        assert "GET" in result
        assert "POST" in result

    def test_multiple_entries_newline_separated(self):
        """Multiple entries are separated by newlines."""
        entries = [_entry(status=200), _entry(status=404)]
        result = to_text(entries)
        lines = result.split('\n')
        assert len(lines) == 2


class TestRenderAggregate:
    """Test aggregate result rendering in text/json/csv formats."""

    def test_text_format_with_dict(self):
        """Dict-like aggregate rendered as key\tvalue lines."""
        agg = {"200": 10, "404": 3, "500": 1}
        result = render_aggregate(agg, fmt="text")
        assert "200\t10" in result
        assert "404\t3" in result

    def test_text_format_with_list_of_tuples(self):
        """List of tuples rendered as key\tvalue lines."""
        agg = [("/a", 5), ("/b", 3)]
        result = render_aggregate(agg, fmt="text")
        assert "/a\t5" in result
        assert "/b\t3" in result

    def test_json_format_with_dict(self):
        """Dict-like aggregate rendered as JSON object."""
        agg = {"200": 10, "404": 3}
        result = render_aggregate(agg, fmt="json")
        assert '"200":10' in result
        assert '"404":3' in result

    def test_json_format_with_list_of_tuples(self):
        """List of tuples rendered as JSON object."""
        agg = [("/a", 5), ("/b", 3)]
        result = render_aggregate(agg, fmt="json")
        assert '"/a":5' in result
        assert '"/b":3' in result

    def test_empty_dict_text(self):
        """Empty dict produces empty string."""
        result = render_aggregate({}, fmt="text")
        assert result == ""

    def test_empty_list_text(self):
        """Empty list produces empty string."""
        result = render_aggregate([], fmt="text")
        assert result == ""

    def test_unknown_format_raises_value_error(self):
        """Unknown format raises ValueError."""
        with pytest.raises(ValueError, match="unknown format"):
            render_aggregate({"a": 1}, fmt="xml")

    def test_csv_format_raises_or_delegates(self):
        """The CLI maps csv format to text for aggregates (see cli.py).
        But render_aggregate itself doesn't handle 'csv' — it falls through
        to the else clause and raises ValueError."""
        with pytest.raises(ValueError, match="unknown format"):
            render_aggregate({"a": 1}, fmt="csv")
