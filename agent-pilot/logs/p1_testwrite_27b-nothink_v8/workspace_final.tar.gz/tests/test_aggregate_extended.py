"""Extended tests for aggregate.py — edge cases and boundary conditions.

Targets: empty inputs, single entries, by_hour with timezone edge cases,
by_url with top=0, total_bytes with zero entries.
"""
from datetime import datetime, timezone

from logalyzer.aggregate import by_hour, by_status, by_url, total_bytes
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


class TestByStatusEdgeCases:
    """Edge cases for by_status aggregation."""

    def test_empty_entries(self):
        """Empty input produces empty Counter."""
        result = by_status([])
        assert len(result) == 0

    def test_single_entry(self):
        """Single entry produces one count."""
        result = by_status([_entry(status=200)])
        assert result[200] == 1
        assert len(result) == 1

    def test_all_same_status(self):
        """All entries with the same status."""
        entries = [_entry(status=200) for _ in range(100)]
        result = by_status(entries)
        assert result[200] == 100
        assert len(result) == 1

    def test_all_different_statuses(self):
        """Each entry has a different status."""
        entries = [_entry(status=s) for s in [200, 301, 404, 500]]
        result = by_status(entries)
        assert len(result) == 4
        for s in [200, 301, 404, 500]:
            assert result[s] == 1


class TestByUrlEdgeCases:
    """Edge cases for by_url aggregation."""

    def test_empty_entries(self):
        """Empty input produces empty list."""
        result = by_url([])
        assert result == []

    def test_single_entry(self):
        """Single entry produces one URL count."""
        result = by_url([_entry(url="/test")])
        assert result == [("/test", 1)]

    def test_top_zero(self):
        """top=0 returns empty list."""
        entries = [_entry(url=f"/u{i}") for i in range(10)]
        result = by_url(entries, top=0)
        assert result == []

    def test_top_larger_than_unique_urls(self):
        """top=N where N > number of unique URLs returns all."""
        entries = [_entry(url="/a"), _entry(url="/b")]
        result = by_url(entries, top=100)
        assert len(result) == 2

    def test_urls_with_same_count_sorted_consistently(self):
        """URLs with the same count are returned in a consistent order."""
        entries = [_entry(url="/b"), _entry(url="/a")]
        result = by_url(entries)
        # Both have count 1; order may vary but both should be present
        urls = [url for url, count in result]
        assert "/a" in urls
        assert "/b" in urls

    def test_url_with_special_characters(self):
        """URLs with special characters are counted correctly."""
        entries = [
            _entry(url="/search?q=a"),
            _entry(url="/search?q=a"),
            _entry(url="/search?q=b"),
        ]
        result = by_url(entries)
        assert len(result) == 2
        assert ("/search?q=a", 2) in result
        assert ("/search?q=b", 1) in result


class TestByHourEdgeCases:
    """Edge cases for by_hour aggregation."""

    def test_empty_entries(self):
        """Empty input produces all-zero buckets."""
        result = by_hour([])
        assert len(result) == 24
        assert all(v == 0 for v in result.values())

    def test_all_24_hours(self):
        """Entries in all 24 hours."""
        entries = [_entry(timestamp=datetime(2026, 1, 1, h, 0, 0, tzinfo=timezone.utc)) for h in range(24)]
        result = by_hour(entries)
        for h in range(24):
            assert result[h] == 1

    def test_midnight_bucket(self):
        """Entries at midnight go into hour 0."""
        entries = [_entry(timestamp=datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc))]
        result = by_hour(entries)
        assert result[0] == 1

    def test_end_of_day_bucket(self):
        """Entries at 23:59 go into hour 23."""
        entries = [_entry(timestamp=datetime(2026, 1, 1, 23, 59, 59, tzinfo=timezone.utc))]
        result = by_hour(entries)
        assert result[23] == 1

    def test_by_hour_returns_dict_with_all_24_keys(self):
        """by_hour always returns a dict with keys 0-23, even if some have 0 count."""
        entries = [_entry(timestamp=datetime(2026, 1, 1, 5, 0, 0, tzinfo=timezone.utc))]
        result = by_hour(entries)
        assert set(result.keys()) == set(range(24))
        assert result[5] == 1
        assert result[0] == 0


class TestTotalBytesEdgeCases:
    """Edge cases for total_bytes aggregation."""

    def test_empty_entries(self):
        """Empty input produces 0 total bytes."""
        assert total_bytes([]) == 0

    def test_single_entry(self):
        """Single entry returns its byte count."""
        assert total_bytes([_entry(bytes=500)]) == 500

    def test_zero_byte_entries(self):
        """All entries with 0 bytes."""
        entries = [_entry(bytes=0) for _ in range(10)]
        assert total_bytes(entries) == 0

    def test_large_total(self):
        """Large total byte count."""
        entries = [_entry(bytes=10**9) for _ in range(10)]
        assert total_bytes(entries) == 10 * 10**9

    def test_mixed_byte_sizes(self):
        """Mixed byte sizes sum correctly."""
        entries = [_entry(bytes=100), _entry(bytes=200), _entry(bytes=300)]
        assert total_bytes(entries) == 600
