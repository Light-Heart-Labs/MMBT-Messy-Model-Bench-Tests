"""Tests for experimental.py — anomaly detection and session windowing.

These tests exercise the 0%-coverage experimental module, documenting its
current behavior. The module is marked "experimental" but exists in the
codebase and should be tested to prevent silent regressions.
"""
from datetime import datetime, timezone

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1", **kw):
    """Helper to create a LogEntry with a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
        **kw,
    )


class TestDetectAnomalies:
    """Test z-score anomaly detection over per-minute request counts."""

    def test_empty_entries_returns_empty_list(self):
        """No entries → no anomalies."""
        assert detect_anomalies([]) == []

    def test_uniform_traffic_no_anomalies(self):
        """When all minutes have the same count, no anomalies are detected."""
        entries = [_entry(datetime(2026, 1, 1, 12, i, 0, tzinfo=timezone.utc)) for i in range(10)]
        result = detect_anomalies(entries)
        assert result == []

    def test_spike_detected_as_anomaly(self):
        """A minute with many more requests than others should be flagged."""
        # 9 minutes with 1 request each, 1 minute with 60 requests
        entries = [_entry(datetime(2026, 1, 1, 12, i, 0, tzinfo=timezone.utc)) for i in range(9)]
        # Add 60 entries in minute 10 (one per second, 0-59)
        entries += [_entry(datetime(2026, 1, 1, 12, 10, s, tzinfo=timezone.utc)) for s in range(60)]
        result = detect_anomalies(entries)
        spike_minute = datetime(2026, 1, 1, 12, 10, 0, tzinfo=timezone.utc)
        assert spike_minute in result

    def test_seconds_are_bucketed_to_minute(self):
        """Entries within the same minute (different seconds) are bucketed together."""
        entries = [
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 0, 30, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 0, 59, tzinfo=timezone.utc)),
        ]
        result = detect_anomalies(entries)
        assert result == []

    def test_microseconds_are_bucketed_to_minute(self):
        """Microseconds are stripped when bucketing."""
        entries = [
            _entry(datetime(2026, 1, 1, 12, 0, 0, 0, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 0, 0, 999999, tzinfo=timezone.utc)),
        ]
        result = detect_anomalies(entries)
        assert result == []

    def test_single_entry_no_anomaly(self):
        """A single entry cannot be anomalous (std=0, threshold=count)."""
        entries = [_entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))]
        result = detect_anomalies(entries)
        assert result == []

    def test_returns_datetime_objects_not_strings(self):
        """Anomaly buckets are datetime objects, not strings."""
        entries = [_entry(datetime(2026, 1, 1, 12, i, 0, tzinfo=timezone.utc)) for i in range(5)]
        entries += [_entry(datetime(2026, 1, 1, 12, 5, s, tzinfo=timezone.utc)) for s in range(50)]
        result = detect_anomalies(entries)
        if result:
            assert all(isinstance(b, datetime) for b in result)

    def test_multiple_ips_same_minute_bucketed_together(self):
        """Anomaly detection is global, not per-IP."""
        entries = [
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc), ip="10.0.0.1"),
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc), ip="10.0.0.2"),
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc), ip="10.0.0.3"),
        ]
        result = detect_anomalies(entries)
        assert result == []


class TestSessionWindow:
    """Test session grouping by IP with inactivity timeout.

    NOTE: session_window() has a bug where it compares consecutive entries
    from the sorted list (using zip(evs, evs[1:])) but only appends to cur
    using the nxt entry. This means the gap check uses the wrong pair of
    entries. The function effectively never splits sessions because prev
    and nxt are always adjacent in the sorted list, but cur only gets nxt.
    We test the actual behavior, not the intended behavior.
    """

    def test_empty_entries_returns_empty_sessions(self):
        """No entries → no sessions."""
        assert session_window([]) == []

    def test_single_entry_one_session(self):
        """A single entry forms one session."""
        entries = [_entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))]
        result = session_window(entries)
        assert len(result) == 1
        ip, session_entries = result[0]
        assert ip == "10.0.0.1"
        assert len(session_entries) == 1

    def test_same_ip_consecutive_requests_one_session(self):
        """Requests from the same IP within the window form one session."""
        entries = [
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 5, 0, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 10, 0, tzinfo=timezone.utc)),
        ]
        result = session_window(entries)
        assert len(result) == 1
        ip, session_entries = result[0]
        assert ip == "10.0.0.1"
        assert len(session_entries) == 3

    def test_different_ips_separate_sessions(self):
        """Different IPs get separate sessions."""
        entries = [
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc), ip="10.0.0.1"),
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc), ip="10.0.0.2"),
        ]
        result = session_window(entries)
        assert len(result) == 2

    def test_entries_sorted_by_timestamp_within_session(self):
        """Entries within a session are sorted by timestamp."""
        entries = [
            _entry(datetime(2026, 1, 1, 12, 5, 0, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 3, 0, tzinfo=timezone.utc)),
        ]
        result = session_window(entries)
        ip, session_entries = result[0]
        timestamps = [e.timestamp for e in session_entries]
        assert timestamps == sorted(timestamps)

    def test_session_window_bug_gap_check_uses_zip_not_cur(self):
        """Document the session_window bug: gap check uses zip(evs, evs[1:])
        but only appends nxt to cur, so prev is never in cur. This means
        the gap check compares adjacent sorted entries but the session
        building is incorrect. We test the actual behavior.

        With 3 entries at t=0, t=5min, t=35min (30min gap > 1800s window):
        - zip produces (t=0, t=5min) and (t=5min, t=35min)
        - gap between t=5min and t=35min is 1800s, which is NOT > 1800
        - So no split occurs, all 3 entries in one session
        """
        entries = [
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 5, 0, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 35, 0, tzinfo=timezone.utc)),
        ]
        result = session_window(entries)
        # Due to the bug, gap is exactly 1800 which is NOT > 1800
        # So all entries remain in one session
        assert len(result) == 1
        assert len(result[0][1]) == 3

    def test_session_window_with_large_gap_splits(self):
        """A gap significantly larger than the window does split sessions.

        With entries at t=0 and t=40min (2400s > 1800s window),
        the gap check compares these two adjacent entries and 2400 > 1800.
        """
        entries = [
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 40, 0, tzinfo=timezone.utc)),
        ]
        result = session_window(entries)
        # Gap is 2400s > 1800s, so this should split
        assert len(result) == 2

    def test_custom_window_seconds(self):
        """Custom window_seconds parameter is respected."""
        entries = [
            _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)),
            _entry(datetime(2026, 1, 1, 12, 2, 0, tzinfo=timezone.utc)),
        ]
        # 120-second gap with 60-second window: 120 > 60, should split
        result = session_window(entries, window_seconds=60)
        assert len(result) == 2
