"""Tests for io.py — file loading with real file I/O.

Targets: load() and load_iter() with temporary files, empty files,
malformed lines, files without trailing newlines.
"""
import os
import tempfile

import pytest

from logalyzer.io import load, load_iter


def _clf_line(ip="127.0.0.1", user="-", method="GET", url="/", status=200, bytes_sent=100):
    """Generate a valid CLF log line."""
    return (
        f'{ip} {user} - [01/Jan/2026:12:00:00 +0000] '
        f'"{method} {url} HTTP/1.1" {status} {bytes_sent}'
    )


class TestLoad:
    """Test load() — reads entire file at once."""

    def test_load_single_line_file(self):
        """A file with one valid log line produces one entry."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write(_clf_line() + "\n")
            path = f.name
        try:
            entries = load(path)
            assert len(entries) == 1
            assert entries[0].ip == "127.0.0.1"
        finally:
            os.unlink(path)

    def test_load_multi_line_file(self):
        """A file with multiple valid log lines."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write(_clf_line(status=200) + "\n")
            f.write(_clf_line(status=404) + "\n")
            f.write(_clf_line(status=500) + "\n")
            path = f.name
        try:
            entries = load(path)
            assert len(entries) == 3
            assert entries[0].status == 200
            assert entries[1].status == 404
            assert entries[2].status == 500
        finally:
            os.unlink(path)

    def test_load_empty_file(self):
        """An empty file produces no entries."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write("")
            path = f.name
        try:
            entries = load(path)
            assert entries == []
        finally:
            os.unlink(path)

    def test_load_file_without_trailing_newline(self):
        """A file whose last line has no trailing newline is still parsed."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write(_clf_line(status=200) + "\n")
            f.write(_clf_line(status=404))  # No trailing newline
            path = f.name
        try:
            entries = load(path)
            assert len(entries) == 2
            assert entries[1].status == 404
        finally:
            os.unlink(path)

    def test_load_file_with_malformed_lines(self):
        """Malformed lines are silently skipped."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write(_clf_line(status=200) + "\n")
            f.write("this is garbage\n")
            f.write(_clf_line(status=404) + "\n")
            f.write("\n")  # Empty line
            path = f.name
        try:
            entries = load(path)
            assert len(entries) == 2
            assert entries[0].status == 200
            assert entries[1].status == 404
        finally:
            os.unlink(path)

    def test_load_file_with_only_malformed_lines(self):
        """A file with only garbage produces no entries."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write("garbage line 1\n")
            f.write("garbage line 2\n")
            path = f.name
        try:
            entries = load(path)
            assert entries == []
        finally:
            os.unlink(path)

    def test_load_nonexistent_file_raises_file_not_found(self):
        """Loading a non-existent file raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            load("/tmp/does_not_exist_12345.log")

    def test_load_file_with_dash_bytes(self):
        """Lines with '-' for bytes are parsed as 0."""
        line = '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" 304 -'
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write(line + "\n")
            path = f.name
        try:
            entries = load(path)
            assert len(entries) == 1
            assert entries[0].bytes == 0
        finally:
            os.unlink(path)


class TestLoadIter:
    """Test load_iter() — generator-based file loading."""

    def test_load_iter_single_line(self):
        """Generator yields one entry for one valid line."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write(_clf_line() + "\n")
            path = f.name
        try:
            entries = list(load_iter(path))
            assert len(entries) == 1
        finally:
            os.unlink(path)

    def test_load_iter_multi_line(self):
        """Generator yields entries for all valid lines."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            for i in range(5):
                f.write(_clf_line(status=200 + i * 100) + "\n")
            path = f.name
        try:
            entries = list(load_iter(path))
            assert len(entries) == 5
        finally:
            os.unlink(path)

    def test_load_iter_empty_file(self):
        """Generator yields nothing for empty file."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write("")
            path = f.name
        try:
            entries = list(load_iter(path))
            assert entries == []
        finally:
            os.unlink(path)

    def test_load_iter_skips_malformed(self):
        """Generator skips malformed lines."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write(_clf_line() + "\n")
            f.write("garbage\n")
            f.write(_clf_line() + "\n")
            path = f.name
        try:
            entries = list(load_iter(path))
            assert len(entries) == 2
        finally:
            os.unlink(path)

    def test_load_iter_is_a_generator(self):
        """load_iter returns a generator, not a list."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            f.write(_clf_line() + "\n")
            path = f.name
        try:
            result = load_iter(path)
            assert hasattr(result, "__iter__")
            assert hasattr(result, "__next__")
        finally:
            os.unlink(path)

    def test_load_iter_nonexistent_file_raises(self):
        """Loading a non-existent file raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            list(load_iter("/tmp/does_not_exist_12345.log"))
