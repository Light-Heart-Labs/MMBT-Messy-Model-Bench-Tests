"""Tests for filters.py — uncovered functions and edge cases.

Targets: expression_filter, combine_and, and edge cases for existing filters.
Note: We avoid the two pre-existing failing test scenarios (string status,
unanchored regex) documented in dead-ends.md.
"""

from logalyzer.filters import (
    combine_and,
    expression_filter,
    ip_allowlist_filter,
    status_filter,
    url_regex_filter,
)
from logalyzer.parser import LogEntry
from datetime import datetime, timezone


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


class TestExpressionFilter:
    """Test expression_filter — Python expression evaluation on LogEntry."""

    def test_status_expression(self):
        """Expression filtering by status code."""
        pred = expression_filter("entry.status >= 400")
        assert pred(_entry(status=404)) is True
        assert pred(_entry(status=200)) is False

    def test_bytes_expression(self):
        """Expression filtering by bytes."""
        pred = expression_filter("entry.bytes > 50")
        assert pred(_entry(bytes=100)) is True
        assert pred(_entry(bytes=10)) is False

    def test_method_expression(self):
        """Expression filtering by HTTP method."""
        pred = expression_filter("entry.method == 'POST'")
        assert pred(_entry(method="POST")) is True
        assert pred(_entry(method="GET")) is False

    def test_combined_expression(self):
        """Expression with multiple conditions."""
        pred = expression_filter("entry.status >= 400 and entry.method == 'GET'")
        assert pred(_entry(status=404, method="GET")) is True
        assert pred(_entry(status=404, method="POST")) is False
        assert pred(_entry(status=200, method="GET")) is False

    def test_url_expression(self):
        """Expression filtering by URL."""
        pred = expression_filter("'admin' in entry.url")
        assert pred(_entry(url="/admin/login")) is True
        assert pred(_entry(url="/index.html")) is False

    def test_ip_expression(self):
        """Expression filtering by IP."""
        pred = expression_filter("entry.ip.startswith('10.')")
        assert pred(_entry(ip="10.0.0.1")) is True
        assert pred(_entry(ip="192.168.1.1")) is False

    def test_expression_returns_bool(self):
        """Expression filter always returns a bool (wrapped in bool())."""
        pred = expression_filter("entry.status")
        # entry.status is 200 (truthy), bool(200) is True
        assert pred(_entry(status=200)) is True
        # entry.status is 0 (falsy), bool(0) is False
        assert pred(_entry(status=0)) is False

    def test_expression_with_no_match(self):
        """Expression that always evaluates to False."""
        pred = expression_filter("entry.status == 99999")
        assert pred(_entry(status=200)) is False


class TestCombineAnd:
    """Test combine_and — AND combination of predicates."""

    def test_single_predicate(self):
        """A single predicate passes through unchanged."""
        pred = combine_and(status_filter(200))
        assert pred(_entry(status=200)) is True
        assert pred(_entry(status=404)) is False

    def test_two_predicates_both_true(self):
        """Two predicates both matching returns True."""
        pred = combine_and(
            status_filter(200),
            expression_filter("entry.method == 'GET'"),
        )
        assert pred(_entry(status=200, method="GET")) is True

    def test_two_predicates_one_false(self):
        """Two predicates where one fails returns False."""
        pred = combine_and(
            status_filter(200),
            expression_filter("entry.method == 'POST'"),
        )
        assert pred(_entry(status=200, method="GET")) is False

    def test_three_predicates(self):
        """Three predicates all matching."""
        pred = combine_and(
            status_filter(200),
            expression_filter("entry.method == 'GET'"),
            expression_filter("entry.bytes > 50"),
        )
        assert pred(_entry(status=200, method="GET", bytes=100)) is True

    def test_short_circuit_evaluation(self):
        """combine_and short-circuits on first False predicate."""
        call_count = [0]

        def counting_pred(entry):
            call_count[0] += 1
            return True

        def failing_pred(entry):
            return False

        pred = combine_and(failing_pred, counting_pred, counting_pred)
        pred(_entry())
        # Only the first predicate should be called (short-circuit)
        assert call_count[0] == 0

    def test_no_predicates_always_true(self):
        """No predicates — all entries pass (vacuous truth)."""
        pred = combine_and()
        assert pred(_entry(status=200)) is True
        assert pred(_entry(status=404)) is True


class TestStatusFilterEdgeCases:
    """Edge cases for status_filter (avoiding the string bug)."""

    def test_status_filter_with_zero(self):
        """Status code 0 (unusual but valid)."""
        pred = status_filter(0)
        assert pred(_entry(status=0)) is True
        assert pred(_entry(status=200)) is False

    def test_status_filter_with_3_digit_codes(self):
        """Various 3-digit status codes."""
        for code in [100, 201, 301, 403, 404, 500, 502, 503]:
            pred = status_filter(code)
            assert pred(_entry(status=code)) is True
            assert pred(_entry(status=200)) is False

    def test_status_filter_does_not_match_different_code(self):
        """Status filter is exact match, not prefix."""
        pred = status_filter(200)
        assert pred(_entry(status=200)) is True
        assert pred(_entry(status=201)) is False
        assert pred(_entry(status=2000)) is False


class TestUrlRegexFilterEdgeCases:
    """Edge cases for url_regex_filter (using anchored patterns to avoid the bug)."""

    def test_exact_url_match(self):
        """Exact URL match with anchored regex."""
        pred = url_regex_filter(r"^/$")
        assert pred(_entry(url="/")) is True
        assert pred(_entry(url="/index.html")) is False

    def test_url_with_query_string(self):
        """URL with query string matched by regex."""
        pred = url_regex_filter(r"^/search\?")
        assert pred(_entry(url="/search?q=test")) is True
        assert pred(_entry(url="/search")) is False

    def test_url_with_unicode(self):
        """URL with unicode characters."""
        pred = url_regex_filter(r"^/path")
        assert pred(_entry(url="/path/über")) is True

    def test_regex_special_chars_escaped(self):
        """Regex with special characters properly escaped."""
        pred = url_regex_filter(r"^/api/v1\.json$")
        assert pred(_entry(url="/api/v1.json")) is True
        assert pred(_entry(url="/api/v1Xjson")) is False

    def test_case_sensitive_match(self):
        """Regex matching is case-sensitive by default."""
        pred = url_regex_filter(r"^/Admin")
        assert pred(_entry(url="/Admin/login")) is True
        assert pred(_entry(url="/admin/login")) is False


class TestIpAllowlistEdgeCases:
    """Edge cases for ip_allowlist_filter."""

    def test_empty_allowlist(self):
        """Empty allowlist — no IPs match."""
        pred = ip_allowlist_filter([])
        assert pred(_entry(ip="10.0.0.1")) is False

    def test_single_ip_allowlist(self):
        """Single IP in allowlist."""
        pred = ip_allowlist_filter(["10.0.0.1"])
        assert pred(_entry(ip="10.0.0.1")) is True
        assert pred(_entry(ip="10.0.0.2")) is False

    def test_ipv6_address(self):
        """IPv6 address in allowlist."""
        pred = ip_allowlist_filter(["::1"])
        assert pred(_entry(ip="::1")) is True
        assert pred(_entry(ip="127.0.0.1")) is False

    def test_allowlist_as_set(self):
        """Allowlist can be a set (not just a list)."""
        pred = ip_allowlist_filter({"10.0.0.1", "10.0.0.2"})
        assert pred(_entry(ip="10.0.0.1")) is True
        assert pred(_entry(ip="10.0.0.3")) is False

    def test_date_range_filter_happy_path(self):
        """Entry within range returns True (exercises the return True path)."""
        from logalyzer.filters import date_range_filter
        from datetime import datetime, timezone
        since = datetime(2025, 1, 1, tzinfo=timezone.utc)
        until = datetime(2027, 1, 1, tzinfo=timezone.utc)
        pred = date_range_filter(since, until)
        entry = _entry(timestamp=datetime(2026, 6, 15, tzinfo=timezone.utc))
        assert pred(entry) is True

    def test_date_range_filter_until_boundary(self):
        """Entry after 'until' returns False (exercises the until check path)."""
        from logalyzer.filters import date_range_filter
        from datetime import datetime, timezone
        since = datetime(2025, 1, 1, tzinfo=timezone.utc)
        until = datetime(2026, 1, 1, tzinfo=timezone.utc)
        pred = date_range_filter(since, until)
        # Entry is after 'until'
        entry = _entry(timestamp=datetime(2026, 6, 15, tzinfo=timezone.utc))
        assert pred(entry) is False
