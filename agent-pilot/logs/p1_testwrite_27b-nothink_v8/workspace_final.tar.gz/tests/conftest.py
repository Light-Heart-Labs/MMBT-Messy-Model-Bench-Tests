"""Shared pytest fixtures."""
import sys
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Workaround: collections.Iterable was removed in Python 3.3+ (moved to collections.abc).
# The source code imports from collections directly, which fails on Python 3.10+.
# We monkey-patch it so the module can be imported. This is a test-side workaround
# for a known bug in the source — we do NOT modify production code.
import collections
from collections.abc import Iterable as _Iterable
if not hasattr(collections, "Iterable"):
    collections.Iterable = _Iterable
