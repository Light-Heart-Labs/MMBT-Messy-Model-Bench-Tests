"""Tests for utils.py — utility functions with edge cases.

Targets: format_bytes (boundary values), chunked (empty/edge cases),
format_legacy (uncovered legacy function), parse_iso_date (error paths).
"""
import pytest

from logalyzer.utils import (
    chunked,
    format_bytes,
    format_legacy,
    parse_iso_date,
)
from logalyzer.parser import LogEntry
from datetime import datetime, timezone


class TestFormatBytes:
    """Test human-readable byte formatting with boundary conditions."""

    def test_zero_bytes(self):
        """Zero bytes should display as '0.0 B'."""
        assert format_bytes(0) == "0.0 B"

    def test_one_byte(self):
        """Single byte."""
        assert format_bytes(1) == "1.0 B"

    def test_just_under_1kb(self):
        """1023 bytes is still in B range."""
        assert format_bytes(1023) == "1023.0 B"

    def test_exactly_1kb(self):
        """1024 bytes is exactly 1.0 KB."""
        assert format_bytes(1024) == "1.0 KB"

    def test_exactly_1mb(self):
        """1024*1024 bytes is exactly 1.0 MB."""
        assert format_bytes(1024 * 1024) == "1.0 MB"

    def test_exactly_1gb(self):
        """1024^3 bytes is exactly 1.0 GB."""
        assert format_bytes(1024 ** 3) == "1.0 GB"

    def test_exactly_1tb(self):
        """1024^4 bytes is exactly 1.0 TB."""
        assert format_bytes(1024 ** 4) == "1.0 TB"

    def test_very_large_value_reaches_pb(self):
        """Values larger than 1 TB go through the loop to PB fallback."""
        result = format_bytes(1024 ** 5)
        # After dividing by 1024 four times (B→KB→MB→GB→TB),
        # n = 1024 which is NOT < 1024, so it divides again → 1.0 PB
        assert result == "1.0 PB"

    def test_small_value_stays_in_bytes(self):
        """512 bytes stays in B unit (the loop doesn't scale down)."""
        assert format_bytes(512) == "512.0 B"

    def test_large_mb_value(self):
        """A value in the MB range."""
        result = format_bytes(1536 * 1024)  # 1.5 MB
        assert "MB" in result

    def test_negative_bytes(self):
        """Negative byte count — the function doesn't guard against this."""
        assert format_bytes(-1) == "-1.0 B"

    def test_fractional_kb_boundary(self):
        """1024 bytes is the boundary between B and KB."""
        assert format_bytes(1023) == "1023.0 B"
        assert format_bytes(1024) == "1.0 KB"

    def test_fractional_mb(self):
        """Value between KB and MB."""
        result = format_bytes(1024 * 1024 // 2)  # 524288 = 0.5 MB
        assert "KB" in result


class TestChunked:
    """Test chunked iterator with edge cases."""

    def test_empty_sequence(self):
        """Empty input produces no chunks."""
        result = list(chunked([], 3))
        assert result == []

    def test_chunk_size_larger_than_sequence(self):
        """When chunk size > sequence length, all items in one chunk."""
        result = list(chunked([1, 2, 3], 10))
        assert result == [[1, 2, 3]]

    def test_chunk_size_one(self):
        """Chunk size of 1 produces one-item chunks."""
        result = list(chunked([1, 2, 3], 1))
        assert result == [[1], [2], [3]]

    def test_exact_multiple(self):
        """When sequence length is an exact multiple of chunk size."""
        result = list(chunked([1, 2, 3, 4, 5, 6], 3))
        assert result == [[1, 2, 3], [4, 5, 6]]

    def test_remainder_chunk(self):
        """Remaining items form a smaller final chunk."""
        result = list(chunked([1, 2, 3, 4, 5], 2))
        assert result == [[1, 2], [3, 4], [5]]

    def test_generator_input(self):
        """chunked works with generator input (not just lists)."""
        def gen():
            yield 1
            yield 2
            yield 3
            yield 4
        result = list(chunked(gen(), 2))
        assert result == [[1, 2], [3, 4]]

    def test_single_item(self):
        """Single item in sequence."""
        result = list(chunked([42], 5))
        assert result == [[42]]

    def test_chunk_size_zero(self):
        """Chunk size of 0 — each item yields immediately as a single-item chunk."""
        result = list(chunked([1, 2], 0))
        assert result == [[1], [2]]


class TestFormatLegacy:
    """Test the legacy formatter — uncovered in the original test suite."""

    def test_format_legacy_output_format(self):
        """Legacy format: 'ip | timestamp | status | url'."""
        entry = LogEntry(
            ip="192.168.1.1",
            user="-",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="GET",
            url="/index.html",
            protocol="HTTP/1.1",
            status=200,
            bytes=1024,
        )
        result = format_legacy(entry)
        assert "192.168.1.1" in result
        assert "200" in result
        assert "/index.html" in result
        assert "|" in result

    def test_format_legacy_does_not_include_method_or_bytes(self):
        """Legacy format omits method and bytes fields (unlike current formats)."""
        entry = LogEntry(
            ip="10.0.0.1",
            user="-",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="POST",
            url="/api",
            protocol="HTTP/1.1",
            status=500,
            bytes=9999,
        )
        result = format_legacy(entry)
        assert "POST" not in result
        assert "9999" not in result

    def test_format_legacy_with_special_url_chars(self):
        """URLs with special characters are included as-is."""
        entry = LogEntry(
            ip="10.0.0.1",
            user="-",
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            method="GET",
            url="/search?q=hello&lang=en",
            protocol="HTTP/1.1",
            status=200,
            bytes=500,
        )
        result = format_legacy(entry)
        assert "/search?q=hello&lang=en" in result


class TestParseIsoDate:
    """Test ISO date parsing with edge cases."""

    def test_valid_date(self):
        """Standard YYYY-MM-DD format."""
        result = parse_iso_date("2026-01-15")
        assert result.year == 2026
        assert result.month == 1
        assert result.day == 15
        assert result.tzinfo is timezone.utc
        assert result.hour == 0
        assert result.minute == 0

    def test_leap_year(self):
        """Feb 29 on a leap year."""
        result = parse_iso_date("2024-02-29")
        assert result.month == 2
        assert result.day == 29

    def test_invalid_date_raises_value_error(self):
        """Invalid date string raises ValueError."""
        with pytest.raises(ValueError):
            parse_iso_date("not-a-date")

    def test_wrong_format_raises_value_error(self):
        """MM/DD/YYYY format should fail (expects YYYY-MM-DD)."""
        with pytest.raises(ValueError):
            parse_iso_date("01-15-2026")

    def test_empty_string_raises_value_error(self):
        """Empty string raises ValueError."""
        with pytest.raises(ValueError):
            parse_iso_date("")

    def test_date_at_midnight_utc(self):
        """Parsed date is at midnight UTC."""
        result = parse_iso_date("2026-06-15")
        assert result.hour == 0
        assert result.minute == 0
        assert result.second == 0
        assert result.tzinfo is timezone.utc
