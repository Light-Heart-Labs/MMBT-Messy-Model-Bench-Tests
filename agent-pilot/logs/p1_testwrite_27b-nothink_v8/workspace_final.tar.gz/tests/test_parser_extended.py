"""Tests for parser.py — edge cases and uncovered paths.

Targets: parse_timestamp edge cases, parse_line with unusual inputs,
parse_lines generator behavior, and the July bug (documented, not fixed).
"""
import pytest

from logalyzer.parser import parse_line, parse_lines, parse_timestamp, MONTH_NAMES
from datetime import timezone


class TestParseTimestampEdgeCases:
    """Edge cases for timestamp parsing."""

    def test_positive_timezone_offset(self):
        """Positive timezone offset (e.g., +0530 for IST)."""
        ts = parse_timestamp("15/Mar/2026:10:00:00 +0530")
        # 10:00 +0530 = 04:30 UTC
        assert ts.hour == 4
        assert ts.minute == 30
        assert ts.tzinfo is timezone.utc

    def test_negative_timezone_offset(self):
        """Negative timezone offset (e.g., -0800 for PST)."""
        ts = parse_timestamp("15/Mar/2026:10:00:00 -0800")
        # 10:00 -0800 = 18:00 UTC
        assert ts.hour == 18
        assert ts.minute == 0
        assert ts.tzinfo is timezone.utc

    def test_utc_offset(self):
        """Zero timezone offset (+0000)."""
        ts = parse_timestamp("15/Mar/2026:10:00:00 +0000")
        assert ts.hour == 10
        assert ts.minute == 0

    def test_midnight_timestamp(self):
        """Timestamp at midnight."""
        ts = parse_timestamp("01/Jan/2026:00:00:00 +0000")
        assert ts.hour == 0
        assert ts.minute == 0
        assert ts.second == 0

    def test_missing_timezone_raises(self):
        """Timestamp without timezone offset raises ValueError."""
        with pytest.raises(ValueError, match="unrecognized timestamp format"):
            parse_timestamp("15/Mar/2026:10:00:00")

    def test_malformed_date_raises(self):
        """Completely malformed timestamp raises ValueError."""
        with pytest.raises(ValueError, match="unrecognized timestamp format"):
            parse_timestamp("not-a-timestamp")

    def test_empty_string_raises(self):
        """Empty string raises ValueError."""
        with pytest.raises(ValueError, match="unrecognized timestamp format"):
            parse_timestamp("")

    def test_invalid_month_name_raises_value_error(self):
        """Invalid month name raises ValueError (but with 'not in list' message,
        not 'unrecognized timestamp format' — the regex matches but index() fails)."""
        with pytest.raises(ValueError, match="'Xyz' is not in list"):
            parse_timestamp("15/Xyz/2026:10:00:00 +0000")

    def test_months_jan_through_jun_parse_correctly(self):
        """Months Jan-Jun parse correctly (before the July gap)."""
        months = [
            ("Jan", 1), ("Feb", 2), ("Mar", 3), ("Apr", 4), ("May", 5), ("Jun", 6),
        ]
        for month_str, expected_num in months:
            ts = parse_timestamp(f"15/{month_str}/2026:10:00:00 +0000")
            assert ts.month == expected_num, f"Month {month_str} should be {expected_num}"

    def test_months_aug_through_dec_have_shifted_indices(self):
        """BUG: Because 'Jul' is missing from MONTH_NAMES, Aug-Dec have
        shifted month numbers. Aug→7, Sep→8, Oct→9, Nov→10, Dec→11.
        This is a known bug (see dead-ends.md)."""
        # The actual (buggy) mapping:
        buggy_mapping = [
            ("Aug", 7), ("Sep", 8), ("Oct", 9), ("Nov", 10), ("Dec", 11),
        ]
        for month_str, actual_month in buggy_mapping:
            ts = parse_timestamp(f"15/{month_str}/2026:10:00:00 +0000")
            assert ts.month == actual_month, f"Month {month_str} maps to {actual_month} (bug)"

    def test_july_raises_value_error(self):
        """July is missing from MONTH_NAMES — this is a known bug (see dead-ends.md)."""
        with pytest.raises(ValueError, match="'Jul' is not in list"):
            parse_timestamp("15/Jul/2026:10:00:00 +0000")

    def test_dec_31_fails_due_to_month_shift_bug(self):
        """BUG: Dec 31 fails because Dec is mapped to month 11 (November),
        and November only has 30 days. This is a cascading bug from the
        missing July in MONTH_NAMES."""
        with pytest.raises(ValueError, match="day is out of range for month"):
            parse_timestamp("31/Dec/2025:23:59:59 +0000")

    def test_month_names_list_has_11_entries(self):
        """MONTH_NAMES has 11 entries (missing July)."""
        assert len(MONTH_NAMES) == 11
        assert "Jul" not in MONTH_NAMES


class TestParseLineEdgeCases:
    """Edge cases for single-line parsing."""

    def test_whitespace_only_line(self):
        """Line with only whitespace returns None."""
        assert parse_line("   ") is None
        assert parse_line("\t") is None

    def test_line_with_leading_trailing_whitespace(self):
        """Line with extra whitespace is stripped before parsing."""
        line = '  127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" 200 100  '
        result = parse_line(line)
        assert result is not None
        assert result.ip == "127.0.0.1"

    def test_various_http_methods(self):
        """Various HTTP methods are parsed correctly."""
        for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
            line = f'127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "{method} / HTTP/1.1" 200 100'
            result = parse_line(line)
            assert result is not None
            assert result.method == method

    def test_various_status_codes(self):
        """Various status codes are parsed correctly."""
        for status in [100, 200, 201, 301, 302, 400, 401, 403, 404, 500, 502, 503]:
            line = f'127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" {status} 100'
            result = parse_line(line)
            assert result is not None
            assert result.status == status

    def test_zero_bytes(self):
        """Zero bytes is parsed correctly."""
        line = '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" 200 0'
        result = parse_line(line)
        assert result is not None
        assert result.bytes == 0

    def test_large_byte_count(self):
        """Large byte count is parsed correctly."""
        line = '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" 200 999999999'
        result = parse_line(line)
        assert result is not None
        assert result.bytes == 999999999

    def test_url_with_query_string(self):
        """URL with query string is parsed correctly."""
        line = '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET /search?q=test&lang=en HTTP/1.1" 200 100'
        result = parse_line(line)
        assert result is not None
        assert result.url == "/search?q=test&lang=en"

    def test_url_with_path_segments(self):
        """URL with multiple path segments."""
        line = '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET /api/v1/users/123 HTTP/1.1" 200 100'
        result = parse_line(line)
        assert result is not None
        assert result.url == "/api/v1/users/123"

    def test_ipv6_address(self):
        """IPv6 address is parsed correctly."""
        line = '::1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" 200 100'
        result = parse_line(line)
        assert result is not None
        assert result.ip == "::1"

    def test_authenticated_user(self):
        """Authenticated user (non-dash) is parsed correctly."""
        line = '127.0.0.1 - admin [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" 200 100'
        result = parse_line(line)
        assert result is not None
        assert result.user == "admin"

    def test_http_2_protocol(self):
        """HTTP/2 protocol is parsed correctly."""
        line = '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/2.0" 200 100'
        result = parse_line(line)
        assert result is not None
        assert result.protocol == "HTTP/2.0"

    def test_line_missing_protocol(self):
        """Line without protocol field returns None."""
        line = '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET /" 200 100'
        result = parse_line(line)
        assert result is None

    def test_line_with_extra_fields(self):
        """Line with extra fields (referer, user-agent) — regex captures core fields."""
        line = '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" 200 100 "http://example.com" "Mozilla/5.0"'
        result = parse_line(line)
        assert result is not None
        assert result.ip == "127.0.0.1"

    def test_log_entry_is_frozen(self):
        """LogEntry dataclass is frozen (immutable)."""
        line = '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" 200 100'
        entry = parse_line(line)
        with pytest.raises(Exception):  # FrozenInstanceError
            entry.ip = "1.2.3.4"


class TestParseLines:
    """Test parse_lines generator."""

    def test_parse_lines_empty(self):
        """Empty input produces no entries."""
        result = list(parse_lines([]))
        assert result == []

    def test_parse_lines_mixed_valid_invalid(self):
        """parse_lines yields only valid entries, skipping invalid ones."""
        lines = [
            '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" 200 100',
            "garbage line",
            '127.0.0.1 - - [01/Jan/2026:12:00:01 +0000] "GET / HTTP/1.1" 404 0',
            "",
            '127.0.0.1 - - [01/Jan/2026:12:00:02 +0000] "GET / HTTP/1.1" 500 50',
        ]
        result = list(parse_lines(lines))
        assert len(result) == 3
        assert result[0].status == 200
        assert result[1].status == 404
        assert result[2].status == 500

    def test_parse_lines_is_a_generator(self):
        """parse_lines returns a generator."""
        result = parse_lines([])
        assert hasattr(result, "__iter__")
        assert hasattr(result, "__next__")

    def test_parse_lines_with_generator_input(self):
        """parse_lines works with generator input."""
        def line_gen():
            yield '127.0.0.1 - - [01/Jan/2026:12:00:00 +0000] "GET / HTTP/1.1" 200 100'
            yield '127.0.0.1 - - [01/Jan/2026:12:00:01 +0000] "GET / HTTP/1.1" 404 0'
        result = list(parse_lines(line_gen()))
        assert len(result) == 2

    def test_parse_line_returns_none_for_valid_format_bad_timestamp(self):
        """A line matching the regex but with an unparseable timestamp returns None.
        This exercises the except ValueError: return None path in parse_line."""
        line = '127.0.0.1 - - [bad-timestamp] "GET / HTTP/1.1" 200 100'
        result = parse_line(line)
        assert result is None
