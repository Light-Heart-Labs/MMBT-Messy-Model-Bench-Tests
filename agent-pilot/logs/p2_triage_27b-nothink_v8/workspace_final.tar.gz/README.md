# Support Ticket Triage — Results & Methodology

## Overview

30 tickets were triaged from `/input/repo/tickets.txt`. Results are in
`/workspace/triage_results.json`.

## Summary

| Category | Count |
|---|---|
| bug-report | 7 |
| billing-refund | 4 |
| feature-request | 3 |
| incident-active | 2 |
| account-management | 2 |
| auth-permissions | 2 |
| general-question | 2 |
| spam-or-noise | 4 |
| external-business | 2 |
| security-incident | 1 |
| legal-compliance | 1 |
| billing-other | 0 |

**Urgent tickets: 5** — 003, 014, 016, 023, 028, 030  
**Duplicate clusters: 2** — see below

## Recommended Processing Order

1. **028** — Security incident (account compromise, freeze requested)
2. **003** — Active incident (org-wide login outage, 503s)
3. **016** — Active incident (API 500 errors, SOC1 review tomorrow)
4. **014 / 023 / 030** — Urgent bug (API rate limits blocking nightly ingestion, growing backlog)
5. **001, 008, 013, 022** — Billing refunds (normal priority)
6. **005, 020, 024, 027** — Bug reports (normal priority)
7. **006, 026** — Account management
8. **007 / 011** — Auth/permissions issue
9. **019** — Legal/compliance (GDPR data export)
10. **002, 012, 015** — Feature requests
11. **017, 025** — General questions
12. **010, 018** — External business (low priority)
13. **004, 009, 021, 029** — Spam/noise (no action needed)

## Duplicate Clusters

### Cluster 1: Dashboard sharing permissions — `["007", "011"]`
- **007** (jordan.lee@mid-co.com): Reports seeing shared dashboards but getting "permission denied"
- **011** (alex.petrov@mid-co.com): Same account (MC-3309), same three dashboards, reports from the sharer's perspective
- These are two sides of the same issue. 011 is marked as `duplicate_of: "007"`.

### Cluster 2: API rate limits — `["014", "023", "030"]`
- **014** (ops@major-customer.com): Initial report of nightly 429s during data ingestion
- **023** (same sender): Follow-up — issue recurred, backlog growing
- **030** (same sender): Third follow-up — still unresolved, threatening escalation
- 023 and 030 are marked as `duplicate_of: "014"`.

## Ambiguous Calls

See `/workspace/decisions/` for detailed reasoning on non-obvious classifications.

### Brief highlights:
- **014** classified as `bug-report` not `billing-other`: The core issue is technical (rate limits), not a billing dispute. The contract mention is context for business impact.
- **029** classified as `spam-or-noise` not `security-incident`: This is extortion, not a legitimate vulnerability disclosure. No engagement warranted.
- **022** classified as `billing-refund`: The explicit ask is a credit for confirmed downtime.
- **016** classified as `incident-active` not `bug-report`: Ongoing outage with active impact and a near-term deadline.
