# Project Aurora — Status Report

**Prepared for:** Brendan (CEO)
**As of:** 2026-04-08 (week 6)

---

## Headline

Aurora V1 (dashboard refresh + embedded SDK) is tracking toward a **mid-July GA** with the SDK shipping in **private beta** (3–5 customers) due to an unbuilt access-control layer. Core workstreams are on track; legal and customer-management items need attention.

---

## Workstreams

| Workstream | Owner | Status | Blocks V1? |
|---|---|---|---|
| Query layer (backend) | Marcus | 60% done; tracking to mid-May (week 6) | Yes |
| Mobile-responsive UX | Jen | On track for mid-May (week 5) | Yes |
| SDK access control (IAM) | Priya / Marcus | IAM design started; API surface discussion next (week 6) | Yes (mitigated via private beta) |
| Panel-density arch fix | Roman | 30% done; targeting V1.1 in August (week 6) | No (40-panel limit accepted for V1) |
| Custom branding | Jen | Parked for V2 (week 3) | No |

---

## Risks

| Severity | Risk | Description |
|---|---|---|
| **HIGH** | SDK access-control gap | No access-control layer exists for embedded SDK; 4-week minimum build (week 5). Mitigated by private-beta approach (week 6). |
| **MEDIUM** | Legal delay on private-beta contracts | Legal has not yet responded to contract draft (week 6). Blocks customer onboarding. |
| **MEDIUM** | Maevia expectation mismatch | Maevia was promised GA SDK at the conference; will push back on private-beta status (week 6). |
| **LOW** | Panel-density limit | V1 ships with 40-panel/page limit; arch fix targeting V1.1 in August (week 3, week 6). |

---

## Decisions Made

| Date | Decision | Decider |
|---|---|---|
| 2026-03-18 (week 3) | Cut custom branding from V1; defer to V2 | Brendan |
| 2026-03-18 (week 3) | Accept 40-panel/page limit as documented V1 limitation | Brendan |
| 2026-03-25 (week 4) | Mobile strategy: web-responsive for V1, native for V2 | Sara (team consensus) |
| 2026-04-08 (week 6) | SDK ships in private beta (3–5 customers) with extra contracts; do not delay V1 | Brendan |

---

## Milestones

| Target | Milestone | Owner |
|---|---|---|
| Mid-May 2026 | Query-layer completion | Marcus |
| Mid-May 2026 | Mobile-responsive UX completion | Jen |
| Mid-July 2026 | V1 GA (dashboard refresh + SDK private beta) | Sara |
| August 2026 | V1.1 — panel-density architectural fix | Roman |
| August 2026 | V1.5 — SDK with full access control | Priya / Marcus |

---

## Open Questions / Asks

1. **Legal engagement:** Legal has not responded to the private-beta contract draft. Can you escalate? (week 6)
2. **Maevia conversation:** Sara has a call with Maevia's CSM to manage expectations about private-beta vs. GA. No CEO involvement needed unless Maevia escalates. (week 6)
3. **V1 GA date confirmation:** Mid-July was the last stated target (week 3). Given the private-beta decision, does this still hold, or should we reconfirm?
