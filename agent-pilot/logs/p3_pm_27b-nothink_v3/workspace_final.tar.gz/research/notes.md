# Working Notes — Synthesis Process

## Reading Pass: Key Facts Extracted

### Team
- Sara (PM), Marcus (TL), Jen (UX), Roman (data), Priya (security, joined week 5)
- Brendan (CEO) — sporadic attendance; key decision-maker

### Workstreams Identified

1. **Query Layer (Backend)** — Owner: Marcus
   - Week 1: "ready-ish", needs work for SDK filter expressions; est. 4-6 weeks
   - Week 2: Revised to 8 weeks (parser + filter combinations)
   - Week 3: Blocked on code review (Lin on PTO until 3/24)
   - Week 4: Sub reviewer Aanya assigned; on track for mid-May
   - Week 5: No update
   - Week 6: 60% done, tracking to mid-May

2. **Dashboard Design / UX** — Owner: Jen
   - Week 1: Design in progress; open questions on custom branding & mobile
   - Week 2: Custom branding confirmed wanted; ~3 weeks extra design
   - Week 3: Custom branding deferred to V2; Jen pivots to mobile
   - Week 4: Mobile scope: native 12+ weeks vs responsive 4 weeks; responsive chosen for V1
   - Week 5: Mobile-responsive on track for mid-May
   - Week 6: Mobile-responsive on track; custom branding still parked

3. **Data Pipeline / Panel Density** — Owner: Roman
   - Week 1: Pipeline fine for dashboard; latency concern at 100+ panels
   - Week 2: Confirmed: ~40 panels/page before lag unacceptable; arch fix needed
   - Week 3: 40-panel limit accepted as V1 known limitation; arch fix as V1.1 fast-follow
   - Week 4: Arch fix started in parallel; est. 6 weeks
   - Week 5: Arch fix on track
   - Week 6: Arch fix 30% done; on track for V1.1 in August

4. **SDK Access Control / Security** — Owner: Priya (security) + Marcus (IAM design)
   - Week 4: Discovered gap — no access-control layer for embedded SDK
   - Week 5: Priya says 4-week minimum; needs IAM design + customer API + audit logging
   - Week 6: IAM design started; ready for API discussion next week

5. **Custom Branding** — Owner: Jen
   - Week 2: Confirmed wanted; mockups exist
   - Week 3: Deferred to V2 by Brendan's decision
   - Week 6: Still parked

### Decisions Identified

1. Week 1 (3/4): Brendan sets target "end of June" — not a decision per se, a directive
2. Week 3 (3/18): Brendan decides to cut custom branding from V1
3. Week 3 (3/18): Brendan accepts 40-panel limit as documented V1 limitation
4. Week 3 (3/18): Jen pivots to mobile (team decision)
5. Week 4 (3/25): Team decides mobile = web-responsive for V1, native for V2
6. Week 5 (4/1): Team identifies 3 options for SDK access-control gap (no decision yet)
7. Week 6 (4/8): Brendan chooses Option B — private beta with 3-5 customers

### Risks Identified

1. SDK access-control gap — HIGH (blocker for SDK V1 GA)
2. Legal delay on private-beta contracts — MEDIUM
3. Maevia customer expectation mismatch — MEDIUM
4. Panel-density architectural fix timeline — LOW (accepted as V1.1)
5. Query-layer timeline risk — MEDIUM (was blocked, now recovering)

### Milestones

- End of June (original) — abandoned
- Mid-July GA — Brendan's ceiling (week 3)
- V1 GA target: mid-July (implied by decisions in week 3-6)
- Query-layer completion: mid-May (week 4, confirmed week 6)
- Mobile-responsive completion: mid-May (week 5)
- SDK V1.5 (with access control): August (week 5 option A timeline)
- V1.1 (arch fix): August (week 3, confirmed week 6)

### Open Questions / Asks for CEO

- Legal hasn't responded to private-beta contract draft
- Maevia was promised GA SDK at conference; they'll push back on private-beta
- No explicit V1 GA date confirmed after Option B decision
