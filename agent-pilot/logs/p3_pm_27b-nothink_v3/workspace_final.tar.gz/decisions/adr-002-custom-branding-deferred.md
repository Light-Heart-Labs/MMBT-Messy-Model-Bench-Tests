# ADR-002: V1 Scope — Custom Branding Deferred

**Date:** 2026-03-18 (week 3)
**Status:** Accepted
**Decider:** Brendan (CEO)

## Context

Custom branding for SDK customers was identified as a 3-week design effort (week 2). The team was already behind the original end-of-June target. Sara proposed cutting custom branding from V1 to make an end-of-July GA date reachable.

## Decision

Brendan approved cutting custom branding from V1. Jen deferred it and pivoted her capacity to mobile UX.

## Consequences

- Custom branding is parked for V2
- Jen's capacity was freed for mobile-responsive design (4-week effort)
- No impact on core dashboard or SDK functionality
