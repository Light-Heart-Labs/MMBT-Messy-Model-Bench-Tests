# ADR-001: V1 Scope — SDK in Private Beta

**Date:** 2026-04-08 (week 6)
**Status:** Accepted
**Decider:** Brendan (CEO)

## Context

The SDK access-control layer was discovered in week 4 to be unbuilt. Priya (security) assessed it as a 4-week minimum project (week 5). Three options were presented to Brendan:

- (a) Ship V1 without the SDK; SDK becomes V1.5 in August
- (b) Ship V1 with SDK in private beta (3-5 customers) with extra contracts
- (c) Push V1 to August with everything

## Decision

Brendan chose option (b): private beta with 3-5 customers. He stated: "We have access-control commitments to make right but we cannot delay V1 entirely."

## Consequences

- Legal must draft and execute private-beta contracts before SDK customers onboard
- Maevia (promised GA at conference) will need a conversation about private-beta status
- IAM design continues in parallel; full access-control layer targets V1.5
