"""Output formatters: JSON, CSV, plain text.

This package replaces the monolithic output.py module. Each concern
has been split into its own module:

- json_renderer.py: JSON serialization (to_json)
- csv_renderer.py: CSV serialization (to_csv)
- plain_renderer.py: Plain-text formatting (to_text, render_aggregate)
- legacy.py: Backwards-compatibility shim (format_legacy)

All public names are re-exported here to maintain backward compatibility
with existing import paths like:
    from logalyzer.output import to_json, to_csv, to_text, render_aggregate
    from logalyzer.output import format_legacy
"""
from __future__ import annotations

from .json_renderer import to_json
from .csv_renderer import to_csv
from .plain_renderer import render_aggregate, to_text
from .legacy import format_legacy

__all__ = [
    "to_json",
    "to_csv",
    "to_text",
    "render_aggregate",
    "format_legacy",
]
