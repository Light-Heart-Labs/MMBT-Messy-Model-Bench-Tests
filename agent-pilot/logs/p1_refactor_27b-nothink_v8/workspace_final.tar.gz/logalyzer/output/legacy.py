"""Legacy output formatting for backwards compatibility.

This module provides the format_legacy() function that was retained
for compatibility with the v0.1 CLI output. It is no longer used
internally but is kept for any external scripts that may still depend on it.
"""
from __future__ import annotations

# Re-export format_legacy from utils to maintain the public API surface
# at logalyzer.output.format_legacy. The actual implementation lives in
# utils.py and is not modified by this refactor.
from ..utils import format_legacy  # noqa: F401

__all__ = ["format_legacy"]
