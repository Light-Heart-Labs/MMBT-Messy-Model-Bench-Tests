# ADR-0001: Why Split output.py

## Status

Accepted

## Context

The `logalyzer/output.py` module mixed four distinct concerns:

1. **JSON serialization** (`to_json`) — hand-crafted JSON string building
2. **CSV serialization** (`to_csv`) — uses `csv` module with `io.StringIO`
3. **Plain-text formatting** (`to_text`) — human-readable log entry formatting
4. **Aggregate rendering** (`render_aggregate`) — dispatches across text/json formats for aggregate data
5. **Legacy compatibility** (`format_legacy`) — a v0.1-era formatter kept for external scripts

This monolithic structure made it difficult to:
- Understand which functions belong to which concern
- Add new output formats without growing the file
- Test individual renderers in isolation
- Reason about dependencies (e.g., `to_json` depends on `LogEntry`, `to_csv` depends on `csv` and `io`)

## Decision

Split `output.py` into a `logalyzer/output/` package with one module per concern:

| Module | Contents |
|--------|----------|
| `json_renderer.py` | `to_json()` |
| `csv_renderer.py` | `to_csv()` |
| `plain_renderer.py` | `to_text()`, `render_aggregate()` |
| `legacy.py` | Re-exports `format_legacy` from `utils.py` |
| `__init__.py` | Re-exports all public names |

## Consequences

- **Positive**: Each module has a single responsibility. New formats can be added as new modules.
- **Positive**: Import paths are preserved via `__init__.py` re-exports.
- **Neutral**: `format_legacy` remains in `utils.py` (not moved) because the task constrains changes to `output.py` only. It is re-exported from `output/legacy.py` and `output/__init__.py`.
- **Neutral**: `render_aggregate` was placed in `plain_renderer.py` because its default format is text and it's the most general rendering function. It handles text and json formats for aggregate data.
