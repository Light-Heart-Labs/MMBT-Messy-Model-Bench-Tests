# ADR-0002: Public API Shape

## Status

Accepted

## Context

The `logalyzer/output` module is imported by `cli.py` and potentially by external scripts. The public API must remain unchanged after the refactor.

## Decision

The following names are re-exported from `logalyzer/output/__init__.py`:

| Name | Source Module | Used By |
|------|--------------|---------|
| `to_json` | `json_renderer.py` | `cli.py` |
| `to_csv` | `csv_renderer.py` | `cli.py` |
| `to_text` | `plain_renderer.py` | `cli.py` |
| `render_aggregate` | `plain_renderer.py` | `cli.py` |
| `format_legacy` | `legacy.py` (re-exported from `utils.py`) | External scripts (backwards compat) |

### Why `format_legacy` is in `legacy.py`

`format_legacy` is defined in `utils.py` and was never imported from `output.py` in the original codebase. However, the task specification requires that `from logalyzer.output import format_legacy` works. Rather than moving the function (which would modify `utils.py`, violating the constraint "only `output.py` may be split"), we re-export it from `output/legacy.py` which imports it from `utils.py`.

### Why `render_aggregate` is in `plain_renderer.py`

`render_aggregate` handles multiple output formats (text, json) for aggregate data structures. It was placed in `plain_renderer.py` because:
1. Its default format is "text"
2. It's a higher-level rendering function that doesn't fit neatly into a single-format module
3. It's closely related to `to_text` in purpose (human-readable output)

### Import compatibility

All existing import patterns are preserved:

```python
# These all still work:
from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.output import format_legacy
from logalyzer import output  # module-level access
```
