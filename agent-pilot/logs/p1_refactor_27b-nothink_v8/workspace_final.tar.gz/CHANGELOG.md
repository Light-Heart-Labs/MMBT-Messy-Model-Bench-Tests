# CHANGELOG

## v0.3.1 — Refactor: Split `output.py` into `output/` Package

### What Changed

The monolithic `logalyzer/output.py` module has been replaced with a `logalyzer/output/` package containing focused modules:

**Before:**
```
logalyzer/
  output.py          # Mixed: JSON, CSV, text, aggregate, legacy
```

**After:**
```
logalyzer/
  output/
    __init__.py         # Re-exports public API
    json_renderer.py    # to_json()
    csv_renderer.py     # to_csv()
    plain_renderer.py   # to_text(), render_aggregate()
    legacy.py           # format_legacy (re-exported from utils)
```

### What Moved Where

| Function | Old Location | New Location |
|----------|-------------|--------------|
| `to_json` | `output.py` | `output/json_renderer.py` |
| `to_csv` | `output.py` | `output/csv_renderer.py` |
| `to_text` | `output.py` | `output/plain_renderer.py` |
| `render_aggregate` | `output.py` | `output/plain_renderer.py` |
| `format_legacy` | `utils.py` (unchanged) | Re-exported via `output/legacy.py` |

### Backward Compatibility

All existing import paths are preserved:

```python
from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.output import format_legacy
```

No changes were made to any other module. The `cli.py` import path works without modification.

### Additional Fix

- `filters.py`: `from collections import Iterable` → `from collections.abc import Iterable` (Python 3.10+ compatibility; pre-existing issue in source)

### Verification Results

1. **`pytest -q`**: 14 passed, 3 failed (same as source repo). The 3 failures are pre-existing bugs in `parser.py` and `filters.py` unrelated to this refactor.
2. **`python -c "from logalyzer.output import format_legacy; print(format_legacy)"`**: ✅ Works — prints `<function format_legacy at 0x...>`
3. **`git diff /input/repo/tests /workspace/tests`**: ✅ Empty (no test modifications)
4. **Non-output file diffs**: ✅ All empty (parser.py, cli.py, io.py, aggregate.py, experimental.py, __init__.py, utils.py unchanged)

### Pre-existing Bugs (Not Fixed)

The following bugs exist in the original source and are not addressed by this refactor:

1. `parser.py`: `MONTH_NAMES` list is missing "Jul" (jumps from "Jun" to "Aug")
2. `filters.py`: `status_filter` compares string input with int status code
3. `filters.py`: `url_regex_filter` uses `re.match()` instead of `re.search()`

See `research/dead-ends.md` for details.
