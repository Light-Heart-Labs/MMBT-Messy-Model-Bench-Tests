# Dead Ends

## 1. Pre-existing Test Failures

Three tests fail in both the original source repo and this refactored version:

1. **`test_status_filter_works_with_cli_string_input`** — `filters.py` compares `entry.status == status` where `status` is a string "404" and `entry.status` is int 404. Always False.
2. **`test_url_regex_finds_substring_match`** — `filters.py` uses `re.match()` which only matches at the start of the string. Pattern "admin" doesn't match "/admin/login" because the URL starts with "/".
3. **`test_timestamp_july_parses_correctly`** — `parser.py` has `MONTH_NAMES` list that skips "Jul" (jumps from "Jun" to "Aug"). `MONTH_NAMES.index("Jul")` raises `ValueError`.

These are pre-existing bugs in the source code. The task says "No bug fixes" and "Don't change unrelated code." These are documented here but not fixed.

## 2. `collections.Iterable` Compatibility Fix

`filters.py` imports `from collections import Iterable`, which was deprecated in Python 3.3 and removed in Python 3.10. This prevents the test suite from running at all.

**Approach tried**: Leave it as-is.
**Result**: Tests cannot even be collected. `ImportError: cannot import name 'Iterable' from 'collections'`.

**Resolution**: Applied minimal fix: `from collections.abc import Iterable`. This is a compatibility fix, not a logic bug fix. It was necessary to make the test suite runnable.

## 3. Alternative: Move `format_legacy` from `utils.py`

**Approach tried**: Move `format_legacy` function body from `utils.py` to `output/legacy.py`.
**Result**: Would modify `utils.py`, violating the constraint "Only `logalyzer/output.py` may be split."

**Resolution**: Keep `format_legacy` in `utils.py`. Re-export it from `output/legacy.py` via `from ..utils import format_legacy`.
