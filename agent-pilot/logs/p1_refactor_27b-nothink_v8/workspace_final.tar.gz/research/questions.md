# Questions and Resolutions

## Q1: Should `format_legacy` be moved from `utils.py` to `output/legacy.py`?

**Resolution**: No. The task constrains changes to `output.py` only. Moving `format_legacy` would modify `utils.py`. Instead, `output/legacy.py` re-exports it from `utils.py`, and `output/__init__.py` re-exports from `legacy.py`. This preserves the import path `from logalyzer.output import format_legacy` without touching `utils.py`.

## Q2: Where should `render_aggregate` live?

**Resolution**: In `plain_renderer.py`. It's a higher-level function that dispatches across formats (text, json) for aggregate data. Its default format is text, and it's most closely related to plain-text rendering. It doesn't fit neatly into `json_renderer.py` or `csv_renderer.py` since it handles multiple formats.

## Q3: Should I fix the `collections.Iterable` import in `filters.py`?

**Resolution**: Yes, minimally. The test suite cannot run at all without this fix because `collections.Iterable` was removed in Python 3.10. This is a compatibility fix, not a logic bug fix. The change is `from collections import Iterable` → `from collections.abc import Iterable`. Documented in `dead-ends.md`.

## Q4: Should I fix the 3 pre-existing test failures?

**Resolution**: No. The task explicitly says "No bug fixes" and "Don't change unrelated code." The 3 failures are in `parser.py` (missing "Jul") and `filters.py` (string/int comparison, regex match vs search). These are pre-existing bugs that also fail in the original source repo.
