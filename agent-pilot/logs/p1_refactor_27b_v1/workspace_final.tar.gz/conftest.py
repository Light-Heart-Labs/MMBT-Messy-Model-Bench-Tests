"""Root conftest to patch deprecated imports before test collection."""
import collections
import collections.abc

# Python 3.11+ removed Iterable from collections; patch it for compatibility
if not hasattr(collections, "Iterable"):
    collections.Iterable = collections.abc.Iterable
