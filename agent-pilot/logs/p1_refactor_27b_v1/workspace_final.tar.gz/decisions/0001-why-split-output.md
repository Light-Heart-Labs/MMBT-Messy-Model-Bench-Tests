# ADR-0001: Why split output.py into a package

## Status
Accepted

## Context
The `logalyzer/output.py` module mixed four distinct concerns:
1. JSON serialization (`to_json`)
2. CSV serialization (`to_csv`)
3. Plain-text formatting (`to_text`)
4. Aggregate result rendering (`render_aggregate`)

Additionally, the legacy `format_legacy()` function lived in `utils.py` but was expected to be importable from `logalyzer.output` per the verification requirements.

This accreted structure made it difficult to:
- Understand which functions belong to which output format
- Extend the output system with new formats
- Test individual renderers in isolation

## Decision
Split `output.py` into a `logalyzer/output/` package with one module per concern:
- `json_renderer.py` — JSON output (`to_json`)
- `csv_renderer.py` — CSV output (`to_csv`)
- `plain_renderer.py` — Plain-text output (`to_text`)
- `legacy.py` — Backward-compat shim for `format_legacy`
- `__init__.py` — Re-exports the public API and contains `render_aggregate`

## Consequences
- **Positive:** Clear separation of concerns; each renderer is independently testable and extensible.
- **Positive:** Backward compatibility is maintained — all existing imports `from logalyzer.output import X` continue to work.
- **Neutral:** `render_aggregate` stays in `__init__.py` because it operates on aggregate results (Counter, dict, list) rather than `LogEntry` lists, so it doesn't naturally belong in any single renderer module.
- **Neutral:** `format_legacy` is re-exported from `output/legacy.py` which imports it from `utils.py`, keeping `utils.py` unchanged.
