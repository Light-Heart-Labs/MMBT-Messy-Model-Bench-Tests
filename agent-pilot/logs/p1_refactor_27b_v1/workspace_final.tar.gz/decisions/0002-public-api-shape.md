# ADR-0002: Public API shape of logalyzer.output

## Status
Accepted

## Context
The `logalyzer.output` module is imported by `cli.py` and must remain backward-compatible. The verification requirements also mandate that `format_legacy` be importable from `logalyzer.output`.

## Decision
The public API of `logalyzer.output` (re-exported from `__init__.py`) includes:

| Symbol | Source module | Used by |
|---|---|---|
| `to_json` | `json_renderer.py` | `cli.py` |
| `to_csv` | `csv_renderer.py` | `cli.py` |
| `to_text` | `plain_renderer.py` | `cli.py` |
| `render_aggregate` | `__init__.py` (defined inline) | `cli.py` |
| `format_legacy` | `legacy.py` (re-exported from `utils.py`) | External scripts (backward compat) |

### Why `render_aggregate` stays in `__init__.py`
`render_aggregate` operates on aggregate results (Counter, dict, list) rather than `LogEntry` lists. It doesn't fit naturally into any single renderer module (json, csv, plain) because it handles all three formats for a different data type. Placing it in `__init__.py` keeps it accessible while avoiding duplication.

### Why `format_legacy` is re-exported rather than moved
`format_legacy` is defined in `utils.py`. The task constraints say "Don't change unrelated code" and `utils.py` is not part of the output module. Instead, `output/legacy.py` imports and re-exports it, making it available at `logalyzer.output.format_legacy` without modifying `utils.py`.

## Consequences
- All existing call sites in `cli.py` continue to work without modification.
- External scripts that import `format_legacy` from `logalyzer.output` continue to work.
- The `__all__` list in `__init__.py` explicitly documents the public API.
