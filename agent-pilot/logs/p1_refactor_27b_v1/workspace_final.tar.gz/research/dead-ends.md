# Dead Ends

## Pre-existing bugs in the codebase (not fixed per task constraints)

### 1. `status_filter` does not handle string status codes
- **Location:** `logalyzer/filters.py`, `status_filter()`
- **Issue:** The CLI passes `--status` as a string (e.g., `"404"`), but the filter compares `entry.status == status` directly. Since `entry.status` is an `int`, `"404" == 404` is `False`.
- **Test affected:** `test_status_filter_works_with_cli_string_input`
- **Resolution:** Documented but not fixed. Out of scope for this refactor.

### 2. `url_regex_filter` uses `re.match` instead of `re.search`
- **Location:** `logalyzer/filters.py`, `url_regex_filter()`
- **Issue:** `re.match` only matches at the start of the string. A pattern like `"admin"` won't match `/admin/login` because the URL starts with `/`.
- **Test affected:** `test_url_regex_finds_substring_match`
- **Resolution:** Documented but not fixed. Out of scope for this refactor.

### 3. `MONTH_NAMES` is missing "Jul"
- **Location:** `logalyzer/parser.py`, `MONTH_NAMES` list
- **Issue:** The list has 11 entries — "Jul" is missing between "Jun" and "Aug". This causes `ValueError: 'Jul' is not in list` when parsing July timestamps.
- **Test affected:** `test_timestamp_july_parses_correctly`
- **Resolution:** Documented but not fixed. Out of scope for this refactor.

## Approaches considered and rejected

### Approach: Keep `output.py` as a thin shim alongside `output/` package
- **Rejected because:** Python doesn't allow a file and directory with the same name in the same package. We must delete `output.py` and replace it with `output/` directory.

### Approach: Move `format_legacy` from `utils.py` to `output/legacy.py`
- **Rejected because:** The task says "Don't change unrelated code" and `utils.py` is not part of the output module. Instead, `format_legacy` is imported into `output/__init__.py` from `utils.py` and re-exported, keeping `utils.py` unchanged.
