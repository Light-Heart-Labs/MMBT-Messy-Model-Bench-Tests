# Questions and Resolutions

## Q1: Should `render_aggregate` go into its own module?
**Resolution:** No. `render_aggregate` operates on aggregate results (Counter, dict, list) rather than `LogEntry` lists. It handles multiple output formats (text, json) for a different data type. Placing it in `__init__.py` keeps it accessible while avoiding the need for a separate module for a single function.

## Q2: Should `format_legacy` be moved from `utils.py` to `output/legacy.py`?
**Resolution:** No. The task says "Don't change unrelated code" and `utils.py` is not part of the output module. Instead, `output/legacy.py` imports and re-exports `format_legacy` from `utils.py`, keeping `utils.py` byte-identical.

## Q3: How to handle the `collections.Iterable` import error in Python 3.11?
**Resolution:** Added a root-level `conftest.py` that patches `collections.Iterable` before test collection. This is a test infrastructure fix, not a source code change. The `filters.py` file itself is left unchanged per task constraints.

## Q4: Should the pre-existing test failures be fixed?
**Resolution:** No. The task explicitly says "No bug fixes. If you encounter a bug, document it in dead-ends.md but don't fix it." All three pre-existing failures are documented in `research/dead-ends.md`.
