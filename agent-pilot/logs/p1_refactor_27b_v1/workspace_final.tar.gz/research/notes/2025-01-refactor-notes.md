# Research Notes

## 2025-01-XX: Initial analysis of output.py

Examined `logalyzer/output.py` and identified four distinct concerns:
1. `to_json()` — JSON serialization of LogEntry lists
2. `to_csv()` — CSV serialization of LogEntry lists  
3. `to_text()` — Plain-text formatting of LogEntry lists
4. `render_aggregate()` — Rendering of aggregate results (Counter, dict, list)

Also noted that `format_legacy()` lives in `utils.py` but must be importable from `logalyzer.output`.

## 2025-01-XX: Import analysis

Only one file imports from `logalyzer.output`:
- `cli.py`: `from .output import render_aggregate, to_csv, to_json, to_text`

No test files import from `logalyzer.output` directly.

## 2025-01-XX: Pre-existing bugs discovered

Three test failures exist in the original codebase:
1. `status_filter` doesn't handle string status codes (compares int to str)
2. `url_regex_filter` uses `re.match` instead of `re.search`
3. `MONTH_NAMES` is missing "Jul"

These are documented in `research/dead-ends.md` and not fixed per task constraints.

## 2025-01-XX: Python 3.11 compatibility

`collections.Iterable` was removed in Python 3.11. The `filters.py` module imports it. Added a root-level `conftest.py` to patch this before test collection, without modifying `filters.py` (which is out of scope).
