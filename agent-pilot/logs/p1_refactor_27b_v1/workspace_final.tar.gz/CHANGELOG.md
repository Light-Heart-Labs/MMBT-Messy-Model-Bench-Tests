# CHANGELOG

## v0.3.2 — Refactor: split `output.py` into `output/` package

### What changed
The single-file `logalyzer/output.py` module has been replaced by a `logalyzer/output/` package with focused submodules:

**Before:**
```
logalyzer/output.py          (single file with all output logic)
```

**After:**
```
logalyzer/output/
  __init__.py                Re-exports public API; contains render_aggregate
  json_renderer.py           to_json()
  csv_renderer.py            to_csv()
  plain_renderer.py          to_text()
  legacy.py                  format_legacy() re-export from utils.py
```

### What moved where
| Function | Old location | New location |
|---|---|---|
| `to_json` | `output.py` | `output/json_renderer.py` |
| `to_csv` | `output.py` | `output/csv_renderer.py` |
| `to_text` | `output.py` | `output/plain_renderer.py` |
| `render_aggregate` | `output.py` | `output/__init__.py` |
| `format_legacy` | `utils.py` (imported via `output.py`) | `output/legacy.py` (re-exported from `utils.py`) |

### Why
- Separation of concerns: each output format has its own module
- Easier to extend with new output formats
- Easier to test individual renderers in isolation
- Zero behavior change: all existing imports continue to work

### What did NOT change
- `logalyzer/parser.py` — unchanged
- `logalyzer/utils.py` — unchanged
- `logalyzer/cli.py` — unchanged
- `logalyzer/filters.py` — unchanged
- `logalyzer/aggregate.py` — unchanged
- `logalyzer/io.py` — unchanged
- `logalyzer/experimental.py` — unchanged
- All test files — byte-identical to original

### Verification results
1. **`pytest -q`** — 14 passed, 3 failed (same 3 pre-existing failures as original)
2. **`python -c "from logalyzer.output import format_legacy; print(format_legacy)"`** — works, prints `<function format_legacy at ...>`
3. **`diff -r /input/repo/tests tests`** — empty (tests are byte-identical)
4. **Non-output file diffs** — all empty (parser.py, utils.py, cli.py, etc. are byte-identical)

### Pre-existing bugs (not fixed, per task constraints)
1. `status_filter` doesn't handle string status codes (int vs str comparison)
2. `url_regex_filter` uses `re.match` instead of `re.search`
3. `MONTH_NAMES` is missing "Jul"

See `research/dead-ends.md` for details.
