"""Output formatters: JSON, CSV, plain text.

This module is a package that re-exports the public API from its submodules.
It replaces the old output.py single-file module.
"""
from __future__ import annotations

from .json_renderer import to_json
from .csv_renderer import to_csv
from .plain_renderer import to_text
from .legacy import format_legacy

# render_aggregate is defined here because it operates on aggregate results
# (Counter, dict, list) rather than LogEntry lists, so it doesn't belong in
# any single renderer module.


def render_aggregate(agg, fmt: str = "text") -> str:
    """Render an aggregate result (Counter, dict, list) as text/json/csv."""
    if fmt == "text":
        if hasattr(agg, "items"):
            return '\n'.join(f"{k}\t{v}" for k, v in agg.items())
        return '\n'.join(f"{k}\t{v}" for k, v in agg)
    elif fmt == "json":
        if hasattr(agg, "items"):
            items = list(agg.items())
        else:
            items = list(agg)
        parts = [f'"{k}":{v}' for k, v in items]
        return '{' + ','.join(parts) + '}'
    else:
        raise ValueError(f"unknown format: {fmt}")


__all__ = [
    "to_json",
    "to_csv",
    "to_text",
    "render_aggregate",
    "format_legacy",
]
