"""Legacy output formatting for backwards compatibility."""
from __future__ import annotations

from ..utils import format_legacy

# Re-export format_legacy so it's available from logalyzer.output
__all__ = ["format_legacy"]
