# Key Facts Incorporated in the Brief

Each fact below traces to one or more of the five source documents.

## Deal Structure & Valuation
| Fact | Source(s) |
|------|-----------|
| $84M Series B closed 2026-01-14 | [Source 1], [Source 5] |
| Post-money valuation: $560M | [Source 1] |
| Previous Series A valuation: $230M (2023) | [Source 1] |
| Total funding across all rounds: $128M | [Source 1] |
| 7 investors total | [Source 5] |
| Lead: Lightning Capital | [Source 1], [Source 5] |
| Participants: Sequoia, Accel, FedEx Ventures (strategic) | [Source 1], [Source 5] |
| 3 additional undisclosed investors | [Source 5] |
| Securities: Series B Preferred Equity | [Source 5] |
| Use of proceeds: "expansion, working capital, general corporate purposes" | [Source 5] |
| Series B was intended to close late 2025 at $720M valuation, repriced to $560M | [Source 2] |

## Revenue & Customers
| Fact | Source(s) |
|------|-----------|
| Company-reported ARR: $42M as of Q4 2025 | [Source 1] |
| ARR a year prior: $11M | [Source 1] |
| Adjusted run-rate ARR (post-churn): $36–37M | [Source 2] |
| Sundry Brands (largest customer, $4.2M ARR) did not renew in November 2025 | [Source 2] |
| Klatch (fast-fashion, top-5 customer) exited December 2025 | [Source 2] |
| Sundry non-renewal characterized by company as "strategic mutual decision" | [Source 2] |
| CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 | [Source 2] |
| CEO claims net retention above 110% | [Source 2] |
| Platform serves over 1,400 e-commerce brands | [Source 1] |
| Named customers: Maevia, Truant Coffee, Brick & Cobble | [Source 1] |
| Top 5 customers = ~38% of ARR | [Source 3] |

## Burn, Staffing & Restructuring
| Fact | Source(s) |
|------|-----------|
| Monthly burn: ~$4M/month (mid-2025) | [Source 3] |
| Monthly revenue: ~$3.5M/month (mid-2025) | [Source 3] |
| Net burn: ~$500K/month | [Source 3] |
| 22 layoffs (~11% of org) in February 2025, mostly customer success/BD | [Source 3] |
| Layoffs not publicly announced | [Source 3] |
| 187 employees across Oakland, Austin, Berlin | [Source 1] |
| Berlin headcount: 41, planned reduction to 28–30 by end Q2 2026 | [Source 4] |
| 30% reduction in international headcount | [Source 4] |
| International expansion deferred to 2027 | [Source 4] |
| Berlin reframed as "support hub" | [Source 4] |
| Nimbus Lite tier sunset: ~310 customers ($5K–$20K ARR each), 90-day notice | [Source 4] |
| $50M credit facility from Silicon Valley Bridge | [Source 4] |
| Credit facility described as "insurance, not operating capital" | [Source 4] |
| Runway: 24+ months at current burn, 36+ months with restructuring | [Source 4] |
| Target: operating-cash-flow breakeven by Q4 2026 | [Source 4] |

## Company Background
| Fact | Source(s) |
|------|-----------|
| Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) | [Source 1] |
| Platform: warehouse management + carrier orchestration + demand forecasting | [Source 1] |
| Offices: Oakland, Austin, Berlin | [Source 1] |
| Senior engineer compensation: $215K base + $50K equity/year | [Source 3] |

## Source Quality Notes
| Source | Type | Reliability Assessment |
|--------|------|----------------------|
| [Source 1] | Press release | Company narrative; accurate on deal terms but omits negatives |
| [Source 2] | TechCrunch article | Journalistic; cites unnamed sources; most reliable on churn/valuation |
| [Source 3] | Former-employee blog | One person's account; useful for burn/layoffs but not independently verified |
| [Source 4] | Leaked internal memo | Likely authentic given specificity; represents management's own assessment |
| [Source 5] | SEC Form D | Regulatory filing; most authoritative on deal structure |
