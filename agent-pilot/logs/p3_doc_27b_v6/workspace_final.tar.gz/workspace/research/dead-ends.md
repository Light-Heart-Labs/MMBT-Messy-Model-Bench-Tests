# Research Dead Ends

Ideas considered but abandoned during analysis.

## 1. Calculating Implied ARR Growth Rate
- **Idea:** Compute the exact year-over-year ARR growth from $11M to $42M (282% growth).
- **Abandoned:** The $42M figure is inflated by churn (adjusted to $36–37M), so the growth rate is less impressive. More importantly, the brief doesn't need the exact percentage — the tension between claimed and adjusted ARR is the more useful insight.

## 2. Analyzing FedEx Ventures' Strategic Investment
- **Idea:** Explore what FedEx Ventures' strategic investment means for distribution channels or integration opportunities.
- **Abandoned:** No source provides detail on what FedEx Ventures actually brings beyond capital. Speculating would violate the "no invented facts" rule.

## 3. Estimating Total Runway in Months
- **Idea:** Calculate exact runway from $84M + $50M credit facility against $4M/month burn.
- **Abandoned:** The memo already states "24+ months at current burn" and "36+ months" with restructuring. Re-calculating would be redundant and the memo's own numbers are the authoritative source.

## 4. Investigating the Three Undisclosed Investors
- **Idea:** Try to identify the three additional investors from the SEC Form D.
- **Abandoned:** The Form D summary explicitly states "individual names not disclosed." No source provides this information.

## 5. Assessing the Engineering Team Quality
- **Idea:** Use the former employee's praise of the codebase as a positive signal for product quality.
- **Abandoned:** This is included in the brief but kept brief. The one-employee perspective is not sufficient to make a strong positive case on its own, and the brief already notes it in the "Good" section.

## 6. Comparing to Industry Benchmarks
- **Idea:** Compare Nimbus's burn rate, customer concentration, and churn to logistics-tech industry averages.
- **Abandoned:** No industry benchmark data is available in the sources. This would require external research, which is prohibited.

## 7. Analyzing the "Nimbus Lite" Customer Segment
- **Idea:** Calculate the total ARR at risk from the Nimbus Lite sunset (~310 customers × $5K–$20K ARR).
- **Abandoned:** The range is too wide for a precise calculation ($1.55M–$6.2M). The fact that ~310 small customers are being pushed off the platform is the key insight, not the exact dollar amount.

## 8. Evaluating the CEO's Credibility
- **Idea:** Assess whether CEO Mira Patel's claims (110% net retention, 3 new $1M+ contracts) are credible.
- **Abandoned:** While the CEO's claims are noted, we cannot independently verify them. The brief mentions them as claims but doesn't endorse or reject them definitively — the right approach given source limitations.
