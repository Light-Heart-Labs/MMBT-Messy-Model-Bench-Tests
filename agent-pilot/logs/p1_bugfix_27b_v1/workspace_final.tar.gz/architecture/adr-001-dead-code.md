# ADR-001: Handling Dead Code and Unused Modules

## Status
Accepted

## Context
The codebase contains code that is not referenced anywhere in the
production code, tests, or benchmarks:

1. **`experimental.py`** — Entire module. Contains `detect_anomalies()`
   and `session_window()`. Not imported by any other module. Not wired
   into the CLI. The docstring says "Keep this file untouched for now —
   it's part of an in-progress feature."

2. **`utils.format_legacy()`** — Legacy formatter. Not called anywhere.
   Docstring says "retained for compatibility with the v0.1 CLI output."

3. **`utils.format_bytes()`** — Human-readable byte formatting. Not used
   anywhere in the codebase.

4. **`utils.chunked()`** — Generic chunking utility. Not used anywhere.

## Decision
- **Delete `experimental.py`**: The "in-progress feature" has been
  abandoned (no commits touching it, no CLI wiring, no tests). Keeping
  dead code increases maintenance burden and confuses new engineers.
  If the feature is needed later, it can be recreated from git history.

- **Delete `format_legacy`, `format_bytes`, and `chunked` from `utils.py`**:
  These are unused. `parse_iso_date` is the only function in utils.py
  that is actually imported (by cli.py). The remaining functions add
  no value and increase the surface area for bugs.

- **Keep `utils.py`** with only `parse_iso_date`: The module still has
  one active function and serves as a reasonable home for shared
  utilities. Renaming or inlining it would be a larger refactor with
  no clear benefit.

## Consequences
- Reduced code surface area
- Fewer imports to maintain
- New engineers won't be confused by dead code
- If any of these functions are needed later, they can be restored from
  git history (commit `c5dd428`)
