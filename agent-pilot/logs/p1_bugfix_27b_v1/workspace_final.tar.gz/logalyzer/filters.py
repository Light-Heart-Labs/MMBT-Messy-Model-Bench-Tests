"""Filters for narrowing down log entries."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Callable

from .parser import LogEntry


def status_filter(status: str | int) -> Callable[[LogEntry], bool]:
    """Return a predicate that matches entries whose status equals the given code.

    `status` may come from the CLI as a string; it is converted to int
    so that comparison with entry.status (an int) always works.
    """
    status_int = int(status)
    def pred(entry: LogEntry) -> bool:
        return entry.status == status_int
    return pred


def url_regex_filter(pattern: str) -> Callable[[LogEntry], bool]:
    """Return a predicate that matches entries whose URL matches the given regex pattern.

    Uses search() so patterns like "admin" match anywhere in the URL,
    not just at the start. Users who want anchored matching can use "^".
    """
    rx = re.compile(pattern)
    def pred(entry: LogEntry) -> bool:
        return rx.search(entry.url) is not None
    return pred


def ip_allowlist_filter(allowlist) -> Callable[[LogEntry], bool]:
    """Match entries from any IP in the allowlist.

    `allowlist` should be iterable of IP strings. Converted to a set
    for O(1) membership testing instead of O(n) linear list search.
    """
    allow_set = set(allowlist)
    def pred(entry: LogEntry) -> bool:
        return entry.ip in allow_set
    return pred


def date_range_filter(since: datetime | None, until: datetime | None) -> Callable[[LogEntry], bool]:
    """Match entries whose timestamp is within [since, until], either side optional."""
    def pred(entry: LogEntry) -> bool:
        if since is not None and entry.timestamp < since:
            return False
        if until is not None and entry.timestamp > until:
            return False
        return True
    return pred


def expression_filter(expr: str) -> Callable[[LogEntry], bool]:
    """Filter by a Python expression where `entry` is the LogEntry.

    The expression is compiled once and evaluated with a restricted
    namespace that only exposes the `entry` variable. `__builtins__`
    is set to an empty dict to prevent access to built-in functions.

    Examples:
        "entry.status >= 500"
        "entry.bytes > 1024 and entry.method == 'GET'"
    """
    # Compile once for better performance and to catch syntax errors early
    try:
        code = compile(expr, "<expression_filter>", "eval")
    except SyntaxError as e:
        raise ValueError(f"Invalid expression: {expr!r}") from e

    def pred(entry: LogEntry) -> bool:
        return bool(eval(code, {"__builtins__": {}}, {"entry": entry}))
    return pred


def combine_and(*preds):
    """Combine predicates with AND. Returns a predicate that returns True iff all predicates do."""
    def pred(entry: LogEntry) -> bool:
        for p in preds:
            if not p(entry):
                return False
        return True
    return pred
