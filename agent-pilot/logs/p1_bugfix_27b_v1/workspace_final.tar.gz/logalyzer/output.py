"""Output formatters: JSON, CSV, plain text."""
from __future__ import annotations

import csv
import io
import json
from typing import Any, Iterable

from .parser import LogEntry


def to_json(entries: Iterable[LogEntry]) -> str:
    """Render entries as a JSON array."""
    objects = []
    for e in entries:
        objects.append({
            "ip": e.ip,
            "user": e.user,
            "timestamp": e.timestamp.isoformat(),
            "method": e.method,
            "url": e.url,
            "protocol": e.protocol,
            "status": e.status,
            "bytes": e.bytes,
        })
    return json.dumps(objects)


def to_csv(entries: Iterable[LogEntry]) -> str:
    """Render entries as CSV (with header row)."""
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["ip", "user", "timestamp", "method", "url", "protocol", "status", "bytes"])
    for e in entries:
        w.writerow([e.ip, e.user, e.timestamp.isoformat(), e.method, e.url, e.protocol, e.status, e.bytes])
    return buf.getvalue()


def to_text(entries: Iterable[LogEntry]) -> str:
    """Render entries as readable plain text, one entry per line."""
    lines = []
    for e in entries:
        lines.append(
            f'{e.timestamp.isoformat()}  {e.ip:>15}  {e.method:<6} {e.status} {e.url}'
        )
    return '\n'.join(lines)


def render_aggregate(agg: Any, fmt: str = "text") -> str:
    """Render an aggregate result (Counter, dict, list) as text/json/csv."""
    if fmt == "text":
        if hasattr(agg, "items"):
            return '\n'.join(f"{k}\t{v}" for k, v in agg.items())
        return '\n'.join(f"{k}\t{v}" for k, v in agg)
    elif fmt == "json":
        if hasattr(agg, "items"):
            items = dict(agg.items())
        else:
            items = {k: v for k, v in agg}
        return json.dumps(items)
    elif fmt == "csv":
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["key", "value"])
        if hasattr(agg, "items"):
            for k, v in agg.items():
                w.writerow([k, v])
        else:
            for k, v in agg:
                w.writerow([k, v])
        return buf.getvalue()
    else:
        raise ValueError(f"unknown format: {fmt}")
