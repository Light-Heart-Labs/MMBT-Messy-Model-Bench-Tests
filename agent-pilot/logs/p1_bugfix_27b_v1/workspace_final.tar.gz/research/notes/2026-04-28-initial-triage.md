# Initial Triage — 2026-04-28

## Issues Found

### Critical (blocks execution)
1. **C1**: `from collections import Iterable` in filters.py — removed in Python 3.10. Causes ImportError on module load. Also unused.

### High (bugs that produce wrong results)
2. **H1**: `status_filter` compares `entry.status == status` where status can be a string from CLI. `200 == "200"` is False in Python.
3. **H2**: `url_regex_filter` uses `rx.match()` which only matches at start of string. Test expects substring matching.
4. **H3**: `by_hour` uses `time.localtime()` which converts to local timezone, not UTC. Test expects UTC bucketing.
5. **H4**: `output.to_json` hand-rolls JSON without escaping special characters (quotes, backslashes in URLs/users).

### Medium (performance, security, maintainability)
6. **M1**: `io.load()` does character-by-character string concatenation — O(n²) behavior.
7. **M2**: `ip_allowlist_filter` does linear search in list — O(n) per lookup.
8. **M3**: `expression_filter` uses `eval()` — security risk even with `__builtins__={}`.
9. **M4**: `cli.py` aggregate CSV output passes "text" format to `render_aggregate` instead of handling CSV properly.

### Low (dead code, documentation, style)
10. **L1**: `experimental.py` — not imported anywhere, not wired into CLI.
11. **L2**: `utils.format_legacy` — not used anywhere.
12. **L3**: `utils.chunked` — not used anywhere.
13. **L4**: README claims "Real-time tail mode" — doesn't exist.
14. **L5**: README says "feature-complete and ready for production use" — clearly not.
15. **L6**: Version mismatch: pyproject.toml says 0.3.1, __init__.py says 0.2.0.
16. **L7**: Unused import `datetime` in test_parser.py.
