# Decision: Document Bugs in Codebase

**Date:** 2024-04-28

## Summary

The starter codebase contains several bugs that prevent some tests from passing. These bugs are documented here but not fixed, per the task requirement: "If you find a bug, document it but don't fix it."

## Bugs Identified

### Bug 1: Deprecated `Iterable` import in `filters.py`

**Location:** `logalyzer/filters.py:5`

**Issue:** The code uses `from collections import Iterable`, but `Iterable` was moved to `collections.abc` in Python 3.9+. This causes an `ImportError` on Python 3.11.

**Workaround:** The conftest.py file monkey-patches `collections.Iterable` to point to `collections.abc.Iterable`.

**Impact:** Without the workaround, no tests can run.

**Decision:** Keep the workaround in conftest.py. Do not modify filters.py.

---

### Bug 2: Status filter doesn't handle string inputs

**Location:** `logalyzer/filters.py:13-16`

**Issue:** The `status_filter` function compares `entry.status` (an int) directly with the `status` parameter. When the CLI passes `--status "404"` as a string, the comparison `entry.status == status` fails because `200 != "200"`.

**Current behavior:**
```python
def status_filter(status: str | int) -> Callable[[LogEntry], bool]:
    def pred(entry: LogEntry) -> bool:
        return entry.status == status  # Fails when status is a string
    return pred
```

**Expected behavior:** The comparison should handle both int and string inputs.

**Decision:** Do not fix. Document in dead-ends.md.

---

### Bug 3: URL regex filter uses `match()` instead of `search()`

**Location:** `logalyzer/filters.py:25-28`

**Issue:** The `url_regex_filter` uses `rx.match(entry.url)` which only matches at the beginning of the string. The test expects substring matching (e.g., "admin" should match "/admin/login").

**Current behavior:**
```python
def url_regex_filter(pattern: str) -> Callable[[LogEntry], bool]:
    rx = re.compile(pattern)
    def pred(entry: LogEntry) -> bool:
        return rx.match(entry.url) is not None  # Only matches at start
    return pred
```

**Expected behavior:** Should use `rx.search(entry.url)` for substring matching.

**Decision:** Do not fix. Document in dead-ends.md.

---

### Bug 4: Missing "Jul" in MONTH_NAMES

**Location:** `logalyzer/parser.py:24-29`

**Issue:** The MONTH_NAMES list is missing "Jul". The list is:
```python
MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Aug", "Sep", "Oct", "Nov", "Dec",
]
```

Notice "Jul" is missing between "Jun" and "Aug".

**Current behavior:** Parsing a timestamp with "Jul" raises `ValueError: 'Jul' is not in list`.

**Expected behavior:** "Jul" should be in the list at index 6 (month 7).

**Decision:** Do not fix. Document in dead-ends.md.

---

## Tests Affected

The following tests fail due to these bugs:

1. `test_status_filter_works_with_cli_string_input` - Bug 2
2. `test_url_regex_finds_substring_match` - Bug 3
3. `test_timestamp_july_parses_correctly` - Bug 4

These tests are part of the original test suite and are documented as failing due to bugs in the codebase.

## Next Steps

Proceed to add new tests for uncovered code paths in:
- `experimental.py` (0% coverage)
- `format_legacy()` in `output.py` (uncovered)
- Edge cases in `utils.py`
- Edge cases in `filters.py`
- Edge cases in `aggregate.py`
