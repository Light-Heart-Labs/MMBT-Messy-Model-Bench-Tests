"""Shared pytest fixtures."""
import sys
import collections
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Workaround for deprecated import in logalyzer/filters.py
# In Python 3.9+, Iterable was moved from collections to collections.abc
# The codebase still uses the old import which causes ImportError
if not hasattr(collections, 'Iterable'):
    import collections.abc
    collections.Iterable = collections.abc.Iterable
