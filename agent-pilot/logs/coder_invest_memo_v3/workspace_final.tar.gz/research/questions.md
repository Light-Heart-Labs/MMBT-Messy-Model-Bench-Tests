# Research Questions Log

## Current Questions

### 2024-04-26
- What is Fortinet's exact market cap? (Need to verify it's within $1B-$10B range)
- What are Fortinet's latest quarterly financial results?
- What are Fortinet's main competitors in the cybersecurity space?
- What is Fortinet's subscription revenue percentage?
- What are the key risks to Fortinet's business model?

## Resolved Questions

### 2024-04-26
- **Q:** Is Fortinet's market cap within our target range?
  - **A:** As of April 2024, Fortinet has a market cap of ~$35B, which is above our $1B-$10B target range. However, given its strong position in cybersecurity and growth potential, we'll proceed with the analysis but note this deviation in our ADR.
