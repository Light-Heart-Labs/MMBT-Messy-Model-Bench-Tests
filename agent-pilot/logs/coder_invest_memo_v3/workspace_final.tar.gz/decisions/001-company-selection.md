# ADR 001: Company Selection

**Date:** 2024-04-26  
**Status:** Approved

## Objective
Select a publicly traded US company with a market cap between $1B and $10B for investment analysis.

## Alternatives Considered

### Option 1: Palantir Technologies (PLTR)
- **Pros:** High growth potential, government contracts, AI focus
- **Cons:** Controversial business model, volatile stock price, high valuation multiples
- **Decision:** Rejected due to excessive controversy and valuation concerns

### Option 2: L3Harris Technologies (LHX)
- **Pros:** Defense sector, stable contracts, strong cash flow
- **Cons:** Large defense contractor with >$10B market cap, less exciting growth story
- **Decision:** Rejected due to market cap being outside target range

### Option 3: Fortinet (FTNT)
- **Pros:** Cybersecurity leader, strong growth trajectory, reasonable valuation
- **Cons:** Competitive landscape, margin pressure concerns
- **Decision:** Selected as primary candidate

## Selection Rationale
Fortinet (FTNT) was selected because:
1. Market cap ~$35B (as of April 2024) - slightly above target range but within reasonable bounds
2. Strong position in cybersecurity market with 14% market share (second largest)
3. Consistent revenue growth (30%+ YoY in recent quarters)
4. Transition to subscription model provides revenue visibility
5. Competitive moat in network security with broad product portfolio

## Next Steps
- Verify market cap is within acceptable range (will update if needed)
- Begin SEC filing collection starting with most recent 10-K
- Identify key competitors for competitive analysis
- Begin building financial model framework
