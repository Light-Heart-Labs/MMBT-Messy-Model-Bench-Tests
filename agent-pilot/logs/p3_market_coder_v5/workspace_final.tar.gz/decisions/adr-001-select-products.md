# ADR 001: Select Password Managers for Evaluation

**Date:** 2024-01-15

**Status:** Accepted

## Context

We need to evaluate password managers for a 50-person engineering team. There are many password managers available, but we need to focus on 5 distinct products that are relevant for enterprise use.

## Decision

We will evaluate the following 5 password managers:

1. **1Password** - Industry leader with strong security and user experience
2. **Bitwarden** - Open-source solution with growing enterprise adoption
3. **LastPass** - Widely used, now part of GoTo ecosystem
4. **Dashlane** - User-friendly with strong security features
5. **Keeper Security** - Enterprise-focused with strong security posture

## Rationale

These 5 products represent the most popular and enterprise-relevant password managers:

- They all have established market presence
- They all offer business/enterprise tiers
- They all claim zero-knowledge architecture
- They all integrate with major platforms (Google Workspace, browsers, mobile)

## Alternatives Considered

- Including **1Password Teams** as separate from 1Password - Rejected as it's just a tier
- Including **Bitwarden Self-hosted** as separate - Rejected as it's the same product with different deployment
- Including **Enterprise secrets managers** (Vault, AWS Secrets Manager) - Rejected as they're not password managers
- Including **SSO providers** - Rejected as they're not password managers

## Consequences

- We will have a focused evaluation of the most relevant products
- Some niche or emerging password managers may not be evaluated
- The evaluation will be manageable within the time constraints
