# ADR 002: Define Password Manager Evaluation Criteria

**Date:** 2024-01-15

**Status:** Accepted

## Context

We need to establish objective criteria to evaluate password managers and determine which is "best for this team."

## Decision

We will evaluate password managers based on the following criteria:

### Must-Have Criteria

1. **SSO Integration with Google Workspace** - The company uses Google Workspace, so SSO integration is essential
2. **SOC 2 Type II Compliance** - Required for our Series-B company; must be verified on official trust page
3. **Zero-Knowledge Architecture** - All sensitive data must be encrypted client-side
4. **Multi-Factor Authentication** - Support for multiple MFA methods (TOTP, push notifications, hardware keys)
5. **Desktop & Mobile Support** - Must have apps for Windows, macOS, Linux, iOS, and Android
6. **Browser Extensions** - Must support Chrome, Firefox, Safari, and Edge

### Important Criteria

7. **Admin Controls** - User provisioning (SCIM), audit logs, emergency access
8. **Pricing Transparency** - Per-seat pricing should be publicly listed or easily obtainable
9. **Developer Tool Integration** - GitHub/GitLab integration, IDE extensions (VS Code, IntelliJ)
10. **Breach Monitoring** - Automatic monitoring for compromised credentials

### Nice-to-Have Criteria

11. **FedRAMP Compliance** - Bonus for government-related work
12. **API Access** - For automation and integration with other tools
13. **Team Folders/Permissions** - Granular access control for sensitive data

## Rationale

These criteria reflect the specific needs of our 50-person engineering team:

- SSO with Google Workspace is non-negotiable for our existing infrastructure
- SOC 2 Type II is required for our business and customer trust
- Zero-knowledge architecture is fundamental to password manager security
- MFA and platform support are essential for adoption and security
- Admin controls are critical for IT management at our scale
- Developer tool integration will improve adoption among engineers

## Consequences

- Some password managers may fail to meet must-have criteria and be eliminated
- We will need to verify compliance claims on official sources, not marketing materials
- We may need to contact sales for pricing information if not publicly listed
- The evaluation will be focused and objective, reducing bias
