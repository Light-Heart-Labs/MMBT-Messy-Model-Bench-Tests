# Working Research Notes

## Initial Brainstorm of Password Managers

### Top Candidates (by market presence and relevance)
1. 1Password - Strong consumer and business reputation
2. Bitwarden - Open-source, growing enterprise adoption
3. LastPass - Widely used, acquired by LogMeIn (now GoTo)
4. Dashlane - User-friendly, strong security posture
5. Keeper Security - Enterprise-focused, strong security

### Potential Contenders (rejected for scope)
- **1Password Teams** - Actually just a tier of 1Password, not separate product
- **Bitwarden Self-hosted** - Worth noting as an alternative but not primary evaluation
- **Enterprise secrets managers** (HashiCorp Vault, AWS Secrets Manager) - Not password managers per se
- **SSO providers** (Okta, Auth0) - Not password managers

## Initial Decision Criteria

1. **SSO Integration**: Must integrate with Google Workspace (SAML 2.0)
2. **Compliance**: SOC 2 Type II is essential; FedRAMP is a plus
3. **Pricing**: Transparent per-seat pricing; annual billing preferred
4. **Admin Controls**: User provisioning (SCIM), audit logs, emergency access
5. **Platform Support**: Desktop (Windows, macOS, Linux), mobile (iOS, Android), browser extensions
6. **Developer Tools**: Integration with GitHub, GitLab, IDEs (VS Code, IntelliJ)
7. **Security Features**: Zero-knowledge architecture, multi-factor authentication, breach monitoring

## Next Steps

1. Research each product's official website for features and pricing
2. Check third-party reviews for unbiased comparisons
3. Verify compliance certifications on official trust pages
4. Look for any security incidents or vulnerabilities
5. Compile findings into comparison matrix
6. Write recommendation memo
