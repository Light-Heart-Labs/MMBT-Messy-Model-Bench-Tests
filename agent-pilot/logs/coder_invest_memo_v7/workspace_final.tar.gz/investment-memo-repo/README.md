# Investment Memo Repository

This repository contains a complete investment memo for a publicly traded US company with a market cap between $1B and $10B.

## Repository Structure

```
/memo/                  Final memo (PDF + source markdown)
/model/                 Three-statement financial model (xlsx)
/raw/
  /filings/             Every SEC filing you downloaded, original format
  /transcripts/         Every earnings call transcript, original source
  /other/               Any other primary source (press releases, etc.)
/extracted/             Parsed/cleaned data from /raw/, with extraction scripts
/analysis/              Notebooks and scripts for any analysis you ran
/research/
  /notes/               Working notes, dated, one file per research session
  /questions.md         Running list of questions you had and how you resolved them
  /dead-ends.md         Things you investigated that didn't pan out, with why
/decisions/             ADR-style decision records for every non-obvious choice
/sources.md             Every URL you fetched, with timestamp and SHA of content
/tool-log.md            Every tool call, in order, with a one-line justification
README.md               This file
```

## How to Navigate This Repository

1. **Start with the memo** (`/memo/memo.md`) - This is the final investment thesis and recommendation.

2. **Follow the trail of evidence**:
   - Every number in the memo should have a traceable path back to SEC filings
   - Check `/extracted/` for cleaned data used in the model
   - Review `/model/` for the financial model itself
   - Verify sources in `/raw/` and `/sources.md`

3. **Understand the decision-making process**:
   - Read `/decisions/` to see how key choices were made
   - Check `/research/questions.md` for questions that arose during research
   - Review `/research/dead-ends.md` for paths that were investigated but didn't pan out

4. **Audit the analysis**:
   - Check `/analysis/` for notebooks and scripts that support the conclusions
   - Verify all external claims against `/sources.md`

## Company Selection

This memo covers **[Company Name]**, a mid-cap technology company with a market cap of approximately $[X]B.

## Last Updated

[Date]
