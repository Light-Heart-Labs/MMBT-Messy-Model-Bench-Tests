# Initial Research Session - 2025-04-26

## Objective
Identify a publicly traded US company with a market cap between $1B and $10B for investment analysis.

## Approach
1. Research mid-cap technology companies (sector I'm familiar with)
2. Filter by market cap range ($1B-$10B)
3. Look for companies with interesting business models or competitive positions

## Initial Company List
- **Nutanix (NTNX)** - Cloud infrastructure and hybrid cloud management
  - Market cap: ~$5.5B
  - Revenue (FY2024): ~$1.4B
  - Growth rate: ~14% YoY
  
- **Snowflake (SNOW)** - Cloud data warehousing
  - Market cap: ~$95B (too large)
  
- **Palantir (PLTR)** - Data analytics
  - Market cap: ~$75B (too large)
  
- **Datadog (DDOG)** - Cloud monitoring
  - Market cap: ~$45B (too large)
  
- **Palo Alto Networks (PANW)** - Cybersecurity
  - Market cap: ~$85B (too large)
  
- **Zscaler (ZS)** - Cloud security
  - Market cap: ~$35B (too large)
  
- **MongoDB (MDB)** - Database software
  - Market cap: ~$25B (too large)
  
- **Workday (WDAY)** - Cloud HR and finance software
  - Market cap: ~$40B (too large)
  
- **ServiceNow (NOW)** - IT service management
  - Market cap: ~$70B (too large)
  
- **Okta (OKTA)** - Identity management
  - Market cap: ~$8B
  - Revenue (FY2024): ~$1.5B
  - Growth rate: ~20% YoY

- **Docusign (DOCU)** - Electronic signature platform
  - Market cap: ~$7B
  - Revenue (FY2024): ~$1.3B
  - Growth rate: ~10% YoY

- **Couchbase (CBSE)** - NoSQL database
  - Market cap: ~$1.2B
  - Revenue (FY2024): ~$150M
  - Growth rate: ~25% YoY

## Initial Screening
Based on initial screening, the following companies appear to be in the target market cap range:
1. Nutanix (NTNX) - $5.5B
2. Okta (OKTA) - $8B
3. Docusign (DOCU) - $7B
4. Couchbase (CBSE) - $1.2B

## Next Steps
1. Conduct deeper research on Nutanix as a potential candidate
2. Review SEC filings to understand business model and financials
3. Analyze competitive positioning and growth prospects

## Questions
- Is Nutanix's business model sustainable given competition from hyperscalers?
- How does Nutanix's subscription transition impact revenue recognition?
- What is Nutanix's competitive advantage in the hybrid cloud management space?
