# Research Questions Log

This document tracks questions that arose during research and how they were resolved.

## Initial Questions

### Q1: Which company should be selected for analysis?
**Question**: How do I identify a suitable company in the $1B-$10B market cap range with interesting investment dynamics?

**Resolution**: Conducted initial research on mid-cap technology companies and identified Nutanix (NTNX) as a promising candidate with:
- Market cap of ~$5.5B
- Transition to subscription model
- Competitive positioning in hybrid cloud management
- Recent financial performance showing growth acceleration

**Status**: Resolved - Nutanix selected for detailed analysis

### Q2: What is Nutanix's business model?
**Question**: How does Nutanix make money, and what are its key products and services?

**Resolution**: Reviewed Nutanix's latest 10-K and found:
- Three main product categories: Cloud Infrastructure, Cloud Management, and Cloud Data Services
- Transitioned to a subscription model in FY2023
- Revenue recognition changes significantly impacted financial statements
- Enterprise Value (EV) multiples are more appropriate than P/E due to debt

**Status**: Resolved - Business model understood

### Q3: What are Nutanix's competitive advantages?
**Question**: How does Nutanix compete against hyperscalers (AWS, Azure, GCP) and other infrastructure providers?

**Resolution**: Identified key competitive advantages:
- Hybrid and multi-cloud management capabilities
- Enterprise customer trust and existing relationships
- Software-defined infrastructure that runs on any hardware
- Strong partner ecosystem

**Status**: Resolved - Competitive advantages identified

### Q4: How does Nutanix's subscription transition affect financial analysis?
**Question**: What adjustments are needed to analyze Nutanix's financials given the subscription model transition?

**Resolution**: Need to:
- Focus on subscription revenue growth rather than total revenue
- Analyze deferred revenue as a growth indicator
- Use EV/Subscription Revenue multiple instead of P/E
- Consider cash flow from operations rather than net income

**Status**: Resolved - Financial analysis approach defined

### Q5: What is the competitive landscape for Nutanix?
**Question**: Who are Nutanix's main competitors, and how does it stack up against them?

**Resolution**: Identified key competitors:
- **Hyperscalers**: AWS, Microsoft Azure, Google Cloud Platform (primary competition)
- **Traditional infrastructure providers**: VMware, Cisco, HPE
- **Specialized competitors**: VMware (virtualization), Red Hat (open source), Oracle (database)

**Status**: Resolved - Competitive landscape mapped

### Q6: What are the key risks for Nutanix?
**Question**: What are the most significant risks to Nutanix's business and stock price?

**Resolution**: Identified key risks:
- Competition from hyperscalers
- Execution risk in sales organization
- Integration risk from acquisitions (e.g., Acme Systems)
- Macroeconomic impact on enterprise IT spending
- Dependency on key partners (e.g., Cisco)

**Status**: Resolved - Key risks documented

## Ongoing Questions

### Q7: What is a reasonable growth rate for Nutanix?
**Question**: What growth rate should be used in the DCF model, and what is the evidence?

**Status**: Pending - Requires deeper analysis of historical growth and market opportunity

### Q8: What is a reasonable discount rate for Nutanix?
**Question**: What WACC should be used given Nutanix's beta and capital structure?

**Status**: Pending - Requires calculation of beta and capital structure analysis

### Q9: What is the terminal growth rate assumption?
**Question**: What is a reasonable long-term growth rate for Nutanix?

**Status**: Pending - Requires industry growth rate research

### Q10: What is the sell-side consensus, and where might the market be wrong?
**Question**: How does Nutanix's current valuation compare to consensus, and what might the market be mispricing?

**Status**: Pending - Requires review of analyst reports and consensus estimates
