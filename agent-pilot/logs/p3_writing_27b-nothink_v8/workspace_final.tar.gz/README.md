# Incident Rewrite Output

This directory contains three audience-tailored rewrites of an internal engineering memo documenting a 4-hour API outage on Friday (14:11–18:24 UTC). Each rewrite is constrained by the specifications in `/input/repo/audience_briefs.json`.

## Files

| File | Audience | Max Words | Actual Words |
|------|----------|-----------|-------------|
| `ceo_brief.md` | CEO / Board prep | 250 | 202 |
| `customer_email.md` | Affected customers | 350 | 260 |
| `legal_summary.md` | In-house counsel | 400 | 253 |
| `decisions/adr-001-007.md` | Internal | — | — |
| `research/notes.md` | Working notes | — | — |

## How to Read

Each rewrite draws exclusively from the source memo at `/input/repo/draft_memo.md`. No facts were invented; all numbers, times, and counts are traceable to the source. The `decisions/` directory contains ADR-style records explaining non-obvious editorial choices (e.g., why named individuals were omitted, why the "second outage in 90 days" framing appears only in the CEO brief). The `research/notes.md` file contains extracted facts and per-audience decision rationale used during the rewrite process.
