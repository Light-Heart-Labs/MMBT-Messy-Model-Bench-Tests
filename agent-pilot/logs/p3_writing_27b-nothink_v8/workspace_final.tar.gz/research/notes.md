# Working Notes — Incident Rewrite Project

## Source Material
- `/input/repo/draft_memo.md` — ~1500-word internal memo from senior engineering manager
- `/input/repo/audience_briefs.json` — per-audience constraints

## Key Facts Extracted from Source Memo

### Timeline
- **14:09 UTC** — Config change deployed (rate-limit thresholds doubled)
- **~14:11 UTC** — Outage begins (502s returned)
- **~14:51 UTC** — Status page still green (wrong endpoint check)
- **~15:11 UTC** — First hour spent on LB health checks (green)
- **~15:11+ UTC** — Priya notices 100% throttle rate on internal limiter
- **18:18 UTC** — Config change reverted
- **18:24 UTC** — Full traffic recovery
- **Total duration:** ~4 hours 13 minutes (14:11–18:24 UTC)

### Impact
- **11,400 customer accounts** impacted
- **28 enterprise accounts** (with named CSMs) had real revenue impact during business hours
- **4 known cases** of downstream automation breakage requiring manual cleanup
- **217 inbound support tickets**
- **31 refund requests** (mix of SLA-credit-only and full-month credit)

### Root Cause
- Config change doubled rate-limit thresholds for internal auth service
- Internal limiter uses a fraction computed against a hard-coded MAX value (not the new configured value)
- Result: ALL inbound auth requests throttled → auth fails → API fails → 502s

### SLA
- Contractual SLA: 99.9% monthly uptime
- Nominally breached for affected accounts
- Legal stance: do not contest credit requests where SLA clearly breached

### Board Signal
- Second 4+ hour outage in 2026 (first was February, database storage issue)
- Second data point in 90 days; a third would trigger reliability program overhaul conversation

### Remediations
1. Add per-region staged config rollout (canary for config) — ~1 sprint, Pri 1
2. Fix internal limiter to compute fraction against actual global config, not constant — ~2 weeks
3. Status-page check already fixed (Friday evening) — was pointing at /healthz on fixed instance
4. New comms policy: on-call commander issues "we see it" message within 15 min
5. Runbook update for "502s widespread but LB green" scenario

## Per-Audience Decisions

### CEO Brief (≤250 words)
- Include: one-line summary, scope (11,400 accounts, 28 enterprise with revenue impact), second-occurrence-in-90-days framing, top remediations
- Exclude: engineering jargon, named individuals, "sorry Sarah", fraction/MAX details
- Tone: concise, executive, direct

### Customer Email (≤350 words)
- Include: outage acknowledgement, plain-language root cause, commitments, SLA credit offer, contact path
- Exclude: named engineer (Marcus), "second outage in 90 days", engineering jargon, internal candor about warnings
- Tone: warm, accountable, active voice, no corporate hedging

### Legal Summary (≤400 words)
- Include: exact time window with timezone, account count and tier breakdown, SLA threshold (99.9%), 4 downstream-automation cases, credit-request handling recommendation
- Exclude: speculation, named-employee blame, informal candor, marketing language, engineering remediation details
- Tone: precise, factual, dispassionate, use "incident" not "outage"
