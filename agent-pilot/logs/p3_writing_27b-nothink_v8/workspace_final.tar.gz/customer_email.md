Subject: What Happened on Friday and What We're Doing About It

Dear customer,

On Friday between 14:11 and 18:24 UTC, our primary API returned errors for approximately 4 hours. We know this disrupted your operations, and we take full responsibility.

**What happened:** A configuration change we deployed to improve our authentication service had an unintended side effect. Instead of reducing restrictions as intended, it triggered an internal safeguard that blocked all authentication requests. Without successful authentication, our API could not process your requests. We also failed to detect the problem promptly — our status page was monitoring the wrong endpoint, so it showed "all clear" while you were experiencing errors.

**What we're doing differently:**
- We are adding staged rollouts for configuration changes so future updates reach a small subset of systems first, giving us time to catch problems before they affect everyone.
- We are fixing the internal safeguard so it responds correctly to configuration changes.
- Our status page now monitors the same endpoints you use, so it will accurately reflect service health.
- We are implementing a policy to send you a proactive update within 15 minutes of any confirmed disruption, even before we know the full cause.

**SLA credit:** If your account was impacted, you are entitled to an SLA credit per our service agreement. To request your credit, contact your customer success manager or reach out to support. We will process all valid requests promptly.

We understand that trust is earned through action, not words. We are committed to doing better.

Sincerely,
The Engineering Team
