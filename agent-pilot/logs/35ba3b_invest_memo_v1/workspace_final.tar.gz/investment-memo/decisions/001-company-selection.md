# ADR-001: Company Selection — GitLab Inc. (GTLB)

## Context
We need a publicly traded US company with market cap between $1B and $10B for a complete investment memo. The company should have sufficient data available (SEC filings, analyst coverage, earnings transcripts) to support a rigorous analysis.

## Decision
Selected **GitLab Inc. (GTLB)**, currently trading at ~$21.50 with a market cap of ~$3.7B.

## Alternatives Considered
1. **Elastic (ESTC)** — ~$4.8B market cap, similar DevOps/developer tools space. Rejected because GitLab has a more compelling "platform play" narrative with clearer path to profitability and stronger AI positioning (GitLab Duo).
2. **SentinelOne (S)** — ~$4.8B market cap, cybersecurity. Rejected because the security space is more crowded and GitLab's DevSecOps positioning gives it a unique wedge.
3. **BILL Holdings (BILL)** — ~$3.7B market cap, fintech SaaS. Rejected because billing/payments has more regulatory complexity and less clear competitive moat.
4. **nClick (NCNO)** — ~$2B market cap, banking software. Rejected because smaller TAM and less analyst coverage.
5. **Varonis (VRNS)** — ~$2.9B market cap, data security. Rejected because more niche positioning and smaller TAM.

## Rationale
GitLab was selected because:
- **Clear business model**: Pure-play SaaS with transparent metrics (ARR, NRR, gross margins)
- **Strong competitive position**: Only true single-application DevSecOps platform
- **AI catalyst**: GitLab Duo (AI coding assistant) is a meaningful new revenue driver
- **Path to profitability**: Company has demonstrated ability to generate FCF while growing 20%+
- **Data availability**: 24 analyst covers, regular SEC filings, quarterly earnings transcripts
- **Attractive valuation**: Trading at ~3.8x sales vs. historical averages, down ~54% from 52-week high
- **Balance sheet**: $1.26B cash, zero debt — strong financial position
- **Market cap sweet spot**: $3.7B is large enough for institutional interest but small enough for meaningful re-rating

## Sources
- yfinance screening data (see /analysis/screening.ipynb)
- Company website: https://about.gitlab.com
