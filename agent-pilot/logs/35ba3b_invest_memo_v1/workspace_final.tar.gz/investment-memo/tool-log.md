# Tool Log

| # | Tool | Command | Justification |
|---|------|---------|---------------|
| 1 | bash | git init | Initialize the git repository for the investment memo project |
| 2 | bash | mkdir -p | Create the required directory structure |
| 3 | bash | pip install | Install Python dependencies for data fetching and analysis |
| 4 | bash | python screening script | Screen for companies in $1B-$10B market cap range |
| 5 | bash | python yfinance fetch | Fetch financial data for candidate companies |
| 6 | bash | curl SEC EDGAR | Download 10-K filings for selected company |
| 7 | bash | curl earnings transcripts | Download earnings call transcripts |
| 8 | bash | python extraction scripts | Parse and clean data from filings |
| 9 | bash | python financial model | Build three-statement financial model |
| 10 | bash | python memo generation | Generate the final investment memo |

