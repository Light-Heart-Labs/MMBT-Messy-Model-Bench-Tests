"""Output formatters: JSON, CSV, plain text.

This package replaces the monolithic output.py module.
All public symbols are re-exported here for backward compatibility.
"""
from __future__ import annotations

from .json_renderer import to_json
from .csv_renderer import to_csv
from .plain_renderer import to_text, render_aggregate
from .legacy import format_legacy

__all__ = [
    "to_json",
    "to_csv",
    "to_text",
    "render_aggregate",
    "format_legacy",
]
