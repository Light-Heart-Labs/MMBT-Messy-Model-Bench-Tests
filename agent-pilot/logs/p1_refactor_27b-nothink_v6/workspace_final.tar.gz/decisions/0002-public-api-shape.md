# ADR-0002: Public API Shape

## Status

Accepted

## Context

The `logalyzer/output` module is imported by `cli.py` with:

```python
from .output import render_aggregate, to_csv, to_json, to_text
```

Additionally, the task requires that `format_legacy` be importable from `logalyzer.output`:

```python
from logalyzer.output import format_legacy
```

## Decision

The `logalyzer/output/__init__.py` re-exports exactly these five symbols:

| Symbol | Source Module | Used By |
|--------|--------------|---------|
| `to_json` | `json_renderer.py` | `cli.py` |
| `to_csv` | `csv_renderer.py` | `cli.py` |
| `to_text` | `plain_renderer.py` | `cli.py` |
| `render_aggregate` | `plain_renderer.py` | `cli.py` |
| `format_legacy` | `legacy.py` (→ `utils.py`) | External scripts (backward compat) |

### Why `format_legacy` is in `output/legacy.py`

`format_legacy` is defined in `utils.py` (not `output.py`). The task requires it to be importable from `logalyzer.output`. Rather than duplicating the function, `output/legacy.py` re-exports it from `utils.py`. This:

1. Keeps the single source of truth in `utils.py`
2. Satisfies the import path requirement
3. Documents the legacy nature of the function

### Why `render_aggregate` is in `plain_renderer.py`

`render_aggregate` supports three formats (text, json, csv) but its default is "text". It's the most general-purpose rendering function and doesn't fit neatly into any single format module. Placing it in `plain_renderer.py` alongside `to_text` keeps the text-oriented rendering functions together.

## Consequences

- All existing import paths continue to work without modification
- No changes needed to `cli.py` or any other caller
- The `__all__` in `__init__.py` explicitly documents the public API surface
