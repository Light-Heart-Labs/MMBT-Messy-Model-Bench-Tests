# ADR-0001: Why Split output.py

## Status

Accepted

## Context

The `logalyzer/output.py` module mixed four distinct concerns:

1. **JSON serialization** (`to_json`) — hand-crafted JSON string building for log entries
2. **CSV serialization** (`to_csv`) — using the `csv` stdlib module
3. **Plain-text formatting** (`to_text`) — human-readable log entry display
4. **Aggregate rendering** (`render_aggregate`) — multi-format rendering of Counter/dict results
5. **Legacy compatibility** — `format_legacy()` was referenced in the task spec as needing to remain importable from `logalyzer.output`

This monolithic structure made it difficult to:
- Understand which functions belong to which concern
- Test individual rendering strategies in isolation
- Evolve one format without risk of affecting others

## Decision

Split `output.py` into a `logalyzer/output/` package with one module per concern:

| Module | Contents | Rationale |
|--------|----------|-----------|
| `json_renderer.py` | `to_json()` | JSON-specific logic, hand-crafted serialization |
| `csv_renderer.py` | `to_csv()` | CSV-specific logic, uses `csv` stdlib |
| `plain_renderer.py` | `to_text()`, `render_aggregate()` | Text formatting + aggregate rendering (default format is text) |
| `legacy.py` | `format_legacy()` | Backwards-compat shim, re-exported from `utils.py` |
| `__init__.py` | Re-exports all public symbols | Maintains backward compatibility for all existing imports |

## Consequences

- **Positive**: Each rendering strategy is now isolated; future changes to one format won't risk others
- **Positive**: The `__init__.py` re-exports ensure zero breaking changes for existing callers
- **Neutral**: `render_aggregate` was placed in `plain_renderer.py` because its default format is "text" and it's the most general-purpose renderer
- **Neutral**: `format_legacy` lives in `utils.py` but is re-exported through `output/legacy.py` and `output/__init__.py` to maintain the import path `from logalyzer.output import format_legacy`
