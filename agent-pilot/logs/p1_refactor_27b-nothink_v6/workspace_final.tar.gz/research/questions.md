# Questions and Resolutions

## Q1: Where should `render_aggregate` live?

**Question**: `render_aggregate` supports text, json, and csv formats. Which module should own it?

**Resolution**: Placed in `plain_renderer.py` because:
- Its default format is "text"
- It's the most general-purpose rendering function
- It doesn't fit neatly into any single format-specific module
- Keeping it with `to_text` groups the text-oriented functions together

## Q2: Should `format_legacy` be copied or re-exported?

**Question**: `format_legacy` is defined in `utils.py`. Should we copy it to `output/legacy.py` or re-export it?

**Resolution**: Re-export from `utils.py`. This:
- Keeps a single source of truth
- Avoids code duplication
- The `legacy.py` module serves as documentation that this is a legacy function
- Satisfies the import path requirement `from logalyzer.output import format_legacy`

## Q3: Should we use absolute or relative imports in the output subpackage?

**Question**: The renderer modules need to import `LogEntry` from `parser.py`. Should we use `from .parser import LogEntry` or `from logalyzer.parser import LogEntry`?

**Resolution**: Used relative imports (`from ..parser import LogEntry`) because:
- The output subpackage is internal to the logalyzer package
- Relative imports make the package structure explicit
- They work regardless of how the package is installed
