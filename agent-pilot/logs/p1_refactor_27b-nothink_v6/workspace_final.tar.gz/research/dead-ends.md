# Dead Ends

## Pre-existing Bug: `collections.Iterable` in filters.py

**Issue**: `logalyzer/filters.py` line 5 imports `from collections import Iterable`, which was removed in Python 3.10. The correct import is `from collections.abc import Iterable`.

**Impact**: This prevents `cli.py` from importing (since `cli.py` imports from `filters.py`), which in turn prevents the full test suite from running. Specifically, `test_filters.py` fails at import time.

**Resolution**: Documented but not fixed per task constraints ("No bug fixes"). The `filters.py` file was not modified.

## Pre-existing Bug: Missing "Jul" in MONTH_NAMES

**Issue**: `logalyzer/parser.py` defines `MONTH_NAMES` but is missing "Jul" (July). The list has "Jun" then "Aug" with "Jul" skipped. This causes `test_timestamp_july_parses_correctly` to fail with `ValueError: 'Jul' is not in list`.

**Impact**: One test fails: `tests/test_parser.py::test_timestamp_july_parses_correctly`.

**Resolution**: Documented but not fixed per task constraints. The `parser.py` file was not modified.

## Approach Considered: Copying format_legacy into legacy.py

**Approach**: Initially considered copying the `format_legacy` function body into `output/legacy.py` instead of re-exporting from `utils.py`.

**Why Reverted**: This would create two copies of the same function, violating DRY. If the function ever needs to change, both copies would need updating. Re-exporting from `utils.py` keeps a single source of truth while still satisfying the import path requirement.
