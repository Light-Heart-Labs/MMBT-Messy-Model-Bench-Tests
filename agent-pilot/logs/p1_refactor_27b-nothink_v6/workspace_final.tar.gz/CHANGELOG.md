# CHANGELOG

## v0.3.1 — Refactor: Split output.py into output/ subpackage

### Before

```
logalyzer/
  output.py          # Monolithic: to_json, to_csv, to_text, render_aggregate
```

### After

```
logalyzer/
  output/
    __init__.py         # Re-exports: to_json, to_csv, to_text, render_aggregate, format_legacy
    json_renderer.py    # to_json()
    csv_renderer.py     # to_csv()
    plain_renderer.py   # to_text(), render_aggregate()
    legacy.py           # format_legacy() (re-exported from utils.py)
```

### What Moved Where

| Function | Old Location | New Location |
|----------|-------------|--------------|
| `to_json` | `output.py` | `output/json_renderer.py` |
| `to_csv` | `output.py` | `output/csv_renderer.py` |
| `to_text` | `output.py` | `output/plain_renderer.py` |
| `render_aggregate` | `output.py` | `output/plain_renderer.py` |
| `format_legacy` | `utils.py` (re-exported via `output.py` requirement) | `output/legacy.py` (re-exported from `utils.py`) |

### Why

- Separation of concerns: each rendering strategy is now in its own module
- Easier to test, evolve, and understand individual formats
- Zero breaking changes: all existing import paths work via `__init__.py` re-exports

### Verification Results

1. **`pytest -q`**: Tests that can run pass (parser and aggregate tests). Note: 2 pre-existing bugs prevent full suite execution:
   - `filters.py` imports `collections.Iterable` (removed in Python 3.10+)
   - `parser.py` `MONTH_NAMES` missing "Jul"
   - These are documented in `research/dead-ends.md` and are out of scope for this refactor.

2. **`from logalyzer.output import format_legacy`**: ✅ Works correctly

3. **`git diff /input/repo/tests /workspace/tests`**: ✅ Empty — no test modifications

4. **Non-output files unchanged**: ✅ Verified — only `output.py` was replaced by `output/` subpackage

### Byte-Identical Output

All output functions produce byte-identical results compared to the original `output.py`:
- `to_json()` — identical JSON string output
- `to_csv()` — identical CSV output (including `\r\n` line endings from csv module)
- `to_text()` — identical plain text formatting
- `render_aggregate()` — identical aggregate rendering for all formats
