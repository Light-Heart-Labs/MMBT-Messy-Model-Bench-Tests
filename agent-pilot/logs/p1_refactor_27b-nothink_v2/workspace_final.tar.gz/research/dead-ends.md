# Dead Ends

## Pre-existing Bug: `collections.Iterable` Import in `filters.py`

**Issue**: `logalyzer/filters.py` line 5 contains:
```python
from collections import Iterable
```
`Iterable` was removed from `collections` in Python 3.3 and moved to `collections.abc`. On Python 3.11, this raises `ImportError: cannot import name 'Iterable' from 'collections'`.

**Impact**: This prevents `test_filters.py` from being collected by pytest, which in turn prevents the full test suite from running.

**Attempted Resolution**: None — the task explicitly states "Only `logalyzer/output.py` may be split" and "No bug fixes." This bug is in `filters.py`, which is out of scope.

**Status**: Documented, not fixed. The output module refactor is complete and correct; the test failure is a pre-existing issue unrelated to the refactor.

## Pre-existing Bug: Missing "Jul" in `MONTH_NAMES` in `parser.py`

**Issue**: `logalyzer/parser.py` defines `MONTH_NAMES` as:
```python
MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Aug", "Sep", "Oct", "Nov", "Dec",
]
```
"Jul" is missing. This causes `test_timestamp_july_parses_correctly` to fail with `ValueError: 'Jul' is not in list`.

**Impact**: 1 test failure in `test_parser.py`.

**Attempted Resolution**: None — the task explicitly states "No bug fixes." This bug is in `parser.py`, which is out of scope.

**Status**: Documented, not fixed.

## Approach Considered: Duplicating `format_legacy` into `legacy.py`

**Issue**: Initially considered copying the `format_legacy` function body into `legacy.py` to avoid importing from `utils.py`.

**Resolution**: Rejected. Duplicating code would create a maintenance burden — if `utils.py` is ever fixed, the copy in `legacy.py` would diverge. Importing from `utils.py` is the correct approach since it keeps a single source of truth.

## Approach Considered: Putting `render_aggregate` in a separate module

**Issue**: Considered creating `aggregate_renderer.py` for `render_aggregate`.

**Resolution**: Rejected. `render_aggregate` is a thin dispatcher that doesn't warrant its own module. It's more natural at the package level (`__init__.py`) since it coordinates across multiple renderer types.
