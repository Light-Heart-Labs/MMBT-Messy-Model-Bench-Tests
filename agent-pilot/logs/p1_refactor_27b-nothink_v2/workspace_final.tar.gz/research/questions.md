# Questions and Resolutions

## Q1: Where should `render_aggregate` live?

**Question**: `render_aggregate` dispatches to text or JSON based on a `fmt` parameter. It doesn't fit neatly into any single renderer module.

**Resolution**: Placed in `__init__.py` since it's a higher-level composite function that doesn't belong to any single renderer. This keeps it at the package level where callers expect to find it.

## Q2: `format_legacy` is in `utils.py`, not `output.py`

**Question**: The task description says `format_legacy` is in `output.py`, but the actual code has it in `utils.py`. Should I move it?

**Resolution**: The task says "Only `logalyzer/output.py` may be split." I cannot modify `utils.py`. Instead, `legacy.py` imports `format_legacy` from `utils.py` and re-exports it. This satisfies the verification requirement (`from logalyzer.output import format_legacy` works) without modifying `utils.py`.

## Q3: Pre-existing bugs prevent full test suite from running

**Question**: `filters.py` has `from collections import Iterable` which fails on Python 3.11+, and `parser.py` has a missing "Jul" in `MONTH_NAMES`. These prevent tests from running.

**Resolution**: Documented in `dead-ends.md`. Per task constraints, I cannot fix bugs or modify files other than `output.py`. The output module itself works correctly and all its functions produce byte-identical output to the original.

## Q4: Should I use `json` module for `to_json`?

**Question**: The original `to_json` hand-builds JSON strings instead of using the `json` module. Should I modernize this?

**Resolution**: No. The task requires byte-identical behavior. The hand-built JSON has specific formatting (no spaces, specific field order) that would differ from `json.dumps()`. The original implementation is preserved exactly.
