# CHANGELOG

## v0.3.2 — Refactor: Split `output.py` into `output/` package

### What Changed

The monolithic `logalyzer/output.py` module has been split into a focused `logalyzer/output/` package:

**Before:**
```
logalyzer/
  output.py          (single file with all formatters)
```

**After:**
```
logalyzer/
  output/
    __init__.py         Re-exports public API; contains render_aggregate()
    json_renderer.py    to_json() — JSON output
    csv_renderer.py     to_csv() — CSV output
    plain_renderer.py   to_text() — plain-text output
    legacy.py           format_legacy() — backward-compat shim
```

### What Moved Where

| Function           | Before              | After                          |
|--------------------|---------------------|--------------------------------|
| `to_json`          | `output.py`         | `output/json_renderer.py`      |
| `to_csv`           | `output.py`         | `output/csv_renderer.py`       |
| `to_text`          | `output.py`         | `output/plain_renderer.py`     |
| `render_aggregate` | `output.py`         | `output/__init__.py`           |
| `format_legacy`    | `utils.py`          | `output/legacy.py` (re-export) |

### Backward Compatibility

All existing import patterns continue to work without modification:

```python
from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.output import format_legacy
```

No changes were made to `cli.py`, tests, or any other call site.

### Why

- **Single Responsibility**: Each renderer module now has one clear purpose
- **Extensibility**: New output formats can be added as new modules
- **Maintainability**: Smaller, focused files are easier to read and modify
- **No behavioral change**: All output is byte-identical to the original

### Verification Results

1. **`pytest -q`**: Tests that can run (parser, aggregate) pass. `test_filters.py` fails to collect due to a pre-existing bug in `filters.py` (`from collections import Iterable` is invalid on Python 3.11+). `test_parser.py::test_timestamp_july_parses_correctly` fails due to a pre-existing bug in `parser.py` (missing "Jul" in `MONTH_NAMES`). These are documented in `research/dead-ends.md`.

2. **`from logalyzer.output import format_legacy`**: Works correctly. The function is re-exported from `output/legacy.py` (which imports it from `utils.py`).

3. **`git diff /input/repo/tests /workspace/tests`**: Empty — no test files were modified.

4. **`git diff /input/repo/logalyzer/parser.py /workspace/logalyzer/parser.py`**: Empty — no non-output files were modified.

### Pre-existing Issues (Not Fixed)

- `filters.py`: `from collections import Iterable` fails on Python 3.11+ (see `research/dead-ends.md`)
- `parser.py`: `MONTH_NAMES` is missing "Jul" (see `research/dead-ends.md`)

These issues existed before this refactor and are out of scope.
