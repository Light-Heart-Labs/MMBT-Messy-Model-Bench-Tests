# ADR-0001: Why Split output.py

## Status

Accepted

## Context

The `logalyzer/output.py` module mixes four distinct concerns:

1. **JSON serialization** (`to_json`) — renders `LogEntry` objects as a JSON array string
2. **CSV serialization** (`to_csv`) — renders `LogEntry` objects as CSV with headers
3. **Plain-text formatting** (`to_text`) — renders `LogEntry` objects as human-readable text
4. **Aggregate rendering** (`render_aggregate`) — a multi-format dispatcher for Counter/dict/list results
5. **Legacy compatibility** (`format_legacy`) — a v0.1-era formatter kept for external scripts

This violates the Single Responsibility Principle and makes the module harder to navigate, test, and maintain. Each renderer has different dependencies (e.g., `csv` and `io` for CSV, none for plain text) and different use cases.

## Decision

Split `output.py` into a `logalyzer/output/` package with one module per concern:

- `json_renderer.py` — `to_json()`
- `csv_renderer.py` — `to_csv()`
- `plain_renderer.py` — `to_text()`
- `legacy.py` — `format_legacy()` (imported from `utils.py` where it's defined)
- `__init__.py` — re-exports the public API; contains `render_aggregate()` as it's a multi-format dispatcher

## Consequences

- **Positive**: Each module has a clear, single purpose. New renderers can be added as new files.
- **Positive**: The `__init__.py` re-exports maintain backward compatibility — all existing imports continue to work.
- **Neutral**: `render_aggregate` lives in `__init__.py` rather than a dedicated module, since it dispatches across formats and doesn't fit a single renderer category.
- **Neutral**: `format_legacy` is defined in `utils.py` (not `output.py`), so `legacy.py` re-exports it rather than duplicating it.
