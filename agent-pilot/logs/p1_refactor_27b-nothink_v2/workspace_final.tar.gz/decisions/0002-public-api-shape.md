# ADR-0002: Public API Shape

## Status

Accepted

## Context

The `logalyzer.output` module is imported by `cli.py` with:

```python
from .output import render_aggregate, to_csv, to_json, to_text
```

Additionally, the task requires that `format_legacy` be importable from `logalyzer.output` for backward compatibility, even though it's defined in `utils.py`.

## Decision

The `logalyzer/output/__init__.py` re-exports the following public API:

| Name              | Source Module       | Notes                                      |
|-------------------|---------------------|--------------------------------------------|
| `to_json`         | `json_renderer.py`  | Imported and re-exported                   |
| `to_csv`          | `csv_renderer.py`   | Imported and re-exported                   |
| `to_text`         | `plain_renderer.py` | Imported and re-exported                   |
| `render_aggregate`| `__init__.py`       | Defined directly (multi-format dispatcher) |
| `format_legacy`   | `legacy.py`         | Re-exported from `utils.py`                |

### Why `render_aggregate` lives in `__init__.py`

`render_aggregate` dispatches to text or JSON based on a `fmt` parameter. It doesn't belong to any single renderer — it's a higher-level composite function. Placing it in `__init__.py` keeps it at the package level where callers expect to find it, without forcing it into a renderer-specific module.

### Why `format_legacy` is in `legacy.py`

The task specification calls for a `legacy.py` module. `format_legacy` is defined in `utils.py` (not in the original `output.py`), so `legacy.py` imports and re-exports it. This keeps the definition in one place (`utils.py`) while making it available from `logalyzer.output` for backward compatibility.

### Backward Compatibility

All existing import patterns continue to work:

```python
from logalyzer.output import to_json, to_csv, to_text, render_aggregate  # cli.py
from logalyzer.output import format_legacy                                # external scripts
```

No changes are required in `cli.py` or any other call site.
