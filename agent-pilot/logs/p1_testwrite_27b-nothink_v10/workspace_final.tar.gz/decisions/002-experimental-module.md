# ADR-002: Experimental Module Testing Decision

## Context

`experimental.py` is marked as "experimental" and "not yet wired into the CLI." It contains two functions: `detect_anomalies()` (z-score-based anomaly detection) and `session_window()` (session grouping by IP).

## Decision

Test the full code paths of both functions. While the module is experimental, the code is real and contains logic worth verifying:

- `detect_anomalies()` has a subtle behavior: it uses population standard deviation (divides by N, not N-1), which means the threshold is lower than with sample std. This affects what counts as an anomaly.
- `session_window()` has a boundary condition: gaps exactly equal to `window_seconds` do NOT split sessions (only `>` splits).

## Recommendation

The experimental module should be kept for now since it's part of an in-progress feature. However, the `detect_anomalies` function should be reviewed for:
1. Whether population vs. sample std is intentional
2. Whether the 3-sigma threshold is appropriate for the use case
