# ADR-001: Test Strategy for logalyzer Coverage Improvement

## Context

The logalyzer codebase has several modules with 0% or low test coverage:
- `experimental.py` — 0% coverage (anomaly detection, session windowing)
- `output.py` — 0% coverage (JSON, CSV, text formatters)
- `utils.py` — 0% coverage (date parsing, byte formatting, chunking, legacy formatter)
- `io.py` — 0% coverage (file loading)
- `cli.py` — 0% coverage (CLI entry point)
- `filters.py` — 74% coverage (missing: expression_filter, combine_and)

## Decision

Target the following modules in priority order:

1. **experimental.py** — Full coverage. Test both `detect_anomalies` and `session_window` with edge cases (empty input, single entry, all same minute, burst patterns).

2. **output.py** — Full coverage. Test `to_json`, `to_csv`, `to_text`, `render_aggregate` with various formats and edge cases (empty entries, special characters in URLs).

3. **utils.py** — Full coverage. Test `parse_iso_date`, `format_bytes`, `format_legacy`, `chunked` with edge cases (zero bytes, negative values, empty sequences, boundary values).

4. **io.py** — Full coverage. Test `load` and `load_iter` with real temp files (empty file, file with no trailing newline, file with mixed valid/invalid lines).

5. **cli.py** — Partial coverage. Test `build_parser` and `main` with various argument combinations.

6. **filters.py** — Fill gaps. Test `expression_filter` and `combine_and` with edge cases.

## Rationale

- These modules represent the most coverage delta per test written
- Edge cases in parsing and formatting are where real bugs hide
- The experimental module, while marked "experimental", contains real logic worth verifying

## Not Testing

- We will NOT test the 3 existing failing tests (status string comparison, url_regex substring match, July month name) — these are bugs in the source code. Documented in dead-ends.md.
