# ADR-003: Legacy Code Testing Decision

## Context

`format_legacy()` in `utils.py` is marked as "Legacy formatter retained for compatibility with the v0.1 CLI output. No longer used internally, kept for any external scripts that may still depend on it."

## Decision

Test `format_legacy()` to increase coverage. While the function is deprecated, testing it:
1. Documents the expected output format for any external scripts still using it
2. Ensures the function doesn't silently break if dependencies change
3. Provides a regression safety net until the function is eventually removed

## Recommendation

The function should be kept until a deprecation warning is added and external users are notified. Eventually it should be removed in a major version bump.
