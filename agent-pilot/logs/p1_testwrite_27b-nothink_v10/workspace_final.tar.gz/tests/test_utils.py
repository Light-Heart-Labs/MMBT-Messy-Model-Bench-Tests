"""Tests for utils.py — date parsing, byte formatting, legacy formatter, chunking.

Exercises edge cases: zero/negative values, empty sequences, boundary conditions,
and the legacy format_legacy function that is no longer used internally.
"""
from datetime import datetime, timezone

from logalyzer.utils import (
    parse_iso_date,
    format_bytes,
    format_legacy,
    chunked,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── parse_iso_date ────────────────────────────────────────────────────────


def test_parse_iso_date_midnight_utc():
    """parse_iso_date should return a UTC datetime at midnight."""
    dt = parse_iso_date("2026-06-15")
    assert dt == datetime(2026, 6, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_leap_year():
    """Should handle leap year dates correctly."""
    dt = parse_iso_date("2024-02-29")
    assert dt == datetime(2024, 2, 29, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_first_of_month():
    """Should handle first day of month."""
    dt = parse_iso_date("2026-01-01")
    assert dt == datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_last_of_month():
    """Should handle last day of month."""
    dt = parse_iso_date("2026-02-28")
    assert dt == datetime(2026, 2, 28, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_invalid_format():
    """Invalid date format should raise ValueError from strptime."""
    try:
        parse_iso_date("2026/01/01")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass


def test_parse_iso_date_invalid_date():
    """Invalid date (e.g., Feb 30) should raise ValueError."""
    try:
        parse_iso_date("2026-02-30")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass


# ── format_bytes ──────────────────────────────────────────────────────────


def test_format_bytes_zero():
    """Zero bytes should format as '0.0 B'."""
    assert format_bytes(0) == "0.0 B"


def test_format_bytes_small():
    """Small byte values should stay in B."""
    assert format_bytes(1) == "1.0 B"
    assert format_bytes(500) == "500.0 B"


def test_format_bytes_just_under_kb():
    """1023 bytes should still be in B."""
    assert format_bytes(1023) == "1023.0 B"


def test_format_bytes_exactly_kb():
    """1024 bytes should be 1.0 KB."""
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_kb_range():
    """Values in KB range should show KB."""
    assert format_bytes(2048) == "2.0 KB"
    assert format_bytes(10240) == "10.0 KB"


def test_format_bytes_exactly_mb():
    """1048576 bytes (1 MB) should show MB."""
    assert format_bytes(1048576) == "1.0 MB"


def test_format_bytes_mb_range():
    """Values in MB range should show MB."""
    assert format_bytes(5 * 1048576) == "5.0 MB"


def test_format_bytes_exactly_gb():
    """1 GB should show GB."""
    assert format_bytes(1073741824) == "1.0 GB"


def test_format_bytes_gb_range():
    """Values in GB range should show GB."""
    assert format_bytes(5 * 1073741824) == "5.0 GB"


def test_format_bytes_exactly_tb():
    """1 TB should show TB."""
    assert format_bytes(1099511627776) == "1.0 TB"


def test_format_bytes_fractional():
    """Fractional values should show one decimal place."""
    result = format_bytes(1536)  # 1.5 KB
    assert result == "1.5 KB"


def test_format_bytes_very_large():
    """Very large values should still format correctly (up to TB)."""
    result = format_bytes(1099511627776 * 2)  # 2 TB
    assert result == "2.0 TB"


# ── format_legacy ─────────────────────────────────────────────────────────


def test_format_legacy_basic():
    """Legacy format should produce pipe-separated fields."""
    entry = _entry()
    result = format_legacy(entry)
    assert "10.0.0.1" in result
    assert "200" in result
    assert "/" in result
    assert "|" in result


def test_format_legacy_field_order():
    """Legacy format order: ip | timestamp | status | url."""
    entry = _entry()
    result = format_legacy(entry)
    parts = [p.strip() for p in result.split("|")]
    assert len(parts) == 4
    assert parts[0] == "10.0.0.1"
    assert parts[2] == "200"
    assert parts[3] == "/"


def test_format_legacy_with_custom_values():
    """Legacy format should reflect custom entry values."""
    entry = _entry(ip="192.168.1.1", status=404, url="/missing")
    result = format_legacy(entry)
    assert "192.168.1.1" in result
    assert "404" in result
    assert "/missing" in result


# ── chunked ───────────────────────────────────────────────────────────────


def test_chunked_empty():
    """Empty sequence should produce no chunks."""
    result = list(chunked([], 3))
    assert result == []


def test_chunked_exact_multiple():
    """Sequence length exactly divisible by chunk size."""
    result = list(chunked([1, 2, 3, 4, 5, 6], 3))
    assert result == [[1, 2, 3], [4, 5, 6]]


def test_chunked_remainder():
    """Sequence with remainder should have a smaller final chunk."""
    result = list(chunked([1, 2, 3, 4, 5], 3))
    assert result == [[1, 2, 3], [4, 5]]


def test_chunked_single_element():
    """Single element with chunk size 1."""
    result = list(chunked([42], 1))
    assert result == [[42]]


def test_chunked_chunk_size_larger_than_sequence():
    """Chunk size larger than sequence should return one chunk."""
    result = list(chunked([1, 2, 3], 10))
    assert result == [[1, 2, 3]]


def test_chunked_chunk_size_one():
    """Chunk size of 1 should produce one-element chunks."""
    result = list(chunked([1, 2, 3], 1))
    assert result == [[1], [2], [3]]


def test_chunked_generator_behavior():
    """chunked should be a generator (lazy evaluation)."""
    gen = chunked([1, 2, 3, 4, 5], 2)
    first = next(gen)
    assert first == [1, 2]
    second = next(gen)
    assert second == [3, 4]
    third = next(gen)
    assert third == [5]
    try:
        next(gen)
        assert False, "Should have raised StopIteration"
    except StopIteration:
        pass


def test_chunked_with_strings():
    """chunked should work with any iterable, not just numbers."""
    result = list(chunked(["a", "b", "c", "d"], 2))
    assert result == [["a", "b"], ["c", "d"]]


def test_format_bytes_petabyte_range():
    """Values exceeding TB should fall through to PB (the final fallback)."""
    # 1 PB = 1024^5 bytes
    pb = 1024**5
    result = format_bytes(pb)
    assert result == "1.0 PB"
    result = format_bytes(pb * 5)
    assert result == "5.0 PB"
