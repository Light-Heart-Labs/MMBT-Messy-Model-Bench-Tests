"""Tests for io.py — file loading helpers.

Tests load() and load_iter() with real temp files covering edge cases:
empty files, files without trailing newlines, mixed valid/invalid lines,
and large files.
"""
import os
import tempfile

from logalyzer.io import load, load_iter

# A valid CLF log line
VALID_LINE = (
    '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] '
    '"GET /apache_pb.gif HTTP/1.0" 200 2326'
)

# Another valid line with different values
VALID_LINE_2 = (
    '192.168.1.1 - - [15/Jan/2026:08:30:00 +0000] '
    '"POST /api/data HTTP/1.1" 201 512'
)

# An invalid line
INVALID_LINE = "this is not a valid log line"


# ── load ──────────────────────────────────────────────────────────────────


def test_load_empty_file():
    """Empty file should return empty list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("")
        path = f.name
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_single_valid_line():
    """File with one valid line should return one entry."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
        assert result[0].user == "frank"
    finally:
        os.unlink(path)


def test_load_multiple_valid_lines():
    """File with multiple valid lines should return all entries."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(VALID_LINE_2 + "\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 2
        assert result[0].ip == "127.0.0.1"
        assert result[1].ip == "192.168.1.1"
    finally:
        os.unlink(path)


def test_load_mixed_valid_invalid():
    """File with mixed valid and invalid lines should skip invalid ones."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(INVALID_LINE + "\n")
        f.write(VALID_LINE_2 + "\n")
        f.write("garbage\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 2
        assert result[0].ip == "127.0.0.1"
        assert result[1].ip == "192.168.1.1"
    finally:
        os.unlink(path)


def test_load_no_trailing_newline():
    """File without trailing newline should still parse the last line."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE)  # no trailing newline
        path = f.name
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_only_invalid_lines():
    """File with only invalid lines should return empty list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(INVALID_LINE + "\n")
        f.write("more garbage\n")
        path = f.name
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_blank_lines():
    """Blank lines should be skipped (parse_line returns None for empty)."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("\n")
        f.write(VALID_LINE + "\n")
        f.write("\n")
        path = f.name
    try:
        result = load(path)
        assert len(result) == 1
    finally:
        os.unlink(path)


def test_load_file_not_found():
    """Loading a non-existent file should raise FileNotFoundError."""
    try:
        load("/nonexistent/path/to/file.log")
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError:
        pass


# ── load_iter ─────────────────────────────────────────────────────────────


def test_load_iter_empty_file():
    """Empty file should yield no entries."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("")
        path = f.name
    try:
        result = list(load_iter(path))
        assert result == []
    finally:
        os.unlink(path)


def test_load_iter_single_valid_line():
    """File with one valid line should yield one entry."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = list(load_iter(path))
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_iter_multiple_lines():
    """File with multiple valid lines should yield all entries."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(VALID_LINE_2 + "\n")
        path = f.name
    try:
        result = list(load_iter(path))
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_mixed_valid_invalid():
    """load_iter should skip invalid lines just like load()."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(INVALID_LINE + "\n")
        f.write(VALID_LINE_2 + "\n")
        path = f.name
    try:
        result = list(load_iter(path))
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_is_generator():
    """load_iter should return a generator, not a list."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = load_iter(path)
        # Should be a generator
        assert hasattr(result, "__next__")
        assert hasattr(result, "__iter__")
    finally:
        os.unlink(path)


def test_load_iter_file_not_found():
    """Loading a non-existent file should raise FileNotFoundError."""
    try:
        list(load_iter("/nonexistent/path/to/file.log"))
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError:
        pass
