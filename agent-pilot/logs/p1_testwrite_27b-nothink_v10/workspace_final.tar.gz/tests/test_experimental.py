"""Tests for experimental.py — anomaly detection and session windowing.

These tests exercise the full code paths of detect_anomalies() and session_window(),
including edge cases like empty input, single entries, and burst patterns.
"""
from datetime import datetime, timedelta, timezone

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1"):
    """Helper to create a LogEntry at a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )


# ── detect_anomalies ──────────────────────────────────────────────────────


def test_detect_anomalies_empty_input():
    """Empty input should return empty list (no buckets, no anomalies)."""
    assert detect_anomalies([]) == []


def test_detect_anomalies_single_entry():
    """A single entry has zero variance, so threshold = mean. No anomalies."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts)]
    assert detect_anomalies(entries) == []


def test_detect_anomalies_uniform_distribution():
    """Uniform distribution across minutes should produce no anomalies."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    # Each minute has exactly 1 request; std=0, threshold=1
    assert detect_anomalies(entries) == []


def test_detect_anomalies_burst_detected():
    """A minute with many more requests than others should be flagged.

    Need enough baseline entries and a large enough burst so the z-score
    threshold (mean + 3*std) is exceeded. With 20 baseline minutes at 1 req
    each and 100 extra in one minute: mean=6, std~21.8, threshold~71.4,
    burst=101 > 71.4.
    """
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    # 20 minutes with 1 request each
    entries = [_entry(base + timedelta(minutes=i)) for i in range(20)]
    # Add 100 requests in minute 5
    burst_minute = base + timedelta(minutes=5)
    entries += [_entry(burst_minute) for _ in range(100)]
    anomalies = detect_anomalies(entries)
    assert burst_minute.replace(second=0, microsecond=0) in anomalies


def test_detect_anomalies_all_same_minute():
    """All entries in the same minute — zero variance, no anomalies."""
    ts = datetime(2026, 1, 1, 12, 30, 45, tzinfo=timezone.utc)
    entries = [_entry(ts) for _ in range(100)]
    assert detect_anomalies(entries) == []


def test_detect_anomalies_buckets_truncate_seconds():
    """Entries within the same minute (different seconds) should be in one bucket."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=30)),
        _entry(base + timedelta(seconds=59)),
    ]
    anomalies = detect_anomalies(entries)
    # All 3 in same bucket; with only 1 bucket, std=0, no anomalies
    assert anomalies == []


def test_detect_anomalies_multiple_bursts():
    """Two burst minutes should both be detected as anomalies."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(30)]
    # Create two bursts
    burst1 = base + timedelta(minutes=5)
    burst2 = base + timedelta(minutes=20)
    entries += [_entry(burst1) for _ in range(100)]
    entries += [_entry(burst2) for _ in range(100)]
    anomalies = detect_anomalies(entries)
    expected = {
        burst1.replace(second=0, microsecond=0),
        burst2.replace(second=0, microsecond=0),
    }
    assert set(anomalies) == expected


# ── session_window ────────────────────────────────────────────────────────


def test_session_window_empty_input():
    """Empty input should return empty sessions list."""
    assert session_window([]) == []


def test_session_window_single_entry():
    """A single entry should produce one session."""
    ts = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(ts)]
    sessions = session_window(entries)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    assert ip == "10.0.0.1"
    assert len(session_entries) == 1


def test_session_window_same_ip_same_session():
    """Entries from the same IP within the window should be one session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        _entry(base + timedelta(minutes=20)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    ip, session_entries = sessions[0]
    assert ip == "10.0.0.1"
    assert len(session_entries) == 3


def test_session_window_gap_splits_session():
    """A gap larger than window_seconds should split into two sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        # 40-minute gap (> 30 min default window)
        _entry(base + timedelta(minutes=50)),
        _entry(base + timedelta(minutes=60)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    assert len(sessions[0][1]) == 2
    assert len(sessions[1][1]) == 2


def test_session_window_multiple_ips():
    """Different IPs should produce separate sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base, ip="10.0.0.1"),
        _entry(base + timedelta(minutes=5), ip="10.0.0.2"),
        _entry(base + timedelta(minutes=10), ip="10.0.0.1"),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    ips = {s[0] for s in sessions}
    assert ips == {"10.0.0.1", "10.0.0.2"}


def test_session_window_custom_window():
    """Custom window_seconds should be respected."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=5)),
        _entry(base + timedelta(minutes=10)),
    ]
    # 2-minute window: gap between entries is 5 min, so each is its own session
    sessions = session_window(entries, window_seconds=120)
    assert len(sessions) == 3


def test_session_window_entries_sorted_by_time():
    """Entries within a session should be sorted by timestamp."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base + timedelta(minutes=10)),
        _entry(base),
        _entry(base + timedelta(minutes=5)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    _, session_entries = sessions[0]
    timestamps = [e.timestamp for e in session_entries]
    assert timestamps == sorted(timestamps)


def test_session_window_exact_window_boundary():
    """A gap exactly equal to window_seconds should NOT split (only > splits)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1800)),  # exactly 30 min
    ]
    sessions = session_window(entries, window_seconds=1800)
    # gap == window_seconds, not >, so still one session
    assert len(sessions) == 1


def test_session_window_just_over_boundary():
    """A gap just over window_seconds should split."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1801)),  # 1 second over
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
