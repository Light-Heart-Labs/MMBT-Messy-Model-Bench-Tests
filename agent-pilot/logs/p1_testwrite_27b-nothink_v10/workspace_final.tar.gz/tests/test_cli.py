"""Tests for cli.py — CLI argument parsing and main entry point.

Tests build_parser() with various argument combinations and main() with
temp files to exercise the full pipeline without modifying production code.
"""
import os
import tempfile

from logalyzer.cli import build_parser, main

# A valid CLF log line
VALID_LINE = (
    '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] '
    '"GET /apache_pb.gif HTTP/1.0" 200 2326'
)

VALID_LINE_2 = (
    '192.168.1.1 - - [15/Jan/2026:08:30:00 +0000] '
    '"POST /api/data HTTP/1.1" 404 512'
)


# ── build_parser ──────────────────────────────────────────────────────────


def test_build_parser_returns_argument_parser():
    """build_parser should return an argparse.ArgumentParser instance."""
    parser = build_parser()
    assert parser.prog == "logalyzer"


def test_build_parser_requires_paths():
    """Parser should require at least one path argument."""
    parser = build_parser()
    try:
        parser.parse_args([])
        assert False, "Should have raised SystemExit"
    except SystemExit:
        pass


def test_build_parser_version_flag():
    """--version flag should be recognized."""
    parser = build_parser()
    try:
        parser.parse_args(["--version"])
        assert False, "Should have raised SystemExit"
    except SystemExit as e:
        # version action exits with code 0
        assert e.code == 0


def test_build_parser_status_flag():
    """--status flag should be parsed as a string."""
    parser = build_parser()
    args = parser.parse_args(["--status", "404", "test.log"])
    assert args.status == "404"


def test_build_parser_url_flag():
    """--url flag should be parsed as a regex pattern string."""
    parser = build_parser()
    args = parser.parse_args(["--url", r"^/api", "test.log"])
    assert args.url == r"^/api"


def test_build_parser_ip_flag_repeatable():
    """--ip flag should be repeatable and collected as a list."""
    parser = build_parser()
    args = parser.parse_args(["--ip", "10.0.0.1", "--ip", "10.0.0.2", "test.log"])
    assert args.ip == ["10.0.0.1", "10.0.0.2"]


def test_build_parser_ip_default_empty():
    """--ip flag should default to empty list."""
    parser = build_parser()
    args = parser.parse_args(["test.log"])
    assert args.ip == []


def test_build_parser_since_flag():
    """--since flag should parse ISO date."""
    parser = build_parser()
    args = parser.parse_args(["--since", "2026-01-01", "test.log"])
    assert args.since is not None
    assert args.since.year == 2026


def test_build_parser_until_flag():
    """--until flag should parse ISO date."""
    parser = build_parser()
    args = parser.parse_args(["--until", "2026-12-31", "test.log"])
    assert args.until is not None
    assert args.until.month == 12


def test_build_parser_since_invalid_date():
    """--since with invalid date should raise error."""
    parser = build_parser()
    try:
        parser.parse_args(["--since", "not-a-date", "test.log"])
        assert False, "Should have raised SystemExit"
    except SystemExit:
        pass


def test_build_parser_aggregate_choices():
    """--aggregate should only accept valid choices."""
    parser = build_parser()
    for choice in ["status", "url", "hour"]:
        args = parser.parse_args(["--aggregate", choice, "test.log"])
        assert args.aggregate == choice


def test_build_parser_aggregate_invalid():
    """--aggregate with invalid choice should raise error."""
    parser = build_parser()
    try:
        parser.parse_args(["--aggregate", "invalid", "test.log"])
        assert False, "Should have raised SystemExit"
    except SystemExit:
        pass


def test_build_parser_top_flag():
    """--top flag should parse as integer."""
    parser = build_parser()
    args = parser.parse_args(["--top", "10", "test.log"])
    assert args.top == 10


def test_build_parser_top_default_none():
    """--top flag should default to None."""
    parser = build_parser()
    args = parser.parse_args(["test.log"])
    assert args.top is None


def test_build_parser_format_choices():
    """--format should only accept valid choices."""
    parser = build_parser()
    for fmt in ["text", "json", "csv"]:
        args = parser.parse_args(["--format", fmt, "test.log"])
        assert args.format == fmt


def test_build_parser_format_default_text():
    """--format should default to 'text'."""
    parser = build_parser()
    args = parser.parse_args(["test.log"])
    assert args.format == "text"


def test_build_parser_expr_flag():
    """--expr flag should accept arbitrary Python expression string."""
    parser = build_parser()
    args = parser.parse_args(["--expr", "entry.status >= 500", "test.log"])
    assert args.expr == "entry.status >= 500"


def test_build_parser_multiple_paths():
    """Parser should accept multiple file paths."""
    parser = build_parser()
    args = parser.parse_args(["file1.log", "file2.log", "file3.log"])
    assert args.paths == ["file1.log", "file2.log", "file3.log"]


# ── main ──────────────────────────────────────────────────────────────────


def test_main_no_args_exits():
    """main() with no args should exit with error (no paths provided)."""
    try:
        main([])
        assert False, "Should have raised SystemExit"
    except SystemExit:
        pass


def test_main_with_valid_file():
    """main() with a valid log file should return 0."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main([path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_with_nonexistent_file():
    """main() with a nonexistent file should raise FileNotFoundError."""
    try:
        main(["/nonexistent/file.log"])
        assert False, "Should have raised FileNotFoundError"
    except FileNotFoundError:
        pass


def test_main_aggregate_status():
    """main() with --aggregate status should produce status counts."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        f.write(VALID_LINE_2 + "\n")
        path = f.name
    try:
        result = main(["--aggregate", "status", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_aggregate_url():
    """main() with --aggregate url should produce URL counts."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--aggregate", "url", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_aggregate_hour():
    """main() with --aggregate hour should produce hour counts."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--aggregate", "hour", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_format_json():
    """main() with --format json should produce JSON output."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--format", "json", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_format_csv():
    """main() with --format csv should produce CSV output."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--format", "csv", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_empty_file():
    """main() with an empty file should return 0 (no entries to process)."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("")
        path = f.name
    try:
        result = main([path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_with_status_filter():
    """main() with --status should exercise the status filter path in main()."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--status", "200", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_with_url_filter():
    """main() with --url should exercise the url_regex filter path in main()."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--url", r"^/apache", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_with_ip_filter():
    """main() with --ip should exercise the ip_allowlist filter path in main()."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--ip", "127.0.0.1", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_with_since_filter():
    """main() with --since should exercise the date_range filter path in main()."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--since", "1999-01-01", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_with_until_filter():
    """main() with --until should exercise the date_range filter path in main()."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--until", "2026-12-31", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_with_expr_filter():
    """main() with --expr should exercise the expression filter path in main()."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--expr", "entry.status == 200", path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_with_top_and_aggregate():
    """main() with --top and --aggregate url should exercise the top parameter path."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write(VALID_LINE + "\n")
        path = f.name
    try:
        result = main(["--aggregate", "url", "--top", "5", path])
        assert result == 0
    finally:
        os.unlink(path)
