"""Additional tests for parser.py — edge cases and uncovered paths.

These tests target the remaining uncovered lines in parser.py:
- parse_timestamp with invalid format (line 47)
- parse_lines generator (lines 92-95)
- parse_line with whitespace-only input
"""
from datetime import timezone

from logalyzer.parser import parse_line, parse_timestamp, parse_lines


def test_parse_timestamp_invalid_format():
    """parse_timestamp should raise ValueError for unrecognized format."""
    try:
        parse_timestamp("2026-01-01T12:00:00Z")
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "unrecognized timestamp format" in str(e)


def test_parse_timestamp_empty_string():
    """parse_timestamp with empty string should raise ValueError."""
    try:
        parse_timestamp("")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass


def test_parse_timestamp_partial_match():
    """parse_timestamp with partial timestamp should raise ValueError."""
    try:
        parse_timestamp("10/Oct/2000")
        assert False, "Should have raised ValueError"
    except ValueError:
        pass


def test_parse_timestamp_positive_offset():
    """parse_timestamp with positive timezone offset should convert correctly."""
    # +0530 means local time is 5:30 ahead of UTC
    # 12:00:00 +0530 = 06:30:00 UTC
    ts = parse_timestamp("15/Jan/2026:12:00:00 +0530")
    assert ts.hour == 6
    assert ts.minute == 30
    assert ts.tzinfo is timezone.utc


def test_parse_timestamp_negative_offset():
    """parse_timestamp with negative timezone offset should convert correctly."""
    # -0500 means local time is 5 hours behind UTC
    # 12:00:00 -0500 = 17:00:00 UTC
    ts = parse_timestamp("15/Jan/2026:12:00:00 -0500")
    assert ts.hour == 17
    assert ts.minute == 0
    assert ts.tzinfo is timezone.utc


def test_parse_timestamp_utc_offset():
    """parse_timestamp with +0000 should produce same time in UTC."""
    ts = parse_timestamp("15/Jan/2026:12:00:00 +0000")
    assert ts.hour == 12
    assert ts.minute == 0


def test_parse_line_whitespace_only():
    """parse_line with whitespace-only input should return None."""
    assert parse_line("   ") is None
    assert parse_line("\t") is None
    assert parse_line("\n") is None


def test_parse_line_with_leading_trailing_whitespace():
    """parse_line should strip leading/trailing whitespace before parsing."""
    line = '  127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.0" 200 2326  '
    e = parse_line(line)
    assert e is not None
    assert e.ip == "127.0.0.1"


def test_parse_line_various_methods():
    """parse_line should handle various HTTP methods."""
    for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 -0700] "{method} / HTTP/1.1" 200 0'
        e = parse_line(line)
        assert e is not None
        assert e.method == method


def test_parse_line_various_status_codes():
    """parse_line should handle various HTTP status codes."""
    for status in [200, 201, 301, 302, 304, 400, 401, 403, 404, 500, 502, 503]:
        line = f'127.0.0.1 - - [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.1" {status} 0'
        e = parse_line(line)
        assert e is not None
        assert e.status == status


def test_parse_line_unicode_ip():
    """parse_line should handle IPv6 addresses."""
    line = '::1 - - [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.1" 200 0'
    e = parse_line(line)
    assert e is not None
    assert e.ip == "::1"


def test_parse_line_large_byte_count():
    """parse_line should handle large byte counts."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.1" 200 999999999'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 999999999


def test_parse_line_url_with_query_string():
    """parse_line should handle URLs with query strings."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 -0700] "GET /search?q=hello%20world HTTP/1.1" 200 500'
    e = parse_line(line)
    assert e is not None
    assert e.url == "/search?q=hello%20world"


def test_parse_line_malformed_timestamp_returns_none():
    """parse_line should return None for lines with unparseable timestamps."""
    # Valid CLF structure but invalid timestamp
    line = '127.0.0.1 - - [invalid-timestamp] "GET / HTTP/1.1" 200 0'
    e = parse_line(line)
    assert e is None


# ── parse_lines ───────────────────────────────────────────────────────────


def test_parse_lines_empty_list():
    """parse_lines with empty list should yield nothing."""
    result = list(parse_lines([]))
    assert result == []


def test_parse_lines_mixed_valid_invalid():
    """parse_lines should skip invalid lines and yield valid ones."""
    lines = [
        '127.0.0.1 - - [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.1" 200 2326',
        "invalid line",
        '192.168.1.1 - - [15/Jan/2026:08:30:00 +0000] "POST /api HTTP/1.1" 201 512',
        "",
        "more garbage",
    ]
    result = list(parse_lines(lines))
    assert len(result) == 2
    assert result[0].ip == "127.0.0.1"
    assert result[1].ip == "192.168.1.1"


def test_parse_lines_is_generator():
    """parse_lines should be a generator (lazy evaluation)."""
    lines = ['127.0.0.1 - - [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.1" 200 2326']
    result = parse_lines(lines)
    assert hasattr(result, "__next__")
    assert hasattr(result, "__iter__")


def test_parse_lines_all_invalid():
    """parse_lines with all invalid lines should yield nothing."""
    lines = ["garbage", "more garbage", ""]
    result = list(parse_lines(lines))
    assert result == []


def test_parse_lines_generator_exhaustion():
    """parse_lines generator should be exhaustible."""
    lines = ['127.0.0.1 - - [10/Oct/2000:13:55:36 -0700] "GET / HTTP/1.1" 200 2326']
    gen = parse_lines(lines)
    entry = next(gen)
    assert entry is not None
    try:
        next(gen)
        assert False, "Should have raised StopIteration"
    except StopIteration:
        pass
