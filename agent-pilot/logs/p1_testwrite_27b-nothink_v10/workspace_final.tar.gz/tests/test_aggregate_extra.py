"""Additional tests for aggregate.py — edge cases and uncovered paths.

Tests empty input handling, by_url with top=None, and boundary conditions
for by_hour with entries at midnight.
"""
from datetime import datetime, timezone

from logalyzer.aggregate import by_status, by_url, by_hour, total_bytes
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── by_status ─────────────────────────────────────────────────────────────


def test_by_status_empty():
    """Empty input should return empty Counter."""
    result = by_status([])
    assert dict(result) == {}


def test_by_status_single_entry():
    """Single entry should produce one count."""
    result = by_status([_entry(status=200)])
    assert result[200] == 1


def test_by_status_all_same_status():
    """All entries with same status should have one bucket."""
    entries = [_entry(status=200) for _ in range(100)]
    result = by_status(entries)
    assert result[200] == 100
    assert len(result) == 1


# ── by_url ────────────────────────────────────────────────────────────────


def test_by_url_empty():
    """Empty input should return empty list."""
    result = by_url([])
    assert result == []


def test_by_url_top_none():
    """by_url with top=None should return all URLs (no truncation)."""
    entries = [_entry(url=f"/u{i}") for i in range(10)]
    result = by_url(entries, top=None)
    assert len(result) == 10


def test_by_url_top_zero():
    """by_url with top=0 should return empty list."""
    entries = [_entry(url=f"/u{i}") for i in range(10)]
    result = by_url(entries, top=0)
    assert result == []


def test_by_url_top_larger_than_unique():
    """by_url with top larger than unique URLs should return all."""
    entries = [_entry(url=f"/u{i}") for i in range(3)]
    result = by_url(entries, top=10)
    assert len(result) == 3


def test_by_url_single_url():
    """Single URL should return one entry."""
    entries = [_entry(url="/home") for _ in range(5)]
    result = by_url(entries)
    assert result == [("/home", 5)]


# ── by_hour ───────────────────────────────────────────────────────────────


def test_by_hour_empty():
    """Empty input should return all 24 hours with zero counts."""
    result = by_hour([])
    assert len(result) == 24
    assert all(v == 0 for v in result.values())


def test_by_hour_midnight():
    """Entries at midnight (hour 0) should be bucketed correctly."""
    entries = [_entry(timestamp=datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc))]
    result = by_hour(entries)
    assert result[0] == 1


def test_by_hour_all_24_hours():
    """Entries in all 24 hours should each have count 1."""
    entries = [
        _entry(timestamp=datetime(2026, 1, 1, h, 0, 0, tzinfo=timezone.utc))
        for h in range(24)
    ]
    result = by_hour(entries)
    assert all(result[h] == 1 for h in range(24))


def test_by_hour_23_hour():
    """Entries at 23:00 should be bucketed into hour 23."""
    entries = [_entry(timestamp=datetime(2026, 1, 1, 23, 59, 59, tzinfo=timezone.utc))]
    result = by_hour(entries)
    assert result[23] == 1


# ── total_bytes ───────────────────────────────────────────────────────────


def test_total_bytes_empty():
    """Empty input should return 0."""
    assert total_bytes([]) == 0


def test_total_bytes_single_entry():
    """Single entry should return its byte count."""
    assert total_bytes([_entry(bytes=500)]) == 500


def test_total_bytes_all_zero():
    """All entries with zero bytes should return 0."""
    entries = [_entry(bytes=0) for _ in range(10)]
    assert total_bytes(entries) == 0
