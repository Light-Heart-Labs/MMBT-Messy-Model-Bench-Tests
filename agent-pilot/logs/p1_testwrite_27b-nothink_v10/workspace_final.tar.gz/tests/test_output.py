"""Tests for output.py — JSON, CSV, text formatters and render_aggregate.

Exercises all output functions with edge cases: empty entries, special characters,
unicode in URLs, and various aggregate formats.
"""
from datetime import datetime, timezone
from collections import Counter

from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── to_json ───────────────────────────────────────────────────────────────


def test_to_json_empty():
    """Empty entries list should produce an empty JSON array."""
    assert to_json([]) == "[]"


def test_to_json_single_entry():
    """Single entry should produce a JSON array with one object."""
    entries = [_entry()]
    result = to_json(entries)
    assert result.startswith("[")
    assert result.endswith("]")
    assert '"ip":"10.0.0.1"' in result
    assert '"status":200' in result
    assert '"bytes":100' in result


def test_to_json_multiple_entries():
    """Multiple entries should be comma-separated in the JSON array."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_json(entries)
    assert result.count('"status":200') == 1
    assert result.count('"status":404') == 1


def test_to_json_timestamp_isoformat():
    """Timestamp should be rendered as ISO format string."""
    entries = [_entry()]
    result = to_json(entries)
    assert "2026-01-01T12:00:00+00:00" in result


def test_to_json_zero_bytes():
    """Zero bytes should render as 0, not as a dash."""
    entries = [_entry(bytes=0)]
    result = to_json(entries)
    assert '"bytes":0' in result


def test_to_json_large_bytes():
    """Large byte values should render correctly."""
    entries = [_entry(bytes=999999999)]
    result = to_json(entries)
    assert '"bytes":999999999' in result


def test_to_json_special_url():
    """URLs with special characters should be included as-is."""
    entries = [_entry(url="/path?foo=bar&baz=1")]
    result = to_json(entries)
    assert "/path?foo=bar&baz=1" in result


def test_to_json_unicode_url():
    """Unicode characters in URLs should be preserved."""
    entries = [_entry(url="/café")]
    result = to_json(entries)
    assert "/café" in result


# ── to_csv ────────────────────────────────────────────────────────────────


def test_to_csv_empty():
    """Empty entries should produce only the header row."""
    result = to_csv([])
    lines = result.strip().split("\n")
    assert len(lines) == 1
    assert "ip,user,timestamp,method,url,protocol,status,bytes" in lines[0]


def test_to_csv_single_entry():
    """Single entry should produce header + one data row."""
    entries = [_entry()]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 2
    assert "10.0.0.1" in lines[1]


def test_to_csv_multiple_entries():
    """Multiple entries should produce header + N data rows."""
    entries = [_entry(status=200), _entry(status=404), _entry(status=500)]
    result = to_csv(entries)
    lines = result.strip().split("\n")
    assert len(lines) == 4  # header + 3 entries


def test_to_csv_commas_in_fields():
    """Fields with commas should be properly quoted by csv.writer."""
    entries = [_entry(user="user,name")]
    result = to_csv(entries)
    # csv.writer will quote the field
    assert "user,name" in result


# ── to_text ───────────────────────────────────────────────────────────────


def test_to_text_empty():
    """Empty entries should produce an empty string."""
    assert to_text([]) == ""


def test_to_text_single_entry():
    """Single entry should produce one formatted line."""
    entries = [_entry()]
    result = to_text(entries)
    assert "10.0.0.1" in result
    assert "GET" in result
    assert "200" in result
    assert "/" in result


def test_to_text_multiple_entries():
    """Multiple entries should be newline-separated."""
    entries = [_entry(status=200), _entry(status=404)]
    result = to_text(entries)
    lines = result.split("\n")
    assert len(lines) == 2


def test_to_text_ip_right_aligned():
    """IP addresses should be right-aligned in the text output."""
    entries = [_entry(ip="1.2.3.4")]
    result = to_text(entries)
    # IP is right-aligned in 15-char field
    assert "1.2.3.4" in result


def test_to_text_method_left_aligned():
    """HTTP method should be left-aligned in the text output."""
    entries = [_entry(method="POST")]
    result = to_text(entries)
    assert "POST" in result


# ── render_aggregate ──────────────────────────────────────────────────────


def test_render_aggregate_text_counter():
    """Counter objects should render as tab-separated key-value pairs."""
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_text_dict():
    """Dict-like objects should render as tab-separated key-value pairs."""
    agg = {"a": 1, "b": 2}
    result = render_aggregate(agg, fmt="text")
    assert "a\t1" in result
    assert "b\t2" in result


def test_render_aggregate_text_list_of_tuples():
    """List of tuples should render as tab-separated key-value pairs."""
    agg = [("url1", 10), ("url2", 5)]
    result = render_aggregate(agg, fmt="text")
    assert "url1\t10" in result
    assert "url2\t5" in result


def test_render_aggregate_json_counter():
    """Counter objects should render as JSON-like key-value pairs."""
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="json")
    assert '"200":10' in result
    assert '"404":3' in result


def test_render_aggregate_json_list_of_tuples():
    """List of tuples should render as JSON-like key-value pairs."""
    agg = [("url1", 10), ("url2", 5)]
    result = render_aggregate(agg, fmt="json")
    assert '"url1":10' in result
    assert '"url2":5' in result


def test_render_aggregate_unknown_format():
    """Unknown format should raise ValueError."""
    agg = {"a": 1}
    try:
        render_aggregate(agg, fmt="xml")
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "unknown format" in str(e)


def test_render_aggregate_default_format():
    """Default format should be 'text'."""
    agg = Counter({"a": 1})
    result = render_aggregate(agg)
    assert "a\t1" in result
