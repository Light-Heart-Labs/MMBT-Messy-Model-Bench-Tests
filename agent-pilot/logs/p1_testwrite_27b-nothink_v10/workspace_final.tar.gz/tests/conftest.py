"""Shared pytest fixtures."""
import sys
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Workaround: Python 3.11 removed `collections.Iterable` (moved to collections.abc).
# The source code uses the old import. We patch it so the module can load.
import collections
if not hasattr(collections, "Iterable"):
    from collections.abc import Iterable
    collections.Iterable = Iterable
