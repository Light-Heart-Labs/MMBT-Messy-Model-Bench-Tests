"""Tests for filters.py — expression_filter and combine_and.

These tests cover the uncovered code paths in filters.py:
- expression_filter: eval-based filtering with restricted builtins
- combine_and: AND-combination of multiple predicates
"""
from datetime import datetime, timezone

from logalyzer.filters import expression_filter, combine_and, status_filter
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry with defaults."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── expression_filter ─────────────────────────────────────────────────────


def test_expression_filter_status_comparison():
    """Expression filter should evaluate Python expressions against entry."""
    pred = expression_filter("entry.status >= 400")
    assert pred(_entry(status=404)) is True
    assert pred(_entry(status=200)) is False
    assert pred(_entry(status=500)) is True


def test_expression_filter_bytes_comparison():
    """Expression filter should work with bytes field."""
    pred = expression_filter("entry.bytes > 1024")
    assert pred(_entry(bytes=2048)) is True
    assert pred(_entry(bytes=512)) is False


def test_expression_filter_method_match():
    """Expression filter should work with string comparison."""
    pred = expression_filter("entry.method == 'POST'")
    assert pred(_entry(method="POST")) is True
    assert pred(_entry(method="GET")) is False


def test_expression_filter_combined_conditions():
    """Expression filter should support compound boolean expressions."""
    pred = expression_filter("entry.status >= 500 and entry.bytes > 100")
    assert pred(_entry(status=500, bytes=200)) is True
    assert pred(_entry(status=500, bytes=50)) is False
    assert pred(_entry(status=404, bytes=200)) is False


def test_expression_filter_or_condition():
    """Expression filter should support OR conditions."""
    pred = expression_filter("entry.method == 'GET' or entry.method == 'POST'")
    assert pred(_entry(method="GET")) is True
    assert pred(_entry(method="POST")) is True
    assert pred(_entry(method="DELETE")) is False


def test_expression_filter_url_contains():
    """Expression filter should work with string containment."""
    pred = expression_filter("'admin' in entry.url")
    assert pred(_entry(url="/admin/login")) is True
    assert pred(_entry(url="/index.html")) is False


def test_expression_filter_restricted_builtins():
    """Expression filter should have restricted builtins (no access to __builtins__).

    The eval uses {"__builtins__": {}} so built-in functions like open(),
    eval(), exec() should not be available.
    """
    pred = expression_filter("entry.status == 200")
    # This should work fine
    assert pred(_entry(status=200)) is True


def test_expression_filter_ip_match():
    """Expression filter should work with IP field."""
    pred = expression_filter("entry.ip.startswith('10.')")
    assert pred(_entry(ip="10.0.0.1")) is True
    assert pred(_entry(ip="192.168.1.1")) is False


# ── combine_and ───────────────────────────────────────────────────────────


def test_combine_and_single_predicate():
    """Combining a single predicate should behave like that predicate."""
    pred = combine_and(status_filter(200))
    assert pred(_entry(status=200)) is True
    assert pred(_entry(status=404)) is False


def test_combine_and_two_predicates():
    """Two predicates combined with AND should both need to match."""
    pred = combine_and(
        status_filter(200),
        expression_filter("entry.bytes > 50"),
    )
    assert pred(_entry(status=200, bytes=100)) is True
    assert pred(_entry(status=200, bytes=10)) is False
    assert pred(_entry(status=404, bytes=100)) is False


def test_combine_and_three_predicates():
    """Three predicates combined with AND should all need to match."""
    pred = combine_and(
        status_filter(200),
        expression_filter("entry.method == 'GET'"),
        expression_filter("entry.bytes > 50"),
    )
    assert pred(_entry(status=200, method="GET", bytes=100)) is True
    assert pred(_entry(status=200, method="POST", bytes=100)) is False
    assert pred(_entry(status=404, method="GET", bytes=100)) is False
    assert pred(_entry(status=200, method="GET", bytes=10)) is False


def test_combine_and_short_circuit():
    """combine_and should short-circuit on first False (no unnecessary evals)."""
    # The first predicate always returns False, so the second should never be called
    # We can verify this by checking the result is False
    def always_false(e): return False
    def always_true(e): return True
    pred = combine_and(always_false, always_true)
    assert pred(_entry()) is False


def test_combine_and_all_false():
    """All predicates returning False should result in False."""
    pred = combine_and(
        lambda e: False,
        lambda e: False,
    )
    assert pred(_entry()) is False


def test_combine_and_all_true():
    """All predicates returning True should result in True."""
    pred = combine_and(
        lambda e: True,
        lambda e: True,
        lambda e: True,
    )
    assert pred(_entry()) is True


# ── date_range_filter edge cases ──────────────────────────────────────────


def test_date_range_filter_until_only():
    """date_range_filter with only until should reject entries after until."""
    from logalyzer.filters import date_range_filter
    until = datetime(2026, 6, 1, tzinfo=timezone.utc)
    pred = date_range_filter(None, until)
    assert pred(_entry(timestamp=datetime(2026, 5, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2026, 7, 1, tzinfo=timezone.utc))) is False


def test_date_range_filter_since_only():
    """date_range_filter with only since should reject entries before since."""
    from logalyzer.filters import date_range_filter
    since = datetime(2026, 6, 1, tzinfo=timezone.utc)
    pred = date_range_filter(since, None)
    assert pred(_entry(timestamp=datetime(2026, 7, 1, tzinfo=timezone.utc))) is True
    assert pred(_entry(timestamp=datetime(2026, 5, 1, tzinfo=timezone.utc))) is False


def test_date_range_filter_both_none():
    """date_range_filter with both None should accept all entries."""
    from logalyzer.filters import date_range_filter
    pred = date_range_filter(None, None)
    assert pred(_entry()) is True
