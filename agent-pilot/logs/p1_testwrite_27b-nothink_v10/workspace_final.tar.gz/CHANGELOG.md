# CHANGELOG

## v0.3.1-test-coverage-improvement

### Coverage Delta

| Metric | Before | After | Delta |
|--------|--------|-------|-------|
| Total statements | 287 | 287 | — |
| Missed statements | 190 | 1 | -189 |
| Coverage | 34% | 99% | +65% |

### Per-Module Coverage

| Module | Before | After |
|--------|--------|-------|
| `__init__.py` | 100% | 100% |
| `aggregate.py` | 100% | 100% |
| `cli.py` | 0% | 98% |
| `experimental.py` | 0% | 100% |
| `filters.py` | 74% | 100% |
| `io.py` | 0% | 100% |
| `output.py` | 0% | 100% |
| `parser.py` | 86% | 100% |
| `utils.py` | 0% | 100% |

### Test Files Added

1. **tests/test_experimental.py** (16 tests) — Full coverage of `detect_anomalies()` and `session_window()` including empty input, single entries, burst detection, session splitting, multi-IP handling, and boundary conditions.

2. **tests/test_output.py** (24 tests) — Full coverage of `to_json()`, `to_csv()`, `to_text()`, and `render_aggregate()` including empty entries, special characters, unicode URLs, and unknown format error handling.

3. **tests/test_utils.py** (30 tests) — Full coverage of `parse_iso_date()`, `format_bytes()`, `format_legacy()`, and `chunked()` including zero/negative values, boundary conditions (B/KB/MB/GB/TB/PB transitions), and generator behavior.

4. **tests/test_io.py** (14 tests) — Full coverage of `load()` and `load_iter()` including empty files, no trailing newline, mixed valid/invalid lines, and file-not-found errors.

5. **tests/test_filters_extra.py** (17 tests) — Coverage of `expression_filter()` and `combine_and()` including compound expressions, short-circuit evaluation, and `date_range_filter` edge cases (since-only, until-only, both-None).

6. **tests/test_parser_extra.py** (19 tests) — Edge cases for `parse_timestamp()` (invalid formats, positive/negative offsets), `parse_line()` (whitespace, IPv6, large byte counts, query strings), and `parse_lines()` generator behavior.

7. **tests/test_cli.py** (35 tests) — Coverage of `build_parser()` argument parsing and `main()` with various filter combinations (--status, --url, --ip, --since, --until, --expr, --aggregate, --format, --top).

8. **tests/test_aggregate_extra.py** (15 tests) — Edge cases for `by_status()`, `by_url()`, `by_hour()`, and `total_bytes()` including empty input, top=None, top=0, midnight bucketing.

### Pre-existing Failing Tests (Not Modified)

Three starter tests fail due to bugs in the source code (documented in `research/dead-ends.md`):

1. `test_status_filter_works_with_cli_string_input` — `status_filter` doesn't convert string to int
2. `test_url_regex_finds_substring_match` — `url_regex_filter` uses `match()` instead of `search()`
3. `test_timestamp_july_parses_correctly` — `MONTH_NAMES` list is missing "Jul"

### Uncovered Lines

- `cli.py:84` — `sys.exit(main())` in `if __name__ == "__main__"` block (unreachable through imports)
