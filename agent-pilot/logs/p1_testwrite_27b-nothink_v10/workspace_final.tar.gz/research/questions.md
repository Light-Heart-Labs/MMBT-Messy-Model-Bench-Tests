# Questions

1. Should we test `expression_filter` with dangerous expressions? The function uses `eval()` with restricted builtins. Testing malicious expressions could be a security concern, but testing that the restriction works is valuable.

2. The `by_hour` function uses `time.localtime()` which depends on the system timezone. The existing test asserts UTC behavior but the function may produce different results on different machines. We should test this carefully.

3. `format_legacy` is marked as "legacy" and "no longer used internally". Should we test it? Yes — the task explicitly says to test dead code to increase coverage.
