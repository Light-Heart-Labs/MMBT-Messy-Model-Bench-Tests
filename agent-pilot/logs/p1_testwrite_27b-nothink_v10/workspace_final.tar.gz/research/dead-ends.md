# Dead Ends

## Failing Starter Tests (Not Modified)

Three existing tests fail against the current codebase due to bugs in the source code:

### 1. `test_status_filter_works_with_cli_string_input` (test_filters.py)
- **Bug**: `status_filter` does `entry.status == status` which compares `int` to `str`. `"404" == 404` is `False`.
- **Impact**: CLI `--status` flag effectively doesn't work.
- **Action**: Documented, not fixed. Per instructions: "If you find a bug, document it but don't fix it."

### 2. `test_url_regex_finds_substring_match` (test_filters.py)
- **Bug**: `url_regex_filter` uses `rx.match()` which anchors at the start of the string. Pattern `"admin"` won't match `"/admin/login"` because the URL starts with `/`.
- **Impact**: URL regex filter only works with anchored patterns.
- **Action**: Documented, not fixed.

### 3. `test_timestamp_july_parses_correctly` (test_parser.py)
- **Bug**: `MONTH_NAMES` list in `parser.py` is missing `"Jul"`. The list goes `["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Aug", ...]` — July is skipped.
- **Impact**: Any log entry dated in July will fail to parse.
- **Action**: Documented, not fixed.

## Design Decisions

### collections.Iterable monkey-patch
The source code imports `from collections import Iterable` which was removed in Python 3.11 (moved to `collections.abc`). We monkey-patch this in `conftest.py` to allow the module to load. This is a test infrastructure workaround, not a production code change.
