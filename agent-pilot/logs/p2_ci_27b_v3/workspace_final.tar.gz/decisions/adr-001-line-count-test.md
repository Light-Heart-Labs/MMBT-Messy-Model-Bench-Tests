# ADR-001: Fix `test_line_count_matches_qty_sum` by updating the test, not the code

## Context

The test `test_line_count_matches_qty_sum` in `tests/test_cart.py` expected `Cart.line_count()` to return the total quantity across all lines (5). However, the implementation returns the number of lines (2).

## Decision

Update the test to match the v0.3.0 API, rather than reverting the code.

## Rationale

The CHANGELOG.md explicitly documents this as an intentional v0.3.0 breaking change:

> `Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior.

The test was written for v0.2.0 behavior and was never updated. The code correctly implements the v0.3.0 spec.

## Consequences

- The test is renamed to `test_line_count_returns_number_of_lines` to accurately describe what it verifies.
- The assertion is changed from `== 5` to `== 2`.
- The docstring is updated to reference the v0.3.0 behavior.
