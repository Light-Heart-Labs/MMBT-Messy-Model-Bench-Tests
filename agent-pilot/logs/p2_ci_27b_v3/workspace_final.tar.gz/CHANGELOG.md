# Changelog

## v0.3.2

- **Fix**: `discount_amount()` now correctly divides by 100 when computing the discount from a percent value. Previously it multiplied `price * percent_off` directly, producing values 100x too large (e.g., `discount_amount(100.0, 20.0)` returned `2000.0` instead of `20.0`). This was a regression from the v0.3.0 API change from fraction to percent.
- **Fix**: Removed unused `json` import from `cart.py` (ruff F401).
- **Fix**: Updated `test_line_count_matches_qty_sum` → `test_line_count_returns_number_of_lines` to match the v0.3.0 breaking change where `Cart.line_count()` returns the number of lines, not total quantity.
- **Style**: Sorted imports and modernized type annotations (`List` → `list`, `Optional[X]` → `X | None`) to satisfy ruff rules I001, UP006, UP035, UP045.
- **Verification**: `ruff check src/ tests/` exits 0 with no errors. `pytest -q` passes all 7 tests with exit code 0.

## v0.3.1 (current — CI red)

CI is failing on this version. See `ci_failure.log` for the full output.

## v0.3.0

- **BREAKING**: `discount_amount()` and `apply_discount()` now take percent (0-100)
  instead of fraction (0.0-1.0). Update callers from `apply_discount(p, 0.2)` to
  `apply_discount(p, 20.0)`.
- `Cart.line_count()` now returns the number of lines, not the total quantity
  across lines. Tests should be updated where they relied on the old behavior.

## v0.2.0

- Added `Cart.set_discount()` for cart-wide discounts.
- `Cart.line_count()` returns total quantity across lines.

## v0.1.0

- Initial release.
