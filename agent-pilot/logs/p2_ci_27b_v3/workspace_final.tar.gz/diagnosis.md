# Diagnosis of CI Failures

## 1. Ruff F401: Unused `json` import in `src/discountkit/cart.py`

**What was wrong:** Line 4 of `cart.py` had `import json` with a comment saying "PLANTED BUG #3: unused import". This triggered ruff's F401 rule.

**Fix:** Removed the unused import line.

**Why:** The import served no purpose and was explicitly marked as a planted bug.

---

## 2. Ruff I001/UP006/UP035/UP045: Import sorting and deprecated typing

**What was wrong:** After removing the `json` import, ruff flagged:
- Unsorted import blocks (I001) in `__init__.py`, `cart.py`, and `test_discount.py`
- `typing.List` deprecated in favor of built-in `list` (UP035/UP006)
- `Optional[float]` should be `float | None` (UP045)

**Fix:** Ran `ruff check --fix` to auto-fix all of these.

**Why:** These are style/modernization issues caught by the configured ruff rules (`E`, `F`, `I`, `B`, `UP`).

---

## 3. `discount_amount` returns wrong value (pytest failures in `test_discount.py`)

**What was wrong:** `discount_amount(100.0, 20.0)` returned `2000.0` instead of `20.0`. The function computed `price * percent_off` but since v0.3.0 the API takes percent (0-100) not fraction (0-1), it should compute `price * percent_off / 100`.

**Fix:** Changed `return round(price * percent_off, 2)` to `return round(price * percent_off / 100, 2)` in `src/discountkit/discount.py`.

**Why:** The changelog documents that v0.3.0 changed the API from fraction to percent, but the implementation was never updated to divide by 100. The tests were correct; the code was wrong.

---

## 4. `line_count` test expects old v0.2.0 behavior (pytest failure in `test_cart.py`)

**What was wrong:** `test_line_count_matches_qty_sum` asserted `c.line_count() == 5` (total quantity), but v0.3.0 changed `line_count()` to return the number of lines (2), not total quantity.

**Fix:** Updated the test to assert `c.line_count() == 2` and renamed it to `test_line_count_returns_number_of_lines`.

**Why:** The changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior." The code was correct per the v0.3.0 spec; the test was stale.
