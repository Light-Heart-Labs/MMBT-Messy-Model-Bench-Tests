# Acquisition Review Memo — Borealis Analytics (Project Lighthouse)

**To:** Executive Committee
**From:** [Reviewer], Executive Committee
**Date:** 2026-04-16
**Re:** Independent assessment of Corp Dev recommendation to proceed to LOI at $84M

---

## Recommendation: HOLD — do not issue LOI until critical diligence gaps are closed

I would **not** approve the LOI in its current form. The deal has merit — growth trajectory, net retention, and engineering quality are genuinely attractive — but the diligence pack contains material gaps and optimistic assumptions. I would reverse to **PROCEED** if the items below are addressed within two weeks. I would move to **PASS** if any red-flag items (★) prove true.

---

## Strongest Concerns

### 1. ★ Valuation anchor is fragile

The pack justifies $84M (~7.4x ARR) citing three comps at 7x–12x ARR, but provides no detail on deal structure, earnouts, or post-close performance. The lowest comp (Trellis at 7x) is used as the floor with no rationale for why Borealis deserves a premium. If comps included significant earnouts, effective multiples could be materially lower. **The pack overclaims comparability without substantiating it.**

### 2. ★ Customer concentration unknown

With ~280 customers and median ARR of $32K, implied total customer ARR (~$8.96M) is notably below reported $11.4M ARR, suggesting a right-skewed distribution with a few large customers. The pack does not disclose what percentage of ARR the top five reference-called customers represent. If the top five account for >25% of ARR, the loss of any one would be material. All four quoted testimonials are uniformly positive. **The pack omits churned customers, detractors, and the one customer who declined to be quoted.**

### 3. ★ Integration plan is optimistic

The pack states "~85% retention expected based on conversations with their VP Eng" — a single-source estimate from someone with incentive to overstate. The plan also calls for sunsetting Aurora within 12 months post-close, aggressive for 280 active customers. **The pack underexplains customer attrition risk during migration and the cost of a longer transition.**

### 4. ★ Synergy estimate is asserted, not derived

The $3.2M annual cost savings from "consolidated infra" is stated without any breakdown. We do not know whether this assumes headcount reductions, infrastructure consolidation, or both. **The pack omits the methodology entirely.**

### 5. ★ Runway calculation is misleading

The pack states "22 months runway at last cap raise" but current cash is $4.1M at $750K/month burn = ~5.5 months. The 22-month figure is historical. No explanation is given for why cash dropped from the implied ~$16.5M to $4.1M. **The pack conflates historical with current runway without flagging the gap.**

### 6. No competitive landscape discussion

The pack makes no mention of Borealis's competitive landscape, market size, or barriers to entry. **Notable omission for a strategic rationale section.**

### 7. IRR estimate lacks transparency

The "28-34% risk-adjusted IRR over 4 years" is stated without model inputs. Given concerns about valuation, synergies, and retention, this range appears to be an assertion rather than a demonstrated calculation.

---

## Specific Diligence Asks (Next 2 Weeks)

See `/workspace/asks.md` for the full list with owners and deadlines. Key items:

1. **Customer concentration** — What % of ARR do the top 5, top 10, and top 20 customers represent?
2. **Churned customer interviews** — Speak to at least 3 customers who left in the past 12 months.
3. **Comp deal deep-dive** — Obtain deal structure details (earnouts, holdbacks) for all three comparables.
4. **Retention risk model** — Stress-test at 60% and 40% retention.
5. **Synergy derivation** — Detailed breakdown of the $3.2M savings estimate.
6. **Runway recalculation** — Confirm months of runway from current cash.
7. **Competitive landscape memo** — Competitors, market size, positioning.
8. **IRR model transparency** — Share the model with all inputs visible.

---

## Bottom Line

The deal is not a pass — it has genuine merit. But the diligence pack reads as advocacy, not analysis. Before committing $84M, we need to close the gaps above. I recommend holding the LOI for two weeks to complete these asks, then reconvening.
