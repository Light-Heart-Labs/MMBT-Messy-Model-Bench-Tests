# Diligence Asks — Next 2 Weeks

**Target completion:** 2026-04-30 (aligned with decision deadline)

---

## 1. Customer Concentration Analysis

| Field | Detail |
|-------|--------|
| **Question** | What percentage of Borealis's ARR is represented by the top 5, top 10, and top 20 customers? |
| **Owner** | Corp Dev (lead), Finance |
| **Deadline** | 2026-04-20 |
| **Rationale** | The pack references the "five largest customers" but does not disclose their revenue share. If concentration is high, the deal carries material customer-loss risk. |
| **Deliverable** | Table showing top-5, top-10, top-20 customer ARR as % of total ARR. |

---

## 2. Churned Customer Interviews

| Field | Detail |
|-------|--------|
| **Question** | Why did the ~9% of customers who churned (per logo retention of 91%) leave Borealis? |
| **Owner** | Corp Dev (lead), Customer Success |
| **Deadline** | 2026-04-23 |
| **Rationale** | The pack discusses only satisfied customers. Understanding churn reasons is critical to assessing product-market fit and post-close retention risk. |
| **Deliverable** | Summary of 3+ churned customer interviews, including reasons for leaving and whether they migrated to a competitor. |

---

## 3. Comparable Transaction Deep-Dive

| Field | Detail |
|-------|--------|
| **Question** | What was the deal structure (upfront cash, earnouts, holdbacks, contingent consideration) for Hexa Insights, Aspen Data, and Trellis Analytics? How did each perform post-close? |
| **Owner** | Corp Dev (lead), External M&A advisor |
| **Deadline** | 2026-04-23 |
| **Rationale** | The pack uses headline multiples (7x–12x ARR) without disclosing deal structure. Earnouts and holdbacks can materially reduce effective consideration. |
| **Deliverable** | One-page summary per comp: deal structure, effective multiple, and any publicly available post-close performance data. |

---

## 4. Retention Risk Model

| Field | Detail |
|-------|--------|
| **Question** | What is the realistic post-close retention rate for Borealis employees, and what does the financial model look like at 60% and 40% retention? |
| **Owner** | Finance (lead), HR, Corp Dev |
| **Deadline** | 2026-04-25 |
| **Rationale** | The pack's 85% retention estimate is based on a single conversation with Borealis's VP Eng. Independent modeling with downside scenarios is needed. |
| **Deliverable** | Retention scenario analysis (85%, 60%, 40%) with impact on revenue, synergy capture, and IRR. |

---

## 5. Synergy Derivation

| Field | Detail |
|-------|--------|
| **Question** | What is the detailed breakdown of the $3.2M annual cost savings estimate? What assumptions underlie it? |
| **Owner** | Finance (lead), Engineering, Corp Dev |
| **Deadline** | 2026-04-22 |
| **Rationale** | The synergy figure is stated without any supporting methodology. The committee needs to understand what drives the number and how defensible it is. |
| **Deliverable** | Line-item breakdown of $3.2M savings (infra, headcount, tools, etc.) with assumptions and timeline for realization. |

---

## 6. Current Runway Recalculation

| Field | Detail |
|-------|--------|
| **Question** | What is Borealis's current runway from the $4.1M cash position at the current $750K/month burn rate? Why did cash decline from the implied ~$16.5M at last cap raise? |
| **Owner** | Finance (lead), Corp Dev |
| **Deadline** | 2026-04-18 |
| **Rationale** | The pack cites "22 months runway at last cap raise" but current cash suggests only ~5.5 months. This gap needs explanation and may indicate accelerating burn or other cash drains. |
| **Deliverable** | Current runway calculation and explanation of cash drawdown since last cap raise. |

---

## 7. Competitive Landscape Memo

| Field | Detail |
|-------|--------|
| **Question** | Who are Borealis's direct and indirect competitors? What is the market size for mid-market e-commerce analytics? What are Borealis's competitive advantages? |
| **Owner** | Corp Dev (lead), Strategy |
| **Deadline** | 2026-04-25 |
| **Rationale** | The pack makes no mention of the competitive landscape. Understanding the market dynamics is essential to validating the strategic rationale. |
| **Deliverable** | 2-page competitive landscape memo covering competitors, market size, growth trends, and Borealis's positioning. |

---

## 8. IRR Model Transparency

| Field | Detail |
|-------|--------|
| **Question** | What are the inputs and assumptions behind the 28-34% IRR estimate? Can the model be shared with the committee? |
| **Owner** | Finance (lead), Corp Dev |
| **Deadline** | 2026-04-22 |
| **Rationale** | The IRR range is stated without showing the model. The committee needs to validate the return case and run sensitivity analyses. |
| **Deliverable** | Shared IRR model with all inputs visible, plus sensitivity analysis on key variables (revenue growth, retention, synergies, valuation). |

---

## 9. Security and Compliance Review

| Field | Detail |
|-------|--------|
| **Question** | Does Borealis have SOC 2 certification? What is their data privacy posture (GDPR, CCPA)? Any pending security incidents or breaches? |
| **Owner** | Security (lead), Legal |
| **Deadline** | 2026-04-25 |
| **Rationale** | As a customer-data-analytics company, Borealis handles sensitive data. Security and compliance posture is critical for integration risk assessment. |
| **Deliverable** | Security and compliance review summary, including certification status and any known incidents. |

---

## 10. Deal Structure Analysis

| Field | Detail |
|-------|--------|
| **Question** | What are the implications of a "cash-heavy" deal structure for our balance sheet? What is Borealis's motivation for preferring cash? |
| **Owner** | Finance (lead), Corp Dev |
| **Deadline** | 2026-04-23 |
| **Rationale** | The pack notes Borealis prefers cash-heavy but does not analyze the implications. Cash-heavy may signal that founders/investors want liquidity, which could affect post-close retention. |
| **Deliverable** | Analysis of deal structure options (all-cash, mixed, stock-heavy) with balance sheet impact and retention implications. |

---

## Summary Timeline

| Deadline | Asks Due |
|----------|----------|
| 2026-04-18 | #6 (Runway) |
| 2026-04-20 | #1 (Customer Concentration) |
| 2026-04-22 | #5 (Synergies), #8 (IRR Model) |
| 2026-04-23 | #2 (Churned Customers), #3 (Comps), #10 (Deal Structure) |
| 2026-04-25 | #4 (Retention Model), #7 (Competition), #9 (Security) |
| 2026-04-30 | Decision reconvene |
