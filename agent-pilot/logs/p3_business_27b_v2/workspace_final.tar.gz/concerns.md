# Concerns — Full Enumeration

This document captures every concern identified during review of the Borealis Analytics deal pack, ranked by severity. Items marked ★ are considered material (deal-breaker potential). Items without the star are notable but less likely to change the recommendation on their own.

---

## ★ Material Concerns

### 1. Valuation anchor is fragile
- The pack cites three comps at 7x–12x ARR to justify $84M (~7.4x ARR).
- No detail on deal structure (earnouts, holdbacks, contingent consideration) for any comp.
- No detail on post-close performance of acquired companies (did they meet projections?).
- The lowest comp (Trellis at 7x) is used as the floor, but no rationale is given for why Borealis deserves a premium over Trellis.
- If any comp included significant earnout components, the effective upfront multiple could be much lower.
- **Risk:** Overpayment if comps are not truly comparable.

### 2. Customer concentration unknown
- ~280 customers, median ARR $32K → implied total customer ARR of ~$8.96M (but reported ARR is $11.4M, suggesting a long tail of smaller customers and/or a few large ones).
- The gap between median-implied ARR ($8.96M) and reported ARR ($11.4M) suggests right-skewed distribution — a few large customers may dominate.
- Top 5 customers were reference-called, but their % of total ARR is not disclosed.
- If top 5 = >25% of ARR, concentration risk is material.
- **Risk:** Loss of a single large customer could significantly impact post-close revenue.

### 3. Integration plan is optimistic
- 85% retention "based on conversations with their VP Eng" — single source, single data point, from someone with incentive to overstate.
- No retention package details (RSUs, bonuses, role changes) are discussed.
- Aurora platform sunset in 12 months is aggressive for 280 active customers.
- No discussion of customer communication plan for the migration.
- No contingency plan if migration takes longer than 12 months.
- **Risk:** Key talent leaves, customers churn during migration, integration costs exceed budget.

### 4. Synergy estimate is asserted, not derived
- $3.2M annual cost savings stated without any breakdown.
- No indication of whether savings come from headcount, infrastructure, or both.
- No timeline for when savings begin to accrue.
- No sensitivity analysis (what if savings are only 50% of estimate?).
- **Risk:** IRR model is overstated if synergies don't materialize.

### 5. Runway calculation is misleading
- Pack states "22 months runway at last cap raise" but current cash is $4.1M at $750K/month burn = ~5.5 months.
- The 22-month figure is historical and no longer relevant.
- No explanation of why cash dropped from implied ~$16.5M (22 months × $750K) to $4.1M.
- **Risk:** Borealis may need a bridge financing or accelerated integration to avoid running out of cash.

---

## Notable Concerns (Lower Severity)

### 6. IRR estimate lacks transparency
- "28-34% risk-adjusted IRR over 4 years" stated without model inputs.
- No sensitivity analysis shown (what if revenue growth slows, retention drops, synergies are lower?).
- No discussion of the discount rate or risk premium applied.
- **Risk:** IRR may be overstated; committee cannot validate the return case.

### 7. No competitive landscape discussion
- Pack makes no mention of Borealis's direct or indirect competitors.
- No market size estimate for mid-market e-commerce analytics.
- No discussion of barriers to entry or defensibility.
- **Risk:** If the market is crowded or shrinking, the strategic rationale weakens.

### 8. Testimonials are uniformly positive
- All four quoted testimonials are glowing; no nuance or criticism.
- One customer declined to be quoted — we don't know why.
- No mention of any detractors or customers with mixed feedback.
- **Risk:** Reference calls may have been cherry-picked.

### 9. Churned customers not addressed
- Logo retention is 91%, meaning 9% of customers left in the period.
- No discussion of why those customers left.
- No interviews with churned customers.
- **Risk:** Churn reasons may reveal product or service weaknesses.

### 10. Engineering review may be superficial
- "Clean, well-tested" codebase assessment from our engineering review.
- No detail on test coverage, CI/CD maturity, or deployment frequency.
- No mention of security audit results or compliance certifications (SOC 2, GDPR, etc.).
- **Risk:** Hidden technical debt or compliance gaps could increase integration cost.

### 11. Product roadmap validation is one-sided
- "Our PM team validated all three are differentiated vs current alternatives."
- No detail on what "differentiated" means or how it was assessed.
- No customer input on roadmap priorities.
- **Risk:** Roadmap may not align with our platform strategy or customer needs.

### 12. No discussion of cultural fit
- Borealis team relocates to our HQ — no discussion of cultural integration.
- No mention of Borealis's company culture, values, or management style.
- **Risk:** Cultural mismatch could accelerate post-close attrition.

### 13. Deal structure TBD
- "Cash + stock split TBD; Borealis preference is cash-heavy."
- No discussion of how the split affects our balance sheet or dilution.
- No discussion of Borealis's motivation for cash-heavy (liquidity event for founders/investors?).
- **Risk:** Cash-heavy deal may strain our balance sheet or signal that Borealis wants out quickly.

### 14. No mention of legal or regulatory issues
- No discussion of pending litigation, IP disputes, or regulatory exposure.
- No mention of data privacy compliance (critical for a customer-data-analytics company).
- **Risk:** Hidden legal liabilities could emerge post-close.

### 15. NPS "high 40s" is mediocre for a SaaS company
- NPS in the "high 40s" is decent but not exceptional for a growing SaaS company.
- For context, top-tier SaaS companies often report NPS >60.
- **Risk:** Customer satisfaction may not be as strong as the pack implies.

---

## Summary

| Severity | Count | Key Themes |
|----------|-------|------------|
| ★ Material | 5 | Valuation, concentration, integration, synergies, runway |
| Notable | 10 | IRR, competition, testimonials, churn, engineering, roadmap, culture, deal structure, legal, NPS |

The five material concerns are sufficient to justify a HOLD recommendation. The ten notable concerns, while individually less impactful, collectively suggest the diligence pack is advocacy-heavy and analysis-light.
