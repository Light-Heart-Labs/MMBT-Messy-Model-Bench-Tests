# Borealis Analytics Acquisition Review — Output Guide

## How to Read This Output

This repository contains an independent executive committee review of the Corp Dev diligence pack for the proposed acquisition of Borealis Analytics at $84M.

### Files

| File | Purpose |
|------|---------|
| [`memo.md`](memo.md) | **Primary deliverable.** 1-page review memo with recommendation, key concerns, and diligence asks. Read this first. |
| [`concerns.md`](concerns.md) | Full enumeration of all 15 concerns identified, ranked by severity. Supports the memo. |
| [`asks.md`](asks.md) | Detailed diligence-ask list with owners, deadlines, and deliverables for the next 2 weeks. |
| [`decisions/`](decisions/) | Architecture Decision Records (ADRs) documenting judgment calls made during the review. |

### Reading Order

1. **Start with `memo.md`** — this is the executive summary and contains the recommendation.
2. **Read `concerns.md`** for the full list of issues, including lower-severity items not in the memo.
3. **Read `asks.md`** for the specific diligence questions to be answered in the next two weeks.
4. **Review `decisions/`** for the rationale behind key judgment calls (recommendation stance, concern classification, ask scope).

### Key Takeaway

The recommendation is **HOLD** — not PASS. The deal has merit but the diligence pack is advocacy-heavy and analysis-light. The committee should require the 10 diligence asks to be completed before reconvening on 2026-04-30.

### Source Material

The only source material used is the Corp Dev diligence pack at `/input/repo/deal_pack.md`. No external data, customer names, or financial figures were invented.
