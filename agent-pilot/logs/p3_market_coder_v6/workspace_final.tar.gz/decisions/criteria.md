# Decision Criteria

## 1. Security & Compliance
- SOC 2 Type II certification [required]
- ISO 27001 certification [preferred]
- Zero-knowledge architecture [required]
- Independent security audit history [required]

## 2. Admin & Management Features
- Google Workspace (G Suite) SSO integration [required]
- User provisioning/deprovisioning via SCIM [required]
- Audit logging with retention period [required]
- Emergency access / break-glass procedures [required]
- Admin dashboard usability [important]

## 3. Developer Experience
- GitHub integration for secrets management [important]
- CLI tool for automation [important]
- API for custom integrations [important]
- Browser extension support (Chrome, Firefox, Safari) [required]

## 4. User Experience
- Desktop apps (macOS, Windows, Linux) [required]
- Mobile apps (iOS, Android) [required]
- Family sharing / team sharing features [important]
- Password generator & health monitoring [important]

## 5. Pricing & Commercial
- Transparent pricing [required]
- Annual billing option [preferred]
- Per-seat pricing for teams [required]
- Free tier or trial period [preferred]

## 6. Vendor Viability
- Established company (not pre-revenue startup) [required]
- Clear business model [required]
- Customer support channels [important]
