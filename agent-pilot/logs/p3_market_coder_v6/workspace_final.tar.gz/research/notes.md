# Research Notes

## Initial Goal
Research and recommend a password manager for a 50-person engineering team at a Series-B SaaS company.

## Key Constraints
- Current state: shadow IT (browser storage, sticky notes, Slack DMs)
- CTO mandate: fix within 90 days
- Team size: 50 people
- Industry: SaaS, likely using Google Workspace, Slack, GitHub

## Initial Product Candidates (based on industry reputation)
1. 1Password
2. Bitwarden
3. LastPass
4. Dashlane
5. Keeper Security

## Research Plan
1. Identify decision criteria (security, features, pricing, admin controls)
2. Research each product against criteria
3. Compare and recommend
4. Document sources for every claim

## Notes on Sources
- Need to verify pricing directly from vendor sites
- Need to verify security certifications (SOC2, ISO 27001) on trust pages
- Need to verify admin features and API capabilities
- Need to verify mobile/desktop app support
