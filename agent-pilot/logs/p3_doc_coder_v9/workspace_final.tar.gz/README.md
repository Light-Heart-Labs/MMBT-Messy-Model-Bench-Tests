# Nimbus Logistics, Inc. — Deal Evaluation Package

## Files

- `brief.md` — The 1-page executive brief (598 words). This is the primary deliverable.
- `key-facts.md` — A list of every material fact incorporated into the brief, with source attribution.
- `research/notes.md` — Working notes from reading the five sources, including tensions and source quality assessment.
- `decisions/adr.md` — ADR-style records for framing choices (recommendation stance, structure, tone, what to omit).

## How to Read This Output

1. Start with `brief.md` — the 1-page executive brief. This is the deliverable for the investor partner.
2. If you want to verify the reasoning, read `key-facts.md` to see all material facts and their sources.
3. For deeper context, read `research/notes.md` for the source-by-source summary and tensions.
4. For framing decisions, read `decisions/adr.md` for the ADR-style records.

## Recommendation Summary

**PASS** the follow-on investment. The company is in a restructuring phase, not a growth phase. The Series B was repriced down from $720M to $560M, and internal memos confirm major cost-cutting and negative unit economics. Wait for Q4 2026 breakeven proof before re-engaging.
