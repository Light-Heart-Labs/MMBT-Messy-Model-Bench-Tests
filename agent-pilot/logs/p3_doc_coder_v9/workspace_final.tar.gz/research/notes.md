# Research Notes — Nimbus Logistics, Inc.

## Source-by-source summary

### SOURCE 1 — Press Release (company-issued)
- Raised $84M Series B led by Lightning Capital, with Sequoia, Accel, FedEx Ventures participating
- Post-money valuation: $560M (up from $230M in Series A)
- Total funding: $128M
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400 customers, 187 employees (Oakland, Austin, Berlin)
- Founded 2021 by Mira Patel and Daniel Wong
- Platform: warehouse management, carrier orchestration, demand forecasting

### SOURCE 2 — TechCrunch News Article
- Lost two top-5 customers in late 2025:
  - Sundry Brands ($4.2M ARR) — non-renewed November (called "strategic mutual decision")
  - Klatch (fast-fashion) — exited December, migrated to competitor
- TechCrunch source says adjusted ARR after December churn is $36-37M (not $42M)
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026
- CEO claims net retention >110%
- Series B was originally meant to close at $720M valuation in late 2025, repriced down after Sundry non-renewal

### SOURCE 3 — Former Employee Blog Post
- Engineering quality is high; CTO Daniel Wong is "the real deal"
- Customer love is real; mid-market brands truly depend on platform
- Compensation competitive: $215K base + $50K equity for senior engineer
- Burn rate ~$4M/month all-in vs ~$3.5M/month revenue (mid-2025)
- Layoffs in February 2025: 22 people (~11% of org), mostly customer success and BD
- Top 5 customers = ~38% of ARR (customer concentration issue)
- Sundry loss was not a shock internally; timing relative to fundraise was rough
- Recommendation: join if you're senior (engineering work, equity upside), but not if you need job security in next 18 months

### SOURCE 4 — Internal Memo (leaked)
- CEO Mira Patel memo dated Feb 28, 2026: "Path to Profitability"
- 30% reduction in international headcount (Berlin office: 41 → 28-30 by end of Q2)
- Pause new hires in EMEA; reframe Berlin as "support hub" (not sales/expansion)
- Sunset "Nimbus Lite" tier (~310 customers, $5K-$20K ARR each); 90-day migration notice
- Secured $50M credit facility from Silicon Valley Bridge (described as "insurance, not operating capital")
- Goal: cash-flow breakeven by Q4 2026, extend runway to 36+ months, trigger Series C from strength

### SOURCE 5 — SEC Form D
- Filed 2026-01-22
- Total offering: $84M
- 7 investors
- First sale: 2026-01-14
- Security: Series B Preferred
- Use of proceeds: "expansion, working capital, general corporate purposes"

---

## Key tensions / contradictions

1. **ARR figure**: Press release says $42M; TechCrunch says adjusted for churn it's $36-37M
2. **Valuation**: Press release says $560M; TechCrunch says repriced down from $720M target
3. **Growth narrative**: Press release emphasizes expansion; internal memo shows major restructuring and layoffs
4. **Customer concentration**: Press release says 1,400 customers; TechCrunch and blog post highlight top-5 = ~38% of ARR
5. **Runway**: Press release implies strong position; internal memo describes "insurance" credit facility and path to breakeven
6. **Layoffs**: Not mentioned in press release; blog post and memo confirm (blog: Feb 2025, 22 people; memo: Berlin cut 30% by Q2 2026)

---

## Source quality assessment

- **Press release (Source 1)**: Company narrative only; omits negatives
- **TechCrunch (Source 2)**: Journalistic, cites sources; likely most balanced on financials
- **Blog post (Source 3)**: One ex-employee's view; credible on internal culture/comp but not financials
- **Memo (Source 4)**: Leaked internal doc; likely accurate on plans but reflects management's framing
- **SEC Form D (Source 5)**: Factual filing; confirms $84M raised, 7 investors, date

---

## Material facts (to be used in brief)

- Raised $84M Series B at $560M post-money valuation (Sources 1, 5)
- Original target valuation was $720M, repriced down (Source 2)
- Reported ARR: $42M (Source 1); adjusted for churn: $36-37M (Source 2)
- Top 5 customers = ~38% of ARR (Source 3)
- Lost Sundry ($4.2M ARR) and Klatch in late 2025 (Source 2)
- Burn rate ~$4M/month vs revenue ~$3.5M/month (Source 3)
- Layoffs in Feb 2025 (22 people, ~11% of org) (Source 3)
- Internal memo: 30% Berlin headcount cut, sunset Nimbus Lite tier (310 customers), $50M credit facility (Source 4)
- Goal: cash-flow breakeven by Q4 2026 (Source 4)

---

## Recommendation framing

The investor must decide: follow-on or pass?

Key positives:
- Strong engineering (CTO quality, clean architecture)
- Real customer love in mid-market segment
- New $50M credit facility extends runway
- Goal of breakeven by Q4 2026 is concrete

Key negatives:
- High customer concentration (top 5 = 38% of ARR)
- Recent churn of two top-5 customers
- Negative unit economics (burn > revenue)
- Layoffs and restructuring signal distress
- Repriced round suggests investor skepticism

Recommendation: **Pass the follow-on** — but with a clear path to re-engage if:
- Q2 2026 shows ARR >$38M (not just reported, but verified run-rate)
- Q3 2026 shows positive operating cash flow
- No further major customer churn in Q2

The company is in a restructuring phase; the current round was a down round with repricing. The internal memo shows they're in damage-control mode, not growth mode. The $50M credit facility is insurance, not growth capital.
