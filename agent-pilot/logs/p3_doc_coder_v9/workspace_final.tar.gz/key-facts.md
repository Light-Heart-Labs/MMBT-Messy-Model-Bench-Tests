# Key Facts — Nimbus Logistics, Inc.

## Funding & Valuation
- Raised $84M Series B at $560M post-money valuation, led by Lightning Capital with Sequoia, Accel, FedEx Ventures [Source 1, Source 5]
- Original target valuation was $720M; round was repriced down after Sundry non-renewal in early December [Source 2]
- Total funding: $128M across all rounds [Source 1]
- Secured $50M credit facility from Silicon Valley Bridge (described as "insurance, not operating capital") [Source 4]

## Financials
- Reported ARR: $42M as of Q4 2025 [Source 1]
- Adjusted ARR after December churn (Sundry and Klatch): $36-37M run-rate [Source 2]
- Burn rate: ~$4M/month all-in (mid-2025) [Source 3]
- Revenue: ~$3.5M/month (mid-2025) [Source 3]
- Negative unit economics: burn exceeds revenue [Source 3]

## Customers
- 1,400 customers reported [Source 1]
- Top 5 customers = ~38% of ARR (customer concentration risk) [Source 3]
- Lost Sundry Brands ($4.2M ARR) in November 2025 (non-renewed) [Source 2]
- Lost Klatch (fast-fashion) in December 2025 (migrated to competitor) [Source 2]
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 [Source 2]
- CEO claims net retention >110% [Source 2]

## Operations
- 187 employees (Oakland, Austin, Berlin) [Source 1]
- Layoffs in February 2025: 22 people (~11% of org), mostly customer success and BD [Source 3]
- Internal memo: 30% reduction in Berlin headcount (41 → 28-30 by end of Q2 2026) [Source 4]
- Berlin office to be reframed as "support hub" (not sales/expansion) [Source 4]
- Sunset "Nimbus Lite" tier (~310 customers, $5K-$20K ARR each); 90-day migration notice [Source 4]
- Goal: cash-flow breakeven by Q4 2026 [Source 4]

## Quality Signals
- Engineering quality: high (CTO Daniel Wong is "the real deal") [Source 3]
- Customer love: real (mid-market brands truly depend on platform) [Source 3]
- Compensation competitive for senior engineers ($215K base + $50K equity) [Source 3]

## Source Quality Notes
- Press release: company narrative only; omits negatives [Source 1]
- TechCrunch: journalistic, cites sources; most balanced on financials [Source 2]
- Blog post: one ex-employee's view; credible on internal culture/comp [Source 3]
- Memo: leaked internal doc; accurate on plans but reflects management framing [Source 4]
- SEC Form D: factual filing; confirms $84M raised, 7 investors, date [Source 5]
