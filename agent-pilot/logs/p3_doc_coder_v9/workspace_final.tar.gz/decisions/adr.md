# ADR: Executive Brief Framing for Nimbus Logistics

## Decision: Recommendation Stance

**Choice:** Pass the follow-on investment, with clear triggers for re-engagement.

**Rationale:**
- The company is in a restructuring phase, not a growth phase.
- The Series B was repriced down from $720M to $560M, signaling investor skepticism.
- Internal memo shows major cost-cutting (30% Berlin cuts, sunset Lite tier) and a $50M credit facility described as "insurance."
- Unit economics are negative: burn ~$4M/month vs revenue ~$3.5M/month.
- High customer concentration (top 5 = ~38% of ARR) with recent churn of two top-5 customers.

**Alternative considered (and rejected):** "More diligence needed"
- This would be appropriate if the signals were ambiguous, but they are not.
- The internal memo and TechCrunch reporting provide clear evidence of distress.
- The press release narrative is contradicted by multiple sources.

---

## Decision: Brief Structure

**Choice:** Lead with recommendation, then evidence, then triggers for re-engagement.

**Rationale:**
- Partner has 5 minutes; must know stance immediately.
- Evidence must include source contradictions (e.g., $42M vs $36-37M ARR).
- Triggers for re-engagement make the recommendation actionable.

**Structure:**
1. Recommendation (bold, clear)
2. Key facts (with source attribution)
3. Tensions (what the company isn't telling you)
4. Triggers for re-engagement
5. Conclusion (re-state stance)

---

## Decision: Tone and Language

**Choice:** Calibrated, not alarmist.

**Rationale:**
- The blog post and memo are real but not perfectly authoritative.
- Use "according to" rather than "it is true that."
- Acknowledge positives (engineering quality, customer love) but don't let them override negatives.

**Examples:**
- "According to the leaked memo, the company is pursuing a path to cash-flow breakeven by Q4 2026."
- "TechCrunch reports that adjusted ARR after December churn is $36-37M, not the $42M cited in the press release."
- "The internal memo confirms layoffs in February 2025, though the company did not announce them publicly."

---

## Decision: What to Omit

**Omitted:**
- Company mission statement ("cloud-native logistics platform for mid-market e-commerce brands")
- Founders' backgrounds beyond names (not material to investment decision)
- Specific customer names (Maevia, Truant Coffee, Brick & Cobble) — not material
- Office locations beyond Berlin cuts (Oakland, Austin not discussed in restructuring)

**Rationale:**
- Brief must be at most 700 words; every word must earn its place.
- Focus on financials, customer health, and operational reality.

---

## Decision: Citations

**Choice:** Inline citations in brackets: [Source 1], [Source 2], etc.

**Rationale:**
- Allows reader to trace claims to sources.
- Avoids footnotes that break flow.
- Standard in deal memos.

**Example:**
- "ARR is reported as $42M [Source 1], but TechCrunch reports that adjusted for December churn the run-rate is $36-37M [Source 2]."
