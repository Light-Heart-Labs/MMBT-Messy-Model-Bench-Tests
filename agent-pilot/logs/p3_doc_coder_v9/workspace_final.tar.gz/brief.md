# Executive Brief: Nimbus Logistics, Inc. — Follow-on Investment Recommendation

**Recommendation: PASS.** Do not participate in the follow-on round. The company is in a restructuring phase, not a growth phase. The Series B was repriced down from a $720M target to $560M, signaling investor skepticism. Internal memos confirm major cost-cutting and negative unit economics. Wait for Q4 2026 breakeven proof before re-engaging.

---

## Key Facts

Nimbus raised $84M at a $560M post-money valuation, led by Lightning Capital [Source 1, Source 5]. TechCrunch reports the round was originally intended to close at $720M but was repriced down after the Sundry non-renewal in early December [Source 2]. The company reports $42M ARR [Source 1], but adjusted for the December churn of two top-5 customers (Sundry at $4.2M ARR and Klatch), the run-rate is $36-37M [Source 2].

Top-5 customers represent ~38% of ARR, a high concentration risk [Source 3]. The company lost two of those five in late 2025, and the internal memo confirms layoffs in February 2025 (22 people, ~11% of org) [Source 3]. Burn rate is ~$4M/month all-in against ~$3.5M/month in revenue, meaning negative unit economics [Source 3].

To extend runway, the company is cutting 30% of Berlin headcount (41 → 28-30 by end of Q2 2026), sunsetting the "Nimbus Lite" tier (310 customers), and securing a $50M credit facility described as "insurance, not operating capital" [Source 4]. The goal is cash-flow breakeven by Q4 2026 [Source 4].

---

## Tensions (What the Company Isn’t Telling You)

The press release emphasizes expansion into international markets and AI-driven optimization [Source 1]. The internal memo tells a different story: international expansion is deferred to 2027, and Berlin is being scaled back to a "support hub" [Source 4]. The company is in damage-control mode, not growth mode.

The CEO claims net retention >110% and three new $1M+ ARR contracts in Q1 [Source 2]. But the TechCrunch report and internal memo suggest these are reactive measures, not evidence of sustainable growth. The $50M credit facility, not the Series B, is the primary source of runway.

---

## Triggers for Re-engagement

Re-engage if:
- Q2 2026 shows verified run-rate ARR >$38M (not just reported, but audited)
- Q3 2026 shows positive operating cash flow
- No further major customer churn in Q2 (top-5 concentration remains a risk)

---

## Conclusion

Nimbus has strong engineering and real customer love in the mid-market segment [Source 3]. But the financials tell a different story: negative unit economics, high customer concentration, and recent churn. The repriced round and internal restructuring confirm the company is not on a path to scalable growth.

**Recommendation: PASS.** Wait for Q4 2026 breakeven proof before re-engaging.

---

*Word count: 598*
