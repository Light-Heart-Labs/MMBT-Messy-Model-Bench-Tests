# ADR-001: Fix `discount_amount` implementation, not the tests

## Context

The `discount_amount()` function was returning values 100x too large. The v0.3.0 changelog says the function signature changed from fraction (0.0-1.0) to percent (0-100), but the implementation still multiplied `price * percent_off` without dividing by 100.

## Decision

Fix the implementation: change `price * percent_off` to `price * percent_off / 100`.

## Rationale

- The docstring examples clearly state `discount_amount(100.0, 20.0) -> 20.0`
- The v0.3.0 changelog documents the API change to percent-based input
- The tests match the documented behavior
- The implementation was the bug — someone updated the API contract but forgot to update the math

## Consequences

- `apply_discount()` is also fixed since it depends on `discount_amount()`
- No API surface change — the function signature and expected behavior remain the same

---

# ADR-002: Fix `test_line_count_matches_qty_sum` test, not the code

## Context

`Cart.line_count()` returns the number of lines (2), but the test expected the total quantity across lines (5).

## Decision

Update the test to expect 2 (number of lines), matching the current implementation.

## Rationale

- The v0.3.0 changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior."
- The code change was intentional and documented
- The test was simply not updated when the behavior changed

## Consequences

- The test name `test_line_count_matches_qty_sum` is slightly misleading now, but the docstring was updated to clarify it checks "number of lines in the cart"
- No code changes needed
