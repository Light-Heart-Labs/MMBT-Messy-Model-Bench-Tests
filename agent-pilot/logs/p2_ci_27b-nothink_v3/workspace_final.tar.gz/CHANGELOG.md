# Changelog

## v0.3.2 (2025-01-XX)

**Bug fixes:**

- **`discount_amount()` was not dividing by 100.** The function signature changed in v0.3.0 to accept percent (0-100) instead of fraction (0.0-1.0), but the implementation still multiplied `price * percent_off` directly, producing results 100x too large. Fixed to `price * percent_off / 100`.
- **Unused `import json` in `cart.py`.** Removed the unused import that triggered ruff F401.
- **`test_line_count_matches_qty_sum` test was not updated for v0.3.0 behavior change.** The v0.3.0 changelog stated that `Cart.line_count()` now returns the number of lines (not total quantity). The test still expected the old behavior (total qty = 5). Updated the test to expect 2 (the number of lines).
- **Ruff lint fixes:** Applied auto-fixes for import sorting (I001), deprecated `typing.List` → `list` (UP006/UP035), and `Optional[X]` → `X | None` (UP045).

**Verification:**
- `ruff check src/ tests/` → 0 errors
- `pytest -q` → 7 passed, 0 failed

## v0.3.1 (previous — CI red)

CI was failing on this version. See `ci_failure.log` for the full output.

## v0.3.0

- **BREAKING**: `discount_amount()` and `apply_discount()` now take percent (0-100)
  instead of fraction (0.0-1.0). Update callers from `apply_discount(p, 0.2)` to
  `apply_discount(p, 20.0)`.
- `Cart.line_count()` now returns the number of lines, not the total quantity
  across lines. Tests should be updated where they relied on the old behavior.

## v0.2.0

- Added `Cart.set_discount()` for cart-wide discounts.
- `Cart.line_count()` returns total quantity across lines.

## v0.1.0

- Initial release.
