# Diagnosis

## CI Failure Analysis

The CI log showed 1 ruff error and 3 test failures. Here's the breakdown:

### 1. Ruff F401: Unused `import json` in `cart.py`

**What was wrong:** Line 4 of `cart.py` had `import json` with a comment `# PLANTED BUG #3: unused import`. This import was never used anywhere in the file.

**Fix:** Removed the import line.

**Why code fix (not test):** This is a lint issue in the source code, not a test issue.

---

### 2. `test_discount_amount` — `assert 2000.0 == 20.0`

**What was wrong:** `discount_amount(100.0, 20.0)` returned `2000.0` instead of `20.0`. The function computes `price * percent_off` but since v0.3.0 the parameter is a percentage (0-100), not a fraction (0.0-1.0). The implementation was never updated to divide by 100.

**Fix:** Changed `return round(price * percent_off, 2)` to `return round(price * percent_off / 100, 2)`.

**Why code fix (not test):** The docstring examples and the v0.3.0 changelog both confirm the function should take percent (0-100). The tests were correct; the implementation was wrong. The docstring says `discount_amount(100.0, 20.0) -> 20.0` which is clearly the intended behavior.

---

### 3. `test_apply_discount` — `assert -1900.0 == 80.0`

**What was wrong:** This was a cascading failure from the `discount_amount` bug. Since `discount_amount` returned 2000 instead of 20, `apply_discount` computed `100 - 2000 = -1900`.

**Fix:** Fixed automatically by fixing `discount_amount`.

---

### 4. `test_line_count_matches_qty_sum` — `assert 2 == 5`

**What was wrong:** The test expected `line_count()` to return the total quantity across all lines (5), but the code returns the number of lines (2).

**Fix:** Updated the test to expect 2 (number of lines).

**Why test fix (not code):** The v0.3.0 changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior." The code was intentionally changed; the test was not updated to match.

---

### 5. Additional ruff issues (I001, UP006, UP035, UP045)

**What was wrong:** Import sorting issues and deprecated typing constructs (`typing.List` → `list`, `Optional[X]` → `X | None`).

**Fix:** Applied `ruff --fix` to auto-correct these.

**Why code fix:** These are lint/style issues in the source code.
