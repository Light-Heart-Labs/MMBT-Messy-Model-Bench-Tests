# ADR-001: Content Omission Decisions by Audience

## Decision: What to omit from each rewrite

### CEO Brief
- **Omitted:** Named individuals (Marcus, Priya, Sarah). The CEO needs to know what happened and what's being done, not who did what.
- **Omitted:** Technical details of the fraction-against-MAX mechanism. Replaced with plain-language description: "configuration update... triggered an internal safeguard that blocked all authentication requests."
- **Omitted:** "Sorry Sarah" and other informal apologies. Not appropriate for board-prep material.
- **Included:** The "second outage in 90 days" framing, as this is explicitly required by the brief as a board signal.

### Customer Email
- **Omitted:** Named engineer (Marcus). No customer needs to know who deployed the change.
- **Omitted:** "Second outage in 90 days" framing. This is an internal board signal, not customer-facing information. Including it would undermine confidence.
- **Omitted:** Internal candor about the unaddressed warning from Sarah (who left in September). This is internal process criticism, not customer-relevant.
- **Omitted:** Engineering jargon (rate limiter, MAX, throttling internals). Replaced with plain language: "configuration change... triggered an internal safeguard."
- **Included:** Explicit SLA credit offer and contact path, as required.

### Legal Summary
- **Omitted:** Named-employee blame. Legal needs facts, not attribution.
- **Omitted:** Engineering remediation details (staged rollout, runbook updates). These are operational, not contractual.
- **Omitted:** Speculation about future outages or reliability program overhaul. Legal needs current facts only.
- **Omitted:** Marketing language and informal candor.
- **Used "incident" not "outage"** per the brief's tone guidance.
- **Included:** The 4 downstream-automation cases and the recommendation for case-by-case handling of relationship-driven requests, as these directly affect credit obligations.
