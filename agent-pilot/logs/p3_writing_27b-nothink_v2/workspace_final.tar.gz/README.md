# Incident Rewrite Output

This directory contains three audience-specific rewrites of an internal engineering memo documenting a ~4-hour API outage on Friday (14:11–18:24 UTC). Each rewrite is tailored to its target audience per the specifications in `/input/repo/audience_briefs.json`.

## Files

| File | Audience | Word Count | Limit |
|------|----------|------------|-------|
| `ceo_brief.md` | CEO / board prep | 193 | ≤250 |
| `customer_email.md` | Affected customers | 260 | ≤350 |
| `legal_summary.md` | In-house counsel | 254 | ≤400 |
| `decisions/adr-001-content-omissions.md` | ADR: what was omitted and why | — | — |
| `research/notes.md` | Working notes and fact extraction | — | — |

## How to Read

Each rewrite uses only facts present in the source memo (`/input/repo/draft_memo.md`). No numbers, times, or customer counts were invented. The three documents differ in tone, detail level, and framing to match their audiences: the CEO brief is concise and executive, the customer email is warm and accountable, and the legal summary is precise and dispassionate. See `decisions/adr-001-content-omissions.md` for rationale on what was excluded from each.
