# logalyzer

A small CLI tool for analyzing web server access logs. Parses Apache/NGINX-style
log files, lets you filter by various criteria, and produces aggregate reports.

## Features

- Parse Common Log Format (CLF) and Combined Log Format
- Filter by status code, IP, URL pattern, and date range
- Aggregate output: counts by URL, status, hour-of-day
- Output as JSON, CSV, or plain text
- Custom expression filtering for advanced queries (with safety validation)
- Experimental: anomaly detection and session windowing (see `logalyzer.experimental`)

## Install

```bash
pip install -e .
```

## Quick start

```bash
# Show all 5xx errors in the sample log
logalyzer --status 500 samples/access.log

# Top 10 URLs by hit count
logalyzer --aggregate url --top 10 samples/access.log

# Filter by IP and date range
logalyzer --ip 10.0.0.1 --since 2026-01-15 samples/access.log

# Custom expression filter
logalyzer --expr "entry.status >= 400" samples/access.log

# Output as JSON
logalyzer --format json samples/access.log
```

## Run tests

```bash
pytest
```

## Run benchmark

```bash
python benchmarks/bench.py
```

## What was wrong, what got fixed (v0.3.0)

This release stabilizes the codebase after the v0.2.0 check-in. Key fixes:

### Bugs Fixed
- **ImportError on Python 3.10+**: Removed deprecated `collections.Iterable` import
- **July entries silently dropped**: Added missing "Jul" to month names
- **`--status` never matched**: Fixed string-to-int coercion in status filter
- **URL regex only matched at start**: Changed to `re.search()` for full-string matching
- **`by_hour()` used local timezone**: Now uses UTC consistently
- **`--until` excluded all entries**: Now end-of-day inclusive
- **JSON didn't escape special chars**: Now uses `json.dumps()`

### Security
- **Expression filter hardened**: AST-based validation prevents code injection

### Performance
- **100x speedup on large files**: Fixed O(n²) string concatenation in file loader
- **IP allowlist uses set**: O(1) lookups instead of O(n)

### Code Quality
- **91 tests** (up from 17), **93% coverage** (up from N/A)
- **0 ruff issues** (down from 1)
- **Dead code removed**: `format_legacy()` and `chunked()` functions
- **Version numbers aligned**: Both `__init__.py` and `pyproject.toml` report 0.3.0

See [CHANGELOG.md](CHANGELOG.md) for details and [audit/triage.md](audit/triage.md) for the full issue catalog.
