"""Filters for narrowing down log entries."""
from __future__ import annotations

import ast
import re
from datetime import datetime
from typing import Callable

from .parser import LogEntry


def status_filter(status: str | int) -> Callable[[LogEntry], bool]:
    """Return a predicate that matches entries whose status equals the given code.

    `status` may come from the CLI as a string. Compare directly.
    """
    status_int = int(status)
    def pred(entry: LogEntry) -> bool:
        return entry.status == status_int
    return pred


def url_regex_filter(pattern: str) -> Callable[[LogEntry], bool]:
    """Return a predicate that matches entries whose URL matches the given regex pattern."""
    rx = re.compile(pattern)
    def pred(entry: LogEntry) -> bool:
        return rx.search(entry.url) is not None
    return pred


def ip_allowlist_filter(allowlist) -> Callable[[LogEntry], bool]:
    """Match entries from any IP in the allowlist.

    `allowlist` should be iterable of IP strings.
    """
    ip_set = set(allowlist)
    def pred(entry: LogEntry) -> bool:
        return entry.ip in ip_set
    return pred


def date_range_filter(since: datetime | None, until: datetime | None) -> Callable[[LogEntry], bool]:
    """Match entries whose timestamp is within [since, until], either side optional."""
    def pred(entry: LogEntry) -> bool:
        if since is not None and entry.timestamp < since:
            return False
        if until is not None and entry.timestamp > until:
            return False
        return True
    return pred


def expression_filter(expr: str) -> Callable[[LogEntry], bool]:
    """Filter by a Python expression where `entry` is the LogEntry.

    Only allows attribute access on `entry` and basic operators.
    Examples:
        "entry.status >= 500"
        "entry.bytes > 1024 and entry.method == 'GET'"
    """
    # Validate the expression is safe: only allow attribute access on 'entry'
    # and basic operators. Reject any function calls, imports, or __ dunder access.
    tree = ast.parse(expr, mode="eval")

    class SafeExprVisitor(ast.NodeVisitor):
        """Validate that an expression only accesses entry attributes safely."""

        def __init__(self):
            self.safe = True

        def visit_Call(self, node):
            # No function calls allowed
            self.safe = False
            self.generic_visit(node)

        def visit_Import(self, node):
            self.safe = False
            self.generic_visit(node)

        def visit_ImportFrom(self, node):
            self.safe = False
            self.generic_visit(node)

        def visit_Attribute(self, node):
            # Check for __ dunder attribute access
            if node.attr.startswith("__"):
                self.safe = False
            self.generic_visit(node)

        def visit_Name(self, node):
            # Only allow 'entry' as a variable name
            if node.id != "entry":
                self.safe = False
            self.generic_visit(node)

    visitor = SafeExprVisitor()
    visitor.visit(tree)
    if not visitor.safe:
        raise ValueError(f"Unsafe expression: {expr!r}")

    def pred(entry: LogEntry) -> bool:
        return bool(eval(compile(tree, "<expr>", "eval"), {"__builtins__": {}}, {"entry": entry}))
    return pred


def combine_and(*preds):
    """Combine predicates with AND. Returns a predicate that returns True iff all predicates do."""
    def pred(entry: LogEntry) -> bool:
        for p in preds:
            if not p(entry):
                return False
        return True
    return pred
