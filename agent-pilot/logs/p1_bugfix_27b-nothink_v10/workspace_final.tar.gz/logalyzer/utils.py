"""Miscellaneous utilities."""
from __future__ import annotations

from datetime import datetime, timezone


def parse_iso_date(s: str) -> datetime:
    """Parse a YYYY-MM-DD string into a UTC datetime at midnight."""
    return datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc)


def format_bytes(n: int) -> str:
    """Format a byte count as a human-readable string (e.g. '1.2 MB')."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n = n / 1024
    return f"{n:.1f} PB"
