# ADR-001: Keep experimental.py as part of the public API

## Status
Accepted

## Context
The `experimental.py` module contains two functions (`detect_anomalies` and
`session_window`) that are not wired into the CLI. The original maintainer's
comment said "Keep this file untouched for now — it's part of an in-progress
feature."

These functions are:
- `detect_anomalies(entries)`: Z-score-based anomaly detection on per-minute request counts
- `session_window(entries, window_seconds)`: Groups entries by IP into sessions

Neither function is imported or called anywhere in the codebase. However, they
are well-documented, have clear interfaces, and could be useful for users who
import the package programmatically.

## Decision
Keep `experimental.py` as part of the public API but:
1. Add comprehensive tests to ensure the functions work correctly
2. Keep the "experimental" naming to signal that the API may change
3. Do not wire into the CLI until there's a clear use case

## Consequences
- Users can import and use these functions programmatically
- The functions are tested and won't silently break
- The module is clearly marked as experimental, so API changes are expected
- Future maintainers should know these are intentionally kept but not CLI-exposed

## Alternatives Considered
- **Delete the module**: Would lose potentially useful functionality. The
  functions are well-implemented and tested.
- **Wire into CLI**: Premature without a clear use case. Adding CLI flags
  for experimental features would complicate the interface.
