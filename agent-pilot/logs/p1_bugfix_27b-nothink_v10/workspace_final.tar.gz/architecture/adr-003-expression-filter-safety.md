# ADR-003: Use AST-based validation for expression_filter

## Status
Accepted

## Context
The `expression_filter` function allows users to provide arbitrary Python
expressions for filtering log entries. The original implementation used
`eval()` with `{"__builtins__": {}}` as the only sandboxing mechanism.

While this prevents most attacks, it's still a security concern because:
1. Users could potentially access dangerous attributes via `entry.__class__`
2. The expression is not validated before execution
3. `eval()` is generally considered a security anti-pattern

## Decision
Add an AST-based validator that:
- Rejects function calls (no `os.system()`, etc.)
- Rejects import statements
- Rejects `__` dunder attribute access (prevents `__class__.__bases__`, etc.)
- Only allows `entry` as a variable name (no access to globals)

## Rationale
- The AST approach is more robust than just removing `__builtins__`
- It provides clear error messages when unsafe expressions are detected
- It maintains the useful feature of custom expression filtering
- The validation is fast (AST parsing is negligible overhead)

## Alternatives Considered
- **Remove expression_filter entirely**: Would lose a useful feature for
  advanced users. The AST validation provides sufficient security.
- **Use a restricted eval library**: No standard library solution exists.
  Third-party libraries would add dependencies.
- **Use a custom expression parser**: Overkill for this use case. The AST
  approach is simpler and leverages the standard library.
