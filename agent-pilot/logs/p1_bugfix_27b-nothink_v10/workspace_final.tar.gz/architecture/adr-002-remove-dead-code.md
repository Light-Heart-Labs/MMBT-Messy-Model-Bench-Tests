# ADR-002: Remove dead code from utils.py

## Status
Accepted

## Context
The `utils.py` module contained four functions:
1. `parse_iso_date(s)` — Used by CLI for `--since`/`--until` parsing
2. `format_bytes(n)` — Not used anywhere, but useful utility
3. `format_legacy(entry)` — Legacy v0.1 formatter, no callers
4. `chunked(seq, size)` — Generic utility, no callers

## Decision
Remove `format_legacy()` and `chunked()` from `utils.py`. Keep `format_bytes()`
as a potentially useful utility for future features.

## Rationale
- `format_legacy()` was explicitly documented as "retained for compatibility
  with the v0.1 CLI output" and "No longer used internally". With no external
  callers identified, keeping dead code increases maintenance burden.
- `chunked()` was a generic utility that was never used. If needed in the
  future, it can be added back or replaced with `itertools.batched` (Python 3.12+).
- `format_bytes()` is kept because it's a useful utility that could be used
  by future features (e.g., a `--summary` flag showing total bytes).

## Consequences
- Reduced code surface area (20 lines removed)
- No breaking changes for users (neither function was used)
- `format_bytes()` remains available for future use
