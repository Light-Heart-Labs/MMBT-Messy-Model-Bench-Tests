"""Tests for expression filter safety."""
import pytest

from logalyzer.filters import expression_filter
from logalyzer.parser import LogEntry
from datetime import datetime, timezone


def make_entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


def test_expression_filter_basic_comparison():
    pred = expression_filter("entry.status >= 200")
    assert pred(make_entry(status=200)) is True
    assert pred(make_entry(status=199)) is False


def test_expression_filter_attribute_access():
    pred = expression_filter("entry.method == 'GET'")
    assert pred(make_entry(method="GET")) is True
    assert pred(make_entry(method="POST")) is False


def test_expression_filter_complex_expression():
    pred = expression_filter("entry.status >= 500 and entry.bytes > 100")
    assert pred(make_entry(status=500, bytes=200)) is True
    assert pred(make_entry(status=500, bytes=50)) is False
    assert pred(make_entry(status=200, bytes=200)) is False


def test_expression_filter_rejects_function_calls():
    with pytest.raises(ValueError, match="Unsafe expression"):
        expression_filter("len(entry.url)")


def test_expression_filter_rejects_import():
    with pytest.raises(ValueError, match="Unsafe expression"):
        expression_filter("__import__('os')")


def test_expression_filter_rejects_dunder_attributes():
    with pytest.raises(ValueError, match="Unsafe expression"):
        expression_filter("entry.__class__")


def test_expression_filter_rejects_unknown_variables():
    with pytest.raises(ValueError, match="Unsafe expression"):
        expression_filter("os.system('echo')")


def test_expression_filter_allows_numeric_literals():
    pred = expression_filter("entry.status > 400")
    assert pred(make_entry(status=500)) is True
    assert pred(make_entry(status=200)) is False


def test_expression_filter_allows_string_literals():
    pred = expression_filter("entry.url == '/admin'")
    assert pred(make_entry(url="/admin")) is True
    assert pred(make_entry(url="/index")) is False
