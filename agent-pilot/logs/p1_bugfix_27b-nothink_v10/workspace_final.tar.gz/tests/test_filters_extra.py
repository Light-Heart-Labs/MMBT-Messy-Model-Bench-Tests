"""Tests for filter combination and edge cases."""
from datetime import datetime, timezone

from logalyzer.filters import combine_and, expression_filter, ip_allowlist_filter
from logalyzer.parser import LogEntry


def make_entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


def test_combine_and_with_no_predicates():
    """combine_and with no predicates should match everything."""
    pred = combine_and()
    assert pred(make_entry()) is True


def test_combine_and_with_single_predicate():
    pred = combine_and(lambda e: e.status == 200)
    assert pred(make_entry(status=200)) is True
    assert pred(make_entry(status=404)) is False


def test_combine_and_with_multiple_predicates():
    pred = combine_and(
        lambda e: e.status == 200,
        lambda e: e.method == "GET",
    )
    assert pred(make_entry(status=200, method="GET")) is True
    assert pred(make_entry(status=200, method="POST")) is False
    assert pred(make_entry(status=404, method="GET")) is False


def test_ip_allowlist_with_set():
    """ip_allowlist_filter should work with set input too."""
    pred = ip_allowlist_filter({"10.0.0.1", "10.0.0.2"})
    assert pred(make_entry(ip="10.0.0.1")) is True
    assert pred(make_entry(ip="10.0.0.3")) is False


def test_expression_filter_with_boolean_operators():
    pred = expression_filter("entry.status >= 200 and entry.status < 400")
    assert pred(make_entry(status=200)) is True
    assert pred(make_entry(status=399)) is True
    assert pred(make_entry(status=400)) is False
    assert pred(make_entry(status=199)) is False


def test_expression_filter_with_or():
    pred = expression_filter("entry.status == 200 or entry.status == 304")
    assert pred(make_entry(status=200)) is True
    assert pred(make_entry(status=304)) is True
    assert pred(make_entry(status=404)) is False
