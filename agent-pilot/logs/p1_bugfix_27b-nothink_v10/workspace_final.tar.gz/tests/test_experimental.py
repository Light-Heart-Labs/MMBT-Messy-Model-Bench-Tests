"""Tests for experimental module features."""
from datetime import datetime, timezone

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def make_entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


def test_detect_anomalies_empty():
    assert detect_anomalies([]) == []


def test_detect_anomalies_no_anomalies():
    """Uniform distribution should have no anomalies."""
    entries = [make_entry(timestamp=datetime(2026, 1, 1, 12, i, 0, tzinfo=timezone.utc))
               for i in range(10)]
    result = detect_anomalies(entries)
    assert result == []


def test_detect_anomalies_detects_spike():
    """A minute with many more requests than others should be flagged."""
    entries = []
    # Normal: 1 request per minute for 10 minutes
    for i in range(10):
        entries.append(make_entry(timestamp=datetime(2026, 1, 1, 12, i, 0, tzinfo=timezone.utc)))
    # Spike: 100 requests in one minute
    for j in range(100):
        entries.append(make_entry(timestamp=datetime(2026, 1, 1, 12, 30, j % 60, tzinfo=timezone.utc)))
    result = detect_anomalies(entries)
    assert len(result) >= 1


def test_session_window_groups_by_ip():
    entries = [
        make_entry(ip="10.0.0.1", timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)),
        make_entry(ip="10.0.0.1", timestamp=datetime(2026, 1, 1, 12, 5, 0, tzinfo=timezone.utc)),
        make_entry(ip="10.0.0.2", timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)),
    ]
    sessions = session_window(entries, window_seconds=3600)
    # Should have 2 sessions (one per IP)
    assert len(sessions) == 2


def test_session_window_splits_on_gap():
    """A gap exceeding the window should split into separate sessions."""
    entries = [
        make_entry(ip="10.0.0.1", timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)),
        make_entry(ip="10.0.0.1", timestamp=datetime(2026, 1, 1, 12, 5, 0, tzinfo=timezone.utc)),
        # 31 minute gap (> 1800s window)
        make_entry(ip="10.0.1", timestamp=datetime(2026, 1, 1, 12, 36, 0, tzinfo=timezone.utc)),
    ]
    # Fix: use different IP to avoid confusion, or use same IP with clear gap
    entries = [
        make_entry(ip="10.0.0.1", timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)),
        make_entry(ip="10.0.0.1", timestamp=datetime(2026, 1, 1, 12, 5, 0, tzinfo=timezone.utc)),
        # 31 minute gap (> 1800s window)
        make_entry(ip="10.0.0.1", timestamp=datetime(2026, 1, 1, 12, 36, 0, tzinfo=timezone.utc)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    # Should have 2 sessions for the same IP
    assert len(sessions) == 2
    assert sessions[0][0] == "10.0.0.1"
    assert len(sessions[0][1]) == 2  # First session has 2 entries
    assert len(sessions[1][1]) == 1  # Second session has 1 entry


def test_session_window_empty():
    assert session_window([]) == []
