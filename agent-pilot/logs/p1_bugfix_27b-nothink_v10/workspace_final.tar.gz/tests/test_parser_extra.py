"""Additional tests for parser edge cases."""
from datetime import timezone

from logalyzer.parser import parse_line, parse_lines, parse_timestamp


def test_parse_lines_yields_entries():
    lines = [
        '10.0.0.1 - - [15/Jan/2026:08:30:00 +0000] "GET / HTTP/1.1" 200 100\n',
        '10.0.0.2 - - [15/Jan/2026:08:30:01 +0000] "GET / HTTP/1.1" 200 200\n',
    ]
    entries = list(parse_lines(lines))
    assert len(entries) == 2
    assert entries[0].ip == "10.0.0.1"
    assert entries[1].ip == "10.0.0.2"


def test_parse_lines_skips_bad_lines():
    lines = [
        '10.0.0.1 - - [15/Jan/2026:08:30:00 +0000] "GET / HTTP/1.1" 200 100\n',
        'garbage line\n',
        '\n',
        '10.0.0.2 - - [15/Jan/2026:08:30:01 +0000] "GET / HTTP/1.1" 200 200\n',
    ]
    entries = list(parse_lines(lines))
    assert len(entries) == 2


def test_parse_timestamp_positive_offset():
    """Test timestamp with positive timezone offset."""
    ts = parse_timestamp("10/Oct/2000:13:55:36 +0500")
    # 13:55:36 +0500 = 08:55:36 UTC
    assert ts.hour == 8
    assert ts.minute == 55


def test_parse_timestamp_zero_offset():
    ts = parse_timestamp("10/Oct/2000:13:55:36 +0000")
    assert ts.hour == 13
    assert ts.tzinfo is timezone.utc


def test_parse_line_with_large_bytes():
    line = '10.0.0.1 - - [15/Jan/2026:08:30:00 +0000] "GET / HTTP/1.1" 200 999999999'
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 999999999


def test_parse_line_with_various_methods():
    for method in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
        line = f'10.0.0.1 - - [15/Jan/2026:08:30:00 +0000] "{method} / HTTP/1.1" 200 100'
        e = parse_line(line)
        assert e is not None, f"Failed to parse {method}"
        assert e.method == method


def test_parse_line_all_months():
    """Verify all 12 months parse correctly."""
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    for i, month in enumerate(months, 1):
        line = f'10.0.0.1 - - [15/{month}/2026:08:30:00 +0000] "GET / HTTP/1.1" 200 100'
        e = parse_line(line)
        assert e is not None, f"Failed to parse {month}"
        assert e.timestamp.month == i, f"Month {month} should be {i}, got {e.timestamp.month}"
