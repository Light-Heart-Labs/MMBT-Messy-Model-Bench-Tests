"""Tests for I/O module."""
import os
import tempfile

from logalyzer.io import load, load_iter
from logalyzer.parser import LogEntry


SAMPLE_LINES = [
    '10.0.0.1 - - [15/Jan/2026:08:30:00 +0000] "GET /index.html HTTP/1.1" 200 1234\n',
    '10.0.0.2 - alice [15/Jan/2026:08:30:15 +0000] "POST /api/login HTTP/1.1" 200 56\n',
    '10.0.0.3 - - [15/Jan/2026:08:30:42 +0000] "GET /static/app.js HTTP/1.1" 200 89234\n',
]


def test_load_returns_list_of_entries():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.writelines(SAMPLE_LINES)
        path = f.name

    try:
        entries = load(path)
        assert isinstance(entries, list)
        assert len(entries) == 3
        assert all(isinstance(e, LogEntry) for e in entries)
    finally:
        os.unlink(path)


def test_load_iter_yields_entries():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.writelines(SAMPLE_LINES)
        path = f.name

    try:
        entries = list(load_iter(path))
        assert len(entries) == 3
        assert entries[0].ip == "10.0.0.1"
        assert entries[1].user == "alice"
    finally:
        os.unlink(path)


def test_load_handles_empty_file():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write("")
        path = f.name

    try:
        entries = load(path)
        assert entries == []
    finally:
        os.unlink(path)


def test_load_skips_malformed_lines():
    lines = [
        '10.0.0.1 - - [15/Jan/2026:08:30:00 +0000] "GET / HTTP/1.1" 200 100\n',
        'this is garbage\n',
        '10.0.0.2 - - [15/Jan/2026:08:30:01 +0000] "GET / HTTP/1.1" 200 200\n',
    ]
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.writelines(lines)
        path = f.name

    try:
        entries = load(path)
        assert len(entries) == 2
    finally:
        os.unlink(path)


def test_load_iter_is_a_generator():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.writelines(SAMPLE_LINES)
        path = f.name

    try:
        gen = load_iter(path)
        # Should be a generator (has __next__ and __iter__)
        assert hasattr(gen, "__next__")
        assert hasattr(gen, "__iter__")
        # Consume one entry
        first = next(gen)
        assert first.ip == "10.0.0.1"
    finally:
        os.unlink(path)


def test_load_handles_file_without_trailing_newline():
    # File with no trailing newline should still parse the last line
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        f.write('10.0.0.1 - - [15/Jan/2026:08:30:00 +0000] "GET / HTTP/1.1" 200 100')
        path = f.name

    try:
        entries = load(path)
        assert len(entries) == 1
        assert entries[0].ip == "10.0.0.1"
    finally:
        os.unlink(path)
