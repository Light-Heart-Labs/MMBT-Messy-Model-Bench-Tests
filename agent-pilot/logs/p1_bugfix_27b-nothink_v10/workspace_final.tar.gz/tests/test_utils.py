"""Tests for utility functions."""
from datetime import datetime, timezone

from logalyzer.utils import parse_iso_date, format_bytes


def test_parse_iso_date():
    result = parse_iso_date("2026-01-15")
    assert result == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_various_dates():
    result = parse_iso_date("2024-12-31")
    assert result == datetime(2024, 12, 31, 0, 0, 0, tzinfo=timezone.utc)


def test_format_bytes_small():
    assert format_bytes(0) == "0.0 B"
    assert format_bytes(500) == "500.0 B"


def test_format_bytes_kb():
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_mb():
    assert format_bytes(1024 * 1024) == "1.0 MB"


def test_format_bytes_gb():
    assert format_bytes(1024 ** 3) == "1.0 GB"
