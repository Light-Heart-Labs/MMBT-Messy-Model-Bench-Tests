"""Tests for CLI entry point."""
import subprocess
import sys


def test_cli_version_flag():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "--version"],
        capture_output=True, text=True
    )
    assert result.returncode == 0
    assert "logalyzer" in result.stdout


def test_cli_parses_sample_log():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode == 0
    assert "10.0.0.1" in result.stdout


def test_cli_status_filter():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "--status", "404", "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode == 0
    assert "404" in result.stdout
    # Should only show the 404 entry
    lines = [line for line in result.stdout.strip().split('\n') if line.strip()]
    assert len(lines) == 1


def test_cli_aggregate_status():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "--aggregate", "status", "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode == 0
    assert "200" in result.stdout


def test_cli_json_format():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "--format", "json", "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode == 0
    import json
    data = json.loads(result.stdout)
    assert isinstance(data, list)
    assert len(data) == 12  # 12 lines in sample log


def test_cli_csv_format():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "--format", "csv", "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode == 0
    lines = result.stdout.strip().split('\n')
    assert lines[0] == "ip,user,timestamp,method,url,protocol,status,bytes"


def test_cli_ip_filter():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "--ip", "10.0.0.1", "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode == 0
    # Should only show entries from 10.0.0.1
    lines = [line for line in result.stdout.strip().split('\n') if line.strip()]
    for line in lines:
        assert "10.0.0.1" in line


def test_cli_url_filter():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "--url", "admin", "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode == 0
    assert "admin" in result.stdout.lower()


def test_cli_expr_filter():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "--expr", "entry.status >= 400", "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode == 0
    # Should show 401, 404, 500, 500 entries
    lines = [line for line in result.stdout.strip().split('\n') if line.strip()]
    assert len(lines) == 4


def test_cli_expr_filter_rejects_unsafe():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "--expr", "__import__('os').system('echo hacked')", "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode != 0
    assert "hacked" not in result.stdout


def test_cli_since_until_filter():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli",
         "--since", "2026-01-15", "--until", "2026-01-15",
         "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode == 0
    # All entries are on 2026-01-15
    lines = [line for line in result.stdout.strip().split('\n') if line.strip()]
    assert len(lines) == 12


def test_cli_aggregate_url_top():
    result = subprocess.run(
        [sys.executable, "-m", "logalyzer.cli", "--aggregate", "url", "--top", "3", "samples/access.log"],
        capture_output=True, text=True,
        cwd="/workspace"
    )
    assert result.returncode == 0
    lines = [line for line in result.stdout.strip().split('\n') if line.strip()]
    assert len(lines) <= 3
