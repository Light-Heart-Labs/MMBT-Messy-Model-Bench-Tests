"""Tests for output formatters."""
from datetime import datetime, timezone

from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.parser import LogEntry


def make_entry(**kw):
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


def test_to_json_produces_valid_json():
    import json
    entries = [make_entry()]
    result = to_json(entries)
    parsed = json.loads(result)
    assert isinstance(parsed, list)
    assert len(parsed) == 1
    assert parsed[0]["ip"] == "10.0.0.1"
    assert parsed[0]["status"] == 200


def test_to_json_escapes_special_characters():
    """JSON output must properly escape quotes and backslashes in strings."""
    import json
    entries = [make_entry(url='/path?q="hello"', user='user"with"quotes')]
    result = to_json(entries)
    parsed = json.loads(result)
    assert parsed[0]["url"] == '/path?q="hello"'
    assert parsed[0]["user"] == 'user"with"quotes'


def test_to_csv_has_header_row():
    entries = [make_entry()]
    result = to_csv(entries)
    # csv module uses \r\n line endings; split on \n and strip \r
    lines = result.strip().replace('\r', '').split('\n')
    assert lines[0] == "ip,user,timestamp,method,url,protocol,status,bytes"
    assert len(lines) == 2  # header + 1 data row


def test_to_csv_escapes_commas_in_values():
    entries = [make_entry(url='/path?a=1,b=2')]
    result = to_csv(entries)
    lines = result.strip().replace('\r', '').split('\n')
    # The URL with commas should be quoted
    assert '"/path?a=1,b=2"' in lines[1]


def test_to_text_formats_one_line_per_entry():
    entries = [make_entry(), make_entry(ip="10.0.0.2")]
    result = to_text(entries)
    lines = result.split('\n')
    assert len(lines) == 2
    assert "10.0.0.1" in lines[0]
    assert "10.0.0.2" in lines[1]


def test_to_text_empty_list():
    result = to_text([])
    assert result == ""


def test_render_aggregate_text_format():
    from collections import Counter
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="text")
    assert "200\t10" in result
    assert "404\t3" in result


def test_render_aggregate_json_format():
    from collections import Counter
    import json
    agg = Counter({"200": 10, "404": 3})
    result = render_aggregate(agg, fmt="json")
    parsed = json.loads(result)
    assert parsed["200"] == 10
    assert parsed["404"] == 3


def test_render_aggregate_list_format():
    agg = [("/a", 5), ("/b", 3)]
    result = render_aggregate(agg, fmt="text")
    assert "/a\t5" in result
    assert "/b\t3" in result


def test_render_aggregate_unknown_format_raises():
    import pytest
    agg = {"a": 1}
    with pytest.raises(ValueError, match="unknown format"):
        render_aggregate(agg, fmt="xml")
