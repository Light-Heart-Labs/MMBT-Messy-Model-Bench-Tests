"""Tests for CLI module (direct import, for coverage)."""
from logalyzer.cli import main, build_parser


def test_build_parser_returns_argument_parser():
    p = build_parser()
    assert p is not None
    assert p.prog == "logalyzer"


def test_main_with_sample_log():
    result = main(["samples/access.log"])
    assert result == 0


def test_main_with_status_filter():
    result = main(["--status", "404", "samples/access.log"])
    assert result == 0


def test_main_with_aggregate():
    result = main(["--aggregate", "status", "samples/access.log"])
    assert result == 0


def test_main_with_json_format():
    result = main(["--format", "json", "samples/access.log"])
    assert result == 0


def test_main_with_csv_format():
    result = main(["--format", "csv", "samples/access.log"])
    assert result == 0


def test_main_with_ip_filter():
    result = main(["--ip", "10.0.0.1", "samples/access.log"])
    assert result == 0


def test_main_with_url_filter():
    result = main(["--url", "admin", "samples/access.log"])
    assert result == 0


def test_main_with_since_until():
    result = main(["--since", "2026-01-15", "--until", "2026-01-15", "samples/access.log"])
    assert result == 0


def test_main_with_expr():
    result = main(["--expr", "entry.status >= 400", "samples/access.log"])
    assert result == 0


def test_main_with_aggregate_url_top():
    result = main(["--aggregate", "url", "--top", "3", "samples/access.log"])
    assert result == 0


def test_main_with_aggregate_hour():
    result = main(["--aggregate", "hour", "samples/access.log"])
    assert result == 0
