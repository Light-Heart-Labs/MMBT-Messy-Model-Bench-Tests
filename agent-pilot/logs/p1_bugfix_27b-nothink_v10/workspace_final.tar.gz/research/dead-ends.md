# Dead Ends

## 1. Attempted to make `--until` inclusive by modifying `parse_iso_date`

**Attempt**: Modified `parse_iso_date` to add `timedelta(days=1)` so that
`--until 2026-01-15` would mean "end of day 2026-01-15".

**Why it didn't work**: `parse_iso_date` is also used by `--since`, where
we want midnight (start of day). Modifying the function would break `--since`.

**Resolution**: Instead, handle the end-of-day logic in the CLI's `main()`
function, where we have context about whether it's `--since` or `--until`.
The `--until` value gets `+ timedelta(days=1) - timedelta(microseconds=1)`
applied in the CLI before passing to `date_range_filter`.

## 2. Attempted to use `collections.abc.Iterable` as a replacement

**Attempt**: Replaced `from collections import Iterable` with
`from collections.abc import Iterable` to fix the Python 3.10+ compatibility
issue.

**Why it didn't work**: While this would fix the import error, the import
was completely unused — no code in `filters.py` or any other module actually
used `Iterable`. The comment claimed "used by some downstream callers" but
no callers existed.

**Resolution**: Simply removed the import. Adding an unused import just to
fix an import error is not a real fix — the real fix is to remove dead code.

## 3. Attempted to make `by_hour` use `datetime.astimezone()` for timezone conversion

**Attempt**: Used `e.timestamp.astimezone(timezone.utc).hour` to ensure UTC
hour extraction.

**Why it didn't work**: The timestamps are already in UTC (parse_timestamp
converts to UTC). Using `astimezone()` was redundant. The real bug was that
the original code used `time.localtime()` which converts to the system's
local timezone.

**Resolution**: Simply use `e.timestamp.hour` directly since timestamps are
already UTC. This is both correct and more efficient.
