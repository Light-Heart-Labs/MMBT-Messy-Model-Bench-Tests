# Decision 004: Convert IP allowlist to set for O(1) lookups

**Date**: 2026-01-15
**Context**: `ip_allowlist_filter` used `entry.ip in allowlist` where
`allowlist` was a list. This is O(n) per lookup.

**Decision**: Convert the allowlist to a set inside the filter function.

**Alternatives considered**:
- Require callers to pass a set: Would be a breaking API change.
- Document that callers should pass a set: Relies on caller discipline.

**Why this choice**: Converting inside the function is transparent to
callers and provides the performance benefit automatically. The conversion
cost is O(n) once, vs O(n) per lookup for a list.
