# Decision 002: Fix status_filter to coerce string to int

**Date**: 2026-01-15
**Context**: The CLI passes `--status` as a string (e.g., `'404'`), but
`LogEntry.status` is an `int`. The original `status_filter` compared
`entry.status == status` directly, which would never match when status
is a string.

**Decision**: Coerce the status argument to `int` inside `status_filter`.

**Alternatives considered**:
- Change the CLI to pass `type=int`: Would break if the user passes a
  non-numeric string (argparse would error before our code runs).
- Compare with `str(entry.status) == status`: Would work but is less
  robust (what if status is already an int from programmatic use?).

**Why this choice**: Coercing to int inside the filter handles both CLI
(string) and programmatic (int) callers correctly.
