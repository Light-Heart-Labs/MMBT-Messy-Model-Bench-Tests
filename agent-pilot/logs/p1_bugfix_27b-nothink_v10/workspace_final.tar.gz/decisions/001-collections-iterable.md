# Decision 001: Replace `from collections import Iterable` with removal

**Date**: 2026-01-15
**Context**: `filters.py` imported `Iterable` from `collections`, which was
removed in Python 3.10 (moved to `collections.abc`).

**Decision**: Remove the import entirely. It was unused — the comment claimed
"used by some downstream callers" but no callers existed.

**Alternatives considered**:
- Replace with `from collections.abc import Iterable`: Would fix the import
  error but add an unused import.
- Keep as-is: Would break on Python 3.10+.

**Why this choice**: The import was dead code. Removing it is cleaner than
replacing it with another unused import.
