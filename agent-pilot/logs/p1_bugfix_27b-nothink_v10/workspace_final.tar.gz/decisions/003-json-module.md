# Decision 003: Replace hand-rolled JSON with json module

**Date**: 2026-01-15
**Context**: `output.py` built JSON strings manually using f-strings. This
doesn't escape special characters (quotes, backslashes) in string values.

**Decision**: Replace with `json.dumps()` from the standard library.

**Alternatives considered**:
- Add manual escaping: Would be error-prone and reinvent the wheel.
- Use a third-party library: Unnecessary; the standard library handles this.

**Why this choice**: `json.dumps()` is the standard, correct, and
maintainable way to produce JSON in Python.
