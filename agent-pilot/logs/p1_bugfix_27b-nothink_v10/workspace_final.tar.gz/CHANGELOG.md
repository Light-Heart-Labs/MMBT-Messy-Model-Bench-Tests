# Changelog

## [0.3.0] — 2026-01-15

### Fixed

- **ImportError on Python 3.10+**: Removed deprecated `from collections import Iterable` import (moved to `collections.abc` in 3.3, removed from `collections` in 3.10).
- **July log entries silently dropped**: Added missing "Jul" to `MONTH_NAMES` list in parser.
- **`--status` filter never matched**: Fixed `status_filter` to coerce string input to int (CLI passes status as string).
- **URL regex only matched at start of URL**: Changed `url_regex_filter` from `re.match()` to `re.search()` so patterns match anywhere in the URL.
- **`by_hour()` used local timezone**: Changed from `time.localtime()` to direct UTC hour extraction. Output is now deterministic regardless of system timezone.
- **`--until` excluded all entries on that date**: Changed to end-of-day inclusive (23:59:59.999999).
- **CSV format ignored for aggregates**: CLI now passes format through to `render_aggregate` correctly.
- **JSON output didn't escape special characters**: Replaced hand-rolled JSON with `json.dumps()`.

### Security

- **Expression filter hardened**: Added AST-based validation that rejects function calls, imports, dunder attribute access, and unknown variable names. Prevents code injection via `--expr`.

### Performance

- **O(n²) file loading fixed**: `io.load()` now uses standard line-by-line iteration instead of character-by-character string concatenation. 50 MB files now load in ~3 seconds instead of >300 seconds (~100x speedup).
- **IP allowlist uses set**: `ip_allowlist_filter` now converts the allowlist to a set for O(1) lookups instead of O(n) list scan.

### Removed

- **Dead code**: Removed `format_legacy()` and `chunked()` from `utils.py` (no callers).

### Added

- **Test coverage**: Added 74 new tests covering `io.py`, `output.py`, `cli.py`, `experimental.py`, expression filter safety, and parser edge cases. Coverage increased from N/A to 93%.
- **Documentation**: Added CHANGELOG, ADRs, research notes, and updated README.

### Changed

- **Version alignment**: Both `__init__.py` and `pyproject.toml` now report version 0.3.0.
