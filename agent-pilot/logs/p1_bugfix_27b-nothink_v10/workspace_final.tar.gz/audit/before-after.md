# Before-After Metrics

## Measurement Methodology

All measurements were taken on the same machine (Linux VM, Python 3.11.15).

### Test Pass Rate
- **Command**: `python -m pytest --tb=short`
- **Before**: 0/0 tests (import error prevents collection)
- **After**: 91/91 tests pass

### Coverage
- **Command**: `python -m pytest --cov=logalyzer --cov-report=term-missing`
- **Before**: N/A (tests couldn't run)
- **After**: 93% (303 statements, 20 missed — mostly `cli.py` subprocess entry point and `utils.py` dead code)

### Ruff Issues
- **Command**: `ruff check logalyzer/ tests/`
- **Before**: 1 issue (unused `collections.Iterable` import)
- **After**: 0 issues

### Benchmark (50 MB log file)
- **Command**: `python benchmarks/bench.py --size 50`
- **Before**: >300 seconds (timed out)
- **After**: ~3.1 seconds

### Benchmark (5 MB log file)
- **Command**: `python benchmarks/bench.py --size 5`
- **Before**: ~3.1 seconds
- **After**: ~0.02 seconds

## Summary Table

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| Tests passed | 0 | 91 | +91 |
| Tests total | 0 (collection error) | 91 | +91 |
| Coverage | N/A | 93% | New |
| Ruff issues | 1 | 0 | -1 |
| Benchmark 50 MB | >300s | ~3.1s | ~100x faster |
| Benchmark 5 MB | ~3.1s | ~0.02s | ~150x faster |

## Notes

- The benchmark improvement is primarily due to fixing the O(n²) string
  concatenation in `io.load()`. The original code read the entire file into
  memory as a single string, then iterated character by character with
  `accumulated = accumulated + ch`, which is O(n²) per line.
- The test count increase is due to both fixing the import error (which
  prevented any tests from running) and adding 74 new tests for previously
  untested modules.
- Ruff issues went from 1 to 0 after fixing the unused import and cleaning
  up test file linting issues (ambiguous variable names, unused imports).
