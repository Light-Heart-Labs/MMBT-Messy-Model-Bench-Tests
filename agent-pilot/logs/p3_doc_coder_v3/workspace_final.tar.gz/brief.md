# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Recommendation

## Recommendation: **PASS**

Do not participate in a follow-on round at the current $560M post-money valuation. The company is not cash-flow positive, its reported ARR is overstated, and the valuation repricing from $720M to $560M suggests overvaluation. A restructuring plan aims for cash-flow breakeven by Q4 2026, but execution risk is high.

---

## Financial Reality: ARR and Burn

The company reports $42M in ARR as of Q4 2025, up from $11M a year prior [Source 1]. However, TechCrunch reports that this figure includes two major customers that churned in late 2025 — Sundry Brands ($4.2M ARR, non-renewed November 2025) and Klatch (exited December 2025) [Source 2]. Adjusted for this churn, the current run-rate ARR is closer to $36-37M [Source 2].

The burn rate is a bigger concern. According to a former senior engineer, the company was spending ~$4M/month all-in vs. ~$3.5M/month in revenue (mid-2025), indicating negative cash flow [Source 3]. The internal memo confirms the need for restructuring to reach cash-flow breakeven by Q4 2026 [Source 4]. The $84M Series B gives 24+ months of runway at current burn, but the new $50M credit facility extends this to 36+ months after the planned cuts [Source 4].

---

## Customer Risk: Churn and Concentration

The company’s growth narrative is undermined by significant churn. Two of its top-five customers exited in late 2025, and the top 5 customers represented ~38% of ARR — a high concentration risk [Source 3]. The CEO claims net retention >110% and three new $1M+ ARR contracts signed in Q1 2026 [Source 2], but these claims are not corroborated by the internal memo or former employee.

The internal memo reveals a plan to sunset the "Nimbus Lite" tier (~310 customers, $5K-$20K ARR each) with a 90-day migration notice [Source 4]. This suggests the company is prioritizing high-margin customers over broad market coverage — a strategic shift not mentioned in the press release.

---

## Operational Reality: Layoffs and Restructuring

The company quietly laid off 22 people (~11% of the org) in February 2025, mostly in customer success and BD — a fact omitted from the press release [Source 3]. The internal memo confirms further cuts: a 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2 2026), a pause on new hires in EMEA, and a reframing of Berlin as a "support hub" rather than a sales/expansion office [Source 4].

International expansion, highlighted in the press release as a key use of proceeds, is deferred to 2027 at earliest [Source 4]. This is a significant pivot from the growth narrative.

---

## Valuation Context: Repricing and Runway

The Series B was originally intended to close at a $720M valuation in late 2025 but was repriced down to $560M after the Sundry non-renewal became known to the lead investor in early December [Source 2]. This $160M repricing reflects the market’s recognition of overvaluation.

The internal memo describes the new $50M credit facility as "insurance, not operating capital" [Source 4], suggesting the company is preparing for a worst-case scenario. The goal is to reach cash-flow breakeven by Q4 2026, which would allow the company to begin Series C conversations "from a position of strength rather than necessity" [Source 4].

---

## Conditions That Would Change the Recommendation

1. **Lower valuation**: If investor can participate at a pre-Series C valuation of $400-450M (reflecting the $36-37M ARR and negative cash flow).
2. **Strong protective provisions**: If investor can secure board seat, anti-dilution provisions, or liquidation preference.
3. **Execution proof**: If investor sees evidence that the restructuring plan is on track (e.g., Q2 2026 cash-flow breakeven milestone achieved).

---

## Conclusion

Nimbus Logistics has a strong technical foundation and a credible founding team, but the financials and operational reality do not support the current valuation. The company is not cash-flow positive, its ARR figure is overstated, and the valuation repricing suggests overvaluation. A restructuring plan aims for cash-flow breakeven by Q4 2026, but execution risk is high. **Recommendation: PASS.**
