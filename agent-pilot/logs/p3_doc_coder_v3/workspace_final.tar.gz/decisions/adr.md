# ADR: Framing the Nimbus Logistics Investment Decision

## Decision: Recommendation Stance

**Recommendation: PASS on a follow-on investment at the current $560M valuation.**

### Rationale

The company is not yet cash-flow positive and relies on new capital to extend runway. The internal memo reveals a restructuring plan to reach cash-flow breakeven by Q4 2026, but this requires significant cuts (layoffs, product sunsetting, international pause). The repricing from $720M to $560M suggests the market (via Lightning Capital) recognized overvaluation.

### Key Metrics Driving the Decision

- **Adjusted ARR**: $36-37M (not $42M as claimed in press release) [Source 2]
- **Burn rate**: ~$4M/month all-in vs ~$3.5M/month revenue → negative cash flow [Source 3]
- **Customer concentration**: top 5 = ~38% of ARR → high risk [Source 3]
- **Valuation repricing**: $720M target → $560M actual → market correction [Source 2]
- **Runway**: 24+ months at current burn → 36+ months after restructuring [Source 4]

### Conditions That Would Change the Recommendation

1. **Lower valuation**: If investor can participate at a pre-Series C valuation of $400-450M (reflecting the $36-37M ARR and negative cash flow), then consider.
2. **Strong protective provisions**: If investor can secure board seat, anti-dilution provisions, or liquidation preference, then consider.
3. **Execution proof**: If investor sees evidence that the restructuring plan is on track (e.g., Q2 2026 cash-flow breakeven milestone achieved), then consider.

### Alternative Framings Considered and Rejected

1. **"More diligence needed"**: Rejected because the sources provide enough information to form a clear stance. The tensions are well-documented and the recommendation is calibrated to the risk/reward profile.

2. **"Invest at current valuation"**: Rejected because the company is not cash-flow positive, the ARR figure is overstated, and the valuation repricing suggests overvaluation.

3. **"Hold for Series C"**: Rejected because the internal memo shows the company is trying to reach breakeven to begin Series C conversations "from a position of strength rather than necessity" — this suggests Series C may not happen if the restructuring fails.

## Decision: Brief Structure

### Headline Stance
Lead with "PASS" in the first paragraph — investor has 5 minutes, so the stance must be clear immediately.

### Structure
1. **Stance + Summary**: One paragraph stating the recommendation and why.
2. **Financial Reality**: Adjusted ARR, burn rate, runway — not the press release narrative.
3. **Customer Risk**: Churn, concentration, net retention claims vs. reality.
4. **Operational Reality**: Layoffs, restructuring, international pause.
5. **Valuation Context**: Repricing from $720M to $560M.
6. **Recommendation + Conditions**: Clear stance with conditions that would change it.

### Tone
- Calibrated: Use "according to" for blog post/memo, not "ground truth"
- Honest about source quality: "press release claims X, but TechCrunch reports Y"
- Avoid hedging: "PASS" not "more diligence needed"

## Decision: Citation Style

- Use `[Source 1]`, `[Source 2]`, etc. inline for specific facts
- Do not fabricate citations — only cite what is in the sources
- When citing a claim, attribute it to the source (e.g., "CEO claims X [Source 2]")