# Nimbus Logistics, Inc. — Deal Evaluation Package

## Overview

This package contains an executive brief and supporting analysis for an investor evaluating whether to make a follow-on investment in Nimbus Logistics, Inc., a Series-B logistics-tech startup.

## Files

- **`brief.md`** — The 1-page executive brief (primary deliverable)
- **`key-facts.md`** — A list of every material fact incorporated into the brief, with source attribution
- **`research/notes.md`** — Working notes from reading the five source documents
- **`decisions/adr.md`** — ADR-style records for framing choices (recommendation stance, brief structure, citation style)
- **`README.md`** — This file

## Sources

The brief is based on five source documents:

1. **Press Release** (company-issued) — Optimistic narrative
2. **TechCrunch News Article** — Journalistic, includes contradictory facts
3. **Former Employee Blog Post** — First-hand perspective, likely biased
4. **Leaked Internal Memo** — Most candid internal view
5. **SEC Form D Filing** — Factual filing, confirms terms

## Recommendation

**PASS on a follow-on investment at the current $560M valuation.**

The company is not cash-flow positive, the ARR figure is overstated ($42M claimed vs $36-37M adjusted), and the valuation repricing from $720M to $560M suggests overvaluation. The internal memo reveals a restructuring plan to reach cash-flow breakeven by Q4 2026, but this requires significant cuts (layoffs, product sunsetting, international pause).

## Conditions That Would Change the Recommendation

1. **Lower valuation**: If investor can participate at a pre-Series C valuation of $400-450M
2. **Strong protective provisions**: If investor can secure board seat, anti-dilution provisions, or liquidation preference
3. **Execution proof**: If investor sees evidence that the restructuring plan is on track (e.g., Q2 2026 cash-flow breakeven milestone achieved)

## How to Read This Output

1. Start with `brief.md` for the executive summary
2. Review `key-facts.md` for the factual basis of the brief
3. Read `research/notes.md` for the working analysis
4. Check `decisions/adr.md` for the framing rationale