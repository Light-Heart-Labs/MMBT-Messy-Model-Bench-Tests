# Working Notes — Nimbus Logistics, Inc. Deal Evaluation

## Source Summary

### Source 1 — Press Release (Company)
- $84M Series B, led by Lightning Capital, closed Jan 14, 2026
- Post-money valuation: $560M (up from $230M in 2023)
- Total funding to date: $128M
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400 customers, 187 employees (Oakland, Austin, Berlin)
- Founders: Mira Patel (CEO), Daniel Wong (CTO)
- Investors: Lightning Capital, Sequoia, Accel, FedEx Ventures

### Source 2 — TechCrunch
- Lost two top-5 customers in late 2025:
  - Sundry Brands ($4.2M ARR) — non-renewed Nov 2025
  - Klatch (fast-fashion) — exited Dec 2025
- Company confirmed Sundry but not Klatch
- Adjusted ARR after December churn: $36-37M
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026
- Net retention claimed >110%
- Series B originally intended to close at $720M valuation in late 2025, repriced down after Sundry non-renewal

### Source 3 — Former Employee Blog
- 14 months at Nimbus as senior engineer
- Engineering quality: high (CTO Daniel Wong is "real deal")
- Compensation: top quartile (e.g., $215K base + $50K equity for senior engineer)
- Burn rate: ~$4M/month all-in vs ~$3.5M/month revenue (mid-2025)
- Layoffs: 22 people (~11% of org) in Feb 2025, mostly customer success & BD
- Customer concentration: top 5 = ~38% of ARR
- Recommendation: join if senior/comfortable with risk; not for job security in next 18 months

### Source 4 — Leaked Internal Memo (Feb 28, 2026)
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
- Pause new hires in EMEA; Berlin becomes "support hub"
- Sunset "Nimbus Lite" tier (~310 customers, $5K-$20K ARR each)
- 90-day migration notice for Lite customers
- New $50M credit facility from Silicon Valley Bridge
- Goal: cash-flow breakeven by Q4 2026
- Runway: extended from 24+ months to 36+ months
- Series C conversations to begin from "position of strength"

### Source 5 — SEC Form D
- Filed Jan 22, 2026
- $84M offered and sold
- 7 investors
- First sale: Jan 14, 2026
- Security type: Series B Preferred
- No officer/director compensation disclosed
- Use of proceeds: "expansion, working capital, general corporate purposes"

## Key Tensions

1. **Valuation vs. Performance**: Press release says $560M valuation, TechCrunch says Series B was repriced from $720M after customer losses.

2. **ARR Figure**: Press release says $42M; TechCrunch says adjusted for December churn, run-rate is $36-37M.

3. **Growth Narrative vs. Reality**: Press release touts 281% ARR growth ($11M → $42M). TechCrunch and blog post reveal significant churn and customer concentration.

4. **Burn Rate**: Blog post says ~$4M/month all-in vs ~$3.5M/month revenue → negative cash flow. Internal memo confirms need for restructuring to reach breakeven.

5. **International Strategy**: Press release says "accelerate expansion into international markets"; internal memo says pause EMEA hires, reduce Berlin to 28-30, reframe as support hub.

6. **Product Strategy**: Press release doesn't mention tier changes; internal memo says sunset "Nimbus Lite" tier.

7. **Layoffs**: Not mentioned in press release; blog post and memo confirm layoffs (22 in Feb 2025).

8. **Runway**: Press release implies growth story; internal memo says Series B gives 24+ months runway but restructuring extends to 36+ months to reach breakeven.

## Source Quality Assessment

- **Press release**: Company narrative only — optimistic, omits negatives.
- **TechCrunch**: Journalistic, cites anonymous sources, includes contradictory facts.
- **Former employee blog**: First-hand, but one perspective; likely biased toward negative experience.
- **Internal memo**: Most candid internal view, but written by CEO to justify restructuring.
- **SEC Form D**: Factual filing, confirms terms but not strategy.

## Initial Recommendation Hypothesis

Given the $4M/month burn vs $3.5M/month revenue, the company is not cash-flow positive and relies on new capital to stay alive. The internal memo shows a restructuring plan to reach breakeven by Q4 2026, but this requires significant cuts (layoffs, product sunsetting, international pause). The repricing from $720M to $560M suggests the market (via Lightning Capital) recognized overvaluation.

**Recommendation: PASS on follow-on investment unless**:
- Investor can participate at a lower valuation (e.g., pre-Series C down round or flat)
- Or investor gets strong protective provisions given the high risk of execution on the restructuring plan.
