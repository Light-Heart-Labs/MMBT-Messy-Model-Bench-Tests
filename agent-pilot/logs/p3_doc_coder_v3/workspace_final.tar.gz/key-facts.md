# Key Facts — Nimbus Logistics, Inc.

## Valuation & Funding
- Series B closed Jan 14, 2026, for $84M, led by Lightning Capital [Source 1, Source 5]
- Post-money valuation: $560M [Source 1]
- Original target valuation for Series B: $720M, repriced down after Sundry non-renewal [Source 2]
- Total funding to date: $128M [Source 1]
- New $50M credit facility secured from Silicon Valley Bridge [Source 4]

## Revenue & Growth
- Reported ARR: $42M as of Q4 2025 [Source 1]
- Prior ARR: $11M a year prior (2024) [Source 1]
- Adjusted ARR after December 2025 churn: $36-37M run-rate [Source 2]
- Top 5 customers represented ~38% of ARR [Source 3]

## Customer Churn
- Lost Sundry Brands ($4.2M ARR) — non-renewed November 2025 [Source 2]
- Lost Klatch (fast-fashion) — exited December 2025 [Source 2]
- Company confirmed Sundry non-renewal but called it "strategic mutual decision"; declined to comment on Klatch [Source 2]
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026 [Source 2]
- CEO claims net retention >110% across 1,400 customers [Source 2]

## Operations & Burn
- 1,400 customers [Source 1]
- 187 employees (Oakland, Austin, Berlin) [Source 1]
- Burn rate: ~$4M/month all-in vs ~$3.5M/month revenue (mid-2025) [Source 3]
- Layoffs: 22 people (~11% of org) in February 2025, mostly customer success and BD [Source 3]

## Restructuring Plan (per internal memo)
- Reduce Berlin office from 41 to 28-30 by end of Q2 2026 [Source 4]
- Pause new hires in EMEA; Berlin becomes "support hub" [Source 4]
- Sunset "Nimbus Lite" tier (~310 customers, $5K-$20K ARR each) [Source 4]
- Goal: cash-flow breakeven by Q4 2026 [Source 4]
- Runway extended from 24+ months to 36+ months [Source 4]

## Product & Strategy
- Platform: warehouse management, carrier orchestration, demand forecasting [Source 1]
- Founders: Mira Patel (CEO), Daniel Wong (CTO) [Source 1]
- Customers: Maevia, Truant Coffee, Brick & Cobble [Source 1]
- Strategic investor: FedEx Ventures [Source 1]
- International expansion deferred to 2027 at earliest [Source 4]

## Compensation & Culture
- Senior engineer compensation: $215K base + $50K equity annually (top quartile) [Source 3]
- Engineering quality: high (CTO Daniel Wong is "real deal") [Source 3]
- High burn culture; new round meant to push company to "default-alive" [Source 3]

## Source Quality Notes
- Press release: company narrative only — optimistic, omits negatives
- TechCrunch: journalistic, cites anonymous sources, includes contradictory facts
- Former employee blog: first-hand, but one perspective; likely biased toward negative experience
- Internal memo: most candid internal view, but written by CEO to justify restructuring
- SEC Form D: factual filing, confirms terms but not strategy
