# Working Notes — Synthesis Process

## Reading Pass: Key Facts Extracted

### Team
- Sara (PM), Marcus (TL), Jen (UX), Roman (data), Priya (security, joined week 5)
- Brendan (CEO) — sporadic attendance; key decision-maker

### Workstreams Identified

1. **Query Layer (Backend)** — Owner: Marcus
   - Week 1: "ready-ish", needs work for SDK filter expressions; est. 4-6 weeks
   - Week 2: Revised to 8 weeks (parser + filter combinations)
   - Week 3: Blocked on code review (Lin on PTO until 3/24)
   - Week 4: Sub reviewer Aanya assigned; on track for mid-May
   - Week 5: No update
   - Week 6: 60% done, tracking to mid-May

2. **Dashboard Design / UX** — Owner: Jen
   - Week 1: Design in progress; open questions on custom branding & mobile
   - Week 2: Custom branding confirmed wanted; ~3 weeks extra design
   - Week 3: Custom branding deferred to V2; Jen pivots to mobile
   - Week 4: Mobile scope: native 12+ weeks vs responsive 4 weeks; responsive chosen for V1
   - Week 5: Mobile-responsive on track for mid-May
   - Week 6: Mobile-responsive on track; custom branding still parked

3. **Data Pipeline / Panel Density** — Owner: Roman
   - Week 1: Pipeline fine for dashboard; latency concern at 100+ panels
   - Week 2: Confirmed: ~40 panels/page before lag unacceptable; arch fix needed
   - Week 3: 40-panel limit accepted as V1 known limitation; arch fix as V1.1 fast-follow
   - Week 4: Arch fix started in parallel; est. 6 weeks
   - Week 5: Arch fix on track
   - Week 6: Arch fix 30% done; on track for V1.1 in August

4. **SDK Access Control / Security** — Owner: Priya (security) + Marcus
   - Week 4: Discovered gap — no access-control layer for embedded SDK
   - Week 5: Priya says 4-week minimum; needs IAM design + API + audit logging
   - Week 6: IAM design started; ready for API discussion next week

5. **Custom Branding** — Owner: Jen
   - Week 2: Confirmed wanted; ~3 weeks design
   - Week 3: Deferred to V2 by Brendan decision
   - Week 6: Still parked

### Decisions Made

1. Week 1 (2026-03-04): Brendan sets target "end of June" (informal)
2. Week 3 (2026-03-18): Custom branding cut from V1 — Brendan
3. Week 3 (2026-03-18): 40-panel limit accepted as V1 known limitation — Brendan
4. Week 4 (2026-03-25): Mobile = web-responsive in V1, native in V2 — Sara + Jen
5. Week 6 (2026-04-08): SDK ships in private beta (option B) with 3-5 customers — Brendan

### Risks Identified

1. SDK access-control gap — could blow timeline (HIGH)
2. Legal delay on private-beta contracts (MEDIUM)
3. Maevia customer expectation mismatch — promised GA SDK at conference (MEDIUM)
4. Panel density limit — 40 panels/page (LOW, accepted)
5. Query-layer timeline risk — was 4-6 weeks, now 8 (MEDIUM, but on track)

### Milestones

- Mid-May: Query layer completion (Marcus)
- Mid-May: Mobile-responsive design completion (Jen)
- End of July: V1 GA target (Sara, per week 3 plan)
- August: V1.1 with architectural fix (Roman)
- August: SDK V1.5 if option A chosen (not chosen)

### Open Questions / Asks for CEO

- Legal hasn't responded to private-beta contract draft
- Maevia CSM call pending — they were promised GA SDK
- Final V1 date confirmation (end-of-July still the plan?)
