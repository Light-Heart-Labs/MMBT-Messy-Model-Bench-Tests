# ADR-001: SDK V1 ships as private beta, not GA

**Date:** 2026-04-08 (week 6)
**Decider:** Brendan (CEO)
**Status:** Accepted

## Context

The SDK access-control layer was discovered in week 4 as a gap: no mechanism exists for controlling what embedded customer Y sees when customer X embeds a dashboard. Priya (security) assessed this as a 4-week minimum project requiring IAM design, customer-facing API, and audit logging (week 5).

Three options were presented to Brendan (week 5):
- (a) Ship V1 without SDK; SDK becomes V1.5 in August
- (b) Ship V1 with SDK in private beta (3-5 customers) with extra contracts
- (c) Push V1 to August with everything

## Decision

Brendan chose option B: private beta with 3-5 customers. Rationale: "We have access-control commitments to make right but we cannot delay V1 entirely."

## Consequences

- Legal must draft private-beta contracts with access-control commitments
- One customer (Maevia) was promised GA SDK at the conference and will push back
- IAM design work proceeds in parallel (Priya + Marcus)
