# ADR-002: Custom branding deferred to V2

**Date:** 2026-03-18 (week 3)
**Decider:** Brendan (CEO)
**Status:** Accepted

## Context

Jen (UX) confirmed in week 2 that custom branding for SDK customers was desired, with mockups ready. However, it required ~3 additional weeks of design work not originally budgeted. With the query-layer estimate expanding from 4-6 to 8 weeks, the end-of-June target was no longer realistic.

## Decision

Brendan directed: "Cut custom-branding for V1." Jen pivoted her capacity to mobile UX instead.

## Consequences

- Custom branding is parked for V2
- Jen's capacity redirected to mobile-responsive design (4 weeks vs 12+ for native)
- Timeline saved ~3 weeks of design work
