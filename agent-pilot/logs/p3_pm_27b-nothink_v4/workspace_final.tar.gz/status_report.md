# Project Aurora — Status Report

**Prepared for:** Brendan (CEO)
**As of:** 2026-04-08 (week 6)

---

## Headline

Aurora V1 (dashboard refresh + embedded SDK) is tracking toward an **end-of-July GA** with the SDK shipping in **private beta** (3–5 customers) due to an unresolved access-control gap. Query-layer and mobile-responsive work are on track for mid-May; the panel-density architectural fix is 30% done and targeting V1.1 in August.

---

## Workstreams

| Workstream | Owner | Status | Blocking V1? |
|---|---|---|---|
| Query layer (SDK filter expressions) | Marcus | 60% done; tracking to mid-May (week 6) | Yes |
| Mobile-responsive UX | Jen | On track for mid-May (week 6) | Yes |
| SDK access control / IAM | Priya + Marcus | IAM design started; API discussion next week (week 6) | Yes (mitigated via private beta) |
| Panel-density architectural fix | Roman | 30% done; targeting V1.1 in August (week 6) | No (40-panel limit accepted for V1) |
| Custom branding | Jen | Parked for V2 (week 3) | No |

---

## Risks

| Severity | Risk | Description |
|---|---|---|
| **High** | SDK access-control gap | No access-control layer exists for embedded dashboards. Mitigated by shipping SDK in private beta with contractual commitments (week 5–6). |
| **Medium** | Legal delay on private-beta contracts | Legal has not yet responded to the contract draft; blocks finalizing private-beta customer list (week 6). |
| **Medium** | Maevia expectation mismatch | Maevia was promised GA SDK at the conference; will push back on private-beta status. CSM call pending (week 6). |
| **Low** | Panel-density limit | V1 ships with a 40-panels-per-page limit; documented as a known limitation. Arch fix targeted for V1.1 (week 3). |

---

## Decisions Made

| Date | Decision | Decider |
|---|---|---|
| 2026-03-18 (week 3) | Custom branding cut from V1; deferred to V2 | Brendan |
| 2026-03-18 (week 3) | 40-panel limit accepted as V1 known limitation | Brendan |
| 2026-03-25 (week 4) | Mobile = web-responsive in V1; native deferred to V2 | Sara + Jen |
| 2026-04-08 (week 6) | SDK ships in private beta (option B) with 3–5 customers | Brendan |

---

## Milestones

| Target | Milestone | Owner |
|---|---|---|
| Mid-May 2026 | Query-layer completion | Marcus |
| Mid-May 2026 | Mobile-responsive design completion | Jen |
| End of July 2026 | V1 GA (dashboard refresh + SDK private beta) | Sara |
| August 2026 | V1.1 — panel-density architectural fix | Roman |

---

## Open Questions / Asks

1. **Legal engagement:** Legal has not responded to the private-beta contract draft. Can you escalate?
2. **Maevia:** A CSM call is scheduled to manage their expectations on private-beta vs. GA. Do you want to be looped in?
3. **V1 date confirmation:** End-of-July remains the target. Does this still align with board commitments?
