# Working Notes — Nimbus Logistics Source Analysis

## Source-by-Source Summary

### Source 1: Press Release (2026-01-14)
- $84M Series B led by Lightning Capital
- Post-money valuation: $560M (up from $230M Series A in 2023)
- Total funding: $128M across all rounds
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400+ e-commerce brands on platform
- 187 employees across Oakland, Austin, Berlin
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (strategic)
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO)
- Platform: warehouse management + carrier orchestration + demand forecasting
- Named customers: Maevia, Truant Coffee, Brick & Cobble

### Source 2: TechCrunch (2026-01-15)
- Lost two top-five customers in late 2025:
  - Sundry Brands: $4.2M ARR, largest contract, non-renewal in November
  - Klatch: fast-fashion brand, exited December, migrated to competitor
- ARR adjusted for churn: $36-37M (vs. $42M in press release)
- $42M figure includes both contracts in their final quarter
- CEO claims three new $1M+ ARR contracts signed in Q1
- Net retention claimed above 110%
- Round was meant to close at $720M but repriced down to $560M after Sundry news
- Nimbus confirmed Sundry non-renewal as "strategic mutual decision"

### Source 3: Former Employee Blog (2026-02-22)
- Author: "Daniel R", former senior engineer, 14 months tenure
- Positive: good architecture, real customer love, competitive comp ($215K base + $50K equity)
- Negative:
  - Burn rate: ~$4M/month vs. ~$3.5M/month revenue (mid-2025)
  - Layoffs: 22 people (~11% of org) cut in Feb 2025, mostly customer success and BD, not publicly announced
  - Customer concentration: top 5 customers = ~38% of ARR
  - Sundry loss was not a shock internally
- Recommendation: good for senior engineers, not for those needing job security

### Source 4: Leaked Internal Memo (2026-03-05)
- From CEO Mira Patel, dated Feb 28
- Restructuring plan for cash-flow breakeven by Q4 2026
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
- International expansion deferred to 2027
- Berlin reframed as "support hub"
- Nimbus Lite tier sunset: ~310 customers ($5K-$20K ARR each), 90-day notice
- $50M credit facility from Silicon Valley Bridge secured
- Runway: 24+ months at current burn, extended to 36+ months with restructuring
- Breakeven by Q4 2026 is trigger for Series C conversations

### Source 5: SEC Form D (2026-01-22)
- Confirms $84M offering, all sold
- 7 investors total
- Securities: Series B Preferred Equity
- No officer/director compensation disclosed
- Use of proceeds: "expansion, working capital, general corporate purposes"
- Three additional investors beyond the four named in press release

## Key Tensions Identified

1. **ARR discrepancy**: $42M (press release) vs. $36-37M adjusted (TechCrunch sources)
2. **Valuation repricing**: $720M target → $560M actual (TechCrunch)
3. **Customer concentration risk**: Top 5 = 38% of ARR (blog), loss of largest customer (TechCrunch)
4. **Burn rate**: $4M/month vs. $3.5M/month revenue (blog) — negative cash flow
5. **Hidden layoffs**: 22 people cut in Feb 2025, not announced (blog)
6. **International retreat**: Berlin headcount cut 30%, expansion deferred (memo)
7. **Product tier elimination**: Nimbus Lite sunset affecting ~310 customers (memo)
8. **Credit facility**: $50M from Silicon Valley Bridge (memo) — not mentioned in press release

## Source Quality Assessment

- **Press Release**: Company narrative, selective framing, confirmed by SEC filing on deal terms
- **TechCrunch**: Journalistic, cites "two sources familiar with finances," company confirmed some claims
- **Blog Post**: Single ex-employee perspective, but specific numbers (burn rate, layoff count) that are internally plausible
- **Leaked Memo**: Internal document, attributed to CEO, specific operational details, company declined to confirm
- **SEC Form D**: Regulatory filing, confirms deal structure, limited detail on investor specifics
