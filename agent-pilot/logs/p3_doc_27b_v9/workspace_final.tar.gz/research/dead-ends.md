# Dead Ends — Ideas Considered and Abandoned

## Ideas Not Included in the Brief

### 1. FedEx Ventures as Strategic Moat
**Considered:** Whether FedEx's strategic investment signals a distribution partnership or integration opportunity that could be a major upside driver.
**Abandoned because:** The sources don't provide any detail about what the FedEx relationship entails beyond "strategic investment." Speculating on the nature of the partnership would be inventing facts. The brief mentions FedEx as a credible backer but doesn't overstate the strategic value.

### 2. Engineering Quality as Investment Thesis
**Considered:** Whether the strong engineering architecture (praised in the blog post) could be a standalone investment thesis — that the platform is defensible and could win even if current growth is bumpy.
**Abandoned because:** While the engineering is good, the brief's purpose is to evaluate a follow-on investment decision, not to assess the product in isolation. Good code doesn't offset customer concentration and negative unit economics. The brief acknowledges the engineering quality in the "What's Working" section but doesn't let it drive the recommendation.

### 3. Competitor Analysis
**Considered:** Whether Klatch's migration to a "competing platform" (Source 2) could be traced to a specific competitor and whether that competitor landscape matters.
**Abandoned because:** The sources don't name the competitor. Any speculation about who Klatch went to would be fabricated. The competitive landscape is not material enough to the recommendation to warrant a section.

### 4. Compensation and Talent Retention
**Considered:** Whether the competitive compensation ($215K base + $50K equity for senior engineers) is relevant to the investment thesis.
**Abandoned because:** While interesting for a hiring decision, compensation levels don't directly inform the investment recommendation. The brief focuses on financial and operational metrics that affect valuation and risk.

### 5. The Three Unnamed Investors
**Considered:** Whether the three additional unnamed investors in the Form D filing (beyond the four named in the press release) could signal something about the round's quality.
**Abandoned because:** The Form D doesn't name them, and there's no information about who they are or what their involvement means. Including speculation about them would be fabricating facts.

### 6. "Strategic Mutual Decision" Framing
**Considered:** Whether the company's characterization of the Sundry non-renewal as a "strategic mutual decision" (Source 2) could indicate a planned transition rather than a failure.
**Abandoned because:** While possible, the former employee's account that the loss was "not a shock" and the concentration risk was "widely understood internally" suggests this was a known problem rather than a strategic choice. The brief treats it as churn rather than a planned transition.

### 7. Berlin Office as International Expansion Signal
**Considered:** Whether the existence of a Berlin office and the company's stated goal of "international expansion" (Source 1) could be a growth vector worth highlighting.
**Abandoned because:** The leaked memo explicitly defers international expansion to 2027 and cuts Berlin headcount by 30%. The brief notes this as a retreat rather than a growth vector.
