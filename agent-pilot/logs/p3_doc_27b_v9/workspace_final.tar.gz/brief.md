# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Assessment

**Date:** 2026-03-15
**Recommendation:** **PASS** on follow-on investment now. Stay on observer list for potential Series C in H2 2026.

---

## Bottom Line

Nimbus has a credible product and top-tier backers, but is burning cash, losing its biggest customers, and executing a major restructuring that signals the current growth trajectory is unsustainable. A follow-on now means doubling down before the turnaround has time to prove itself. Wait.

---

## The Deal

Nimbus closed an $84M Series B in January 2026 at $560M post-money, led by Lightning Capital with participation from Sequoia, Accel, and FedEx Ventures [Source 1]. The round was originally targeted at $720M but repriced downward after the company's largest customer, Sundry Brands ($4.2M ARR), declined to renew in November 2025 [Source 2]. Total funding: $128M [Source 1].

---

## Revenue and Churn

The company reports $42M ARR as of Q4 2025, up from $11M a year prior [Source 1]. However, that figure includes two major contracts in their final quarter. Sundry Brands ($4.2M ARR) departed in November and fast-fashion brand Klatch exited in December [Source 2]. Adjusted for churn, the current run-rate is closer to $36–37M [Source 2].

Customer concentration is a structural risk: the top five customers represent approximately 38% of ARR [Source 3]. The loss of Sundry was "not a shock to the team" internally, suggesting the concentration problem was known and unaddressed [Source 3].

---

## Unit Economics

According to a former senior engineer, Nimbus was burning approximately $4M/month in mid-2025 against roughly $3.5M/month in revenue — a negative cash-flow position [Source 3]. A leaked internal memo confirms the company is not profitable and outlines a restructuring plan aimed at cash-flow breakeven by Q4 2026 [Source 4].

The restructuring is significant:
- **30% reduction in international headcount**, cutting Berlin from 41 to 28–30 employees, with international expansion deferred to 2027 [Source 4]
- **Sunset of the "Nimbus Lite" tier**, affecting approximately 310 customers in the $5K–$20K ARR range [Source 4]
- **$50M credit facility** secured from Silicon Valley Bridge, described as "insurance, not operating capital" [Source 4]

The memo states the Series B provides 24+ months of runway at current burn, extended to 36+ months with restructuring [Source 4].

---

## Organizational Instability

The company quietly laid off 22 people (~11% of the org) in February 2025, primarily in customer success and BD, without public announcement [Source 3]. The current restructuring adds further headcount reductions in Berlin [Source 4]. This pattern of unannounced cuts raises questions about internal communication.

---

## Source Quality

The press release [Source 1] presents the company narrative; deal terms are confirmed by the SEC Form D [Source 5]. TechCrunch [Source 2] cites unnamed sources; the company confirmed the Sundry non-renewal but declined to comment on Klatch. The former employee blog [Source 3] is a single perspective but provides specific, internally plausible figures. The leaked memo [Source 4] is attributed to the CEO; the company declined to confirm specifics.

---

## Rationale

**Pass because:**

1. **Restructuring is unproven.** The company is cutting 30% of its international team, sunsetting a product tier, and deferring expansion. Investing now means betting on a turnaround before there's evidence it's working.

2. **Customer concentration is material.** Losing 38% of ARR from five customers, including the largest, is not sustainable. The company needs to demonstrate it can replace that revenue.

3. **Valuation repricing is a warning.** Going from $720M target to $560M actual suggests the lead investor saw the churn data and adjusted. A follow-on investor should not ignore what the lead already priced in.

4. **Adequate runway.** With 36+ months post-restructuring [Source 4], there is no imminent capital crisis and no urgency to invest now.

**Stay on the observer list** because the product is strong, the team is credible, and if the restructuring produces a path to profitability by Q4 2026, the Series C could present a more attractive entry point — from a position of demonstrated strength rather than necessity, as the CEO frames it [Source 4].

---

## What Would Change This Recommendation

- Evidence that the three new $1M+ ARR contracts mentioned by the CEO [Source 2] are signed and closing
- Confirmation that net retention is genuinely above 110% across the remaining base
- Successful Berlin restructuring without further customer attrition
- A Series C process demonstrating improved unit economics and reduced concentration
