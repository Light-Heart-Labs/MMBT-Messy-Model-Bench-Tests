# ADR-001: Recommendation Stance — PASS

**Status:** Accepted
**Date:** 2026-03-15

## Context

The brief requires a clear stance: invest, pass, or more diligence needed. The sources present strong contradictory signals — a credible product and top-tier backers versus negative unit economics, customer concentration, and an unproven restructuring plan.

## Decision

**PASS** on follow-on investment now, with a recommendation to stay on the observer list for potential Series C in H2 2026.

## Rationale

A "more diligence needed" stance would be hedging. The sources provide enough information to form a clear view:

1. The restructuring is unproven — investing now means betting on a turnaround before evidence it's working.
2. Customer concentration (38% of ARR from 5 customers) is a material, known risk.
3. The valuation repricing ($720M → $560M) signals that the lead investor already adjusted for the churn data.
4. With 36+ months of runway, there is no urgency to invest now.

The "observer list" qualifier avoids a hard "never" — if the restructuring works and the Series C shows improved unit economics, the opportunity could be re-evaluated.

## Alternatives Considered

- **Invest:** Would require accepting the company's narrative at face value and ignoring the contradictory signals from the other four sources.
- **More diligence needed:** Would be appropriate if the sources were evenly split or if critical information was missing. But the sources are not evenly split — four of five sources (TechCrunch, blog, memo, and even the SEC filing's lack of detail) point to risks that the press release doesn't address.
