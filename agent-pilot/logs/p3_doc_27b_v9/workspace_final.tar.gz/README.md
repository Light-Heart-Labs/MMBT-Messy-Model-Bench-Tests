# How to Read This Output

## Primary Deliverable

- **`/workspace/brief.md`** — The 1-page executive brief (731 words). This is the main output. Read this first.

## Supporting Materials

- **`/workspace/key-facts.md`** — Every material fact incorporated into the brief, with source attribution. Use this to verify that every claim in the brief traces to a source.

- **`/workspace/research/notes.md`** — Working notes from reading the five source documents. Includes source-by-source summaries, key tensions identified, and source quality assessment.

- **`/workspace/research/dead-ends.md`** — Ideas considered during analysis but not included in the brief, with explanations for why they were abandoned.

- **`/workspace/decisions/adr-001-recommendation.md`** — Architecture Decision Record explaining the choice of "PASS" as the recommendation stance, including alternatives considered.

## Source Mapping

The five source documents from `/input/repo/sources.md` are referenced throughout as:

| Citation | Source | Type |
|----------|--------|------|
| [Source 1] | Press Release (company-issued) | Company narrative |
| [Source 2] | TechCrunch News Article | Journalistic reporting |
| [Source 3] | Former Employee Blog Post | Single perspective |
| [Source 4] | Leaked Internal Memo | Internal document |
| [Source 5] | SEC Form D Filing Summary | Regulatory filing |

## Methodology

1. Read all five sources in full
2. Extracted material facts with source attribution
3. Identified tensions and contradictions across sources
4. Assessed source quality and reliability
5. Formulated recommendation based on synthesis of all sources
6. Drafted brief with clear stance, inline citations, and no fabricated data
7. Created supporting documentation for traceability
