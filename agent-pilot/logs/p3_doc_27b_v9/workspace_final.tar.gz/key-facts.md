# Key Facts Incorporated in the Brief

Each fact below traces to one or more of the five source documents.

## Deal Terms
- $84M Series B closed January 2026, $560M post-money valuation [Source 1, Source 5]
- Led by Lightning Capital; participation from Sequoia, Accel, FedEx Ventures (strategic) [Source 1, Source 5]
- Total funding across all rounds: $128M [Source 1]
- Round originally targeted at $720M but repriced down after Sundry non-renewal [Source 2]
- 7 total investors (3 additional unnamed beyond the four named) [Source 5]
- Securities: Series B Preferred Equity [Source 5]

## Revenue and Customer Metrics
- Company-reported ARR: $42M as of Q4 2025, up from $11M a year prior [Source 1]
- Adjusted ARR (after churn): $36–37M [Source 2]
- Sundry Brands: largest customer, $4.2M ARR, non-renewal in November 2025 [Source 2]
- Klatch: fast-fashion brand, exited December 2025, migrated to competitor [Source 2]
- Top 5 customers represent ~38% of ARR [Source 3]
- 1,400+ e-commerce brands on platform [Source 1]
- CEO claims three new $1M+ ARR contracts signed in Q1 2026 [Source 2]
- CEO claims net retention above 110% [Source 2]

## Financials and Burn
- Burn rate: ~$4M/month in mid-2025 [Source 3]
- Revenue: ~$3.5M/month in mid-2025 [Source 3]
- Company is not profitable; restructuring aimed at cash-flow breakeven by Q4 2026 [Source 4]
- Runway: 24+ months at current burn, extended to 36+ months with restructuring [Source 4]
- $50M credit facility from Silicon Valley Bridge [Source 4]

## Organizational
- 187 employees across Oakland, Austin, Berlin [Source 1]
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO) [Source 1]
- 22 people laid off (~11% of org) in February 2025, mostly customer success and BD, not publicly announced [Source 3]
- Berlin headcount: 41, planned reduction to 28–30 by end Q2 2026 (30% cut) [Source 4]
- International expansion deferred to 2027 [Source 4]

## Product and Platform
- Platform: warehouse management + carrier orchestration + demand forecasting [Source 1]
- Named customers: Maevia, Truant Coffee, Brick & Cobble [Source 1]
- Nimbus Lite tier being sunset; ~310 customers affected ($5K–$20K ARR each), 90-day notice [Source 4]
- Berlin office reframed as "support hub" rather than sales/expansion office [Source 4]

## Source Quality
- Press release [Source 1]: company narrative; confirmed on deal terms by SEC Form D [Source 5]
- TechCrunch [Source 2]: cites unnamed sources; company confirmed Sundry non-renewal, declined to comment on Klatch
- Former employee blog [Source 3]: single perspective; provides specific figures (burn rate, layoff count, concentration)
- Leaked memo [Source 4]: attributed to CEO; company declined to confirm specifics
- SEC Form D [Source 5]: regulatory filing; confirms deal structure; limited additional insight
