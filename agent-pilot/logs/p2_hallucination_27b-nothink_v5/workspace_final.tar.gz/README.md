# How to read this output

## Files

- **`triage.json`** — The main output. Contains verdict (`real` or `fabricated`) and evidence for each of the 15 issues, plus a summary count.
- **`notes.md`** — Detailed reasoning for each verdict, organized by real vs. fabricated.
- **`decisions/`** — ADRs for borderline calls where the issue partially matches reality but the report's specific claim is wrong.

## Methodology

1. Read the full issue report to understand all 15 claims.
2. Enumerated all files in the codebase to verify file existence.
3. Read every source file in full.
4. For each issue:
   - Verified the cited file exists.
   - Verified the cited line numbers match the claimed behavior.
   - Checked if the alleged behavior exists elsewhere in the codebase.
   - Ran Python to confirm runtime behavior where relevant (e.g., the `from collections import Iterable` ImportError).
5. Applied the rule: wrong file citation = fabricated, even if the underlying concern has merit elsewhere.

## Summary

| Verdict | Count | Issues |
|---------|-------|--------|
| Real | 6 | 001, 002, 004, 006, 013, 014 |
| Fabricated | 9 | 003, 005, 007, 008, 009, 010, 011, 012, 015 |
