# Verification Notes for logalyzer Code Review Triage

## Overview

Reviewed 15 issues from a draft code-review report against the actual logalyzer codebase. Found **6 real** issues and **9 fabricated** ones.

## Real Issues (6)

### 001 — `from collections import Iterable` (filters.py:5)
Confirmed. This import was removed in Python 3.10. The code uses `from collections import Iterable` which raises `ImportError` on Python 3.11+. Should be `from collections.abc import Iterable`.

### 002 — `eval()` usage (filters.py:59)
Confirmed. `expression_filter()` uses `eval()` with user-supplied expressions. Even with `{"__builtins__": {}}`, the `entry` variable gives access to LogEntry attributes, and attribute access chains can be exploited (e.g., `entry.__class__.__bases__[0].__subclasses__()`).

### 004 — README claims non-existent tail mode
Confirmed. README.md line 13 says "Real-time tail mode for live log streams" but there is no `--tail` flag in cli.py and no streaming logic anywhere.

### 006 — experimental.py is dead code
Confirmed. The file exists with `detect_anomalies()` and `session_window()` but no other file in the codebase imports from it.

### 013 — O(n²) list/string building in io.py:load()
Confirmed. Lines 24 and 32 use `result = result + [entry]` (creates new list each time) and line 27 uses `accumulated = accumulated + ch` (character-by-character string concatenation). Both are O(n²) anti-patterns.

### 014 — O(n) membership test in ip_allowlist_filter
Confirmed. filters.py:36 uses `entry.ip in allowlist` where allowlist is a list from argparse's `action="append"`. Should convert to `set` for O(1) lookups.

## Fabricated Issues (9)

### 003 — SQL injection in parser.py
Fabricated. parser.py contains only regex-based log parsing. No SQL queries, no database interaction, no string concatenation for queries.

### 005 — `--top` flag broken with AttributeError
Fabricated. `--top` is properly defined with `type=int` at cli.py:33 and used correctly at cli.py:64. No AttributeError occurs.

### 007 — CSRF in web.py
Fabricated. `logalyzer/web.py` does not exist. There is no web interface in the codebase.

### 008 — 8192-char truncation in parser.py
Fabricated. `parse_line()` does not truncate input. It strips whitespace and applies a regex match to the full line.

### 009 — `format_legacy()` in output.py
Fabricated. The function exists in `logalyzer/utils.py:21`, not `output.py`. Per the rules, wrong file citation = fabricated.

### 010 — Race condition in load_iter
Fabricated. Each call to `load_iter()` opens its own file handle. No shared state between concurrent calls.

### 011 — Double-counting 3xx in by_status
Fabricated. `by_status()` simply iterates entries and increments a Counter. No special 3xx handling, no double-counting possible.

### 012 — Stale cache in cache.py
Fabricated. `logalyzer/cache.py` does not exist. No caching module in the codebase.

### 015 — `__init__.py` imports LogEntry
Fabricated. `__init__.py` only contains a docstring and `__version__`. It does not import `LogEntry` from anywhere.
