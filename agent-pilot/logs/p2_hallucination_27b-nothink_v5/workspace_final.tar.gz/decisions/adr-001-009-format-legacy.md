# ADR-001: Issue 009 — format_legacy() location

## Context
Issue 009 claims `format_legacy()` is in `logalyzer/output.py` and is unused dead code.

## Investigation
The function `format_legacy()` does exist, but in `logalyzer/utils.py:21`, not `output.py`. It is indeed unused (no other module imports it).

## Decision
Labeled **fabricated** because the report cites the wrong file. Per the task rules: "A wrong file citation makes the issue fabricated." The function does exist and is dead code, but the claim as written (that it's in `output.py`) is incorrect.

## Note
A diligent reviewer might separately note that `format_legacy()` in `utils.py` is dead code, but that's a different finding from what was reported.

---

# ADR-002: Issue 005 — --top flag behavior

## Context
Issue 005 claims `--top` raises `AttributeError` because `args.top` is referenced before being parsed into the right type.

## Investigation
`--top` is defined at cli.py:33 with `type=int, default=None`. It's used at cli.py:64 as `by_url(entries, top=args.top)`. The `by_url` function accepts `top: int | None`. Everything works correctly.

## Decision
Labeled **fabricated**. The flag is properly typed and used. No AttributeError occurs. The only minor quirk is that `--top` only has an effect with `--aggregate url` (it's ignored for `--aggregate status` and `--aggregate hour`), but that's a design choice, not a bug.
