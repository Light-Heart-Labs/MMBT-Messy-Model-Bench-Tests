# Verification Notes — logalyzer Code Review Triage

## Overview

Reviewed 15 issues from the preliminary report against the actual codebase.
**6 real, 9 fabricated.**

## Real Issues (6)

| # | File | Issue |
|---|------|-------|
| 001 | `filters.py:5` | `from collections import Iterable` — removed in Python 3.10+ |
| 002 | `filters.py:59` | `eval()` on user-supplied expressions |
| 004 | `README.md:10` | Claims "Real-time tail mode" that doesn't exist |
| 006 | `experimental.py` | Entire module is unused (no imports anywhere) |
| 013 | `io.py:24,27` | O(n²) list concatenation and character-by-character string building |
| 014 | `filters.py:36` | `entry.ip in allowlist` — O(n) lookup on a list |

## Fabricated Issues (9)

| # | Reason |
|---|--------|
| 003 | No SQL code exists anywhere in the codebase |
| 005 | `--top` flag is correctly defined with `type=int` and used properly |
| 007 | No `web.py` file exists; there is no web interface |
| 008 | `parse_line()` does not truncate to 8192 chars |
| 009 | `format_legacy()` is in `utils.py`, not `output.py` as claimed |
| 010 | `load_iter()` is a simple generator with no threading or shared state |
| 011 | `by_status()` is a straightforward Counter increment — no double-counting |
| 012 | No `cache.py` file exists |
| 015 | `__init__.py` does not import `LogEntry` — it only sets `__version__` |

## Key Decisions

### Issue 009 — Wrong file citation
The `format_legacy()` function does exist, but in `utils.py:21`, not `output.py`.
Per the rules: "A wrong file citation makes the issue fabricated." The claim
specifically says "The `format_legacy()` function in `output.py` is unused" —
since `output.py` has no such function, the claim as written is fabricated.

### Issue 010 — Race condition claim
The `load_iter()` function is a straightforward generator. There is no
concurrency mechanism, no shared mutable state, and no claim that it's
thread-safe. The "race between file-handle creation and iteration" is
nonsensical for a single-threaded generator pattern.

### Issue 015 — Import claim
`__init__.py` is minimal (2 lines: docstring + `__version__`). It does not
import anything from `parser`. The claim is entirely fabricated.
