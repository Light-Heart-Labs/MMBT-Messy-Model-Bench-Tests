# Verification Notes for logalyzer Code Review Triage

## Overview

Reviewed 15 issues from the preliminary code-review report against the actual logalyzer codebase. Found **6 real** issues and **9 fabricated** ones.

## Real Issues (6)

### 001 — `from collections import Iterable` (filters.py:5)
Confirmed. `Iterable` was moved from `collections` to `collections.abc` in Python 3.3 and the direct import was removed in Python 3.10. On Python 3.11 this raises `ImportError`. This is a breaking bug.

### 002 — `eval()` usage (filters.py:59)
Confirmed. The `expression_filter()` function uses `eval()` with restricted builtins. While `{"__builtins__": {}}` prevents access to built-in functions, the `entry` object is still accessible and its methods/attributes can be called. This is a security concern.

### 004 — README false claim about tail mode
Confirmed. README.md line 12 claims "Real-time tail mode for live log streams" but no `--tail` flag or streaming logic exists in cli.py or anywhere else.

### 006 — experimental.py is dead code
Confirmed. The file exists but is never imported by any other module. `grep -r 'experimental' --include='*.py'` returns no results.

### 013 — O(n²) performance in io.py load()
Confirmed. Two O(n²) patterns:
- Line 24: `result = result + [entry]` — creates a new list each iteration
- Line 27: `accumulated = accumulated + ch` — builds strings character by character

### 014 — O(n) membership test in ip_allowlist_filter
Confirmed. `entry.ip in allowlist` uses list membership testing. The `--ip` flag in cli.py uses `action='append'` which produces a list. For large allowlists, this should be converted to a set.

## Fabricated Issues (9)

### 003 — SQL injection in parser.py
Fabricated. parser.py contains no SQL code whatsoever. It only uses regex to parse log lines into dataclass instances.

### 005 — --top flag broken
Fabricated. The `--top` flag is properly defined with `type=int` and used correctly at line 64. No AttributeError would occur.

### 007 — Missing CSRF in web.py
Fabricated. `logalyzer/web.py` does not exist. There is no web interface in this codebase.

### 008 — Line truncation in parser.py
Fabricated. `parse_line()` does not truncate input. It uses `line.strip()` and regex matching on the full line. No 8192-character limit exists.

### 009 — format_legacy() in output.py
Fabricated. The function exists in `logalyzer/utils.py:21`, NOT in `output.py`. Per the rules, a wrong file citation makes the issue fabricated.

### 010 — Race condition in io.py load_iter()
Fabricated. Each call to `load_iter()` creates its own file handle. There is no shared mutable state between concurrent calls. The claim of a race condition is not supported by the code.

### 011 — Double-counting in by_status()
Fabricated. The function simply iterates entries and increments a Counter. Each entry is counted exactly once. No special handling of 3xx codes exists.

### 012 — Stale cache in cache.py
Fabricated. `logalyzer/cache.py` does not exist. There is no caching layer in this codebase.

### 015 — __init__.py imports LogEntry
Fabricated. `__init__.py` only contains a docstring and `__version__`. It does not import `LogEntry` from `parser`.
