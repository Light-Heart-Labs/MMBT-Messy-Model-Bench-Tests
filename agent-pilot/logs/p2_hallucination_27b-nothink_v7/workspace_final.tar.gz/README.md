# Logalyzer Code Review Triage

This directory contains the results of verifying 15 issues from a preliminary code-review report against the actual logalyzer codebase.

## Files

- **triage.json** — The main output. Contains verdicts (`real` or `fabricated`) for each of the 15 issues, with evidence citations.
- **notes.md** — Detailed reasoning for each verdict, organized by real vs. fabricated.
- **decisions/** — ADRs for borderline calls where the issue description partially matched but had incorrect details.

## Summary

| Verdict | Count |
|---------|-------|
| Real    | 6     |
| Fabricated | 9 |

## Real Issues

| ID | Description | Location |
|----|-------------|----------|
| 001 | `from collections import Iterable` (removed in Python 3.10+) | `filters.py:5` |
| 002 | `eval()` with restricted builtins in expression filter | `filters.py:59` |
| 004 | README claims "Real-time tail mode" that doesn't exist | `README.md:12` |
| 006 | `experimental.py` is dead code (never imported) | `experimental.py` |
| 013 | O(n²) list concatenation and string building in `load()` | `io.py:24,27` |
| 014 | O(n) list membership test in `ip_allowlist_filter()` | `filters.py:36` |

## Fabricated Issues

| ID | Reason |
|----|--------|
| 003 | No SQL code exists in parser.py |
| 005 | `--top` flag is correctly typed and used |
| 007 | `web.py` does not exist |
| 008 | No line truncation in `parse_line()` |
| 009 | `format_legacy()` is in `utils.py`, not `output.py` |
| 010 | No race condition in `load_iter()` |
| 011 | No double-counting in `by_status()` |
| 012 | `cache.py` does not exist |
| 015 | `__init__.py` does not import `LogEntry` |
