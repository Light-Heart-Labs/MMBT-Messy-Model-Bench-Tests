# ADR-001: Issue 009 — format_legacy() location mismatch

## Context

Issue 009 claims that `format_legacy()` is an unused function in `logalyzer/output.py`. However, the function actually exists in `logalyzer/utils.py:21`, not in `output.py`.

## Decision

Labeled as **fabricated** because the file citation is wrong. Per the rules: "A wrong file citation makes the issue fabricated. If issue 009 claims a function is in `output.py` but the function actually lives in `utils.py`, the issue as written is fabricated."

## Notes

- The function `format_legacy()` does exist in the codebase (at `utils.py:21`)
- It is indeed unused (no other module imports it)
- However, the report specifically claims it's in `output.py`, which is incorrect
- `output.py` contains `to_json()`, `to_csv()`, `to_text()`, and `render_aggregate()` — no `format_legacy()`
- The dead-code observation is valid but the file location is wrong, so the issue as written is fabricated
