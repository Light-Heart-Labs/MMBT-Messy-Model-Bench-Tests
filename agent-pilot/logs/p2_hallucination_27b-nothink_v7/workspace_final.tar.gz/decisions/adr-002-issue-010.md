# ADR-002: Issue 010 — Race condition claim in load_iter()

## Context

Issue 010 claims that `load_iter()` in `io.py` has a race condition when called concurrently by multiple threads on the same file.

## Decision

Labeled as **fabricated** because the code does not exhibit the described race condition.

## Reasoning

- `load_iter()` opens its own file handle via `with open(path, "r") as f`
- Each thread gets its own file descriptor and file position
- There is no shared mutable state between concurrent calls
- The `with` statement and the `for line in f` iteration are atomic within a single thread
- While file-level locking could be a concern in some scenarios, the specific claim of "a race between the file-handle creation and the iteration that can corrupt the parsed output" is not supported by the code
