# Legal Summary: SLA Credit Obligations — Friday Incident

## Incident Timeline
- **Start**: 14:11 UTC, Friday
- **End**: 18:24 UTC, Friday
- **Duration**: 4 hours 13 minutes

## Scope of Impact
- **Total impacted accounts**: 11,400
- **Enterprise accounts (named CSMs)**: ~28
- **Known downstream automation failures**: 4 cases

## SLA Framework
- Contractual SLA: 99.9% monthly uptime
- Credit provision for breach: Yes, per MSA terms

## SLA Credit Assessment
- **Enterprise accounts**: SLA was nominally breached for the ~28 named enterprise accounts. Contractual SLA credits are appropriate.
- **Downstream automation harm**: 4 confirmed cases of downstream automation breaking; these warrant additional engagement beyond standard credits (e.g., hands-on data cleanup support).
- **Remaining accounts**: ~11,372 accounts experienced impact but no confirmed downstream harm. SLA credits available on request; these are relationship-driven, not contractual.

## Recommendation
Process SLA credits for all enterprise accounts where the SLA was breached. Handle non-enterprise credit requests case-by-case, focusing on relationship preservation. The 4 downstream automation cases should receive additional support beyond standard credits.
