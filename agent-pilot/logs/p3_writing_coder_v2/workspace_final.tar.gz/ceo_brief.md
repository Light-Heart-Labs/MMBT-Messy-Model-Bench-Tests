# CEO Brief: Friday API Outage

**What happened**: A configuration change caused our primary API to return 502 errors for ~4 hours (14:11–18:24 UTC), affecting 11,400 customer accounts. Approximately 28 enterprise accounts experienced revenue impact during business hours.

**Scope**: This is the second 4+ hour outage in 2026 (the other was in February). While not yet at a "program overhaul" level, two such events in 90 days is a board-level signal we need to address reliability systematically.

**Remediations**:
1. Add staged config rollouts (canary deploys for configuration changes) — ~1 sprint.
2. Fix internal rate-limiting logic to use actual configuration values — ~2 weeks.
3. Update status-page health checks to mirror customer-facing endpoints — complete.
4. Implement 15-minute incident acknowledgment protocol — in progress.

**Next steps**: We will provide SLA credits to impacted enterprise accounts and handle refund requests case-by-case. Engineering is prioritizing the two medium-term fixes above.
