# Incident Rewrite Package

This directory contains three audience-specific rewrites of the internal draft memo (`/input/repo/draft_memo.md`), each tailored to its target audience per the specifications in `/input/repo/audience_briefs.json`.

## Output Files

- `ceo_brief.md` — Executive summary for CEO (148 words). Focuses on scope, impact, board-level signal, and top remediations. No technical jargon.
- `customer_email.md` — Mass email to affected customers (166 words). Warm, accountable, explains root cause in plain language, explicitly offers SLA credits.
- `legal_summary.md` — Legal assessment for in-house counsel (170 words). Precise facts only: timeline, scope, SLA framework, credit obligations.

## Decisions Log

The `decisions/` directory contains ADR-style notes on non-obvious choices, including:
- What was omitted per audience (e.g., no named engineer in customer email, no engineering details in legal summary)
- How word counts were managed
- Tone alignment strategies

## Working Notes

The `research/` directory contains working notes that track fact extraction, audience constraints, and draft development.
