# Subject: Update on Friday’s Service Disruption

Dear Valued Customer,

On Friday from 14:11 to 18:24 UTC, our API experienced an outage that caused 502 errors for many of you. We understand this disrupted your workflows, and we sincerely apologize.

The root cause was a configuration update that inadvertently throttled all authentication requests. Our engineering team identified the issue, rolled back the change, and restored full service by 18:24 UTC.

We’re taking concrete steps to prevent this from happening again:
- Implementing staged configuration rollouts for greater safety.
- Updating our internal rate-limiting logic to respond correctly to configuration changes.
- Enhancing our status monitoring to match the endpoints you use.

As part of our service commitment, we are issuing SLA credits to all affected enterprise accounts. If you’d like to request a credit or discuss the impact on your operations, please contact your CSM or support@company.com. For urgent matters, reply to this email.

We appreciate your continued trust and partnership.

Sincerely,
The Customer Success Team
