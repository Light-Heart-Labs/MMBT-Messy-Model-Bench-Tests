# Working Notes

## Source Memo Summary

- **Incident time**: 14:11 UTC to 18:24 UTC on Friday
- **Root cause**: Config change doubled rate-limit thresholds for auth service; internal limiter used a hard-coded MAX value, causing 100% throttle rate on all auth requests → API 502s
- **Status page issue**: Check pointed at wrong endpoint (/healthz on fixed instance), stayed green while customers got 502s
- **Impact**: ~11,400 customer accounts affected; ~28 enterprise accounts (named CSMs) had revenue impact; 4 cases of downstream automation breaking; 217 support tickets; 31 refund requests
- **Remediations**:
  1. Add canary deploys for config changes (1 sprint)
  2. Fix internal limiter to use actual global config instead of hard-coded MAX (2 weeks)
  3. Fix status-page check to use same endpoints as customers
  4. Improve incident comms: "we see it, we're working it" within 15 min
  5. Update runbooks for this failure mode

## Audience-Specific Constraints

### CEO Brief
- Max 250 words
- Must include: one-line summary, scope (accounts, revenue), second-occurrence-in-90-days, top 3-4 remediations
- Must NOT include: internal nicknames/apologies, engineering-jargon, detailed technical explanations

### Customer Email
- Max 350 words
- Must include: outage acknowledgement, root cause in plain language, commitments going forward, explicit SLA credit offer, contact path
- Must NOT include: named individual blame, engineering-jargon, internal board signals, "second outage in 90 days"

### Legal Summary
- Max 400 words
- Must include: exact time window, scope (account count, tier breakdown), SLA threshold (99.9%), 4 known downstream-automation cases, credit handling recommendation
- Must NOT include: speculation, named blame, informal candor, marketing language, engineering remediation details

## Key Numbers to Preserve
- 14:11 UTC to 18:24 UTC (4 hours 13 minutes)
- 11,400 customer accounts impacted
- ~28 enterprise accounts (named CSMs)
- 4 cases of downstream automation breaking
- 217 support tickets
- 31 refund requests
- 99.9% monthly uptime SLA
