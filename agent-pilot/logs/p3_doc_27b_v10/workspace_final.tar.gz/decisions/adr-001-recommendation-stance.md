# ADR-001: Recommendation Stance — PASS vs. MORE DILIGENCE

**Date:** 2026-03-15
**Status:** Accepted

## Context

The brief requires a clear stance: recommend follow-on investment, pass, or "more diligence needed" with specifics. The available sources present conflicting signals — strong growth metrics from the company versus churn, burn, and concentration risks from other sources.

## Decision

**PASS at current valuation** is the recommended stance.

## Rationale

"More diligence needed" is a hedge that defers the decision. The available information is sufficient to form a view:
- The company is cash-flow negative (~$500K/month net burn) [Source 3]
- The largest customer ($4.2M ARR) was lost in November 2025 [Source 2]
- Top-five customer concentration is ~38% of ARR [Source 3]
- The valuation was repriced down from $720M to $560M [Source 2]
- The company has cut staff twice in 12 months without public disclosure [Source 3, Source 4]
- International expansion has been deferred to 2027 [Source 4]

These facts, taken together, present a risk profile that does not justify a follow-on at the current valuation. The "What Would Change This Assessment" section captures the specific conditions that would flip the recommendation.

## Consequences

- The brief leads with PASS, not hedging
- Specific conditions for reconsideration are stated
- The investor can act on this recommendation without needing to commission additional research
