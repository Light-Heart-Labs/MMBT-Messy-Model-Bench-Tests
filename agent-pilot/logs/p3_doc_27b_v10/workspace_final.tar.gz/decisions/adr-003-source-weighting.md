# ADR-003: Source Weighting — Leaked Memo as Most Informative

**Date:** 2026-03-15
**Status:** Accepted

## Context

The five sources vary in reliability: press release (company narrative), TechCrunch (journalistic, unnamed sources), blog post (single ex-employee), leaked memo (internal document), SEC filing (regulatory).

## Decision

Weight the leaked internal memo [Source 4] as the most informative source for understanding management's own risk assessment and strategic direction.

## Rationale

The memo is an internal document from the CEO that outlines restructuring plans, cost targets, and strategic pivots. It reveals management's own assessment of the company's challenges (need for 30% international headcount reduction, deferral of expansion, product tier sunset) in their own words. This is more revealing than any external source because it shows what management is doing internally, not just what they're saying publicly.

The memo is obtained by The Information [Source 4], a reputable publication, which adds credibility to its authenticity.

## Consequences

- The brief emphasizes the memo's revelations about strategic retreat
- The memo's breakeven target (Q4 2026) is used as a key milestone
- The credit facility ($50M from Silicon Valley Bridge) is highlighted as a risk signal
