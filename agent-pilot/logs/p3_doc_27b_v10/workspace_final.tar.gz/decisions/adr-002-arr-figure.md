# ADR-002: ARR Figure — Use Adjusted $36-37M as Primary Reference

**Date:** 2026-03-15
**Status:** Accepted

## Context

The company reports $42M ARR [Source 1]. TechCrunch sources indicate adjusted run-rate is $36-37M after accounting for churned contracts [Source 2].

## Decision

Report both figures but use the adjusted $36-37M as the primary reference for valuation analysis.

## Rationale

The $42M figure includes contracts that had already terminated by quarter-end. Using the company's reported figure without adjustment would misrepresent the company's current revenue position. The adjusted figure is more conservative and therefore more appropriate for investment analysis.

## Consequences

- Valuation multiples are calculated on the adjusted figure
- The brief is more credible to sophisticated investors
- The company's growth narrative is contextualized rather than dismissed
