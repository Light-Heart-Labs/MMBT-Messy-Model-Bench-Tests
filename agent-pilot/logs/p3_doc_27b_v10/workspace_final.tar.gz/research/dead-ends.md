# Dead Ends — Ideas Considered and Abandoned

## 1. "More Diligence Needed" as the Primary Stance

**Considered:** Leading with "more diligence needed" and listing specific diligence items.

**Abandoned because:** The task explicitly requires a clear stance. "More diligence needed" is hedging. The available information is sufficient to form a view: the company is burning cash, has lost its largest customer, faces concentration risk, and is retreating from its stated strategy. A PASS recommendation is defensible on the available evidence. The "What Would Change This Assessment" section captures the diligence items that would flip the recommendation.

## 2. Including Engineering Quality as a Positive Factor

**Considered:** Giving more weight to the former employee's praise for the engineering architecture and CTO Daniel Wong.

**Abandoned because:** While the engineering quality is a genuine positive, it does not materially affect the investment decision at this stage. The platform's technical merit is already reflected in the $84M raise and the customer base of 1,400 brands. The investment decision hinges on unit economics, customer retention, and runway — not code quality. A brief mention in the opening paragraph suffices.

## 3. Speculating on the Identity of the Three Unnamed Investors

**Considered:** Attempting to identify the three additional investors not named in the Form D filing.

**Abandoned because:** No source provides this information. Speculating would violate the rule against invented facts. The Form D confirms 7 total investors [Source 5], and the named participants (Lightning Capital, Sequoia, Accel, FedEx Ventures) account for 4. The remaining 3 are irrelevant to the investment thesis.

## 4. Calculating an Implied Price-to-ARR Multiple Range

**Considered:** Providing a detailed range of valuation multiples (e.g., 13.3x–18.2x depending on which ARR figure is used) and comparing to sector benchmarks.

**Abandoned because:** No source provides sector benchmark multiples. Comparing to external benchmarks would require internet research, which is prohibited. The brief notes the multiple is "aggressive" based on the company's own risk profile (cash-flow negative, concentration risk) rather than external comparison.

## 5. Including the $50K/year Equity Vesting Detail

**Considered:** Using the former employee's compensation detail ($215K base + $50K equity/year) as evidence of competitive compensation and potential dilution.

**Abandoned because:** While interesting context, it does not materially affect the investment decision. The compensation structure is a single data point from one employee and does not inform the broader capital structure or dilution analysis.

## 6. Analyzing the FedEx Ventures Strategic Investment

**Considered:** Speculating on what the FedEx Ventures strategic investment means for distribution partnerships or channel access.

**Abandoned because:** No source provides detail on the terms or strategic rationale for the FedEx investment. The press release simply lists FedEx Ventures as a participant [Source 1]. Speculating on partnership implications would be fabrication.
