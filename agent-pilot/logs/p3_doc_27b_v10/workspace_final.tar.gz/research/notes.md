# Working Notes — Nimbus Logistics Source Analysis

## Source-by-Source Summary

### Source 1: Press Release (2026-01-14)
- $84M Series B led by Lightning Capital
- Post-money valuation: $560M (up from $230M Series A in 2023)
- Total funding: $128M across all rounds
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400+ e-commerce brands on platform
- 187 employees across Oakland, Austin, Berlin
- Investors: Lightning Capital (lead), Sequoia, Accel, FedEx Ventures (strategic)
- Founded 2021 by Mira Patel (CEO) and Daniel Wong (CTO)
- Platform: warehouse management + carrier orchestration + demand forecasting
- Named customers: Maevia, Truant Coffee, Brick & Cobble

### Source 2: TechCrunch (2026-01-15)
- Lost two top-5 customers in late 2025:
  - Sundry Brands: $4.2M ARR, did not renew in November
  - Klatch (fast-fashion): exited December, migrated to competitor
- ARR adjusted for churn: $36-37M run-rate (vs. $42M claimed)
- Sundry non-renewal characterized as "strategic mutual decision" by company
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026
- Net retention claimed above 110%
- Series B originally targeted $720M valuation, repriced down to $560M after Sundry news
- Two sources familiar with finances cited

### Source 3: Former Employee Blog (2026-02-22)
- Author: "Daniel R", former senior engineer, 14 months tenure
- Burn rate: ~$4M/month all-in (mid-2025)
- Revenue: ~$3.5M/month
- Net burn: ~$500K/month
- Layoffs: 22 people (~11% of org) in February 2025, mostly customer success and BD
- Layoffs not announced publicly
- Top 5 customers = ~38% of ARR
- Sundry loss was not a shock internally
- Engineering quality praised; CTO Daniel Wong called "the real deal"
- Compensation: $215K base + $50K equity/year for senior engineers
- Customer relationships described as genuine

### Source 4: Leaked Internal Memo (2026-03-05)
- Dated February 28, 2026, from CEO Mira Patel
- 30% reduction in international headcount (Berlin office)
- Berlin headcount: 41 → 28-30 by end of Q2
- International expansion deferred to 2027
- Berlin reframed as "support hub" not sales/expansion
- "Nimbus Lite" tier being sunset: ~310 customers ($5K-$20K ARR each)
- 90-day notice for affected customers
- New $50M credit facility from Silicon Valley Bridge
- Memo describes credit facility as "insurance, not operating capital"
- Runway: 24+ months at current burn, extended to 36+ months with restructuring
- Target: operating-cash-flow breakeven by Q4 2026
- Breakeven would trigger Series C conversations "from a position of strength"

### Source 5: SEC Form D (filed 2026-01-22)
- Confirms $84M offering, all sold
- 7 investors total
- Preferred Equity (Series B)
- Lightning Capital lead, Sequoia/Accel pro-rata, FedEx Ventures strategic
- 3 additional unnamed investors
- Use of proceeds: "expansion, working capital, general corporate purposes"
- No executive compensation disclosed in connection with offering

## Key Tensions Identified

1. **ARR discrepancy**: $42M (press release) vs. $36-37M adjusted (TechCrunch sources)
2. **Valuation repricing**: Originally $720M target, came down to $560M
3. **Customer concentration**: Top 5 = 38% of ARR (blog), loss of #1 customer ($4.2M)
4. **Burn vs. revenue**: $4M/mo burn vs. $3.5M/mo revenue (blog)
5. **Layoffs not disclosed**: 22 people cut in Feb 2025, not announced publicly
6. **International retreat**: Berlin being cut 30%, expansion deferred to 2027
7. **Product tier sunset**: Nimbus Lite being killed, ~310 small customers affected
8. **Credit facility**: $50M from Silicon Valley Bridge — "insurance" per memo
9. **Runway claims**: 24+ months at current burn, 36+ months with restructuring

## Source Quality Assessment

- **Press Release**: Company narrative, cherry-picked metrics, omits churn/layoffs
- **TechCrunch**: Journalistic, cites unnamed sources, company confirmed some facts
- **Blog Post**: Single ex-employee perspective, but specific numbers and insider knowledge
- **Leaked Memo**: Internal document, likely authentic given specificity, obtained by The Information
- **SEC Form D**: Regulatory filing, factual but limited scope
