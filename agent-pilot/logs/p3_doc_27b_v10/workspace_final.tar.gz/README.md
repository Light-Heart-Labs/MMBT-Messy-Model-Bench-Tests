# Nimbus Logistics — Executive Brief Output

## How to Read This Output

### Primary Deliverable
- **`brief.md`** — The 1-page executive brief (643 words). This is the main deliverable for the investment committee. It leads with a clear PASS recommendation and synthesizes all five sources.

### Supporting Materials
- **`key-facts.md`** — A structured table of every material fact incorporated into the brief, with source attribution. Use this to verify that no numbers were invented.
- **`research/notes.md`** — Working notes from reading the five sources. Includes source-by-source summaries, key tensions identified, and source quality assessment.
- **`research/dead-ends.md`** — Ideas considered and abandoned during analysis, with rationale for each decision.
- **`decisions/`** — ADR-style records for non-obvious framing choices:
  - `adr-001-recommendation-stance.md` — Why PASS rather than "more diligence needed"
  - `adr-002-arr-figure.md` — Why the adjusted $36-37M ARR is used as the primary reference
  - `adr-003-source-weighting.md` — Why the leaked memo is weighted as the most informative source
  - `adr-004-valuation-analysis.md` — Why no external benchmark comparisons are used

### Source Mapping
| Source | Type | Reliability |
|--------|------|-------------|
| Source 1 | Press Release | Company narrative; cherry-picked |
| Source 2 | TechCrunch Article | Journalistic; cites unnamed sources; partially confirmed by company |
| Source 3 | Former Employee Blog | Single perspective; insider knowledge; specific numbers |
| Source 4 | Leaked Internal Memo | Internal document; obtained by The Information; most detailed |
| Source 5 | SEC Form D | Regulatory filing; factual but limited scope |

### Recommendation
**PASS** at the $560M post-money valuation. The company is cash-flow negative, has lost its largest customer, faces significant concentration risk, and is retreating from its international expansion strategy. Reconsideration conditions are stated in the brief.
