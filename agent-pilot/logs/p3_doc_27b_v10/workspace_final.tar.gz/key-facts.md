# Key Facts Incorporated into Brief

## Financial Metrics

| Fact | Value | Source |
|------|-------|--------|
| Series B amount | $84M | [Source 1], [Source 5] |
| Post-money valuation | $560M | [Source 1] |
| Previous valuation (Series A, 2023) | $230M | [Source 1] |
| Total funding raised | $128M | [Source 1] |
| Reported ARR (Q4 2025) | $42M | [Source 1] |
| ARR one year prior | $11M | [Source 1] |
| Adjusted run-rate ARR (post-churn) | $36-37M | [Source 2] |
| Monthly burn rate | ~$4M/month | [Source 3] |
| Monthly revenue | ~$3.5M/month | [Source 3] |
| Net monthly burn | ~$500K/month | [Source 3] (derived) |
| Original Series B target valuation | $720M | [Source 2] |
| Credit facility secured | $50M from Silicon Valley Bridge | [Source 4] |

## Customer & Market

| Fact | Value | Source |
|------|-------|--------|
| Number of customers | 1,400+ e-commerce brands | [Source 1] |
| Top 5 customers as % of ARR | ~38% | [Source 3] |
| Largest customer lost | Sundry Brands, $4.2M ARR, November 2025 | [Source 2] |
| Second customer lost | Klatch (fast-fashion), December 2025 | [Source 2] |
| New contracts signed Q1 2026 | 3 contracts, each $1M+ ARR | [Source 2] |
| Net retention rate (claimed) | Above 110% | [Source 2] |
| Nimbus Lite customers being sunset | ~310 customers, $5K-$20K ARR each | [Source 4] |

## Organizational

| Fact | Value | Source |
|------|-------|--------|
| Employee count | 187 | [Source 1] |
| Offices | Oakland, Austin, Berlin | [Source 1] |
| Layoffs (Feb 2025) | 22 people (~11% of org) | [Source 3] |
| Layoffs public announcement | None | [Source 3] |
| Berlin headcount reduction | 41 → 28-30 (30% cut) | [Source 4] |
| International expansion timeline | Deferred to 2027 | [Source 4] |
| Target breakeven | Q4 2026 | [Source 4] |
| Runway at current burn | 24+ months | [Source 4] |
| Runway with restructuring | 36+ months | [Source 4] |

## Investor & Governance

| Fact | Value | Source |
|------|-------|--------|
| Lead investor | Lightning Capital | [Source 1], [Source 5] |
| Existing investors participating | Sequoia Capital, Accel | [Source 1], [Source 5] |
| Strategic investor | FedEx Ventures | [Source 1], [Source 5] |
| Total investors in round | 7 | [Source 5] |
| Security type | Series B Preferred Equity | [Source 5] |
| Use of proceeds | "Expansion, working capital, general corporate purposes" | [Source 5] |
| Executive compensation in offering | $0 disclosed | [Source 5] |

## Founding & Product

| Fact | Value | Source |
|------|-------|--------|
| Founded | 2021 | [Source 1] |
| CEO | Mira Patel | [Source 1] |
| CTO | Daniel Wong | [Source 1] |
| Platform components | Warehouse management, carrier orchestration, demand forecasting | [Source 1] |
| Named customers | Maevia, Truant Coffee, Brick & Cobble | [Source 1] |
