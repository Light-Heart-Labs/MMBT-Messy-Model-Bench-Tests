# Executive Brief: Nimbus Logistics, Inc. — Follow-On Investment Recommendation

**Date:** 2026-03-15
**Subject:** Series B follow-on evaluation

---

## Recommendation: PASS at current valuation

Nimbus Logistics presents a credible technology platform with strong founding leadership, but the risk profile revealed across multiple sources does not justify a follow-on at the $560M post-money valuation. The company is cash-flow negative, has lost its largest customer, faces significant concentration risk, and is actively retreating from its international expansion strategy. A follow-on would be reconsidered only if the company demonstrates sustained adjusted ARR above $40M, reduces top-five customer concentration below 25%, and achieves its Q4 2026 breakeven target.

---

## The Numbers: Reported vs. Adjusted

Nimbus reports $42M ARR as of Q4 2025, up from $11M a year prior [Source 1]. However, two sources familiar with the company's finances indicate this figure includes contracts that had already churned: Sundry Brands ($4.2M ARR, non-renewal in November) and Klatch (exit in December) [Source 2]. Adjusted for churn, the current run-rate is closer to $36–37M [Source 2].

Burn is equally concerning. A former senior engineer reports ~$4M/month all-in against ~$3.5M in monthly revenue as of mid-2025, implying ~$500K/month net burn [Source 3]. The Series B and a $50M credit facility from Silicon Valley Bridge extend runway to 36+ months under the company's restructuring plan [Source 4], but the company remains cash-flow negative with no clear inflection before Q4 2026.

---

## Customer Concentration and Churn

The top five customers represent approximately 38% of ARR [Source 3]. The loss of Sundry Brands — the largest contract at $4.2M — followed by Klatch in December, is a material hit [Source 2]. CEO Mira Patel claims three new $1M+ ARR contracts signed in Q1 2026 and net retention above 110% [Source 2], but these claims are unverified and may reflect aggressive booking to support the fundraising narrative.

Compounding the churn concern, the company is sunseting its "Nimbus Lite" tier, affecting ~310 small customers ($5K–$20K ARR each) with a 90-day notice [Source 4].

---

## Organizational Instability

Nimbus has cut staff twice in the past year. In February 2025, the company quietly laid off 22 people (~11% of the org), primarily in customer success and BD, without public announcement [Source 3]. An internal memo dated February 2026 outlines a 30% reduction in international headcount, cutting the Berlin office from 41 to 28–30 employees [Source 4]. International expansion has been deferred to 2027, with Berlin reframed as a "support hub" [Source 4].

The lack of transparency around the 2025 layoffs raises governance concerns. The reported 187-employee count [Source 1] reflects the post-layoff organization.

---

## The Valuation Question

The Series B closed at $560M, more than doubling the $230M Series A from 2023 [Source 1]. Insiders report the round was originally targeted at $720M and repriced downward after the Sundry non-renewal became known to the lead investor in early December [Source 2]. At $560M, the valuation implies a price-to-ARR multiple of approximately 15x on reported ARR (or 15–16x on the adjusted $36–37M figure), which is aggressive for a cash-flow-negative logistics platform with demonstrated concentration risk.

---

## What Would Change This Assessment

A follow-on becomes viable if:
1. **Adjusted ARR exceeds $40M** on a sustained basis.
2. **Top-five concentration falls below 25%**.
3. **Q4 2026 breakeven is on track**, with quarterly progress showing declining net burn.
4. **Transparency improves**, including public disclosure of material customer losses.

---

## Source Quality Note

The company press release [Source 1] and SEC Form D [Source 5] provide verified financial data. The TechCrunch article [Source 2] cites unnamed sources but was partially confirmed by the company. The former-employee blog [Source 3] offers insider perspective but reflects one individual's experience. The leaked internal memo [Source 4], obtained by The Information, provides the most detailed view of management's own risk assessment. Where sources conflict, the more conservative figure has been used.
