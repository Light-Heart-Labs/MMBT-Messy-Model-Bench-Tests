# Diligence Asks for the Next 2 Weeks

## 1. Revenue Quality & Growth Sustainability

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| Provide cohort analysis of revenue growth: breakdown of new vs. expansion vs. churn by quarter in FY2025. | Borealis CFO | 2026-04-22 | To assess growth quality and sustainability. |
| Share sales pipeline report (value, stage, win rate) as of 2026-04-15. | Borealis Sales Lead | 2026-04-22 | To validate growth trajectory beyond historical. |
| Provide unit economics: CAC, payback period, and LTV by customer segment. | Borealis CFO | 2026-04-23 | To assess scalability and long-term margin potential. |

## 2. Customer Health & Retention

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| Conduct reference calls with 5 *randomly selected* customers (not just top 5), including at least 2 churned or downgraded accounts. | Corp Dev | 2026-04-24 | To get unbiased view of customer sentiment. |
| Provide churn analysis: reasons for churn, timing, and correlation with product usage or support tickets. | Borealis Product Ops | 2026-04-23 | To understand root causes of 9% logo churn. |
| Share NPS breakdown by customer segment (e-commerce vs. B2B SaaS vs. others). | Borealis Customer Success | 2026-04-22 | To validate "high 40s NPS" claim and identify segment risks. |

## 3. Financial & Contractual Diligence

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| Review Borealis's most recent 12-month cash flow forecast and assumptions (growth, burn, runway). | Borealis CFO | 2026-04-22 | To verify runway calculation and burn trends. |
| Provide summary of top 10 customer contracts: renewal dates, termination clauses, and pricing terms. | Borealis Legal | 2026-04-23 | To assess revenue visibility and contract risk. |
| Share data on customer concentration: % of ARR from top 5, 10, and 20 customers. | Borealis Finance | 2026-04-22 | To quantify customer dependency risk. |

## 4. Product & Technical Deep Dive

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| Independent code review (by our Eng team) covering scalability, data governance, and compliance (GDPR/CCPA). | Our VP Eng + external contractor | 2026-04-25 | To validate "clean tech debt" claim. |
| Provide data pipeline architecture diagram and data lineage documentation. | Borealis CTO | 2026-04-24 | To assess data quality and regulatory risk. |
| Review product roadmap: prioritize features vs. integration requirements. | Our PM + Borealis PM | 2026-04-23 | To validate 4-6 month integration timeline. |

## 5. Integration & Retention Plan

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| Provide detailed retention plan for Borealis team (incentives, roles, timeline) with sign-offs from key individuals. | Corp Dev + HR | 2026-04-24 | To validate "85% retention" assumption. |
| Share integration work plan: milestones, resource allocation, and risk mitigation. | Our Integration Lead | 2026-04-25 | To assess feasibility of 4-6 month timeline. |
| Conduct cultural fit assessment with Borealis engineering and product teams. | Our HR + Corp Dev | 2026-04-23 | To identify potential friction points. |

## 6. Synergy Validation

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| Breakdown of $3.2M synergy estimate: infra, headcount, and licensing savings with assumptions. | Our Finance + Ops | 2026-04-24 | To validate synergy claim and timeline. |
| Estimate integration costs (legal, migration, downtime, severance). | Our Finance | 2026-04-23 | To assess net financial impact. |

## 7. Risk Assessment

| Ask | Owner | Deadline | Notes |
|-----|-------|----------|-------|
| Draft "Risks & Mitigations" section covering: key-person risk (CTO), integration failure, customer migration failure, regulatory issues, and cultural misalignment. | Corp Dev | 2026-04-25 | To close the gap in the current pack. |
