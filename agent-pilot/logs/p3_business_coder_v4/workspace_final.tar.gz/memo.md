# Executive Committee Review: Borealis Analytics Acquisition  
**Date:** 2026-04-15  
**Prepared by:** Executive Committee Member  

## Recommendation: HOLD

I recommend **HOLD** — do not proceed to LOI at $84M at this time. The deal has strong strategic fit (mid-market e-commerce expansion, minimal feature overlap), but the diligence pack is incomplete and contains significant red flags. I would change my stance to **PROCEED** if the following are validated in the next 2 weeks:  
1. Cohort analysis and unit economics (CAC, payback, LTV) confirm sustainable growth.  
2. Randomized customer reference calls and churn analysis validate strong retention across segments.  
3. Integration plan with retention incentives and synergy breakdown is signed off by our internal teams.  
4. A formal "Risks & Mitigations" section is added and accepted by legal/tech teams.  

## Strongest Concerns

**1. Revenue Growth Lacks Context.** The pack cites 80% YoY revenue growth ($5.1M → $9.2M) and 92% YoY ARR growth, but provides no breakdown of *how* this was achieved. Was it driven by a few large logos? Are there signs of discounting or churn? Without unit economics or cohort analysis, the growth may not be repeatable.

**2. Customer Metrics Are Overstated.** The pack cites NPS in the "high 40s" and four positive testimonials from the top 5 customers. With only 280 customers, a sample of 5 is statistically insignificant and potentially biased (e.g., only satisfied customers were quoted). The 27-point spread between net retention (118%) and logo retention (91%) is also unusual for a Series-A company and suggests expansion is driven by a few large accounts — a higher-risk pattern.

**3. Integration Risk Is Understated.** The pack claims a "4-6 month full integration timeline" and "85% retention expected" but provides no evidence. There is no detailed retention plan, migration risk assessment, or integration cost breakdown. The 12-month Aurora sunset is particularly risky if customer adoption stalls.

**4. Valuation Context Is Incomplete.** While $84M (~7.4x ARR) is "in line with comps," the pack ignores key adjustments: Borealis is a private Series-A company (not public-acquired), and no liquidity discount or control premium is applied. With only $4.1M cash and 22 months runway, the company is not yet self-sustaining — a factor not reflected in the valuation.

## Diligence Asks for Next 2 Weeks

To de-risk the deal, I propose the following priorities:  

**Revenue & Customer Health:**  
- Cohort analysis of revenue growth (new vs. expansion vs. churn) and unit economics (CAC, payback, LTV) by 2026-04-22.  
- Reference calls with 5 *randomly selected* customers (including churned accounts) and churn analysis by 2026-04-24.  

**Integration & Synergy Validation:**  
- Detailed integration work plan with retention incentives and synergy breakdown by 2026-04-25.  
- Independent Eng review of codebase (scalability, data governance, compliance) by 2026-04-25.  

**Risk Assessment:**  
- Formal "Risks & Mitigations" section covering key-person risk (CTO), migration failure, and regulatory issues by 2026-04-25.  

If these asks are not satisfactorily addressed, I recommend passing on the deal.
