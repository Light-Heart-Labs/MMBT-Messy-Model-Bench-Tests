# Concerns with the Borealis Acquisition Deal Pack

## 1. Overstated Strategic Rationale

- **Claim**: "Borealis would extend our analytics surface area into mid-market e-commerce, a segment we currently service only via partner integrations."
- **Concern**: This is presented as a clear strategic gap, but the pack provides no data on the size of that gap, the revenue opportunity, or whether our existing partner integrations are already serving the segment adequately. Without this context, it's unclear if this is a *new* market or just a more direct path to an existing one.

## 2. Revenue Growth Sustainability

- **Claim**: 80% YoY revenue growth ($5.1M → $9.2M) and 92% YoY ARR growth.
- **Concern**: The pack does not break down *how* this growth was achieved. Was it driven by a few large logos? Is the sales pipeline sustainable? Are there signs of churn or discounting? Without unit economics or cohort analysis, the growth looks impressive but may not be repeatable.

## 3. Net Retention vs. Logo Retention Discrepancy

- **Claim**: Net retention 118%, Logo retention 91%.
- **Concern**: A 27-point spread is unusually high for a Series-A company. This could indicate that a few large customers are driving disproportionate growth (expansion-only retention), which is riskier than broad-based expansion. The pack doesn't explain this gap.

## 4. Customer Testimonials — Small Sample, High Variance

- **Claim**: 4 of 5 top customers willing to be quoted, NPS in "high 40s".
- **Concerns**:
  - Sample size of 5 is tiny for a 280-customer base.
  - No breakdown of NPS by customer segment (e.g., e-commerce vs. B2B SaaS).
  - Testimonials are curated and positive; no mention of detractors or churn reasons.
  - No data on how representative these 5 are of the broader base.

## 5. Valuation Context — Missing Key Details

- **Claim**: $84M (~7.4x ARR) is "in line with the lower comps".
- **Concerns**:
  - Comps are all public-acquired companies (Salesforce, Snowflake, HubSpot), but Borealis is a private Series-A. The liquidity discount and control premium are not addressed.
  - No adjustment for Borealis's stage (e.g., earlier-stage companies typically trade at lower multiples).
  - No discussion of Borealis's cash position ($4.1M) and runway (22 months) relative to the acquisition price.

## 6. Integration Risk — Understated

- **Claim**: "4-6 month full integration timeline", "85% retention expected".
- **Concerns**:
  - No risk assessment of the 12-month Aurora sunset. What happens if customer migration stalls or fails?
  - "85% retention" is stated without evidence. The pack mentions "conversations with their VP Eng" but no formal retention plan or incentives.
  - No mention of cultural fit or potential friction between engineering teams.

## 7. Tech Debt — "Clean" is Subjective

- **Claim**: "Modern Python + Postgres + dbt — clean, well-tested. No concerning patterns."
- **Concerns**:
  - Engineering review is cited but no details on *how* it was conducted (e.g., code scan, interviews, audit).
  - "No concerning patterns" is vague. What about scalability, data governance, or compliance (e.g., GDPR, CCPA)?
  - No mention of data quality or lineage — critical for a data analytics product.

## 8. Burn Rate and Runway — Misleading Context

- **Claim**: "$750K monthly burn, 22 months runway at last cap raise."
- **Concerns**:
  - Runway is calculated at *last cap raise*, not current burn. If growth has accelerated, burn may have increased too.
  - No discussion of whether the company is on track to profitability or if the burn is expected to rise post-acquisition (e.g., due to integration costs).

## 9. Synergy Estimate — Unsubstantiated

- **Claim**: "$3.2M annual cost savings from consolidated infra."
- **Concerns**:
  - No breakdown of how this was calculated (e.g., infra cost reduction, headcount overlap, licensing savings).
  - No timeline for realizing synergies. Are they Year 1 or Year 3?
  - Integration costs are not mentioned — could easily offset or exceed savings.

## 10. Missing Risk Section

- **Concern**: The pack has no dedicated "Risks & Mitigations" section. Key risks like customer churn, integration failure, regulatory issues, or key-person dependency (e.g., CTO) are not explicitly addressed.

## 11. Sign-Off Scope Ambiguity

- **Claim**: "Signed off by: VP Corp Dev, VP Eng (technical review), CFO (financial review)."
- **Concern**: No indication of *what* each sign-off covers. For example, did the VP Eng review only the codebase, or also data practices? Did the CFO review only financials, or also customer contracts and liabilities?

## 12. LOI Timeline Pressure

- **Concern**: Decision needed by 2026-04-30 (2 weeks from pack date). This tight timeline may pressure the committee to accept incomplete diligence. The pack should explicitly state what diligence is *remaining* and what assumptions are being relied upon.
