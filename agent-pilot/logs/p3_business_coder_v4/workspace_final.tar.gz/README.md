# Borealis Analytics Acquisition Review

This directory contains the executive committee review of the Borealis Analytics acquisition diligence pack.

## Files

| File | Purpose |
|------|---------|
| `memo.md` | **Primary deliverable**: 1-page memo with recommendation, top concerns, and key asks. |
| `concerns.md` | Comprehensive list of all concerns with the deal pack (12 items). |
| `asks.md` | Detailed diligence plan for the next 2 weeks (21 specific asks). |
| `decisions/adr001.md` | ADR: Memo length constraint (≤700 words). |
| `decisions/adr002.md` | ADR: Recommendation stance (HOLD, with conditions to PROCEED). |
| `decisions/adr003.md` | ADR: Memo structure (recommendation → concerns → asks). |

## Summary

- **Recommendation**: HOLD — do not proceed to LOI at $84M until key diligence gaps are addressed.
- **Top Concerns**: Revenue quality, customer metrics reliability, integration risk, and valuation context.
- **Next Steps**: 2-week diligence sprint (see `asks.md`) to validate growth sustainability, customer health, and integration plan.

## How to Use

1. Read `memo.md` for the executive summary.
2. Review `concerns.md` for full context on identified issues.
3. Refer to `asks.md` for the action plan to de-risk the deal.
