# Working Notes — Synthesis Process

## Workstreams Identified

1. **Dashboard Refresh** — Core dashboard UI overhaul. Owner: Jen (UX). Status: On track. Mobile-responsive added to V1 scope (week 4). Custom branding deferred to V2 (week 3).
2. **Query Layer / Backend** — Backend work to support SDK filter expressions. Owner: Marcus (TL). Status: 60% done, tracking to mid-May (week 6). Was 4-6 weeks, revised to 8 weeks (week 2).
3. **Embedded SDK** — Analytics SDK that uses dashboard primitives. Owner: Marcus (backend) + Roman (data). Status: Private beta only for V1 (week 6). Access-control layer is a blocker; 4-week effort identified (week 5).
4. **Data Pipeline / Panel Density** — Architectural fix for >40 panels/page. Owner: Roman. Status: 30% done, targeting V1.1 in August (week 6). 40-panel limit accepted as known limitation for V1 (week 3).
5. **Security / IAM** — Access-control layer for SDK multi-tenant model. Owner: Priya (security) + Marcus. Status: IAM design started (week 6). 4-week minimum project (week 5).
6. **Mobile** — Mobile strategy for dashboard. Owner: Jen. Status: Web-responsive chosen for V1 (4 weeks), native deferred to V2 (week 4). On track for mid-May (week 5).

## Decisions Chronology

1. **Week 1 (2026-03-04):** Aurora = dashboard refresh + embedded SDK as one shipped thing. (Sara)
2. **Week 3 (2026-03-18):** Custom branding cut from V1. (Brendan)
3. **Week 3 (2026-03-18):** 40-panel limit accepted as known limitation for V1; architectural fix deferred to V1.1. (Brendan)
4. **Week 3 (2026-03-18):** End-of-July GA target (conditional on above cuts). (Brendan)
5. **Week 4 (2026-03-25):** Mobile = web-responsive in V1, native in V2. (Sara + Jen)
6. **Week 6 (2026-04-08):** SDK ships in private beta (3-5 customers) for V1; access-control contracts required. (Brendan)

## Risks

1. **HIGH — Access-control layer timeline:** 4-week IAM project (Priya, week 5) may slip V1 if private-beta contracts don't land. Legal hasn't responded (week 6).
2. **HIGH — Maevia customer expectation:** Promised GA SDK at conference; will push back on private-beta. (week 6)
3. **MEDIUM — Query-layer delay:** 8-week effort, 60% done (week 6). If it slips past mid-May, V1 timeline is at risk.
4. **MEDIUM — Panel-density limitation:** 40-panel limit is a known V1 limitation; architectural fix is 30% done (week 6).
5. **LOW — Custom branding deferred:** Parked for V2; no current risk. (week 3)

## Milestones

- **Mid-May 2026:** Query-layer completion (Marcus)
- **Mid-May 2026:** Mobile-responsive completion (Jen)
- **End of July 2026:** V1 GA (dashboard refresh + SDK private beta) — conditional
- **August 2026:** V1.1 with architectural fix (Roman)
- **August 2026:** SDK V1.5 with full access control (if option B doesn't resolve)

## Open Questions / Asks for CEO

1. Legal involvement for private-beta contracts — no response yet (week 6).
2. Maevia expectation management — they were promised GA SDK (week 6).
3. Final V1 date confirmation — end-of-July is conditional on access-control contracts landing.
