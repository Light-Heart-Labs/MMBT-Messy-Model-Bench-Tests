# Project Aurora — Status Report for CEO Brendan

**Prepared:** 2026-04-08 | **Source:** 6 weekly notes (2026-03-04 to 2026-04-08)

---

## Headline

Project Aurora (dashboard refresh + embedded analytics SDK) targets **end-of-July V1 GA**, but the SDK ships in **private beta** (3–5 customers) pending legal contracts. Two items need your attention: legal engagement and Maevia expectation management.

---

## Workstreams

| Workstream | Owner | Status | Blocks V1? |
|---|---|---|---|
| Dashboard Refresh | Jen | On track; mobile-responsive added (w4) | No |
| Query Layer | Marcus | 60% done; tracking to mid-May (w6) | Yes |
| Embedded SDK | Marcus + Roman | Private beta for V1; access-control in progress (w6) | Partially |
| Panel Density Fix | Roman | 30% done; targeting V1.1 in Aug (w6) | No — 40-panel limit accepted (w3) |
| Security / IAM | Priya + Marcus | Design started; 4-week effort (w5) | Yes — for full SDK GA |
| Mobile | Jen | Web-responsive on track for mid-May (w5); native → V2 (w4) | No |

---

## Risks

| Severity | Risk | Description |
|---|---|---|
| **HIGH** | Access-control contracts not finalized | Legal has not responded to private-beta contract draft (w6). |
| **HIGH** | Maevia expectation gap | Promised GA SDK at conference; will push back on private-beta (w6). |
| **MEDIUM** | Query-layer slip | 8-week effort, 60% done (w6). Past mid-May puts V1 at risk. |
| **MEDIUM** | Panel-density limitation | 40-panel/page limit is a known V1 limitation (w3). |
| **LOW** | Custom branding deferred | Parked for V2 (w3). No current impact. |

---

## Decisions Made

| Date | Decision | Decider |
|---|---|---|
| 2026-03-04 (w1) | Aurora = dashboard refresh + SDK as one product | Sara |
| 2026-03-18 (w3) | Custom branding cut from V1 | Brendan |
| 2026-03-18 (w3) | 40-panel limit accepted for V1; fix deferred to V1.1 | Brendan |
| 2026-03-18 (w3) | V1 GA target: end of July (conditional) | Brendan |
| 2026-03-25 (w4) | Mobile: web-responsive in V1, native in V2 | Sara + Jen |
| 2026-04-08 (w6) | SDK ships in private beta for V1 | Brendan |

---

## Milestones

| Target | Milestone | Owner |
|---|---|---|
| Mid-May 2026 | Query-layer complete | Marcus |
| Mid-May 2026 | Mobile-responsive complete | Jen |
| End of July 2026 | V1 GA (dashboard + SDK private beta) | Sara |
| August 2026 | V1.1 — panel density fix | Roman |

---

## Open Questions / Asks

1. **Legal engagement:** Legal has not responded to the private-beta contract draft (w6). Can you escalate?
2. **Maevia:** Promised GA SDK at conference (w6). How should we frame the private-beta pivot?
3. **V1 date:** End-of-July is conditional on contracts landing. If legal slips, delay V1 or ship dashboard-only?
