# Questions and Resolutions

## Q1: Where does `format_legacy` actually live?

**Question**: The task description says `output.py` contains `format_legacy()`, but in the actual codebase it's in `utils.py`.

**Resolution**: The task verification requires `from logalyzer.output import format_legacy` to work. I created `output/legacy.py` which re-exports `format_legacy` from `utils.py`. This satisfies the verification requirement without moving the function's definition (which would require changing `utils.py`, out of scope).

## Q2: Where should `render_aggregate` go?

**Question**: `render_aggregate` dispatches across text and JSON formats. It doesn't belong to a single renderer.

**Resolution**: Kept it in `output/__init__.py`. It's a thin 15-line dispatcher that doesn't warrant its own module. This keeps the public API surface identical — `from logalyzer.output import render_aggregate` works exactly as before.

## Q3: Should I fix the `collections.Iterable` import error?

**Question**: `filters.py` uses `from collections import Iterable` which is removed in Python 3.11. This blocks test execution.

**Resolution**: Fixed to `from collections.abc import Iterable`. This is a minimal compatibility fix, not a refactor. Documented in `dead-ends.md`.

## Q4: Should I fix the 3 pre-existing test failures?

**Question**: Three tests fail due to bugs in `filters.py` (string vs int comparison, `match` vs `search`) and `parser.py` (missing "Jul" in month names).

**Resolution**: Per task constraints, bug fixes are out of scope. Documented in `dead-ends.md`. The same 3 tests fail before and after the refactor, confirming behavior preservation.
