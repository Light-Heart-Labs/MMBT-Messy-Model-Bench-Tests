# Dead Ends

## Pre-existing bugs (not fixed, per task constraints)

### 1. `status_filter` doesn't handle string input

**File**: `logalyzer/filters.py`, `status_filter()`

**Bug**: The CLI passes `--status` as a string (e.g., `"404"`), but `status_filter` compares `entry.status == status` directly. Since `entry.status` is an `int`, `"404" == 404` is `False`.

**Test**: `test_status_filter_works_with_cli_string_input` fails.

**Not fixed**: Out of scope. The refactor is structural only.

### 2. `url_regex_filter` uses `match` instead of `search`

**File**: `logalyzer/filters.py`, `url_regex_filter()`

**Bug**: `re.match()` only matches at the start of the string. A pattern like `"admin"` won't match `"/admin/login"` because the URL starts with `/`. Should use `re.search()`.

**Test**: `test_url_regex_finds_substring_match` fails.

**Not fixed**: Out of scope.

### 3. `MONTH_NAMES` is missing "Jul"

**File**: `logalyzer/parser.py`, `MONTH_NAMES` list

**Bug**: The list has 11 entries — "Jul" is missing (the list jumps from "Jun" to "Aug"). This causes `ValueError` when parsing July timestamps.

**Test**: `test_timestamp_july_parses_correctly` fails.

**Not fixed**: Out of scope.

### 4. `collections.Iterable` import (fixed as compatibility shim)

**File**: `logalyzer/filters.py`

**Issue**: `from collections import Iterable` was removed in Python 3.3+ (moved to `collections.abc`). This blocks test execution on Python 3.11.

**Fixed**: Changed to `from collections.abc import Iterable`. This is a minimal compatibility fix, not a behavioral change.

## Approaches considered and rejected

### Approach: Move `format_legacy` from `utils.py` to `output/legacy.py`

**Rejected**: The task says "Only `logalyzer/output.py` may be split." Moving `format_legacy` out of `utils.py` would change `utils.py`, which is out of scope. Instead, `legacy.py` re-exports it.

### Approach: Create a separate `aggregate_renderer.py` for `render_aggregate`

**Rejected**: `render_aggregate` is a thin 15-line dispatcher that doesn't belong to any single format. Creating a dedicated module for it would be over-engineering. Keeping it in `__init__.py` is simpler and maintains the same import path.
