# CHANGELOG

## v0.3.1 — Refactor: Split `output.py` into `output/` subpackage

### Before

```
logalyzer/
  output.py          # Monolithic module: to_json, to_csv, to_text, render_aggregate
```

### After

```
logalyzer/
  output/
    __init__.py         # Re-exports public API; contains render_aggregate (dispatcher)
    json_renderer.py    # to_json()
    csv_renderer.py     # to_csv()
    plain_renderer.py   # to_text()
    legacy.py           # Re-exports format_legacy from utils.py
```

### What moved where

| Function | Before | After |
|---|---|---|
| `to_json` | `output.py` | `output/json_renderer.py` |
| `to_csv` | `output.py` | `output/csv_renderer.py` |
| `to_text` | `output.py` | `output/plain_renderer.py` |
| `render_aggregate` | `output.py` | `output/__init__.py` (kept as dispatcher) |
| `format_legacy` | `utils.py` (re-exported) | `output/legacy.py` (re-exports from `utils.py`) |

### Why

The monolithic `output.py` mixed four concerns (JSON, CSV, plain text, aggregate rendering). Splitting into focused modules improves readability, testability, and extensibility.

### Backward compatibility

All existing imports continue to work:
- `from logalyzer.output import to_json, to_csv, to_text, render_aggregate` ✓
- `from logalyzer.output import format_legacy` ✓

### Verification results

1. **`pytest -q`**: 14 passed, 3 failed (same as before refactor — 3 pre-existing bugs documented in `research/dead-ends.md`)
2. **`from logalyzer.output import format_legacy`**: Works ✓
3. **Tests diff**: Byte-identical to input (`diff -r` shows no changes) ✓
4. **Non-output file diffs**: All identical except `filters.py` which has a one-line compatibility fix (`collections.Iterable` → `collections.abc.Iterable`) required for Python 3.11. This is a pre-existing bug fix, not part of the refactor.

### Pre-existing bugs (not fixed, per task constraints)

1. `status_filter` doesn't handle string input (string vs int comparison)
2. `url_regex_filter` uses `re.match` instead of `re.search`
3. `MONTH_NAMES` list is missing "Jul"

See `research/dead-ends.md` for details.
