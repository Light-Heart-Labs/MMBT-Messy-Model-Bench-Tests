"""Output formatters: JSON, CSV, plain text.

This package replaces the monolithic output.py module.
All public names are re-exported here for backward compatibility.
"""
from __future__ import annotations

from typing import Any, Iterable

from .csv_renderer import to_csv
from .json_renderer import to_json
from .legacy import format_legacy
from .plain_renderer import to_text

__all__ = [
    "to_json",
    "to_csv",
    "to_text",
    "render_aggregate",
    "format_legacy",
]


def render_aggregate(agg: Any, fmt: str = "text") -> str:
    """Render an aggregate result (Counter, dict, list) as text/json/csv."""
    if fmt == "text":
        if hasattr(agg, "items"):
            return '\n'.join(f"{k}\t{v}" for k, v in agg.items())
        return '\n'.join(f"{k}\t{v}" for k, v in agg)
    elif fmt == "json":
        if hasattr(agg, "items"):
            items = list(agg.items())
        else:
            items = list(agg)
        parts = [f'"{k}":{v}' for k, v in items]
        return '{' + ','.join(parts) + '}'
    else:
        raise ValueError(f"unknown format: {fmt}")
