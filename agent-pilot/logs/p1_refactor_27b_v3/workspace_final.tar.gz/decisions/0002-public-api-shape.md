# ADR-0002: Public API shape

## Status

Accepted

## Context

The `logalyzer.output` module is imported by `cli.py` with:

```python
from .output import render_aggregate, to_csv, to_json, to_text
```

The task verification also requires:

```python
from logalyzer.output import format_legacy
```

## Decision

The `__init__.py` of the new `output/` package re-exports exactly these names:

| Name | Source module | Notes |
|---|---|---|
| `to_json` | `json_renderer.py` | Moved verbatim |
| `to_csv` | `csv_renderer.py` | Moved verbatim |
| `to_text` | `plain_renderer.py` | Moved verbatim |
| `render_aggregate` | `__init__.py` | Kept in `__init__.py` — it's a dispatcher, not a single-format renderer |
| `format_legacy` | `legacy.py` (→ `utils.py`) | Re-exported for backward compatibility |

The `__all__` list in `__init__.py` explicitly enumerates these five names to make the public API surface clear.

## Rationale for keeping `render_aggregate` in `__init__.py`

`render_aggregate` is a thin dispatcher that switches on a `fmt` parameter to produce text or JSON output for aggregate data (Counters, dicts, lists). It doesn't belong to any single renderer module because it handles multiple formats. Placing it in `__init__.py` keeps it accessible without creating a separate "aggregate_renderer.py" module for a 15-line function.

## Rationale for `format_legacy` in `legacy.py`

The function `format_legacy` actually lives in `utils.py` (not in the original `output.py`). The task specification requires it to be importable from `logalyzer.output`. The `legacy.py` module re-exports it from `utils.py`, satisfying both the verification requirement and the principle that `legacy.py` is the home for backward-compatibility shims.
