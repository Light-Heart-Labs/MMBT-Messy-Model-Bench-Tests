# ADR-0001: Why split output.py?

## Status

Accepted

## Context

The `logalyzer/output.py` module mixed four distinct concerns:

1. **JSON serialization** (`to_json`) — hand-built JSON string output for log entries
2. **CSV serialization** (`to_csv`) — uses `csv.writer` to produce CSV output
3. **Plain-text formatting** (`to_text`) — human-readable one-line-per-entry format
4. **Aggregate rendering** (`render_aggregate`) — a thin dispatcher that formats Counter/dict/list results

Additionally, the task specification called for a `format_legacy()` function to be available from `logalyzer.output`, though in the actual codebase it lives in `utils.py`.

This monolithic structure made it hard to:
- Understand which functions belong to which output concern
- Add new output formats without bloating the module
- Test individual renderers in isolation
- Reason about dependencies (e.g., `csv` and `io` imports only needed by CSV)

## Decision

Split `logalyzer/output.py` into a `logalyzer/output/` package with one module per concern:

| Module | Contents |
|---|---|
| `__init__.py` | Re-exports public API; contains `render_aggregate` (dispatcher, not tied to one format) |
| `json_renderer.py` | `to_json()` |
| `csv_renderer.py` | `to_csv()` |
| `plain_renderer.py` | `to_text()` |
| `legacy.py` | Re-exports `format_legacy` from `utils.py` |

## Consequences

- **Positive**: Each renderer is now a focused, single-responsibility module. New formats can be added as new files.
- **Positive**: All existing imports (`from logalyzer.output import X`) continue to work via `__init__.py` re-exports.
- **Neutral**: `render_aggregate` stays in `__init__.py` because it dispatches across formats rather than belonging to one.
- **Neutral**: `format_legacy` is re-exported from `legacy.py` (which imports from `utils.py`) to satisfy the verification requirement that `from logalyzer.output import format_legacy` works.
