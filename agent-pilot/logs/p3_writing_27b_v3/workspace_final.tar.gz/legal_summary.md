# Incident Summary — SLA Credit Obligation Review

**Incident Window:** 14:11 UTC to 18:24 UTC, Friday. Duration: approximately 4 hours 13 minutes.

**Scope of Impact:**
- Total accounts impacted: approximately 11,400.
- Enterprise accounts (with named CSMs) with confirmed revenue impact during business hours: approximately 28.
- Cases of confirmed downstream automation failure requiring manual remediation: at least 4.
- Inbound support tickets received: 217.
- Refund requests received to date: 31 (mix of SLA-credit-only requests and full-month-credit requests).

**Contractual SLA:** The applicable service-level agreement provides for 99.9% monthly uptime, with service credits for breach. Based on the incident duration and the proportion of the month affected, the SLA threshold was nominally breached for the approximately 11,400 impacted accounts.

**Credit-Request Handling Recommendation:**
- **SLA-driven requests (approximately 28 enterprise accounts):** Process standard SLA credits per the terms of each customer's Master Services Agreement. The SLA was breached; credits should not be contested.
- **Downstream-automation harm (at least 4 cases):** In addition to standard SLA credits, provide hands-on data-cleanup support engagement at no charge. These cases involve documented operational damage beyond uptime impact.
- **Remaining accounts (approximately 11,368):** SLA credits are available to any account that explicitly requests one. No proactive credit issuance is required for accounts that did not request credits.
- **Relationship-driven requests (accounts with no measurable impact requesting credits):** These are not contractual obligations. Handle case by case through finance and customer success.

**Status-Page Discrepancy:** The public status page reported green status for approximately the first 40 minutes of the incident because the monitoring check was configured against an incorrect endpoint. This has been corrected. This discrepancy does not alter the SLA breach determination.

**Pending:** Legal and finance are working through the 31 refund requests on a case-by-case basis. SLA-impact analysis is required by end of day Tuesday for the credit-processing batch.
