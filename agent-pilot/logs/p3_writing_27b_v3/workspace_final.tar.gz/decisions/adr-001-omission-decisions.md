# ADR-001: Omission Decisions Per Audience

## CEO Brief

| Decision | Rationale |
|---|---|
| Omitted named individuals (Marcus, Priya, Sarah) | Per spec: no internal nicknames or informal apologies. CEO needs outcomes, not personnel details. |
| Omitted technical root-cause detail (rate limiter, hard-coded MAX, fraction computation) | Per spec: no engineering jargon without translation. Replaced with "configuration change to our authentication service caused it to reject requests it should have allowed." |
| Included "second 4+ hour disruption in 2026" and "two incidents in 90 days" | Per spec: must include second-occurrence-in-90-days framing as board signal. |
| Included 4 remediations | Per spec: must include 3-4 most material remediations. Selected: staged config rollout, auth service fix, status-page correction, faster comms. |
| Included financial exposure section | CEO needs to understand liability scope for board prep. |

## Customer Email

| Decision | Rationale |
|---|---|
| Omitted named engineer (Marcus) | Per spec: must not blame a named individual. |
| Omitted "second outage in 90 days" framing | Per spec: this is an internal signal, not customer-facing. Including it would undermine confidence. |
| Omitted internal warnings (Sarah's June flag) | Per spec: no internal candor about unaddressed warnings. |
| Omitted technical jargon (rate limiter, MAX, throttling) | Per spec: no engineering jargon. Replaced with plain-language explanation. |
| Included explicit SLA credit offer | Per spec: must include explicit reference to SLA credit and how to request. |
| Included contact path (CSM + support) | Per spec: must include a contact path. |

## Legal Summary

| Decision | Rationale |
|---|---|
| Used "incident" not "outage" | Per spec: use "incident" not "outage." |
| Omitted named employees | Per spec: no named-employee blame. |
| Omitted engineering remediation details | Per spec: engineering remediation details are irrelevant to counsel. |
| Omitted speculation about future outages | Per spec: no speculation about future outages. |
| Omitted marketing language and apologies | Per spec: no marketing language, no apologies. |
| Included exact time window with timezone | Per spec: must include exact incident time window with timezone. |
| Included 4 downstream-automation cases | Per spec: must include the four cases of known downstream-automation harm. |
| Included credit-handling recommendation | Per spec: must include recommendation on credit-request handling. |
