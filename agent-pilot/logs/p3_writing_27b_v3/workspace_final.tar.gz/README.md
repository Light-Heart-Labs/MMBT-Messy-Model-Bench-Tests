# Incident Rewrite Output

This directory contains three audience-tailored rewrites of an internal outage memo, produced from a single source document. Each rewrite follows strict constraints defined in `audience_briefs.json` regarding content, tone, word limits, and prohibited material.

## Files

| File | Audience | Max Words | Actual Words |
|---|---|---|---|
| `ceo_brief.md` | CEO (board prep) | 250 | 241 |
| `customer_email.md` | Affected customers (mass email) | 350 | 282 |
| `legal_summary.md` | In-house counsel (SLA review) | 400 | 303 |
| `decisions/adr-001-omission-decisions.md` | Internal | — | ADR-style records of non-obvious omission choices per audience |
| `research/notes.md` | Internal | — | Working notes with extracted facts and audience-specific decisions |

## How to Read

Each rewrite is a standalone document. The CEO brief is a 5-minute read for board preparation, focusing on impact, board-level signals, and remediations. The customer email is a warm, accountable message to affected customers with an explicit SLA-credit offer. The legal summary is a dispassionate, factual record for counsel to advise on SLA-credit obligations. All facts in the rewrites are sourced exclusively from the original draft memo — no external information was introduced.
