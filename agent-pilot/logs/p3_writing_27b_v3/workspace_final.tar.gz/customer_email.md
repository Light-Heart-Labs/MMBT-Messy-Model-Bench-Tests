# Service Disruption — What Happened and What We're Doing About It

Dear Customer,

On Friday, from approximately 14:11 UTC to 18:24 UTC, you may have experienced errors when using our API. We want to be direct about what happened, what it means for you, and what we're doing to make sure it doesn't happen again.

**What happened:** A configuration change we deployed to our authentication service caused it to reject requests it should have allowed. This cascaded into errors across our API. We identified the problem, reverted the change at 18:18 UTC, and all services recovered fully by 18:24 UTC.

**Who was affected:** Approximately 11,400 customer accounts experienced some level of disruption. We know this disrupted your workflows, and we take full responsibility.

**What we're changing:**
- We are adding staged rollouts for configuration changes so updates are tested on a small subset before reaching all customers.
- We are fixing the underlying logic in our authentication service so it responds correctly to configuration updates.
- We have corrected our status-page monitoring so it accurately reflects the endpoints you use.
- We are implementing a 15-minute acknowledgment rule so you hear from us quickly, even before we have a full diagnosis.

**SLA credit:** If your account was affected, you are entitled to service-level-credit under our SLA. If you would like to request a credit, please contact your customer success manager or reach out to our support team. We will process eligible requests promptly.

We know trust is earned through reliability, and we fell short this time. We are committed to doing better.

If you have questions, please contact your customer success manager or reply to this email.

Sincerely,

The Engineering Team
