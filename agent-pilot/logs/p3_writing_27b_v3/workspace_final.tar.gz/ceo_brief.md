# CEO Board Prep — Friday Service Disruption

**Summary:** From 14:11 to 18:24 UTC Friday, our primary API returned errors for 60–100% of requests across all customer accounts. A configuration change to our authentication service caused the disruption. We reverted the change at 18:18 UTC; full recovery by 18:24 UTC.

**Impact:** Approximately 11,400 customer accounts were affected. Roughly 28 enterprise accounts experienced revenue impact during business hours. At least 4 customers had downstream automation failures requiring manual cleanup. We received 217 support tickets and 31 refund requests.

**Board Signal:** This is the second 4+ hour service disruption in 2026 (the first was a database storage issue in February). Two incidents in 90 days warrants board awareness. A third would require a full reliability program review.

**Remediations Underway:**
1. **Staged configuration rollout** — Adding per-region canary deployment for config changes (1 sprint, top priority).
2. **Authentication service fix** — Decoupling the internal limiter from a hard-coded threshold so it responds correctly to configuration updates (2-week project).
3. **Status-page monitoring corrected** — The check was pointing at the wrong endpoint; fixed Friday evening.
4. **Faster customer communication** — Implementing a 15-minute acknowledgment rule so customers hear from us before they have to ask.

**Financial Exposure:** Legal and finance are processing 31 refund requests case by case. Standard SLA credits apply to the 28 enterprise accounts. The 4 customers with downstream automation damage are being offered hands-on cleanup support in addition to SLA credits.
