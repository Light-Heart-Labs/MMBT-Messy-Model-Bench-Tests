# Changelog

## v0.3.2 (2025-01-XX)

**Bug fixes:**

- **`discount_amount()` was not dividing by 100.** The v0.3.0 breaking change switched the API from fraction (0.0–1.0) to percent (0–100), but the implementation still multiplied `price * percent_off` directly instead of `price * percent_off / 100`. This caused `discount_amount(100.0, 20.0)` to return `2000.0` instead of `20.0`. Fixed by dividing by 100.
- **Unused `json` import in `cart.py`.** An unused `import json` was left in the file (planted bug). Removed to satisfy ruff F401.
- **Import sorting and modern typing.** Applied ruff auto-fixes: sorted imports (I001), replaced `typing.List` with `list` (UP006/UP035), replaced `Optional[X]` with `X | None` (UP045).
- **`test_line_count_matches_qty_sum` updated for v0.3.0 API.** The changelog for v0.3.0 states that `Cart.line_count()` was changed to return the number of lines (not total quantity). The test was not updated to reflect this. Updated the test to expect `2` (number of lines) instead of `5` (total quantity).

**Verification:**
- `ruff check src/ tests/` → 0 errors
- `pytest -q` → 7 passed, 0 failed

## v0.3.1 (current — CI red)

CI is failing on this version. See `ci_failure.log` for the full output.

## v0.3.0

- **BREAKING**: `discount_amount()` and `apply_discount()` now take percent (0-100)
  instead of fraction (0.0-1.0). Update callers from `apply_discount(p, 0.2)` to
  `apply_discount(p, 20.0)`.
- `Cart.line_count()` now returns the number of lines, not the total quantity
  across lines. Tests should be updated where they relied on the old behavior.

## v0.2.0

- Added `Cart.set_discount()` for cart-wide discounts.
- `Cart.line_count()` returns total quantity across lines.

## v0.1.0

- Initial release.
