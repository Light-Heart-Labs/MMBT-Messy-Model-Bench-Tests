# ADR-001: Fix discount_amount implementation, not the tests

## Context

The `discount_amount()` function was returning `price * percent_off` instead of `price * percent_off / 100`. The v0.3.0 changelog documented a breaking API change from fraction (0.0–1.0) to percent (0–100), but the implementation was never updated to match.

## Decision

Fix the implementation in `src/discountkit/discount.py` by dividing by 100.

## Rationale

- The docstring examples (`discount_amount(100.0, 20.0) -> 20.0`) are correct.
- The tests are correct (they test the documented behavior).
- The changelog says the API takes percent (0–100), so the implementation must divide by 100.
- The code was simply never updated after the API change was documented.

## Consequences

- `discount_amount(100.0, 20.0)` now correctly returns `20.0`.
- `apply_discount(100.0, 20.0)` now correctly returns `80.0`.
- All discount-related tests pass.

---

# ADR-002: Fix test_line_count to match v0.3.0 API

## Context

The v0.3.0 changelog states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior." The test `test_line_count_matches_qty_sum` still expected the old behavior (total quantity = 5).

## Decision

Update the test to expect the new behavior (number of lines = 2).

## Rationale

- The changelog explicitly documents this as an intentional API change.
- The code correctly implements the new behavior (`return len(self.lines)`).
- The changelog itself says "Tests should be updated."
- Reverting the code would break the documented API contract.

## Consequences

- The test now correctly validates that `line_count()` returns the number of lines.
- The test name `test_line_count_matches_qty_sum` is slightly misleading now (it doesn't match qty sum), but renaming it would be cosmetic. The docstring was updated to clarify the intent.
