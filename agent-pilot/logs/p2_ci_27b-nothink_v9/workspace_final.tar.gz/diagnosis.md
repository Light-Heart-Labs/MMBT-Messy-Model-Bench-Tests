# Diagnosis

## CI Failure Analysis

The CI log showed 1 ruff error and 3 test failures.

### Issue 1: Ruff F401 — unused `json` import

**File:** `src/discountkit/cart.py`
**Error:** `F401 [*] 'json' imported but unused`
**Fix:** Removed the `import json` line.
**Reason:** The import was clearly a planted bug (comment even says "PLANTED BUG #3"). No code in the file uses `json`.

### Issue 2: `discount_amount()` returns wrong value

**File:** `src/discountkit/discount.py`
**Error:** `discount_amount(100.0, 20.0)` returns `2000.0` instead of `20.0`
**Root cause:** The v0.3.0 changelog says the API changed from fraction (0.0–1.0) to percent (0–100), but the implementation was never updated. The code does `price * percent_off` which treats the percent as a multiplier (20x) instead of a percentage (20%).
**Fix:** Changed `price * percent_off` to `price * percent_off / 100`.
**Decision:** Fix the code, not the test. The docstring examples (`discount_amount(100.0, 20.0) -> 20.0`) and the test expectations are correct. The implementation was wrong.

### Issue 3: `test_line_count_matches_qty_sum` fails

**File:** `tests/test_cart.py`
**Error:** `assert c.line_count() == 5` fails because `line_count()` returns `2`
**Root cause:** The v0.3.0 changelog explicitly states: "`Cart.line_count()` now returns the number of lines, not the total quantity across lines. Tests should be updated where they relied on the old behavior." The test was never updated.
**Fix:** Updated the test to expect `2` (number of lines) instead of `5` (total quantity).
**Decision:** Fix the test, not the code. The changelog documents this as an intentional API change, and the code correctly implements the new behavior.

### Issue 4: Ruff import sorting and modern typing (I001, UP006, UP035, UP045)

**Files:** `src/discountkit/__init__.py`, `src/discountkit/cart.py`, `tests/test_discount.py`
**Error:** Import blocks unsorted; deprecated `typing.List` and `Optional` usage.
**Fix:** Applied `ruff check --fix` to auto-fix all of these.
**Decision:** These are style/modernization issues that ruff's config explicitly selects for (select = ["E", "F", "I", "B", "UP"]).
