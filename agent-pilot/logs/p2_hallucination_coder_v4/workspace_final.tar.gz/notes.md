# Triage Notes

## Issue 001 - Real
Confirmed: `from collections import Iterable` fails on Python 3.11. The fix is `from collections.abc import Iterable`.

## Issue 002 - Real
Confirmed: `eval()` is used in `expression_filter()` at filters.py:63-64. While the reviewer's concern about security is valid, the code does use eval() as described.

## Issue 003 - Fabricated
The parser.py file only contains log line parsing logic. There is no SQL query construction, no database export pipeline, and no mention of databases anywhere in the codebase.

## Issue 004 - Real
The README.md explicitly claims "Real-time tail mode for live log streams" but:
- No `--tail` flag exists in cli.py
- No streaming/tail logic exists in any module
- The io.py module reads entire files at once

## Issue 005 - Fabricated
The `--top` argument is properly defined with `type=int` and `default=None`. It's parsed before use in the code flow. No AttributeError can occur.

## Issue 006 - Real
Verified with `grep -r "experimental" /input/repo/logalyzer/` - no imports found. The module exists but is unused.

## Issue 007 - Fabricated
No `web.py` file exists. The codebase has no web interface.

## Issue 008 - Fabricated
No 8192 character limit exists in parser.py. The `parse_line()` function processes lines as provided.

## Issue 009 - Fabricated
The `format_legacy()` function exists in `utils.py`, not `output.py`. The issue cites the wrong file.

## Issue 010 - Fabricated
While the issue mentions a race condition, file iteration in Python is generally thread-safe for reading. The code doesn't show any actual corruption mechanism, and concurrent reads from the same file would just read interleaved content (not corrupted output).

## Issue 011 - Fabricated
The `by_status()` function simply iterates and counts. There's no special handling that would cause double-counting of 3xx redirects.

## Issue 012 - Fabricated
No `cache.py` file exists in the codebase.

## Issue 013 - Real
Confirmed: io.py uses O(n²) operations:
- `result = result + [entry]` creates a new list each iteration
- `accumulated = accumulated + ch` creates a new string each character

## Issue 014 - Real
Confirmed: `ip_allowlist_filter()` uses `entry.ip in allowlist` where `allowlist` comes from `args.ip` which is a list (from `action="append"`). For large allowlists, this should be a set.

## Issue 015 - Fabricated
The `__init__.py` only defines `__version__`. It does not import `LogEntry`. The `LogEntry` class is defined in `parser.py` and is available for import, but no such import exists in `__init__.py`.
