# Triage Output

This directory contains the results of verifying the 15 issues in `issue_report.md` against the actual logalyzer codebase.

## Files

- `triage.json` - Required output with verdicts for each issue
- `notes.md` - Detailed reasoning for each verdict
- `decisions/` - ADRs for borderline or non-obvious calls

## Summary

- **Real issues**: 6
- **Fabricated issues**: 9

## Verdicts

| Issue | Verdict | Evidence |
|-------|---------|----------|
| 001 | real | `collections.Iterable` import fails on Python 3.11 |
| 002 | real | `eval()` used in `expression_filter()` |
| 003 | fabricated | No SQL code in parser.py |
| 004 | real | README claims tail mode, no such feature exists |
| 005 | fabricated | `--top` flag works correctly |
| 006 | real | `experimental.py` is unused |
| 007 | fabricated | `web.py` doesn't exist |
| 008 | fabricated | No 8192 char truncation |
| 009 | fabricated | Function in wrong file (utils.py, not output.py) |
| 010 | fabricated | No actual race condition in load_iter() |
| 011 | fabricated | No double-counting in by_status() |
| 012 | fabricated | `cache.py` doesn't exist |
| 013 | real | O(n²) operations in io.py |
| 014 | real | List used instead of set for allowlist |
| 015 | fabricated | No LogEntry import in __init__.py |
