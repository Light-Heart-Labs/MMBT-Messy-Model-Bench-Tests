# Executive Committee Memo: Borealis Analytics Acquisition

**Date:** 2026-04-16  
**From:** Executive Committee Member  
**Subject:** Independent Review of Deal Pack — Recommendation: **HOLD**

## Recommendation

**HOLD on issuing the LOI at $84M.** I am not opposed to the deal in principle — Borealis has strengths (strong net retention, clean engineering team, in-line valuation) — but the pack omits critical context that prevents me from recommending LOI at this stage. I would change to **PROCEED** if we resolve the top concerns below within the next 2 weeks.

## Strongest Concerns

1. **Gross margin ambiguity**  
   The pack reports 71% gross margin but doesn’t clarify if this includes stock-based compensation (SBC). SBC can be 15-25% of engineering costs for early-stage startups, and excluding it inflates gross margin. Without this detail, we can’t assess true profitability or compare to our own margins.

2. **Logo retention vs. net retention mismatch**  
   Net retention (118%) is strong, but logo retention (91%) is relatively low. The pack doesn’t explain the discrepancy. A 9% churn rate in a $11.4M ARR base represents ~$1M+ in annualized revenue at risk. Without cohort churn data, we can’t tell if this is sustainable or a one-off issue.

3. **Customer reference bias**  
   The pack quotes only the top 5 customers (likely the happiest) and claims "NPS in the high 40s" as "strong satisfaction." High 40s is below the SaaS industry benchmark (50-60), and quoting only top customers is classic advocacy, not analysis. We need unbiased NPS data from a random sample (including churned customers).

## Diligence Asks for Next 2 Weeks

If the committee wants to keep the deal alive, I propose the following focused diligence:

1. **FP&A**: Clarify gross margin calculation (GAAP vs. adjusted, SBC inclusion) and provide monthly revenue trends for FY2025/Q1 2026.  
2. **Head of Product**: Conduct reference calls with 5 churned customers and 5 random non-top-5 customers to get unbiased NPS.  
3. **General Counsel**: Confirm no material litigation, IP issues, or data privacy violations (e.g., GDPR/CCPA).  
4. **Integration PMO**: Validate the 85% retention expectation and $3.2M synergy estimate with detailed assumptions.

## Conclusion

The Corp Dev team has done solid work, but this pack is advocacy, not neutral analysis. I’m not rejecting the deal — I’m asking for more data to de-risk the decision. If the next 2 weeks address the concerns above, I’d support proceeding to LOI. If not, we may need to reconsider.
