# Borealis Analytics Acquisition Review

## Overview

This repository contains the executive committee review of the Borealis Analytics acquisition deal pack, prepared by an independent executive committee member.

## Files

| File | Purpose |
|---|---|
| `memo.md` | The 1-page memo with recommendation, concerns, and asks |
| `concerns.md` | A longer enumeration of every concern considered |
| `asks.md` | The diligence-ask list for the next 2 weeks |
| `decisions/` | ADRs for judgment calls (tone, ranking, recommendation) |
| `README.md` | This file |

## How to Use

1. Start with `memo.md` for the executive summary.
2. Review `concerns.md` for a deeper dive into the issues.
3. Use `asks.md` as a checklist for the next 2 weeks of diligence.
4. Check `decisions/` for the rationale behind key judgment calls.

## Timeline

- **Deal pack received**: 2026-04-15
- **Memo due**: 2026-04-16
- **LOI decision deadline**: 2026-04-30

## Next Steps

1. Share memo with executive committee.
2. Assign diligence asks to Corp Dev, FP&A, Eng, Legal.
3. Schedule follow-up meeting in 2 weeks to review new data.
