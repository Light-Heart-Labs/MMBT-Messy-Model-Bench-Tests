# Diligence Asks for Borealis Analytics — Next 2 Weeks

## 1. Financial Deep Dive (Owner: FP&A Lead, Deadline: 2026-04-25)

- [ ] **Monthly revenue trend**: Provide monthly revenue for FY2025 and Q1 2026 to assess growth trajectory and seasonality.
- [ ] **Gross margin reconciliation**: Break down gross margin calculation, including SBC allocation. Is 71% GAAP gross margin or adjusted?
- [ ] **CAC and LTV**: Provide customer acquisition cost (CAC) by channel, payback period, and LTV:CAC ratio.
- [ ] **Churn analysis**: Provide cohort churn analysis (by customer segment, ARR tier) to understand logo retention drivers.
- [ ] **Contract terms**: Provide sample customer contracts (redacted) to review change-of-control, termination, and renewal terms.

## 2. Customer & Market Validation (Owner: Head of Product, Deadline: 2026-04-25)

- [ ] **Random sample NPS**: Conduct reference calls with 5 churned customers and 5 random non-top-5 customers to get unbiased NPS.
- [ ] **Competitive displacement**: For each of the top 10 customers, document why they chose Borealis over alternatives (e.g., Hexa, Aspen, in-house).
- [ ] **Integration readiness survey**: Survey Borealis customers on willingness to migrate to our platform, expected timeline, and potential blockers.

## 3. Engineering & Product Assessment (Owner: VP Eng, Deadline: 2026-04-25)

- [ ] **Codebase audit**: Provide test coverage %, CI/CD pipeline status, and security scan results (SAST/DAST).
- [ ] **Tech debt inventory**: List top 5 tech debt items with estimated remediation effort and business impact.
- [ ] **CTO track record**: Verify CTO Sarah Lin's role, tenure, and outcomes at Snowflake/Looker (e.g., team size, product launches).

## 4. Legal & Compliance (Owner: General Counsel, Deadline: 2026-04-25)

- [ ] **IP ownership**: Confirm Borealis owns all IP, including open-source contributions and third-party integrations.
- [ ] **Data privacy**: Provide SOC 2 report, GDPR/CCPA compliance documentation, and any past security incidents.
- [ ] **Litigation risk**: Confirm no pending or threatened litigation (customer, employee, or partner).

## 5. Integration & Synergy Validation (Owner: Integration PMO, Deadline: 2026-04-25)

- [ ] **Retention plan**: Provide detailed retention plan for Borealis employees, including retention bonuses, role mapping, and cultural integration.
- [ ] **Synergy breakdown**: Provide detailed $3.2M synergy estimate with assumptions (e.g., infrastructure consolidation, headcount reduction).
- [ ] **Migration plan**: Provide customer migration plan with milestones, rollback strategy, and fallback if 12-month sunset is missed.

## 6. Independent Valuation Review (Owner: CFO, Deadline: 2026-04-28)

- [ ] **Discounted cash flow (DCF) model**: Build a DCF model with base, upside, and downside scenarios based on growth, margin, and synergy assumptions.
- [ ] **Sensitivity analysis**: Test valuation sensitivity to key variables (e.g., ARR growth, gross margin, integration timeline).
- [ ] **Alternative acquirer benchmark**: Estimate what a financial acquirer might pay vs. a strategic acquirer.

## 7. Executive Committee Decision Input (Owner: Corp Dev, Deadline: 2026-04-28)

- [ ] **Strategic fit workshop**: Schedule a 90-minute session with executive committee to pressure-test strategic rationale (e.g., "Why Borealis over building in-house?").
- [ ] **Risk register**: Provide a risk register with mitigation plans for top 10 deal risks (e.g., customer churn, integration failure, talent attrition).
- [ ] **LOI terms draft**: Draft LOI terms (e.g., earnout, working capital, reps & warranties) for committee review.
