# Concerns with the Borealis Acquisition Deal Pack

## 1. Overstated Strategic Rationale

- **Feature overlap claim**: The pack states "minimal overlap (~12%)" but provides no methodology. Without knowing how overlap was measured (e.g., feature flags vs. use cases vs. technical architecture), this claim is advocacy, not analysis. A 12% overlap could still mean significant customer confusion or internal complexity.
- **Mid-market e-commerce claim**: The pack says we "currently service only via partner integrations" but doesn't specify what those are, their performance, or whether they're strategic or tactical. If our partner integrations are weak or underperforming, Borealis may not be the right solution.

## 2. Financials — Omitted Context

- **Growth sustainability**: 80% YoY revenue growth is impressive, but the pack doesn't disclose whether this is sustainable or if growth is decelerating. We need to see monthly/quarterly revenue trends, not just FY2024 vs FY2025.
- **Gross margin definition**: The pack says "71% gross margin" but doesn't clarify if this includes stock-based compensation (SBC) or not. SBC can be 15-25% of engineering costs for early-stage startups, and excluding it inflates gross margin.
- **Net retention vs. Logo retention mismatch**: Net retention (118%) is strong, but logo retention (91%) is relatively low. The pack doesn't explain the discrepancy. A 9% churn rate in a $11.4M ARR base represents ~$1M+ in annualized revenue at risk.
- **Runway and burn**: The pack says "22 months runway at last cap raise" but doesn't disclose the size of the raise, the valuation, or whether there's a down-round risk. If they raised at a high valuation and growth is slowing, they may be in trouble.

## 3. Customer Testimonials — Selection Bias

- **Top 5 customers only**: The pack only quotes the top 5 customers (by revenue, presumably). This is a classic selection bias — it's easy to find happy customers if you only ask the ones most likely to be satisfied. We need to know the overall NPS, not just the top 5's NPS.
- **No churned customers**: No mention of why customers churned or what alternatives they chose. Without understanding churn drivers, we can't assess whether our integration will fix or exacerbate the problem.
- **"NPS in the high 40s"**: High 40s is not "strong satisfaction" — it's below the industry benchmark for SaaS (typically 50-60). This is a stretch to call "strong."

## 4. Product & Team — Unverified Claims

- **"No critical attrition"**: The pack says there's been "no critical attrition" in the last 12 months, but doesn't define "critical" or provide turnover rates. A 10% turnover rate is normal; a 20%+ rate is concerning. We need the actual number.
- **CTO's track record**: The pack praises CTO Sarah Lin's "prior experience at Snowflake and Looker" but doesn't disclose her role, tenure, or whether she's proven at scaling engineering teams through acquisitions.
- **Tech debt assessment**: The pack says the codebase is "clean, well-tested" but provides no evidence (e.g., test coverage %, code review frequency, CI/CD maturity). This is engineering theater without data.

## 5. Comparable Transactions — Flawed Benchmarking

- **ARR multiples**: The pack compares Borealis at 7.4x ARR to comps at 7-12x, but doesn't adjust for growth rate, margin, or integration complexity. If Hexa, Aspen, and Trellis had higher growth or better margins, the comparison is invalid.
- **Acquirer context**: The pack doesn't disclose whether the comps were strategic vs. financial acquirers. Strategic acquirers (like Salesforce, Snowflake) pay premiums that may not apply to us.

## 6. Integration Plan — Overly Optimistic

- **85% retention expectation**: The pack says "85% retention expected" but doesn't disclose how this was estimated. Is this based on historical integration data? If so, what was the sample size and context?
- **Synergy estimate**: "$3.2M annual cost savings" is a bold claim without breakdown. How much is infrastructure vs. headcount vs. overhead? Are these savings achievable in year 1 or year 3?
- **Aurora sunset**: A 12-month sunset timeline is aggressive for a $11.4M ARR product with 280 customers. What happens if migration stalls? What's the fallback?

## 7. Missing Key Diligence Areas

- **Legal/contractual**: No mention of customer contract terms (e.g., change of control clauses, termination rights), IP ownership, or litigation risk.
- **Data privacy**: No mention of GDPR/CCPA compliance, data handling practices, or past security incidents.
- **Sales process**: How did Borealis acquire customers? What's the CAC vs. LTV? Without this, we can't assess the sustainability of their growth.

## 8. Deal Pack Bias

- **Advocacy tone**: The pack uses phrases like "strongest tuck-in we've seen this year" and "clean financials" — language that's appropriate for a recommendation memo, not a neutral diligence report.
- **Signed off by**: The pack is signed off by VP Corp Dev, VP Eng, and CFO — all internal stakeholders with incentives to close deals. There's no independent review (e.g., from Legal, Security, or a third-party expert).
