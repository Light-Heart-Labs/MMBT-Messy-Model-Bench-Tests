# Key Facts — Nimbus Logistics, Inc.

## Financial Metrics

- **Series B financing**: $84M, led by Lightning Capital, with participation from Sequoia Capital, Accel, and FedEx Ventures [Source 1, Source 5]
- **Post-money valuation**: $560M [Source 1]
- **Previous valuation (Series A)**: $230M [Source 1]
- **Total funding to date**: $128M [Source 1]
- **Reported ARR (Q4 2025)**: $42M [Source 1]
- **Adjusted ARR (after December 2025 churn)**: $36-37M [Source 2]
- **Revenue (mid-2025)**: ~$3.5M/month [Source 3]
- **Burn rate (mid-2025)**: ~$4M/month all-in [Source 3]
- **New $50M credit facility**: Secured from Silicon Valley Bridge [Source 4]

## Customer Metrics

- **Reported customers**: 1,400 e-commerce brands [Source 1]
- **Top 5 customers**: ~38% of ARR [Source 3]
- **Lost customers in late 2025**:
  - Sundry Brands ($4.2M ARR) — non-renewed in November [Source 2]
  - Klatch (fast-fashion) — exited in December [Source 2]
- **Nimbus Lite tier customers**: ~310, mostly $5K-$20K ARR each [Source 4]

## Operational Metrics

- **Employees**: 187 (as of press release) [Source 1]
- **Layoffs in Feb 2025**: 22 people (~11% of org), mostly customer success and BD [Source 3]
- **Berlin office**: Reduced from 41 to ~28-30 by end of Q2 2026 [Source 4]
- **Offices**: Oakland, Austin, Berlin [Source 1]

## Timeline

- **Founded**: 2021 by Mira Patel and Daniel Wong [Source 1]
- **Series A**: 2023 [Source 1]
- **Series B close date**: 2026-01-14 [Source 1, Source 5]
- **SEC Form D filing**: 2026-01-22 [Source 5]
- **Internal memo date**: 2026-02-28 [Source 4]
- **TechCrunch article date**: 2026-01-15 [Source 2]
- **Former employee blog post date**: 2026-02-22 [Source 3]

## Valuation Context

- **Series B intended valuation (before repricing)**: $720M [Source 2]
- **Series B repriced after Sundry non-renewal** [Source 2]

## Runway and Strategy

- **Runway after Series B**: 24+ months at current burn [Source 4]
- **Extended runway after cost cuts**: 36+ months [Source 4]
- **Target**: Cash-flow breakeven by Q4 2026 [Source 4]
- **International expansion**: Deferred to 2027 at earliest [Source 4]

## Source Quality Notes

- **Press release (Source 1)**: Company-issued, optimistic, omits negatives
- **TechCrunch (Source 2)**: Independent reporting, contradicts company narrative on key points
- **Former employee blog (Source 3)**: Subjective but likely accurate on internal facts
- **Internal memo (Source 4)**: Most candid about challenges, but written by CEO to justify actions
- **SEC Form D (Source 5)**: Factual but minimal detail
