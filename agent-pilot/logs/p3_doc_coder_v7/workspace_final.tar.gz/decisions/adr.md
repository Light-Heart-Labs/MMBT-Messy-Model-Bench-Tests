# ADR — Executive Brief Framing for Nimbus Logistics, Inc.

## Decision: Recommend *Pass* on follow-on investment

### Rationale

The executive brief must be a clear recommendation, not a hedge. After weighing all five sources, the evidence points to a company in damage-control mode, not growth mode. The $84M Series B was not a clean growth round but a repriced, defensive raise to extend runway after significant customer churn and internal restructuring.

### Key framing choices

1. **Lead with the adjusted ARR, not the headline $42M**
   - Press release cites $42M ARR, but TechCrunch (with two financial sources) adjusts for December churn to $36-37M.
   - Former employee confirms revenue ~$3.5M/month, which equals $42M, but that was mid-2025 — before the December churn.
   - The internal memo's cost-cutting plan assumes a weaker base (36-37M run-rate), not $42M.
   - Using $36-37M as the baseline is more honest and reflects the actual run-rate at the time of the fundraise repricing.

2. **Valuation context matters**
   - Press release says "more than doubling" from $230M to $560M.
   - TechCrunch reveals the round was originally intended to close at $720M and was repriced down after Sundry non-renewal.
   - The $560M valuation is therefore not a 2x, but a 2.4x from $230M to $560M, or effectively a 1.6x from the intended $720M repricing point.
   - This suggests the market (via Lightning Capital) was less enthusiastic than the company's initial pitch.

3. **Customer concentration is a material risk**
   - Former employee states top 5 customers = ~38% of ARR.
   - TechCrunch confirms two of those five were lost in late 2025.
   - The internal memo's plan to sunset the lowest tier (310 customers) suggests a strategic shift away from broad-based growth toward a narrower, higher-value segment — but this also increases concentration risk if the top customers churn.

4. **The $50M credit facility is a red flag, not a safety net**
   - Internal memo describes it as "insurance, not operating capital."
   - This implies the $84M Series B is already committed to existing operations, and the credit facility is a contingency.
   - It also suggests the company may be in a weaker negotiating position (needing credit rather than equity).

5. **Recommendation must be conditional**
   - The brief should state: "Pass on the follow-on at current terms, but reconsider if the following conditions are met:"
     - Management provides credible evidence of stabilized churn (e.g., net retention >100% for two consecutive quarters)
     - The $36-37M run-rate ARR is confirmed as stable (not declining further)
     - The cost cuts (especially Berlin reduction and Lite tier sunset) are executed without further customer attrition

### Why not "More diligence needed"?

"More diligence needed" is a cop-out for a 5-minute partner brief. The sources provide enough information to form a clear stance. The burden is on the company to prove the narrative is stronger than the evidence suggests — and the internal memo and TechCrunch reporting show the narrative is already being revised downward.

### Tone calibration

- Avoid language like "allegedly" or "according to some sources" for well-corroborated facts (e.g., Sundry non-renewal, ARR adjustment, layoff in Feb 2025).
- Use "according to" for subjective claims (e.g., "customer love is real" per former employee blog).
- Cite sources inline for every specific number or claim.
