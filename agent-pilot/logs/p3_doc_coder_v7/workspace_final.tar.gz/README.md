# Nimbus Logistics, Inc. — Deal Evaluation Package

## Files

| File | Purpose |
|------|---------|
| `brief.md` | **Primary deliverable**: 1-page executive brief with clear recommendation (PASS) |
| `key-facts.md` | List of every material fact, with source attribution |
| `research/notes.md` | Working notes from reading all five sources |
| `decisions/adr.md` | ADR-style record of framing choices (why PASS, not "more diligence needed") |
| `README.md` | This file |

## How to Read This Package

1. **Start with `brief.md`** — the 1-page executive brief. This is the deliverable for the investor partner.
2. **Check `key-facts.md`** — verify that every number and claim in the brief is sourced.
3. **Review `research/notes.md`** — see how the analysis unfolded, including tensions between sources.
4. **Read `decisions/adr.md`** — understand the framing choices (e.g., why PASS, not hedging).

## Source Attribution

- **Source 1**: Company press release (optimistic, omits negatives)
- **Source 2**: TechCrunch article (independent, contradicts company narrative)
- **Source 3**: Former employee blog post (subjective but likely accurate on internal facts)
- **Source 4**: Leaked internal memo (most candid about challenges)
- **Source 5**: SEC Form D filing (factual but minimal detail)

## Recommendation

**PASS** on the follow-on investment at current terms. The $560M valuation implies growth momentum that no longer exists—ARR is $36–37M, not $42M, and churn is ongoing. The cost cuts are necessary but not sufficient to restore confidence without evidence of stabilized retention.

Upside triggers for reconsideration:
- Net retention >100% for two consecutive quarters
- Stable $36–37M run-rate ARR (no further decline)
- No further customer attrition from cost-cutting actions
