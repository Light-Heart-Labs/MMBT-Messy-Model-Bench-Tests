# Working Notes — Nimbus Logistics, Inc. Source Analysis

## Source-by-source summary

### SOURCE 1 — Press Release (company-issued)
- Series B: $84M, led by Lightning Capital, with participation from Sequoia, Accel, FedEx Ventures
- Post-money valuation: $560M (up from $230M in Series A)
- Total funding to date: $128M
- ARR: $42M as of Q4 2025 (up from $11M a year prior)
- 1,400 customers, 187 employees (Oakland, Austin, Berlin)
- Founded 2021 by Mira Patel and Daniel Wong (CTO)
- Customers: Maevia, Truant Coffee, Brick & Cobble

### SOURCE 2 — TechCrunch News Article
- Lost two top-5 customers in late 2025:
  - Sundry Brands ($4.2M ARR) — non-renewed in November
  - Klatch (fast-fashion) — exited in December
- Company confirmed Sundry but called it "strategic mutual decision"
- Adjusted ARR after December churn: $36-37M (per TechCrunch source)
- CEO claims 3 new $1M+ ARR contracts signed in Q1 2026
- Claims net retention >110% across 1,400 customers
- Series B originally intended to close at $720M valuation in late 2025, repriced down after Sundry non-renewal

### SOURCE 3 — Former Employee Blog Post
- Engineering quality is high; CTO Daniel Wong is "the real deal"
- Customer love is real; mid-market brands truly depend on platform
- Compensation competitive: senior engineer $215K base + $50K equity
- Burn rate ~$4M/month all-in vs ~$3.5M/month revenue (mid-2025)
- Layoffs in Feb 2025: 22 people (~11% of org), mostly customer success & BD
- Top 5 customers = ~38% of ARR (widely known internally)
- Path to survival requires faster growth or significant cuts
- Recommend for senior engineers, not for those needing job security in next 18 months

### SOURCE 4 — Internal Memo (leaked)
- CEO memo dated Feb 28, 2026: "Path to Profitability"
- 30% reduction in international headcount (Berlin: 41 → 28-30 by end Q2)
- Pause new hires in EMEA; Berlin repositioned as "support hub"
- Sunset "Nimbus Lite" tier (~310 customers, $5K-$20K ARR each)
- New $50M credit facility from Silicon Valley Bridge
- Runway extended from 24+ months to 36+ months
- Target: cash-flow breakeven by Q4 2026, then Series C from strength

### SOURCE 5 — SEC Form D
- Filing date: 2026-01-22
- Total offering: $84M
- 7 investors
- First sale: 2026-01-14
- Security: Series B Preferred
- Use of proceeds: "expansion, working capital, general corporate purposes"

## Key tensions and contradictions

1. ARR figure:
   - Press release: $42M
   - TechCrunch (adjusted for December churn): $36-37M
   - Former employee: revenue ~$3.5M/month → $42M ARR (matches press release)
   - Internal memo: implies need for cuts suggests underlying weakness

2. Valuation:
   - Press release: $560M (more than double $230M)
   - TechCrunch: Series B meant to close at $720M, repriced down after Sundry non-renewal

3. Customer concentration:
   - Press release: 1,400 customers, no mention of concentration
   - TechCrunch: lost two top-5 customers
   - Former employee: top 5 = ~38% of ARR
   - Internal memo: sunset lowest tier (310 customers) — may indicate strategic shift

4. Burn and runway:
   - Former employee: $4M/month burn vs $3.5M revenue → negative cash flow
   - Internal memo: Series B gave 24+ months runway; new $50M credit extends to 36+ months

5. Layoffs:
   - Press release: 187 employees (no mention of layoffs)
   - Former employee: 22 layoffs in Feb 2025 (~11% of org)
   - Internal memo: further 30% international headcount reduction planned

6. International expansion:
   - Press release: "accelerate our expansion into international markets"
   - Internal memo: pause EMEA hiring, reduce Berlin from 41 to ~28-30, reframe as support hub, defer international expansion to 2027

## Source quality assessment

- Press release: company narrative, optimistic, omits negatives
- TechCrunch: independent reporting, contradicts company narrative on key points (churn, repricing)
- Former employee: subjective but likely accurate on internal facts (burn, layoffs, customer concentration)
- Internal memo: most candid about challenges, but written by CEO to justify actions
- SEC Form D: factual but minimal detail

## Initial recommendation framework

The company is:
- Technically capable (good engineering, strong product)
- Facing real customer concentration and churn issues
- Burning cash and needing to cut costs to extend runway
- Attempting to pivot from international expansion to U.S. mid-market focus

Investor decision hinges on:
- Belief in management's ability to execute cost cuts and stabilize churn
- Confidence that $36-37M run-rate ARR (not $42M) is sustainable
- Assessment of whether $560M valuation is justified given reality
