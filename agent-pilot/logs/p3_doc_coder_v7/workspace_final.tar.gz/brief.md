# Executive Brief: Nimbus Logistics, Inc. — Follow-on Investment Recommendation

**Date**: 2026-04-01  
**Recommendation**: **PASS** on the follow-on investment at current terms.

---

## Summary

Nimbus Logistics raised $84M at a $560M valuation in January 2026, but the round was repriced down from a $720M target after losing two top-5 customers (including its largest, Sundry Brands at $4.2M ARR) in late 2025 [Source 2]. Adjusted for that December churn, current run-rate ARR is $36–37M—not the headline $42M—and the company is burning cash ($4M/month vs. $3.5M revenue) [Source 3]. Internal restructuring (30% Berlin headcount cut, sunset of the $5K–$20K “Lite” tier for 310 customers) and a new $50M credit facility extend runway to 36+ months, targeting cash-flow breakeven by Q4 2026 [Source 4].

The company has strong engineering and product (CTO Daniel Wong is technically adept, customers are “genuinely dependent” on the platform) [Source 3], but customer concentration remains a material risk: the top 5 customers represent ~38% of ARR, and two of those five were lost in late 2025 [Source 2, Source 3]. The internal memo confirms the company is in damage-control mode, not growth mode.

**Recommendation**: **Pass**. The $560M valuation implies growth momentum that no longer exists—ARR is $36–37M, not $42M, and churn is ongoing. The cost cuts are necessary but not sufficient to restore confidence without evidence of stabilized retention.

---

## Key Facts

- **ARR**: $42M reported (press release), but $36–37M adjusted for December 2025 churn [Source 1, Source 2]
- **Valuation**: $560M post-money, down from $720M intended [Source 1, Source 2]
- **Customer churn**: Lost Sundry ($4.2M ARR) and Klatch in late 2025; top 5 customers = ~38% of ARR [Source 2, Source 3]
- **Burn**: $4M/month all-in vs. $3.5M revenue → negative cash flow [Source 3]
- **Cost cuts**: 30% Berlin headcount reduction (41 → ~28–30), sunset of Lite tier (310 customers) [Source 4]
- **Runway**: Extended to 36+ months via $50M credit facility, targeting cash-flow breakeven by Q4 2026 [Source 4]

---

## Risks

1. **Customer concentration**: Top 5 = ~38% of ARR; losing two of five in one quarter is a red flag [Source 2, Source 3]
2. **Valuation misalignment**: $560M implies growth, but the round was repriced down and the company is cutting costs to survive [Source 2, Source 4]
3. **Cash flow**: Negative cash flow ($4M burn vs. $3.5M revenue) requires constant fundraising [Source 3]
4. **Execution risk**: Cost cuts (Berlin, Lite tier) could trigger further customer attrition if not executed flawlessly [Source 4]

---

## Upside Triggers (Reconsider if Met)

1. **Net retention >100% for two consecutive quarters** (currently claimed at >110%, but unverified post-churn) [Source 2]
2. **Stable $36–37M run-rate ARR** (no further decline after Lite tier sunset and Berlin cuts)
3. **No further customer attrition** from cost-cutting actions (e.g., Lite tier customers not lost to competitors)

---

## Bottom Line

Nimbus is technically capable but operationally fragile. The $84M Series B was a defensive raise, not a growth round. At $560M, the valuation assumes a $42M ARR base with strong growth—yet the actual run-rate is $36–37M and the company is cutting costs to extend runway. Without evidence of stabilized retention, the risk of further down-round dilution is high.

**Recommendation**: **Pass**. Reconsider only if management provides credible evidence of net retention >100% for two consecutive quarters and stable run-rate ARR.
