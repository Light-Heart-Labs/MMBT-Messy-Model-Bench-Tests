# Diagnosis

## Failure 1: ruff F401 — unused `import json` in `cart.py`

**What was wrong:** `cart.py` had `import json` on line 4, but `json` was never
used anywhere in the file. The comment `# PLANTED BUG #3` confirms this was
intentionally inserted to break CI.

**Fix:** Removed the unused import.

**Why code fix (not test):** This is a lint issue in the source code, not a
test issue.

---

## Failure 2: `test_discount_amount` — `assert 2000.0 == 20.0`

**What was wrong:** `discount_amount(100.0, 20.0)` returned 2000.0 instead of
20.0. The function body was `return round(price * percent_off, 2)` but should
be `return round(price * percent_off / 100, 2)`. The v0.3.0 changelog says the
API changed from fraction (0.0-1.0) to percent (0-100), but the implementation
was never updated to divide by 100.

**Fix:** Changed `price * percent_off` to `price * percent_off / 100` in
`discount.py`.

**Why code fix (not test):** The changelog documents the intended API
(percent-based), and the docstring examples confirm `discount_amount(100.0,
20.0) -> 20.0`. The tests were correct; the implementation was wrong.

---

## Failure 3: `test_apply_discount` — `assert -1900.0 == 80.0`

**What was wrong:** `apply_discount(100.0, 20.0)` returned -1900.0. This is a
cascading failure from the `discount_amount` bug above: `apply_discount` calls
`discount_amount`, which returned 2000.0 instead of 20.0, so the result was
`100.0 - 2000.0 = -1900.0`.

**Fix:** Fixed by the same change to `discount_amount` (dividing by 100).

---

## Failure 4: `test_line_count_matches_qty_sum` — `assert 2 == 5`

**What was wrong:** The test expected `line_count()` to return 5 (total quantity
across lines), but the code returns 2 (number of lines). The v0.3.0 changelog
explicitly states: "`Cart.line_count()` now returns the number of lines, not the
total quantity across lines. Tests should be updated where they relied on the
old behavior."

**Fix:** Updated the test to assert `c.line_count() == 2` and updated the
docstring comment to reflect the new behavior.

**Why test fix (not code):** The changelog documents this as an intentional API
change in v0.3.0. The code correctly implements the documented behavior. The
test was simply not updated when the API changed.

---

## Additional ruff lint issues (I001, UP006, UP035, UP045)

After fixing the F401, running `ruff check` revealed additional issues:
- **I001**: Import blocks not sorted (alphabetical order)
- **UP006/UP035**: `typing.List` deprecated, use builtin `list`
- **UP045**: `Optional[float]` should be `float | None`

All fixed by reorganizing imports and using modern Python 3.10+ type syntax.
