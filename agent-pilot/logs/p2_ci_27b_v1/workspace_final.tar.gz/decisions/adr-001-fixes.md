# ADR-001: Fix `discount_amount` implementation, not tests

**Status:** Accepted

**Context:** The v0.3.0 changelog documents a breaking change: `discount_amount()`
and `apply_discount()` now take percent (0-100) instead of fraction (0.0-1.0).
However, the implementation was never updated — it still multiplies directly
without dividing by 100.

**Decision:** Fix the implementation in `discount.py` by adding `/ 100` to the
calculation. Do not change the tests.

**Rationale:**
- The docstring examples (`discount_amount(100.0, 20.0) -> 20.0`) confirm the
  intended behavior.
- The changelog documents the API contract (percent-based).
- The tests correctly assert the documented behavior.
- The implementation was simply incomplete after the v0.3.0 API migration.

---

# ADR-002: Fix `test_line_count` test, not implementation

**Status:** Accepted

**Context:** `Cart.line_count()` returns `len(self.lines)` (number of lines).
The test `test_line_count_matches_qty_sum` asserts it should return the total
quantity (5). The v0.3.0 changelog explicitly states this was an intentional
API change.

**Decision:** Update the test to match the documented v0.3.0 behavior. Do not
change the implementation.

**Rationale:**
- The changelog for v0.3.0 says: "`Cart.line_count()` now returns the number of
  lines, not the total quantity across lines. Tests should be updated where they
  relied on the old behavior."
- The code correctly implements the documented API.
- The test was simply not updated during the v0.3.0 release.
