# Changelog

## v0.3.2 (2025-04-28)

**Bug fixes:**

- **`discount_amount()` now correctly divides by 100.** The v0.3.0 migration to
  percent-based API (0-100 instead of 0.0-1.0) was incomplete — the function
  accepted percent values but multiplied directly without dividing by 100,
  producing results 100× too large. Fixed `price * percent_off` →
  `price * percent_off / 100`.
- **Removed unused `import json` from `cart.py`.** This was a planted bug that
  triggered ruff F401 (unused import).
- **Updated `test_line_count_matches_qty_sum` to match v0.3.0 API.** The
  changelog for v0.3.0 documented that `Cart.line_count()` was changed from
  returning total quantity to returning the number of lines. The test was not
  updated at the time of the v0.3.0 release and still asserted the old behavior.
  Fixed the test to assert `line_count() == 2` (two lines) instead of
  `line_count() == 5` (total quantity).
- **Fixed ruff lint issues (I001, UP006, UP035, UP045).** Sorted import blocks,
  replaced deprecated `typing.List` with builtin `list`, replaced
  `Optional[float]` with `float | None`, and removed unused `Optional` import.

**Verification:**

- `ruff check src/ tests/` → 0 errors
- `pytest -q` → 7 passed, 0 failed

## v0.3.1 (current — CI red)

CI is failing on this version. See `ci_failure.log` for the full output.

## v0.3.0

- **BREAKING**: `discount_amount()` and `apply_discount()` now take percent (0-100)
  instead of fraction (0.0-1.0). Update callers from `apply_discount(p, 0.2)` to
  `apply_discount(p, 20.0)`.
- `Cart.line_count()` now returns the number of lines, not the total quantity
  across lines. Tests should be updated where they relied on the old behavior.

## v0.2.0

- Added `Cart.set_discount()` for cart-wide discounts.
- `Cart.line_count()` returns total quantity across lines.

## v0.1.0

- Initial release.
