# ADR-0001: Why Split output.py

## Status

Accepted

## Context

The `logalyzer/output.py` module mixed four distinct concerns:

1. **JSON serialization** (`to_json`) — hand-crafted JSON string building
2. **CSV serialization** (`to_csv`) — uses `csv` stdlib module
3. **Plain-text formatting** (`to_text`) — human-readable line formatting
4. **Aggregate rendering** (`render_aggregate`) — higher-level formatting for aggregation results

Additionally, `format_legacy()` existed in `utils.py` but was conceptually an output concern, and the task required it to be importable from `logalyzer.output`.

This accreted structure made it difficult to:
- Understand which functions belong to which output concern
- Add new output formats without further bloating the module
- Test individual renderers in isolation

## Decision

Split `output.py` into a `logalyzer/output/` package with one module per concern:

| Module | Contents |
|--------|----------|
| `json_renderer.py` | `to_json()` |
| `csv_renderer.py` | `to_csv()` |
| `plain_renderer.py` | `to_text()`, `render_aggregate()` |
| `legacy.py` | `format_legacy()` |
| `__init__.py` | Re-exports all public names |

## Consequences

- **Positive**: Each module has a single, clear responsibility. New output formats can be added as new modules.
- **Positive**: The `__init__.py` re-exports maintain backward compatibility — no call sites need to change.
- **Neutral**: `render_aggregate()` was placed in `plain_renderer.py` because it primarily produces text output (with a JSON fallback). It could have been its own module, but that would add unnecessary granularity for a single function.
- **Neutral**: `format_legacy()` was copied from `utils.py` into `legacy.py` rather than moved, to avoid changing `utils.py` (which is out of scope). The original in `utils.py` remains unchanged.
