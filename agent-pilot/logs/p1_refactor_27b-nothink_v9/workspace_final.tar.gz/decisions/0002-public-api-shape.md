# ADR-0002: Public API Shape

## Status

Accepted

## Context

The `logalyzer/output` package must maintain backward compatibility with all existing import paths. The key question is: what names should be re-exported from `logalyzer/output/__init__.py`?

## Decision

The `__init__.py` re-exports exactly the names that were available from the old `output.py` module, plus `format_legacy` which the task requires to be importable from `logalyzer.output`:

```python
__all__ = [
    "to_json",
    "to_csv",
    "to_text",
    "render_aggregate",
    "format_legacy",
]
```

### Rationale for each export

| Name | Source Module | Reason |
|------|--------------|--------|
| `to_json` | `json_renderer.py` | Used by `cli.py` for `--format json` |
| `to_csv` | `csv_renderer.py` | Used by `cli.py` for `--format csv` |
| `to_text` | `plain_renderer.py` | Used by `cli.py` for default text output |
| `render_aggregate` | `plain_renderer.py` | Used by `cli.py` for aggregate output |
| `format_legacy` | `legacy.py` | Required by task spec; backward compat |

### Why `render_aggregate` is in `plain_renderer.py`

`render_aggregate()` is a higher-level function that formats aggregation results (Counters, dicts, lists). It supports both "text" and "json" output modes. It was placed in `plain_renderer.py` rather than its own module because:

1. It's a single function — a dedicated module would be excessive
2. Its primary mode is text output (the default `fmt="text"`)
3. Its JSON mode is a simple dict-to-string conversion, not the same as `to_json()` which handles `LogEntry` objects

### Why `format_legacy` is in `legacy.py`

The task spec explicitly requires a `legacy.py` module. `format_legacy()` is the only legacy function, so it lives there alone. It was copied from `utils.py` (not moved) to avoid modifying `utils.py`, which is out of scope.

## Consequences

- All existing `from logalyzer.output import X` imports continue to work
- The `__all__` list makes the public API explicit
- Internal modules (`json_renderer`, etc.) are not directly imported by external code
