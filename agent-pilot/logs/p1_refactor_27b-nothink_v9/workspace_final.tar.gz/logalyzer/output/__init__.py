"""Output formatters: JSON, CSV, plain text.

This package replaces the old output.py module. All public names are
re-exported here so that existing import paths continue to work:

    from logalyzer.output import to_json, to_csv, to_text, render_aggregate, format_legacy
"""
from __future__ import annotations

from .json_renderer import to_json
from .csv_renderer import to_csv
from .plain_renderer import render_aggregate, to_text
from .legacy import format_legacy

__all__ = [
    "to_json",
    "to_csv",
    "to_text",
    "render_aggregate",
    "format_legacy",
]
