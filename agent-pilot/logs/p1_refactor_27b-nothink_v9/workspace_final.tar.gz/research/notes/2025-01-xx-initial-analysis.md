# Working Notes

## 2025-01-XX: Initial Analysis

### Current structure of output.py
- `to_json(entries)` — hand-crafted JSON string building for LogEntry list
- `to_csv(entries)` — uses csv.writer for LogEntry list
- `to_text(entries)` — plain text formatting for LogEntry list
- `render_aggregate(agg, fmt)` — formats Counter/dict/list results

### Import analysis
- `cli.py` imports: `render_aggregate, to_csv, to_json, to_text` from `.output`
- No other files import from `output.py`
- `format_legacy` is in `utils.py`, not `output.py` (task description was slightly inaccurate)

### Pre-existing bugs found
1. `filters.py`: `from collections import Iterable` — removed in Python 3.10+
2. `parser.py`: `MONTH_NAMES` list is missing "Jul" (has "Jun" then "Aug")
3. `filters.py`: `status_filter` compares string "404" with int 404 using `==`
4. `filters.py`: `url_regex_filter` uses `rx.match()` which only matches at start of string

### Test results (before and after refactor)
- 14 passing, 3 failing (same in both cases)
- Failures are pre-existing bugs in filters.py and parser.py

### Design decisions
- `render_aggregate` placed in `plain_renderer.py` (primary mode is text)
- `format_legacy` copied from `utils.py` to `legacy.py` (not moved, to avoid changing utils.py)
- `__init__.py` re-exports all public names for backward compatibility
