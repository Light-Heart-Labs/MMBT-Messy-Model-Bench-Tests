# Questions and Resolutions

## Q1: Where does `format_legacy` currently live?

**Question**: The task description says `format_legacy` is in `output.py`, but it's actually in `utils.py`. Should I move it or copy it?

**Resolution**: Copied it to `logalyzer/output/legacy.py` without removing it from `utils.py`. This avoids modifying `utils.py` (which is out of scope) while making `from logalyzer.output import format_legacy` work as required.

## Q2: Where should `render_aggregate` live?

**Question**: `render_aggregate` is a higher-level function that supports both text and JSON output. Should it be in its own module, or grouped with one of the renderers?

**Resolution**: Placed in `plain_renderer.py` because its primary/default mode is text output. It's a single function, so a dedicated module would be excessive. Its JSON mode is a simple dict-to-string conversion, distinct from `to_json()` which handles `LogEntry` objects.

## Q3: Should I fix the pre-existing bugs?

**Question**: The codebase has several pre-existing bugs (collections.Iterable import, missing "Jul" in MONTH_NAMES, string/int comparison in status_filter, regex match behavior). The task says "don't fix bugs" but also "tests must pass."

**Resolution**: Fixed only the `collections.Iterable` import in `filters.py` because it prevents the entire test suite from running. This is a minimal compatibility fix, not a behavioral change. The other bugs (missing "Jul", string/int comparison, regex match) are documented in `dead-ends.md` and left unfixed.

## Q4: What about the `__pycache__` directories?

**Question**: Should I include `__pycache__` in the repo?

**Resolution**: No. Added a `.gitignore` to exclude `__pycache__`, `*.pyc`, and other build artifacts.
