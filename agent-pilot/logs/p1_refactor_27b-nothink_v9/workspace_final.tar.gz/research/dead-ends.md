# Dead Ends

## Pre-existing Bugs (Not Fixed)

### 1. `collections.Iterable` import in `filters.py`

**Bug**: `from collections import Iterable` fails on Python 3.10+ because `Iterable` was moved to `collections.abc`.

**Fix applied**: Changed to `from collections.abc import Iterable`. This was the only pre-existing bug that was fixed, because it prevented the entire test suite from running. It's a minimal compatibility fix with no behavioral change.

### 2. Missing "Jul" in `MONTH_NAMES` in `parser.py`

**Bug**: The `MONTH_NAMES` list in `parser.py` is:
```python
MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Aug", "Sep", "Oct", "Nov", "Dec",
]
```
"Jul" is missing between "Jun" and "Aug". This causes `parse_timestamp()` to raise `ValueError: 'Jul' is not in list` for any log line dated in July.

**Test affected**: `test_timestamp_july_parses_correctly`

**Why not fixed**: Out of scope — this is a bug in `parser.py`, which is not part of the refactor target.

### 3. String/int comparison in `status_filter` in `filters.py`

**Bug**: `status_filter` compares `entry.status == status` directly. When the CLI passes `--status "404"` as a string, this comparison fails because `entry.status` is an `int` (404) and the filter receives a `str` ("404").

**Test affected**: `test_status_filter_works_with_cli_string_input`

**Why not fixed**: Out of scope — this is a bug in `filters.py`, which is not part of the refactor target.

### 4. `url_regex_filter` uses `match()` instead of `search()` in `filters.py`

**Bug**: `url_regex_filter` uses `rx.match(entry.url)` which only matches at the start of the string. The test expects pattern "admin" to match "/admin/login", but `match()` fails because the URL starts with "/".

**Test affected**: `test_url_regex_finds_substring_match`

**Why not fixed**: Out of scope — this is a bug in `filters.py`, which is not part of the refactor target.

## Approaches Considered and Rejected

### Approach 1: Move `format_legacy` from `utils.py` to `output/legacy.py`

**Rejected**: The task says "Only `logalyzer/output.py` may be split." Moving `format_legacy` from `utils.py` would require modifying `utils.py`, which is out of scope. Instead, the function was copied to `legacy.py` while keeping the original in `utils.py`.

### Approach 2: Put `render_aggregate` in its own module

**Rejected**: `render_aggregate` is a single function. A dedicated module would add unnecessary granularity. It was placed in `plain_renderer.py` since its primary output mode is text.

### Approach 3: Keep `output.py` as a thin shim that imports from the subpackage

**Rejected**: The task explicitly requires replacing `output.py` with an `output/` package. A shim would leave dead code in the repo.
