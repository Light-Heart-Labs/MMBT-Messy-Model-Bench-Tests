# Triage Notes — logalyzer Issue Report Verification

## Overview

Reviewed 15 issues from a draft code-review report against the actual logalyzer codebase.
**6 real, 9 fabricated.**

## Real Issues (6)

| # | Issue | File:Line |
|---|-------|-----------|
| 001 | `from collections import Iterable` (removed in Python 3.10+) | `filters.py:5` |
| 002 | `eval()` on user-supplied expressions | `filters.py:59` |
| 004 | README claims "Real-time tail mode" that doesn't exist | `README.md:10` |
| 006 | `experimental.py` is never imported by any other module | `experimental.py` (whole file) |
| 013 | O(n²) list concatenation and string concatenation in `load()` | `io.py:24,27` |
| 014 | `ip_allowlist_filter` uses list membership instead of set | `filters.py:36` |

## Fabricated Issues (9)

| # | Issue | Why Fabricated |
|---|-------|----------------|
| 003 | SQL injection in parser.py | No SQL anywhere in the codebase. Parser uses regex only. |
| 005 | `--top` flag raises AttributeError | `--top` is correctly defined with `type=int` and works fine. |
| 007 | Missing CSRF in web.py | `web.py` does not exist. No web interface in the codebase. |
| 008 | `parse_line()` truncates at 8192 chars | No truncation logic exists in `parse_line()`. |
| 009 | `format_legacy()` in output.py is unused | `format_legacy()` is in `utils.py`, not `output.py`. Wrong file = fabricated. |
| 010 | Race condition in `load_iter()` | Each call opens its own file handle; no shared state. |
| 011 | `by_status()` double-counts 3xx | Simple Counter increment; no special 3xx handling exists. |
| 012 | `cache.py` doesn't invalidate stale entries | `cache.py` does not exist. No caching layer in the codebase. |
| 015 | `__init__.py` imports `LogEntry` from parser | `__init__.py` only contains `__version__`. No such import exists. |

## Key Observations

- The previous reviewer invented at least 3 files that don't exist: `web.py`, `cache.py`, and claimed `format_legacy()` was in `output.py` (it's in `utils.py`).
- Several claims about behavior (SQL injection, truncation, race conditions, double-counting) describe bugs that simply aren't present in the code.
- The real issues are all verifiable and well-documented in the actual source.
