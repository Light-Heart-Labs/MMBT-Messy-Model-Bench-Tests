# Verification Notes for logalyzer Code Review Triage

## Overview

Reviewed 15 issues from a draft code-review report against the actual logalyzer codebase. Found **6 real** issues and **9 fabricated** ones.

## Real Issues (6)

### 001 — `from collections import Iterable` (filters.py:5)
Confirmed. This import was removed in Python 3.10. Running the code on Python 3.11 produces `ImportError: cannot import name 'Iterable' from 'collections'`.

### 002 — `eval()` usage (filters.py:59)
Confirmed. The `expression_filter()` function uses `eval()` with `{"__builtins__": {}}` as globals. While this restricts built-in functions, it still allows attribute access on the `entry` object, which could be exploited.

### 004 — README false claim about tail mode
Confirmed. README.md line 12 claims "Real-time tail mode for live log streams" but no `--tail` flag exists in cli.py and no streaming logic is present anywhere.

### 006 — experimental.py is dead code
Confirmed. The file exists but is never imported by any other module in the codebase (verified with grep across all .py files).

### 013 — O(n²) performance in io.py load()
Confirmed. Two performance anti-patterns:
- Line 24: `result = result + [entry]` creates a new list each iteration
- Line 27: `accumulated = accumulated + ch` builds strings character-by-character

### 014 — O(n) membership test in ip_allowlist_filter
Confirmed. `entry.ip in allowlist` where allowlist is a list (from argparse `action='append'`). Should use a set for O(1) lookups.

## Fabricated Issues (9)

### 003 — SQL injection in parser.py
Fabricated. parser.py contains no SQL queries, no database interaction, and no string concatenation for SQL. The parser only does regex matching.

### 005 — --top flag broken
Fabricated. The `--top` argument is properly defined with `type=int, default=None` (cli.py:33) and correctly passed to `by_url()` (cli.py:64). No AttributeError would occur.

### 007 — CSRF in web.py
Fabricated. `logalyzer/web.py` does not exist. There is no web interface in the codebase.

### 008 — 8192 character truncation in parser.py
Fabricated. `parse_line()` does not truncate input. It strips whitespace and applies a regex with no length limit.

### 009 — format_legacy() in output.py
Fabricated. The function `format_legacy()` exists in `utils.py:21`, NOT in `output.py`. The issue cites the wrong file. While the function is indeed unused, the claim as written is fabricated because it references a non-existent location.

### 010 — Race condition in io.py load_iter()
Fabricated. `load_iter()` opens its own file handle per call. There is no shared mutable state between concurrent calls. No lock is needed.

### 011 — Double-counting 3xx in by_status()
Fabricated. `by_status()` simply increments a Counter for each entry's status code. There is no special handling of 3xx codes and no double-counting.

### 012 — Stale cache in cache.py
Fabricated. `logalyzer/cache.py` does not exist. There is no caching layer in the codebase.

### 015 — __init__.py imports LogEntry
Fabricated. `__init__.py` only contains `__version__ = '0.2.0'`. It does not import `LogEntry` from anywhere. No ImportError would occur.
