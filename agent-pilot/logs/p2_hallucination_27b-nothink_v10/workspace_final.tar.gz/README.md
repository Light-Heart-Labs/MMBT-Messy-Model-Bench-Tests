# Logalyzer Code Review Triage

This directory contains the results of verifying 15 issues from a draft code-review report against the actual logalyzer codebase.

## Files

- **triage.json** — The main output. Contains verdict (`real` or `fabricated`) and evidence for each of the 15 issues, plus a summary count.
- **notes.md** — Detailed reasoning for each verdict, organized by real vs. fabricated.
- **decisions/** — ADRs (Architecture Decision Records) for borderline calls where the issue description partially matched reality but cited the wrong file or mischaracterized the code.

## Summary

| Verdict | Count |
|---------|-------|
| Real | 6 |
| Fabricated | 9 |

### Real Issues
- **001**: `from collections import Iterable` — broken import (filters.py:5)
- **002**: `eval()` usage — security risk (filters.py:59)
- **004**: README false claim about tail mode
- **006**: experimental.py is dead code
- **013**: O(n²) performance in io.py load()
- **014**: O(n) membership test in ip_allowlist_filter

### Fabricated Issues
- **003**: SQL injection — no SQL in parser.py
- **005**: --top flag broken — it works correctly
- **007**: CSRF in web.py — file doesn't exist
- **008**: 8192 char truncation — no truncation exists
- **009**: format_legacy in output.py — it's in utils.py
- **010**: Race condition — no shared state
- **011**: Double-counting 3xx — no such behavior
- **012**: Stale cache — cache.py doesn't exist
- **015**: __init__.py imports LogEntry — it doesn't

## Methodology

Each issue was verified by:
1. Checking if the cited file exists
2. Reading the actual code at the cited location
3. Searching the entire codebase for the claimed behavior
4. Running the code where applicable (e.g., confirming the ImportError on issue 001)
