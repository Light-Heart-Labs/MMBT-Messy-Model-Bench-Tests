# ADR-002: Test coverage strategy for under-covered modules

## Context

Baseline coverage is 34%. The following modules have 0% or very low coverage:
- `experimental.py` — 0% (32 statements)
- `output.py` — 0% (35 statements)
- `utils.py` — 0% (21 statements)
- `io.py` — 0% (26 statements)
- `cli.py` — 0% (59 statements)
- `filters.py` — 74% (10 statements missed: `expression_filter`, `combine_and`)
- `parser.py` — 86% (7 statements missed: `parse_lines`, error paths)

## Decision

We will write tests for:

1. **experimental.py** — Full coverage of `detect_anomalies` and `session_window`
   including edge cases (empty entries, single entry, all same minute, etc.)

2. **output.py** — Full coverage of `to_json`, `to_csv`, `to_text`, `render_aggregate`
   including edge cases (empty entries, special characters in URLs, etc.)
   Also test `format_legacy` from utils.py which is called from output context.

3. **utils.py** — Edge cases for `format_bytes` (0, 1, boundary values, large numbers),
   `parse_iso_date` (invalid dates), `chunked` (empty, single, exact multiple, remainder),
   `format_legacy` (the uncovered function).

4. **io.py** — Test `load` and `load_iter` with real files, empty files,
   files with no trailing newline, files with only blank lines.

5. **cli.py** — Test `build_parser` and `main` with various argument combinations.
   Focus on integration paths.

6. **filters.py** — Test `expression_filter` and `combine_and` (the uncovered functions).

7. **parser.py** — Test `parse_lines` generator, malformed timestamps,
   edge cases in `parse_timestamp`.

## Not testing

- `benchmarks/bench.py` — Performance benchmarks, not testable with pytest
- The 3 pre-existing failing tests — Documented in `research/notes/known-bugs.md`

## Rationale

These modules represent the largest coverage gaps. Testing them provides
the most signal per test written. Edge cases and error paths are prioritized
over happy-path tests (which are already partially covered).
