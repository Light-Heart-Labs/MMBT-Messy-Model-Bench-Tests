# ADR-001: Handling `collections.Iterable` import error in Python 3.11+

## Context

`logalyzer/filters.py` contains `from collections import Iterable`, which was
deprecated in Python 3.3 and removed in Python 3.10+. This causes an
`ImportError` when running tests on Python 3.11.

## Decision

We cannot modify production code (per project rules). The existing tests
already fail to collect due to this bug. We work around it in test
infrastructure by patching `collections.Iterable` in `conftest.py` before
any module imports occur.

This is a test infrastructure workaround, not a production code change. The
production code remains byte-identical to the input.

## Consequences

- Tests can now run and collect properly
- The underlying bug in `filters.py` remains unfixed (documented)
- Any reviewer running `pytest` will see the same behavior

## Alternative considered

- Fixing the import in `filters.py` — rejected because it violates the
  "no production code changes" rule.
