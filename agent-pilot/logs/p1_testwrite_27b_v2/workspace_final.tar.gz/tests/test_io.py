"""Tests for io.py — file loading helpers.

These tests exercise code that has 0% baseline coverage.
"""
import os
import tempfile

from logalyzer.io import load, load_iter
from logalyzer.parser import LogEntry


SAMPLE_LINE = (
    '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] '
    '"GET /apache_pb.gif HTTP/1.0" 200 2326'
)


def _write_file(content):
    """Write content to a temp file and return its path."""
    f = tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False)
    f.write(content)
    f.close()
    return f.name


# ── load ────────────────────────────────────────────────────────────────────


def test_load_empty_file():
    """An empty file should produce an empty list."""
    path = _write_file("")
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_single_line_with_newline():
    """A file with one valid log line and trailing newline."""
    path = _write_file(SAMPLE_LINE + "\n")
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_single_line_without_trailing_newline():
    """A file with one valid log line but no trailing newline.
    This exercises the 'if accumulated' branch at the end of load()."""
    path = _write_file(SAMPLE_LINE)
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_multiple_lines():
    """A file with multiple valid log lines."""
    content = SAMPLE_LINE + "\n" + SAMPLE_LINE + "\n" + SAMPLE_LINE + "\n"
    path = _write_file(content)
    try:
        result = load(path)
        assert len(result) == 3
    finally:
        os.unlink(path)


def test_load_mixed_valid_and_invalid_lines():
    """A file with a mix of valid and invalid lines should skip invalid ones."""
    content = SAMPLE_LINE + "\ngarbage line\n" + SAMPLE_LINE + "\n"
    path = _write_file(content)
    try:
        result = load(path)
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_only_blank_lines():
    """A file with only blank lines should produce an empty list."""
    path = _write_file("\n\n\n")
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_only_garbage_lines():
    """A file with only invalid lines should produce an empty list."""
    path = _write_file("not a log line\nalso not a log line\n")
    try:
        result = load(path)
        assert result == []
    finally:
        os.unlink(path)


def test_load_unicode_in_url():
    """A file with unicode characters in URLs should parse correctly."""
    line = (
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] '
        '"GET /café HTTP/1.0" 200 100'
    )
    path = _write_file(line + "\n")
    try:
        result = load(path)
        assert len(result) == 1
        assert result[0].url == "/café"
    finally:
        os.unlink(path)


def test_load_returns_list_of_logentry():
    """load() should return a list of LogEntry objects."""
    path = _write_file(SAMPLE_LINE + "\n")
    try:
        result = load(path)
        assert isinstance(result, list)
        assert all(isinstance(e, LogEntry) for e in result)
    finally:
        os.unlink(path)


# ── load_iter ───────────────────────────────────────────────────────────────


def test_load_iter_empty_file():
    """An empty file should produce no entries from the generator."""
    path = _write_file("")
    try:
        result = list(load_iter(path))
        assert result == []
    finally:
        os.unlink(path)


def test_load_iter_single_line():
    """A file with one valid log line."""
    path = _write_file(SAMPLE_LINE + "\n")
    try:
        result = list(load_iter(path))
        assert len(result) == 1
        assert result[0].ip == "127.0.0.1"
    finally:
        os.unlink(path)


def test_load_iter_multiple_lines():
    """A file with multiple valid log lines."""
    content = SAMPLE_LINE + "\n" + SAMPLE_LINE + "\n"
    path = _write_file(content)
    try:
        result = list(load_iter(path))
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_skips_invalid_lines():
    """load_iter should skip lines that don't parse."""
    content = SAMPLE_LINE + "\ngarbage\n" + SAMPLE_LINE + "\n"
    path = _write_file(content)
    try:
        result = list(load_iter(path))
        assert len(result) == 2
    finally:
        os.unlink(path)


def test_load_iter_is_generator():
    """load_iter should return a generator, not a list."""
    path = _write_file(SAMPLE_LINE + "\n")
    try:
        result = load_iter(path)
        # Generators have __next__ method
        assert hasattr(result, '__next__')
    finally:
        os.unlink(path)


def test_load_iter_lazy_evaluation():
    """load_iter should be lazy — we can consume entries one at a time."""
    content = SAMPLE_LINE + "\n" + SAMPLE_LINE + "\n"
    path = _write_file(content)
    try:
        gen = load_iter(path)
        first = next(gen)
        assert first.ip == "127.0.0.1"
        second = next(gen)
        assert second.ip == "127.0.0.1"
        try:
            next(gen)
            assert False, "Expected StopIteration"
        except StopIteration:
            pass
    finally:
        os.unlink(path)
