"""Tests for utils.py — utility functions with edge cases.

These tests exercise code that has 0% baseline coverage, including
the deliberately uncovered `format_legacy()` function.
"""
from datetime import datetime, timezone

from logalyzer.utils import (
    parse_iso_date,
    format_bytes,
    format_legacy,
    chunked,
)
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── parse_iso_date ──────────────────────────────────────────────────────────


def test_parse_iso_date_valid():
    """A valid YYYY-MM-DD string should parse to midnight UTC."""
    dt = parse_iso_date("2026-01-15")
    assert dt == datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_leap_year():
    """Feb 29 on a leap year should parse correctly."""
    dt = parse_iso_date("2024-02-29")
    assert dt == datetime(2024, 2, 29, 0, 0, 0, tzinfo=timezone.utc)


def test_parse_iso_date_invalid_date_raises():
    """An invalid date string should raise ValueError from strptime."""
    try:
        parse_iso_date("2026-13-01")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_wrong_format_raises():
    """A string in the wrong format should raise ValueError."""
    try:
        parse_iso_date("01/15/2026")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_iso_date_empty_string_raises():
    """An empty string should raise ValueError."""
    try:
        parse_iso_date("")
        assert False, "Expected ValueError"
    except ValueError:
        pass


# ── format_bytes ────────────────────────────────────────────────────────────


def test_format_bytes_zero():
    """Zero bytes should format as '0.0 B'."""
    assert format_bytes(0) == "0.0 B"


def test_format_bytes_one():
    """One byte should format as '1.0 B'."""
    assert format_bytes(1) == "1.0 B"


def test_format_bytes_below_kb():
    """Values below 1024 should stay in bytes."""
    assert format_bytes(512) == "512.0 B"
    assert format_bytes(1023) == "1023.0 B"


def test_format_bytes_exactly_kb():
    """Exactly 1024 bytes should format as '1.0 KB'."""
    assert format_bytes(1024) == "1.0 KB"


def test_format_bytes_exactly_mb():
    """Exactly 1 MB should format as '1.0 MB'."""
    assert format_bytes(1024 * 1024) == "1.0 MB"


def test_format_bytes_exactly_gb():
    """Exactly 1 GB should format as '1.0 GB'."""
    assert format_bytes(1024 ** 3) == "1.0 GB"


def test_format_bytes_exactly_tb():
    """Exactly 1 TB should format as '1.0 TB'."""
    assert format_bytes(1024 ** 4) == "1.0 TB"


def test_format_bytes_above_tb():
    """Values above 1 TB should format in PB (the fallback)."""
    result = format_bytes(1024 ** 5)
    assert "PB" in result


def test_format_bytes_fractional():
    """Fractional values should show one decimal place."""
    # 1536 bytes = 1.5 KB
    assert format_bytes(1536) == "1.5 KB"


def test_format_bytes_negative():
    """Negative byte counts — the function doesn't guard against this.
    It will produce negative values in the current unit."""
    result = format_bytes(-1024)
    assert result == "-1024.0 B"


# ── format_legacy ───────────────────────────────────────────────────────────


def test_format_legacy_basic():
    """format_legacy should produce the pipe-delimited string format."""
    e = _entry(ip="192.168.1.1", status=404, url="/missing")
    result = format_legacy(e)
    assert "192.168.1.1" in result
    assert "404" in result
    assert "/missing" in result
    assert "|" in result


def test_format_legacy_timestamp_format():
    """format_legacy includes the ISO timestamp."""
    e = _entry()
    result = format_legacy(e)
    assert "2026-01-01" in result


def test_format_legacy_field_order():
    """format_legacy outputs fields in order: ip | timestamp | status | url."""
    e = _entry(ip="1.2.3.4", status=500, url="/error")
    result = format_legacy(e)
    parts = [p.strip() for p in result.split("|")]
    assert parts[0] == "1.2.3.4"
    assert "500" in parts[2]
    assert parts[3] == "/error"


# ── chunked ─────────────────────────────────────────────────────────────────


def test_chunked_empty():
    """An empty sequence should produce no chunks."""
    result = list(chunked([], 3))
    assert result == []


def test_chunked_single_item():
    """A single item should produce one chunk of size 1."""
    result = list(chunked([1], 3))
    assert result == [[1]]


def test_chunked_exact_multiple():
    """When the sequence length is an exact multiple of chunk size,
    all chunks should be full."""
    result = list(chunked([1, 2, 3, 4, 5, 6], 3))
    assert result == [[1, 2, 3], [4, 5, 6]]


def test_chunked_with_remainder():
    """When the sequence length is not a multiple of chunk size,
    the last chunk should contain the remainder."""
    result = list(chunked([1, 2, 3, 4, 5], 3))
    assert result == [[1, 2, 3], [4, 5]]


def test_chunked_size_one():
    """Chunk size of 1 should produce one-element chunks."""
    result = list(chunked([1, 2, 3], 1))
    assert result == [[1], [2], [3]]


def test_chunked_size_larger_than_sequence():
    """Chunk size larger than the sequence should produce one chunk."""
    result = list(chunked([1, 2], 10))
    assert result == [[1, 2]]


def test_chunked_generator_behavior():
    """chunked should be a generator (lazy evaluation)."""
    gen = chunked([1, 2, 3, 4], 2)
    first = next(gen)
    assert first == [1, 2]
    second = next(gen)
    assert second == [3, 4]
    try:
        next(gen)
        assert False, "Expected StopIteration"
    except StopIteration:
        pass


def test_chunked_with_strings():
    """chunked should work with any iterable, not just numbers."""
    result = list(chunked(["a", "b", "c", "d"], 2))
    assert result == [["a", "b"], ["c", "d"]]
