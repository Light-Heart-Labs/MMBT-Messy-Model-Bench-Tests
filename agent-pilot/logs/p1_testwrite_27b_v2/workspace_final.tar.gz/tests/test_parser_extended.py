"""Extended tests for parser.py — parse_lines generator and edge cases.

These tests cover the 14% of parser.py that was not covered by the
original test suite (parse_lines generator, error paths).
"""
from datetime import datetime, timezone

from logalyzer.parser import parse_line, parse_lines, parse_timestamp


SAMPLE_LINE = (
    '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] '
    '"GET /apache_pb.gif HTTP/1.0" 200 2326'
)


# ── parse_lines ─────────────────────────────────────────────────────────────


def test_parse_lines_empty():
    """parse_lines with an empty iterable should produce no entries."""
    result = list(parse_lines([]))
    assert result == []


def test_parse_lines_single_line():
    """parse_lines with one valid line should yield one entry."""
    result = list(parse_lines([SAMPLE_LINE]))
    assert len(result) == 1
    assert result[0].ip == "127.0.0.1"


def test_parse_lines_multiple_lines():
    """parse_lines with multiple valid lines should yield multiple entries."""
    lines = [SAMPLE_LINE, SAMPLE_LINE, SAMPLE_LINE]
    result = list(parse_lines(lines))
    assert len(result) == 3


def test_parse_lines_skips_invalid_lines():
    """parse_lines should skip lines that don't parse."""
    lines = [SAMPLE_LINE, "garbage", "", SAMPLE_LINE]
    result = list(parse_lines(lines))
    assert len(result) == 2


def test_parse_lines_skips_empty_lines():
    """parse_lines should skip empty lines."""
    lines = ["", "  ", SAMPLE_LINE, ""]
    result = list(parse_lines(lines))
    assert len(result) == 1


def test_parse_lines_is_generator():
    """parse_lines should return a generator."""
    result = parse_lines([SAMPLE_LINE])
    assert hasattr(result, '__next__')


def test_parse_lines_lazy_evaluation():
    """parse_lines should be lazy — entries are yielded one at a time."""
    lines = [SAMPLE_LINE, SAMPLE_LINE, SAMPLE_LINE]
    gen = parse_lines(lines)
    first = next(gen)
    assert first.ip == "127.0.0.1"
    second = next(gen)
    assert second.ip == "127.0.0.1"
    third = next(gen)
    assert third.ip == "127.0.0.1"
    try:
        next(gen)
        assert False, "Expected StopIteration"
    except StopIteration:
        pass


def test_parse_lines_with_malformed_timestamp():
    """Lines with malformed timestamps should be skipped by parse_lines.
    
    The parse_line function catches ValueError from parse_timestamp and
    returns None, which parse_lines filters out.
    """
    line = '127.0.0.1 - - [invalid-timestamp] "GET / HTTP/1.0" 200 100'
    result = list(parse_lines([line]))
    assert result == []


# ── parse_timestamp edge cases ──────────────────────────────────────────────


def test_parse_timestamp_positive_tz_offset():
    """A positive timezone offset should shift the time backward to UTC."""
    # 13:00 +0500 means UTC is 13:00 - 5:00 = 08:00
    ts = parse_timestamp("10/Oct/2000:13:00:00 +0500")
    assert ts.hour == 8
    assert ts.minute == 0
    assert ts.tzinfo is timezone.utc


def test_parse_timestamp_utc_offset():
    """A +0000 timezone offset should keep the time as-is."""
    ts = parse_timestamp("10/Oct/2000:13:00:00 +0000")
    assert ts.hour == 13
    assert ts.tzinfo is timezone.utc


def test_parse_timestamp_large_negative_offset():
    """A large negative offset like -1200 should shift forward."""
    # 01:00 -1200 means UTC is 01:00 + 12:00 = 13:00
    ts = parse_timestamp("10/Oct/2000:01:00:00 -1200")
    assert ts.hour == 13


def test_parse_timestamp_invalid_format_raises():
    """An invalid timestamp format should raise ValueError."""
    try:
        parse_timestamp("not-a-timestamp")
        assert False, "Expected ValueError"
    except ValueError as exc:
        assert "unrecognized timestamp format" in str(exc)


def test_parse_timestamp_missing_timezone_raises():
    """A timestamp missing the timezone portion should raise ValueError."""
    try:
        parse_timestamp("10/Oct/2000:13:55:36")
        assert False, "Expected ValueError"
    except ValueError:
        pass


def test_parse_timestamp_invalid_month_raises():
    """A timestamp with an invalid month abbreviation should raise ValueError.
    
    NOTE: 'Jul' is missing from MONTH_NAMES (known bug). This test
    documents that behavior.
    """
    try:
        parse_timestamp("04/Jul/2026:12:00:00 +0000")
        assert False, "Expected ValueError"
    except ValueError as exc:
        assert "not in list" in str(exc)


def test_parse_timestamp_december_parses():
    """December parses but with wrong month number due to missing 'Jul' in MONTH_NAMES.
    
    BUG: 'Jul' is missing from MONTH_NAMES, so 'Dec' maps to index 10,
    which becomes month 11 instead of 12. This test documents the actual
    (buggy) behavior without fixing it.
    """
    ts = parse_timestamp("25/Dec/2025:23:59:59 +0000")
    # Due to missing 'Jul', Dec maps to month 11 instead of 12
    assert ts.month == 11
    assert ts.day == 25
    assert ts.year == 2025


def test_parse_timestamp_march_parses():
    """March should parse correctly (middle of the list)."""
    ts = parse_timestamp("15/Mar/2026:00:00:00 +0000")
    assert ts.month == 3


# ── parse_line edge cases ──────────────────────────────────────────────────


def test_parse_line_with_whitespace():
    """parse_line should strip leading/trailing whitespace."""
    line = "  " + SAMPLE_LINE + "  "
    e = parse_line(line)
    assert e is not None
    assert e.ip == "127.0.0.1"


def test_parse_line_with_lowercase_method_returns_none():
    """The regex requires uppercase methods. Lowercase should return None."""
    line = '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] "get / HTTP/1.0" 200 100'
    assert parse_line(line) is None


def test_parse_line_with_special_url_characters():
    """URLs with query strings and special characters should parse."""
    line = (
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] '
        '"GET /search?q=hello+world&page=1 HTTP/1.1" 200 5000'
    )
    e = parse_line(line)
    assert e is not None
    assert e.url == "/search?q=hello+world&page=1"
    assert e.bytes == 5000


def test_parse_line_with_ipv6():
    """IPv6 addresses should parse (they match \S+)."""
    line = (
        '::1 - - [10/Oct/2000:13:55:36 +0000] '
        '"GET / HTTP/1.1" 200 100'
    )
    e = parse_line(line)
    assert e is not None
    assert e.ip == "::1"


def test_parse_line_with_large_status_code():
    """Non-standard status codes should still parse."""
    line = (
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] '
        '"GET / HTTP/1.1" 999 100'
    )
    e = parse_line(line)
    assert e is not None
    assert e.status == 999


def test_parse_line_with_large_byte_count():
    """Very large byte counts should parse correctly."""
    line = (
        '127.0.0.1 - - [10/Oct/2000:13:55:36 +0000] '
        '"GET / HTTP/1.1" 200 9999999999'
    )
    e = parse_line(line)
    assert e is not None
    assert e.bytes == 9999999999
