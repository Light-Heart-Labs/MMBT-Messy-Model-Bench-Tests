"""Shared pytest fixtures."""
import sys
from pathlib import Path

# Make logalyzer importable when tests run from the project root
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Workaround: filters.py imports `collections.Iterable` which was removed in
# Python 3.10+. We patch it before any logalyzer module is imported.
# This is a test-only workaround; production code is not modified.
import collections
from collections.abc import Iterable as _Iterable
if not hasattr(collections, "Iterable"):
    collections.Iterable = _Iterable
