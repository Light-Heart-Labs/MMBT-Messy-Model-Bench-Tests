"""Tests for experimental.py — anomaly detection and session windowing.

These tests exercise code that has 0% baseline coverage.
"""
from datetime import datetime, timezone, timedelta

from logalyzer.experimental import detect_anomalies, session_window
from logalyzer.parser import LogEntry


def _entry(ts, ip="10.0.0.1", **kw):
    """Helper to create a LogEntry with a specific timestamp."""
    return LogEntry(
        ip=ip,
        user="-",
        timestamp=ts,
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
        **kw,
    )


# ── detect_anomalies ────────────────────────────────────────────────────────


def test_detect_anomalies_empty_entries():
    """Empty input should return an empty list (no anomalies possible)."""
    assert detect_anomalies([]) == []


def test_detect_anomalies_single_entry():
    """A single entry has std=0, so threshold=mean. Count=1, threshold=1.
    1 > 1 is False, so no anomalies."""
    e = _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))
    assert detect_anomalies([e]) == []


def test_detect_anomalies_uniform_distribution():
    """When all minutes have the same count, std=0, threshold=mean.
    No minute exceeds the threshold."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    # 10 entries, 10 different minutes, each with count 1
    assert detect_anomalies(entries) == []


def test_detect_anomalies_spike_detected():
    """A minute with many more requests than others should be flagged.
    
    We need a large enough spike to exceed mean + 3*std.
    With 10 normal minutes at count 1 and 1 spike at count 200:
    mean = (10*1 + 200)/11 = 210/11 ≈ 19.09
    var = (10*(1-19.09)^2 + (200-19.09)^2)/11 ≈ (10*327.25 + 32544.8)/11 ≈ 3113.45
    std ≈ 55.8
    threshold ≈ 19.09 + 167.4 = 186.5
    200 > 186.5 → True
    """
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    # 10 normal minutes with 1 request each
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    # 1 spike minute with 200 requests
    spike_time = base + timedelta(minutes=100)
    entries += [_entry(spike_time) for _ in range(200)]
    anomalies = detect_anomalies(entries)
    assert spike_time in anomalies


def test_detect_anomalies_all_same_minute():
    """All entries in the same minute — std=0, threshold=mean=count.
    count > count is False, so no anomalies."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base) for _ in range(100)]
    assert detect_anomalies(entries) == []


def test_detect_anomalies_seconds_truncated_to_minute():
    """Entries within the same minute (different seconds) should be bucketed together."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=30)),
        _entry(base + timedelta(seconds=59)),
    ]
    # All 3 entries are in the same minute bucket
    anomalies = detect_anomalies(entries)
    # With only 1 bucket, std=0, threshold=3, 3>3 is False
    assert anomalies == []


def test_detect_anomalies_multiple_anomalous_minutes():
    """Multiple minutes can be anomalous if they all exceed the threshold.
    
    10 normal minutes at count 1, 2 spike minutes at count 200 each.
    mean = (10 + 400)/12 = 35
    var = (10*(1-35)^2 + 2*(200-35)^2)/12 = (10*1156 + 2*27225)/12 = 66310/12 ≈ 5525.8
    std ≈ 74.3
    threshold ≈ 35 + 223 = 258
    200 > 258 is False... need bigger spikes.
    Let's use 500: mean = (10+1000)/12 = 84.17
    var = (10*(1-84.17)^2 + 2*(500-84.17)^2)/12 = (10*6907.1 + 2*172884)/12 = 414885/12 ≈ 34573.8
    std ≈ 185.9
    threshold ≈ 84.17 + 557.8 = 642
    500 > 642 is False... 
    Let's use 1000: mean = (10+2000)/12 = 167.5
    var = (10*(1-167.5)^2 + 2*(1000-167.5)^2)/12 = (10*27780.25 + 2*692890.6)/12 = 1663583.7/12 ≈ 138632
    std ≈ 372.3
    threshold ≈ 167.5 + 1117 = 1284.5
    1000 > 1284.5 is False... 
    
    The z-score approach makes it hard to get multiple anomalies.
    Let's try: 20 normal at 1, 2 spikes at 1000.
    mean = (20 + 2000)/22 = 91.82
    var = (20*(1-91.82)^2 + 2*(1000-91.82)^2)/22 = (20*8268.5 + 2*826850)/22 = 1736530/22 ≈ 78933
    std ≈ 281
    threshold ≈ 91.82 + 843 = 935
    1000 > 935 → True!
    """
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = []
    # 20 normal minutes with 1 request each
    for i in range(20):
        entries.append(_entry(base + timedelta(minutes=i)))
    # 2 spike minutes with 1000 requests each
    for spike_min in (100, 101):
        for _ in range(1000):
            entries.append(_entry(base + timedelta(minutes=spike_min)))
    anomalies = detect_anomalies(entries)
    assert len(anomalies) == 2
    assert base + timedelta(minutes=100) in anomalies
    assert base + timedelta(minutes=101) in anomalies


# ── session_window ──────────────────────────────────────────────────────────


def test_session_window_empty():
    """No entries means no sessions."""
    assert session_window([]) == []


def test_session_window_single_entry():
    """A single entry forms one session."""
    e = _entry(datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc))
    sessions = session_window([e])
    assert len(sessions) == 1
    ip, entries = sessions[0]
    assert ip == "10.0.0.1"
    assert len(entries) == 1


def test_session_window_single_ip_continuous():
    """All entries from one IP within the window form a single session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [_entry(base + timedelta(minutes=i)) for i in range(10)]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    assert len(sessions[0][1]) == 10


def test_session_window_single_ip_gap_exceeds_window():
    """A gap larger than window_seconds splits the session.
    
    The condition is `gap > window_seconds`, so we need gap > 1800.
    Gap of 31 minutes = 1860 seconds > 1800.
    """
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(minutes=10)),
        _entry(base + timedelta(minutes=41)),  # 31 min gap = 1860s > 1800s
        _entry(base + timedelta(minutes=50)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    assert len(sessions[0][1]) == 2
    assert len(sessions[1][1]) == 2


def test_session_window_multiple_ips():
    """Different IPs get separate sessions."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base, ip="10.0.0.1"),
        _entry(base + timedelta(minutes=1), ip="10.0.0.2"),
        _entry(base + timedelta(minutes=2), ip="10.0.0.1"),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
    ips = {s[0] for s in sessions}
    assert ips == {"10.0.0.1", "10.0.0.2"}


def test_session_window_entries_sorted_by_time():
    """Entries within a session should be sorted by timestamp."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base + timedelta(minutes=5)),
        _entry(base),
        _entry(base + timedelta(minutes=3)),
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 1
    _, session_entries = sessions[0]
    timestamps = [e.timestamp for e in session_entries]
    assert timestamps == sorted(timestamps)


def test_session_window_gap_exactly_at_boundary():
    """A gap exactly equal to window_seconds should NOT split the session
    (the condition is strictly greater than)."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1800)),  # exactly 30 min
    ]
    sessions = session_window(entries, window_seconds=1800)
    # gap == 1800, not > 1800, so same session
    assert len(sessions) == 1
    assert len(sessions[0][1]) == 2


def test_session_window_gap_just_over_boundary():
    """A gap just over window_seconds should split the session."""
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        _entry(base),
        _entry(base + timedelta(seconds=1801)),  # 1 second over
    ]
    sessions = session_window(entries, window_seconds=1800)
    assert len(sessions) == 2
