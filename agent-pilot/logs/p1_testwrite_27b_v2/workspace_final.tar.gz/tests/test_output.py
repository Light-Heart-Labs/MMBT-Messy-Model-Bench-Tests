"""Tests for output.py — JSON, CSV, text, and aggregate renderers.

These tests exercise code that has 0% baseline coverage.
"""
from datetime import datetime, timezone

from logalyzer.output import to_json, to_csv, to_text, render_aggregate
from logalyzer.parser import LogEntry


def _entry(**kw):
    """Helper to create a LogEntry."""
    defaults = dict(
        ip="10.0.0.1",
        user="-",
        timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
        method="GET",
        url="/",
        protocol="HTTP/1.1",
        status=200,
        bytes=100,
    )
    defaults.update(kw)
    return LogEntry(**defaults)


# ── to_json ─────────────────────────────────────────────────────────────────


def test_to_json_empty():
    """Empty entries list should produce an empty JSON array."""
    assert to_json([]) == "[]"


def test_to_json_single_entry():
    """A single entry should produce a JSON array with one object."""
    e = _entry()
    result = to_json([e])
    assert result.startswith("[")
    assert result.endswith("]")
    assert '"ip":"10.0.0.1"' in result
    assert '"status":200' in result
    assert '"bytes":100' in result


def test_to_json_multiple_entries():
    """Multiple entries should produce a JSON array with multiple objects."""
    e1 = _entry(ip="10.0.0.1", status=200)
    e2 = _entry(ip="10.0.0.2", status=404)
    result = to_json([e1, e2])
    assert '"ip":"10.0.0.1"' in result
    assert '"ip":"10.0.0.2"' in result
    assert '"status":200' in result
    assert '"status":404' in result


def test_to_json_special_characters_in_url():
    """URLs with special characters should be included as-is in JSON output.
    
    NOTE: The current implementation does NOT escape special JSON characters
    like quotes or backslashes in URL strings. This test documents current
    behavior without fixing it.
    """
    e = _entry(url='/path?q=1&foo="bar"')
    result = to_json([e])
    # The URL is included literally (no escaping)
    assert '/path?q=1&foo=' in result


def test_to_json_unicode_url():
    """URLs with unicode characters should be included in JSON output."""
    e = _entry(url="/café")
    result = to_json([e])
    assert "café" in result


def test_to_json_zero_bytes():
    """Entries with zero bytes should render correctly."""
    e = _entry(bytes=0)
    result = to_json([e])
    assert '"bytes":0' in result


# ── to_csv ──────────────────────────────────────────────────────────────────


def test_to_csv_empty():
    """Empty entries should produce only the header row."""
    result = to_csv([])
    lines = result.strip().split('\n')
    assert len(lines) == 1
    assert "ip" in lines[0]
    assert "status" in lines[0]


def test_to_csv_single_entry():
    """A single entry should produce header + one data row."""
    e = _entry()
    result = to_csv([e])
    lines = result.strip().split('\n')
    assert len(lines) == 2
    assert "10.0.0.1" in lines[1]
    assert "200" in lines[1]


def test_to_csv_multiple_entries():
    """Multiple entries should produce header + multiple data rows."""
    e1 = _entry(ip="10.0.0.1")
    e2 = _entry(ip="10.0.0.2")
    result = to_csv([e1, e2])
    lines = result.strip().split('\n')
    assert len(lines) == 3


def test_to_csv_comma_in_url():
    """URLs containing commas should be properly quoted by csv.writer."""
    e = _entry(url="/path?a=1,b=2")
    result = to_csv([e])
    # csv.writer should quote fields containing commas
    assert '"/path?a=1,b=2"' in result or "/path?a=1,b=2" in result


# ── to_text ─────────────────────────────────────────────────────────────────


def test_to_text_empty():
    """Empty entries should produce an empty string."""
    assert to_text([]) == ""


def test_to_text_single_entry():
    """A single entry should produce one line of text."""
    e = _entry()
    result = to_text([e])
    assert "10.0.0.1" in result
    assert "GET" in result
    assert "200" in result
    assert "/" in result


def test_to_text_multiple_entries():
    """Multiple entries should produce multiple lines separated by newlines."""
    e1 = _entry(ip="10.0.0.1")
    e2 = _entry(ip="10.0.0.2")
    result = to_text([e1, e2])
    lines = result.split('\n')
    assert len(lines) == 2


def test_to_text_ip_alignment():
    """IP addresses should be right-aligned in a 15-character field."""
    e1 = _entry(ip="1.2.3.4")
    e2 = _entry(ip="123.45.67.89")
    result = to_text([e1, e2])
    lines = result.split('\n')
    # Both lines should have the method at the same column
    method_col_1 = lines[0].find("GET")
    method_col_2 = lines[1].find("GET")
    assert method_col_1 == method_col_2


# ── render_aggregate ────────────────────────────────────────────────────────


def test_render_aggregate_text_with_items():
    """Aggregate with .items() (like Counter) should render as key\tvalue lines."""
    from collections import Counter
    agg = Counter({"a": 1, "b": 2})
    result = render_aggregate(agg, fmt="text")
    assert "a\t1" in result
    assert "b\t2" in result


def test_render_aggregate_text_with_list_of_tuples():
    """Aggregate as list of tuples should render as key\tvalue lines."""
    agg = [("a", 1), ("b", 2)]
    result = render_aggregate(agg, fmt="text")
    assert "a\t1" in result
    assert "b\t2" in result


def test_render_aggregate_json_with_items():
    """Aggregate with .items() should render as JSON-like object."""
    from collections import Counter
    agg = Counter({"a": 1, "b": 2})
    result = render_aggregate(agg, fmt="json")
    assert '"a":1' in result
    assert '"b":2' in result
    assert result.startswith("{")
    assert result.endswith("}")


def test_render_aggregate_json_with_list_of_tuples():
    """Aggregate as list of tuples should render as JSON-like object."""
    agg = [("a", 1), ("b", 2)]
    result = render_aggregate(agg, fmt="json")
    assert '"a":1' in result
    assert '"b":2' in result


def test_render_aggregate_unknown_format_raises():
    """An unknown format should raise ValueError."""
    agg = {"a": 1}
    try:
        render_aggregate(agg, fmt="xml")
        assert False, "Expected ValueError"
    except ValueError as exc:
        assert "unknown format" in str(exc)


def test_render_aggregate_empty_counter():
    """An empty Counter should render as empty text."""
    from collections import Counter
    agg = Counter()
    result = render_aggregate(agg, fmt="text")
    assert result == ""


def test_render_aggregate_empty_list():
    """An empty list should render as empty text."""
    result = render_aggregate([], fmt="text")
    assert result == ""
