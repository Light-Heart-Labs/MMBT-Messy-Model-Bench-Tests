"""Tests for cli.py — command-line interface integration.

These tests exercise code that has 0% baseline coverage.
"""
import os
import tempfile

from logalyzer.cli import build_parser, main


SAMPLE_LINE = (
    '127.0.0.1 - frank [10/Oct/2000:13:55:36 -0700] '
    '"GET /apache_pb.gif HTTP/1.0" 200 2326'
)


def _write_log(content):
    """Write content to a temp log file and return its path."""
    f = tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False)
    f.write(content)
    f.close()
    return f.name


# ── build_parser ────────────────────────────────────────────────────────────


def test_build_parser_returns_argument_parser():
    """build_parser should return an argparse.ArgumentParser instance."""
    p = build_parser()
    assert p.prog == "logalyzer"


def test_build_parser_requires_paths():
    """The parser should require at least one positional path argument."""
    p = build_parser()
    try:
        p.parse_args([])
        assert False, "Expected SystemExit"
    except SystemExit:
        pass


def test_build_parser_version_flag():
    """The --version flag should be recognized."""
    p = build_parser()
    try:
        p.parse_args(["--version"])
        assert False, "Expected SystemExit from version action"
    except SystemExit as e:
        assert e.code == 0


def test_build_parser_status_flag():
    """The --status flag should be recognized and stored."""
    p = build_parser()
    args = p.parse_args(["--status", "404", "logfile.log"])
    assert args.status == "404"


def test_build_parser_url_flag():
    """The --url flag should be recognized and stored."""
    p = build_parser()
    args = p.parse_args(["--url", r"^/api", "logfile.log"])
    assert args.url == r"^/api"


def test_build_parser_ip_flag_repeatable():
    """The --ip flag should be repeatable (action='append')."""
    p = build_parser()
    args = p.parse_args(["--ip", "10.0.0.1", "--ip", "10.0.0.2", "logfile.log"])
    assert args.ip == ["10.0.0.1", "10.0.0.2"]


def test_build_parser_since_until_flags():
    """The --since and --until flags should parse ISO dates."""
    p = build_parser()
    args = p.parse_args(["--since", "2026-01-01", "--until", "2026-12-31", "logfile.log"])
    assert args.since is not None
    assert args.until is not None


def test_build_parser_aggregate_choices():
    """The --aggregate flag should only accept valid choices."""
    p = build_parser()
    args = p.parse_args(["--aggregate", "status", "logfile.log"])
    assert args.aggregate == "status"


def test_build_parser_aggregate_invalid_choice():
    """The --aggregate flag should reject invalid choices."""
    p = build_parser()
    try:
        p.parse_args(["--aggregate", "invalid", "logfile.log"])
        assert False, "Expected SystemExit"
    except SystemExit:
        pass


def test_build_parser_format_choices():
    """The --format flag should only accept valid choices."""
    p = build_parser()
    args = p.parse_args(["--format", "json", "logfile.log"])
    assert args.format == "json"


def test_build_parser_top_flag():
    """The --top flag should be parsed as an integer."""
    p = build_parser()
    args = p.parse_args(["--top", "10", "logfile.log"])
    assert args.top == 10


def test_build_parser_expr_flag():
    """The --expr flag should be recognized and stored."""
    p = build_parser()
    args = p.parse_args(["--expr", "entry.status >= 500", "logfile.log"])
    assert args.expr == "entry.status >= 500"


def test_build_parser_default_format_is_text():
    """The default output format should be 'text'."""
    p = build_parser()
    args = p.parse_args(["logfile.log"])
    assert args.format == "text"


def test_build_parser_default_ip_is_empty_list():
    """The default IP allowlist should be an empty list."""
    p = build_parser()
    args = p.parse_args(["logfile.log"])
    assert args.ip == []


def test_build_parser_default_aggregate_is_none():
    """The default aggregate should be None."""
    p = build_parser()
    args = p.parse_args(["logfile.log"])
    assert args.aggregate is None


# ── main ────────────────────────────────────────────────────────────────────


def test_main_returns_zero_on_success():
    """main() should return 0 on success."""
    path = _write_log(SAMPLE_LINE + "\n")
    try:
        result = main([path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_text_output_contains_ip():
    """Default text output should contain the IP address."""
    import subprocess
    path = _write_log(SAMPLE_LINE + "\n")
    try:
        result = main([path])
        assert result == 0
    finally:
        os.unlink(path)


def test_main_json_output():
    """JSON format output should be valid JSON-like structure."""
    path = _write_log(SAMPLE_LINE + "\n")
    try:
        # Capture stdout
        import io
        from contextlib import redirect_stdout
        buf = io.StringIO()
        with redirect_stdout(buf):
            main([path, "--format", "json"])
        output = buf.getvalue().strip()
        assert output.startswith("[")
        assert output.endswith("]")
        assert "127.0.0.1" in output
    finally:
        os.unlink(path)


def test_main_csv_output():
    """CSV format output should contain header row."""
    path = _write_log(SAMPLE_LINE + "\n")
    try:
        import io
        from contextlib import redirect_stdout
        buf = io.StringIO()
        with redirect_stdout(buf):
            main([path, "--format", "csv"])
        output = buf.getvalue().strip()
        assert "ip" in output
        assert "status" in output
    finally:
        os.unlink(path)


def test_main_aggregate_status():
    """Aggregate by status should produce status code counts."""
    path = _write_log(SAMPLE_LINE + "\n" + SAMPLE_LINE + "\n")
    try:
        import io
        from contextlib import redirect_stdout
        buf = io.StringIO()
        with redirect_stdout(buf):
            main([path, "--aggregate", "status"])
        output = buf.getvalue().strip()
        assert "200" in output
    finally:
        os.unlink(path)


def test_main_aggregate_url():
    """Aggregate by URL should produce URL counts."""
    path = _write_log(SAMPLE_LINE + "\n")
    try:
        import io
        from contextlib import redirect_stdout
        buf = io.StringIO()
        with redirect_stdout(buf):
            main([path, "--aggregate", "url"])
        output = buf.getvalue().strip()
        assert "/apache_pb.gif" in output
    finally:
        os.unlink(path)


def test_main_aggregate_hour():
    """Aggregate by hour should produce hour counts."""
    path = _write_log(SAMPLE_LINE + "\n")
    try:
        import io
        from contextlib import redirect_stdout
        buf = io.StringIO()
        with redirect_stdout(buf):
            main([path, "--aggregate", "hour"])
        output = buf.getvalue().strip()
        # The timestamp is 13:55:36 -0700 = 20:55:36 UTC, so hour 20
        assert "20" in output
    finally:
        os.unlink(path)


def test_main_aggregate_json_format():
    """Aggregate with JSON format should produce JSON-like output."""
    path = _write_log(SAMPLE_LINE + "\n")
    try:
        import io
        from contextlib import redirect_stdout
        buf = io.StringIO()
        with redirect_stdout(buf):
            main([path, "--aggregate", "status", "--format", "json"])
        output = buf.getvalue().strip()
        assert output.startswith("{")
        assert output.endswith("}")
    finally:
        os.unlink(path)


def test_main_empty_file():
    """main() with an empty log file should produce empty output."""
    path = _write_log("")
    try:
        import io
        from contextlib import redirect_stdout
        buf = io.StringIO()
        with redirect_stdout(buf):
            main([path])
        output = buf.getvalue().strip()
        assert output == ""
    finally:
        os.unlink(path)


def test_main_multiple_files():
    """main() should handle multiple log files."""
    path1 = _write_log(SAMPLE_LINE + "\n")
    path2 = _write_log(SAMPLE_LINE + "\n")
    try:
        import io
        from contextlib import redirect_stdout
        buf = io.StringIO()
        with redirect_stdout(buf):
            main([path1, path2])
        output = buf.getvalue().strip()
        # Should have 2 lines of output
        lines = output.split('\n')
        assert len(lines) == 2
    finally:
        os.unlink(path1)
        os.unlink(path2)
