# Known Bugs in Starter Codebase

These bugs exist in the original code and cause 3 pre-existing test failures.
Per project rules, we do NOT fix them — we document them and write new tests
that pass against the current (buggy) behavior.

## 1. Missing "Jul" in MONTH_NAMES (parser.py)

`logalyzer/parser.py` line 22-25 defines `MONTH_NAMES` but skips "Jul":
```python
MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Aug", "Sep", "Oct", "Nov", "Dec",
]
```
"Jul" is absent, so `parse_timestamp("04/Jul/2026:12:00:00 +0000")` raises
`ValueError: 'Jul' is not in list`. This causes
`test_timestamp_july_parses_correctly` to fail.

## 2. status_filter doesn't handle string input (filters.py)

`status_filter` compares `entry.status == status` directly. When the CLI passes
`--status "404"` as a string, `404 == "404"` is `False`. The test
`test_status_filter_works_with_cli_string_input` fails because of this type
mismatch.

## 3. url_regex_filter uses match() not search() (filters.py)

`url_regex_filter` uses `rx.match(entry.url)` which only matches at the start
of the string. Pattern "admin" won't match "/admin/login" because the URL
starts with "/". The test `test_url_regex_finds_substring_match` fails.
